#!/bin/bash
# f46_audit.sh — приёмочный стенд правок R46 (аудит-16):
#  A. update_dnsmasq_upstreams: порядок managed-блока — при
#     DNS_UNAVAILABLE резолверы провайдера/bootstrap первыми, мёртвый
#     40500 ПОСЛЕДНИМ; при живых портах — только порты + 40500 последним
#  B. рендер списков: порядок файла (не алфавит), висящий комментарий
#     остаётся хвостом, связка «заголовок+подзаголовок» без разрыва;
#     идемпотентность за один прогон; дифференциал totals/dups/errors
#     с r42 (3bd4fbf) на трёх наборах; run3 == run2
#  C. deploy: итоговое сообщение честное (ЧАСТИЧНО при unsafe, ✅ в else)
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f46chk
rm -rf "$F"; mkdir -p "$F"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. Порядок managed-блока DNS (R46-1, реальная функция) ═══"
awk '/^update_dnsmasq_upstreams\(\)/,/^}/' "$K/opt/bin/unblock_dnsmasq.sh" > "$F/udu.s"
cat > "$F/run.sh" <<'EOF'
DNS_UPSTREAM_BEGIN="# BEGIN KeenZOO managed DNS upstreams"
DNS_UPSTREAM_END="# END KeenZOO managed DNS upstreams"
safe_replace() { cat "$2" > "$1"; }
provider_resolver_list() { printf '77.88.8.8 77.88.8.7\n'; }
BOOTSTRAP_RESOLVERS="8.8.8.8 1.1.1.1"
. /tmp/f46chk/udu.s
DNS_WORKING_PORTS=""
DNSMASQ_CONF=/tmp/f46chk/d1.conf
printf 'listen-address=127.0.0.1\n' > "$DNSMASQ_CONF"
update_dnsmasq_upstreams
echo "== unavailable =="; sed -n '/BEGIN KeenZOO/,/END KeenZOO/p' "$DNSMASQ_CONF"
DNS_WORKING_PORTS="40508 40509"
DNSMASQ_CONF=/tmp/f46chk/d2.conf
printf 'listen-address=127.0.0.1\n' > "$DNSMASQ_CONF"
update_dnsmasq_upstreams
echo "== working =="; sed -n '/BEGIN KeenZOO/,/END KeenZOO/p' "$DNSMASQ_CONF"
EOF
OUT=$(sh "$F/run.sh" 2>&1)
U=$(printf '%s\n' "$OUT" | sed -n '/== unavailable ==/,/== working ==/p' | grep '^server=')
W=$(printf '%s\n' "$OUT" | sed -n '/== working ==/,$p' | grep '^server=')
[ "$(printf '%s\n' "$U" | head -1)" = "server=77.88.8.8" ] \
    && ok "A1: DNS_UNAVAILABLE — первым живой резолвер провайдера" \
    || bad "A1: первым: $(printf '%s\n' "$U" | head -1)"
[ "$(printf '%s\n' "$U" | tail -1)" = "server=127.0.0.1#40500" ] \
    && ok "A2: 40500 — последним (мёртвый адрес замыкает цепочку)" \
    || bad "A2: последним: $(printf '%s\n' "$U" | tail -1)"
[ "$(printf '%s\n' "$U" | wc -l)" = 5 ] && [ -z "$(printf '%s\n' "$U" | grep -v '77.88.8.8\|77.88.8.7\|8.8.8.8\|1.1.1.1\|40500')" ] \
    && ok "A3: состав unavailable: провайдер×2 + bootstrap×2 + 40500" \
    || bad "A3: состав: $U"
[ "$W" = "server=127.0.0.1#40508
server=127.0.0.1#40509
server=127.0.0.1#40500" ] \
    && ok "A4: working — только порты, 40500 последним (r42-поведение)" \
    || bad "A4: working: $W"

echo "═══ B. Рендер списков (R46-2) ═══"
python3 - "$K" "$F" <<'PYB'
import ast, importlib.util, io, os, subprocess, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import lists_core as lc

d = os.path.join(F, 'lists'); os.makedirs(d)
lc.UNBLOCK_DIR = d

cases = [
    ('шапка+раздел',
     '# KeenZOO VLESS\n# ——— раздел 1 ———\nexample.com\n',
     '# KeenZOO VLESS\n# ——— раздел 1 ———\nexample.com\n'),
    ('хвостовая пометка',
     'example.com\n# конец списка\n',
     'example.com\n\n# конец списка\n'),
    ('порядок разделов (не алфавит)',
     '# zeta\nz.com\n# alpha\na.com\n',
     '# zeta\nz.com\n\n# alpha\na.com\n'),
]
for name, text, expect in cases:
    p = os.path.join(d, name.split('(')[0].strip().replace(' ', '_') + '.txt')
    lc.parse_and_save(p, text)
    out = io.open(p, encoding='utf-8').read()
    if out != expect:
        bad(f'{name}: {out!r} != ожидаемому {expect!r}')
        continue
    lc.parse_and_save(p, out)
    out2 = io.open(p, encoding='utf-8').read()
    if out2 != out:
        bad(f'{name}: второй прогон изменил файл: {out2!r}')
    else:
        ok(f'B: {name}: вывод точен, идемпотентен за один прогон')

src = io.open(os.path.join(K, 'opt/etc/bot/handlers.py'), encoding='utf-8').read()
seg = [ast.get_source_segment(src, n) for n in ast.parse(src).body
       if isinstance(n, ast.FunctionDef) and n.name == 'sections_to_text'][0]
ns = {}
exec(seg, ns)
got = ns['sections_to_text'](
    [{'comment': 'hdr', 'entries': []},
     {'comment': 'sub', 'entries': ['a.com']}])
if got == '# hdr\n# sub\na.com':
    ok('B: sections_to_text: заголовок+подзаголовок без разрыва')
else:
    bad(f'sections_to_text: {got!r}')

r42_src = subprocess.run(
    ['git', '-C', K, 'show', '3bd4fbf:opt/etc/bot/lists_core.py'],
    capture_output=True, text=True).stdout
if not r42_src:
    has_git = subprocess.run(
        ['git', '-C', K, 'rev-parse', '--git-dir'],
        capture_output=True).returncode == 0
    if not has_git:
        # раскладка релиза (ZIP): дифференциал с r42 требует git-истории —
        # честный пропуск, не ошибка (см. README_TESTS)
        print('[SKIP] дифференциал с r42: нет git-истории (раскладка релиза)')
    else:
        bad('r42 lists_core недоступен в репозитории (нужен 3bd4fbf)')
else:
    r42_path = os.path.join(F, 'lists_core_r42.py')
    io.open(r42_path, 'w', encoding='utf-8').write(r42_src)
    spec = importlib.util.spec_from_file_location('lc_r42', r42_path)
    lc42 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lc42)
    datasets = [
        '# Alpha\n1.1.1.1\n8.8.8.8 # dup\n# Beta\nbad!!\n10.0.0.0/8\n8.8.8.8\n\n# Gamma\nexample.com\n*.wild.example\n',
        io.open(os.path.join(K, 'opt/etc/unblock/vless.txt'), encoding='utf-8').read(),
        io.open(os.path.join(K, 'opt/etc/unblock/bot.txt'), encoding='utf-8').read(),
    ]
    diff_ok = True
    for i, data in enumerate(datasets):
        dA = os.path.join(F, f'diff{i}a'); dB = os.path.join(F, f'diff{i}b')
        os.makedirs(dA); os.makedirs(dB)
        lc.UNBLOCK_DIR = dA; lc42.UNBLOCK_DIR = dB
        fn = f'set{i}.txt'
        rA = lc.parse_and_save(os.path.join(dA, fn), data)
        rB = lc42.parse_and_save(os.path.join(dB, fn), data)
        if set(rA) != set(rB):
            bad(f'набор {i}: ключи {set(rA)} != {set(rB)}'); diff_ok = False; continue
        for k in rA:
            if k == 'filepath':
                continue
            if rA[k] != rB[k]:
                bad(f'набор {i}: {k}: {rA[k]} != {rB[k]}'); diff_ok = False
        p2 = os.path.join(dA, fn)
        t2 = io.open(p2, encoding='utf-8').read()
        lc.parse_and_save(p2, t2)
        if io.open(p2, encoding='utf-8').read() != t2:
            bad(f'набор {i}: третий прогон изменил файл'); diff_ok = False
    if diff_ok:
        ok('B: дифференциал с r42: totals/dups/errors идентичны ×3; run3 == run2')

io.open(os.path.join(F, 'b.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
BP=0; BF=1
[ -s "$F/b.counts" ] && read BP BF < "$F/b.counts"
PASS=$((PASS+BP)); FAIL=$((FAIL+BF))

echo "═══ C. Честное итоговое сообщение deploy (R46-3) ═══"
grep -q 'Проект развёрнут ЧАСТИЧНО' "$K/opt/bin/deploy_bypass.sh" \
    && ok "C1: ветка ЧАСТИЧНО присутствует" || bad "C1: нет ветки ЧАСТИЧНО"
if grep -B2 '✅ Проект развёрнут' "$K/opt/bin/deploy_bypass.sh" | grep -q 'else'; then
    ok "C2: ✅ «развёрнут» — только в else (безопасная ветка)"
else
    bad "C2: ✅ вне условной ветки"
fi
grep -q 'if \[ "\${DEPLOY_UNSAFE_STATE:-0}" = 1 \]; then' "$K/opt/bin/deploy_bypass.sh" \
    && ok "C3: гейт DEPLOY_UNSAFE_STATE не тронут" || bad "C3: гейт исчез"

echo "═══ F46 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
