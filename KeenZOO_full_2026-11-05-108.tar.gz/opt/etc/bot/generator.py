#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
/opt/etc/bot/generator.py
"""

import os
import sys

# K60-05 (аудит-35): явный минимум интерпретатора (Flask 3.0.x — 3.8+,
# subprocess.run(capture_output=...) — 3.7+); прежде на старом
# интерпретаторе панель падала ImportError без объяснения. Чек до
# остальных импортов — сообщение попадает в stderr журнала сервиса.
if sys.version_info < (3, 8):
    print('KeenZOO: требуется Python 3.8+ (найден '
          + sys.version.split()[0]
          + '). Обновите python3 в Entware',
          file=sys.stderr)
    sys.exit(1)

import json
import errno
import ipaddress
import logging
import shutil
import subprocess
import tempfile
import threading
import signal
import time
import hashlib
import hmac
import html
import gzip
import re
import secrets
from urllib.parse import urlparse

from flask import (
    Flask, render_template_string,
    request, flash, redirect,
    url_for, abort, session, jsonify, Response,
)

# FB-188 (аудит-48, изоляция импорта): путь вычисляется от расположения файла
# generator.py, а не жёстко /opt/etc/bot — при запуске из копии дерева
# (стенды/verify) импортируются модули КОПИИ, а не установленные в /opt;
# на устройстве os.path.dirname(...) == '/opt/etc/bot' — поведение то же.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    import bot_config as config
except Exception as _cfg_err:
    # bot_config.py общий для панели и бота. При ошибке импорта оставляем
    # только минимальную диагностическую страницу, но не раскрываем через
    # HTTP текст исключения, исходную строку или traceback: в этой строке
    # могут находиться Telegram-токен и пароль панели.
    try:
        import traceback as _em_traceback
        _em_tb = _em_traceback.format_exc()
    except Exception:  # аварийная ветка сама падать не должна
        _em_tb = ''

    _em_kind = type(_cfg_err).__name__
    _em_line = getattr(_cfg_err, 'lineno', None)
    if not isinstance(_em_line, int) or _em_line <= 0:
        # Для исключения времени исполнения SyntaxError.lineno нет. Берём
        # только номер кадра bot_config.py, не читая исходную строку.
        _em_line = None
        _em_cursor = getattr(_cfg_err, '__traceback__', None)
        while _em_cursor is not None:
            try:
                if os.path.basename(
                        _em_cursor.tb_frame.f_code.co_filename) == \
                        'bot_config.py':
                    _em_line = int(_em_cursor.tb_lineno)
            except Exception:
                pass
            _em_cursor = _em_cursor.tb_next

    _em_public = _em_kind
    if _em_line is not None:
        _em_public += ', строка %d' % _em_line

    # Полный traceback нужен администратору, но содержит потенциальные
    # секреты. Пишем его отдельно и принудительно с правами root-only.
    # Env-путь оставлен для изолированного стенда; init-скрипт его не задаёт.
    _em_log_path = os.environ.get(
        'KEENZOO_EMERGENCY_LOG',
        '/opt/etc/bot/generator-emergency.log')
    _em_log_ok = False
    _em_fd = None
    try:
        _em_flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
        if hasattr(os, 'O_NOFOLLOW'):
            _em_flags |= os.O_NOFOLLOW
        _em_fd = os.open(_em_log_path, _em_flags, 0o600)
        os.fchmod(_em_fd, 0o600)
        with os.fdopen(
                _em_fd, 'w', encoding='utf-8', errors='replace') as _em_f:
            _em_fd = None
            _em_f.write(
                '%s\nОшибка импорта bot_config.py: %s\n\n%s' % (
                    time.strftime('%Y-%m-%d %H:%M:%S'),
                    _em_public,
                    _em_tb or '(traceback недоступен)\n'))
        _em_log_ok = True
    except Exception as _em_log_err:
        if _em_fd is not None:
            try:
                os.close(_em_fd)
            except Exception:
                pass
        # Не выводим str(_em_log_err): путь/текст системной ошибки тоже не
        # нужен HTTP-клиенту и может содержать лишние данные.
        sys.stderr.write(
            '[!] Не удалось создать закрытый аварийный журнал: %s\n'
            % type(_em_log_err).__name__)

    sys.stderr.write(
        '\n[!] Ошибка в /opt/etc/bot/bot_config.py: %s\n'
        '    Аварийный HTTP-режим доступен только через loopback.\n'
        % _em_public)
    if _em_log_ok:
        sys.stderr.write(
            '    Подробный диагноз: %s (режим 0600).\n\n'
            % _em_log_path)
    else:
        sys.stderr.write(
            '    Подробный диагноз записать не удалось.\n\n')
    sys.stderr.flush()

    # Обычный порт берётся из generator_settings сломанного сейчас
    # конфига, поэтому аварийный порт — из окружения или штатный 8080.
    try:
        _em_port = int(os.environ.get('KEENZOO_PANEL_PORT') or 8080)
    except (TypeError, ValueError):
        _em_port = 8080

    _em_app = Flask(__name__)
    _em_title = html.escape(_em_public)
    _em_log_hint = (
        'Полный диагноз записан в <code>%s</code> с режимом '
        '<code>0600</code>.' % html.escape(_em_log_path)
        if _em_log_ok else
        'Закрытый диагностический журнал создать не удалось.')

    @_em_app.route('/', defaults={'_em_path': ''})
    @_em_app.route('/<path:_em_path>')
    def _emergency_page(_em_path):
        _em_body = (
            "<!doctype html><html lang=ru><meta charset=utf-8>"
            "<title>KeenZOO: ошибка bot_config.py</title>"
            "<body style='font:14px/1.5 monospace;background:#1b1b1b;"
            "color:#eee;padding:24px;max-width:900px;margin:auto'>"
            "<h2 style='color:#ff7b72'>&#9888; Панель в аварийном режиме</h2>"
            "<p>Файл <b>/opt/etc/bot/bot_config.py</b> не читается &#8212; "
            "этот модуль общий для панели и бота, поэтому оба не работают, "
            "пока ошибка не исправлена.</p>"
            "<pre style='background:#000;padding:12px;color:#ffa657'>"
            + _em_title +
            "</pre><p>Исходная строка и traceback намеренно скрыты. "
            + _em_log_hint +
            "</p>"
            "<h3>Как исправить</h3>"
            "<pre style='background:#000;padding:12px;color:#8ddb8c'>"
            "ssh root@&lt;роутер&gt;\n"
            "vi /opt/etc/bot/bot_config.py   # правим указанную строку\n"
            "cd /opt/etc/bot &amp;&amp; python3 -c 'import bot_config'\n"
            "/opt/etc/init.d/S99generator restart\n"
            "/opt/etc/init.d/S99telegram_bot restart\n"
            "</pre>"
            "<p>Аварийная страница слушает только "
            "<code>127.0.0.1:%d</code>. Для просмотра с компьютера "
            "используйте SSH-туннель:</p>"
            "<pre style='background:#000;padding:12px;color:#8ddb8c'>"
            "ssh -L 18080:127.0.0.1:%d -p 222 root@&lt;роутер&gt;\n"
            "# затем откройте http://127.0.0.1:18080/"
            "</pre>"
            "<p style='color:#9c9c9c'>Либо вернуть конфиг из бэкапа: "
            "<code>sh /opt/bin/deploy_bypass.sh -restore</code> "
            "(восстановит и остальные файлы проекта).</p>"
            % (_em_port, _em_port))
        return Response(_em_body, 503, mimetype='text/html')

    try:
        # Auth-настройки лежат в сломанном bot_config и недоступны. Поэтому
        # fail-closed: никакого LAN/WAN listener, только SSH-защищённый
        # loopback. Обычная панель ниже по файлу сохраняет 0.0.0.0 + два
        # штатных рубежа (setup_firewall и security_checks).
        _em_app.run(host='127.0.0.1', port=_em_port,
                    threaded=True, use_reloader=False)
    except OSError as _em_bind_err:
        sys.stderr.write(
            '[!] Аварийная страница не заняла loopback-порт %s: %s\n'
            % (_em_port, type(_em_bind_err).__name__))
        sys.stderr.flush()
    raise SystemExit(0)

from utils import (
    shadowsocks_config,
    trojan_config,
    vless_config,
    tor_config,
    hysteria_config,
    apply_direct_config,
    keys_bridges_warnings,
    log_error,
    # show ntce status делегируется в utils.nfqws2_intelliqos_suspected
    nfqws2_intelliqos_suspected as _nfqws2_intelliqos_suspected,
)

# Журналирование: в лог попадают ТОЛЬКО ошибки. По умолчанию werkzeug
# пишет строку на КАЖДЫЙ HTTP-запрос, и generator.log неограниченно рос
# на накопителе с Entware. Оставляем уровень ERROR.
logging.basicConfig(level=logging.ERROR)
logging.getLogger('werkzeug').setLevel(logging.ERROR)

app = Flask(__name__)

# r94 (аудит r93, KZ93-02/KZ93-03, опция Ж — решение владельца
# 03.11.2026): глобальный гейт запросов — не больше 8 одновременных
# обработчиков (семафор DNS-маршрута остаётся вторым уровнем); прочие
# получают быстрый 503 busy. Werkzeug (threaded=True) создаёт поток на
# каждое соединение — гейт ограничивает одновременно РАБОТАЮЩИЕ
# обработчики (форки dig/iptables, рендеры); вместе со стеком 256 КиБ
# (r93) это удерживает профиль памяти панели на слабых устройствах
# 64–128 МБ. Ответ 503 той же формы, что busy DNS-маршрута: JS-потребители
# (r94, пакет Б) обрабатывают оба одинаково.
_REQ_GATE_MAX = 8
_REQ_GATE_WAIT = 1.0
_REQ_GATE = threading.BoundedSemaphore(_REQ_GATE_MAX)
_KZ_WSGI_ORIG = None


def _kz_install_request_gate():
    """Оборачивает WSGI-приложение глобальным семафором; повторный
    вызов — no-op (защита от двойной установки)."""
    global _KZ_WSGI_ORIG
    if _KZ_WSGI_ORIG is not None:
        return
    _KZ_WSGI_ORIG = app.wsgi_app

    def _gated(environ, start_response):
        if not _REQ_GATE.acquire(timeout=_REQ_GATE_WAIT):
            _body = json.dumps({
                'status': 'busy',
                'message': 'Панель занята — повторите через '
                           'несколько секунд'},
                ensure_ascii=False).encode('utf-8')
            # r95 (аудит r94, KZ94-05): Retry-After для честного
            # повтора клиентов (JS-поллеры обрабатывают busy).
            start_response(
                '503 Service Unavailable',
                [('Content-Type',
                  'application/json; charset=utf-8'),
                 ('Cache-Control', 'no-store'),
                 ('Retry-After', '1')])
            return [_body]
        try:
            return _KZ_WSGI_ORIG(environ, start_response)
        finally:
            _REQ_GATE.release()

    app.wsgi_app = _gated


_kz_install_request_gate()

# ── Единый источник настроек: bot_config.generator_settings ──────────────
# Раньше панель дублировала пути и порты собственными константами, из-за
# чего значения расходились с bot_config.py и shell-скриптами (характерный
# пример — lock_dir). Теперь всё читается из одного места.
_GS = getattr(config, 'generator_settings', {})

SECRET_FILE = _GS.get(
    'secret_file', '/opt/etc/bot/.secret_key')


def _load_or_create_secret():
    """
    Постоянный ключ подписи сессии. Хранится в файле, иначе при каждом
    перезапуске панели сессии (а с ними и CSRF-токены) обнулялись бы.
    Ошибки файловой системы не должны валить панель на старте: в худшем
    случае откатываемся на эфемерный ключ и пишем об этом в лог.
    """
    try:
        if os.path.exists(SECRET_FILE):
            with open(SECRET_FILE, 'r') as f:
                key = f.read().strip()
            if len(key) >= 32:
                return key

        os.makedirs(
            os.path.dirname(SECRET_FILE) or '.',
            exist_ok=True)

        key = hashlib.sha256(os.urandom(64)).hexdigest()
        # Права выставляются в момент создания, до записи содержимого.
        fd = os.open(
            SECRET_FILE,
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w') as f:
            f.write(key)
        return key
    except OSError as err:
        sys.stderr.write(
            f"[!] Не удалось сохранить {SECRET_FILE}: {err}. "
            "Сессии будут сбрасываться при перезапуске панели.\n")
        return hashlib.sha256(os.urandom(64)).hexdigest()


app.secret_key = _load_or_create_secret()
app.jinja_env.autoescape = True


def generate_csrf():
    """
    CSRF-токен хранится в серверной сессии и переиспользуется в течение
    всей сессии. Ключ подписи сессии сохраняется в SECRET_FILE и не
    меняется при перезапуске панели, поэтому токен остаётся стабильным
    между открытиями страниц, а не генерируется каждый раз заново.
    """
    token = session.get('csrf_token')

    if isinstance(token, str) and len(token) >= 32:
        return token

    token = hmac.new(
        app.secret_key.encode(),
        os.urandom(32),
        hashlib.sha256).hexdigest()

    session['csrf_token'] = token
    session.permanent = True
    session.modified = True
    return token


def validate_csrf(token):
    expected = session.get(
        'csrf_token', '')
    if (not expected
            or not isinstance(token, str)):
        return False
    return hmac.compare_digest(
        token, expected)


LAN_IP = _GS.get('listen_ip', getattr(config, 'routerip', '192.168.1.1'))
LISTEN_PORT = int(_GS.get('listen_port', 8080))
MAX_CONTENT_LENGTH = 1 * 1024 * 1024
UNBLOCK_TIMEOUT = int(_GS.get('unblock_timeout', 300))

# Панель обслуживает только внутренние сети. Публичные адреса и любые
# внешние подключения отклоняются до аутентификации.
# Учёт неудачных входов: {ip: (число_неудач, заблокирован_до)}.
# Хранится в памяти процесса — перезапуск панели сбрасывает счётчики,
# что приемлемо: панель доступна только из LAN.
_auth_fails = {}
_AUTH_MAX_FAILS = 5
_AUTH_BLOCK_SEC = 300
# AF-1 (аудит-22): жёсткий предел размера _auth_fails (см.
# _auth_fails_sweep): истёкшие записи чистятся, активные блокировки
# при переполнении выселяются ближайшими к истечению.
_AUTH_FAILS_MAX = 256

ALLOWED_SUBNETS = [
    ipaddress.ip_network('127.0.0.0/8'),
    ipaddress.ip_network('192.168.0.0/16'),
    ipaddress.ip_network('10.0.0.0/8'),
    ipaddress.ip_network('172.16.0.0/12'),
]

# O-1 (аудит-22): дополнительные доверенные имена для Origin-проверки
# POST-запросов. FB-14 (аудит-25, K50-4): штатное имя Keenetic
# 'my.keenetic.net' входит в базовый набор кода — прежде оно
# попадало только через конфиг, ключа которого нет в шаблоне, и
# панель по my.keenetic.net была read-only (GET проходит, POST —
# 403 CSRF). Секция generator в bot_config.py, ключ
# allowed_origin_hosts (список), только РАСШИРЯЕТ базовый набор.
_ORIGIN_EXTRA_HOSTS = ['my.keenetic.net'] + [
    str(h) for h in (_GS.get('allowed_origin_hosts', []) or [])]

GENERATOR_LOG = _GS.get(
    'log_file', '/opt/etc/bot/generator.log')
LOCK_DIR = _GS.get(
    'lock_dir', '/tmp/unblock_update.lockdir')
UPDATE_STATUS_FILE = _GS.get(
    'status_file', '/tmp/unblock_update_status.json')
UPDATE_LOG_FILE = _GS.get(
    'update_log', '/tmp/unblock_update.log')

# ── Обновление протоколов из веб-панели ──────────────────────────────
# Отдельные файлы состояния: обновление протоколов и пересборка списков
# запускаются независимо и не должны затирать статус друг друга.
PROTO_UPD_STATUS = (
    '/tmp/proto_update_status.json')
PROTO_UPD_LOG = (
    '/tmp/proto_update.log')
# Обновление всех компонентов может занимать минуты; после этого срока
# зависший запуск считается мёртвым и разрешается новый.
PROTO_UPD_TIMEOUT = 900

DNS_PORTS_DOT = list(
    getattr(config, 'dnsovertls_ports',
            [40500, 40501, 40502, 40503]))
DNS_PORTS_DOH = list(
    getattr(config, 'dnsoverhttps_ports',
            [40508, 40509, 40510, 40511]))
# Не использовать torproject.org как health-check: домен может быть
# заблокирован в России. Контрольная зона должна быть DNSSEC-подписанной,
# стабильной и не относиться к спискам обхода.
DNS_HEALTH_DOMAIN = str(getattr(
    config, 'dns_health_domain', 'example.com'))

SERVICE_SCRIPTS = {
    'shadowsocks': config.paths['init_shadowsocks'],
    'trojan': config.paths['init_trojan'],
    'vless': config.paths['init_xray'],
    'tor': config.paths['init_tor'],
    'hysteria': config.paths['init_hysteria'],
    # r87 (NFQWS2): обёртка S90nfqws2 — единый механизм ENABLED=.
    # Вкладка панели — r88; механизм toggle готов уже в r87.
    'nfqws2': config.paths.get(
        'init_nfqws2', '/opt/etc/init.d/S90nfqws2'),
}

BYPASS_IPSETS = dict(config.ipset_names)


# ── Логика списков вынесена в lists_core (C9, ревью 2026-10-12) ──────
# Здесь и ниже имена ре-экспортируются, чтобы сохранить прежние точки
# обращения панели. Реализация — одна, и бот подтягивает именно её.
# K67-02 (аудит-43): неиспользуемые ре-экспорты убраны после сверки
# потребителей — bot/*.py импортируют lists_core напрямую (g в
# handlers — это lists_core, не generator), тесты девятку не трогают.
from lists_core import (
    BYPASS_FILES, BOT_BYPASS_FILE,
    MAX_LIST_LINES, read_file_text,
    _clean_entry,
    _validate_entry, _atomic_write_text,
    _list_write_guard,
    _all_bypass_filepaths,
    ListRevisionConflict,
    parse_and_save_if_revision)



def rotate_log():
    if not os.path.exists(GENERATOR_LOG):
        return
    try:
        if os.path.getsize(
                GENERATOR_LOG) > 524288:
            with open(GENERATOR_LOG, 'r',
                      encoding='utf-8') as f:
                lines = f.readlines()
            with open(GENERATOR_LOG, 'w',
                      encoding='utf-8') as f:
                f.writelines(lines[-50:])
    except OSError as e:
        # Ротация лога — штатная фоновая операция; сбой не критичен,
        # но молча глотать ошибку ФС нельзя.
        logging.error('log rotate %s: %s', GENERATOR_LOG, e)


def web_log(message):
    """Запись в журнал панели (раньше функция была пустой заглушкой)."""
    try:
        rotate_log()
        with open(GENERATOR_LOG, 'a', encoding='utf-8') as f:
            f.write(
                f"{time.strftime('%Y-%m-%d %H:%M:%S')}"
                f" - {message}\n")
    except OSError:
        pass


def _is_local_ip(ip_str):
    try:
        addr = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return any(
        addr in s for s in ALLOWED_SUBNETS)


def _client_ip():
    """
    Реальный адрес клиента. Заголовки X-Forwarded-For / X-Real-IP
    сознательно игнорируются: панель не работает за доверенным обратным
    прокси, а эти заголовки подделываются клиентом и позволяли бы обойти
    ограничение «только LAN».
    """
    return request.remote_addr or ''


def _is_local_request():
    ip_str = _client_ip()
    if not _is_local_ip(ip_str):
        return False

    # Решение принимается по адресу КЛИЕНТА (проверен выше): он не
    # подделывается, так как берётся из TCP-соединения.
    # Заголовок Host дополнительно НЕ ограничивается: у роутера несколько
    # внутренних адресов (гостевая сеть, отдельный бридж 5 ГГц, VPN
    # прошивки), а клиенты обращаются и по имени my.keenetic.net —
    # прежняя проверка отклоняла такие запросы с 403.
    return True


_AUTH_FAILS_LOCK = threading.Lock()


def _auth_cmp(a, b):
    """
    FB-33 (аудит-26, K51-4): сравнение секретов строго в БАЙТАХ —
    модульная функция (прежде замыкание создавалось на каждый запрос;
    hmac.compare_digest на str падает с TypeError для не-ASCII —
    пароль с кириллицей ронял каждый запрос в 500).
    """
    try:
        return hmac.compare_digest(
            str(a or '').encode('utf-8'),
            str(b or '').encode('utf-8'))
    except (UnicodeError, TypeError):
        return False


def _auth_fails_trim(fails_map):
    """
    FB-11 (аудит-25, A9-5): детерминированное выселение до предела.
    Жертва выбирается по (blocked_until, fails): сначала активные
    счётчики (blocked_until == 0.0), среди них — с меньшим числом
    неудач; активные блокировки вытесняются последними.
    """
    while len(fails_map) > _AUTH_FAILS_MAX:
        victim = min(fails_map,
                     key=lambda c: (fails_map[c][1],
                                    fails_map[c][0]))
        del fails_map[victim]


def _auth_fails_sweep(fails_map, client, now):
    """
    AF-1 (аудит-22): политика счётчика неудачных входов.
    FB-11 (аудит-25, K50-2): «истёкшая» запись — только ЗАКОНЧИВШАЯСЯ
    блокировка (0 < blocked_until <= now). Прежнее условие
    entry[1] <= now было истинно всегда для активного счётчика
    (blocked_until == 0.0): счётчик стирался каждым запросом, порог
    _AUTH_MAX_FAILS был недостижим, 429 не наступал никогда.
    Гарантия len <= _AUTH_FAILS_MAX выполняется и ПОСЛЕ вставки
    нового клиента (_auth_fails_trim в security_checks); пара
    sweep+вставка — под _AUTH_FAILS_LOCK (панель работает с
    threaded=True). Возвращает (fails, blocked_until) клиента
    после снятия его истёкшей блокировки.
    """
    if len(fails_map) > _AUTH_FAILS_MAX:
        for stale in [c for c, v in fails_map.items()
                      if 0 < v[1] <= now]:
            del fails_map[stale]
    _auth_fails_trim(fails_map)
    entry = fails_map.get(client)
    if entry is not None and entry[1] and entry[1] <= now:
        del fails_map[client]
        return 0, 0.0
    return entry if entry is not None else (0, 0.0)


def _csrf_origin_allowed(value, client_ip):
    """
    O-1 (аудит-22): решение о доверии Origin/Referer POST-запроса.
    request.host сознательно НЕ используется (DNS-rebinding, L-1
    аудит-20). Допускаются:
      * имена/адреса панели с точным портом LISTEN_PORT: LAN_IP,
        реальные адреса LAN-интерфейсов, 127.0.0.1, localhost и
        admin-список allowed_origin_hosts (например my.keenetic.net);
      * loopback-имя с ЛЮБЫМ портом, но только при loopback-клиенте:
        так работает SSH-туннель из INSTALL
        (ssh -L 18080:127.0.0.1:8080) — браузер шлёт
        Origin http://127.0.0.1:18080, Flask видит клиента 127.0.0.1;
        удалённый клиент с таким Origin не проходит.
    Пустой порт — порт схемы по умолчанию (80/443), допускается
    только при совпадении с LISTEN_PORT.
    """
    if not value:
        return False
    try:
        parsed = urlparse(value)
    except Exception:
        return False
    if parsed.scheme not in ('http', 'https'):
        return False
    netloc = parsed.netloc or ''
    hostname, port = netloc, ''
    if ':' in netloc:
        hostname, port = netloc.rsplit(':', 1)
    hostname = hostname.strip('[]')
    if not hostname:
        return False
    try:
        client_loopback = ipaddress.ip_address(
            client_ip).is_loopback
    except ValueError:
        client_loopback = False
    if hostname in ('127.0.0.1', 'localhost'):
        # FB-14 (аудит-25, A9-4): loopback-имя доверяет только
        # loopback-подключению (SSH-туннель — любой порт). Прежний
        # фолбэк «порт == LISTEN_PORT» пропускал Origin вида
        # http://127.0.0.1:8080 от нелокального клиента вопреки
        # собственному контракту функции (docstring выше).
        return client_loopback
    if port == '':
        port = ('443' if parsed.scheme == 'https'
                else '80')
    if port != str(LISTEN_PORT):
        return False
    if hostname == str(LAN_IP):
        return True
    if hostname in _lan_host_addresses():
        return True
    return hostname in _ORIGIN_EXTRA_HOSTS


@app.before_request
def security_checks():
    # 1. Только внутренние сети.
    if not _is_local_request():
        log_error(
            f"[w] отклонён внешний запрос от {_client_ip()}")
        return ('⛔ Доступ разрешён только из локальной сети.', 403)

    # 2. Обязательная аутентификация. Пустой пароль в bot_config.py
    #    означает «панель не настроена» — доступ закрыт полностью,
    #    вместо прежнего поведения с открытым входом.
    web_user = str(getattr(config, 'web_username', '') or '')
    web_pass = str(getattr(config, 'web_password', '') or '')

    if not web_user or not web_pass:
        return (
            '⛔ Веб-панель не настроена: задайте web_username и '
            'web_password в /opt/etc/bot/bot_config.py',
            503)

    auth = request.authorization
    client = _client_ip()

    # Защита от подбора пароля. Панель доступна только из LAN, но
    # заражённое устройство внутри сети могло перебирать пароль без
    # ограничений. Счётчик неудач ведётся по адресу клиента в памяти
    # процесса; после _AUTH_MAX_FAILS попыток адрес блокируется на
    # _AUTH_BLOCK_SEC секунд. Успешный вход счётчик сбрасывает.
    now = time.time()
    # AF-1 (аудит-22): чистка + жёсткий предел — _auth_fails_sweep
    # (гарантия len <= _AUTH_FAILS_MAX; прежняя inline-чистка удаляла
    # только истёкшие, и активные блокировки не были ограничены).
    # FB-11 (аудит-25): пара «sweep + вставка» атомарна под
    # _AUTH_FAILS_LOCK (панель работает с threaded=True), а предел
    # соблюдается и ПОСЛЕ вставки нового клиента (_auth_fails_trim).
    _early_429 = None
    with _AUTH_FAILS_LOCK:
        fails, blocked_until = _auth_fails_sweep(
            _auth_fails, client, now)

        # Сравнение строго в БАЙТАХ — _auth_cmp (FB-33, аудит-26).
        ok = bool(
            auth
            and _auth_cmp(auth.username, web_user)
            and _auth_cmp(auth.password, web_pass))

    # ВАЖНО: блокировка применяется только к НЕВЕРНЫМ попыткам.
    # Если отвергать и правильный пароль, администратор запирает сам
    # себя, а злоумышленник из LAN легко устраивает отказ в
    # обслуживании, просто перебирая пароль с чужого адреса.
        if ok:
            _auth_fails.pop(client, None)
        elif auth is None:
            # FB-53 (аудит-29, N54-4): запрос БЕЗ учётных данных — не
            # попытка подбора: счётчик не наращивается (пять
            # параллельных вкладок/prefetch до ввода пароля не
            # блокировали адрес на 300 с; замер: 401×5 → 429).
            # Отвечаем обычным 401; блокировка действует на
            # предъявленные неверные креды — перебор без
            # предъявления бессмыслен, верный пароль по-прежнему
            # снимает блокировку (pop выше).
            pass
        else:
            if blocked_until > now:
                # Пауза уже идёт: не наращиваем счётчик, просто
                # отказываем.
                _early_429 = Response(
                    'Too many failed attempts',
                    429,
                    {'Retry-After':
                     str(int(blocked_until - now)),
                     'WWW-Authenticate':
                     'Basic realm="Keenetic bypass panel"'})
            else:
                fails += 1
                if fails >= _AUTH_MAX_FAILS:
                    _auth_fails[client] = (
                        0, now + _AUTH_BLOCK_SEC)
                    log_error(
                        f'[w] {_AUTH_MAX_FAILS} неудачных входов '
                        f'с {client} — пауза {_AUTH_BLOCK_SEC}с')
                else:
                    _auth_fails[client] = (fails, 0.0)
                # FB-11 (аудит-25, A9-5): предел и после вставки —
                # sweep мог оставить ровно _AUTH_FAILS_MAX записей,
                # и новый клиент давал бы 256+1.
                _auth_fails_trim(_auth_fails)

    if not ok:
        if _early_429 is not None:
            return _early_429
        # Задержка замедляет автоматический перебор — уже ВНЕ lock,
        # чтобы неудачный подбор не удерживал критическую секцию.
        # FB-64 (аудит-32, R55-02): задержка — ТОЛЬКО для предъявленных
        # неверных кредов. Запрос без Authorization (auth=None) — не
        # перебор (FB-53 его и не считает): прежде каждый такой запрос
        # удерживал server-поток 0.5 с, а панель работает с
        # threaded=True без предела потоков (замер отчёта r55: 512
        # одновременных без credentials — 512×401 и рост числа
        # потоков). Теперь 401 без задержки; неверный предъявленный
        # пароль по-прежнему ждёт 0.5 с (и ограничен 429 после
        # _AUTH_MAX_FAILS — ранний 429 выше возвращается без sleep).
        if auth is not None:
            time.sleep(0.5)
        return Response(
            'Authentication required',
            401,
            {'WWW-Authenticate':
             'Basic realm="Keenetic bypass panel"'})

    # 3. Защита от CSRF на уровне источника запроса.
    if request.method == 'POST':
        # L-1 (аудит-20) + O-1 (аудит-22): request.host не источник
        # доверия (DNS-rebinding). Политика — _csrf_origin_allowed:
        # фиксированные имена с портом панели (LAN_IP, адреса
        # LAN-интерфейсов, allowed_origin_hosts) и loopback-Origin с
        # любым портом при loopback-клиенте (SSH-туннель из INSTALL).
        origin = request.headers.get('Origin', '')
        referer = request.headers.get('Referer', '')
        source = origin or referer
        if not source or not _csrf_origin_allowed(
                source, client):
            return ('⛔ CSRF.', 403)


# R44-2 (аудит-14, N-2): whitelist путей runtime-кэша iptables — тот же
# список, что в pick_iptables (deploy_bypass.sh / 100-redirect.sh):
# /tmp объявлен враждебной средой, «файл существует + X_OK» недостаточно.
_IPT_CACHE_PATHS = (
    '/usr/sbin/iptables', '/sbin/iptables', '/bin/iptables',
    '/usr/bin/iptables', '/usr/local/sbin/iptables',
    '/tmp/sbin/iptables', '/tmp/usr/sbin/iptables',
    '/opt/sbin/iptables', '/opt/bin/iptables',
)


def _iptables_bin():
    """
    Пакет Entware "iptables" кладёт /opt/sbin/iptables без расширений
    TPROXY/socket/set и перекрывает прошивочный бинарник в PATH.
    Для правил панели нужен рабочий iptables, поэтому выбираем явно.
    """
    # На Keenetic прошивочный iptables лежит НЕ в /usr/sbin: этого пути
    # там нет вовсе. Реально встречаются /opt/sbin (Entware) и внутренние
    # пути прошивки, поэтому список кандидатов расширен, а в конце —
    # поиск через PATH.
    # 100-redirect.sh пишет результат capability-проверенного выбора
    # (M6): кэш точнее перебора путей по «файл существует».
    try:
        with open('/tmp/keenzoo_iptables_bin', encoding='utf-8') as f:
            cached = f.read().strip()
        if cached in _IPT_CACHE_PATHS and os.access(cached, os.X_OK):
            return cached
    except OSError:
        pass

    for cand in ('/usr/sbin/iptables', '/sbin/iptables',
                 '/bin/iptables', '/usr/bin/iptables',
                 '/opt/sbin/iptables', '/opt/bin/iptables'):
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    found = shutil.which('iptables')
    if found:
        return found
    return 'iptables'


IPTABLES = _iptables_bin()


def _ipt(*args):
    """Вызов iptables с ограничением по времени.

    -w заставляет iptables ждать освобождения xtables-блокировки:
    без ограничения параллельный вызов из ndm-хука мог подвесить
    поток панели навсегда. Истёкшее ожидание возвращается как обычная
    неудача (returncode 1), иначе TimeoutExpired обрушил бы запуск
    панели, которая вызывает setup_firewall при старте.
    """
    try:
        return subprocess.run(
            [IPTABLES, '-w'] + list(args),
            capture_output=True, text=True,
            timeout=15)
    except subprocess.TimeoutExpired:
        log_error(
            '[!] iptables не ответил за 15 с: '
            + ' '.join(str(a) for a in args))
        return subprocess.CompletedProcess(
            args=args, returncode=1, stdout='', stderr='timeout')
    except OSError as err:
        # Бинарника может не оказаться в PATH в момент загрузки роутера
        # (USB монтируется с задержкой, PATH у init-скриптов урезан):
        # необработанный FileNotFoundError из subprocess ронял старт
        # панели до поднятия Flask. Несколько невыполненных правил —
        # деградация ACL, но не смерть сервиса.
        log_error('[!] iptables недоступен (%s): %s'
                  % (type(err).__name__, err))
        return subprocess.CompletedProcess(
            args=args, returncode=1, stdout='', stderr=str(err))


def _lan_subnet_list():
    """
    FW-1 (аудит-20): подсети, реально существующие на LAN-интерфейсах,
    тем же способом, что и блок B7 хука 100-redirect.sh:
    ip -4 route (proto kernel), фолбэк — ip -4 addr.
    Возвращает (список CIDR c 127.0.0.0/8, найдено_ли_что-то_кроме_lo).
    """
    subnets = ['127.0.0.0/8']
    found = False
    for ifname in list(getattr(config, 'lan_ifaces', ['br0', 'br1'])):
        nets = []
        try:
            r = subprocess.run(
                ['ip', '-4', 'route', 'show', 'dev', ifname],
                capture_output=True, text=True, timeout=5)
            for line in (r.stdout or '').splitlines():
                f = line.split()
                if 'kernel' in f and f and '/' in f[0]:
                    nets.append(f[0])
        except (OSError, ValueError,
                subprocess.TimeoutExpired):
            pass
        if not nets:
            try:
                r = subprocess.run(
                    ['ip', '-4', 'addr', 'show', 'dev', ifname],
                    capture_output=True, text=True, timeout=5)
                for line in (r.stdout or '').splitlines():
                    f = line.split()
                    if len(f) >= 2 and f[0] == 'inet' and '/' in f[1]:
                        # SN-1 (аудит-22): addr даёт адрес хоста
                        # (192.168.2.1/24); нормализуем в сеть —
                        # строгие сборки iptables отвергают host-bits
                        # (см. комментарий L-2 в хуке). Невалидные
                        # строки пропускаем. Хук не трогаем: его
                        # первичный путь (proto kernel) сети уже даёт,
                        # fallback редок, а правка хука требует
                        # пере-верификации ruleset (f33).
                        try:
                            nets.append(str(ipaddress.ip_interface(
                                f[1]).network))
                        except ValueError:
                            continue
            except (OSError, ValueError,
                    subprocess.TimeoutExpired):
                pass
        for net in nets:
            if net not in subnets:
                subnets.append(net)
            found = True
    return subnets, found


# FB-22 (аудит-25, K50-9): TTL-кэш адресов LAN (60 с) — прежде каждый
# POST панели форкал `ip` по разу на интерфейс (до трёх subprocess на
# действие). Кэшируется и ПУСТОЙ результат: там, где `ip` отсутствует
# или не отдаёт адресов, наивный кэш «только непустой» не срабатывал
# и холостые форки уходили на каждый запрос. Смена адреса моста
# подхватывается в пределах минуты.
_LAN_HOSTS_CACHE = {'ts': 0.0, 'addrs': frozenset()}
_LAN_HOSTS_CACHE_TTL = 60.0
# FB-30 (аудит-26, R51-06): refresh под lock — при одновременном
# истечении TTL несколько POST-потоков не устраивают stampede форков
# `ip` (замер аудита: 8 одновременных miss × 3 интерфейса = 24
# subprocess; с double-check внутри секции — 3).
_LAN_HOSTS_LOCK = threading.Lock()


def _lan_host_addresses():
    """
    O-1 (аудит-22): фактические IPv4-адреса LAN-интерфейсов (строки).
    Панель доступна по любому из них: Origin/Referer с таким hostname
    и портом панели допускается CSRF-проверкой (прежде допускался
    только основной LAN_IP, и обращение по адресу другого моста
    лишало POST-действий). FB-22 (аудит-25): TTL-кэш 60 с.
    FB-30 (аудит-26): refresh под _LAN_HOSTS_LOCK.
    """
    _now = time.time()
    if _now - _LAN_HOSTS_CACHE['ts'] < _LAN_HOSTS_CACHE_TTL:
        return _LAN_HOSTS_CACHE['addrs']
    with _LAN_HOSTS_LOCK:
        _now = time.time()
        if _now - _LAN_HOSTS_CACHE['ts'] < _LAN_HOSTS_CACHE_TTL:
            return _LAN_HOSTS_CACHE['addrs']
        addrs = set()
        for ifname in list(getattr(config, 'lan_ifaces',
                                    ['br0', 'br1'])):
            try:
                r = subprocess.run(
                    ['ip', '-4', 'addr', 'show', 'dev', str(ifname)],
                    capture_output=True, text=True, timeout=5)
            except (OSError, ValueError,
                    subprocess.TimeoutExpired):
                continue
            for line in (r.stdout or '').splitlines():
                f = line.split()
                if len(f) >= 2 and f[0] == 'inet':
                    addr = f[1].split('/')[0]
                    try:
                        ipaddress.ip_address(addr)
                    except ValueError:
                        continue
                    addrs.add(addr)
        _LAN_HOSTS_CACHE['ts'] = _now
        _LAN_HOSTS_CACHE['addrs'] = frozenset(addrs)
        return _LAN_HOSTS_CACHE['addrs']


def setup_firewall(port):
    """
    Ограничивает доступ к порту панели на уровне netfilter.

    Разрешение выдаётся по ИСХОДНОЙ ПОДСЕТИ, а не по имени интерфейса.
    Прежняя версия перечисляла br0/br1/wlan0/..., после чего вешала DROP
    без "-i". На Keenetic Wi-Fi-клиенты часто приходят через другой мост
    (гостевая сеть, отдельный бридж для 5 ГГц, иные имена вида wl0/ra0),
    и тогда ACCEPT для них не создавался, а общий DROP блокировал доступ:
    панель открывалась с роутера, но не с телефона по Wi-Fi.
    FW-1 (аудит-20): допускаются только подсети, реально существующие
    на LAN-интерфейсах (_lan_subnet_list, паритет с блоком B7 хука
    100-redirect.sh). Прежний blanket-цикл по ALLOWED_SUBNETS открывал
    панель с аплинка при приватном WAN (CGNAT/L2TP 10/8) — хук эти
    правила специально снимает, а панель возвращала их при каждом
    старте. Прикладная проверка Flask (_is_local_ip) остаётся вторым
    рубежом без изменений.
    """
    wan = ['eth0', 'eth1', 'ppp0', 'ppp1', 'wan0', 'usb0']

    # Снять возможные разрешения на WAN.
    for i in wan:
        while _ipt('-D', 'INPUT', '-p', 'tcp', '--dport', str(port),
                   '-i', i, '-j', 'ACCEPT').returncode == 0:
            pass

    # Снять прежний DROP, чтобы затем добавить его последним.
    while _ipt('-D', 'INPUT', '-p', 'tcp', '--dport', str(port),
               '-j', 'DROP').returncode == 0:
        pass

    # Снять устаревшие ACCEPT по именам интерфейсов, оставшиеся
    # от предыдущих версий, — иначе они накапливаются.
    for i in list(getattr(config, 'lan_ifaces', ['br0', 'br1'])) + \
            ['lo', 'wlan0', 'wlan1']:
        while _ipt('-D', 'INPUT', '-p', 'tcp', '--dport', str(port),
                   '-i', i, '-j', 'ACCEPT').returncode == 0:
            pass

    # FW-1b (аудит-21/R50-5): снять blanket-RFC1918 прежних редакций
    # панели — их же удаляет блок B7 хука. Без этого при обновлении
    # r46→r47 правила, оставшиеся от старой панели, продолжали жить
    # в INPUT до ближайшего ndm-события, открывая порт аплинку
    # (CGNAT/L2TP 10/8). Fallback на ALLOWED_SUBNETS не вводится:
    # при недоступности ip хук B7 деградирует панель до loopback —
    # панель обязана деградировать согласованно, иначе качели.
    for legacy_net in ('192.168.0.0/16', '10.0.0.0/8',
                       '172.16.0.0/12'):
        while _ipt('-D', 'INPUT', '-p', 'tcp', '--dport', str(port),
                   '-s', legacy_net, '-j', 'ACCEPT').returncode == 0:
            pass

    # FW-1 (аудит-20): разрешаем только реальные подсети LAN-интерфейсов
    # (как блок B7 хука); blanket-RFC1918 открывал панель с аплинка при
    # приватном WAN (CGNAT/L2TP 10/8).
    lan_subnets, lan_found = _lan_subnet_list()
    if not lan_found:
        # Паритет с деградацией B7: след в журнале обязателен.
        log_error('setup_firewall: подсети LAN не определены — '
                  'веб-панель доступна только с 127.0.0.1')
    for net in lan_subnets:
        if _ipt('-C', 'INPUT', '-p', 'tcp', '--dport', str(port),
                '-s', net, '-j', 'ACCEPT').returncode != 0:
            # SN-1 (аудит-22): отказ создания ACCEPT обязан попадать
            # в журнал — иначе панель молча закрыта DROP с этой
            # подсети без следа в логе.
            if _ipt('-I', 'INPUT', '-p', 'tcp', '--dport', str(port),
                    '-s', net, '-j', 'ACCEPT').returncode != 0:
                log_error('setup_firewall: ACCEPT не создан: ' + net)

    # Всё остальное (в первую очередь WAN) — запретить.
    _ipt('-A', 'INPUT', '-p', 'tcp', '--dport', str(port), '-j', 'DROP')


def _check_csrf():
    token = request.form.get(
        'csrf_token', '')
    if not validate_csrf(token):
        abort(403)


# ── Включение/отключение протоколов ──────────────────────────────────────
# Состояние хранится в самом init-скрипте (ENABLED=yes|no) — это штатный
# механизм Entware: rc.func не запускает сервис при ENABLED=no, поэтому
# выбор переживает перезагрузку роутера без отдельного файла состояния.
# Конфигурации протоколов при отключении НЕ трогаются: повторное включение
# поднимает сервис с прежними ключами.
TAB_TO_SERVICE = {
    'ss': 'shadowsocks',
    'tr': 'trojan',
    'vl': 'vless',
    'to': 'tor',
    'hy': 'hysteria',
    # r87 (NFQWS2): таблица — механизм toggle_service; вкладка 'za'
    # появится в r88 (мокап на утверждение).
    'za': 'nfqws2',
}


def _read_enabled(sn):
    """Читает ENABLED= из init-скрипта.

    K3 (повторный аудит 2026-10-12): нет файла — протокол не
    установлен ⇒ выключен. Синхронно с shell-семантикой после
    исправления P5 (common.sh:svc_configured, хук:svc_installed),
    иначе панель показывала «включён» у несуществующего пакета.
    """
    sc = SERVICE_SCRIPTS.get(sn)
    if not sc or not os.path.exists(sc):
        return False
    try:
        with open(sc, 'r', encoding='utf-8',
                  errors='replace') as f:
            for line in f:
                m = re.match(
                    r'\s*ENABLED\s*=\s*([A-Za-z]+)', line)
                if m:
                    return m.group(1).lower() == 'yes'
    except OSError:
        pass
    return True


def get_services_enabled():
    """Состояние всех протоколов для отрисовки ползунков."""
    return {
        tab: _read_enabled(sn)
        for tab, sn in TAB_TO_SERVICE.items()
    }


def _write_enabled(sn, value):
    """Атомарно переписывает строку ENABLED= в init-скрипте."""
    sc = SERVICE_SCRIPTS.get(sn)
    if not sc:
        raise ValueError(f"?: {sn}")
    if not os.path.exists(sc):
        raise FileNotFoundError(f"!: {sc}")

    with open(sc, 'r', encoding='utf-8',
              errors='replace') as f:
        lines = f.readlines()

    word = 'yes' if value else 'no'
    found = False
    for i, line in enumerate(lines):
        if re.match(r'\s*ENABLED\s*=', line):
            lines[i] = f'ENABLED={word}\n'
            found = True
            break
    if not found:
        # Строки нет — добавляем после shebang.
        pos = 1 if lines and lines[0].startswith('#!') else 0
        lines.insert(pos, f'ENABLED={word}\n')

    # Запись через временный файл: обрыв не оставит битый init-скрипт.
    # FB-52 (аудит-29, N54-3): tmp уникален на ВЫЗОВ (mkstemp), а не
    # по PID — два параллельных переключения протокола из панели
    # (threaded=True) делили один {sc}.tmp.{pid}: finally сносил
    # чужой tmp, os.replace падал. Права 0755 обязательны
    # (init-скрипт исполняется rc.unslung).
    _fd, tmp = tempfile.mkstemp(
        prefix=f'{os.path.basename(sc)}.', suffix='.tmp',
        dir=os.path.dirname(sc))
    try:
        with os.fdopen(_fd, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        os.chmod(tmp, 0o755)
        os.replace(tmp, sc)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


def _flash_reapply_warning(reapply_ok):
    """r93 (аудит r92, P2-4): переприменение правил перехвата не
    подтвердилось — предупреждение рядом с успехом переключения
    (не fatal: хук идемпотентен, переприменится событием NDM)."""
    if reapply_ok is False:
        flash('⚠️ Правила перехвата не переприменились — '
              'перепроверьте состояние протоколов (подробности '
              'в логе)', 'err')


def _rollback_enabled(sn, prev):
    """r91 (аудит r90, А): best-effort откат ENABLED= к прежнему
    значению при отказе init-операции — состояние на диске не
    расходится с фактом."""
    try:
        _write_enabled(sn, prev)
    except Exception as e:  # noqa: BLE001
        log_error(f'[w]rollback ENABLED {sn}: {e}')


def set_service_enabled(sn, value):
    """
    Переключает протокол: правит ENABLED, затем запускает или
    останавливает сервис. Правила netfilter переприменяются, чтобы
    трафик не уходил на порт остановленного сервиса.
    r91 (аудит r90, А): честность результата — returncode init
    проверяется; при отказе start/stop прежнее ENABLED= атомарно
    восстанавливается и поднимается RuntimeError (панель показывает
    «❌», а не ложный «✅ включён»). Прежде ENABLED записывался до
    запуска, а код возврата игнорировался: отказ старта оставлял на
    диске ENABLED=yes при неработающей службе, отказ stop —
    ENABLED=no при живом процессе.
    r93 (аудит r92, P2-4): возвращает результат переприменения
    правил (bool) — вызывающие показывают предупреждение при False.
    """
    prev = _read_enabled(sn)
    _write_enabled(sn, value)

    sc = SERVICE_SCRIPTS.get(sn)
    action = 'start' if value else 'stop'
    try:
        r = subprocess.run(
            [sc, action],
            capture_output=True, text=True, timeout=30)
    except (subprocess.SubprocessError, OSError) as e:
        _rollback_enabled(sn, prev)
        raise RuntimeError(f"{sn}: {e}") from e
    if r.returncode != 0:
        _rollback_enabled(sn, prev)
        err = (r.stderr.strip() or r.stdout.strip()
               or f'init {action} rc={r.returncode}')
        raise RuntimeError(f'{sn}: {err[:200]}')

    # r93 (аудит r92, P2-4): результат переприменения правил
    # возвращается вызывающим (False — не переприменились); init-отказ
    # по-прежнему исключение. Вызывающие, игнорирующие возврат,
    # поведение не меняют.
    return _reapply_netfilter()

def _reapply_netfilter():
    """
    Переприменяет правила перехвата. Хук сам пропускает протоколы,
    у которых ENABLED=no, и снимает их прежние правила.
    r91 (аудит r90, А): коды возврата хука собираются и логируются
    (прежде глотались); не фатально — хук идемпотентен и
    переприменится следующим событием NDM.
    r93 (аудит r92, P2-4): возвращает True/False по итогу обеих
    таблиц (хука нет — True); вызывающие показывают «⚠️ правила не
    переприменились» рядом с успехом переключения.
    """
    hook = '/opt/etc/ndm/netfilter.d/100-redirect.sh'
    if not os.path.exists(hook):
        return True
    ok = True
    for table in ('nat', 'mangle'):
        env = dict(os.environ,
                   type='iptable', table=table)
        try:
            r = subprocess.run(
                [hook], env=env, capture_output=True,
                text=True, timeout=60)
            if r.returncode != 0:
                ok = False
                log_error(
                    f'[w]netfilter hook {table}: '
                    f'rc={r.returncode}')
        except (subprocess.SubprocessError, OSError) as e:
            ok = False
            log_error(f'[w]netfilter hook {table}: {e}')
    return ok

def restart_service(sn):
    sc = SERVICE_SCRIPTS.get(sn)
    if not sc:
        raise ValueError(f"?: {sn}")
    if not os.path.exists(sc):
        raise FileNotFoundError(f"!: {sc}")
    os.chmod(sc, 0o755)
    # r89 (П3): рестарт протокола мог сменить VPS — обновляем
    # managed-excludes nfqws2 (тихо; нет пакета — no-op).
    try:
        import utils as _u
        _u.nfqws2_update_excludes_quiet()
    except Exception:  # noqa: BLE001
        pass
    # Истёкшее ожидание превращается в понятную ошибку: вызывающий код
    # ловит RuntimeError и показывает её пользователю.
    try:
        r = subprocess.run(
            [sc, 'restart'],
            capture_output=True,
            text=True, timeout=30)
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(
            f'{sn}: перезапуск не завершился за 30 с') from e
    if r.returncode != 0:
        err = (r.stderr.strip()
               or r.stdout.strip())
        raise RuntimeError(f"{sn}: {err}")


# r102 (аудит r101, KZ101-01): общий guard статуса списочного
# обновления — стабильный lock-файл (не удаляется при unlock, inode
# стабилен), flock(2) неблокирующе с коротким спином. Сериализует
# ВСЕХ writers UPDATE_STATUS_FILE: _write_update_status панели,
# write_status/аварийный cleanup unblock_update.sh и транзакционный
# финализатор обёртки — окно «проверка claim → замена» (probe S s1:
# конкурентная публикация между сверкой и mv затиралась устаревшим
# done/error) закрыто. Зеркалирует _kz_proto_guard (r96–r99).
_LIST_UPD_GUARD = UPDATE_STATUS_FILE + '.lockfile'


def _kz_list_guard_acquire():
    """fd — guard взят; False — занят/недоступен. Секция держится
    миллисекунды: чтение статуса, проверка claim, атомарная замена;
    НИКАКИХ ожиданий/долгих операций внутри. Lock-файл открывается
    O_CREAT 0600 + O_NOFOLLOW: подложный симлинк → отказ
    (fail-closed, как у mkdir-модели r97)."""
    import fcntl
    try:
        fd = os.open(
            _LIST_UPD_GUARD, os.O_RDWR | os.O_CREAT
            | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    except OSError:
        return False
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        return False
    return fd


def _kz_list_guard_release(token=None):
    """Снятие guard: flock LOCK_UN + close. token — fd от acquire;
    постороннее значение безопасно игнорируется."""
    if token is None:
        return
    import fcntl
    try:
        fcntl.flock(token, fcntl.LOCK_UN)
    except (OSError, TypeError):
        pass
    try:
        os.close(token)
    except (OSError, TypeError):
        pass


def _kz_list_guard(timeout=2.0):
    """acquire с коротким спином (guard держат миллисекунды):
    False по таймауту — fail-closed: вызывающая ветка не
    выполняет запись (r103, P2-02)."""
    _deadline = time.monotonic() + timeout
    while True:
        tok = _kz_list_guard_acquire()
        # r99 (AUD-R98-03): отказ — ТОЛЬКО False (sentinel); fd 0
        # при закрытом stdin — ВАЛИДНЫЙ lock (truthiness его терял)
        if tok is not False:
            return tok
        if time.monotonic() >= _deadline:
            return False
        time.sleep(0.05)


def _write_update_status(
        status, message='', claim=None):
    """r103 (аудит r102, P2-02): fail-closed — guard не взят за
    таймаут: публикация НЕ выполняется, возвращается False (прежний
    best-effort mkstemp+os.replace мимо lock'а возвращал
    ownership-гонку KZ101-01 при занятом/недоступном guard'е).
    True — запись опубликована. r102: транзакционно, под общим
    guard (см. _kz_list_guard)."""
    _g = _kz_list_guard()
    if _g is False:
        logging.error('update status guard занят/недоступен — '
                      'публикация «%s» пропущена (fail-closed)',
                      status)
        return False
    try:
        data = {
            'status': status,
            'ts': int(time.time()),
            'message': message}
        # r101 (аудит r100, P2-01): claim владельца в running-публикации —
        # fallback обёртки сверяет его перед mv (прежде mv -f мог затереть
        # свежий running конкурентного запуска).
        if claim:
            data['claim'] = claim
        # TW-1 (аудит-20): уникальный временный файл (O_EXCL) и
        # атомарный os.replace — прежний фиксированный «.tmp» в /tmp
        # позволял писать сквозь symlink.
        _fd, tmp = tempfile.mkstemp(
            prefix=UPDATE_STATUS_FILE + '.wtmp.',
            dir='/tmp')
        with os.fdopen(_fd, 'w') as f:
            json.dump(data, f)
        os.replace(tmp, UPDATE_STATUS_FILE)
        return True
    except (OSError, TypeError, ValueError) as e:
        logging.error('update status write %s: %s',
                      UPDATE_STATUS_FILE, e)
        return False
    finally:
        _kz_list_guard_release(_g)


def _read_update_status():
    if not os.path.exists(
            UPDATE_STATUS_FILE):
        return {
            'status': 'idle',
            'ts': 0, 'message': ''}
    try:
        with open(
                UPDATE_STATUS_FILE, 'r') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {
                'status': 'idle',
                'ts': 0, 'message': ''}
    except (json.JSONDecodeError,
            IOError, ValueError):
        return {
            'status': 'idle',
            'ts': 0, 'message': ''}
    # FB-126 (аудит-43): файл не трогаем — признак зависания вычисляется
    # на чтении и служит единственным источником истины о возрасте
    # running для дашборда, /api/update-status и самого запуска
    # (apply_unblock_async). Прежние потребители поля не читают:
    # обратная совместимость полная.
    _ts = data.get('ts')
    if (data.get('status') == 'running'
            and isinstance(_ts, (int, float))
            and time.time() - _ts > UNBLOCK_TIMEOUT):
        data['stale'] = True
    return data


def _proc_cmdline_contains(pid, marker):
    """FB-158 (аудит-45, R77-03): личность процесса по
    /proc/<pid>/cmdline (паттерн S99generator): True — cmdline
    содержит marker (байты), False — не содержит, None — /proc не
    читается, личность не доказана."""
    try:
        with open(
                '/proc/%d/cmdline' % pid,
                'rb') as f:
            blob = f.read()
    except OSError:
        return None
    return marker in blob.replace(b'\x00', b' ')


# FB-157 (аудит-45, R77-02): single-flight старт обновления. Прежний
# код выполнял «чтение статуса → running → Popen» без блокировки:
# два параллельных запроса (двойной клик, две открытые вкладки)
# успевали оба прочитать idle, оба написать running и оба запустить
# wrapper — внешнее ревью r77 воспроизвело это в 5/5 прогонов.
# Lock сериализует всю последовательность; shell-lock в
# unblock_update.sh остаётся вторым барьером (запуски вне панели:
# cron, командная строка).
_UPDATE_START_LOCK = threading.Lock()


def apply_unblock_async(only_sets=''):
    sc = '/opt/bin/unblock_update.sh'
    if not os.path.exists(sc):
        raise FileNotFoundError(sc)
    os.chmod(sc, 0o755)
    # FB-157: повторная проверка внутри lock — проигравший поток
    # перечитывает статус, видит fresh running и получает честный 409.
    with _UPDATE_START_LOCK:
        st = _read_update_status()
        if st.get('status') == 'running':
            age = time.time() - st.get('ts', 0)
            if age < UNBLOCK_TIMEOUT:
                raise RuntimeError(
                    f"Уже ({int(age)}с).")
            # FB-158 (аудит-45, R77-03): stale-статус разбирается по
            # lock-каталогу БЕЗ запуска wrapper'а поверх и БЕЗ слепого
            # удаления. Прежний код: (1) lock-каталог без pid-файла не
            # анализировался вовсе — Popen стартовал поверх, mkdir в
            # wrapper'е проигрывал 150×2 с и update честно падал
            # «locked» после 5 минут ложного running; (2) мусор в pid
            # (ValueError) ловился общим except и тоже вёл к запуску
            # поверх. Теперь каждый неразрешимый случай — отдельный
            # UNKNOWN-отказ (409) с ручной процедурой в сообщении.
            # «Живость» pid дополнена личностью по /proc/<pid>/cmdline:
            # kill -0 доказывает лишь существование КАКОГО-ТО процесса
            # — при переиспользовании pid чужой процесс не должен
            # блокировать кнопку обновления часами. Продолжать
            # разрешено только когда владелец lock'а доказуемо мёртв:
            # pid мёртв, либо жив, но это заведомо не наш updater
            # (cmdline без unblock_update.sh) — тогда каталог
            # снимается. Нечитаемый cmdline — UNKNOWN: личность не
            # доказана, вслепую не действуем.
            _lockdir = os.path.isdir(LOCK_DIR)
            pf = os.path.join(
                LOCK_DIR, 'pid')
            if _lockdir and not os.path.exists(pf):
                raise RuntimeError(
                    'Lock обновления без pid-файла — происхождение '
                    'неизвестно. Удалите каталог вручную: '
                    f'rm -rf {LOCK_DIR}')
            if _lockdir:
                try:
                    with open(pf, 'r') as f:
                        op = int(
                            f.read().strip())
                except (OSError, ValueError) as e:
                    raise RuntimeError(
                        'pid lock-каталога обновления не читается '
                        f'({e}). Удалите каталог вручную: '
                        f'rm -rf {LOCK_DIR}')
                # FB-172 (аудит-46, A-R79-06): доказанная смерть —
                # только ESRCH. EPERM означает «процесс жив, но
                # сигналом его не проверить» (чужой владелец): прежде
                # любой OSError считался смертью, и lock снимался при
                # живом-но-недоступном pid с запуском поверх. EPERM и
                # прочие ошибки уходят в cmdline-проверку личности
                # (UNKNOWN-ветвь ниже), lock вслепую не снимается.
                _dead = False
                try:
                    os.kill(op, 0)
                except OSError as _e:
                    _dead = (getattr(_e, 'errno', None)
                             == errno.ESRCH)
                if not _dead:
                    _own = _proc_cmdline_contains(
                        op, b'unblock_update.sh')
                    if _own:
                        # FB-127 (аудит-43): живой СВОЙ процесс —
                        # долгий прогон, честный отказ (409), дубль
                        # не создаём.
                        raise RuntimeError(
                            'Обновление ещё выполняется '
                            f'(процесс {op} жив, '
                            f'{int(age)}с)')
                    if _own is None:
                        raise RuntimeError(
                            f'Lock обновления: процесс {op} жив, но '
                            'личность по /proc не читается — вслепую '
                            'не действую. Диагностика: '
                            f'cat /proc/{op}/cmdline, затем rm -rf '
                            f'{LOCK_DIR}')
                    # живой ЧУЖОЙ pid: переиспользован, владелец
                    # lock'а мёртв — каталог мусор, снимаем.
                    web_log(
                        'stale update lock: pid %d жив, но это не '
                        'unblock_update.sh (pid переиспользован) — '
                        'lock снят' % op)
                    _dead = True
                if _dead:
                    import shutil
                    shutil.rmtree(
                        LOCK_DIR,
                        ignore_errors=True)
            _write_update_status('idle', 'stale')
        # r101 (аудит r100, P2-01): claim этого прогона — передаётся
        # обёртке и пишется в running; fallback публикует финал только
        # при совпадении (зеркалит протокольную ветку r96/KZ95-03).
        _claim_id = secrets.token_hex(8)
        # r103 (аудит r102, P2-02): running-публикация fail-closed —
        # guard не взят (занят/недоступен) => статус не пишется и прогон
        # не стартует: активный владелец статуса не затёрт, UI получает
        # честный отказ (прежде best-effort писал мимо lock'а).
        if not _write_update_status(
                'running', 'starting', claim=_claim_id):
            raise RuntimeError(
                'Статус обновления занят — повторите позже.')
        # TW-1 (аудит-20): обёртка передаётся sh -c как argv, а не файлом с
        # предсказуемым именем в /tmp (open/chmod/Popen следовали за symlink
        # и исполнялись от root). Лог — дескриптор с O_NOFOLLOW; временный
        # статус — mkstemp (O_EXCL) + атомарный mv.
        try:
            log_fd = os.open(
                UPDATE_LOG_FILE,
                os.O_WRONLY | os.O_CREAT | os.O_TRUNC
                | getattr(os, 'O_NOFOLLOW', 0))
        except OSError as e:
            web_log(f'update log open (symlink?): {e}')
            log_fd = -1
        # FB-127 (аудит-43): сбой подготовки запуска обязан оставлять
        # честный error-статус — прежний код писал running до mkstemp, и
        # при ENOSPC/отказе fork (OSError у Popen) свежий running ложно
        # блокировал кнопки дашборда на UNBLOCK_TIMEOUT и дольше.
        try:
            _tfd, tmp_status = tempfile.mkstemp(
                prefix=UPDATE_STATUS_FILE + '.wtmp.',
                dir='/tmp')
        except OSError as e:
            _write_update_status(
                'error', f'запуск не удался: {e}')
            raise
        os.close(_tfd)
        # FB-121 (аудит-42): значения передаются дочернему sh через окружение,
        # а не хвостовыми argv. POSIX-форма «sh -c body имя арг…» реализована
        # не везде: живой инцидент 2026-10-24/25 — Keenetic-прошивка с Entware
        # перенаправляет exec /bin/sh на /opt/bin/sh, молча выбрасывая имя и
        # позиционные параметры; обёртка видела пустые $1–$4 (три строки
        # ошибок в /tmp/unblock_update.log), и обновление навсегда зависало
        # в running/starting. «-c body» + env — минимум, поддерживаемый любым
        # sh; значения окружения к тому же не видны в /proc/PID/cmdline.
        body = '''STATUS_FILE="$KZ_STATUS_FILE"; TMP_STATUS="$KZ_TMP_STATUS"; SCRIPT="$KZ_SCRIPT"; ONLY="$KZ_ONLY"
# r100 (аудит r99, KZ99-01): cleanup-страховка ДО env-проверки —
# ранний fail-closed выход не должен оставлять родительский temp
# (на роутере /tmp — tmpfs в ОЗУ; этот trap прежде ставился ниже
# и не срабатывал при exit 3 из аварийной ветки).
[ -n "$TMP_STATUS" ] && trap 'rm -f "$TMP_STATUS"' 0 1 2 15
# FB-124 (аудит-42): самоконтроль — пустая обязательная переменная значит
# нештатное окружение (KZ_* не дошли до sh): честный отказ и выход
# вместо тихой смерти с вечным «running» в панели. Диагноз — только
# stderr (лог обёртки); общий статус не трогаем (r100/KZ99-02 — как
# протокольная обёртка с r99/KZ98-01): без доказательства владения
# запись небезопасна; «зависший» running ограничен stale (FB-126).
if [ -z "$STATUS_FILE" ] || [ -z "$TMP_STATUS" ] || [ -z "$SCRIPT" ]; then
    # r100 (аудит r99, KZ99-02): аварийная ветка fail-closed — как в
    # протокольной обёртке с r99 (KZ98-01): общий статус-файл НЕ
    # трогаем. Прежде прямой printf > STATUS писал без атомарности
    # и сверки владения — затирал свежий running другого прогона и
    # следовал по symlink. Диагностика — только в stderr, rc=3.
    echo "keenzoo: обёртка обновления не получила KZ_*-переменные (FB-121/FB-124)" >&2
    exit 3
fi
# TS-1 (аудит-22): временный статус не должен переживать прогон —
# при успехе fallback не срабатывает, и без trap файл оставался в /tmp.
trap 'rm -f "$TMP_STATUS"' 0 1 2 15
export PATH=/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin
# r103 (аудит r102, P3): путь статуса — в окружение child-updater'а
# (при операторском generator_settings.status_file родитель и child
# пишут в один файл; прежде child уходил в свой дефолт).
export STATUS_FILE
# r105 (аудит r104, P3-02): путь журнала — в окружение child-updater'а
# (при операторском generator_settings.update_log).
[ -n "${KZ_UPDATE_LOG_FILE:-}" ] && export UPDATE_LOG_FILE="$KZ_UPDATE_LOG_FILE"
[ -n "$ONLY" ] && export ONLY_SETS="$ONLY"
# Lock и основной статус обслуживает SCRIPT.
"$SCRIPT"
RC=$?
# Резервный статус только если SCRIPT не успел записать done/error.
NEED_FALLBACK=0
[ -f "$STATUS_FILE" ] || NEED_FALLBACK=1
if [ -f "$STATUS_FILE" ]; then
    grep -Eq '"status"[[:space:]]*:[[:space:]]*"running"' "$STATUS_FILE" && NEED_FALLBACK=1
fi
if [ "$NEED_FALLBACK" -eq 1 ]; then
    # r102 (аудит r101, KZ101-01): транзакционный финализатор —
    # перепроверка владения и атомарная замена выполняются ПОД общим
    # flock (KZ_GUARD = STATUS_FILE.lockfile; тот же lock-файл у
    # _write_update_status панели и write_status updater'а): окно
    # «проверка claim → mv», в котором конкурентная публикация
    # затиралась устаревшим done/error (probe S s1), закрыто.
    # Чужой/неизвестный владелец (claim не совпал / поля нет) и чужой
    # терминальный статус — честный пропуск с диагностикой (24);
    # guard занят (3) — пропуск. temp убирают ветка ниже и trap.
    # Зеркалит протокольную ветку r96–r99.
    TS=$(date +%s)
    if [ "$RC" -eq 0 ]; then
        S="done"; M="ok"
    else
        S="error"; M="exit code $RC"
    fi
    if KZ_S="$S" KZ_TS="$TS" KZ_MSG="$M" KZ_ST="$STATUS_FILE" \
       KZ_GUARD="${STATUS_FILE}.lockfile" KZ_TMP="$TMP_STATUS" \
       "${KZ_PY:-python3}" -S -c '
import os, sys, json, time, fcntl
ST = os.environ["KZ_ST"]; GU = os.environ["KZ_GUARD"]
CL = os.environ.get("KZ_CLAIM", ""); S = os.environ["KZ_S"]
TS = os.environ["KZ_TS"]; MSG = os.environ["KZ_MSG"]
TMP = os.environ["KZ_TMP"]
fd = None
dl = time.monotonic() + 6.0
while True:
    try:
        fd = os.open(GU, os.O_RDWR | os.O_CREAT
                     | getattr(os, "O_NOFOLLOW", 0), 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        break
    except OSError:
        if fd is not None:
            os.close(fd)
            fd = None
        if time.monotonic() >= dl:
            sys.exit(3)
        time.sleep(0.1)
try:
    # r99 (аудит r98, KZ98-01, дубль): пустого claim не существует —
    # нет доказательства владения, публикация невозможна
    if not CL:
        sys.exit(24)
    try:
        with open(ST) as f:
            cur = json.load(f)
    except FileNotFoundError:
        cur = None
    except Exception:
        cur = "err"
    _pub = False
    if cur is None:
        _pub = True
    elif (isinstance(cur, dict)
            and cur.get("status") == "running"
            and cur.get("claim") == CL):
        _pub = True
    if not _pub:
        sys.exit(24)
    with open(TMP, "w") as f:
        json.dump({"status": S, "ts": int(TS),
                   "message": MSG}, f, separators=(",", ":"))
    os.replace(TMP, ST)
finally:
    try:
        fcntl.flock(fd, fcntl.LOCK_UN)
    except OSError:
        pass
    os.close(fd)
'; then
        :
    else
        _GRC=$?
        if [ "$_GRC" = 24 ]; then
            echo "keenzoo: fallback пропущен: running принадлежит другому прогону (claim не совпал)" >&2
        else
            echo "keenzoo: guard статуса занят — результат не опубликован" >&2
        fi
        rm -f "$TMP_STATUS"
    fi
fi
exit "$RC"
'''
        try:
            subprocess.Popen(
                # FB-121 (аудит-42): argv строго три элемента, без хвостовых
                # аргументов (см. комментарий у body выше).
                ['/bin/sh', '-c', body],
                # FB-129 (аудит-43, вариант A): наследуем окружение панели —
                # прежде потомок получал только PATH и KZ_*, и операторские
                # KEENZOO_* (DLTMP, BOOTSTRAP_PROBE_MAX, ALLOW_HTTP_FEED),
                # http_proxy, TZ не доходили до updater'а. Родитель и
                # потомок — один и тот же root-процесс панели, утечки нет.
                env={**os.environ,
                     'PATH': '/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                     'KZ_STATUS_FILE': UPDATE_STATUS_FILE,
                     # r105 (аудит r104, P3-02): передача пути журнала ребёнку
                     'KZ_UPDATE_LOG_FILE': UPDATE_LOG_FILE,
                     'KZ_TMP_STATUS': tmp_status,
                     'KZ_SCRIPT': sc,
                     'KZ_ONLY': only_sets,
                     # r101 (P2-01): claim прогона для сверки fallback'ом
                     'KZ_CLAIM': _claim_id,
                     # r102 (KZ101-01): финализатор зовёт python-хелпер
                     # интерпретатором самой панели (зеркалит протокол,
                     # r99/AUD-R98-02); literal python3 — ручные запуски
                     'KZ_PY': sys.executable},
                start_new_session=True,
                stdin=subprocess.DEVNULL,
                stdout=(log_fd if log_fd >= 0
                        else subprocess.DEVNULL),
                stderr=subprocess.STDOUT)
        except OSError as e:
            # TS-1 (аудит-22): не оставлять temp-файл при отказе запуска.
            if log_fd >= 0:
                os.close(log_fd)
            try:
                os.unlink(tmp_status)
            except OSError:
                pass
            # FB-127 (аудит-43): атомарный error-статус вместо брошенного
            # running (записчик сам атомарен: mkstemp + os.replace).
            _write_update_status(
                'error', f'запуск не удался: {e}')
            raise
        if log_fd >= 0:
            os.close(log_fd)


def _test_dns_port(port):
    """Проверить локальный DNS-порт на уровне DNS и DNSSEC.

    torproject.org здесь намеренно не используется: его блокировка в
    России не должна показываться как отказ локального DoT/DoH. Результат
    структурированный, чтобы панель могла отличить DNSSEC-ok, обычный
    DNS-ответ без AD и настоящий отказ/подозрительный AA-ответ.
    """
    try:
        r = subprocess.run(
            ['dig', '+dnssec', '+noall', '+comments', '+answer', '+stats',
             '+time=2', '+tries=1', DNS_HEALTH_DOMAIN,
             '@localhost', '-p', str(port)],
            capture_output=True,
            text=True, timeout=5)
        out = r.stdout or ''
        rtt_match = re.search(
            r'Query time:\s*(\d+)\s*msec', out,
            re.IGNORECASE)
        rtt_ms = (int(rtt_match.group(1))
                  if rtt_match else None)
        status = ''
        match = re.search(r'status:\s*([^,;\s]+)', out)
        if match:
            status = match.group(1).upper()

        flags_match = re.search(
            r'flags:\s*([^;\n]+)', out, re.IGNORECASE)
        flags = set()
        if flags_match:
            flags = set(
                flags_match.group(1).lower().split())

        has_a = bool(re.search(
            r'(?m)^\S+\.?\s+\d+\s+IN\s+A\s+'
            r'\d+\.\d+\.\d+\.\d+\s*$', out))
        has_aa = 'aa' in flags
        has_ad = 'ad' in flags

        if status != 'NOERROR' or not has_a:
            return {
                'ok': False,
                'secure': False,
                'state': 'dns-failed',
                'detail': status or 'no-response',
                'rtt_ms': rtt_ms,
            }
        if has_aa:
            return {
                'ok': False,
                'secure': False,
                'state': 'dns-suspect-aa',
                'detail': 'authoritative-answer',
                'rtt_ms': rtt_ms,
            }
        if has_ad:
            return {
                'ok': True,
                'secure': True,
                'state': 'dnssec-ok',
                'detail': 'NOERROR + A + AD',
                'rtt_ms': rtt_ms,
            }
        return {
            'ok': True,
            'secure': False,
            'state': 'dns-ok-no-dnssec',
            'detail': 'NOERROR + A without AD',
            'rtt_ms': rtt_ms,
        }
    except (OSError, subprocess.SubprocessError):
        return {
            'ok': False,
            'secure': False,
            'state': 'dns-failed',
            'detail': 'dig-error',
            'rtt_ms': None,
        }


def read_pinned_hosts():
    """Закреплённые адреса прокси-серверов из /opt/etc/hosts.

    Пин создаёт unblock_dnsmasq.sh, пока штатный DNS работает. Панель
    только показывает результат — если адрес сервера задан доменом,
    видно, какой IP закреплён на случай блокировки DNS.
    """
    path = config.paths.get(
        'hosts_file', '/opt/etc/hosts')
    begin = '# --- KeenZOO pinned'
    end = '# --- end KeenZOO pinned'
    out = []
    try:
        # FB-169 (аудит-46, B-R79-03): errors='replace' — битый байт в
        # /opt/etc/hosts не должен ронять /api/dns-status в HTTP-500:
        # секция диагностическая, UnicodeDecodeError прежде не ловился
        # (except OSError).
        with open(path, 'r', encoding='utf-8',
                  errors='replace') as f:
            inside = False
            for line in f:
                line = line.strip()
                if line.startswith(begin):
                    inside = True
                    continue
                if line.startswith(end):
                    break
                if inside and line:
                    parts = line.split()
                    if len(parts) >= 2:
                        out.append({
                            'ip': parts[0],
                            'host': parts[1]})
    except OSError:
        pass
    return out


def check_dns_ports():
    res = {
        'dot': {},
        'doh': {},
        'health_domain': DNS_HEALTH_DOMAIN,
    }
    for p in DNS_PORTS_DOT:
        res['dot'][str(p)] = _test_dns_port(p)
    for p in DNS_PORTS_DOH:
        res['doh'][str(p)] = _test_dns_port(p)
    res['pinned'] = read_pinned_hosts()
    return res


# ── Дашборд (этап 1): лёгкая телеметрия ────────────────────────────────
# Только дешёвые источники: /proc/* и файлы проекта. Никаких exec и
# сетевых проверок в снапшоте — тяжёлый статус DNS дашборд получает
# отдельным медленным поллом /api/dns-status (как вкладка dns).
# Все функции принимают пути параметрами — тестируемость без /proc.
# FB-154 (аудит-44, опция 3): 2.5 с (было 1.0). Каденс клиента —
# 2 с, поэтому каждый второй поллинг открытой вкладки — кэш-хит, а
# пересбор снапшота (чтения /proc) происходит не чаще раза в ~4 с.
# Ровно 2.0 с эффекта не дают: запрос приходит на границе TTL.
DASH_CACHE_TTL = 2.5
_DASH_LOCK = threading.Lock()
_DASH_STATE = {
    'ts': 0.0,
    'prev_stat': None,   # (total, idle) /proc/stat прошлого замера
    'prev_net': None,    # (ts, {iface: (rx, tx)}) прошлого замера
    'snapshot': None,
}

# Lease-файлы dnsmasq Entware: первый существующий используется для
# человеческих имён устройств (ARP даёт только IP/MAC).
DASH_LEASE_PATHS = (
    '/opt/var/lib/misc/dnsmasq.leases',
    '/tmp/dnsmasq.leases',
)


def _proc_uptime(path='/proc/uptime'):
    """Секунды непрерывной работы из /proc/uptime."""
    try:
        with open(path, 'r') as f:
            return float(f.readline().split()[0])
    except (OSError, ValueError, IndexError):
        return None


def _proc_stat_totals(path='/proc/stat'):
    """(total, idle) по строке 'cpu ' /proc/stat (в jiffies)."""
    try:
        with open(path, 'r') as f:
            head = f.readline()
        if not head.startswith('cpu '):
            return None
        v = [int(x) for x in head.split()[1:9]]
        total = sum(v)
        idle = v[3] + (v[4] if len(v) > 4 else 0)
        return (total, idle)
    except (OSError, ValueError, IndexError):
        return None


def _cpu_pct(prev, cur):
    """Загрузка ЦП между двумя замерами /proc/stat, %."""
    if not prev or not cur:
        return None
    dt = cur[0] - prev[0]
    di = cur[1] - prev[1]
    if dt <= 0:
        return None
    return max(0.0, min(100.0, round((1.0 - di / dt) * 100.0, 1)))


def _meminfo_totals(path='/proc/meminfo'):
    """(MemTotal, MemAvailable, approx) в КиБ; None при нечитаемости.
    FB-161 (аудит-45, R77-06): на ядрах без MemAvailable (<3.14;
    k2.6-фиды Entware реальны) прежний код отдавал None — RAM-виджет
    панели пустовал. FB-171 (аудит-46, A-R79-05/B-R79-01): fallback —
    традиционная free-style оценка MemFree+Buffers+Cached (строка
    «-/+ buffers/cache» классического free), НЕ MemAvailable — его на
    старых ядрах не существует. Помечается approx=True: панель рисует
    «≈»; оценка может завышать available на долю tmpfs (Shmem входит в
    Cached), но не занижает на 2×Buffers, как прежняя форма
    free+cached-buffers (на 128-МБ фикстуре ревью r79 — ложное
    «занято >85%» вместо честных 60%). Clamp в [0, MemTotal]."""
    total = avail = free = cached = buffers = None
    try:
        with open(path, 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    total = int(line.split()[1])
                elif line.startswith('MemAvailable:'):
                    avail = int(line.split()[1])
                elif line.startswith('MemFree:'):
                    free = int(line.split()[1])
                elif line.startswith('Cached:'):
                    cached = int(line.split()[1])
                elif line.startswith('Buffers:'):
                    buffers = int(line.split()[1])
                if total is not None and avail is not None:
                    break
    except (OSError, ValueError, IndexError):
        return None
    if not total:
        return None
    if avail is not None:
        return (total, avail, False)
    if free is None or cached is None:
        return None
    # FB-171 (аудит-46): традиционная сумма free-style.
    est = free + (buffers or 0) + cached
    if est < 0:
        est = 0
    if est > total:
        est = total
    return (total, est, True)


def _proc_route_default_iface(path='/proc/net/route'):
    """Интерфейс маршрута по умолчанию, без exec.
    FB-160 (аудит-45, R77-05): маршрут обязан быть UP (RTF_UP 0x1) и
    не REJECT
    (RTF_REJECT 0x200) — прежде принимался любой маршрут с
    gateway-битом, включая down (flags 0002: шлюз прописан, линк
    лежит), и «интернет» загорался на мёртвом канале. PPP-дефолт
    (шлюз — адрес пира) gateway-бита не несёт: такой маршрут
    (flags 0001) принимается только для интерфейсов ppp*. Первый
    подходящий маршрут таблицы выигрывает, как и прежде."""
    try:
        with open(path, 'r') as f:
            next(f)
            for line in f:
                p = line.split()
                if len(p) < 8 or p[1] != '00000000':
                    continue
                try:
                    flags = int(p[3], 16)
                except ValueError:
                    continue
                if not flags & 0x1 or flags & 0x200:
                    continue
                if flags & 0x2 or p[0].startswith('ppp'):
                    return p[0]
    except (OSError, StopIteration, ValueError):
        pass
    return None


_NET_EXCLUDE = ('lo', 'tun', 'tap', 'nwg', 'wg', 'docker', 'veth')


def _proc_net_bytes(path='/proc/net/dev', keep=()):
    """{iface: (rx_bytes, tx_bytes)}; lo/туннели (tun, tap, nwg, wg),
    docker/veth исключены. FB-162 (аудит-45, R77-07): мосты (br*) НЕ
    исключены — при br-аплинке в счётчики интерфейса маршрута
    попадает и LAN-трафик, поэтому панель называет показатель
    «счётчиками интерфейса», а не «интернетом» (прежний докстринг
    обещал исключение мостов, которого в коде нет).
    FB-173 (аудит-46, A-R79-08): keep — имена интерфейсов, читаемые
    ДАЖЕ из исключённых префиксов: интерфейс маршрута по умолчанию
    (например, wg0) обязан иметь счётчики, иначе при живом
    WireGuard-туннеле график показывает прочерк."""
    out = {}
    try:
        with open(path, 'r') as f:
            for line in f:
                if ':' not in line:
                    continue
                name, rest = line.split(':', 1)
                name = name.strip()
                if (not name
                        or (name.startswith(_NET_EXCLUDE)
                            and name not in keep)):
                    continue
                fl = rest.split()
                if len(fl) < 9:
                    continue
                out[name] = (int(fl[0]), int(fl[8]))
    except (OSError, ValueError, IndexError):
        pass
    return out


def _net_rate(prev, cur, iface, dt):
    """(down_bps, up_bps) по дельте счётчиков интерфейса за dt сек."""
    if dt <= 0 or not iface:
        return None
    if iface not in prev or iface not in cur:
        return None
    drx = cur[iface][0] - prev[iface][0]
    dtx = cur[iface][1] - prev[iface][1]
    if drx < 0 or dtx < 0:
        return None  # счётчик обнулился (перезапуск интерфейса)
    return (round(drx * 8.0 / dt, 1), round(dtx * 8.0 / dt, 1))


def _dash_devices(lease_paths=DASH_LEASE_PATHS,
                  arp_path='/proc/net/arp', limit=6):
    """Устройства LAN: /proc/net/arp + имена из lease-файлов dnsmasq."""
    names = {}
    for lp in lease_paths:
        try:
            with open(lp, 'r') as f:
                for line in f:
                    parts = line.split()
                    if len(parts) >= 4:
                        names[parts[2]] = parts[3]
            break
        except OSError:
            continue
    seen = {}
    try:
        with open(arp_path, 'r') as f:
            next(f)
            for line in f:
                p = line.split()
                if len(p) < 6:
                    continue
                # FB-128 (аудит-43): статическая запись (привязка
                # IP-MAC в Keenetic) имеет flags 0x6 = ATF_PERM|ATF_COM;
                # точное сравнение со строкой '0x2' её отбрасывало.
                # Берём бит ATF_COM: 0x2 и 0x6 входят, incomplete (0x0)
                # и мусор — мимо.
                try:
                    arp_flags = int(p[2], 16)
                except ValueError:
                    continue
                if not arp_flags & 0x2:
                    continue
                ip = p[0]
                if ip in seen:
                    continue
                seen[ip] = {
                    'ip': ip,
                    'mac': p[3],
                    'iface': p[5],
                    'name': names.get(ip) or '',
                }
    except (OSError, StopIteration, ValueError):
        pass
    out = list(seen.values())
    out.sort(key=lambda d: (0 if d['name'] else 1, d['ip']))
    return {'count': len(out), 'top': out[:limit]}


_DASH_LISTS_LOCK = threading.Lock()
_DASH_LISTS_CACHE = {'ts': 0.0, 'data': None}
_DASH_LISTS_TTL = 30.0


def _dash_lists_counts():
    """Счётчики записей всех списков обхода (TTL-кэш 30 с)."""
    now = time.time()
    with _DASH_LISTS_LOCK:
        if (_DASH_LISTS_CACHE['data'] is not None
                and now - _DASH_LISTS_CACHE['ts'] < _DASH_LISTS_TTL):
            return _DASH_LISTS_CACHE['data']
        out = {}
        pairs = (
            ('ss', 'shadowsocks'), ('tr', 'trojan'),
            ('vl', 'vless'), ('to', 'tor'), ('hy', 'hysteria'))
        for k, fk in pairs:
            try:
                txt, _rv = _list_snap(BYPASS_FILES[fk])
                d, ip, cidr = _count_entries(txt)
                out[k] = d + ip + cidr
            except (OSError, ValueError):
                # FB-166 (аудит-45, R77-11): прежде except Exception
                # глотал любые ошибки кода в молчаливый None — регрессии
                # парсера были бы невидимы. Узкий кортеж: файловые сбои
                # и кривые значения; прочее обязано падать заметно.
                out[k] = None
        # r89 (NFQWS2): user.list — последним пунктом списков
        # протоколов панели (решение по r87).
        try:
            txt, _rv = _list_snap(
                config.list_files.get('nfqws2', ''))
            d, ip, cidr = _count_entries(txt)
            out['za'] = d + ip + cidr
        except (OSError, ValueError):
            out['za'] = None
        try:
            txt, _rv = _list_snap(BOT_BYPASS_FILE)
            d, ip, cidr = _count_entries(txt)
            out['bt'] = d + ip + cidr
        except (OSError, ValueError):
            out['bt'] = None
        _DASH_LISTS_CACHE['ts'] = now
        _DASH_LISTS_CACHE['data'] = out
        return out


def _dashboard_snapshot(force=False,
                        stat_path='/proc/stat',
                        mem_path='/proc/meminfo',
                        net_path='/proc/net/dev',
                        route_path='/proc/net/route',
                        arp_path='/proc/net/arp',
                        lease_paths=None):
    """Сводный лёгкий снапшот дашборда.

    TTL DASH_CACHE_TTL защищает /proc от частых перечитываний, а дельты
    CPU/скорости считаются между реальными пересборками — поэтому prev-
    значения обновляются только при пересборке, не при возврате кэша.
    Потокобезопасно: панель работает с threaded=True.
    """
    now = time.time()
    with _DASH_LOCK:
        if (not force
                and _DASH_STATE['snapshot'] is not None
                and now - _DASH_STATE['ts'] < DASH_CACHE_TTL):
            return _DASH_STATE['snapshot']
        stat = _proc_stat_totals(stat_path)
        # FB-173 (аудит-46): iface — до чтения счётчиков: интерфейс
        # маршрута (даже из исключённых префиксов, как wg0) читается
        # с keep, чтобы график не пустовал при туннельном дефолте.
        iface = _proc_route_default_iface(route_path)
        net = _proc_net_bytes(
            net_path, keep=(iface,) if iface else ())
        net_t = time.time()
        mem = _meminfo_totals(mem_path)
        cpu = _cpu_pct(_DASH_STATE['prev_stat'], stat)
        prev_net = _DASH_STATE['prev_net']
        rate = (None if prev_net is None or net is None else
                _net_rate(prev_net[1], net, iface,
                          net_t - prev_net[0]))
        try:
            un = os.uname()
            host, arch = un.nodename, un.machine
        except AttributeError:
            host = arch = ''
        snap = {
            'ts': int(now),
            'uptime': _proc_uptime(),
            'host': host,
            'arch': arch,
            'cpu_pct': cpu,
            'ram': ({'used_kib': mem[0] - mem[1],
                     'total_kib': mem[0],
                     'approx': mem[2]} if mem else None),
            'rate': ({'down': rate[0], 'up': rate[1],
                      'iface': iface} if rate
                     else {'down': None, 'up': None,
                           'iface': iface}),
            'wan_up': bool(iface),
            'devices': _dash_devices(
                lease_paths=lease_paths or DASH_LEASE_PATHS,
                arp_path=arp_path),
            'services': get_services_enabled(),
            'update': _read_update_status(),
            'lists': _dash_lists_counts(),
        }
        if stat is not None:
            _DASH_STATE['prev_stat'] = stat
        if net is not None:
            _DASH_STATE['prev_net'] = (net_t, net)
        _DASH_STATE['snapshot'] = snap
        _DASH_STATE['ts'] = now
        return snap


def _count_entries(text):
    d = ip = cidr = 0
    for line in text.split('\n'):
        s = line.strip()
        if s and not s.startswith('#'):
            c = _clean_entry(s)
            if c:
                r = _validate_entry(c)
                if r:
                    if r[0] == 'cidr':
                        cidr += 1
                    elif r[0] == 'ip':
                        ip += 1
                    else:
                        d += 1
    return d, ip, cidr


def _format_details(d, ip, cidr):
    p = []
    if d:
        p.append(f'{d} доменов')
    if ip:
        p.append(f'{ip} IP')
    if cidr:
        p.append(f'{cidr} CIDR')
    return (', '.join(p)
            if p else '0 записей')


# Сколько уникальных IP обогащать RDAP/RIPEstat при поиске пулов.
# Каждый IP — до двух HTTPS-запросов к внешним сервисам; на слабом
# роутере 6 штук — разумный потолок по времени ответа панели.
_LOOKUP_RDAP_LIMIT = 6


def _curl_json(url, max_time=6):
    """GET JSON через curl; None при любой ошибке/не-JSON."""
    try:
        r = subprocess.run(
            ['curl', '-s', '--connect-timeout', '4',
             '--max-time', str(max_time), url],
            capture_output=True, text=True,
            timeout=max_time + 4,
            check=False)
        if r.returncode != 0 or not r.stdout:
            return None
        return json.loads(r.stdout)
    except (OSError, ValueError):
        # OSError — curl недоступен/убит; ValueError — тело не JSON.
        return None


def _ip_owner_info(ip_str):
    """RDAP + RIPEstat по IP: CIDR владельца, ASN, организация.

    Источники:
      * https://rdap.org/ip/{ip} — реестр (bootstrap на нужный RIR):
        имя сети, тип, страна, исходный CIDR из cidr0_cidrs либо
        start/end-адресов;
      * RIPEstat prefix-overview — анонсированный префикс и
        (asn, holder) — то, что реально маршрутизируется.
    Все ветки необязательны: чего нет — того нет.
    """
    info = {}
    rd = _curl_json(
        f'https://rdap.org/ip/{ip_str}')
    if isinstance(rd, dict):
        name = (rd.get('name')
                or rd.get('handle') or '')
        if name:
            info['rdap_name'] = str(name)
        for k in ('type', 'country'):
            if rd.get(k):
                info['rdap_' + k] = str(rd[k])
        # Современный формат: cidr0_cidrs[]
        for c in rd.get('cidr0_cidrs') or []:
            v4 = c.get('v4prefix')
            ln = c.get('length')
            if v4 and ln is not None:
                info['rdap_cidr'] = f'{v4}/{ln}'
                break
        # Старый формат: startAddress/endAddress
        if ('rdap_cidr' not in info
                and rd.get('startAddress')
                and rd.get('endAddress')):
            try:
                s = ipaddress.ip_address(
                    rd['startAddress'])
                e = ipaddress.ip_address(
                    rd['endAddress'])
                nets = [
                    str(n)
                    for n in
                    ipaddress.summarize_address_range(
                        s, e)]
                if nets:
                    info['rdap_cidr'] = nets[0]
            except (ValueError, TypeError):
                # Кривые start/end в ответе реестра — просто без CIDR.
                pass
        # Организация из entities (registrant)
        for ent in rd.get('entities') or []:
            roles = ent.get('roles') or []
            if 'registrant' not in roles:
                continue
            vc = ent.get('vcardArray')
            try:
                for row in (vc[1] if vc
                            and len(vc) > 1
                            else []):
                    if (row
                            and row[0] == 'fn'
                            and len(row) > 3):
                        info['org'] = str(row[3])
                        raise StopIteration
            except StopIteration:
                break
            except (IndexError, KeyError,
                    TypeError, ValueError):
                # Кривой vcard у entity — имя сети уже есть,
                # организацию можно пропустить.
                break
    st = _curl_json(
        'https://stat.ripe.net/data/'
        'prefix-overview/data.json'
        f'?resource={ip_str}')
    if isinstance(st, dict):
        d = st.get('data') or {}
        bl = d.get('block') or {}
        if bl.get('resource'):
            info['prefix'] = str(bl['resource'])
        asns = d.get('asns') or []
        if asns:
            first = asns[0] or {}
            if first.get('asn'):
                info['asn'] = (
                    f"AS{first['asn']}")
            if first.get('holder'):
                info['as_holder'] = str(
                    first['holder'])
    return info


def _lookup_resource(query):
    results = {
        'query': query, 'ips': [],
        'cidrs': [], 'domains': [],
        'in_lists': {}, 'errors': [],
        'missing': [], 'found': [],
        'covered': {}, 'ipinfo': {},
    }
    q = query.strip().lower()

    presets = {
        'telegram': {
            'cidr_url': (
                'https://core.telegram.org'
                '/resources/cidr.txt'),
            'domains': [
                'api.telegram.org',
                'cdn-telegram.org',
                'telegram.org', 't.me',
                'core.telegram.org',
                'telegra.ph',
                'telegram.me',
            ],
        },
        'whatsapp': {
            'domains': [
                'whatsapp.com',
                'whatsapp.net', 'wa.me',
                'web.whatsapp.com',
                'static.whatsapp.net',
                'mmg.whatsapp.net',
                'media.fna.whatsapp.net',
                'pps.whatsapp.net',
                'fbcdn.com', 'fbcdn.net',
            ],
        },
        'youtube': {
            'domains': [
                'youtube.com',
                'youtu.be',
                'googlevideo.com',
                'ytimg.com',
                'ggpht.com',
                'googleusercontent.com',
                'youtube-nocookie.com',
                'googleapis.com',
            ],
        },
    }

    # IPv4-only фильтр
    _ip4 = re.compile(
        r'^\d+\.\d+\.\d+\.\d+$')
    # Имя хоста: буквы/цифры/дефис/точка, без ведущего дефиса.
    _host_re = re.compile(
        r'^(?!-)[a-z0-9-]{1,63}'
        r'(?:\.(?!-)[a-z0-9-]{1,63})*\.?$')
    _cidr4 = re.compile(
        r'^\d+\.\d+\.\d+\.\d+/\d+$')

    if q in presets:
        preset = presets[q]
        results['domains'] = list(
            preset.get('domains', []))
        cidr_url = preset.get('cidr_url')
        if cidr_url:
            try:
                r = subprocess.run(
                    ['curl', '-s',
                     '--max-time', '10',
                     cidr_url],
                    capture_output=True,
                    check=False,
                    text=True, timeout=15)
                if r.returncode == 0:
                    for line in (
                            r.stdout.strip()
                            .split('\n')):
                        line = line.strip()
                        if (line
                                and _cidr4.match(
                                    line)):
                            results[
                                'cidrs'
                            ].append(line)
            except Exception:
                pass
        for domain in results['domains']:
            try:
                r = subprocess.run(
                    ['dig', '+short',
                     domain, '@localhost'],
                    capture_output=True,
                    text=True, timeout=10)
                for ip in (
                        r.stdout.strip()
                        .split('\n')):
                    ip = ip.strip()
                    if (_ip4.match(ip)
                            and ip not in
                            results['ips']):
                        results[
                            'ips'
                        ].append(ip)
            except Exception:
                pass
    elif _ip4.match(q):
        results['ips'] = [q]
    elif _cidr4.match(q):
        results['cidrs'] = [q]
    elif (q.startswith('as')
          and q[2:].isdigit()):
        asn = q.upper()
        try:
            r = subprocess.run(
                ['curl', '-s',
                 '--max-time', '15',
                 'https://stat.ripe.net'
                 '/data/announced-prefixes'
                 '/data.json'
                 f'?resource={asn}'],
                capture_output=True,
                text=True, timeout=20)
            if r.returncode == 0:
                data = json.loads(
                    r.stdout)
                for p in (
                        data.get('data', {})
                        .get('prefixes',
                             [])):
                    prefix = p.get(
                        'prefix', '')
                    if (prefix
                            and _cidr4.match(
                                prefix)):
                        results[
                            'cidrs'
                        ].append(prefix)
        except Exception as e:
            results['errors'].append(
                str(e))
    else:
        # Валидация домена перед передачей во внешнюю утилиту.
        # Раньше в dig уходила произвольная строка: значение вида
        # "-f/etc/passwd" трактовалось бы как ОПЦИЯ, а не имя хоста
        # (аргументы передаются списком, поэтому shell-инъекция была
        # невозможна, но подмена опции — вполне).
        if not _host_re.match(q) or len(q) > 253:
            results['errors'].append(
                'Недопустимое имя хоста')
            results['domains'] = []
            return results
        results['domains'] = [q]
        try:
            r = subprocess.run(
                ['dig', '+short', '--', q,
                 '@localhost'],
                capture_output=True,
                text=True, timeout=10)
            for ip in (
                    r.stdout.strip()
                    .split('\n')):
                ip = ip.strip()
                if _ip4.match(ip):
                    results[
                        'ips'
                    ].append(ip)
        except Exception:
            pass
        try:
            r = subprocess.run(
                ['dig', '+short', 'CNAME',
                 '--', q, '@localhost'],
                capture_output=True,
                text=True, timeout=10)
            for cname in (
                    r.stdout.strip()
                    .split('\n')):
                cname = (
                    cname.strip()
                    .rstrip('.'))
                if (cname and cname != q
                        and ':' not in
                        cname):
                    results[
                        'domains'
                    ].append(cname)
        except Exception:
            pass

    # ═══════════════════════════════
    # Загрузить все записи из списков
    # ═══════════════════════════════

    list_domains = {}  # domain → [files]
    list_cidrs = []    # [(network, file)]

    for fp in _all_bypass_filepaths():
        fname = os.path.splitext(
            os.path.basename(fp))[0]
        if not os.path.exists(fp):
            continue
        for line in (
                read_file_text(fp)
                .split('\n')):
            entry = line.split('#')[0].strip()
            if not entry:
                continue
            if _cidr4.match(entry):
                try:
                    net = (
                        ipaddress.ip_network(
                            entry,
                            strict=False))
                    list_cidrs.append(
                        (net, fname))
                except ValueError:
                    pass
            elif _ip4.match(entry):
                try:
                    net = (
                        ipaddress.ip_network(
                            entry + '/32',
                            strict=False))
                    list_cidrs.append(
                        (net, fname))
                except ValueError:
                    pass
            elif entry and '/' not in entry:
                if entry not in list_domains:
                    list_domains[entry] = []
                list_domains[entry].append(
                    fname)

    # ═══════════════════════════════
    # Проверка доменов
    # (точное + родительский домен)
    # ═══════════════════════════════

    all_items = set()
    found_anywhere = set()
    covered = {}

    for domain in results['domains']:
        all_items.add(domain)
        # Точное совпадение
        if domain in list_domains:
            found_anywhere.add(domain)
            for f in list_domains[domain]:
                results['in_lists']. \
                    setdefault(f, []) \
                    .append(domain)
            continue
        # Родительский домен
        parts = domain.split('.')
        parent_found = False
        for i in range(1, len(parts)):
            parent = '.'.join(parts[i:])
            if parent in list_domains:
                found_anywhere.add(domain)
                covered[domain] = parent
                for f in (
                        list_domains[parent]):
                    results['in_lists']. \
                        setdefault(f, []) \
                        .append(
                            f"{domain} "
                            f"({parent})")
                parent_found = True
                break
        if not parent_found:
            pass  # пойдёт в missing

    # ═══════════════════════════════
    # Проверка IP
    # (точное + вхождение в CIDR)
    # ═══════════════════════════════

    for ip_str in results['ips']:
        all_items.add(ip_str)
        try:
            ip_addr = ipaddress.ip_address(
                ip_str)
        except ValueError:
            continue
        ip_found = False
        # Точное
        if ip_str in list_domains:
            found_anywhere.add(ip_str)
            ip_found = True
            for f in list_domains[ip_str]:
                results['in_lists']. \
                    setdefault(f, []) \
                    .append(ip_str)
        # Вхождение в CIDR
        if not ip_found:
            for net, fname in list_cidrs:
                if ip_addr in net:
                    found_anywhere.add(
                        ip_str)
                    covered[ip_str] = (
                        str(net))
                    results['in_lists']. \
                        setdefault(
                            fname, []) \
                        .append(
                            f"{ip_str} "
                            f"({net})")
                    ip_found = True
                    break

    # ═══════════════════════════════
    # Проверка CIDR
    # (точное + вхождение в больший)
    # ═══════════════════════════════

    for cidr_str in results['cidrs']:
        all_items.add(cidr_str)
        try:
            check_net = (
                ipaddress.ip_network(
                    cidr_str, strict=False))
        except ValueError:
            continue
        for net, fname in list_cidrs:
            if (check_net.subnet_of(net)
                    and check_net != net):
                # Вложен в больший
                found_anywhere.add(cidr_str)
                covered[cidr_str] = (
                    str(net))
                results['in_lists']. \
                    setdefault(fname, []) \
                    .append(
                        f"{cidr_str} "
                        f"({net})")
                break
            elif check_net == net:
                # Точное совпадение
                found_anywhere.add(cidr_str)
                results['in_lists']. \
                    setdefault(fname, []) \
                    .append(cidr_str)
                break

    # ═══════════════════════════════
    # RDAP/RIPEstat обогащение IP:
    # CIDR владельца, ASN, организация.
    # Используется вкладкой поиска пулов
    # (задача: добавить выбранный
    # CIDR/домен в нужный список).
    # ═══════════════════════════════
    for ip_str in results['ips'][
            :_LOOKUP_RDAP_LIMIT]:
        info = _ip_owner_info(ip_str)
        if info:
            results['ipinfo'][ip_str] = info
            # Анонсированный префикс владельца — кандидат
            # во множество CIDR для добавления в списки.
            pfx = info.get('prefix') or info.get(
                'rdap_cidr') or ''
            if (pfx and _cidr4.match(pfx)
                    and pfx
                    not in results['cidrs']):
                results['cidrs'].append(pfx)

    results['missing'] = sorted(
        all_items - found_anywhere)
    results['found'] = sorted(
        found_anywhere)
    results['covered'] = covered

    return results



# ── Дашборд «KeeneticOS Hybrid» (этап 1) ────────────────────────────────
# Главная страница панели: обзор ПРОЕКТА (списки обхода, сервисы, DNS,
# обновления) + лёгкая системная телеметрия (/proc/*). Данные отдаёт
# /api/dashboard (TTL-кэш), тяжёлый статус DNS — отдельный медленный
# полл /api/dns-status, как на вкладке dns. Никаких внешних ассетов:
# стиль, иконки и скрипт инлайн; график — canvas, 1 кадр в тик опроса,
# пауза при скрытой вкладке (см. JS в конце шаблона).
SHELL_TEMPLATE = r'''<!DOCTYPE html>
<html lang="ru" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>KeenZOO Panel · {{ tab_title }}</title>
<style>
:root{
  --font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif;
  --r-l:12px; --r-m:10px; --r-s:8px;
 --fs-caption:13px;--fs-s:14.5px;--fs-m:15px;--fs-l:17px;--fs-xl:18px;
 --sp-1:4px;--sp-2:8px;--sp-3:12px;--sp-4:16px;--sp-5:24px;--sp-6:32px;
 --z-sticky:30;--z-menu:40;--z-pop:50;--z-backdrop:55;--z-rail:60;--z-tip:70;--z-toast:90;
 --ease:cubic-bezier(.2,.7,.3,1);--dur:.15s;
  --bg:#e9edf2; --surface:#ffffff; --surface-2:#f1f4f8; --surface-3:#e6ebf1;
  --outline:#d7dee7; --outline-2:#e8edf3;
  --text:#1b2433; --muted:#4b5a6e; --faint:#546273;
  --primary:#007fb4; --primary-h:#009bd6; --primary-c:#d9f1fc; --on-primary-c:#0a4f78;
  --ok:#0b9c66; --ok-c:#e3f6ee; --on-ok-c:#075e42;
  --warn:#b35408; --warn-c:#fcf1e0; --on-warn-c:#7a4108;
  --err:#d43c3c; --err-c:#fdeaea; --on-err-c:#991b1b;
  --sh-1:0 1px 2px rgba(27,36,51,.06),0 2px 6px rgba(27,36,51,.05);
  --sh-2:0 6px 18px rgba(27,36,51,.10),0 16px 36px rgba(27,36,51,.10);
  --rail-w:76px; --rail-wx:240px; --top-h:60px;
  color-scheme:light;
}
html[data-theme="dark"]{
  --bg:#1b2433; --surface:#1e293b; --surface-2:#17202d; --surface-3:#2b3a50;
  --outline:#2b3644; --outline-2:#202a37;
  --text:#e9edf3; --muted:#a3b0c2; --faint:#8a95a7;
  --primary:#00a8e8; --primary-h:#29b9f2; --primary-c:#17394e; --on-primary-c:#cfeafe;
  --ok:#31d09b; --ok-c:#0d3527; --on-ok-c:#a7f3d0;
  --warn:#f2b13e; --warn-c:#39290b; --on-warn-c:#fde3a7;
  --err:#f87e7e; --err-c:#3d181b; --on-err-c:#fecdcd;
  --sh-1:0 1px 2px rgba(0,0,0,.45); --sh-2:0 8px 26px rgba(0,0,0,.55);
  color-scheme:dark;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{font:14px/1.5 var(--font);background:var(--bg);color:var(--text);
  -webkit-font-smoothing:antialiased;transition:background .25s,color .25s}
button{font:inherit;color:inherit;background:none;border:0;cursor:pointer}
a{color:inherit;text-decoration:none}
:focus-visible{outline:2px solid var(--primary);outline-offset:2px;border-radius:6px}
.ico{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;
  stroke-linecap:round;stroke-linejoin:round;flex:none}
.ico-s{width:16px;height:16px}.ico-l{width:24px;height:24px}
.rail{position:fixed;inset:0 auto 0 0;width:var(--rail-w);z-index:var(--z-rail);
  background:var(--surface);border-right:1px solid var(--outline);
  display:flex;flex-direction:column;overflow:hidden;
  transition:width .2s var(--ease),box-shadow .2s}
.rail:hover,body.rail-pin .rail{width:var(--rail-wx);box-shadow:var(--sh-2)}
.rail-head{height:var(--top-h);display:flex;align-items:center;gap:12px;padding:0 24px;flex:none;white-space:nowrap}
.logo{width:38px;height:38px;border-radius:12px;flex:none;display:grid;place-items:center;color:#fff;
  background:linear-gradient(135deg,#0061e6,#0043b8);box-shadow:0 3px 10px rgba(0,97,230,.35)}
.rail-title{font-size:20px;font-weight:750;letter-spacing:-.02em;opacity:0;transition:opacity .15s}
.rail-title b{color:var(--primary);font-weight:800}
.rail:hover .rail-title,body.rail-pin .rail-title{opacity:1}
nav{flex:1;padding:8px;display:flex;flex-direction:column;gap:4px}
.rail-item{display:flex;align-items:center;gap:14px;height:46px;padding:0 26px;
  border-radius:12px;color:var(--muted);font-weight:550;white-space:nowrap;
  transition:background .15s,color .15s;position:relative}
.rail-item .ico{width:22px;height:22px;flex:none}
.rail-item:hover{background:var(--surface-2);color:var(--text)}
.rail-item[aria-current="page"]{background:var(--primary-c);color:var(--on-primary-c);font-weight:650}
.rail-item[aria-current="page"]::before{content:"";position:absolute;left:-8px;top:12px;bottom:12px;
  width:4px;border-radius:4px;background:var(--primary)}
.rail .lbl{opacity:0;transition:opacity .15s}
.rail:hover .lbl,body.rail-pin .lbl{opacity:1}
.rail-tip{position:absolute;left:calc(100% + 10px);top:50%;transform:translateY(-50%);
  background:var(--text);color:var(--bg);font-size:var(--fs-caption);font-weight:500;padding:5px 10px;
  border-radius:6px;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .12s;z-index:var(--z-tip)}
.rail:not(:hover) .rail-item:not([aria-current]):hover .rail-tip{opacity:1}
.rail-backdrop{display:none;position:fixed;inset:0;z-index:var(--z-backdrop);background:rgba(15,20,28,.45)}
body.rail-open .rail-backdrop{display:block}
.rail-foot{padding:10px 16px 16px;border-top:1px solid var(--outline-2);flex:none;white-space:nowrap}
.rail-pin-btn{display:flex;align-items:center;gap:14px;width:100%;padding:10px 10px;
  border-radius:10px;color:var(--muted);font-size:var(--fs-s)}
.rail-pin-btn:hover{background:var(--surface-2);color:var(--text)}
.rail-pin-btn .ico{transition:transform .2s}
body.rail-pin .rail-pin-btn .ico{transform:rotate(180deg)}
.rail-ver{display:flex;align-items:center;gap:10px;font-size:var(--fs-caption);color:var(--muted);padding:8px 10px}
.rail-ver .dot{width:8px;height:8px;border-radius:50%;background:var(--ok);flex:none}
.theme-btn{margin-left:auto;width:30px;height:30px;border-radius:8px;display:grid;
  place-items:center;color:var(--muted)}
.theme-btn:hover{background:var(--surface-2);color:var(--text)}
.main{margin-left:var(--rail-w);min-height:100vh;display:flex;flex-direction:column;
  transition:margin-left .2s var(--ease)}
.topbar{position:sticky;top:0;z-index:var(--z-sticky);height:var(--top-h);flex:none;
  display:flex;align-items:center;gap:14px;padding:0 24px;
  background:color-mix(in srgb,var(--surface) 90%,transparent);
  backdrop-filter:blur(10px);border-bottom:1px solid var(--outline)}
.menu-btn{width:40px;height:40px;border-radius:var(--r-s);display:none;place-items:center;color:var(--muted)}
@media(max-width:760px){.menu-btn{display:grid}}
.tb-crumb{font-size:var(--fs-caption);color:var(--faint)}
.tb-title{font-size:19px;font-weight:750;letter-spacing:.1px}
.tb-title b{color:var(--primary);font-weight:800}
/* FB-190 (панель-r83): KeenZOO в шапке — только когда рельс свёрнут
   до значков (или мобильный вид); развёрнутое меню — вордмарк в рельсе */
@media(min-width:701px){
.tb-title{display:none}
body.rail-ico .tb-title{display:inline}
}
@media(max-width:700px){
body.rail-open .tb-title{display:none}
}
/* ── FB-149 (панель-77): подпункты рельса — видны всегда (Протоколы: Hysteria…Tor) ── */
.rail-subs{display:none;flex-direction:column;margin:2px 0 6px}
.rail:hover .rail-subs,body.rail-pin .rail-subs{display:flex}
.rail-subs a{display:flex;align-items:center;height:36px;padding:0 16px 0 50px;
  color:var(--muted);font-size:var(--fs-s);text-decoration:none;
  border-radius:0 var(--r-s) var(--r-s) 0;white-space:nowrap}
.rail-subs a:hover{background:var(--surface-2);color:var(--text)}
.rail-subs a[aria-current="page"]{background:var(--primary-c);color:var(--on-primary-c);font-weight:600}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:14px}
.tb-model{font-size:var(--fs-caption);color:var(--muted);text-align:right;line-height:1.35}
.tb-model b{color:var(--text);font-weight:650}
.uptime{font-size:var(--fs-caption);color:var(--muted)}
.badge{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:999px;
  font-weight:600;font-size:var(--fs-s);background:var(--primary-c);color:var(--on-primary-c)}
.badge.down{background:var(--err-c);color:var(--on-err-c)}
.pulse{width:8px;height:8px;border-radius:50%;background:currentColor;position:relative}
.pulse::after{content:"";position:absolute;inset:-4px;border-radius:50%;
  border:2px solid currentColor;opacity:.5;animation:pulse 2s ease-out infinite}
@keyframes pulse{0%{transform:scale(.4);opacity:.8}80%,100%{transform:scale(1.3);opacity:0}}
.bell-wrap{position:relative}
.bell{width:40px;height:40px;border-radius:var(--r-s);display:grid;place-items:center;
  color:var(--muted);position:relative;transition:background .15s,color .15s}
.bell:hover{background:var(--surface-2);color:var(--text)}
.evmenu{position:absolute;right:0;top:48px;width:370px;max-width:calc(100vw - 32px);
  background:var(--surface);border:1px solid var(--outline);border-radius:var(--r-l);
  box-shadow:var(--sh-2);padding:8px;display:none;z-index:var(--z-pop)}
.evmenu.open{display:block;animation:pop .18s ease-out}
@keyframes pop{from{opacity:0;transform:translateY(-6px) scale(.98)}to{opacity:1;transform:none}}
.ev{display:flex;gap:12px;padding:12px;border-radius:var(--r-m);cursor:default}
.ev:hover{background:var(--surface-2)}
.ev h4{font-size:var(--fs-s);font-weight:600}
.ev p{font-size:var(--fs-caption);color:var(--muted);margin-top:2px}

.frame{flex:1;width:100%;border:0;display:block;background:var(--bg)}
/* FB-138 (ревью r71): мобильный пакет в конце стиля — в r71 стоял
   выше базовых правил и каскадом отменялся (см. пакет дашборда) */
@media(max-width:760px){
  .rail{transform:none;width:64px!important}
  body.rail-open .rail{width:var(--rail-wx)!important;box-shadow:var(--sh-2)}
  body.rail-open{overflow:hidden}
  body.rail-open .rail .lbl{opacity:1}
  body.rail-open .rail-subs{display:flex}
  .main{margin-left:64px!important}
  .topbar{padding:0 14px;gap:10px}
  .tb-name{flex:1 1 auto;min-width:0}
  .tb-title{font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
}

/* ═ FB-149/FB-151 (панель-77): сайдбар по решению владельца (panel_preview_r78): группы, подсветка, мобильный режим, палитра ═ */
:root{--kz-side:#ffffff;--kz-side-hover:#e8f0f8;--kz-side-active:#d9edf8;--kz-side-line:#c9d4e0}
html[data-theme="dark"]{--kz-side:#171f2c;--kz-side-hover:#202d40;--kz-side-active:#2d3e58;--kz-side-line:#344154}
.rail{width:208px!important;background:var(--kz-side);border-right:1px solid var(--kz-side-line)}
.rail:hover,body.rail-pin .rail{width:208px!important;box-shadow:none}
.rail-head{height:52px;padding:0 18px}
.rail .lbl{opacity:1!important}
.rail-tip{display:none!important}
.nav-head{font-size:11px;font-weight:700;color:var(--primary);text-transform:uppercase;
  letter-spacing:.3px;padding:12px 21px 6px}
.rail-item{height:38px;min-height:38px;padding:0 18px;border-left:3px solid transparent;
  border-radius:0;gap:11px}
.rail-item .ico{width:17px;height:17px;color:#9fb1c7}
.rail-item:hover{background:var(--kz-side-hover);color:var(--text)}
.rail-item[aria-current="page"]{background:var(--kz-side-active);border-left-color:var(--primary);color:var(--text);font-weight:700}
.rail-item[aria-current="page"]::before{display:none}
.rail-subs{display:flex!important;margin:0;padding:2px 8px 9px 34px}
.rail-subs a{height:auto;min-height:29px;padding:5px 10px;border-radius:3px;
  border-left:2px solid transparent;font-size:13.5px}
.rail-subs a:hover{background:var(--kz-side-hover);color:var(--text)}
.rail-subs a[aria-current="page"]{background:var(--kz-side-active);border-left-color:var(--primary);color:var(--text);font-weight:600}
.rail-pin-btn{display:none!important}
.rail-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:calc(var(--z-rail) - 1);
  opacity:0;pointer-events:none;transition:opacity .15s}
body.rail-open .rail-backdrop{opacity:1;pointer-events:auto}
.topbar{height:48px}
.tb-title{color:var(--primary);font-size:19px;font-weight:700;letter-spacing:.4px}
.main{margin-left:208px!important}
@media(max-width:700px){
  .rail{transform:translateX(-100%);width:260px!important;overflow-y:auto}
  body.rail-open .rail{transform:none;box-shadow:var(--sh-2)}
  body.rail-open{overflow:hidden}
  .main{margin-left:0!important}
  body.rail-open .rail{width:260px!important}
}
/* ═ FB-151 (панель-77): выравнивание и читаемость левого меню ═ */
.nav-head{font-size:12px;padding:13px 21px 6px}
.rail-item{font-size:15px}
.rail-item .lbl{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rail-subs{padding:2px 8px 9px 26px}
.rail-subs a{font-size:14px;padding:5px 21px}
/* ═══ FB-190..FB-203 (панель-r83, решение владельца): утверждённый шаблон
   panel_preview_r83.html — логотип/вордмарк, аббревиатуры, шрифты ═══ */
.logo{background:none;box-shadow:none;border-radius:0}
.logo .logo-svg,.hero .emoji .logo-svg{width:100%;height:100%;display:block}
.hero .emoji{background:none}
.wm b{color:var(--primary);font-weight:800}
body{font-variant-numeric:tabular-nums;-webkit-font-smoothing:antialiased}
/* FB-191 (панель-r83): кнопка «Скрыть меню» возвращена — рельс
   сворачивается до значков, подпункты протоколов — аббревиатуры
   HS/VL/TR/SS/TO (крупный полужирный шрифт); вордмарк рельса видим
   всегда в развёрнутом виде (ранее opacity:0 от hover-схемы r77) */
.rail-pin-btn{display:flex!important}
.rail-title{opacity:1!important}
@media(min-width:701px){
.rail{transition:width .2s var(--ease)}
body.rail-ico .rail{width:76px!important}
body.rail-ico .main{margin-left:76px!important}
body.rail-ico .rail-head{padding:0;justify-content:center}
body.rail-ico .rail .lbl,body.rail-ico .rail-title{display:none}
body.rail-ico .rail-item{justify-content:center;padding:0;
  border-left-color:transparent;border-right:3px solid transparent}
body.rail-ico .rail-item[aria-current="page"]{border-right-color:var(--primary)}
body.rail-ico .rail-pin-btn{justify-content:center;padding:10px 0}
body.rail-ico .rail-pin-btn .lbl{display:none}
body.rail-ico .rail-pin-btn .ico{transform:rotate(180deg)}
body.rail-ico .rail-subs{display:flex!important;flex-direction:row;flex-wrap:wrap;
  justify-content:center;gap:3px;margin:0;padding:2px 8px 8px}
body.rail-ico .rail-subs a{font-size:0;min-height:0;height:auto;padding:7px 8px;
  border-radius:8px;border-left-width:0}
body.rail-ico .rail-subs a::before{content:attr(data-abbr);font-size:14px;font-weight:700;letter-spacing:.02em}
}</style>
</head>
<body>
<svg style="display:none" xmlns="http://www.w3.org/2000/svg">
  <!-- FB-190 (панель-r83): новый символ проекта — щит + Wi-Fi (MD3) -->
  <symbol id="i-logo" viewBox="0 0 24 24">
    <defs><linearGradient id="lgz" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#00a8e8"/><stop offset="1" stop-color="#0072a6"/>
    </linearGradient></defs>
    <path d="M12 1.7l8.3 3.7v5.7c0 5.3-3.5 9-8.3 10.5C7.2 20.1 3.7 16.4 3.7 11.1V5.4L12 1.7z" fill="url(#lgz)"/>
    <path d="M7.3 7.7a7.6 7.6 0 0 1 9.4 0" stroke="#fff" stroke-width="1.7" fill="none" stroke-linecap="round"/>
    <path d="M9.5 10.4a4.3 4.3 0 0 1 5 0" stroke="#fff" stroke-width="1.7" fill="none" stroke-linecap="round"/>
    <circle cx="12" cy="13.5" r="1.55" fill="#fff"/>
  </symbol>
  <symbol id="i-dash" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></symbol>
<symbol id="i-apps" viewBox="0 0 24 24"><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><path d="M17 13v8M13 17h8"/></symbol>
<symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/></symbol>
<symbol id="i-cpu" viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9.5" y="9.5" width="5" height="5" rx="1"/><path d="M9 2v3m6-3v3M9 19v3m6-3v3M2 9h3m-3 6h3M19 9h3m-3 6h3"/></symbol>
<symbol id="i-gear" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></symbol>
<symbol id="i-right" viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></symbol>
<symbol id="i-moon" viewBox="0 0 24 24"><path d="M21 12.8A8.5 8.5 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></symbol>
<symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4l1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></symbol>
<symbol id="i-search" viewBox="0 0 24 24"><circle cx="10" cy="10" r="6"/><path d="m21 21-6-6"/></symbol>
<symbol id="i-bot" viewBox="0 0 24 24"><rect x="4.4" y="8.4" width="15.2" height="11.4" rx="3.6"/><circle cx="9.4" cy="13.8" r="1.25" fill="currentColor" stroke="none"/><circle cx="14.6" cy="13.8" r="1.25" fill="currentColor" stroke="none"/><path d="M9.7 17h4.6M12 8.4V5.6"/><circle cx="12" cy="4.5" r="1.15" fill="currentColor" stroke="none"/><path d="M2.4 12.8v3M21.6 12.8v3"/></symbol>
</svg>
<aside class="rail" aria-label="Разделы">
  <div class="rail-head">
    <span class="logo"><svg class="logo-svg" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-logo"/></svg></span>
    <span class="rail-title wm">Keen<b>ZOO</b></span>
    
  </div>
  <nav class="rail-nav">
    <div class="nav-head">Статус</div>
    <a class="rail-item" href="/"{% if rail_group == 'dash' %} aria-current="page"{% endif %}><svg class="ico" viewBox="0 0 24 24"><use href="#i-dash"/></svg><span class="lbl">Обзор</span></a>
    <div class="nav-head">Протоколы</div>
    <div class="rail-subs">
      <a href="/?tab=hy" data-abbr="HS"{% if tab == 'hy' %} aria-current="page"{% endif %}>Hysteria</a>
      <a href="/?tab=vl" data-abbr="VL"{% if tab == 'vl' %} aria-current="page"{% endif %}>VLESS</a>
      <a href="/?tab=tr" data-abbr="TR"{% if tab == 'tr' %} aria-current="page"{% endif %}>Trojan</a>
      <a href="/?tab=ss" data-abbr="SS"{% if tab == 'ss' %} aria-current="page"{% endif %}>Shadowsocks</a>
      <a href="/?tab=to" data-abbr="TO"{% if tab == 'to' %} aria-current="page"{% endif %}>Tor</a>
      <a href="/?tab=za" data-abbr="NZ"{% if tab == 'za' %} aria-current="page"{% endif %}>NFQWS2</a>
    </div>
    <div class="nav-head">Настройки</div>
    <a class="rail-item" href="/?tab=dns"{% if tab == 'dns' %} aria-current="page"{% endif %}><svg class="ico" viewBox="0 0 24 24"><use href="#i-shield"/></svg><span class="lbl">DNS</span></a>
    <a class="rail-item" href="/?tab=upd"{% if tab == 'upd' %} aria-current="page"{% endif %}><svg class="ico" viewBox="0 0 24 24"><use href="#i-cpu"/></svg><span class="lbl">Обновления</span></a>
    <a class="rail-item" href="/?tab=cfg"{% if tab == 'cfg' %} aria-current="page"{% endif %}><svg class="ico" viewBox="0 0 24 24"><use href="#i-gear"/></svg><span class="lbl">Конфигурации</span></a>
    <a class="rail-item" href="/?tab=lk"{% if tab == 'lk' %} aria-current="page"{% endif %}><svg class="ico" viewBox="0 0 24 24"><use href="#i-search"/></svg><span class="lbl">Поиск</span></a>
    <a class="rail-item" href="/?tab=bt"{% if tab == 'bt' %} aria-current="page"{% endif %}><svg class="ico" viewBox="0 0 24 24"><use href="#i-bot"/></svg><span class="lbl">Telegram-бот</span></a>
  </nav>
  <div class="rail-foot">
    <button class="rail-pin-btn" id="pinBtn" type="button"><svg class="ico ico-s" viewBox="0 0 24 24"><use href="#i-right"/></svg><span class="lbl">Скрыть меню</span></button>
    <div class="rail-ver">
      <button class="theme-btn" id="themeBtn" type="button" aria-label="Переключить тему"><svg class="ico ico-s" viewBox="0 0 24 24"><use href="#i-moon"/></svg></button>
    </div>
  </div>
</aside>
<div class="rail-backdrop" id="railBd"></div>

<div class="main">
  <header class="topbar">
    <button class="menu-btn" id="menuBtn" type="button" aria-label="Открыть меню"><svg class="ico" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>
    <div class="tb-name">
      <div class="tb-title">Keen<b>ZOO</b></div>
    </div>
  </header>
  <iframe class="frame" id="panelFrame" src="/panel?tab={{ tab }}" title="KeenZOO · {{ tab_title }}"></iframe>
</div>
<script>
/* FB-136 (вариант A): оболочка MD3; содержимое прежней панели — в
   same-origin iframe /panel?tab=… (общие localStorage-тема, общие
   endpooints). Тема синхронизируется окну и фрейму через storage. */
(function(){
  var $=function(id){return document.getElementById(id)};
  function setTheme(t){document.documentElement.dataset.theme=t;
    try{localStorage.setItem('kzp-theme',t)}catch(e){}
    var b=$('themeBtn');if(b){b.setAttribute('aria-pressed',String(t==='dark'));
      /* FB-194 (панель-r83): значок меняется вместе с темой (как в дашборде) */
      var u=b.firstElementChild&&b.firstElementChild.firstElementChild;
      if(u)u.setAttribute('href',t==='dark'?'#i-sun':'#i-moon')}}
  try{var saved=localStorage.getItem('kzp-theme');if(saved)setTheme(saved)}catch(e){}
  try{window.addEventListener('storage',function(e){if(e.key==='kzp-theme'&&(e.newValue==='dark'||e.newValue==='light'))setTheme(e.newValue)})}catch(e){}
  $('themeBtn').addEventListener('click',function(){setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark')});
  /* FB-191 (панель-r83): «Скрыть меню» — сворачивание рельса до значков;
     FB-190: KeenZOO в шапке появляется только в свёрнутом виде */
  $('pinBtn').addEventListener('click',function(){
    var ico=document.body.classList.toggle('rail-ico');
    this.setAttribute('title',ico?'Показать меню':'Скрыть меню')});
  /* FB-149 (панель-77): ☰ — выезжающее меню на мобильном; клик по пункту/вне — закрыть */
  $('menuBtn').addEventListener('click',function(e){e.stopPropagation();
    document.body.classList.toggle('rail-open')});
  var kzBd=$('railBd');if(kzBd)kzBd.addEventListener('click',function(){
    document.body.classList.remove('rail-open')});
  Array.prototype.forEach.call(document.querySelectorAll('.rail a'),function(a){
    a.addEventListener('click',function(){document.body.classList.remove('rail-open')})});
  $('railBd').addEventListener('click',function(){document.body.classList.remove('rail-open')});
})();
</script>
</body>
</html>
'''

DASH_TEMPLATE = r'''<!DOCTYPE html>
<html lang="ru" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="kz-csrf" content="{{ csrf_token }}">
<title>KeenZOO Panel · Обзор</title>
<style>
:root{
  --font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif;
  --r-l:12px; --r-m:10px; --r-s:8px;
 --fs-caption:13px;--fs-s:14.5px;--fs-m:15px;--fs-l:17px;--fs-xl:18px;
 --sp-1:4px;--sp-2:8px;--sp-3:12px;--sp-4:16px;--sp-5:24px;--sp-6:32px;
 --z-sticky:30;--z-menu:40;--z-pop:50;--z-backdrop:55;--z-rail:60;--z-tip:70;--z-toast:90;
 --ease:cubic-bezier(.2,.7,.3,1);--dur:.15s;
  --bg:#e9edf2; --surface:#ffffff; --surface-2:#f1f4f8; --surface-3:#e6ebf1;
  --outline:#d7dee7; --outline-2:#e8edf3;
  --text:#1b2433; --muted:#4b5a6e; --faint:#546273;
  --primary:#007fb4; --primary-h:#009bd6; --primary-c:#d9f1fc; --on-primary-c:#0a4f78;
  --ok:#0b9c66; --ok-c:#e3f6ee; --on-ok-c:#075e42;
  --warn:#b35408; --warn-c:#fcf1e0; --on-warn-c:#7a4108;
  --err:#d43c3c; --err-c:#fdeaea; --on-err-c:#991b1b;
  --sh-1:0 1px 2px rgba(27,36,51,.06),0 2px 6px rgba(27,36,51,.05);
  --sh-2:0 6px 18px rgba(27,36,51,.10),0 16px 36px rgba(27,36,51,.10);
  --rail-w:76px; --rail-wx:240px; --top-h:60px;
  color-scheme:light;
}
html[data-theme="dark"]{
  --bg:#1b2433; --surface:#1e293b; --surface-2:#17202d; --surface-3:#2b3a50;
  --outline:#2b3644; --outline-2:#202a37;
  --text:#e9edf3; --muted:#a3b0c2; --faint:#8a95a7;
  --primary:#00a8e8; --primary-h:#29b9f2; --primary-c:#17394e; --on-primary-c:#cfeafe;
  --ok:#31d09b; --ok-c:#0d3527; --on-ok-c:#a7f3d0;
  --warn:#f2b13e; --warn-c:#39290b; --on-warn-c:#fde3a7;
  --err:#f87e7e; --err-c:#3d181b; --on-err-c:#fecdcd;
  --sh-1:0 1px 2px rgba(0,0,0,.45); --sh-2:0 8px 26px rgba(0,0,0,.55);
  color-scheme:dark;
}
*{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{font:14px/1.5 var(--font);background:var(--bg);color:var(--text);
  -webkit-font-smoothing:antialiased;transition:background .25s,color .25s}
button{font:inherit;color:inherit;background:none;border:0;cursor:pointer}
a{color:inherit;text-decoration:none}
:focus-visible{outline:2px solid var(--primary);outline-offset:2px;border-radius:6px}
.ico{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:2;
  stroke-linecap:round;stroke-linejoin:round;flex:none}
.ico-s{width:16px;height:16px}.ico-l{width:24px;height:24px}
.rail{position:fixed;inset:0 auto 0 0;width:var(--rail-w);z-index:var(--z-rail);
  background:var(--surface);border-right:1px solid var(--outline);
  display:flex;flex-direction:column;overflow:hidden;
  transition:width .2s var(--ease),box-shadow .2s}
.rail:hover,body.rail-pin .rail{width:var(--rail-wx);box-shadow:var(--sh-2)}
.rail-head{height:var(--top-h);display:flex;align-items:center;gap:12px;padding:0 24px;flex:none;white-space:nowrap}
.logo{width:38px;height:38px;border-radius:12px;flex:none;display:grid;place-items:center;color:#fff;
  background:linear-gradient(135deg,#0061e6,#0043b8);box-shadow:0 3px 10px rgba(0,97,230,.35)}
.rail-title{font-size:20px;font-weight:750;letter-spacing:-.02em;opacity:0;transition:opacity .15s}
.rail-title b{color:var(--primary);font-weight:800}
.rail:hover .rail-title,body.rail-pin .rail-title{opacity:1}
nav{flex:1;padding:8px;display:flex;flex-direction:column;gap:4px}
.rail-item{display:flex;align-items:center;gap:14px;height:46px;padding:0 26px;
  border-radius:12px;color:var(--muted);font-weight:550;white-space:nowrap;
  transition:background .15s,color .15s;position:relative}
.rail-item .ico{width:22px;height:22px;flex:none}
.rail-item:hover{background:var(--surface-2);color:var(--text)}
.rail-item[aria-current="page"]{background:var(--primary-c);color:var(--on-primary-c);font-weight:650}
.rail-item[aria-current="page"]::before{content:"";position:absolute;left:-8px;top:12px;bottom:12px;
  width:4px;border-radius:4px;background:var(--primary)}
.rail .lbl{opacity:0;transition:opacity .15s}
.rail:hover .lbl,body.rail-pin .lbl{opacity:1}
.rail-tip{position:absolute;left:calc(100% + 10px);top:50%;transform:translateY(-50%);
  background:var(--text);color:var(--bg);font-size:var(--fs-caption);font-weight:500;padding:5px 10px;
  border-radius:6px;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .12s;z-index:var(--z-tip)}
.rail:not(:hover) .rail-item:not([aria-current]):hover .rail-tip{opacity:1}
.rail-backdrop{display:none;position:fixed;inset:0;z-index:var(--z-backdrop);background:rgba(15,20,28,.45)}
body.rail-open .rail-backdrop{display:block}
.rail-foot{padding:10px 16px 16px;border-top:1px solid var(--outline-2);flex:none;white-space:nowrap}
.rail-pin-btn{display:flex;align-items:center;gap:14px;width:100%;padding:10px 10px;
  border-radius:10px;color:var(--muted);font-size:var(--fs-s)}
.rail-pin-btn:hover{background:var(--surface-2);color:var(--text)}
.rail-pin-btn .ico{transition:transform .2s}
body.rail-pin .rail-pin-btn .ico{transform:rotate(180deg)}
.rail-ver{display:flex;align-items:center;gap:10px;font-size:var(--fs-caption);color:var(--muted);padding:8px 10px}
.rail-ver .dot{width:8px;height:8px;border-radius:50%;background:var(--ok);flex:none}
.theme-btn{margin-left:auto;width:30px;height:30px;border-radius:8px;display:grid;
  place-items:center;color:var(--muted)}
.theme-btn:hover{background:var(--surface-2);color:var(--text)}
.main{margin-left:var(--rail-w);min-height:100vh;display:flex;flex-direction:column;
  transition:margin-left .2s var(--ease)}
.topbar{position:sticky;top:0;z-index:var(--z-sticky);height:var(--top-h);flex:none;
  display:flex;align-items:center;gap:14px;padding:0 24px;
  background:color-mix(in srgb,var(--surface) 90%,transparent);
  backdrop-filter:blur(10px);border-bottom:1px solid var(--outline)}
.menu-btn{width:40px;height:40px;border-radius:var(--r-s);display:none;place-items:center;color:var(--muted)}
@media(max-width:760px){.menu-btn{display:grid}}
.tb-crumb{font-size:var(--fs-caption);color:var(--faint)}
.tb-title{font-size:19px;font-weight:750;letter-spacing:.1px}
.tb-title b{color:var(--primary);font-weight:800}
/* FB-190 (панель-r83): KeenZOO в шапке — только когда рельс свёрнут
   до значков (или мобильный вид); развёрнутое меню — вордмарк в рельсе */
@media(min-width:701px){
.tb-title{display:none}
body.rail-ico .tb-title{display:inline}
}
@media(max-width:700px){
body.rail-open .tb-title{display:none}
}
/* ── FB-149 (панель-77): подпункты рельса — видны всегда (Протоколы: Hysteria…Tor) ── */
.rail-subs{display:none;flex-direction:column;margin:2px 0 6px}
.rail:hover .rail-subs,body.rail-pin .rail-subs{display:flex}
.rail-subs a{display:flex;align-items:center;height:36px;padding:0 16px 0 50px;
  color:var(--muted);font-size:var(--fs-s);text-decoration:none;
  border-radius:0 var(--r-s) var(--r-s) 0;white-space:nowrap}
.rail-subs a:hover{background:var(--surface-2);color:var(--text)}
.rail-subs a[aria-current="page"]{background:var(--primary-c);color:var(--on-primary-c);font-weight:600}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:14px}
.tb-model{font-size:var(--fs-caption);color:var(--muted);text-align:right;line-height:1.35}
.tb-model b{color:var(--text);font-weight:650}
.uptime{font-size:var(--fs-caption);color:var(--muted)}
.badge{display:inline-flex;align-items:center;gap:8px;padding:6px 14px;border-radius:999px;
  font-weight:600;font-size:var(--fs-s);background:var(--primary-c);color:var(--on-primary-c)}
.badge.down{background:var(--err-c);color:var(--on-err-c)}
.pulse{width:8px;height:8px;border-radius:50%;background:currentColor;position:relative}
.pulse::after{content:"";position:absolute;inset:-4px;border-radius:50%;
  border:2px solid currentColor;opacity:.5;animation:pulse 2s ease-out infinite}
@keyframes pulse{0%{transform:scale(.4);opacity:.8}80%,100%{transform:scale(1.3);opacity:0}}
.bell-wrap{position:relative}
.bell{width:40px;height:40px;border-radius:var(--r-s);display:grid;place-items:center;
  color:var(--muted);position:relative;transition:background .15s,color .15s}
.bell:hover{background:var(--surface-2);color:var(--text)}
.evmenu{position:absolute;right:0;top:48px;width:370px;max-width:calc(100vw - 32px);
  background:var(--surface);border:1px solid var(--outline);border-radius:var(--r-l);
  box-shadow:var(--sh-2);padding:8px;display:none;z-index:var(--z-pop)}
.evmenu.open{display:block;animation:pop .18s ease-out}
@keyframes pop{from{opacity:0;transform:translateY(-6px) scale(.98)}to{opacity:1;transform:none}}
.ev{display:flex;gap:12px;padding:12px;border-radius:var(--r-m);cursor:default}
.ev:hover{background:var(--surface-2)}
.ev h4{font-size:var(--fs-s);font-weight:600}
.ev p{font-size:var(--fs-caption);color:var(--muted);margin-top:2px}
.content{flex:1;padding:var(--sp-5) var(--sp-5) var(--sp-6);display:grid;gap:var(--sp-4);
  grid-template-columns:repeat(12,1fr);max-width:1440px;width:100%;margin:0 auto}
.card{background:var(--surface);border:1px solid var(--outline-2);border-radius:7px;
  box-shadow:var(--sh-1);padding:18px 20px;transition:box-shadow .2s}
.card:hover{box-shadow:var(--sh-2)}
.card-h{display:flex;align-items:center;gap:10px;margin-bottom:14px}
.card-h h2{font-size:var(--fs-m);font-weight:700}
.card-h .ico{color:var(--primary)}
.card-note{margin-left:auto;font-size:11.5px;color:var(--faint)}
.c-span12{grid-column:span 12}.c-span8{grid-column:span 8}.c-span7{grid-column:span 7}
.c-span5{grid-column:span 5}.c-span4{grid-column:span 4}
@media(max-width:1180px){.c-span8,.c-span7,.c-span5{grid-column:span 12}.c-span4{grid-column:span 6}}
@media(max-width:760px){.content{grid-template-columns:1fr}.c-span4{grid-column:span 1}}
.hero{grid-column:span 12;display:flex;align-items:center;gap:16px;flex-wrap:wrap;padding:18px 22px}
.hero .emoji{width:48px;height:48px;border-radius:14px;background:var(--primary-c);
  color:var(--primary);display:grid;place-items:center;flex:none}
.hero h1{font-size:var(--fs-xl);font-weight:750}
.hero p{font-size:var(--fs-s);color:var(--muted);margin-top:2px;max-width:640px}
.hero-actions{margin-left:auto;display:flex;gap:10px;flex-wrap:wrap}
.qbtn{display:inline-flex;align-items:center;gap:8px;padding:9px 16px;border-radius:999px;
  background:var(--primary);color:#fff;font-weight:600;font-size:var(--fs-s);
  box-shadow:0 2px 8px color-mix(in srgb,var(--primary) 35%,transparent);
  transition:background .15s,transform .1s}
.qbtn:hover{background:var(--primary-h)}
html[data-theme="dark"] .qbtn{color:#0b1512}
.qbtn:active{transform:scale(.97)}
.qbtn:disabled{opacity:.6;cursor:default}
.qbtn.ghost{background:var(--surface-2);color:var(--text);box-shadow:none;border:1px solid var(--outline)}
.qbtn.ghost:hover{background:var(--surface-3)}
.feed{display:flex;flex-direction:column}
.fitem{display:flex;gap:12px;padding:12px 8px;border-radius:var(--r-m)}
.fitem:hover{background:var(--surface-2)}
.fitem+.fitem{border-top:1px solid var(--outline-2)}
.fitem .ico-wrap{width:36px;height:36px;border-radius:10px;display:grid;place-items:center;flex:none}
.fitem.ok .ico-wrap{background:var(--ok-c);color:var(--ok)}
.fitem.warn .ico-wrap{background:var(--warn-c);color:var(--warn)}
.fitem.err .ico-wrap{background:var(--err-c);color:var(--err)}
.fitem.info .ico-wrap{background:var(--primary-c);color:var(--primary)}
.fitem h4{font-size:var(--fs-s);font-weight:650;line-height:1.4}
.fitem p{font-size:var(--fs-caption);color:var(--muted);margin-top:1px;line-height:1.45}
.kmap{display:flex;align-items:stretch;gap:10px;padding:6px 0 2px}
.knode{flex:1;border:1px solid var(--outline);border-radius:var(--r-l);padding:14px;
  display:flex;flex-direction:column;gap:8px;min-width:0;
  background:var(--surface-2);transition:transform .15s,box-shadow .15s}
.knode:hover{transform:translateY(-2px);box-shadow:var(--sh-1)}
.knode .top{display:flex;align-items:center;gap:10px}
.knode .tile{width:40px;height:40px;border-radius:11px;display:grid;place-items:center;flex:none;
  background:var(--surface);color:var(--muted);border:1px solid var(--outline)}
.knode.ok .tile{background:var(--ok-c);color:var(--ok);border-color:transparent}
.knode.pri .tile{background:var(--primary-c);color:var(--primary);border-color:transparent}
.knode.err .tile{background:var(--err-c);color:var(--err);border-color:transparent}
.knode b{font-size:var(--fs-s);font-weight:700}
.knode .st{margin-left:auto;font-size:11px;font-weight:700;padding:2px 10px;border-radius:999px}
.knode.ok .st{background:var(--ok-c);color:var(--on-ok-c)}
.knode.pri .st{background:var(--primary-c);color:var(--on-primary-c)}
.knode.err .st{background:var(--err-c);color:var(--on-err-c)}
.knode .st.off{background:var(--surface-3);color:var(--faint)}
.knode p{font-size:var(--fs-caption);color:var(--muted);line-height:1.5}
.kconn{display:flex;flex-direction:column;justify-content:center;gap:6px;flex:none;width:64px;
  align-items:center;padding-bottom:14px}
.kconn .pipe{width:100%;height:6px;border-radius:6px;background:var(--surface-3);position:relative;overflow:hidden}
.kconn .pipe::after{content:"";position:absolute;inset:0;border-radius:6px;
  background:linear-gradient(90deg,var(--primary),var(--primary-h));
  transform-origin:left;animation:fill .5s ease-out forwards}
.knode.err+.kconn .pipe::after,.knode.err~.kconn .pipe::after{background:var(--err)}
@keyframes fill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
.kconn small{font-size:10.5px;color:var(--faint);text-align:center;line-height:1.3}
.tr-head{display:flex;align-items:baseline;gap:18px;flex-wrap:wrap}
.tr-val .num{font-size:23px;font-weight:750;font-variant-numeric:tabular-nums}
.tr-val .num small{font-size:var(--fs-caption);font-weight:600;color:var(--muted);margin-left:4px}
.tr-val .cap{font-size:11.5px;color:var(--muted);display:flex;gap:6px;align-items:center;margin-top:2px}
.tr-val .cap i{width:10px;height:3px;border-radius:2px;display:inline-block}
.dl .num{color:var(--primary)}.dl .cap i{background:var(--primary)}
.ul .num{color:var(--ok)}.ul .cap i{background:var(--ok)}
.tr-note{margin-left:auto;font-size:11.5px;color:var(--faint);text-align:right}
canvas.chart{width:100%;height:185px;display:block;margin-top:12px;border-radius:var(--r-s)}
.rings{display:flex;justify-content:space-around;gap:12px;flex-wrap:wrap}
.ring{text-align:center;padding:8px 4px}
.ring svg{width:106px;height:106px;transform:rotate(-90deg)}
.ring .track{stroke:var(--surface-3);fill:none;stroke-width:10}
.ring .bar{fill:none;stroke-width:10;stroke-linecap:round;
  transition:stroke-dashoffset .8s var(--ease)}
.ring .pct{font-size:var(--fs-xl);font-weight:750;font-variant-numeric:tabular-nums}
.ring .cap{font-size:var(--fs-caption);color:var(--muted);margin-top:2px;line-height:1.35}
.ring small{font-size:11px;color:var(--faint)}
.lrow{display:flex;align-items:center;gap:12px;padding:10px 8px;border-radius:var(--r-m);
  transition:background .15s}
.lrow:hover{background:var(--surface-2)}
.lrow+.lrow{border-top:1px solid var(--outline-2)}
.lrow .nm{font-size:var(--fs-s);font-weight:600}
.lrow .cnt{font-size:var(--fs-caption);color:var(--muted);margin-top:1px}
.lrow .go{margin-left:auto;font-size:var(--fs-caption);color:var(--primary);font-weight:600;flex:none}
/* FB-193 (панель-r83): плитка «Обход блокировок» — сетка 2×3, кликабельные
   названия; FB-193: заголовок «DNS и туннели» — ссылка */
.pgrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.pgw{display:flex;align-items:center;gap:9px;padding:8px 12px;border-radius:var(--r-m);
  background:var(--surface-2);min-width:0}
.pgw:hover{background:var(--primary-c)}
.pgw .cnt{margin-left:auto;font-size:var(--fs-caption);color:var(--muted);white-space:nowrap;flex:none}
.pg-name{color:var(--primary);font-weight:650;text-decoration:none;font-size:var(--fs-m);
  min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pg-name:hover{text-decoration:underline}
.tlink{color:inherit;text-decoration:none}
.tlink:hover{color:var(--primary)}
/* FB-204 (панель-r84): одна колонка на узких экранах — строка
   «имя + счётчик» шире половины плитки, надписи наезжали */
@media(max-width:760px){.pgrid{grid-template-columns:1fr}}
.ldot{width:9px;height:9px;border-radius:50%;background:var(--surface-3);flex:none;
  box-shadow:0 0 0 3px color-mix(in srgb,var(--surface-3) 45%,transparent)}
.ldot.on{background:var(--ok);box-shadow:0 0 0 3px color-mix(in srgb,var(--ok) 18%,transparent)}
.dns-dots{display:flex;flex-wrap:wrap;gap:8px;margin:4px 0 10px}
.pdot{display:inline-flex;align-items:center;gap:6px;font-size:var(--fs-caption);font-variant-numeric:tabular-nums;
  padding:4px 10px;border-radius:999px;background:var(--surface-2);color:var(--muted)}
.pdot i{width:8px;height:8px;border-radius:50%;background:var(--faint)}
.pdot.ok{background:var(--ok-c);color:var(--on-ok-c)}.pdot.ok i{background:var(--ok)}
.pdot.bad{background:var(--err-c);color:var(--on-err-c)}.pdot.bad i{background:var(--err)}
.chips{display:flex;flex-wrap:wrap;gap:8px}
.chip{display:inline-flex;align-items:center;gap:7px;font-size:var(--fs-caption);font-weight:600;
  padding:5px 12px;border-radius:999px;background:var(--surface-2);color:var(--muted)}
.chip i{width:8px;height:8px;border-radius:50%;background:var(--faint)}
.chip.on{background:var(--ok-c);color:var(--on-ok-c)}.chip.on i{background:var(--ok)}
.subh{font-size:11.5px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;
  color:var(--faint);margin:14px 0 8px}
.subh:first-child{margin-top:0}
.dev{display:flex;align-items:center;gap:14px;padding:10px 8px;border-radius:var(--r-m);
  transition:background .15s}
.dev:hover{background:var(--surface-2)}
.dev+.dev{border-top:1px solid var(--outline-2)}
.dev .ico-wrap{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;flex:none;
  background:var(--surface-3);color:var(--muted)}
.dev .name{font-size:var(--fs-s);font-weight:600}
.dev .sub{font-size:11.5px;color:var(--faint);font-variant-numeric:tabular-nums}
.dev .ifchip{margin-left:auto;font-size:11px;color:var(--muted);background:var(--surface-2);
  padding:3px 10px;border-radius:999px;flex:none}
.upd-line{display:flex;align-items:baseline;gap:8px;padding:8px 4px}
.upd-line .st{font-size:var(--fs-s);font-weight:650}
.upd-line .ago{margin-left:auto;font-size:var(--fs-caption);color:var(--faint)}
.upd-sched{font-size:var(--fs-caption);color:var(--muted);line-height:1.6;margin-top:8px}
[data-tip]{position:relative;cursor:default}
[data-tip]::after{content:attr(data-tip);position:absolute;left:50%;bottom:calc(100% + 10px);
  transform:translateX(-50%) translateY(4px);width:max-content;max-width:300px;
  background:var(--text);color:var(--bg);font-size:var(--fs-caption);font-weight:400;line-height:1.5;
  padding:9px 12px;border-radius:8px;box-shadow:var(--sh-2);
  opacity:0;pointer-events:none;transition:opacity .15s .25s,transform .15s .25s;
  white-space:normal;z-index:var(--z-rail);text-align:left}
[data-tip]::before{content:"";position:absolute;left:50%;bottom:calc(100% + 4px);
  transform:translateX(-50%);border:6px solid transparent;border-top-color:var(--text);
  opacity:0;transition:opacity .15s .25s;z-index:var(--z-rail)}
[data-tip]:hover::after,[data-tip]:hover::before,
[data-tip]:focus-visible::after{opacity:1;transform:translateX(-50%) translateY(0)}
@media (prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:.01ms!important;transition-duration:.01ms!important}
}
/* FB-138 (ревью r71): мобильный пакет перенесён в КОНЕЦ стиля — в r71
   он стоял выше базовых правил .topbar/.content/.card/.kmap/…, и каскад
   молча отменял большинство свойств. Расширено: kmap — колонкой,
   коннекторы и hover-подсказки скрыты, заголовки карточек переносятся,
   топбар — с эллипсисом, кольца компактнее. */
@media(max-width:760px){
  .rail{transform:none;width:64px!important}
  body.rail-open .rail{width:var(--rail-wx)!important;box-shadow:var(--sh-2)}
  body.rail-open{overflow:hidden}
  body.rail-open .rail .lbl{opacity:1}
  body.rail-open .rail-subs{display:flex}
  .main{margin-left:64px!important}
  .topbar{padding:0 14px;gap:10px}
  .tb-model{display:none}
  .tb-name{flex:1 1 auto;min-width:0}
  .tb-title{font-size:15px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .content{padding:var(--sp-4) var(--sp-3) var(--sp-5);gap:var(--sp-3)}
  .content > .card{grid-column:1 / -1}
  .card{padding:14px}
  .badge{padding:5px 10px;font-size:var(--fs-caption)}
  .hero-actions{margin-left:0;width:100%}
  .hero-actions .qbtn{flex:0 1 auto;min-height:36px;padding:7px 13px;font-size:var(--fs-caption);gap:7px;box-shadow:none}
  .hero-actions .qbtn .ico{width:16px;height:16px}
  .card-h{flex-wrap:wrap;gap:8px}
  .card-note{display:none}
  [data-tip]::after,[data-tip]::before{display:none}
  .kmap{flex-direction:column;gap:8px}
  .kconn{display:none}
  .knode{padding:12px}
  .ring svg{width:88px;height:88px}
  .rings{display:grid;grid-template-columns:1fr 1fr;justify-items:center;gap:var(--sp-2)}
}

/* ═ FB-149/FB-151 (панель-77): сайдбар по решению владельца (panel_preview_r78): группы, подсветка, мобильный режим, палитра ═ */
:root{--kz-side:#ffffff;--kz-side-hover:#e8f0f8;--kz-side-active:#d9edf8;--kz-side-line:#c9d4e0}
html[data-theme="dark"]{--kz-side:#171f2c;--kz-side-hover:#202d40;--kz-side-active:#2d3e58;--kz-side-line:#344154}
.rail{width:208px!important;background:var(--kz-side);border-right:1px solid var(--kz-side-line)}
.rail:hover,body.rail-pin .rail{width:208px!important;box-shadow:none}
.rail-head{height:52px;padding:0 18px}
.rail .lbl{opacity:1!important}
.rail-tip{display:none!important}
.nav-head{font-size:11px;font-weight:700;color:var(--primary);text-transform:uppercase;
  letter-spacing:.3px;padding:12px 21px 6px}
.rail-item{height:38px;min-height:38px;padding:0 18px;border-left:3px solid transparent;
  border-radius:0;gap:11px}
.rail-item .ico{width:17px;height:17px;color:#9fb1c7}
.rail-item:hover{background:var(--kz-side-hover);color:var(--text)}
.rail-item[aria-current="page"]{background:var(--kz-side-active);border-left-color:var(--primary);color:var(--text);font-weight:700}
.rail-item[aria-current="page"]::before{display:none}
.rail-subs{display:flex!important;margin:0;padding:2px 8px 9px 34px}
.rail-subs a{height:auto;min-height:29px;padding:5px 10px;border-radius:3px;
  border-left:2px solid transparent;font-size:13.5px}
.rail-subs a:hover{background:var(--kz-side-hover);color:var(--text)}
.rail-subs a[aria-current="page"]{background:var(--kz-side-active);border-left-color:var(--primary);color:var(--text);font-weight:600}
.rail-pin-btn{display:none!important}
.rail-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:calc(var(--z-rail) - 1);
  opacity:0;pointer-events:none;transition:opacity .15s}
body.rail-open .rail-backdrop{opacity:1;pointer-events:auto}
.topbar{height:48px}
.tb-title{color:var(--primary);font-size:19px;font-weight:700;letter-spacing:.4px}
.main{margin-left:208px!important}
@media(max-width:700px){
  .rail{transform:translateX(-100%);width:260px!important;overflow-y:auto}
  body.rail-open .rail{transform:none;box-shadow:var(--sh-2)}
  body.rail-open{overflow:hidden}
  .main{margin-left:0!important}
  body.rail-open .rail{width:260px!important}
}
/* ═ FB-151 (панель-77): выравнивание и читаемость левого меню ═ */
.nav-head{font-size:12px;padding:13px 21px 6px}
.rail-item{font-size:15px}
.rail-item .lbl{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.rail-subs{padding:2px 8px 9px 26px}
.rail-subs a{font-size:14px;padding:5px 21px}
/* ═══ FB-190..FB-203 (панель-r83, решение владельца): утверждённый шаблон
   panel_preview_r83.html — логотип/вордмарк, аббревиатуры, шрифты ═══ */
.logo{background:none;box-shadow:none;border-radius:0}
.logo .logo-svg,.hero .emoji .logo-svg{width:100%;height:100%;display:block}
.hero .emoji{background:none}
.wm b{color:var(--primary);font-weight:800}
body{font-variant-numeric:tabular-nums;-webkit-font-smoothing:antialiased}
/* FB-191 (панель-r83): кнопка «Скрыть меню» возвращена — рельс
   сворачивается до значков, подпункты протоколов — аббревиатуры
   HS/VL/TR/SS/TO (крупный полужирный шрифт); вордмарк рельса видим
   всегда в развёрнутом виде (ранее opacity:0 от hover-схемы r77) */
.rail-pin-btn{display:flex!important}
.rail-title{opacity:1!important}
@media(min-width:701px){
.rail{transition:width .2s var(--ease)}
body.rail-ico .rail{width:76px!important}
body.rail-ico .main{margin-left:76px!important}
body.rail-ico .rail-head{padding:0;justify-content:center}
body.rail-ico .rail .lbl,body.rail-ico .rail-title{display:none}
body.rail-ico .rail-item{justify-content:center;padding:0;
  border-left-color:transparent;border-right:3px solid transparent}
body.rail-ico .rail-item[aria-current="page"]{border-right-color:var(--primary)}
body.rail-ico .rail-pin-btn{justify-content:center;padding:10px 0}
body.rail-ico .rail-pin-btn .lbl{display:none}
body.rail-ico .rail-pin-btn .ico{transform:rotate(180deg)}
body.rail-ico .rail-subs{display:flex!important;flex-direction:row;flex-wrap:wrap;
  justify-content:center;gap:3px;margin:0;padding:2px 8px 8px}
body.rail-ico .rail-subs a{font-size:0;min-height:0;height:auto;padding:7px 8px;
  border-radius:8px;border-left-width:0}
body.rail-ico .rail-subs a::before{content:attr(data-abbr);font-size:14px;font-weight:700;letter-spacing:.02em}
}</style>
</head>
<body>
<svg style="display:none" aria-hidden="true">
    <!-- FB-190 (панель-r83): новый символ проекта — щит + Wi-Fi (MD3) -->
  <symbol id="i-logo" viewBox="0 0 24 24">
    <defs><linearGradient id="lgz" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#00a8e8"/><stop offset="1" stop-color="#0072a6"/>
    </linearGradient></defs>
    <path d="M12 1.7l8.3 3.7v5.7c0 5.3-3.5 9-8.3 10.5C7.2 20.1 3.7 16.4 3.7 11.1V5.4L12 1.7z" fill="url(#lgz)"/>
    <path d="M7.3 7.7a7.6 7.6 0 0 1 9.4 0" stroke="#fff" stroke-width="1.7" fill="none" stroke-linecap="round"/>
    <path d="M9.5 10.4a4.3 4.3 0 0 1 5 0" stroke="#fff" stroke-width="1.7" fill="none" stroke-linecap="round"/>
    <circle cx="12" cy="13.5" r="1.55" fill="#fff"/>
  </symbol>
  <symbol id="i-dash" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></symbol>
  <symbol id="i-apps" viewBox="0 0 24 24"><rect x="3" y="3" width="8" height="8" rx="2"/><rect x="13" y="3" width="8" height="8" rx="2"/><rect x="3" y="13" width="8" height="8" rx="2"/><path d="M17 13v8M13 17h8"/></symbol>
  <symbol id="i-shield" viewBox="0 0 24 24"><path d="M12 2l8 4v6c0 5-3.5 8.5-8 10-4.5-1.5-8-5-8-10V6l8-4z"/><path d="M9 12l2 2 4-4"/></symbol>
  <symbol id="i-cpu" viewBox="0 0 24 24"><rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9.5" y="9.5" width="5" height="5" rx="1"/><path d="M9 2v3m6-3v3M9 19v3m6-3v3M2 9h3m-3 6h3M19 9h3m-3 6h3"/></symbol>
  <symbol id="i-gear" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.08a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.08a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.08a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></symbol>
  <symbol id="i-bell" viewBox="0 0 24 24"><path d="M6 9a6 6 0 1 1 12 0c0 5 2 6 2 6H4s2-1 2-6"/><path d="M10.3 20a2 2 0 0 0 3.4 0"/></symbol>
  <symbol id="i-right" viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></symbol>
  <symbol id="i-router" viewBox="0 0 24 24"><rect x="3" y="13" width="18" height="8" rx="2"/><path d="M7 17h.01M11 17h.01"/><path d="M8 9.5a7 7 0 0 1 8 0M6.5 6a10 10 0 0 1 11 0" opacity=".9"/></symbol>
  <symbol id="i-globe" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></symbol>
  <symbol id="i-devices" viewBox="0 0 24 24"><rect x="2" y="6" width="13" height="10" rx="2"/><path d="M2 12h13"/><rect x="17" y="9" width="5" height="11" rx="1.5"/><path d="M5 19h8"/></symbol>
  <symbol id="i-host" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M2 20h20"/><path d="M8 20v-4m8 4v-4"/></symbol>
  <symbol id="i-down" viewBox="0 0 24 24"><path d="M12 4v13m0 0l-5-5m5 5l5-5M4 21h16"/></symbol>
  <symbol id="i-up" viewBox="0 0 24 24"><path d="M12 20V7m0 0l-5 5m5-5l5 5M4 3h16"/></symbol>
  <symbol id="i-ok" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M8.5 12.5l2.5 2.5 4.5-5"/></symbol>
  <symbol id="i-warn" viewBox="0 0 24 24"><path d="M10.3 3.9L2.8 17a2 2 0 0 0 1.7 3h15a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></symbol>
  <symbol id="i-info" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></symbol>
  <symbol id="i-sun" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4l1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></symbol>
<symbol id="i-search" viewBox="0 0 24 24"><circle cx="10" cy="10" r="6"/><path d="m21 21-6-6"/></symbol>
<symbol id="i-bot" viewBox="0 0 24 24"><rect x="4.4" y="8.4" width="15.2" height="11.4" rx="3.6"/><circle cx="9.4" cy="13.8" r="1.25" fill="currentColor" stroke="none"/><circle cx="14.6" cy="13.8" r="1.25" fill="currentColor" stroke="none"/><path d="M9.7 17h4.6M12 8.4V5.6"/><circle cx="12" cy="4.5" r="1.15" fill="currentColor" stroke="none"/><path d="M2.4 12.8v3M21.6 12.8v3"/></symbol>
  <symbol id="i-moon" viewBox="0 0 24 24"><path d="M21 12.8A8.5 8.5 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></symbol>
  <symbol id="i-zap" viewBox="0 0 24 24"><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></symbol>
  <symbol id="i-refresh" viewBox="0 0 24 24"><path d="M20 11A8 8 0 0 0 6.3 6.3L3 9m1-6v6h6M4 13a8 8 0 0 0 13.7 4.7L21 15m-1 6v-6h-6"/></symbol>
</svg>

<aside class="rail" aria-label="Основная навигация">
  <div class="rail-head">
    <span class="logo"><svg class="logo-svg" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-logo"/></svg></span>
    <span class="rail-title wm">Keen<b>ZOO</b></span>
    
  </div>
  <nav>
    <div class="nav-head">Статус</div>
    <a class="rail-item" href="/" aria-current="page"><svg class="ico" viewBox="0 0 24 24"><use href="#i-dash"/></svg><span class="lbl">Обзор</span></a>
    <div class="nav-head">Протоколы</div>
    <div class="rail-subs">
      <a href="/?tab=hy" data-abbr="HS">Hysteria</a>
      <a href="/?tab=vl" data-abbr="VL">VLESS</a>
      <a href="/?tab=tr" data-abbr="TR">Trojan</a>
      <a href="/?tab=ss" data-abbr="SS">Shadowsocks</a>
      <a href="/?tab=to" data-abbr="TO">Tor</a>
      <a href="/?tab=za" data-abbr="NZ">NFQWS2</a>
    </div>
    <div class="nav-head">Настройки</div>
    <a class="rail-item" href="/?tab=dns"><svg class="ico" viewBox="0 0 24 24"><use href="#i-shield"/></svg><span class="lbl">DNS</span></a>
    <a class="rail-item" href="/?tab=upd"><svg class="ico" viewBox="0 0 24 24"><use href="#i-cpu"/></svg><span class="lbl">Обновления</span></a>
    <a class="rail-item" href="/?tab=cfg"><svg class="ico" viewBox="0 0 24 24"><use href="#i-gear"/></svg><span class="lbl">Конфигурации</span></a>
    <a class="rail-item" href="/?tab=lk"><svg class="ico" viewBox="0 0 24 24"><use href="#i-search"/></svg><span class="lbl">Поиск</span></a>
    <a class="rail-item" href="/?tab=bt"><svg class="ico" viewBox="0 0 24 24"><use href="#i-bot"/></svg><span class="lbl">Telegram-бот</span></a>
  </nav>
  <div class="rail-foot">
    <button class="rail-pin-btn" id="pinBtn" type="button"><svg class="ico ico-s" viewBox="0 0 24 24"><use href="#i-right"/></svg><span class="lbl">Скрыть меню</span></button>
    <div class="rail-ver">
      <button class="theme-btn" id="themeBtn" type="button" aria-label="Переключить тему"><svg class="ico ico-s" viewBox="0 0 24 24"><use href="#i-moon"/></svg></button>
    </div>
  </div>
</aside>
<div class="rail-backdrop" id="railBd"></div>


<div class="main" id="dashRoot">
  <header class="topbar">
    <button class="menu-btn" id="menuBtn" type="button" aria-label="Открыть меню"><svg class="ico" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg></button>
    <div class="tb-name">
      <div class="tb-crumb" id="tbHost" style="display:none">Keenetic</div>
      <div class="tb-title">Keen<b>ZOO</b></div>
    </div>
    <div class="tb-right">
      <div class="tb-model">Работает <b class="uptime" id="uptimeV">—</b><br><span id="tbArch"></span></div>
      <span class="badge" id="wanBadge"><span class="pulse"></span><span id="wanTxt">…</span></span>
      <div class="bell-wrap">
        <button class="bell" id="bellBtn" type="button" aria-label="События" aria-expanded="false">
          <svg class="ico" viewBox="0 0 24 24"><use href="#i-bell"/></svg>
        </button>
        <div class="evmenu" id="evMenu" role="menu" aria-label="События"></div>
      </div>
    </div>
  </header>

  <main class="content">
    <section class="card hero" aria-label="Сводка состояния">
      <span class="emoji" id="heroIco"><svg class="logo-svg" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-logo"/></svg></span>
      <div>
        <h1 id="heroTitle">Загрузка…</h1>
        <p id="heroSub">Получаем состояние роутера и проекта</p>
      </div>
      <div class="hero-actions">
        <button class="qbtn" id="updBtn" type="button" data-tip="Запустить обновление списков обхода сейчас, не дожидаясь расписания 06:00. Обычно занимает 1–2 минуты; интерфейс продолжит работать."><svg class="ico ico-s" viewBox="0 0 24 24"><use href="#i-refresh"/></svg>Обновить списки</button>
        <a class="qbtn" href="/?tab=dns" data-tip="Вкладка DNS: состояние локальных DoT/DoH-серверов, проверка подмены, закреплённые адреса."><svg class="ico ico-s" viewBox="0 0 24 24"><use href="#i-shield"/></svg>Диагностика DNS</a>
      </div>
    </section>

<section class="card c-span8" aria-labelledby="h-map">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-globe"/></svg>
        <h2 id="h-map">Соединение</h2>
        <span class="card-note">наведите на элемент для подробностей</span>
      </div>
      <div class="kmap">
        <div class="knode ok" id="mapWan" data-tip="Внешний интерфейс и маршрут по умолчанию. Если маршрута нет — проверьте кабель или настройки провайдера.">
          <div class="top"><span class="tile"><svg class="ico" viewBox="0 0 24 24"><use href="#i-globe"/></svg></span><b>Интернет</b><span class="st" id="mapWanSt">…</span></div>
          <p id="mapWanSub">—</p>
        </div>
        <div class="kconn"><span class="pipe"></span><small id="mapWanLnk">WAN</small></div>
        <div class="knode pri" data-tip="Этот роутер: имя хоста и архитектура из системы, время непрерывной работы — из /proc/uptime.">
          <div class="top"><span class="tile"><svg class="ico" viewBox="0 0 24 24"><use href="#i-router"/></svg></span><b>Роутер</b><span class="st">норма</span></div>
          <p id="mapRouterSub">—</p>
        </div>
        <div class="kconn"><span class="pipe"></span><small>LAN · Wi-Fi</small></div>
        <div class="knode" data-tip="Устройства, замеченные в ARP локальной сети. Имена берутся из lease-файлов dnsmasq, если выдавались.">
          <div class="top"><span class="tile"><svg class="ico" viewBox="0 0 24 24"><use href="#i-devices"/></svg></span><b>Устройства</b><span class="st off" id="mapDevSt">—</span></div>
          <p id="mapDevSub">—</p>
        </div>
      </div>
    </section>

    <section class="card c-span4" aria-labelledby="h-feed">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-info"/></svg>
        <h2 id="h-feed">Состояние</h2>
      </div>
      <div class="feed" id="feed"></div>
    </section>    <section class="card c-span8" aria-labelledby="h-traffic">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-zap"/></svg>
        <!-- FB-162 (аудит-45, R77-07): показатель — счётчики
             интерфейса маршрута по умолчанию; при br-аплинке сюда
             входит и LAN-трафик (мосты из счётчиков не исключаются). -->
        <h2 id="h-traffic">Скорость: счётчики интерфейса</h2>
        <span class="card-note">живые данные · пауза, если вкладка скрыта</span>
      </div>
      <div class="tr-head">
        <div class="tr-val dl"><span class="num" id="dlBig">—</span><span class="cap"><i></i>загрузка</span></div>
        <div class="tr-val ul"><span class="num" id="ulBig">—</span><span class="cap"><i></i>отдача</span></div>
        <span class="tr-note">последние ~3 минуты<br><span id="rateIface" style="color:var(--faint)"></span></span>
      </div>
      <canvas class="chart" id="chart" height="185" role="img" aria-label="График скорости загрузки и отдачи"></canvas>
    </section>

    <section class="card c-span4" aria-labelledby="h-sys">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-cpu"/></svg>
        <h2 id="h-sys">Нагрузка системы</h2>
      </div>
      <div class="rings">
        <div class="ring">
          <svg viewBox="0 0 100 100" aria-hidden="true"><circle class="track" cx="50" cy="50" r="42"/><circle class="bar" id="cpuBar" cx="50" cy="50" r="42" stroke="var(--primary)" stroke-dasharray="263.9" stroke-dashoffset="263.9"/></svg>
          <div class="pct" id="cpuPct">—</div>
          <div class="cap">Процессор<br><small>все ядра</small></div>
        </div>
        <div class="ring">
          <svg viewBox="0 0 100 100" aria-hidden="true"><circle class="track" cx="50" cy="50" r="42"/><circle class="bar" id="ramBar" cx="50" cy="50" r="42" stroke="var(--ok)" stroke-dasharray="263.9" stroke-dashoffset="263.9"/></svg>
          <div class="pct" id="ramPct">—</div>
          <div class="cap">Память<br><small id="ramSub">—</small></div>
        </div>
      </div>
    </section>

    <section class="card c-span7" aria-labelledby="h-lists">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-apps"/></svg>
        <h2 id="h-lists">Обход блокировок</h2>
        <span class="card-note">домены, IP и подсети в списках</span>
      </div>
      <!-- FB-193 (панель-r83): названия протоколов кликабельны (2 в ряд),
           ссылки «открыть →» убраны -->
      <div id="listRows" class="pgrid">
        <div class="pgw"><span class="ldot" id="dot-ss"></span><a class="pg-name" href="/?tab=ss">Shadowsocks</a><span class="cnt" id="cnt-ss">—</span></div>
        <div class="pgw"><span class="ldot" id="dot-tr"></span><a class="pg-name" href="/?tab=tr">Trojan</a><span class="cnt" id="cnt-tr">—</span></div>
        <div class="pgw"><span class="ldot" id="dot-vl"></span><a class="pg-name" href="/?tab=vl">VLESS</a><span class="cnt" id="cnt-vl">—</span></div>
        <div class="pgw"><span class="ldot" id="dot-to"></span><a class="pg-name" href="/?tab=to">Tor</a><span class="cnt" id="cnt-to">—</span></div>
        <div class="pgw"><span class="ldot" id="dot-hy"></span><a class="pg-name" href="/?tab=hy">Hysteria</a><span class="cnt" id="cnt-hy">—</span></div>
        <div class="pgw"><span class="ldot" id="dot-za"></span><a class="pg-name" href="/?tab=za">NFQWS2</a><span class="cnt" id="cnt-za">—</span></div>
        <div class="pgw"><span class="ldot on"></span><a class="pg-name" href="/?tab=bt">Telegram-бот</a><span class="cnt" id="cnt-bt">—</span></div>
      </div>
    </section>

    <section class="card c-span5" aria-labelledby="h-dns">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-shield"/></svg>
        <h2 id="h-dns"><a class="tlink" href="/?tab=dns">DNS и туннели</a></h2>
        <span class="card-note">автопроверка — раз в 2 ч (cron)</span>
      </div>
      <div class="subh">Локальные DNS-серверы</div>
      <div class="dns-dots" id="dnsDots"><span class="pdot"><i></i>проверяем…</span></div>
      <div class="upd-line"><span class="st" id="dnsSum">—</span></div>
      <div class="subh">Сервисы обхода</div>
      <div class="chips" id="svcChips"></div>
    </section>

    <section class="card c-span7" aria-labelledby="h-dev">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-devices"/></svg>
        <h2 id="h-dev">Устройства</h2>
        <span class="card-note" id="devNote">в локальной сети</span>
      </div>
      <div id="devList"></div>
    </section>

    <section class="card c-span5" aria-labelledby="h-upd">
      <div class="card-h">
        <svg class="ico" viewBox="0 0 24 24"><use href="#i-refresh"/></svg>
        <h2 id="h-upd">Обновления</h2>
      </div>
      <div class="upd-line"><span class="st" id="updState">—</span><span class="ago" id="updAgo"></span></div>
      <div class="upd-sched">Списки: ежедневно в 06:00, полная пересборка — среда 03:00.<br>Бинарники и пакеты: проверка по воскресеньям.</div>
      <div style="display:flex;gap:10px;margin-top:14px;flex-wrap:wrap">
        <button class="qbtn" id="updBtn2" type="button" data-tip="То же действие, что и кнопка в шапке: запустить обновление списков сейчас."><svg class="ico ico-s" viewBox="0 0 24 24"><use href="#i-refresh"/></svg>Обновить сейчас</button>
        <a class="qbtn" href="/?tab=upd">Протоколы и версии →</a>
      </div>
    </section>
  </main>
</div>

<script>
'use strict';
/* Дашборд (этап 1): лёгкий поллинг /api/dashboard (2 с активная вкладка,
   15 с фоновая), медленный полл /api/dns-status (60 с, первый через 1.5 с).
   Все обновления — textContent/порождение минимальных узлов; график —
   canvas, одна отрисовка на тик. */
(function(){
  var CSRF=(document.querySelector('meta[name="kz-csrf"]')||{}).content||'';
  var $=function(id){return document.getElementById(id)};
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function plural(n,f){n=Math.abs(n);var m10=n%10,m100=n%100;
    if(m10===1&&m100!==11)return f[0];
    if(m10>=2&&m10<=4&&(m100<10||m100>=20))return f[1];
    return f[2]}
  function fmtUp(s){if(s==null)return '—';
    var d=Math.floor(s/86400),h=Math.floor(s%86400/3600),m=Math.floor(s%3600/60);
    if(d>0)return d+' '+plural(d,['день','дня','дней'])+' '+h+' ч';
    if(h>0)return h+' '+plural(h,['час','часа','часов'])+' '+m+' мин';
    return m+' '+plural(m,['минуту','минуты','минут'])}
  function fmtAgo(ts){if(!ts)return '';
    var s=Math.max(0,Math.floor(Date.now()/1000-ts));
    if(s<60)return 'только что';
    if(s<3600)return Math.floor(s/60)+' мин назад';
    if(s<86400)return Math.floor(s/3600)+' ч назад';
    return Math.floor(s/86400)+' дн назад'}
  function fmtMbps(v){return v==null?'—':(v/1e6).toFixed(2).replace('.',',')+'<small>Мбит/с</small>'}
  function fmtMiB(k){return (k/1024).toFixed(0)+' МБ'}

  /* тема — общий ключ с остальной панелью (kzp-theme) */
  var themeBtn=$('themeBtn');
  function setTheme(t){
    document.documentElement.setAttribute('data-theme',t);
    themeBtn.firstElementChild.firstElementChild.setAttribute('href',t==='dark'?'#i-sun':'#i-moon');
    try{localStorage.setItem('kzp-theme',t)}catch(e){}
    drawChart();
  }
  try{var saved=localStorage.getItem('kzp-theme');if(saved)setTheme(saved)}catch(e){}
  try{window.addEventListener('storage',function(e){if(e.key==='kzp-theme'&&(e.newValue==='dark'||e.newValue==='light'))setTheme(e.newValue)})}catch(e){}
  themeBtn.addEventListener('click',function(){
    setTheme(document.documentElement.getAttribute('data-theme')==='dark'?'light':'dark');
  });
  /* FB-191 (панель-r83): «Скрыть меню» — сворачивание рельса до значков;
     FB-190: KeenZOO в шапке появляется только в свёрнутом виде */
  $('pinBtn').addEventListener('click',function(){
    var ico=document.body.classList.toggle('rail-ico');
    this.setAttribute('title',ico?'Показать меню':'Скрыть меню')});
  /* FB-149 (панель-77): ☰ — выезжающее меню на мобильном; клик по пункту/вне — закрыть */
  $('menuBtn').addEventListener('click',function(e){e.stopPropagation();
    document.body.classList.toggle('rail-open')});
  var kzBd=$('railBd');if(kzBd)kzBd.addEventListener('click',function(){
    document.body.classList.remove('rail-open')});
  Array.prototype.forEach.call(document.querySelectorAll('.rail a'),function(a){
    a.addEventListener('click',function(){document.body.classList.remove('rail-open')})});
  $('railBd').addEventListener('click',function(){document.body.classList.remove('rail-open')});
  var bell=$('bellBtn'),evMenu=$('evMenu');
  bell.addEventListener('click',function(e){e.stopPropagation();
    var open=evMenu.classList.toggle('open');bell.setAttribute('aria-expanded',open)});
  document.addEventListener('click',function(e){
    if(!evMenu.contains(e.target)&&e.target!==bell){evMenu.classList.remove('open');bell.setAttribute('aria-expanded','false')}});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'){evMenu.classList.remove('open');bell.setAttribute('aria-expanded','false')}});

  /* график */
  var cv=$('chart'),ctx=cv.getContext('2d'),N=90,dBuf=[],uBuf=[],i;
  for(i=0;i<N;i++){dBuf.push(null);uBuf.push(null)}
  function css(v){return getComputedStyle(document.documentElement).getPropertyValue(v).trim()}
  function drawChart(){
    var w=cv.clientWidth,h=185,dpr=window.devicePixelRatio||1;
    if(cv.width!==Math.round(w*dpr)){cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr)}
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
    var vals=[],j;for(j=0;j<N;j++){if(dBuf[j]!=null)vals.push(dBuf[j]);if(uBuf[j]!=null)vals.push(uBuf[j])}
    var mx=vals.length?Math.max(1,Math.max.apply(null,vals))*1.15:1;
    var pad=6,bw=(w-14)/(N-1);
    ctx.strokeStyle=css('--outline')||'#d7dee7';ctx.lineWidth=1;
    ctx.fillStyle=css('--faint')||'#8b95a5';ctx.font='10px '+css('--font');
    for(var g=0;g<=3;g++){
      var y=pad+(h-2*pad-16)*g/3+6;
      ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();
      ctx.fillText((mx*(1-g/3)/1e6).toFixed(1)+' Мбит/с',4,y-3);
    }
    function series(buf,color,fill){
      ctx.beginPath();var started=false;
      for(var k=0;k<N;k++){
        if(buf[k]==null){started=false;continue}
        var x=7+k*bw,y=h-16-(buf[k]/mx)*(h-2*pad-16);
        if(!started){ctx.moveTo(x,y);started=true}else ctx.lineTo(x,y);
      }
      ctx.strokeStyle=color;ctx.lineWidth=2;ctx.lineJoin='round';ctx.stroke();
      if(fill){
        ctx.lineTo(7+(N-1)*bw,h-10);ctx.lineTo(7,h-10);ctx.closePath();
        var gr=ctx.createLinearGradient(0,0,0,h);
        gr.addColorStop(0,color+'30');gr.addColorStop(1,color+'03');
        ctx.fillStyle=gr;ctx.fill();
      }
    }
    series(uBuf,css('--ok')||'#0b9c66',false);
    series(dBuf,css('--primary')||'#0061e6',true);
  }

  /* данные */
  var S={d:null,dns:null,devSig:'',feedSig:'',chartIdx:0};
  var LISTS=[['ss','Shadowsocks'],['tr','Trojan'],['vl','VLESS'],['to','Tor'],['hy','Hysteria']];
  function feedItems(){
    var d=S.d,it=[];
    if(!d)return it;
    if(d.update&&d.update.status==='running'&&d.update.stale)
      it.push(['warn','i-warn','Обновление зависло','Начато '+fmtAgo(d.update.ts)+' — можно запустить повторно: если старый процесс ещё жив, панель сообщит и не создаст дубль']);
    else if(d.update&&d.update.status==='running')
      it.push(['info','i-refresh','Обновление списков идёт','Занимает 1–2 минуты, интерфейс работает как обычно']);
    else if(d.update&&d.update.status==='error')
      it.push(['warn','i-warn','Последнее обновление не завершилось','Подробности — на вкладке «Система»; следующая попытка в 06:00']);
    else if(d.update&&d.update.status==='done')
      it.push(['ok','i-ok','Списки обхода обновлены',fmtAgo(d.update.ts)+', всё успешно']);
    /* FB-163 (аудит-45, R77-08): reachability не проверяется —
       статус отражает лишь наличие маршрута по умолчанию. */
    if(d.wan_up)it.push(['ok','i-globe','Маршрут по умолчанию найден','Интерфейс маршрута: '+esc(d.rate.iface||'WAN')]);
    /* FB-174 (аудит-46, A-R79-09): проверяется только IPv4-маршрут;
       IPv6-канал без IPv4 этой проверкой не виден. */
    else it.push(['err','i-warn','Нет IPv4-маршрута по умолчанию','Проверьте кабель/VLAN провайдера или поднимите туннель']);
    if(S.dns){
      var tot=S.dns.tot,live=S.dns.live;
      if(live===tot)it.push(['ok','i-shield','DNS-цепочка в порядке','Все '+tot+' локальных серверов отвечают']);
      else if(live>0)it.push(['warn','i-shield','DNS: живы '+live+' из '+tot,'Резервные серверы не отвечают — на работу это, как правило, не влияет']);
      else it.push(['err','i-shield','Локальные DNS не отвечают','Проверьте сервисы DoT/DoH на вкладке «DNS»']);
    }
    var svcOn=[],svcAll=[];
    for(var k=0;k<LISTS.length;k++){var key=LISTS[k][0];
      svcAll.push(LISTS[k][1]);
      if(d.services&&d.services[key])svcOn.push(LISTS[k][1])}
    if(svcOn.length)it.push(['ok','i-zap','Обход активен: '+svcOn.join(', '),'Всего сервисов: '+svcAll.length+'; отключённые не мешают работе остальных']);
    else it.push(['info','i-zap','Сервисы обхода отключены','Включить можно на вкладке «Приложения»']);
    var ramPct=d.ram?Math.round(d.ram.used_kib*100/d.ram.total_kib):null;
    if(ramPct!=null&&ramPct>85)it.push(['warn','i-cpu','Память занята более 85%'+(d.ram.approx?' (оценка ≈)':''),'Возможно, стоит перезагрузить роутер в удобное время']);
    return it;
  }
  function renderFeed(){
    var it=feedItems(),sig=it.map(function(x){return x[1]+x[2]}).join('|');
    if(sig===S.feedSig)return;S.feedSig=sig;
    $('feed').innerHTML=it.map(function(x){
      return '<div class="fitem '+x[0]+'"><span class="ico-wrap"><svg class="ico" viewBox="0 0 24 24"><use href="#'+x[1]+'"/></svg></span><div><h4>'+x[2]+'</h4><p>'+x[3]+'</p></div></div>'
    }).join('');
    $('evMenu').innerHTML=it.map(function(x){
      return '<div class="ev"><svg class="ico" style="color:var(--'+(x[0]==='ok'?'ok':x[0]==='warn'?'warn':x[0]==='err'?'err':'primary')+')" viewBox="0 0 24 24"><use href="#'+x[1]+'"/></svg><div><h4>'+x[2]+'</h4><p>'+x[3]+'</p></div></div>'
    }).join('');
  }
  function render(d){
    S.d=d=d||{};
    $('uptimeV').textContent=fmtUp(d.uptime);
    $('tbHost').textContent=d.host?('Keenetic · '+d.host):'Keenetic';
    $('tbArch').textContent=d.arch||'';
    var wb=$('wanBadge');
    if(d.wan_up){wb.className='badge';$('wanTxt').textContent='Подключено'}
    else{wb.className='badge down';$('wanTxt').textContent='Нет связи'}
    /* герой */
    var running=d.update&&d.update.status==='running'&&!d.update.stale;
    var staleUpd=d.update&&d.update.status==='running'&&!!d.update.stale;
    if(running){$('heroTitle').textContent='Идёт обновление списков…';
      $('heroSub').textContent='Обычно занимает 1–2 минуты. Можно продолжать пользоваться панелью.'}
    else if(staleUpd){$('heroTitle').textContent='Обновление зависло';
      $('heroSub').textContent='Начато '+fmtAgo(d.update.ts)+' и не отвечает. Можно запустить повторно: если старый процесс ещё жив, панель сообщит и не создаст дубль.'}
    else if(!d.wan_up){$('heroTitle').textContent='Нет соединения с интернетом';
      $('heroSub').textContent='Маршрут по умолчанию не найден. Туннели и локальная сеть продолжают работать.'}
    else{var total=0,kk;for(kk in (d.lists||{})){if(d.lists[kk]!=null)total+=d.lists[kk]}
      $('heroTitle').textContent='Всё работает нормально';
      $('heroSub').textContent='Маршрут по умолчанию найден, в сети '+(d.devices?d.devices.count:0)+' '+plural(d.devices?d.devices.count:0,['устройство','устройства','устройств'])+', в списках обхода — '+total+' '+plural(total,['запись','записи','записей'])+'.'}
    $('updBtn').disabled=!!running;$('updBtn2').disabled=!!running;
    /* карта */
    var mw=$('mapWan');
    if(d.wan_up){mw.className='knode ok';$('mapWanSt').textContent='онлайн';$('mapWanSt').className='st';
      $('mapWanSub').innerHTML='маршрут по умолчанию: '+esc(d.rate&&d.rate.iface||'WAN')+'<br>внешний канал провайдера'}
    else{mw.className='knode err';$('mapWanSt').textContent='нет';$('mapWanSt').className='st';
      $('mapWanSub').textContent='маршрут по умолчанию не найден'}
    $('mapRouterSub').innerHTML=esc(d.host||'роутер')+' · '+esc(d.arch||'')+'<br>без перезагрузки: '+fmtUp(d.uptime);
    $('mapDevSt').textContent=d.devices?d.devices.count:'—';
    $('mapDevSub').textContent=d.devices?('замечено в локальной сети'+(d.devices.count?'':' (пусто)')):'—';
    /* кольца */
    var CIRC=263.9;
    var cp=d.cpu_pct;
    if(cp!=null){$('cpuBar').setAttribute('stroke-dashoffset',CIRC*(1-cp/100));$('cpuPct').textContent=Math.round(cp)+'%'}
    else{$('cpuPct').textContent='—'}
    if(d.ram){var rp=Math.min(100,d.ram.used_kib*100/d.ram.total_kib);
      $('ramBar').setAttribute('stroke-dashoffset',CIRC*(1-rp/100));
      /* FB-161 (аудит-45, R77-06): ≈ — оценка на ядрах без
         MemAvailable, не точное значение (FB-171/аудит-46:
         free-style MemFree+Buffers+Cached). */
      $('ramPct').textContent=(d.ram.approx?'≈':'')+Math.round(rp)+'%';
      $('ramSub').textContent=(d.ram.approx?'≈оценка: ':'')+fmtMiB(d.ram.used_kib)+' из '+fmtMiB(d.ram.total_kib)}
    /* FB-171 (аудит-46, A-R79-05): ram=null (meminfo недоступен) —
       прежде виджет навсегда сохранял последние цифры. Сброс в «—». */
    else{$('ramPct').textContent='—';$('ramSub').textContent='нет данных';$('ramBar').setAttribute('stroke-dashoffset',CIRC)}
    /* график */
    dBuf.push(d.rate&&d.rate.down!=null?d.rate.down:null);dBuf.shift();
    uBuf.push(d.rate&&d.rate.up!=null?d.rate.up:null);uBuf.shift();
    $('dlBig').innerHTML=fmtMbps(d.rate&&d.rate.down);
    $('ulBig').innerHTML=fmtMbps(d.rate&&d.rate.up);
    $('rateIface').textContent=d.rate&&d.rate.iface?('счётчики интерфейса '+d.rate.iface):'';
    drawChart();
    /* списки */
    var lk,lm={'ss':'ss','tr':'tr','vl':'vl','to':'to','hy':'hy','za':'za','bt':'bt'};
    for(lk in lm){
      var el=$('cnt-'+lk);if(!el)continue;
      var v=d.lists?d.lists[lk]:null;
      el.textContent=v==null?'нет данных':(v+' '+plural(v,['запись','записи','записей']));
      if(lk!=='bt'){var dt=$('dot-'+lk);
        dt.className='ldot'+(d.services&&d.services[lk]?' on':'')}
    }
    /* сервисы-чипы */
    $('svcChips').innerHTML=LISTS.map(function(x){
      var on=S.d.services&&S.d.services[x[0]];
      return '<span class="chip'+(on?' on':'')+'"><i></i>'+x[1]+'</span>'}).join('');
    /* устройства */
    if(d.devices){
      var sig=(d.devices.count+'|'+d.devices.top.map(function(x){return x.ip}).join(','));
      if(sig!==S.devSig){S.devSig=sig;
        $('devNote').textContent='показаны первые '+d.devices.top.length+' из '+d.devices.count;
        $('devList').innerHTML=d.devices.top.length?d.devices.top.map(function(x){
          var nm=x.name||'Без имени';
          return '<div class="dev" data-tip="IP: '+esc(x.ip)+' · MAC: '+esc(x.mac)+''+(x.name?' · имя из lease-файла dnsmasq':'')+'"><span class="ico-wrap"><svg class="ico" viewBox="0 0 24 24"><use href="#i-host"/></svg></span><div><div class="name">'+esc(nm)+'</div><div class="sub">'+esc(x.ip)+'</div></div><span class="ifchip">'+esc(x.iface)+'</span></div>'
        }).join(''):'<p style="font-size:var(--fs-s);color:var(--muted);padding:8px 4px">Устройств не найдено — ARP-таблица пуста.</p>'}
    }
    /* обновления */
    var u=d.update||{};
    if(u.status==='running'&&u.stale){$('updState').textContent='Обновление зависло';$('updAgo').textContent=fmtAgo(u.ts)}
    else if(u.status==='running'){$('updState').textContent='Обновление идёт';$('updAgo').textContent=''}
    else if(u.status==='done'){$('updState').textContent='Списки обновлены';$('updAgo').textContent=fmtAgo(u.ts)}
    else if(u.status==='error'){$('updState').textContent='Ошибка обновления';$('updAgo').textContent=fmtAgo(u.ts)}
    else{$('updState').textContent='Ещё не запускалось';$('updAgo').textContent=''}
    renderFeed();
  }
  /* DNS: медленный полл */
  function pollDns(){
    fetch('/api/dns-status',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){
      /* r94 (аудит r93, KZ93-01): busy-503/пустой ответ не затирает
         последнее корректное состояние (прежде tot=0 давало «все 0
         серверов живы» и стирало точки); следующий полл обновит */
      if(!j||j.status==='busy'||!j.dot&&!j.doh){
        $('dnsSum').textContent='DNS: проверка занята, повтор…';
        renderFeed();return}
      var tot=0,live=0,parts=[];
      ['dot','doh'].forEach(function(grp){
        if(!j||!j[grp])return;
        Object.keys(j[grp]).forEach(function(p){
          tot++;var ok=!!(j[grp][p]&&j[grp][p].ok);if(ok)live++;
          parts.push([p,ok]);
        });
      });
      S.dns={tot:tot,live:live};
      parts.sort(function(a,b){return parseInt(a[0],10)-parseInt(b[0],10)});
      $('dnsDots').innerHTML=parts.map(function(x){
        return '<span class="pdot '+(x[1]?'ok':'bad')+'" data-tip="'+(x[1]?'Сервер отвечает на DNS-запросы':'Порт не отвечает: сервер выключен или завис. На работу остальных не влияет.')+'"><i></i>'+esc(x[0])+'</span>'}).join('');
      $('dnsSum').textContent=live===tot?('все '+tot+' серверов живы'):(live+' из '+tot+' живы');
      renderFeed();
    }).catch(function(){});
  }
  /* главное: тик 1 с, порог 2/15 с */
  var lastPoll=0;
  function pollNow(){
    fetch('/api/dashboard',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){
      /* r94 (аудит r93, Ж): busy-503 гейта не затирает дашборд —
         рендер только полноценных данных */
      if(!d||d.status==='busy')return;
      render(d)}).catch(function(){});
  }
  setInterval(function(){
    var now=Date.now();
    if(document.hidden){if(now-lastPoll<15000)return}
    else{if(now-lastPoll<2000)return}
    lastPoll=now;pollNow();
  },1000);
  pollNow();
  setTimeout(pollDns,1500);
  setInterval(function(){if(!document.hidden)pollDns()},60000);
  window.addEventListener('resize',function(){if(!document.hidden)drawChart()});
  /* кнопка обновления списков */
  function startUpdate(){
    var fd=new FormData();fd.append('csrf_token',CSRF);
    fetch('/dash/update-lists',{method:'POST',body:fd,credentials:'same-origin'})
      .then(function(r){return r.json()})
      .then(function(j){
        if(!j.started){
          $('heroTitle').textContent='Обновление не запущено';
          $('heroSub').textContent=j.message||'Не удалось запустить — подробности в журнале панели.';
          return}
        $('heroTitle').textContent='Идёт обновление списков…';
        $('heroSub').textContent='Обычно занимает 1–2 минуты.';
        $('updBtn').disabled=true;$('updBtn2').disabled=true;
        var n=0;
        (function wait(){
          fetch('/api/update-status',{credentials:'same-origin'})
            .then(function(r){return r.json()})
            .then(function(st){
              if((st.status==='busy'||(st.status==='running'&&!st.stale))&&n<200){n++;setTimeout(wait,2000)}
              else{$('updBtn').disabled=false;$('updBtn2').disabled=false;pollNow()}
            }).catch(function(){if(n<200){n++;setTimeout(wait,3000)}
              else{$('updBtn').disabled=false;$('updBtn2').disabled=false;pollNow()}});
        })();
      }).catch(function(){
        $('heroTitle').textContent='Не удалось связаться с панелью';
        $('heroSub').textContent='Проверьте соединение и попробуйте ещё раз.';
      });
  }
  $('updBtn').addEventListener('click',startUpdate);
  $('updBtn2').addEventListener('click',startUpdate);
})();
</script>
</body>
</html>'''

PAGE_TEMPLATE = r'''
<!DOCTYPE html><html lang="ru" data-theme="light"><head>
<meta charset="utf-8">
<meta name="viewport"
  content="width=device-width,
  initial-scale=1">
<title>KeenZOO Panel</title>
<script>
/* Тема: светлая по умолчанию, выбор хранится локально (без cookie). */
(function () {
  function applyTheme(t) {
    document.documentElement.dataset.theme = t;
    var b = document.getElementById('themeBtn');
    if (b) b.setAttribute('aria-pressed', String(t === 'dark'));
  }
  try {
    var s = localStorage.getItem('kzp-theme');
    if (s === 'dark' || s === 'light') applyTheme(s);
  } catch (e) {}
  /* FB-136: тема синхронно меняется и в других окнах/iframe (storage). */
  try {
    window.addEventListener('storage', function (e) {
      if (e.key === 'kzp-theme' &&
          (e.newValue === 'dark' || e.newValue === 'light'))
        applyTheme(e.newValue);
    });
  } catch (e) {}
  window.toggleTheme = function () {
    var t = (document.documentElement.dataset.theme === 'dark') ? 'light' : 'dark';
    applyTheme(t);
    try { localStorage.setItem('kzp-theme', t); } catch (e) {}
  };
})();
</script>
<style>
/* FB-139 (r73): токены дашборда (MD3) + алиасы легаси-правил:
   имена селекторов и разметка не менялись — приводится только вид */
:root{
 --font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif;
 --r-l:12px; --r-m:10px; --r-s:8px;
 --fs-caption:13px;--fs-s:14.5px;--fs-m:15px;--fs-l:17px;--fs-xl:18px;
 --sp-1:4px;--sp-2:8px;--sp-3:12px;--sp-4:16px;--sp-5:24px;--sp-6:32px;
 --z-sticky:30;--z-menu:40;--z-pop:50;--z-backdrop:55;--z-rail:60;--z-tip:70;--z-toast:90;
 --ease:cubic-bezier(.2,.7,.3,1);--dur:.15s;
 --surface:#ffffff; --surface-2:#f1f4f8; --surface-3:#e6ebf1;
 --outline:#d7dee7; --outline-2:#e8edf3;
 --text:#1b2433; --faint:#546273;
 --primary:#007fb4; --primary-h:#009bd6; --primary-c:#d9f1fc; --on-primary-c:#0a4f78;
 --ok:#0b9c66; --ok-c:#e3f6ee; --on-ok-c:#075e42;
 --warn:#b35408; --warn-c:#fcf1e0; --on-warn-c:#7a4108;
 --err:#d43c3c; --err-c:#fdeaea; --on-err-c:#991b1b;
 --sh-1:0 1px 2px rgba(27,36,51,.06),0 2px 6px rgba(27,36,51,.05);
 --sh-2:0 6px 18px rgba(27,36,51,.10),0 16px 36px rgba(27,36,51,.10);
 --txt:#1b2433;--muted:#4b5a6e;--accent:#007fb4;--accent2:#009bd6;
 --green:#0b9c66;--red:#d43c3c;--orange:#b35408;
 --gl:#ffffff;--gl2:#f1f4f8;--brd:#e6ebf1;--bg:#e9edf2;--page:#e9edf2;
 --line:#c9d4e0;--soft:#d9f1fc;--oksoft:#e3f6ee;--warnsoft:#fcf1e0;
 --badsoft:#fdeaea;--on-accent:#fff;--radius:12px;
 --side:#ffffff;--side-txt:#1b2433;--side-mut:#5a6577;--side-acc:#007fb4;
 --on-acc-c:#0a4f78;
 --space:var(--sp-3);--control-h:44px;--content-max:1180px;
 color-scheme:light;font-size:var(--fs-m)
}
html[data-theme="dark"]{
 --surface:#1e293b; --surface-2:#17202d; --surface-3:#2b3a50;
 --outline:#2b3644; --outline-2:#202a37;
 --text:#e0e8f3; --faint:#93a5bd;
 --primary:#00a8e8; --primary-h:#29b9f2; --primary-c:#17394e; --on-primary-c:#cfeafe;
 --ok:#31d09b; --ok-c:#0d3527; --on-ok-c:#a7f3d0;
 --warn:#f2b13e; --warn-c:#39290b; --on-warn-c:#fde3a7;
 --err:#f87e7e; --err-c:#3d181b; --on-err-c:#fecdcd;
 --sh-1:0 1px 2px rgba(0,0,0,.45); --sh-2:0 8px 26px rgba(0,0,0,.55);
 --txt:#e0e8f3;--muted:#b0bfd2;--accent:#00a8e8;--accent2:#29b9f2;
 --green:#31d09b;--red:#f87e7e;--orange:#f2b13e;
 --gl:#1e293b;--gl2:#17202d;--brd:#3b485b;--bg:#1b2433;--page:#1b2433;
 --line:#3b485b;--soft:#17394e;--oksoft:#0d3527;--warnsoft:#39290b;
 --badsoft:#3d181b;--on-accent:#fff;
 --side:#171f2c;--side-txt:#e9edf3;--side-mut:#95a1b3;--side-acc:#00a8e8;
 --on-acc-c:#cfeafe;
 color-scheme:dark
}
*{box-sizing:border-box;margin:0;padding:0}
html{min-height:100%;background:var(--page);
 -webkit-text-size-adjust:100%;text-size-adjust:100%}
body{
 background:var(--page);color:var(--txt);min-height:100vh;min-height:100dvh;
 overflow-x:hidden;font-family:var(--font);font-size:var(--fs-m);
 line-height:1.6;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility;
 -webkit-tap-highlight-color:transparent
}
h1{font-size:var(--fs-xl);line-height:1.25;font-weight:650;color:var(--txt)}
svg.ico{width:18px;height:18px;flex:0 0 auto;stroke:currentColor;fill:none;
 stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
button,input,textarea,select{font:inherit}
button{touch-action:manipulation}
.tab-btn:focus-visible,.btn:focus-visible,.dns-toggle:focus-visible,
.lk-presets button:focus-visible,.icon-btn:focus-visible,
details.cfg-d>summary:focus-visible,select:focus-visible,
input:focus-visible,textarea:focus-visible{
 outline:2px solid var(--accent);outline-offset:2px
}
.layout{display:flex;min-height:100vh;min-height:100dvh}
.side{
 width:208px;flex:0 0 208px;background:var(--side);display:flex;
 flex-direction:column;position:sticky;top:0;height:100vh;height:100dvh;overflow-y:auto;
 border-right:1px solid var(--outline)
}
/* FB-149 (панель-77): сайдбар панели скрыт — навигация через левое меню */
.side{display:none!important}
.side-brand{display:flex;align-items:center;gap:10px;padding:15px 13px 12px}
.side-logo{
 width:32px;height:32px;border-radius:10px;display:grid;place-items:center;
 background:linear-gradient(135deg,#0061e6,#0043b8);color:#fff;flex:0 0 32px;font-size:0;
 box-shadow:0 3px 10px rgba(0,97,230,.35)
}
.side-logo svg{width:20px;height:20px}
.brand-text{min-width:0}.brand-name{font-weight:700;font-size:15px;letter-spacing:1px;
 color:var(--side-txt);-webkit-text-fill-color:var(--side-txt)}
.brand-sub{font-size:11px;color:var(--side-mut);letter-spacing:.2px}
.tabs{display:flex;flex-direction:column;flex:1;padding:2px 9px}
.nav-group{font-size:10px;letter-spacing:1.15px;text-transform:uppercase;
 color:var(--side-mut);padding:13px 6px 5px;font-weight:700}
.tab-btn{
 width:100%;height:44px;text-align:left;display:flex;align-items:center;gap:10px;
 background:none;border:0;border-radius:999px;color:var(--side-mut);
 font-size:var(--fs-s);font-weight:550;padding:0 14px;margin:1px 0;cursor:pointer;
 transition:background var(--dur) var(--ease),color var(--dur) var(--ease)
}
.tab-btn svg.ico{color:var(--side-mut)}
.tab-btn:hover{background:var(--gl2);color:var(--side-txt)}
.tab-btn:hover svg.ico{color:var(--side-acc)}
.tab-btn.active{background:var(--primary);color:#fff;font-weight:600}
.tab-btn.active svg.ico{color:#fff}
html[data-theme="dark"] .tab-btn.active{background:var(--primary-c);color:var(--on-primary-c)}
html[data-theme="dark"] .tab-btn.active svg.ico{color:var(--primary)}
.tab-btn:active{transform:scale(.985)}
.side-foot{
 padding:11px 13px;font-size:11px;color:var(--side-mut);border-top:1px solid var(--outline);
 display:flex;gap:7px;align-items:center
}
.live-dot{width:8px;height:8px;border-radius:50%;background:var(--green);flex:0 0 8px}
.main{flex:1;min-width:0;padding:18px 22px 30px}
.page-head{
 position:sticky;top:0;z-index:var(--z-sticky);display:flex;align-items:center;gap:10px;flex-wrap:wrap;
 margin:-18px -22px 15px;padding:10px 22px;border-bottom:1px solid var(--outline);
 /* FB-211 (панель-r86): backdrop-filter убран — в мобильных Chromium
    переполнение фильтруемого слоя уводит подсказку заголовка под
    контент; фон непрозрачный, стекинг предсказуем во всех движках */
 background:var(--gl)
}
.page-title{flex:0 1 auto;min-width:160px}
.hd-pill{
 display:inline-flex;align-items:center;justify-content:center;height:26px;padding:0 10px;
 border-radius:99px;font-size:var(--fs-caption);font-weight:600;white-space:nowrap
}
.hd-pill.ok{background:var(--ok-c);color:var(--on-ok-c)}
.hd-pill.warn{background:var(--warn-c);color:var(--on-warn-c)}
.hd-pill.bad{background:var(--err-c);color:var(--on-err-c)}
.hd-pill.ghost{background:var(--gl2);color:var(--muted);font-weight:500}
.hd-time{
 margin-left:auto;font-family:ui-monospace,"Cascadia Mono",Consolas,monospace;
 font-size:var(--fs-caption);color:var(--muted);white-space:nowrap
}
.icon-btn{
 display:inline-flex;align-items:center;justify-content:center;width:var(--control-h);height:var(--control-h);
 border-radius:var(--r-m);border:1px solid var(--line);background:var(--gl2);color:var(--muted);cursor:pointer
}
.icon-btn:hover{border-color:var(--accent);color:var(--accent)}
.icon-btn .ico{width:18px;height:18px}
.icon-btn .ico-sun{display:block}.icon-btn .ico-moon{display:none}
html[data-theme="dark"] .icon-btn .ico-sun{display:none}
html[data-theme="dark"] .icon-btn .ico-moon{display:block}
.card{min-width:0;max-width:var(--content-max);margin:0 auto}
.tiles{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:var(--space);align-items:stretch;max-width:var(--content-max);width:100%;margin:0 auto}
.tile{
 grid-column:span 12;min-width:0;background:var(--gl);border:1px solid var(--outline-2);
 border-radius:var(--radius);box-shadow:var(--sh-1);padding:var(--sp-4);transition:box-shadow var(--dur) var(--ease);
}
.tile:has(>form .btn-key),.tile:has(>form .btn-cfg){display:flex;flex-direction:column}
.tile:has(>form .btn-key)>form,.tile:has(>form .btn-cfg)>form{display:flex;flex-direction:column;flex:1}
.tile:has(>form .btn-key)>form>.btn,.tile:has(>form .btn-cfg)>form>.btn{margin-top:auto}
.tile:hover{box-shadow:var(--sh-2)}
.tile:not(.tile-span){grid-column:span 6}
.tile-span{grid-column:1/-1}
.tile-hint{font-size:var(--fs-caption);color:var(--muted);margin:10px 0 0;line-height:1.45}
.tile-hint b{color:var(--txt)}
.tab-content{display:none}.tab-content.active{display:block}
label{display:block;font-size:var(--fs-s);color:var(--muted);margin-bottom:7px}
textarea,input[type=text],select{
 width:100%;min-height:var(--control-h);padding:9px 11px;background:var(--surface-2);
 border:1px solid var(--outline);border-radius:var(--r-m);color:var(--txt);font-size:var(--fs-m)
}
textarea{
 font-family:ui-monospace,Consolas,monospace;resize:vertical;line-height:1.5
}
input[type=text]{font-family:ui-monospace,Consolas,monospace}
textarea:focus,input[type=text]:focus,select:focus{
 outline:none;border-color:var(--primary);box-shadow:0 0 0 3px var(--primary-c)
}
textarea::placeholder,input::placeholder{color:var(--muted)}
.key-area{min-height:88px}
/* FB-203 (панель-r83): шрифт списков протоколов крупнее */
.list-area{min-height:250px;font-size:15px;line-height:1.6}
#lk-output,#lk-add-entries{font-family:ui-monospace,Consolas,monospace;font-size:var(--fs-s)}
.cfg-ta{min-height:240px}
.compact-area{min-height:120px}.config-entry{min-height:120px}.select-control{font-family:ui-sans-serif,system-ui,sans-serif}
.hint{font-size:var(--fs-caption);color:var(--muted);margin:5px 0 11px;line-height:1.4}
.hint code,.info-box code{background:var(--gl2);color:var(--txt);padding:1px 5px;border-radius:5px}
/* FB-206 (панель-r84): линии по бокам подписи вместо контейнера-полосы
   height:1px — многострочная подпись центрировалась на полосе и наезжала
   на подпись ниже; контейнер растёт по высоте подписи, центр сохранён */
.divider{
 display:flex;align-items:center;gap:10px;margin:15px 0
}
.divider::before,.divider::after{
 content:"";height:1px;background:var(--line);flex:1;min-width:12px
}
.divider span{
 background:var(--gl);color:var(--accent);font-size:var(--fs-caption);font-weight:600;padding:0 8px;border-radius:var(--r-m);
 max-width:100%;overflow-wrap:anywhere;text-align:center
}
.subhead{font-size:11.5px;letter-spacing:.6px;text-transform:uppercase;
 color:var(--faint);font-weight:700;margin-bottom:8px}
.subhead-gap{margin:11px 0 7px}
.counter{font-size:var(--fs-caption);color:var(--muted);text-align:right;margin-top:4px}
.btn{
 width:100%;min-height:var(--control-h);padding:8px 16px;border:1px solid var(--outline);
 border-radius:999px;background:var(--gl2);color:var(--text);font-size:var(--fs-s);font-weight:600;
 cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;
 transition:background var(--dur) var(--ease),border-color var(--dur) var(--ease),color var(--dur) var(--ease)
}
.btn:hover{background:var(--surface-3)}.btn:active{transform:scale(.985)}
.btn:disabled{opacity:.55;cursor:not-allowed;transform:none}
.btn-key{background:var(--primary);border-color:var(--primary);color:#fff;
 box-shadow:0 2px 8px color-mix(in srgb,var(--primary) 35%,transparent)}
.btn-key:hover{background:var(--primary-h);border-color:var(--primary-h)}
html[data-theme="dark"] .btn-key{color:#0b1512}
.btn-cfg,.btn-save{background:var(--primary);border-color:var(--primary);color:#fff;margin-top:6px}
/* FB-192 (панель-r83): залиты как «Применить ключ» */
.btn-cfg:hover,.btn-save:hover{background:var(--primary-h);border-color:var(--primary-h)}
html[data-theme="dark"] .btn-cfg,html[data-theme="dark"] .btn-save{color:#0b1512}
.btn .spinner-ring{
 display:none;width:16px;height:16px;border-radius:50%;border:2px solid var(--brd);
 border-top-color:currentColor;animation:spin .6s linear infinite
}
.btn.loading .spinner-ring{display:inline-block}.btn.loading .btn-label{opacity:.7}
@keyframes spin{to{transform:rotate(360deg)}}
.action-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.action-row>.btn{width:auto;min-width:170px;flex:1 1 170px}
.action-row-auto>.btn{flex:0 1 auto}.action-row-result>.btn{flex:1 1 220px}
.action-auto{min-width:180px}
.lookup-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;margin-bottom:10px}
.lookup-submit{width:var(--control-h);min-width:var(--control-h);padding:0}
.result-info{font-size:var(--fs-s);color:var(--muted);margin-bottom:7px}
.result-status{margin-bottom:9px}.result-output{min-height:200px;background:var(--surface-2)}
.is-hidden{display:none}.lk-presets{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}
.lk-presets button{
 min-height:36px;padding:6px 12px;border:1px solid var(--line);border-radius:var(--r-m);
 background:var(--gl);color:var(--muted);cursor:pointer;font-size:var(--fs-s);
 transition:color .12s,border-color .12s
}
.lk-presets button:hover{color:var(--accent);border-color:var(--accent)}
#update-bar,#pin-bar{display:none}
.msg,#update-bar,#pin-bar{
 max-width:var(--content-max);width:100%;margin:0 auto var(--space);padding:10px 13px;
 border-radius:var(--r-m);border:1px solid var(--line);background:var(--gl);font-size:var(--fs-m);white-space:pre-line
}
.msg-ok{border-color:transparent;border-left:3px solid var(--ok);
 background:var(--ok-c);color:var(--on-ok-c)}
.msg-err{border-color:transparent;border-left:3px solid var(--err);
 background:var(--err-c);color:var(--on-err-c)}
#update-bar,#pin-bar{text-align:center;white-space:pre-wrap}
#update-bar.running{display:block;border-color:transparent;
 border-left:3px solid var(--primary);background:var(--primary-c);color:var(--on-primary-c)}
#update-bar.done{display:block;border-color:transparent;
 border-left:3px solid var(--ok);background:var(--ok-c);color:var(--on-ok-c)}
#update-bar.warn{display:block;border-color:transparent;
 border-left:3px solid var(--warn);background:var(--warn-c);color:var(--on-warn-c)}
#update-bar.error{display:block;border-color:transparent;
 border-left:3px solid var(--err);background:var(--err-c);color:var(--on-err-c)}
#pin-bar.warn{display:block;border-color:transparent;
 border-left:3px solid var(--err);background:var(--err-c);color:var(--on-err-c)}
#pin-bar.ok{display:block;border-color:transparent;
 border-left:3px solid var(--ok);background:var(--ok-c);color:var(--on-ok-c)}
.svc-row{
 display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:48px;
 background:var(--surface-2);border:1px solid var(--line);border-radius:var(--r-m);padding:9px 11px
}
.svc-name{font-size:var(--fs-m);font-weight:650;color:var(--muted);min-width:0;overflow-wrap:anywhere}
.svc-name.on{color:var(--green)}.svc-name.off{color:var(--red)}
.switch{position:relative;display:inline-block;width:56px;height:30px;flex:0 0 56px}
.switch input{position:absolute;opacity:0;width:100%;height:100%;margin:0;cursor:pointer}
.slider{position:absolute;cursor:pointer;inset:0;background:var(--brd);border-radius:24px;transition:background .15s}
.slider:before{
 position:absolute;content:"";height:22px;width:22px;left:4px;top:4px;background:#fff;
 border-radius:50%;transition:transform .15s
}
.switch input:checked+.slider{background:var(--accent)}
.switch input:checked+.slider:before{transform:translateX(26px)}
.switch input:focus-visible+.slider{outline:2px solid var(--accent);outline-offset:2px}
.dns-panel{max-width:var(--content-max);width:100%;margin:var(--space) auto 0}
.dns-toggle{
 width:100%;min-height:38px;background:var(--gl);border:1px solid var(--line);border-radius:var(--r-m);
 padding:7px 12px;color:var(--muted);font-size:var(--fs-s);cursor:pointer;text-align:center;
 transition:color .12s,border-color .12s
}
.dns-toggle:hover{color:var(--accent);border-color:var(--accent)}
.dns-grid{
 display:none;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:8px;
 background:var(--gl);border:1px solid var(--line);border-radius:var(--r-m);padding:10px
}
.dns-grid.open{display:grid}
.dns-port{
 text-align:center;padding:7px 6px;border-radius:var(--r-m);font-size:var(--fs-caption);
 font-family:ui-monospace,Consolas,monospace;background:var(--surface-2);border:1px solid var(--line);
 overflow-wrap:anywhere
}
.dns-port.ok{color:var(--green);border-color:var(--green)}
.dns-port.fail{color:var(--red);border-color:var(--red)}
.dns-port.insecure{color:var(--orange);border-color:var(--orange)}
.dns-port.checking{color:var(--muted)}
.dns-label{
 font-size:var(--fs-caption);color:var(--muted);margin:5px 0 0;font-weight:650;
 grid-column:1/-1;background:none;border:0;text-align:left
}
.ver-grid{display:none;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:8px;
 background:var(--gl);border:1px solid var(--line);border-radius:var(--r-m);padding:10px}
.ver-grid.open{display:grid}.ver-item{display:flex;flex-direction:column;gap:6px;min-width:0}
.upd-all-row{display:none;grid-column:1/-1}.upd-all-row.on{display:block}
.upd-btn{display:none;width:100%;font-size:var(--fs-s);padding:7px 10px;
 background:var(--warn-c);border-color:transparent;color:var(--on-warn-c)}
.upd-btn.on{display:block}.upd-all-row .upd-btn{display:block}
.upd-check-result{font-size:var(--fs-s);color:var(--muted)}
.upd-out{
 display:none;white-space:pre-wrap;font-family:ui-monospace,Consolas,monospace;font-size:var(--fs-caption);line-height:1.4;
 max-height:240px;overflow:auto;padding:9px 11px;border-radius:var(--r-m);background:var(--surface-2);
 border:1px solid var(--line);color:var(--txt);word-break:break-word
}
.upd-out.on{display:block}
.pin-box{
 display:none;grid-column:1/-1;white-space:pre-wrap;font-family:ui-monospace,Consolas,monospace;
 font-size:var(--fs-caption);line-height:1.5;color:var(--muted);padding:8px 10px;border-radius:var(--r-m);
 background:var(--surface-2);border:1px solid var(--line);word-break:break-all
}
.pin-box.on{display:block}
.spoof-verdict{font-size:var(--fs-l);font-weight:650;margin:5px 0}.spoof-verdict.ok{color:var(--green)}
.spoof-verdict.warn{color:var(--orange)}.spoof-verdict.bad{color:var(--red)}
.spoof-meta{font-size:var(--fs-s);color:var(--muted);margin-bottom:7px;overflow-wrap:anywhere}
.spoof-ports{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:6px;margin-bottom:9px}
.spoof-port{
 display:flex;justify-content:space-between;gap:8px;min-width:0;background:var(--surface-2);
 border:1px solid var(--line);border-radius:var(--r-m);padding:7px 8px;font-size:var(--fs-s)
}
.spoof-port>span:first-child{min-width:0;overflow-wrap:anywhere}.spoof-port .ok{color:var(--green)}
.spoof-port .warn{color:var(--orange)}.spoof-port .bad{color:var(--red)}
.rs-mode{font-size:16px;font-weight:650;margin:5px 0}.rs-mode.ok{color:var(--green)}
.rs-mode.warn{color:var(--orange)}.rs-mode.bad{color:var(--red)}
.rs-primary{font-size:var(--fs-m);margin:0 0 8px;color:var(--txt);overflow-wrap:anywhere}
.spoof-port .mut{color:var(--muted)}
.spoof-port .rs-ver{border-bottom:1px dotted var(--accent);cursor:help}
details.cfg-d{
 background:var(--gl);border:1px solid var(--line);border-radius:var(--r-m);margin-bottom:8px;overflow:hidden
}
details.cfg-d>summary{
 cursor:pointer;list-style:none;display:flex;flex-wrap:wrap;gap:4px 10px;align-items:center;
 min-height:42px;padding:8px 10px;font-size:var(--fs-m);user-select:none
}
details.cfg-d>summary::-webkit-details-marker{display:none}
details.cfg-d>summary::before{content:"\25B6";font-size:9px;color:var(--muted);transition:transform .15s}
details.cfg-d[open]>summary::before{transform:rotate(90deg)}
details.cfg-d>summary .cfg-path{
 font-family:ui-monospace,Consolas,monospace;font-size:var(--fs-caption);color:var(--muted);overflow-wrap:anywhere
}
details.cfg-d>summary .cfg-meta{font-size:var(--fs-caption);color:var(--muted);margin-left:auto}
.cfg-btns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:9px 10px 0}
.cfg-btns .btn{width:100%;margin:0}
details.cfg-d>.upd-out{margin:9px 10px 10px}
.info-box{
 background:var(--soft);border:0;border-left:3px solid var(--accent);border-radius:var(--r-m);
 padding:11px 12px;margin-bottom:13px;font-size:var(--fs-s);line-height:1.6;color:var(--on-acc-c)
}
.lk-presets{margin-bottom:11px}.lk-presets button{min-width:100px}
.rp-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.rp-btn{min-width:0}.rp-btn.active{border-color:transparent;background:var(--soft);
 color:var(--on-acc-c);box-shadow:none}
.rp-btn:disabled{opacity:.45;cursor:not-allowed;box-shadow:none}
.kz-hint{display:flex;justify-content:space-between;font-size:var(--fs-caption);color:var(--muted);margin-top:4px}
.kz-hint .kz-err{color:var(--err);font-weight:600}
#kzToasts{position:fixed;right:16px;bottom:16px;z-index:var(--z-toast);display:flex;flex-direction:column;gap:8px;
 max-width:min(360px,calc(100vw - 32px))}
.kz-toast{background:var(--gl);border:1px solid var(--outline-2);border-left:3px solid var(--ok);
 border-radius:var(--r-m);box-shadow:var(--sh-2);padding:11px 14px;font-size:var(--fs-s);color:var(--txt);
 animation:kz-in .18s ease-out}
.kz-toast.kz-warn{border-left-color:var(--warn)}
/* FB-146 (У-18): скелетон незавершённых проверок DNS и пустое состояние */
.dns-grid .dns-port.checking{color:transparent;
 background-image:linear-gradient(90deg,var(--surface-3) 25%,var(--surface-2) 50%,var(--surface-3) 75%);
 background-size:200% 100%;animation:kz-skel 1.1s linear infinite}
@keyframes kz-skel{from{background-position:200% 0}to{background-position:-200% 0}}
.kz-empty{display:flex;flex-direction:column;align-items:center;gap:var(--sp-2);
 padding:var(--sp-5) var(--sp-3);color:var(--muted);font-size:var(--fs-s);text-align:center}
.kz-empty .kz-eico{width:44px;height:44px;border-radius:12px;background:var(--surface-2);
 display:grid;place-items:center;font-size:20px}
@keyframes kz-in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
*::-webkit-scrollbar{width:8px;height:8px}*::-webkit-scrollbar-thumb{background:var(--brd);border-radius:4px}
*::-webkit-scrollbar-track{background:transparent}
@media (max-width:960px){
 .layout{flex-direction:column}.side{
  width:100%;flex:0 0 auto;height:auto;position:sticky;top:0;z-index:var(--z-menu);flex-direction:row;align-items:center;
  overflow-x:auto;scrollbar-width:none
 }
 .side::-webkit-scrollbar{display:none}.side-brand{padding:9px 11px;flex-shrink:0}.brand-sub{display:none}
 .tabs{flex-direction:row;padding:0 5px;flex:1;scroll-snap-type:x proximity}
 .nav-group{display:none}.tab-btn{width:auto;height:44px;white-space:nowrap;padding:0 12px;
  border-radius:999px;scroll-snap-align:start;color:var(--side-mut)}
 .tab-btn.active{background:var(--primary);color:#fff;border-color:transparent;box-shadow:none}
 .tab-btn.active svg.ico{color:#fff}
 html[data-theme="dark"] .tab-btn.active{background:var(--primary-c);color:var(--on-primary-c)}
 html[data-theme="dark"] .tab-btn.active svg.ico{color:var(--primary)}.side-foot{display:none}
 .main{padding:var(--sp-3) var(--sp-3) var(--sp-5)}
 /* FB-211 (панель-r86): relative+z-index:1 — выше статичных карточек,
    ниже липкого сайдбара вкладок (z-menu); sticky по-прежнему нет */
 .page-head{position:relative;z-index:1;margin:-12px -12px 12px;padding:9px 12px}
 .page-title{font-size:var(--fs-l)}.dns-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:700px){
 .tile:not(.tile-span){grid-column:1/-1}.cfg-btns{grid-template-columns:1fr}
 .action-row>.btn,.action-auto{flex:1 1 100%;min-width:0}.rp-row{grid-template-columns:1fr}
 .spoof-ports{grid-template-columns:1fr}.tile{padding:14px}
  /* FB-209 (панель-r85): значок темы — в одной строке с заголовком;
    мобильная шапка — грид: строка 1 — заголовок и значок темы,
    строка 2 — DNS-пилюли, строка 3 — время последней проверки */
 .page-head{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center}
 .page-title{grid-column:1;grid-row:1;min-width:0}
 .page-head .icon-btn{grid-column:2;grid-row:1;justify-self:end}
 #hd-mode{grid-column:1;grid-row:2}
 #hd-verdict{grid-column:2;grid-row:2}
 .hd-time{grid-column:1/-1;grid-row:3;margin-left:0}
 .hd-pill{height:28px}
}
@media (max-width:420px){
 .main{padding-left:9px;padding-right:9px}.page-head{margin-left:-9px;margin-right:-9px;padding-left:9px;padding-right:9px}
 .side-brand{padding-left:9px;padding-right:9px}.tabs{padding-left:3px;padding-right:3px}.tab-btn{padding:0 8px;font-size:var(--fs-caption);gap:7px}
 .tab-btn svg.ico{width:16px;height:16px}.tile{padding:12px}.divider{margin:13px 0}.info-box{font-size:var(--fs-caption)}
 .dns-grid,.ver-grid{padding:8px;gap:6px}.dns-port,.spoof-port{font-size:var(--fs-caption)}
}
@media (prefers-reduced-motion:reduce){*{transition:none !important;animation:none !important}}

/* ═ FB-151 (панель-77): PAGE — компоненты по решению владельца (panel_preview_r78): пилюли-строка, кнопки, карточки ═ */
.layout{flex-direction:column!important}
body{font-size:15px}
.page-head h1{font-size:21px;letter-spacing:.1px}
.tile{border-radius:7px}
/* FB-149 (панель-77): на компьютере меню одно (слева), пилюли — только мобильная строка */
.side{display:none!important}
@media(max-width:700px){
  .side{display:block!important;position:static!important;width:100%!important;flex:0 0 auto!important;
    height:auto!important;min-height:0!important;border-right:0!important;
    border-bottom:1px solid var(--line);background:transparent}
  .tabs{flex-direction:row!important;flex-wrap:nowrap;overflow-x:auto;gap:6px;
    padding:8px 12px!important;scroll-snap-type:none}
  .tab-btn{flex:0 0 auto;white-space:nowrap}
}
.nav-group{display:none}
.tab-btn{height:34px;min-height:34px;padding:7px 12px;border-radius:4px;
  border:1px solid var(--brd);background:var(--gl2);font-weight:700;font-size:14px}
.tab-btn.active{background:var(--primary-c);border-color:var(--primary);color:var(--txt)}
.btn{border-radius:5px;font-weight:700}
.btn-key{background:#007fb4;border:1px solid var(--primary);color:#fff;
  box-shadow:none}
.btn-key:hover{background:#009bd6;border-color:var(--primary)}
.btn-save,.btn-cfg{background:#007fb4;border:1px solid var(--primary);color:#fff}
.btn-save:hover,.btn-cfg:hover{background:#009bd6;border-color:var(--primary)}
html[data-theme="dark"] .btn-save,html[data-theme="dark"] .btn-cfg{color:#0b1512}
.info-box{border-radius:5px}
/* ═══ FB-190..FB-203 (панель-r83, решение владельца): утверждённый шаблон
   panel_preview_r83.html — заголовки 22px, ON/OFF, подсказки, уведомления ═══ */
.page-head h1{font-size:22px;font-weight:700;letter-spacing:-.012em}
.page-title b{font-weight:800}
body{font-variant-numeric:tabular-nums;-webkit-font-smoothing:antialiased}
.st-lg{font-size:17px;font-weight:700;letter-spacing:.07em}
.st-on{color:var(--primary)}
.st-off{color:var(--faint)}
.tip{position:relative;display:inline-flex;align-items:center;gap:6px;cursor:help;outline:none}
.tip.t-underline{border-bottom:1px dotted var(--faint)}
.tip-b{position:absolute;left:0;top:calc(100% + 9px);z-index:var(--z-tip);min-width:240px;max-width:420px;
  background:var(--gl);border:1px solid var(--outline-2);color:var(--txt);padding:11px 14px;
  border-radius:var(--r-m);font-size:var(--fs-s);font-weight:400;line-height:1.6;text-align:left;
  box-shadow:var(--sh-2);opacity:0;visibility:hidden;transform:translateY(5px);pointer-events:none;
  transition:opacity .16s ease .25s,transform .16s ease .25s,visibility .16s ease .25s}
.tip:hover .tip-b,.tip:focus-visible .tip-b{opacity:1;visibility:visible;transform:none;transition-delay:.12s}
/* r89 (NFQWS2, раунд 4): типографическая унификация ВСЕХ подсказок —
   13px, вес 400, обычный регистр/трекинг. Специфичность .tip .tip-b
   (0,2,0) обязательна: .divider span{font-weight:600} и
   .subhead{letter-spacing} (0,1,1) наследуются и перебивают одиночный
   класс. Все tip-b панели живут внутри .tip — покрытие полное. */
.tip .tip-b{font-size:var(--fs-caption);font-weight:400;text-transform:none;letter-spacing:normal}
/* r89 (NFQWS2): плитки вкладки — перенесено из мокапа r88 (раунды 1-4) */
.za-rows{display:flex;flex-direction:column}
.za-row{display:flex;justify-content:space-between;align-items:baseline;gap:12px;
 padding:7px 0;border-bottom:1px solid var(--outline-2);font-size:var(--fs-s)}
.za-row:last-child{border-bottom:0;padding-bottom:2px}
.za-row>span{color:var(--faint)}
.za-row>b{font-weight:600;text-align:right;min-width:0;overflow-wrap:anywhere}
.za-row .st{font-size:var(--fs-l)}
.za-warn{margin-top:14px;background:var(--err-c);border:1px solid color-mix(in srgb,var(--err) 30%,transparent);
 border-left:3px solid var(--err);border-radius:var(--r-m);padding:11px 14px;font-size:var(--fs-s);
 color:var(--on-err-c);line-height:1.55}
.za-warn b{display:block;margin-bottom:3px}
/* r90 (правка владельца 02.11.2026): конфликт-кнопки — в один ряд,
   растянуты на ширину блока (десктоп, grid 1fr 1fr); мобильный
   (≤700px, брейкпоинт страницы) — прежний вертикальный вид мокапа
   r88 раунда 2. */
.za-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:11px}
.za-actions form{display:flex;min-width:0}
.za-actions .btn{width:100%;max-width:100%;min-width:0;min-height:36px;
 padding:6px 12px;font-size:12.5px;line-height:1.4;margin-top:0}
@media(max-width:700px){
 .za-actions{grid-template-columns:1fr;justify-items:center}
 .za-actions form{width:100%}
 .za-actions .btn{width:auto}
 .za-actions form .btn{width:100%}
}
.za-iq{margin-top:10px;background:var(--warn-c);border:1px solid color-mix(in srgb,var(--warn) 30%,transparent);
 border-left:3px solid var(--warn);border-radius:var(--r-m);padding:10px 14px;font-size:var(--fs-caption);
 color:var(--on-warn-c);line-height:1.5}
.za-ok{margin-top:14px;background:var(--ok-c);border:1px solid color-mix(in srgb,var(--ok) 30%,transparent);
 border-left:3px solid var(--ok);border-radius:var(--r-m);padding:11px 14px;font-size:var(--fs-s);
 color:var(--on-ok-c);line-height:1.55}
.za-gui-url{font-size:var(--fs-caption);color:var(--faint);margin:6px 0 4px;overflow-wrap:anywhere}
.za-auto{display:inline-flex;align-items:center;justify-content:center;gap:6px}
.za-auto .ico{width:16px;height:16px;flex:0 0 auto;fill:var(--primary)}
.za-mode-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.za-mode-row form{display:flex}
.za-mode-row form .btn{flex:1 1 auto;width:100%;min-width:0}
.za-tip{left:50%;right:auto;min-width:200px;max-width:min(340px,calc(100vw - 48px));
 transform:translate(-50%,5px);text-align:center;line-height:1.55}
.tip:hover .za-tip,.tip:focus-visible .za-tip{transform:translate(-50%,0)}
.za-tip-head{left:0;min-width:240px;max-width:min(340px,calc(100vw - 44px));
 text-align:center;line-height:1.55}
.tip-b code{background:var(--surface-3);border-radius:5px;padding:1px 5px;font-size:12px}
/* FB-195: компактное однострочное уведомление */
.kz-note{display:flex;align-items:center;gap:11px;background:var(--primary-c);color:var(--on-primary-c);
  border-radius:var(--r-m);padding:10px 15px;font-size:var(--fs-s);font-weight:500;box-shadow:var(--sh-1)}
.kz-note .ico{flex:none;color:var(--primary)}
.kz-note .nt{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
</style></head><body>
<div class="layout">
<aside class="side">
  <nav class="tabs" role="tablist" aria-label="Разделы панели">
    <div class="nav-group">Протоколы</div>
  <button id="btn-ss" class="tab-btn
    {% if active=='ss' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='ss' else 'false' }}" tabindex="{{ 0 if active=='ss' else -1 }}" onclick="go('ss')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 3 14h7l-1 8 10-12h-7z"/></svg>Shadowsocks</button>
  <button id="btn-tr" class="tab-btn
    {% if active=='tr' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='tr' else 'false' }}" tabindex="{{ 0 if active=='tr' else -1 }}" onclick="go('tr')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>Trojan</button>
  <button id="btn-vl" class="tab-btn
    {% if active=='vl' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='vl' else 'false' }}" tabindex="{{ 0 if active=='vl' else -1 }}" onclick="go('vl')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>VLESS</button>
  <button id="btn-to" class="tab-btn
    {% if active=='to' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='to' else 'false' }}" tabindex="{{ 0 if active=='to' else -1 }}" onclick="go('to')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></svg>Tor</button>
  <button id="btn-hy" class="tab-btn
    {% if active=='hy' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='hy' else 'false' }}" tabindex="{{ 0 if active=='hy' else -1 }}" onclick="go('hy')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 8h8a3 3 0 1 0-3-3M3 12h12a3 3 0 1 1-3 3M3 16h6"/></svg>Hysteria</button>
    <div class="nav-group">Списки и поиск</div>
  <button id="btn-bt" class="tab-btn
    {% if active=='bt' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='bt' else 'false' }}" tabindex="{{ 0 if active=='bt' else -1 }}" onclick="go('bt')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true" style="color:var(--primary)"><use href="#i-bot"/></svg> Бот</button>
  <button id="btn-lk" class="tab-btn
    {% if active=='lk' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='lk' else 'false' }}" tabindex="{{ 0 if active=='lk' else -1 }}" onclick="go('lk')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="10" cy="10" r="6"/><path d="m21 21-6-6"/></svg> Поиск</button>
    <div class="nav-group">Система</div>
  <button id="btn-upd" class="tab-btn
    {% if active=='upd' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='upd' else 'false' }}" tabindex="{{ 0 if active=='upd' else -1 }}" onclick="go('upd')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12a9 9 0 1 1-2.6-6.3M21 3v6h-6"/></svg> Обновления</button>
  <button id="btn-dns" class="tab-btn
    {% if active=='dns' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='dns' else 'false' }}" tabindex="{{ 0 if active=='dns' else -1 }}" onclick="go('dns')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22s8-3.6 8-10V5l-8-3-8 3v7c0 6.4 8 10 8 10z"/><path d="m9 11.5 2 2 4-4.5"/></svg> DNS</button>
  <button id="btn-cfg" class="tab-btn
    {% if active=='cfg' %}active{% endif %}"
    role="tab" aria-selected="{{ 'true' if active=='cfg' else 'false' }}" tabindex="{{ 0 if active=='cfg' else -1 }}" onclick="go('cfg')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2"/><circle cx="15" cy="17" r="2"/></svg> Конфиги</button>
  </nav>
  <div class="side-foot">
    <span class="live-dot"></span>LAN &middot; Wi-Fi &middot; WG
  </div>
</aside>
<div class="main">
{% set PT={'ss':'Shadowsocks',
  'tr':'Trojan','vl':'VLESS','to':'Tor',
  'hy':'Hysteria','za':'NFQWS2','bt':'Бот — список обхода',
  'lk':'Поиск','upd':'Обновления',
  'dns':'DNS',
  'cfg':'Конфигурации'} %}
<header class="page-head">
  <h1 class="page-title"
    id="page-title"{% if active in ('ss','tr','vl','to','hy') %} style="color:{{ 'var(--primary)' if svc_enabled[active] else 'var(--faint)' }}"{% elif active == 'za' %} style="color:{{ 'var(--primary)' if za.enabled else 'var(--faint)' }}"{% endif %}>{% if active in ('ss','tr','vl','to','hy') %}<span class="tip t-underline" tabindex="0">{{ PT[active] }}<span class="tip-b" role="tooltip">&#128260; Отключённый протокол останавливается сразу и &lt;b&gt;не запустится после перезагрузки&lt;/b&gt; (ENABLED=no в init-скрипте); включение — только этим переключателем. Конфигурация и ключи сохраняются.</span></span>{% elif active == 'upd' %}<span class="tip t-underline" tabindex="0">{{ PT[active] }}<span class="tip-b" role="tooltip">&#128230; Версии (архитектура) — установка производится вручную</span></span>{% else %}{{ PT[active] }}{% endif %}</h1>
  <!-- FB-205 (панель-r84): DNS-пилюли — только на вкладке DNS; на
       остальных вкладках «LOCAL_DNSSEC / ещё не проверялось» под
       заголовком не показываются, кнопка темы придержана вправо -->
  {% if active == 'dns' %}
  <span class="hd-pill ghost" id="hd-mode">DNS —</span>
  <span class="hd-pill ghost" id="hd-verdict">проверка подмены —</span>
  <span class="hd-time" id="hd-time"></span>
  {% endif %}
  <button id="themeBtn" class="icon-btn" type="button" title="Тёмная/светлая тема"
    aria-label="Переключить тему" aria-pressed="false" onclick="toggleTheme()"{% if active != 'dns' %} style="margin-left:auto"{% endif %}>
    <svg class="ico ico-sun" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
    <svg class="ico ico-moon" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
  </button>
</header>
<div id="update-bar" aria-live="polite"></div>
<div id="pin-bar" aria-live="polite"></div>
{% with msgs = get_flashed_messages(
  with_categories=true) %}
{% if msgs %}{% for cat, msg in msgs %}
<div role="status" class="msg {{ 'msg-ok'
  if cat=='ok' else 'msg-err' }}">
  {{ msg }}</div>
{% endfor %}{% endif %}{% endwith %}
<div class="card">
  {% for tid, tname, fkey in [
    ('ss','Shadowsocks','shadowsocks'),
    ('tr','Trojan','trojan'),
    ('vl','VLESS','vless'),
    ('to','Tor','tor'),
    ('hy','Hysteria','hysteria')] %}
  <div id="tab-{{ tid }}" role="tabpanel" tabindex="-1" aria-labelledby="btn-{{ tid }}"
    class="tab-content
    {% if active==tid %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span tile-ctl">
    <form method="post"
      action="{{ url_for('toggle_service',
        tab=tid) }}"
      id="tgl-{{ tid }}">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <input type="hidden" name="enabled"
        value="{{ '0' if svc_enabled[tid]
          else '1' }}">
      <div class="svc-row">
        <!-- FB-200 (панель-r83): дубль имени убран — имя только в заголовке
             вкладки; статус ON/OFF, пояснение — в подсказке -->
        <span class="tip st st-lg
          {{ 'st-on' if svc_enabled[tid]
            else 'st-off' }}" tabindex="0">
          {{ 'ON' if svc_enabled[tid]
            else 'OFF' }}<span class="tip-b" role="tooltip">&#128260; Отключённый протокол останавливается сразу и &lt;b&gt;не запустится после перезагрузки&lt;/b&gt; (ENABLED=no в init-скрипте); включение — только этим переключателем. Конфигурация и ключи сохраняются.</span></span>
        <label class="switch">
          <input type="checkbox"
            aria-label="Включить или отключить службу"
            {% if svc_enabled[tid] %}checked{% endif %}
            onchange="document.getElementById(
              'tgl-{{ tid }}').submit()">
          <span class="slider"></span>
        </label>
      </div>
    </form>
    {% if nfw2_mirror and not svc_enabled[tid] %}
    <!-- r90 (решение владельца 02.11.2026, зеркальный П1): включение
         протокола при NFQWS2 Глобал/Авто — блок с force-кнопкой -->
    <div class="za-warn">
      <b>&#128680; Конфликт с NFQWS2 (Глобал/Авто)</b>
      Правила NFQWS2 затронут соединения {{ tname }} к его VPS
      и DNS-апстримы. Для одновременной работы переведите NFQWS2
      в селективный режим.
      <div class="za-actions">
        <form method="post"
          action="{{ url_for('toggle_service', tab=tid) }}"
          onsubmit="return btnLock(this)">
          <input type="hidden"
            name="csrf_token"
            value="{{ csrf_token }}">
          <input type="hidden" name="enabled" value="1">
          <input type="hidden" name="force" value="1">
          <button type="submit" class="btn btn-key">
            <span class="spinner-ring"></span>
            <span class="btn-label">Выключить NFQWS2 и включить {{ tname }}</span>
          </button>
        </form>
        <button type="button" class="btn"
          onclick="this.closest('.za-warn').style.display='none'">
          <span class="btn-label">Отмена</span>
        </button>
      </div>
    </div>
    {% endif %}
    </div>
    {% if tid == 'to' %}
    <div class="tile tile-span">
    <form method="post"
      action="{{ url_for('key_to') }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <div class="subhead">
        &#128274; obfs4</div>
      <label>Мосты (по одному)</label>
      <textarea name="obfs4_bridges"
        class="key-area"
        placeholder="obfs4 ..."></textarea>
      <div class="subhead subhead-gap">
        &#127760; Webtunnel</div>
      <label>Мосты (по одному)</label>
      <textarea name="webtunnel_bridges"
        class="key-area"
        placeholder="webtunnel ..."></textarea>
      <button type="submit"
        class="btn btn-key">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128273; Применить</span>
      </button>
    </form>
    </div>
    {% else %}
    <div class="tile">
    <form method="post"
      action="{{ url_for('key_'+tid) }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <label>Ключ {{ tname }}</label>
      <input type="text" name="key"
        placeholder="Ключ {{ tname }}">
      <button type="submit"
        class="btn btn-key">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128273; Применить ключ</span>
      </button>
    </form>
    </div>
    <div class="tile">
    <form method="post"
      action="{{ url_for('config_'+tid) }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <label>config.json</label>
      <textarea name="config_data"
        class="key-area config-entry"
        spellcheck="false"
        placeholder='{"outbounds":[...]}'></textarea>
      <p class="hint">
        Содержимое config.json.
        Inbound заменяется.</p>
      <button type="submit"
        class="btn btn-cfg">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128196; Применить конфигурацию</span>
      </button>
    </form>
    </div>
    {% endif %}
    <div class="tile tile-span">
    <div class="divider">
      <span>&#128195;
        {{ fkey }}.txt &mdash;
        {{ list_details[tid] }}</span>
    </div>
    <form method="post"
      action="{{ url_for('list_'+tid) }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <input type="hidden"
        name="rev"
        value="{{ revs[tid] }}">
      <label>Список
        ({{ ipsets[tid] }})</label>
      <textarea name="content"
        class="list-area"
        id="ta-{{ tid }}">{{ contents[tid] }}</textarea>
      <div class="counter"
        id="cnt-{{ tid }}"></div>
      <p class="hint">
        <code>#Секция</code>
        <code>site.com #заметка</code>
        <code>1.2.3.0/24</code></p>
      <button type="submit"
        class="btn btn-save">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128190; Сохранить</span>
      </button>
    </form>
    </div>
  </div>
  </div>
  {% endfor %}
  <!-- ═══ r89 (NFQWS2): вкладка «NFQWS2» — мокап r88, раунды 1-5 ═══ -->
  <div id="tab-za" role="tabpanel" tabindex="-1" aria-labelledby="btn-za" class="tab-content
    {% if active=='za' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span tile-ctl">
    <form method="post"
      action="{{ url_for('toggle_service', tab='za') }}"
      id="tgl-za">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <input type="hidden" name="enabled"
        value="{{ '0' if za.enabled else '1' }}">
      <div class="svc-row">
        <span class="tip st st-lg
          {{ 'st-on' if za.enabled else 'st-off' }}" tabindex="0">
          {{ 'ON' if za.enabled else 'OFF' }}<span class="tip-b" role="tooltip">&#128260; Отключённый протокол останавливается сразу и &lt;b&gt;не запустится после перезагрузки&lt;/b&gt; (ENABLED=no в init-скрипте); включение — только этим переключателем. Конфигурация и ключи сохраняются.</span></span>
        <label class="switch">
          <input type="checkbox"
            aria-label="Включить или отключить службу"
            {% if za.enabled %}checked{% endif %}
            onchange="document.getElementById(
              'tgl-za').submit()">
          <span class="slider"></span>
        </label>
      </div>
    </form>
    {% if za.conflicts and za.conflicts_required %}
    <div class="za-warn">
      <b>&#128680; Конфликт с включёнными туннелями</b>
      NFQWS2 (Глобал/Авто) затрагивает соединения туннелей:
      {{ za.conflicts|join(', ') }} — и DNS-апстримы.
      <div class="za-actions">
        <form method="post"
          action="{{ url_for('toggle_service', tab='za') }}"
          onsubmit="return btnLock(this)">
          <input type="hidden"
            name="csrf_token"
            value="{{ csrf_token }}">
          <input type="hidden" name="enabled" value="1">
          <input type="hidden" name="force" value="1">
          <button type="submit" class="btn btn-key">
            <span class="spinner-ring"></span>
            <span class="btn-label">Выключить протоколы и включить NFQWS2</span>
          </button>
        </form>
        <button type="button" class="btn"
          onclick="this.closest('.za-warn').style.display='none'">
          <span class="btn-label">Отмена</span>
        </button>
      </div>
    {% if za.intelliqos_suspected %}
    <div class="za-iq">&#9888;&#65039; IntelliQOS включен — правила NFQWS2 могут
      не срабатывать (flow offloading). Отключите IntelliQOS в веб-конфигураторе.</div>
    {% endif %}
    </div>
    {% elif za.conflicts %}
    <div class="za-ok">
      <b>&#9989; Совместимо с включёнными туннелями</b>
      Домены из списков туннелей ({{ za.conflicts|join(', ') }}) идут
      в туннели, остальные обрабатываются nfqws2 по user.list (селектив).
      Бот при выключенных туннелях: перенесите api.telegram.org из
      bot.txt в список ниже — сможет работать через NFQWS2.
    </div>
    {% endif %}
    {% if za.intelliqos_suspected
          and not (za.conflicts and za.conflicts_required) %}
    <div class="za-iq">&#9888;&#65039; IntelliQOS включен — правила NFQWS2 могут
      не срабатывать (flow offloading). Отключите IntelliQOS в веб-конфигураторе.</div>
    {% endif %}
    </div>

    <div class="tile">
      <div class="subhead">&#128202; Состояние</div>
      <div class="za-rows">
        <div class="za-row"><span>Версия</span><b>{{ za.version or '?' }}</b></div>
        <div class="za-row"><span>Служба</span><b class="st {{ 'st-on' if za.enabled else 'st-off' }}">{{ 'ON' if za.enabled else 'OFF' }}</b></div>
        <div class="za-row"><span>Процесс</span><b>{{ 'жив' if za.running else 'не запущен' }}</b></div>
        {% set za_mode_ru = {'list': 'Селектив', 'all': 'Глобал', 'auto': 'Авто'} %}
        <div class="za-row"><span>Режим</span><b>{{ za_mode_ru.get(za.mode, za.mode or '?') }}</b></div>
        <div class="za-row"><span>Конфликты</span><b{% if za.conflicts and za.conflicts_required %} style="color:var(--err)"{% endif %}>{{ za.conflicts|join(', ') if (za.conflicts and za.conflicts_required) else ('нет (совместимо)' if za.conflicts else 'нет') }}</b></div>
        <div class="za-row"><span>Intelli QoS</span><b{% if za.intelliqos_suspected %} style="color:var(--warn)"{% endif %}>{{ 'Включен' if za.intelliqos_suspected else 'Выключен' }}</b></div>
      </div>
    </div>

    <div class="tile">
      <div class="subhead">
        <span class="tip t-underline" tabindex="0">&#9881;&#65039; Настройка (GUI пакета)<span class="tip-b za-tip" role="tooltip">Штатный web-интерфейс nfqws2 (порт 90). Открывается в новой вкладке; доступен только из локальной сети, без пароля.</span></span>
      </div>
      <p class="za-gui-url">{{ za.gui_url }} &middot; без пароля &middot; только LAN</p>
      <a class="btn btn-key" href="{{ za.gui_url }}" target="_blank" rel="noopener"
         style="display:flex;align-items:center;justify-content:center;text-decoration:none">
        <span class="btn-label">&#127760; Открыть настройки</span>
      </a>
    </div>

    <div class="tile tile-span">
    <div class="divider">
      <span class="tip t-underline" tabindex="0">&#128279; Режим работы<span class="tip-b za-tip" role="tooltip">Селектив — обрабатывать только домены из user.list. Глобал — весь трафик, кроме exclude.list. Авто — заблокированные ресурсы определяются автоматически (auto.list).</span></span>
    </div>
    <div class="za-mode-row">
      <form method="post" action="{{ url_for('mode_za') }}" onsubmit="return btnLock(this)">
        <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
        <input type="hidden" name="mode" value="list">
        <button type="submit" class="btn rp-btn{% if za.mode == 'list' %} active{% endif %}">&#128196; Селектив</button>
      </form>
      <form method="post" action="{{ url_for('mode_za') }}" onsubmit="return btnLock(this)">
        <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
        <input type="hidden" name="mode" value="all">
        <button type="submit" class="btn rp-btn{% if za.mode == 'all' %} active{% endif %}">&#127760; Глобал</button>
      </form>
      <form method="post" action="{{ url_for('mode_za') }}" onsubmit="return btnLock(this)">
        <input type="hidden" name="csrf_token" value="{{ csrf_token }}">
        <input type="hidden" name="mode" value="auto">
        <button type="submit" class="btn rp-btn{% if za.mode == 'auto' %} active{% endif %} za-auto"><svg class="ico" viewBox="0 -960 960 960" aria-hidden="true"><path d="M408-412h146l25 73q3 8 10.5 13.5T606-320q15 0 23.5-12.5T633-359L519-661q-3-9-11-14t-17-5h-22q-9 0-17 5t-11 14L327-360q-5 14 3.5 27t24.5 13q10 0 17.5-5.5T383-340l25-72Zm18-52 52-150h4l52-150H426Zm-80 304H240q-33 0-56.5-23.5T160-240v-106l-77-78q-11-12-17-26.5T60-480q0-15 6-29.5T83-536l77-78v-106q0-33 23.5-56.5T240-800h106l78-77q12-11 26.5-17t29.5-6q15 0 29.5 6t26.5 17l78 77h106q33 0 56.5 23.5T800-720v106l77 78q11 12 17 26.5t6 29.5q0 15-6 29.5T877-424l-77 78v106q0 33-23.5 56.5T720-160H614l-78 77q-12 11-26.5 17T480-60q-15 0-29.5-6T424-83l-78-77Zm34-80 100 100 100-100h140v-140l100-100-100-100v-140H580L480-820 380-720H240v140L140-480l100 100v140h140Zm100-240Z"></path></svg><span>Авто</span></button>
      </form>
    </div>
    <p class="hint">Применяется сразу; работающая служба перезапускается.</p>
    </div>

    <div class="tile tile-span">
    <div class="divider">
      <span>&#128195;
        user.list &mdash;
        {{ list_details.za }}</span>
    </div>
    <form method="post"
      action="{{ url_for('list_za') }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <input type="hidden"
        name="rev"
        value="{{ revs.za }}">
      <label>Список
        (nfqws2)</label>
      <textarea name="content"
        class="list-area"
        id="ta-za">{{ contents.za }}</textarea>
      <div class="counter"
        id="cnt-za"></div>
      <p class="hint">
        <code>site.com</code> <code># комментарий</code>
        &mdash; по одному в строке; используется в режиме «Селектив».
        Бот без туннелей: перенесите api.telegram.org из bot.txt сюда.</p>
      <button type="submit" class="btn btn-save">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128190; Сохранить</span>
      </button>
    </form>
    </div>
  </div>
  </div>
  <div id="tab-bt" role="tabpanel" tabindex="-1" aria-labelledby="btn-bt" class="tab-content
    {% if active=='bt' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="divider">
      <!-- FB-196/FB-198 (панель-r83): описание — в подсказке, значок MD3 -->
      <span class="tip t-underline" tabindex="0">
        <svg class="ico" viewBox="0 0 24 24" aria-hidden="true" style="color:var(--primary)"><use href="#i-bot"/></svg>
        <b>Обход роутера</b>
        <span class="tip-b" role="tooltip">Выходной трафик &rarr; протокол из блока ниже (по умолчанию xray :10810).<br>&#9888;&#65039; Не IP VPS!<br>&#128204; Совпадения ОК.</span>
      </span>
    </div>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <!-- FB-196 (панель-r83): описание — в подсказке на заголовке -->
      <span class="tip t-underline" tabindex="0">
        <span>&#128737;&#65039; Протокол для трафика роутера</span>
        <span class="tip-b" role="tooltip">TCP/UDP идут через выбранный готовый туннель; если он не готов, control-plane безопасно переходит на другой готовый туннель. Если готовых нет — действует fail-closed, без прямого выхода. У TCP-only Trojan UDP явно блокируется.</span>
      </span>
    </div>
    <div class="rp-row">
      <button type="button" class="btn rp-btn" id="rp-vl"
        onclick="setRouterProto('vl',this)">VLESS :10810</button>
      <button type="button" class="btn rp-btn" id="rp-tr"
        onclick="setRouterProto('tr',this)">Trojan :10829</button>
      <button type="button" class="btn rp-btn" id="rp-hy"
        onclick="setRouterProto('hy',this)">Hysteria :10830</button>
    </div>
    <p class="hint" id="rp-status"></p>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>&#128195; bot.txt &mdash;
        {{ list_details.bt }}</span></div>
    <form method="post"
      action="{{ url_for('list_bt') }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <input type="hidden"
        name="rev"
        value="{{ revs.bt }}">
      <label>Список
        ({{ ipsets.bt }})</label>
      <textarea name="content"
        class="list-area"
        id="ta-bt">{{ contents.bt }}</textarea>
      <div class="counter"
        id="cnt-bt"></div>
      <p class="hint">
        <code>api.telegram.org</code></p>
      <button type="submit"
        class="btn btn-save">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128190; Сохранить</span>
      </button>
    </form>
    </div>
  </div>
  </div>
  <div id="tab-lk" role="tabpanel" tabindex="-1" aria-labelledby="btn-lk" class="tab-content
    {% if active=='lk' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="info-box">
      &#128269; <b>Поиск IP и CIDR</b><br>
      Введите сайт, IP, AS-номер
      или выберите сервис.</div>
    <div class="lk-presets">
      <button type="button" onclick="lkSet('telegram')">
        Telegram</button>
      <button type="button" onclick="lkSet('whatsapp')">
        WhatsApp</button>
      <button type="button" onclick="lkSet('youtube')">
        YouTube</button>
    </div>
    <div class="lookup-row">
      <input type="text" id="lk-query"
        inputmode="search" enterkeyhint="search" autocomplete="off" spellcheck="false"
        placeholder="Сайт, IP, AS32934">
      <button type="button" class="btn btn-key lookup-submit"
        onclick="doLookup()">
        <span class="spinner-ring"
          id="lk-spin"></span>
        <span class="btn-label">
          &#128269;</span>
      </button>
    </div>
    </div>
    <div class="tile tile-span">
    <div id="lk-results" class="is-hidden">
      <div class="divider">
        <span>Результаты</span></div>
      <div id="lk-info" class="result-info"></div>
      <div id="lk-status" class="result-status"></div>
      <textarea id="lk-output" class="list-area result-output" readonly spellcheck="false"></textarea>
      <div class="action-row">
        <button type="button" class="btn btn-save"
          onclick="copyLookup(event)">
          &#128203; Копировать</button>
      </div>
      <div class="divider">
        <span>&#10133; Добавить выбранное
          в список обхода</span></div>
      <div id="lk-add" class="is-hidden">
        <select id="lk-add-list" class="key-area"
          style="min-height:auto;padding:.4rem;
          margin-bottom:.5rem">
          <option value="shadowsocks">shadowsocks.txt</option>
          <option value="trojan">trojan.txt</option>
          <option value="vless" selected>vless.txt</option>
          <option value="tor">tor.txt</option>
          <option value="hysteria">hysteria.txt</option>
          <option value="bot">bot.txt</option>
        </select>
        <textarea id="lk-add-entries" class="list-area compact-area" spellcheck="false"
          placeholder="По одной записи на строку:
домены, IP, CIDR"></textarea>
        <div class="action-row action-row-result">
          <button type="button" class="btn btn-save"
            onclick="addToList()">
            &#10133; Добавить в список</button>
          <span id="lk-add-result"
            class="upd-check-result"></span>
        </div>
        <p class="hint">Дубли отсекаются
          автоматически; применение — при
          ближайшем обновлении списков.</p>
      </div>
      <p class="hint">
        …или скопируйте вручную
        в список нужного протокола.</p>
    </div>
    </div>
  </div>
  </div>
  <!-- ==== PHASE2: вкладка «Обновления» (задача 3) ==== -->
  <div id="tab-upd" role="tabpanel" tabindex="-1" aria-labelledby="btn-upd" class="tab-content
    {% if active=='upd' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <!-- FB-208 (панель-r85): одна надпись вместо двух («Обновления
         протоколов» + «Проверка новых версий»), сокращённая подсказка;
         FB-207: пояснение «Версии (архитектура…)» перенесено в подсказку
         заголовка вкладки, карточки проверки и версий объединены -->
    <div class="divider">
      <span class="tip t-underline" tabindex="0"><span>Проверка новых версий протоколов</span>
        <span class="tip-b" role="tooltip">Автопроверка — еженедельно (вс 03:00) с уведомлением в панель и в Telegram.</span></span>
    </div>
    <div class="action-row action-row-auto">
      <button type="button" class="btn btn-save action-auto" id="upd-check-btn"
        onclick="updCheck()">&#128269; Проверить сейчас</button>
      <span id="upd-check-result"
        class="upd-check-result"></span>
    </div>
    <div class="upd-out" id="upd-check-out"></div>
    <div class="ver-grid open" id="ver-grid">
    <div class="dns-label">
      Протокол &mdash; Версия</div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-xray">xray</div>
      <button type="button" class="btn upd-btn"
        id="ub-xray"
        onclick="runUpd('xray','xray')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-hysteria">hysteria</div>
      <button type="button" class="btn upd-btn"
        id="ub-hysteria"
        onclick="runUpd('hysteria','hysteria')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-shadowsocks">ss</div>
      <button type="button" class="btn upd-btn"
        id="ub-shadowsocks"
        onclick="runUpd('opkg','shadowsocks')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-trojan">trojan</div>
      <button type="button" class="btn upd-btn"
        id="ub-trojan"
        onclick="runUpd('opkg','trojan')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-tor">tor</div>
      <button type="button" class="btn upd-btn"
        id="ub-tor"
        onclick="runUpd('opkg','tor')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-dnsmasq">dnsmasq</div>
      <button type="button" class="btn upd-btn"
        id="ub-dnsmasq"
        onclick="runUpd('opkg','dnsmasq')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-nfqws2">nfqws2</div>
      <button type="button" class="btn upd-btn"
        id="ub-nfqws2"
        onclick="runUpd('nfqws2','nfqws2')">
        &#8681; Обновить</button>
    </div>
    <div class="upd-all-row" id="upd-all-row">
      <button type="button" class="btn upd-btn"
        id="ub-all"
        onclick="runUpd('all','all')">
        &#8681; Обновить всё</button>
    </div>
    <div class="upd-out" id="upd-out"></div>
    </div>
  </div>
  </div>
  </div>
  <!-- ==== PHASE2: вкладка «DNS-безопасность» (задача 4) ==== -->
  <div id="tab-dns" role="tabpanel" tabindex="-1" aria-labelledby="btn-dns" class="tab-content
    {% if active=='dns' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="divider">
      <!-- FB-195 (панель-r83): описание — в подсказке -->
      <span class="tip t-underline" tabindex="0">
        <span>&#128737; <b>Защита от подмены DoH/DoT</b></span>
        <span class="tip-b" role="tooltip">Автопроверка — не чаще 1 раза в 2 часа (cron).<br>Доверенный DoH/DoT: нет флага <code>aa</code> + валидный DNSSEC (<code>ad</code>). Выбирается самый быстрый доверенный резолвер.<br>Доверенных нет &rarr; резолв через живой туннель (VLESS &rarr; Trojan &rarr; Hysteria); всё недоступно &rarr; Google/Yandex DNS.<br>Исключения: <code>server=/зона/…</code> и Tor (:9053) не затрагиваются.</span>
      </span>
    </div>
    <div class="action-row action-row-auto">
      <button type="button" class="btn btn-save action-auto" id="spoof-check-btn"
        onclick="spoofCheck()">&#128737; Проверить DNS</button>
      <span id="spoof-api-status"
        class="upd-check-result"></span>
    </div>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>Вердикт последней проверки</span></div>
    <div id="spoof-verdict"
      class="spoof-verdict">ещё не проверялось</div>
    <div id="spoof-meta" class="spoof-meta"></div>
    </div>
    <div class="tile tile-span">
    <div class="divider"><span>Активный резолвер</span></div>
    <div id="rs-mode" class="rs-mode">нет данных</div>
    <div id="rs-primary" class="rs-primary"></div>
    <div id="rs-order" class="spoof-ports"></div>
    <div id="rs-meta" class="spoof-meta"></div>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>Системные DoT/DoH-порты (40500–40511)</span></div>
    <div id="spoof-ports" class="spoof-ports"></div>
    <div class="upd-out" id="spoof-log"></div>
    </div>
  </div>
  </div>
  <!-- ==== TAB-CFG: вкладка «Конфиги» (редактор конфигураций) ==== -->
  <div id="tab-cfg" role="tabpanel" tabindex="-1" aria-labelledby="btn-cfg" class="tab-content
    {% if active=='cfg' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="divider">
      <!-- FB-196 (панель-r83): описание — в подсказке -->
      <span class="tip t-underline" tabindex="0">
        <span>&#9881; <b>Редактор конфигураций служб</b></span>
        <span class="tip-b" role="tooltip">Полный <code>*.json</code> службы: текст разбирается парсером, записывается в боевой файл, служба перезапускается. Перед записью прежний файл сохраняется как <code>.bak</code> рядом с ним.<br>VLESS: поле <code>inbounds</code> не задаётся вручную — сервер пересобирает его под tcp+udp TPROXY.<br>Tor: мосты <code>obfs4</code>/<code>webtunnel</code> по одному в строке (разметка из мессенджеров снимается); пустое поле — снять все мосты.</span>
      </span>
    </div>
    <div class="action-row action-row-auto action-row-tight">
      <button type="button" class="btn btn-key action-auto"
        id="cfg-reload-btn" onclick="loadCfg(true)">
        &#8635; Перечитать файлы</button>
      <span id="cfg-status"
        class="upd-check-result"></span>
    </div>
    </div>
  </div>
    {% for ck, ct in [
      ('ss','Shadowsocks'),
      ('tr','Trojan'),
      ('vl','VLESS (Xray)'),
      ('hy','Hysteria')] %}
    <!-- FB-197 (панель-r83): все службы изначально свёрнуты -->
    <details class="cfg-d">
      <summary><b>{{ ct }}</b>
        <span class="cfg-path"
          id="cfg-path-{{ ck }}"></span>
        <span class="cfg-meta"
          id="cfg-meta-{{ ck }}"></span></summary>
      <textarea id="cfg-ta-{{ ck }}"
        class="cfg-ta key-area"
        spellcheck="false"
        placeholder='{"…json…"}'></textarea>
      <div class="cfg-btns">
        <button class="btn btn-key"
          onclick="cfgCheck('{{ ck }}')">
          &#10004; Проверить JSON</button>
        <button class="btn btn-save"
          id="cfg-save-{{ ck }}"
          onclick="cfgSave('{{ ck }}')">
          &#128190; Записать и перезапустить</button>
      </div>
      <div class="upd-out"
        id="cfg-out-{{ ck }}"></div>
    </details>
    {% endfor %}
    <details class="cfg-d">
      <summary><b>Tor &mdash; мосты</b>
        <span class="cfg-path"
          id="cfg-path-to"></span>
        <span class="cfg-meta"
          id="cfg-meta-to"></span></summary>
      <textarea id="cfg-ta-to"
        class="cfg-ta key-area"
        
        spellcheck="false"
        placeholder="obfs4 1.2.3.4:443 …&#10;webtunnel 1.2.3.4:443 url=…"></textarea>
      <div class="cfg-btns">
        <button class="btn btn-save"
          id="cfg-save-to"
          onclick="cfgSave('to')">
          &#128190; Сохранить мосты
          и перезапустить</button>
      </div>
      <div class="upd-out"
        id="cfg-out-to"></div>
    </details>
  </div>
</div>
<!-- FB-150 (панель-77): DNS-панель (DoT/DoH) — только во вкладке DNS;
     кнопка «Версии и обновления» убрана (версии — в «Обновлениях») -->
<div class="dns-panel" id="kzDnsPanel"{% if active != 'dns' %} style="display:none"{% endif %}>
  <button type="button" class="dns-toggle"
    onclick="toggleDns()">
    &#128268; DNS (DoT/DoH)</button>
  <div class="dns-grid" id="dns-grid">
    <div class="dns-label">DoT</div>
    {% for p in dns_dot_ports %}
    <div class="dns-port checking"
      id="dp-{{ p }}">{{ p }}</div>
    {% endfor %}
    <div class="dns-label">DoH</div>
    {% for p in dns_doh_ports %}
    <div class="dns-port checking"
      id="dp-{{ p }}">{{ p }}</div>
    {% endfor %}
    <div class="dns-label is-hidden" id="pin-label">
      Закреплённые адреса серверов</div>
    <div class="pin-box" id="pin-box"></div>
  </div>
</div>
</div>
</div>
<script>
/* Файл отдаётся роутером на каждый запрос страницы, поэтому русский
   текст пишется напрямую (страница в UTF-8), а не \uXXXX-кодами:
   так короче и не тратится время на разбор escape-последовательностей.
   Повторяющиеся операции вынесены в g/each/setCell. */
function g(i){return document.getElementById(i)}
function each(a,f){for(var i=0;i<a.length;i++)f(a[i])}
/* Переключение вкладок без перезагрузки страницы: все вкладки уже
   отрисованы в DOM. Прежний вариант (location.href) заставлял роутер
   на каждый клик заново читать все списки обхода, считать записи и
   формировать 30 КБ HTML. Теперь запрос к роутеру не уходит вовсе,
   а адрес правится через history — ссылка остаётся рабочей. */
function kzSyncTabs(){
  var i,b,btns=document.querySelectorAll('.tab-btn');
  for(i=0;i<btns.length;i++){
    b=btns[i];
    var on=b.classList.contains('active');
    b.setAttribute('aria-selected',on?'true':'false');
    b.tabIndex=on?0:-1;
  }
}
function kzTabsKeys(){
  var list=document.querySelector('.tabs');
  if(!list)return;
  list.addEventListener('keydown',function(e){
    var ts=[].slice.call(document.querySelectorAll('.tab-btn')),i,n=null,k;
    i=ts.indexOf(document.activeElement);
    if(i<0){for(k=0;k<ts.length;k++)if(ts[k].classList.contains('active')){i=k;break}}
    if(e.key==='ArrowRight')n=ts[(i+1)%ts.length];
    if(e.key==='ArrowLeft')n=ts[(i-1+ts.length)%ts.length];
    if(e.key==='Home')n=ts[0];
    if(e.key==='End')n=ts[ts.length-1];
    if(n){e.preventDefault();n.focus();go(n.id.replace('btn-',''))}
  });
}
function kzKeyForms(){
  var forms=[].slice.call(document.querySelectorAll('form[action^="/key/"]')),f;
  for(f=0;f<forms.length;f++){
    (function(form){
      var inp=form.querySelector('input[name="key"]');
      if(!inp)return;
      var btn=form.querySelector('button[type="submit"]');
      var hint=document.createElement('div');
      hint.className='kz-hint';
      inp.insertAdjacentElement('afterend',hint);
      function upd(){
        var v=inp.value.trim(),n=inp.value.length;
        if(btn)btn.disabled=!v;
        /* FB-210 (панель-r85): подсказка сокращена до «Введите ключ» */
        hint.innerHTML=v?'':'<span class="kz-err">Введите ключ</span>';
      }
      inp.addEventListener('input',upd);
      upd();
    })(forms[f]);
  }
}
function kzToast(text,warn){
  var box=document.getElementById('kzToasts');
  if(!box){
    box=document.createElement('div');
    box.id='kzToasts';
    box.setAttribute('aria-live','polite');
    document.body.appendChild(box);
  }
  var t=document.createElement('div');
  t.className='kz-toast'+(warn?' kz-warn':'');
  t.textContent=text;
  box.appendChild(t);
  /* FB-202 (панель-r83): уведомления исчезают через 5 секунд */
  setTimeout(function(){t.remove()},5000);
}
function kzDrafts(){
  /* FB-145 (У-16): черновики textarea в localStorage (дебаунс 400 мс),
     восстановление только в пустое поле + toast + «Очистить черновик»;
     после успешного сохранения (сервер вернул .msg-ok) совпадающий
     черновик удаляется */
  var tas=document.querySelectorAll('textarea[id]'),i,ta;
  for(i=0;i<tas.length;i++){ta=tas[i];
    if(ta.readOnly||ta.disabled)continue;
    (function(ta){
      var key='kzdraft:'+ta.id,t=null;
      try{t=localStorage.getItem(key)}catch(x){}
      if(t&&!ta.value){
        ta.value=t;
        if(window.kzToast)kzToast('Черновик восстановлен: '+ta.id,false);
        var clear=document.createElement('button');
        clear.type='button';clear.className='btn';
        clear.style.cssText='margin-top:6px;font-size:12px;min-height:32px;padding:4px 12px';
        clear.textContent='Очистить черновик';
        clear.onclick=function(){
          ta.value='';try{localStorage.removeItem(key)}catch(x2){}
          clear.remove();ta.focus()};
        ta.insertAdjacentElement('afterend',clear);
      }
      var tm=null;
      ta.addEventListener('input',function(){
        clearTimeout(tm);tm=setTimeout(function(){
          try{
            if(ta.value)localStorage.setItem(key,ta.value);
            else localStorage.removeItem(key)
          }catch(x){}
        },400)})
    })(ta);
  }
  var okmsg=document.querySelector('.msg-ok');
  if(okmsg){var j,a;
    for(j=0;j<tas.length;j++){a=tas[j];if(!a.value)continue;
      try{if(localStorage.getItem('kzdraft:'+a.id)===a.value)
        localStorage.removeItem('kzdraft:'+a.id)}catch(x){}}}
}
function kzEmptyState(){
  /* FB-146 (У-18): пустое состояние DNS до первой проверки */
  var dns=document.querySelector('.dns-grid');
  var panel=document.getElementById('tab-dns');
  if(!dns||!panel||dns.classList.contains('open'))return;
  var em=document.createElement('div');
  /* FB-195 (панель-r83): компактная однострочная плашка (MD3) */
  em.className='kz-note';em.id='kzEmpty';
  em.innerHTML='<svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-info"/></svg>'+
    '<span class="nt">Пока ничего не проверено — нажмите «Проверить DNS», чтобы увидеть состояние портов</span>';
  panel.insertBefore(em,panel.firstChild);
  document.addEventListener('click',function(e){
    var tt=e.target.closest?e.target.closest('.dns-toggle'):null;
    if(tt){var el=document.getElementById('kzEmpty');if(el)el.remove()}},true);
}
function kzInitUx(){
  kzSyncTabs();kzTabsKeys();kzKeyForms();kzDrafts();kzEmptyState();
  var hm=(location.hash||"").match(/#tab-([a-z]+)/);
  if(hm)go(hm[1],true);
  var m=document.querySelector('.msg'),u=document.getElementById('update-bar');
  if(m&&m.textContent.trim())kzToast(m.textContent.trim().slice(0,120),m.className.indexOf('msg-err')>=0);
  else if(u&&u.textContent.trim())kzToast(u.textContent.trim().slice(0,120),true);
}
if(document.readyState==='loading')
  document.addEventListener('DOMContentLoaded',kzInitUx);
else kzInitUx();
function go(id,nopush){
  var kzdp=document.getElementById('kzDnsPanel');
  if(kzdp)kzdp.style.display=(id==='dns')?'block':'none';
  var i,el,tabs=document.querySelectorAll('.tab-content'),
  btns=document.querySelectorAll('.tab-btn');
  for(i=0;i<tabs.length;i++)
    tabs[i].classList.remove('active');
  for(i=0;i<btns.length;i++)
    btns[i].classList.remove('active');
  el=g('tab-'+id);
  if(!el){location.href='/panel?tab='+id;return}
  el.classList.add('active');
  el=g('btn-'+id);
  if(el)el.classList.add('active');
  kzSyncTabs();
  if(!nopush&&window.history&&history.pushState)
    history.pushState({kzTab:id},'','#tab-'+id);
  window.scrollTo(0,0);
  if(id==='cfg')loadCfg(false);
  if(id==='upd')fetchVer();
  var pb=g('btn-'+id),pt=g('page-title');
  if(pb&&pt)pt.textContent=pb.textContent.trim()}
function kzFetch(btn,url,opts){
  /* FB-143 (У-13): лоадер+блокировка кнопки на время запроса,
     минимум 600 мс видимости; снятие в finally-семантике. Кнопку
     можно не передавать — берём активную (кликнувшую). Точки с
     собственными guard'ами (runUpd/_updTimer, check/_chkT) и
     фоновые опросы (jget, updPoll) не оборачиваются. */
  if(!btn){var ae=document.activeElement;
    if(ae&&ae.tagName==='BUTTON')btn=ae}
  if(btn){btn.classList.add('loading');btn.disabled=true}
  var t0=Date.now();
  function done(){
    if(!btn)return;
    var w=600-(Date.now()-t0);if(w<0)w=0;
    setTimeout(function(){
      btn.classList.remove('loading');btn.disabled=false},w)}
  return fetch(url,opts).then(
    function(r){done();return r},
    function(e){done();throw e})}
window.addEventListener('popstate',function(e){
  /* FB-144 (У-11): возврат по вкладкам; без state/hash — исходная
     вкладка сервера (kzFirstTab) */
  var id=(e.state&&e.state.kzTab)||
    ((location.hash||'').match(/#tab-([a-z]+)/)||[])[1]||
    window.kzFirstTab;
  if(id)go(id,true)});
var _kzfb=document.querySelector('.tab-btn.active');
window.kzFirstTab=_kzfb?_kzfb.id.replace('btn-',''):'ss';
function jget(u,cb){fetch(u,{credentials:'same-origin',cache:'no-store'}).then(function(r){
  if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}).then(cb).catch(function(){})}
/* Экранирование перед вставкой в innerHTML: значения приходят из
   /api/lookup и содержат пользовательский ввод (домен из поля поиска).
   Без этого строка вида "<img src=x onerror=...>.com" выполнялась
   как HTML — подтверждённый XSS. */
function esc(v){
  return String(v==null?'':v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;')}
function setCell(el,cls,txt){
  if(!el)return;el.className='dns-port '+cls;
  el.textContent=txt}

each(['ss','tr','vl','to','hy','bt'],function(id){
  var ta=g('ta-'+id),cnt=g('cnt-'+id);
  if(!ta||!cnt)return;
  function u(){cnt.textContent='Стр: '+
    ta.value.split('\n').length}
  ta.addEventListener('input',u);u()});

function btnLock(f){
  var b=f.querySelector('.btn');
  if(!b||b.classList.contains('loading'))
    return false;
  b.classList.add('loading');
  b.disabled=true;return true}

/* FB-202 (панель-r83): «✅ Готово» показывается только по завершениям
   ТЕКУЩЕЙ сессии — кэшированный done прошлой сессии при открытии
   вкладки больше не всплывает */
var _poll=null,_ld=Math.floor(Date.now()/1000);
function pollUpdate(){
  /* r95 (аудит r94, KZ94-02): прямой fetch вместо jget — busy-503 не
     глотается молча: состояние и таймер полла не ломаются, следующий
     тик повторит запрос */
  fetch('/api/update-status',{credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json()}).then(function(d){
    if(d&&d.status==='busy'){
      /* r96 (аудит r95, KZ95-04): первый busy тоже ставит таймер —
         единственный вход pollUpdate при загрузке страницы: без
         интервала «следующего тика» не было бы вовсе */
      if(!_poll)_poll=setInterval(pollUpdate,2000);
      return}
    var bar=g('update-bar'),
    now=Math.floor(Date.now()/1000);
    function stop(){if(_poll){
      clearInterval(_poll);_poll=null}}
    if(d.status==='running'){
      var e=now-(d.ts||now);if(e<0)e=0;
      bar.className='running';
      bar.textContent='\u23F3 Обновление… '+e+'с';
      bar.style.display='block';
      if(!_poll)_poll=setInterval(pollUpdate,2000);
    }else if(d.status==='done'){
      if(d.ts>_ld){_ld=d.ts;
        // F7 (аудит rev5 #1): done с сообщением (RULES MISSING, optional
        // VPN failed) — не зелёный успех: жёлтая плашка с текстом
        // предупреждения, чтобы утечка мимо правил не маскировалась.
        // F8 (аудит-6 L-1): replace убирал только «ok; » — голое «ok»
        // (типовой ответ успеха подshell-конфигуратора) само становилось
        // ложным жёлтым предупреждением. Сравниваем явно до замены.
        var _wm=(d.message||'');
        if(_wm==='ok')_wm='';
        else _wm=_wm.replace(/^ok;\s*/,'');
        if(_wm){bar.className='warn';
          bar.textContent='\u26A0\uFE0F Готово, с предупреждением: '+_wm;
        }else{bar.className='done';
          bar.textContent='\u2705 Готово';}
        bar.style.display='block';
        setTimeout(function(){
          bar.style.display='none'},5000)}
      stop();
    }else if(d.status==='error'&&d.ts&&
        (now-d.ts)<120){
      bar.className='error';
      bar.textContent='\u274C '+(d.message||'');
      bar.style.display='block';stop();
    }else{stop()}}).catch(function(){})}
pollUpdate();

/* Доступность серверов обхода: плашка показывается, пока проблема не
   устранена. Проверка выполняется в unblock_dnsmasq.sh (крон, подъём
   WAN, смена ключа), панель лишь отображает её результат. */
function pollPin(){
  jget('/api/pin-status',function(d){
    var b=g('pin-bar');
    if(!b||!d)return;
    if(d.kind==='warn'&&d.message){
      b.className='warn';
      b.textContent=d.message;
    }else if(d.kind==='ok'&&d.message){
      b.className='ok';
      b.textContent=d.message;
      setTimeout(function(){
        b.className='';b.style.display='none'},15000);
    }else{
      b.className='';b.style.display='none';
    }
  })}
var _pinPoll=null;
function startPinPoll(){
  if(_pinPoll||document.hidden)return;
  _pinPoll=setInterval(function(){if(!document.hidden)pollPin()},120000)
}
pollPin();startPinPoll();
document.addEventListener('visibilitychange',function(){
  if(document.hidden){clearInterval(_pinPoll);_pinPoll=null}
  else{pollPin();startPinPoll()}
});

var DNS_PORTS={{ dns_ports|tojson }};
var _dO=false;
var _dnsBusyTries=0;
function toggleDns(){
  var el=g('dns-grid');_dO=!_dO;
  el.className=_dO?'dns-grid open':'dns-grid';
  if(_dO)fetchDns()}
function fetchDns(){
  each(DNS_PORTS,function(p){
    setCell(g('dp-'+p),'checking',p+'…')});
  /* r94 (аудит r93, KZ93-01): прямой fetch вместо jget — busy-503 не
     глотается молча: ячейки остаются в «проверка идёт», один автоповтор
     через 3 с (только пока вкладка открыта); иная ошибка — честная
     индикация вместо вечного «checking» */
  fetch('/api/dns-status',{credentials:'same-origin',cache:'no-store'}).then(function(r){return r.json()}).then(function(d){
    if(d&&d.status==='busy'){
      if(_dnsBusyTries<1){_dnsBusyTries++;
        setTimeout(function(){if(_dO)fetchDns()},3000)}
      else{_dnsBusyTries=0;
        each(DNS_PORTS,function(p){
          setCell(g('dp-'+p),'fail',p+' — проверка занята')})}
      return}
    _dnsBusyTries=0;
    each(['dot','doh'],function(t){
      if(!d[t])return;
      each(Object.keys(d[t]),function(p){
        var info=d[t][p],
            ok=typeof info==='boolean'?info:!!info.ok,
            secure=typeof info==='object'&&!!info.secure,
            state=typeof info==='object'?(info.state||''):'',
            cls=secure?'ok':(ok?'insecure':'fail');
        setCell(g('dp-'+p),cls,
          p+(secure?' \u2713 DNSSEC':
            (ok?' \u2248 DNS':' \u2717 DNS')));
        if(g('dp-'+p)&&typeof info==='object')
          g('dp-'+p).title=state+'; '+
            (info.detail||'')})});
    /* Пин показывается, только если адрес сервера задан доменом:
       при заданном IP закреплять нечего и блок остаётся скрытым. */
    var pb=g('pin-box'),pl=g('pin-label'),
        pin=d.pinned||[];
    if(pb&&pl){
      if(pin.length){
        var t='';
        each(pin,function(x){
          t+=esc(x.host)+' \u2192 '+esc(x.ip)+'\n'});
        pb.textContent=t.replace(/\n$/,'');
        pb.className='pin-box on';
        pl.className='dns-label';
        pl.style.display='';
      }else{
        pb.className='pin-box';
        pl.style.display='none';
        pl.className='dns-label is-hidden';
      }}}).catch(function(){
    each(DNS_PORTS,function(p){
      setCell(g('dp-'+p),'fail',p+' —')})})}

var VER_NAMES=['xray','hysteria','shadowsocks',
  'trojan','tor','dnsmasq','nfqws2'];
var _vO=false;
/* ── Обновление протоколов ───────────────────────────────────────
   Скрипт работает минутами, поэтому запрос лишь стартует его,
   а прогресс подтягивается опросом /api/proto-update-status. */
var _updTimer=null;
/* Показ/скрытие кнопки обновления конкретного протокола. */
function updBtnShow(name,on){
  var b=g('ub-'+name);
  if(b)b.className='btn upd-btn'+(on?' on':'')}
/* Блокировка всех кнопок на время работы обновления. */
function updBtns(off){
  each(VER_NAMES.concat(['all']),
    function(a){var b=g('ub-'+a);
      if(b)b.disabled=off})}
function updShow(txt){
  var o=g('upd-out');if(!o)return;
  o.className='upd-out on';
  /* Вывод скрипта попадает в DOM — экранируем. */
  o.textContent=txt}
function updPoll(){
  fetch('/api/proto-update-status',
    {credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(d){
    /* r95 (аудит r94, KZ94-02): busy-503 гейта — транзит: таймер
       живёт, кнопки не разблокируются, статус не считается ошибкой */
    if(d&&d.status==='busy'){updShow('⏳ Панель занята — ждём статус обновления…');return}
    var log=d.log||'';
    var head=d.status==='running'
      ? 'Выполняется…'
      : (d.status==='done'
         ? 'Готово' : 'Ошибка: '+(d.message||''));
    updShow(head+(log?'\n\n'+log:''));
    if(d.status==='running')return;
    clearInterval(_updTimer);_updTimer=null;
    updBtns(false);
    /* Версии могли измениться — перечитываем. */
    fetchVer()})
  .catch(function(){})}
function runUpd(action,label){
  if(_updTimer)return;
  if(!confirm('Запустить обновление: '
    +(label||action)
    +'?\nСервисы будут перезапущены.'))return;
  updBtns(true);
  updShow('Запуск…');
  var b=new FormData();
  b.append('action',action);
  b.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  fetch('/update/run',
    {method:'POST',body:b,
     credentials:'same-origin'})
  .then(function(r){return r.json()
    .then(function(j){return {ok:r.ok,j:j}})})
  .then(function(res){
    if(res.j&&res.j.status==='busy'){
      /* r96 (аудит r95, KZ95-04): busy-503 — честная индикация
         вместо «неизвестная ошибка»; старт не принят, кнопки
         разблокируются */
      updShow('\u23F3 Панель занята — повторите через пару секунд');
      updBtns(false);return}
    if(!res.ok||!res.j.ok){
      updShow('Ошибка: '
        +(res.j.error||'неизвестная'));
      updBtns(false);return}
    _updTimer=setInterval(updPoll,2000);
    updPoll()})
  .catch(function(e){
    updShow('Ошибка сети: '+e);
    updBtns(false)})}
function toggleVer(){
  var el=g('ver-grid');_vO=!_vO;
  el.className=_vO?'ver-grid open':'ver-grid';
  if(_vO)fetchVer()}
var _verBusy=0;
function fetchVer(){
  each(VER_NAMES,function(n){
    setCell(g('ver-'+n),'checking',n+'…')});
  /* r96 (аудит r95, KZ95-04): прямой fetch вместо jget — busy-503
     не глотается молча: ячейки не остаются в вечном «checking»;
     один автоповтор через 2 с, затем честная индикация */
  fetch('/api/protocol-versions',
    {credentials:'same-origin',cache:'no-store'})
  .then(function(r){return r.json()})
  .then(function(d){
    if(d&&d.status==='busy'){
      if(!_verBusy){_verBusy=1;
        setTimeout(fetchVer,2000);return}
      _verBusy=0;
      /* r97 (аудит r96, KZ96-03): терминальное состояние занятости —
         явный класс fail с текстом, а не «checking» с ⏳ (прежде
         выглядело как идущая проверка, которая никогда не закончится) */
      each(VER_NAMES,function(n){
        setCell(g('ver-'+n),'fail',n+' — занято')});
      var _vw=g('upd-check-result');
      if(_vw)_vw.textContent='панель занята — повторите позже';
      return}
    _verBusy=0;
    var _ua=g('upd-arch');
    if(_ua&&d.arch)_ua.textContent=d.arch;
    if(d.ts){
      var _tt=g('upd-check-result');
      if(_tt&&!_tt.textContent)
        _tt.textContent='последняя проверка: '+fmtTs(d.ts)}
    /* FB-73 (аудит-33, R58-03): частичный провал источников —
       предупреждение видно ДАЖЕ при найденном обновлении (прежде
       поле check_failed не читалось вовсе и «✅ Всё актуально»
       маскировало недоступный GitHub/opkg). sources — per-source
       статусы (ok/fail/na) для панели. */
    if(d.check_failed){
      var _cw=g('upd-check-result'),_ps=d.sources||{},
      _bad=[],_nm={opkg:'opkg',gh_xray:'GitHub (xray)',
        gh_hysteria:'GitHub (hysteria)'};
      each(Object.keys(_nm),function(k){
        if(_ps[k]==='fail')_bad.push(_nm[k])});
      if(_cw)_cw.textContent='⚠️ проверка неполная'+(_bad.length?
        ' — недоступны: '+_bad.join(', '):'')+
        ' (статус может быть неточным)';
    }
    if(!d.versions)return;
    var u={},src={},gh=d.github_only||{},any=false;
    if(d.updates)each(d.updates,function(x){
      u[x.name]=x.available;src[x.name]=x.source});
    each(Object.keys(d.versions),function(n){
      /* github_only — справочная версия для протоколов, которые
         обновляются только через opkg. Заполняется, лишь если на
         GitHub появилась сборка под архитектуру роутера. */
      var v=d.versions[n],nv=u[n],
      /* Источник показывается рядом с версией: пользователь видит,
         откуда придёт обновление — с GitHub или из репозитория
         Entware. Для xray и hysteria выбирается более свежая. */
      s=src[n]?' ('+src[n]+')':'';
      if(nv){
        setCell(g('ver-'+n),'fail',n+': '+v+' \u2192 '+nv+s);
        /* Кнопка появляется только у того протокола, для которого
           обновление действительно найдено. */
        updBtnShow(n,true);any=true;
      }else if(gh[n]&&gh[n]!==v){
        /* Обновление доступно на GitHub, но ставится только из opkg. */
        setCell(g('ver-'+n),'ok',
          n+': '+v+' (GitHub: '+gh[n]+')');
        updBtnShow(n,false);
      }else{
        setCell(g('ver-'+n),'ok',n+': '+v);
        updBtnShow(n,false);
      }});
    /* «Обновить всё» имеет смысл лишь когда есть что обновлять. */
    var ar=g('upd-all-row');
    if(ar)ar.className=any?'upd-all-row on':'upd-all-row'})
  .catch(function(){
    /* r97 (аудит r96, KZ96-03): сетевой/не-JSON сбой (обрыв, 401,
       HTML от прокси, 500) — честная индикация вместо вечного
       «checking» (зеркало fetchDns r94, KZ93-01). Автоповтор не
       добавляем: GET-повтор при busy уже есть выше, повторяет
       пользователь */
    _verBusy=0;
    each(VER_NAMES,function(n){
      setCell(g('ver-'+n),'fail',n+' —')});
    var _vw=g('upd-check-result');
    if(_vw)_vw.textContent='не удалось получить версии'})}

/* ── PHASE2: вкладка «Обновления» ────────────────────────────
   Ручной запуск проверки версий (check_updates.sh) через общий
   фон-раннер; вкладка «DNS» — такой же запуск dns_spoof_check.sh. */
function goVer(){go('upd');fetchVer()}
var _chkT=null;
function chkPoll(kind,onDone){
  jget('/api/check-status?kind='+kind,function(d){
    var out=g(kind==='updates'
      ?'upd-check-out':'spoof-log');
    var msg=g(kind==='updates'
      ?'upd-check-result':'spoof-api-status');
    if(!d||!d.status)return;
    if(out){out.className='upd-out on';
      out.textContent=(d.log||'').slice(-3000)}
    if(msg)msg.textContent=
      d.status==='running'?'выполняется…':
      (d.status==='done'?'готово':
       d.status==='error'
        ?'ошибка: '+(d.message||''):'');
    if(d.status==='running')return;
    clearInterval(_chkT);_chkT=null;
    var btn=g(kind==='updates'
      ?'upd-check-btn':'spoof-check-btn');
    if(btn)btn.disabled=false;
    if(onDone)onDone()})}
function chkRun(kind){
  if(_chkT)return;
  var btn=g(kind==='updates'
    ?'upd-check-btn':'spoof-check-btn');
  if(btn)btn.disabled=true;
  var fd=new FormData();fd.append('kind',kind);
  fd.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  fetch('/check/run',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(j){
    if(j&&j.status==='busy'){
      /* r96 (аудит r95, KZ95-04): busy-503 — честная индикация,
         не «ошибка»; проверка не принята, кнопка разблокируется */
      var msg=g(kind==='updates'
        ?'upd-check-result':'spoof-api-status');
      if(msg)msg.textContent='\u23F3 панель занята — повторите позже';
      if(btn)btn.disabled=false;return}
    if(!j.ok){
      var msg=g(kind==='updates'
        ?'upd-check-result':'spoof-api-status');
      if(msg)msg.textContent=j.error||'ошибка';
      if(btn)btn.disabled=false;return}
    _chkT=setInterval(function(){
      chkPoll(kind,kind==='updates'
        ?fetchVer:fetchSpoof)},3000);
    chkPoll(kind,null)})
  .catch(function(){if(btn)btn.disabled=false})}
function updCheck(){chkRun('updates')}
function spoofCheck(){chkRun('dns-spoof')}

/* ── PHASE2: вкладка «DNS-безопасность» ──────────────────────
   Читает /api/dns-spoof (json dns_spoof_check.sh). */
var _SP_TEXT={
  /* FB-195 (панель-r83): короткий вердикт, только на вкладке DNS */
  'LOCAL_DNSSEC':'DNS-SEC ОК',
  'LOCAL_INSECURE':'внимание: обычный DNS без DNSSEC',
  'TUNNEL_DNS':'резолвинг через туннель',
  'BOOTSTRAP_PUBLIC':'аварийный режим: Google/Yandex DNS',
  'DNS_DEAD':'DNS недоступен',
  'unknown':'ещё не проверялось'};
function fmtTs(t){
  if(!t)return '—';
  try{return new Date(t*1000).toLocaleString()}
    catch(e){return '—'}}
function fetchSpoof(){
  jget('/api/dns-spoof',function(d){
    var v=g('spoof-verdict');if(!v)return;
    var cls='ok';
    if(d.verdict==='LOCAL_INSECURE'
       ||d.verdict==='TUNNEL_DNS')cls='warn';
    else if(d.verdict==='BOOTSTRAP_PUBLIC'
       ||d.verdict==='DNS_DEAD')cls='bad';
    v.className='spoof-verdict '+cls;
    v.textContent=_SP_TEXT[d.verdict]
      ||d.verdict||'нет данных';
    var _hd=g('hd-verdict');
    if(_hd){_hd.className='hd-pill '+cls;
      _hd.textContent=_SP_TEXT[d.verdict]||d.verdict||'нет данных';}
    var m=g('spoof-meta');
    if(m){
      var bits=[];
      bits.push('проверено: '+fmtTs(d.ts));
      if(d.fastest)bits.push('самый быстрый доверенный: '+d.fastest);
      if(d.tunnel_proto)bits.push('туннель: '+d.tunnel_proto);
      if(d.suspected_spoof&&d.suspected_spoof.length)
        bits.push('\u26A0\uFE0F подмена на портах: '
          +d.suspected_spoof.join(', '));
      if(d.bootstrap_servers&&d.bootstrap_servers.length)
        bits.push('fallback: '+d.bootstrap_servers.join(', '));
      m.textContent=bits.join(' | ')}
    var grid=g('spoof-ports');
    if(grid&&d.ports){
      var h='';
      each(Object.keys(d.ports).sort(),function(k){
        var p=d.ports[k],pc='bad',label='недоступен';
        if(p.rc===0){pc='ok';
          label='доверен, '+p.rtt+'мс'}
        else if(p.rc===2){pc='warn';
          label='без DNSSEC, '+p.rtt+'мс'}
        if(p.reason==='authoritative'){
          pc='bad';
          label='\u26A0\uFE0F ПОДМЕНА (aa)'}
        h+='<div class="spoof-port"><span>'+esc(k)
          +'</span><span class="'+pc+'">'+label
          +'</span></div>'});
      grid.innerHTML=h}
    fetchResolver()})}
var _RS_MODE={
  'LOCAL_DNSSEC':['ok','локальный шифрованный DNS (DNSSEC)'],
  'DNS_OK_NO_DNSSEC':['warn','обычный DNS без DNSSEC'],
  'LOCAL_INSECURE':['warn','обычный DNS без DNSSEC'],
  'TUNNEL_DNS':['warn','DNS через туннель'],
  'DNS_UNAVAILABLE':['bad','DNS недоступен'],
  'DNS_UNAVAILABLE_FALLBACK':['bad',
    'DNS недоступен (аварийный 40500)'],
  'BOOTSTRAP_PUBLIC':['bad',
    'аварийный режим: публичный DNS'],
  'DNS_DEAD':['bad','DNS мёртв']};
/* R6 «Активный резолвер»: читает /api/dns-resolver (решение
   последнего DNS-цикла + имена upstream'ов из show dns-proxy).
   Новых DNS-прогонов не добавляет — только чтение state-файлов. */
function fetchResolver(){
  jget('/api/dns-resolver',function(d){
    var m=g('rs-mode');if(!m||!d)return;
    if(!d.ok){
      m.className='rs-mode';
      m.textContent='нет данных — DNS-цикл ещё не выполнялся';
      return}
    var mm=_RS_MODE[d.mode]||['',d.mode||'неизвестно'];
    m.className='rs-mode '+mm[0];
    m.textContent=mm[1]+(d.tunnel?(' · '+d.tunnel):'');
    var _hm=g('hd-mode');
    if(_hm){_hm.className='hd-pill '+(mm[0]||'ghost');
      _hm.textContent=d.mode||'нет данных';}
    var _ht=g('hd-time');
    /* FB-199 (панель-r83): честная формулировка каденса проверки */
    if(_ht)_ht.textContent='Последняя проверка DNS: '+(d.ts_state?fmtTs(d.ts_state):'—');
    var pr=g('rs-primary'),pinfo=null,ix;
    if(d.ports)for(ix=0;ix<d.ports.length;ix++)
      if(d.ports[ix].port===d.primary)pinfo=d.ports[ix];
    if(pr){
      var prtext=d.primary
        ?('активный: '+d.primary
          +(pinfo&&pinfo.name?(' ('+pinfo.name+')'):'')
          +(pinfo&&pinfo.kind?(', '+pinfo.kind):'')
          +(d.primary_rtt?(' · '+d.primary_rtt+' мс'):''))
        :'активный резолвер не выбран';
      pr.textContent=prtext}
    var og=g('rs-order');
    var _fresh=!!(d.ts_spoof&&d.ts_state
      &&d.ts_spoof>d.ts_state);
    if(og){
      var h='';
      if(d.ports)for(ix=0;ix<d.ports.length;ix++){
        var p=d.ports[ix],
          sc=p.state==='secure'?'ok'
            :(p.state==='insecure'?'warn':'bad'),
          lb=(ix===0&&p.port===d.primary)
            ?'основной':('резерв '+ix),
          rt=p.rtt?(p.rtt+'мс'):'—';
        h+='<div class="spoof-port"><span>'+esc(p.port)
          +(p.kind?(' '+esc(p.kind)):'')
          +' · '+(p.name?esc(p.name)
            :'<span class="mut">без имени</span>')
          +'</span><span class="'+sc
            +(_fresh?' rs-ver':'')+'" title="'+esc(
            _fresh?'проверка свежее цикла: '+fmtTs(d.ts_spoof):'')+'">'
          +lb+' · '+rt+(_fresh?' ✓':'')+'</span></div>'}
      og.innerHTML=h
        ||'<div class="spoof-meta">порядок пуст</div>'}
    var mt=g('rs-meta');
    if(mt){
      var bits=[];
      bits.push('резерв по циклу: '+(d.ts_state?fmtTs(d.ts_state):'—'));
      bits.push('проверка портов: '+(d.ts_spoof?fmtTs(d.ts_spoof):'—'));
      if(_fresh)bits.push('\u26A0\uFE0F проверка свежее цикла —'
        +' порядок резервов пересчитается при ближайшем цикле');
      bits.push(d.names_from_ndm
        ?'имена: ndmc show dns-proxy'
        :'имена резолверов не определены (ndmc)');
      if(d.suspected&&d.suspected.length)
        bits.push('\u26A0\uFE0F подмена: '
          +d.suspected.join(', '));
      mt.textContent=bits.join(' | ')}
  })}
function lkSet(v){g('lk-query').value=v;doLookup()}
function doLookup(){
  var q=g('lk-query').value.trim();
  if(!q)return;
  var sp=g('lk-spin');
  sp.style.display='inline-block';
  var fd=new FormData();fd.append('query',q);
  fd.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  kzFetch(document.querySelector('.lookup-submit'),'/api/lookup',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(d){
    sp.style.display='none';
    g('lk-results').style.display='block';
    var dn=d.domains||[],ips=d.ips||[],
    cid=d.cidrs||[],inl=d.in_lists||{},
    miss=d.missing||[],fnd=d.found||[],
    cov=d.covered||{};
    g('lk-info').textContent='Сайты: '+dn.length+
      ' | IP: '+ips.length+
      ' | CIDR: '+cid.length;
    /* RDAP/RIPEstat-обогащение (задача 5):
       CIDR владельца, ASN, организация. */
    var ipi=d.ipinfo||{},_ik=Object.keys(ipi);
    if(_ik.length){
      var rh='<div style="margin:.4rem 0">';
      each(_ik,function(ip){
        var o=ipi[ip],parts=[];
        if(o.prefix)parts.push('префикс '+o.prefix);
        else if(o.rdap_cidr)
          parts.push('CIDR '+o.rdap_cidr);
        if(o.asn)parts.push(o.asn);
        if(o.as_holder)parts.push(o.as_holder);
        else if(o.org)parts.push(o.org);
        rh+='<div style="font-size:.75rem;'
          +'color:var(--muted)">'
          +esc(ip)+' &rarr; '
          +esc(parts.join(' | ')||'—')
          +'</div>'});
      rh+='</div>';
      g('lk-info').insertAdjacentHTML(
        'afterend',rh)}
    var h='<div style="font-size:.8rem">';
    if(fnd.length){
      h+='<div style="color:var(--green);'+
        'margin-bottom:.3rem">\u2705 В списках: '+
        fnd.length+'</div>';
      each(Object.keys(inl),function(k){
        h+='<span style="color:var(--green);'+
          'font-size:.72rem">  '+esc(k)+'.txt: '+
          esc(inl[k].join(', '))+'</span><br>'});
      var ck=Object.keys(cov);
      if(ck.length){
        h+='<div style="color:var(--accent);'+
          'font-size:.72rem;margin-top:.2rem">'+
          '\u2139\uFE0F Покрыты:</div>';
        each(ck,function(k){
          h+='<span style="color:var(--accent);'+
            'font-size:.72rem">  '+esc(k)+' \u2192 '+
            esc(cov[k])+'</span><br>'})}}
    if(miss.length)
      h+='<div style="color:var(--orange);'+
        'margin-top:.3rem">\u26A0\uFE0F Нет в '+
        'списках: '+miss.length+'</div>';
    if(!fnd.length&&!miss.length)
      h+='<span style="color:var(--muted)">'+
        'Нет данных</span>';
    g('lk-status').innerHTML=h+'</div>';
    function sortItems(a){
      var ok=[],no=[];
      each(a,function(v){
        (miss.indexOf(v)>=0?no:ok).push(v)});
      return ok.concat(no)}
    function mark(v){
      if(cov[v])return v+' #\u2705 '+cov[v];
      return v+(miss.indexOf(v)>=0?
        ' #\u26A0\uFE0F':' #\u2705')}
    var lines=[];
    function push(arr,title){
      if(!arr.length)return;
      if(lines.length)lines.push('');
      lines.push('#'+title);
      each(arr,function(v){lines.push(mark(v))})}
    var d1=sortItems(dn);
    if(d1.length){lines.push('#'+q);
      each(d1,function(v){lines.push(mark(v))})}
    push(sortItems(ips),q+' IP');
    push(sortItems(cid),q+' CIDR');
    g('lk-output').value=lines.join('\n');
    /* Форма «добавить в список»: сырые значения без пометок,
       сначала то, чего нет в списках. */
    var raw=[],_seen={};
    function _push(v){
      if(v&&!_seen[v]){_seen[v]=1;raw.push(v)}}
    each(sortItems(dn),_push);
    each(sortItems(ips),_push);
    each(sortItems(cid),_push);
    g('lk-add-entries').value=raw.join('\n');
    g('lk-add').style.display=
      raw.length?'block':'none';
    g('lk-add-result').textContent='';
  }).catch(function(e){
    sp.style.display='none';
    alert('\u274C '+e)})}

function addToList(){
  var t=g('lk-add-entries').value.trim();
  if(!t)return;
  var fd=new FormData();
  fd.append('list',g('lk-add-list').value);
  fd.append('entries',t);
  fd.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  kzFetch(document.querySelector('#lk-add .btn-save'),'/api/lookup-add',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(j){
    var m=g('lk-add-result');
    /* r95 (аудит r94, KZ94-05): busy-503 — честная пометка вместо
       общего «❌ ошибка»; ввод пользователя сохраняется */
    if(j&&j.status==='busy'){m.textContent='\u23F3 Панель занята — повторите через пару секунд (ввод сохранён)';return}
    if(j.ok){m.textContent='\u2705 '+(j.message||'добавлено')
      +(j.warning?' \u26A0 '+j.warning:'')}
    else{m.textContent='\u274C '+(j.error||'ошибка')}})
  .catch(function(e){
    g('lk-add-result').textContent='\u274C '+e})}

function copyLookup(ev){
  var ta=g('lk-output');
  ta.select();
  ta.setSelectionRange(0,ta.value.length);
  try{
    document.execCommand('copy');
    var b=(ev||window.event).target,
    old=b.textContent;
    b.textContent='\u2705 Скопировано';
    setTimeout(function(){
      b.textContent=old},2000)
  }catch(e){}}

/* ── TAB-CFG: вкладка «Конфиги» ────────────────────────────
   Чтение/запись боевых конфигов служб через /api/cfg. Содержимое
   текстовых полей перетирается ответом сервера только при явном
   «Перечитать файлы» или после успешной записи — иначе несохранённые
   правки пользователя затирались бы фоновой перезагрузкой. */
var _CFGKIND={ss:'json',tr:'json',vl:'json',
  hy:'json',to:'bridges'};
var _CFGLOADED=false;
function loadCfg(force){
  if(_CFGLOADED&&!force)return;
  var st=g('cfg-status');
  if(st)st.textContent='чтение…';
  jget('/api/cfg',function(d){
    _CFGLOADED=true;
    if(st)st.textContent='';
    if(!d||!d.items){if(st)
      st.textContent='нет данных';return}
    for(var k in d.items){var it=d.items[k],
      ta=g('cfg-ta-'+k),me=g('cfg-meta-'+k),
      pa=g('cfg-path-'+k);
      if(pa)pa.textContent=it.path||'';
      if(ta&&(!ta.value||force))
        ta.value=it.content||'';
      if(me)me.textContent=it.exists
        ?fmtTs(it.mtime)
        :(it.error||'файла нет')}})}
function cfgCheck(k){
  var out=g('cfg-out-'+k),ta=g('cfg-ta-'+k);
  if(!out||!ta)return;
  out.className='upd-out on';
  if(_CFGKIND[k]!=='json'){
    out.textContent='мосты проверяются при записи';return}
  try{JSON.parse(ta.value);
    out.textContent='✔ JSON корректен'}
  catch(e){out.textContent='✘ JSON: '+e.message}}
function cfgSave(k){
  var ta=g('cfg-ta-'+k),out=g('cfg-out-'+k),
    btn=g('cfg-save-'+k);
  if(!ta||!out)return;
  out.className='upd-out on';
  if(_CFGKIND[k]==='json'){
    try{JSON.parse(ta.value)}
    catch(e){
      out.textContent='✘ JSON: '+e.message;return}}
  if(!window.confirm('Перезаписать конфигурацию '
     +'и перезапустить службу?'))return;
  if(btn)btn.disabled=true;
  out.textContent='запись…';
  var fd=new FormData();
  fd.append('content',ta.value);
  fd.append('csrf_token',document.querySelector(
    'input[name=csrf_token]').value);
  kzFetch(btn,'/api/cfg/'+k,{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(j){
    out.textContent=j.ok
      ?('✔ сохранено; '+(j.restart_ok
          ?'служба перезапущена'
          :'✘ перезапуск: '+(j.error||'?'))
        +(j.warnings&&j.warnings.length
          ?'\n⚠ '+j.warnings.join('; '):'')
        +(j.bak?'\nрезервная копия: '+j.bak:''))
      :('✘ '+(j.error||'ошибка записи'));
    if(j.ok){_CFGLOADED=false;loadCfg(true)}})
  .catch(function(){
    out.textContent='✘ ошибка связи с панелью'})
  .then(function(){if(btn)btn.disabled=false})}

/* Переключатель протокола для unblockrouter (вкладка «Бот»).
   Выбор хранится в /opt/etc/unblock/router_proto; бэкенд после записи
   сам перестраивает правила хуком — здесь только подсветка и статус. */
function paintRp(d){
  if(!d)return;
  each(['vl','tr','hy'],function(k){
    var b=g('rp-'+k);if(!b)return;
    b.className='btn rp-btn'+(d.proto===k?' active':'');
    if(d.installed&&!d.installed[k]){
      b.disabled=true;b.title='пакет не установлен'}
    else{
      b.disabled=false;
      b.title=d.ready&&d.ready[k]===false
        ?'локальный proxy-порт не готов по свежему snapshot':''}});
  var s=g('rp-status'),st=d.state||'unknown',
    eff=d.effective||d.proto||'vl',txt='выбран: '+(d.proto||'vl');
  if(st==='ready')txt+=' · local listener готов';
  else if(st==='fallback')txt+=' · tunnel failover: '+eff;
  else if(st==='blocked')txt+=' · нет готового туннеля, fail-closed';
  else txt+=d.status_stale
    ?' · статус hook устарел/отсутствует, состояние неизвестно'
    :' · состояние ещё не определено hook-ом';
  if(d.status_age!==null&&d.status_age!==undefined)
    txt+=' · возраст '+d.status_age+'с';
  if(s)s.textContent=txt}
function loadRouterProto(){jget('/api/router-proto',paintRp)}
function setRouterProto(p,btn){
  if(!confirm('Переключить трафик роутера (unblockrouter) на '
    +p.toUpperCase()
    +'?\nПравила будут перестроены.'))return;
  var s=g('rp-status');
  if(s)s.textContent='переключаю…';
  var fd=new FormData();
  fd.append('proto',p);
  fd.append('csrf_token',document.querySelector(
    'input[name=csrf_token]').value);
  kzFetch(btn,'/api/router-proto',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()
    .then(function(j){return {ok:r.ok,j:j}})})
  .then(function(res){
    if(res.j&&res.j.ok){loadRouterProto();
      if(s)s.textContent='переключено на '+p
        +' · правила применены';}
    else if(s)s.textContent='\u2718 '
      +((res.j&&res.j.error)||'ошибка')})
  .catch(function(){if(s)s.textContent=
    '\u2718 ошибка связи с панелью'})}

/* Первичное наполнение новых вкладок */
fetchSpoof();
if(g('tab-bt')&&g('tab-bt').className.indexOf('active')>=0)
  loadRouterProto();
if(g('tab-cfg')&&g('tab-cfg').className
   .indexOf('active')>=0)loadCfg(false);
g('lk-query').addEventListener('keydown',
  function(e){if(e.key==='Enter')doLookup()});
</script></body></html>'''


def _list_snap(fp):
    """FB-63 (аудит-32, R55-01) → FB-70 (аудит-33, K58-1/R58-02):
    revision редактора списка = SHA-256 байтов содержимого на момент
    отрисовки вкладки (прежде mtime_ns: mtime скачет от касаний без
    смены текста и может не смениться при перезаписи того же текста).
    POST с чужим rev = вкладка устарела (правка успела прийти из
    другой вкладки/бота/lookup-add): явный конфликт вместо молчаливой
    потери устаревшим полным текстом более свежих записей (полная
    замена не мержится).
    FB-86 (аудит-35, R59-02/K60-02): НЕТ отдельного _list_rev — файл
    читается ОДИН раз: один и тот же снимок байтов даёт и revision
    (SHA-256), и текст вкладки. Прежние независимые read_file_text +
    _list_content_rev читали файл дважды: между чтениями правка из
    другой вкладки успевала изменить файл, и страница показывала
    текст одной версии с revision другой — POST «обновления» затирал
    свежие записи, не будучи замеченным как конфликт. Текст — с той
    же семантикой, что read_file_text (utf-8, rstrip('\\n\\r'));
    ошибки чтения = пустой снимок (rev пустого байтового набора,
    text='')."""
    try:
        with open(fp, 'rb') as f:
            raw = f.read()
    except OSError:
        raw = b''
    rev = hashlib.sha256(raw).hexdigest()
    text = raw.decode(
        'utf-8', errors='replace').rstrip('\n\r') if raw else ''
    return text, rev


# FB-136 (вариант A): заголовки вкладок и группа рельса для оболочки.
PANEL_TABS = {
    'ss': ('Shadowsocks', 'proto'),
    'tr': ('Trojan', 'proto'),
    'vl': ('VLESS', 'proto'),
    'to': ('Tor', 'proto'),
    'hy': ('Hysteria', 'proto'),
    # r89 (NFQWS2): последняя вкладка группы «Протоколы» (мокап r88).
    'za': ('NFQWS2', 'proto'),
    'bt': ('BOT', 'bot'),
    'lk': ('Поиск', 'search'),
    'upd': ('Обновления', 'settings'),
    'dns': ('DNS', 'dns'),
    'cfg': ('Конфигурации', 'settings'),
}


def _render(active='ss'):
    # FB-136 (вариант A): дашборд — главная; вкладки проекта —
    # MD3-обёртка (рельс+топбар) с прежней панелью в same-origin
    # iframe /panel?tab=…: MD3-хром не пропадает, логика вкладок
    # не меняется (этап 1 сохранён, структура проекта — тоже).
    if active == 'dash':
        return render_template_string(
            DASH_TEMPLATE,
            csrf_token=generate_csrf())
    title, group = PANEL_TABS.get(
        active, ('Панель', 'apps'))
    return render_template_string(
        SHELL_TEMPLATE,
        tab=active,
        tab_title=title,
        rail_group=group)


def _render_legacy(active='ss'):
    # Прежнее тело _render: полноценно работает и напрямую (/panel),
    # и внутри iframe оболочки.
    contents, lc = {}, {}
    ld, ipsets = {}, {}
    revs = {}
    km = {
        'ss': 'shadowsocks',
        'tr': 'trojan',
        'vl': 'vless',
        'to': 'tor',
        'hy': 'hysteria'}
    # FB-86 (аудит-35, R59-02/K60-02): каждый файл читается ОДИН раз —
    # _list_snap возвращает и текст вкладки, и revision из одного
    # снимка байтов (см. docstring _list_snap).
    for k in ('ss', 'tr', 'vl',
              'to', 'hy'):
        fk = km[k]
        t, rv = _list_snap(BYPASS_FILES[fk])
        contents[k] = t
        revs[k] = rv
        d, ip, cidr = _count_entries(t)
        lc[k] = d + ip + cidr
        ld[k] = _format_details(
            d, ip, cidr)
        ipsets[k] = BYPASS_IPSETS[fk]
    bt, bt_rv = _list_snap(BOT_BYPASS_FILE)
    contents['bt'] = bt
    revs['bt'] = bt_rv
    d, ip, cidr = _count_entries(bt)
    lc['bt'] = d + ip + cidr
    ld['bt'] = _format_details(
        d, ip, cidr)
    ipsets['bt'] = BYPASS_IPSETS['bot']
    # r90 (зеркальный П1): NFQWS2 включён и режим Глобал/Авто —
    # на вкладках выключенных туннелей показывается блокирующее
    # предупреждение с force-кнопкой.
    try:
        import utils as _u
        nfw2_mirror = _u.nfqws2_blocks_tunnels()
    except Exception:  # noqa: BLE001
        nfw2_mirror = False
    # r89 (NFQWS2): данные вкладки za (мокап r88, раунды 1-5).
    za = _nfqws2_status()
    za_t, za_rv = _list_snap(
        config.list_files.get('nfqws2', ''))
    contents['za'] = za_t
    revs['za'] = za_rv
    d, ip, cidr = _count_entries(za_t)
    lc['za'] = d + ip + cidr
    ld['za'] = _format_details(
        d, ip, cidr)
    return render_template_string(
        PAGE_TEMPLATE,
        active=active,
        nfw2_mirror=nfw2_mirror,
        za=za,
        contents=contents,
        revs=revs,
        list_counts=lc,
        list_details=ld,
        ipsets=ipsets,
        dns_dot_ports=DNS_PORTS_DOT,
        dns_doh_ports=DNS_PORTS_DOH,
        dns_ports=DNS_PORTS_DOT + DNS_PORTS_DOH,
        svc_enabled=get_services_enabled(),
        csrf_token=generate_csrf())


def _read_proto_update():
    """Статус фонового обновления протоколов.
    r95 (аудит r94, KZ94-05): корень/статус/ts валидируются —
    повреждённый файл (список/строка вместо объекта, строковый или
    NaN/Infinity ts) даёт безопасный объект, а не AttributeError →
    HTTP 500; нечисловой ts трактуется как отсутствующий, поэтому
    вечный «running» без таймаута невозможен."""
    try:
        with open(PROTO_UPD_STATUS, 'r') as f:
            d = json.load(f)
    except Exception:
        return {'status': 'idle', 'ts': 0,
                'message': '', 'log': ''}
    if not isinstance(d, dict):
        return {'status': 'error', 'ts': 0,
                'message': 'Файл статуса повреждён (не объект)',
                'log': ''}
    if d.get('status') not in (
            'running', 'done', 'error', 'idle'):
        d['status'] = 'error'
        d['message'] = (d.get('message')
                        or 'Неизвестный статус')
    _ts = d.get('ts')
    # r96 (аудит r95, KZ95-03): метка — конечное число в допустимом
    # диапазоне: гигантский int (10**400) прежде проходил проверку
    # типов и ронял маршрут OverflowError'ом (HTTP 500); будущая
    # метка (больше +60 c) держала вечный «running» — age<0, таймаут
    # не срабатывал, старт блокировался. Некорректная метка
    # трактуется как отсутствующая (running уходит в «Таймаут»).
    try:
        _tsf = float(_ts)
    except (TypeError, ValueError, OverflowError):
        _tsf = None
    if (isinstance(_ts, bool)
            or _tsf is None
            or _tsf != _tsf
            or _tsf == float('inf')
            or _tsf == float('-inf')
            or _tsf > time.time() + 60.0):
        d['ts'] = 0
    # Процесс мог быть убит, не успев записать финальный статус.
    if d.get('status') == 'running':
        age = time.time() - d.get('ts', 0)
        if age > PROTO_UPD_TIMEOUT:
            d['status'] = 'error'
            d['message'] = 'Таймаут'
    d['log'] = _tail_file(PROTO_UPD_LOG)
    return d


def _tail_file(path, limit=4000):
    """rev35 (R35-6, аудит-6 P2.2): хвост файла читается seek'ом от
    конца — весь лог больше не грузится в память (большой per-run лог
    на слабом роутере раздувал RAM при каждом опросе статуса)."""
    try:
        with open(path, 'rb') as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - limit), os.SEEK_SET)
            data = f.read(limit)
        return data.decode('utf-8', 'replace')
    except Exception:
        return ''


# FB-168 (аудит-46, A-R79-03): single-flight старт обновления
# протоколов — образец FB-157 списочной обёртки (_UPDATE_START_LOCK
# протокольный путь не защищал: два запроса оба читали idle и оба
# запускали wrapper, ревью r79 — 2×Popen на общих status/log).
_PROTO_UPD_LOCK = threading.Lock()

# r98 (аудит r97, AUD-R97-01/KZ97-01 — решение владельца 04.11.2026):
# межпроцессный guard статуса — flock(2) по СТАБИЛЬНОМУ lock-файлу
# (никем не переименовывается и не удаляется — в отличие от
# каталогов, которые реклеймеры переименовывают). Прежний mkdir-guard
# (r97) оставлял окно mkdir→запись-owner: публикация «по имени»
# попадала в чужой каталог — ДВА токена (проба E аудита r97), а
# ash-реклейм сверял только PID — same-PID подмена удаляла свежий
# guard (проба G). flock: взаимоисключение гарантирует ядро;
# освобождается автоматически при гибели держателя — слой
# stale-реклейма не нужен вовсе, «подвисший guard» невозможен;
# fcntl — stdlib Linux-CPython (Entware-профиль проекта).
# ash-финализатор обёртки использует тот же lock-файл через
# python-хелпер (BusyBox-апплет flock на прошивке Keenetic не
# гарантируется; python3 — жёсткая зависимость панели).
_PROTO_UPD_GUARD = PROTO_UPD_STATUS + '.lockfile'


def _kz_proto_guard_acquire():
    """fd — guard взят; False — занят/недоступен. Секция держится
    миллисекунды: чтение статуса, проверка claim, атомарная замена;
    НИКАКИХ ожиданий/долгих операций внутри. Lock-файл открывается
    O_CREAT 0600 + O_NOFOLLOW: подложный симлинк → отказ
    (fail-closed, как у mkdir-модели r97)."""
    import fcntl
    try:
        fd = os.open(
            _PROTO_UPD_GUARD, os.O_RDWR | os.O_CREAT
            | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    except OSError:
        return False
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        return False
    return fd


def _kz_proto_guard_release(token=None):
    """Снятие guard: flock LOCK_UN + close. token — fd от acquire;
    постороннее значение безопасно игнорируется."""
    if token is None:
        return
    import fcntl
    try:
        fcntl.flock(token, fcntl.LOCK_UN)
    except (OSError, TypeError):
        pass
    try:
        os.close(token)
    except (OSError, TypeError):
        pass


def _kz_proto_guard(timeout=2.0):
    """acquire с коротким спином (guard держат миллисекунды):
    False по таймауту — вызывающие ветки отказывают в безопасную
    сторону (старт → честный отказ, error-публикация → False,
    финализатор → не публикует, чужой статус не трогается)."""
    _deadline = time.monotonic() + timeout
    while True:
        tok = _kz_proto_guard_acquire()
        # r99 (аудит r98, AUD-R98-03): отказ — ТОЛЬКО False (sentinel);
        # fd 0 при закрытом stdin — ВАЛИДНЫЙ lock, truthiness его
        # терял: спин до таймаута и утечка lock до завершения
        # процесса (прежде «if tok:»)
        if tok is not False:
            return tok
        if time.monotonic() >= _deadline:
            return False
        time.sleep(0.05)


def _kz_proto_publish_error(action, message, claim=None):
    """FB-168/FB-181 (аудит-46/47): best-effort атомарная публикация
    error-статуса протокольного обновления — при любом отказе запуска
    или подготовки статус не должен застревать в «running» до
    stale-таймаута 900 с; собственный temp убирается и при провале
    публикации, осиротевших .wtmp не остаётся.
    FB-187 (аудит-48, A-R81-PROTO-02/KZ81-02): возвращает True при
    успешной публикации, False — если не удалось (persistent ENOSPC
    и т.п.): вызывающий снимает running-клейм этой попытки, чтобы
    повтор не блокировался таймаутом 900 секунд.
    r95 (аудит r94, KZ94-06/опция Е — решение владельца 03.11.2026):
    чужой живой running-клейм не перезаписывается — свежий running
    НЕ нашей попытки (claim не совпал, включая running дочернего
    процесса без claim) остаётся нетронутым; прежде os.replace
    заменял любой статус безусловно (межпроцессный сценарий вне
    штатного singleton, закрывается по решению владельца).
    r97 (аудит r96, KZ96-02 — решение владельца 04.11.2026):
    межпроцессный guard: проверка claim и публикация — ОДНА
    критическая секция (прежде compare→replace окно позволяло
    вставить свежий чужой running между проверкой и os.replace и
    затем затереть его); guard не взят за таймаут → False —
    безопасная сторона, чужой статус не трогается.
    r98 (аудит r97, AUD-R97-01): примитив guard — flock(2) по
    стабильному lock-файлу (mkdir-модель допускала два токена);
    токен секции — fd."""
    _g = _kz_proto_guard()
    if _g is False:
        return False
    try:
        try:
            with open(PROTO_UPD_STATUS, 'r') as f:
                _cur = json.load(f)
            if (isinstance(_cur, dict)
                    and _cur.get('status') == 'running'
                    and (claim is None
                         or _cur.get('claim') != claim)):
                # r96 (аудит r95, KZ95-04): claim=None — нет
                # доказательства владения: ЛЮБОЙ свежий running не
                # перезаписывается (контракт докстринга; прежде
                # «running без claim» трактовался как свой и
                # затирался).
                # r96 (аудит r95, KZ95-02): свежесть — двусторонняя
                # рамка: будущая метка (больше +60 c) свежей НЕ
                # считается, арифметика защищена от гигантских int.
                _cts = _cur.get('ts')
                try:
                    _age = time.time() - float(_cts)
                except (TypeError, ValueError, OverflowError):
                    _age = None
                if (_age is not None
                        and not isinstance(_cts, bool)
                        and _age == _age
                        and -60.0 <= _age <= PROTO_UPD_TIMEOUT):
                    return True
        except (OSError, ValueError):
            pass
        _etmp = None
        try:
            _efd, _etmp = tempfile.mkstemp(
                prefix=PROTO_UPD_STATUS + '.wtmp.', dir='/tmp')
            with os.fdopen(_efd, 'w') as f:
                json.dump({'status': 'error',
                           'ts': int(time.time()),
                           'action': action,
                           'message': message}, f)
            os.replace(_etmp, PROTO_UPD_STATUS)
            return True
        except OSError:
            if _etmp is not None:
                try:
                    os.unlink(_etmp)
                except OSError:
                    pass
            return False
    finally:
        _kz_proto_guard_release(_g)


def start_proto_update(action):
    """Запускает update_protocols.sh в фоне.

    Скрипт работает минутами, поэтому HTTP-запрос его не ждёт:
    панель опрашивает /api/proto-update-status.
    """
    if action not in ('xray', 'hysteria', 'nfqws2',
                      'opkg', 'all'):
        raise ValueError('action')

    # FB-168: повторная проверка внутри lock — проигравший
    # перечитывает статус и получает честный 409 (образец
    # FB-157); shell-lock update_protocols.sh — второй барьер.
    with _PROTO_UPD_LOCK:
        st = _read_proto_update()
        if st.get('status') == 'running':
            age = int(time.time()
                      - st.get('ts', 0))
            raise RuntimeError(
                f'Обновление уже идёт ({age}с)')

        sc = config.paths.get(
            'update_protocols',
            '/opt/bin/update_protocols.sh')
        if not os.path.exists(sc):
            raise FileNotFoundError(sc)

        # FB-181 (аудит-47, A-R80-PROTO-01/B-R80-03): публикация
        # «running» — обязательное предусловие запуска. Прежде провал
        # записи проглатывался, и Popen запускался без статуса:
        # single-flight слеп (второй запрос запускал второй wrapper),
        # temp-файлы оставались осиротевшими.
        # FB-187 (аудит-48, A-R81-PROTO-02/KZ81-02): ВСЕ временные
        # ресурсы готовятся ДО публикации «running» — файл результата
        # обёртки и лог открываются раньше; отказ подготовки = статуса
        # нет вовсе, нечему застревать (прежде второй mkstemp ПОСЛЕ
        # публикации при ENOSPC оставлял «running» до таймаута 900 с,
        # а best-effort error падал в том же ENOSPC).
        _ptmp = None
        tmp_status = None
        # r93 (аудит r92, KZ92-03/E): метка нашей «running»-публикации
        # — сверяется перед снятием клейма (см. ветку Popen-отказа).
        # r95 (аудит r94, KZ94-06/E): случайный claim-id — уникален
        # даже при совпадении action и секунды публикации.
        _claim_ts = None
        _claim_id = None
        log_fd = -1
        try:
            try:
                log_fd = os.open(
                    PROTO_UPD_LOG,
                    os.O_WRONLY | os.O_CREAT | os.O_TRUNC
                    | getattr(os, 'O_NOFOLLOW', 0))
            except OSError as e:
                # лог не критичен: без него обёртка пишет в DEVNULL
                web_log(f'proto log open (symlink?): {e}')
                log_fd = -1
            # TW-1 (аудит-20): уникальные временные файлы (O_EXCL) +
            # os.replace/mv — фиксированные пути в /tmp не открываются
            # на запись напрямую (symlink).
            _pfd, tmp_status = tempfile.mkstemp(
                prefix=PROTO_UPD_STATUS + '.wtmp.',
                dir='/tmp')
            os.close(_pfd)
            _pfd, _ptmp = tempfile.mkstemp(
                prefix=PROTO_UPD_STATUS + '.wtmp.',
                dir='/tmp')
            _claim_ts = int(time.time())
            import secrets as _sec
            _claim_id = _sec.token_hex(8)
            with os.fdopen(_pfd, 'w') as f:
                json.dump({
                    'status': 'running',
                    'ts': _claim_ts,
                    'action': action,
                    'claim': _claim_id,
                    'message': 'Запуск...'}, f)
            # r97 (аудит r96, KZ96-02 — решение владельца
            # 04.11.2026): публикация running — под межпроцессным
            # guard с ПОВТОРНОЙ проверкой внутри секции: конкурент
            # (другой процесс панели/бота) мог запустить свой прогон
            # после нашей первой проверки — threading.Lock процесса
            # его не видит; его свежий running не затираем (409,
            # образец FB-168). Guard не взят → честный отказ.
            _g = _kz_proto_guard()
            if _g is False:
                raise RuntimeError(
                    'Статус обновления занят — повторите')
            try:
                try:
                    with open(PROTO_UPD_STATUS, 'r') as f:
                        _cur = json.load(f)
                    if (isinstance(_cur, dict)
                            and _cur.get('status') == 'running'):
                        _cts = _cur.get('ts')
                        try:
                            _age = time.time() - float(_cts)
                        except (TypeError, ValueError, OverflowError):
                            _age = None
                        if (_age is not None and _age == _age
                                and -60.0 <= _age
                                <= PROTO_UPD_TIMEOUT):
                            raise RuntimeError(
                                'Обновление уже идёт')
                except (OSError, ValueError):
                    pass
                os.replace(_ptmp, PROTO_UPD_STATUS)
                _ptmp = None
            finally:
                _kz_proto_guard_release(_g)
        except RuntimeError:
            # r97 (KZ96-02): конкурент выиграл гонку старта (или
            # guard занят) — попытка не публикуется, ресурсы этой
            # попытки убираем; error не публикуем: наш running так
            # и не появился, чужой не трогаем
            if log_fd >= 0:
                os.close(log_fd)
            for _t in (_ptmp, tmp_status):
                if _t is not None:
                    try:
                        os.unlink(_t)
                    except OSError:
                        pass
            raise
        except OSError as e:
            web_log(f"protocol update preparation: {e}")
            if log_fd >= 0:
                os.close(log_fd)
            for _t in (_ptmp, tmp_status):
                if _t is not None:
                    try:
                        os.unlink(_t)
                    except OSError:
                        pass
            _kz_proto_publish_error(
                action,
                f'Не удалось зафиксировать статус запуска: {e}',
                claim=_claim_id)
            raise

        # TW-1 (аудит-20): sh -c с argv вместо файла-обёртки в /tmp.
        # FB-181 (аудит-47, A-R80-PROTO-01/B-R80-03): сбой Popen не
        # оставляет ложного «running» — атомарный error с диагнозом
        # (образец FB-127 списочной обёртки); fd закрывается ровно
        # один раз в finally.
        # FB-121 (аудит-42): как и в обёртке обновления списков — значения
        # через окружение, а не хвостовые argv «sh -c body имя арг…» (форма
        # не поддерживается Keenetic-прошивкой — см. комментарий у первой
        # обёртки; кнопка «Обновить протоколы» зависала так же).
        body = '''SC="$KZ_SC"; ACT="$KZ_ACT"; ST="$KZ_ST"; TMP="$KZ_TMP"
# r100 (аудит r99, KZ99-01): cleanup-страховка ДО env-проверки —
# ранний fail-closed выход не должен оставлять родительский temp
# (на роутере /tmp — tmpfs в ОЗУ; этот trap прежде ставился ниже
# и не срабатывал при exit 3 из аварийной ветки).
[ -n "$TMP" ] && trap 'rm -f "$TMP"' 0 1 2 15
# FB-124 (аудит-42): самоконтроль — пустая переменная = нештатное
# окружение: error-статус и выход, а не тихая смерть (см. первую обёртку).
if [ -z "$SC" ] || [ -z "$ACT" ] || [ -z "$ST" ] || [ -z "$TMP" ] || [ -z "$KZ_CLAIM" ]; then
    # r99 (аудит r98, KZ98-01): аварийная ветка fail-closed — общий
    # статус-файл НЕ трогаем: прежде прямой printf > ST писал мимо
    # flock и мог затереть чужой свежий running, а пустой KZ_CLAIM
    # означал «пропустить сверку» и публиковал поверх любого
    # статуса. Диагностика — только в stderr (лог обёртки), rc=3.
    echo "keenzoo: обёртка протоколов не получила KZ_*-переменные (FB-121/FB-124, KZ_CLAIM обязателен)" >&2
    exit 3
fi
# TS-1 (аудит-22): страховка от остатка при убийстве прогона.
trap 'rm -f "$TMP"' 0 1 2 15
"$SC" "$ACT"
RC=$?
TS=$(date +%s)
if [ "$RC" -eq 0 ]; then S=done; M="Готово"; else S=error; M="Код возврата $RC"; fi
# r96 (аудит r95, KZ95-03): публикация финала — только пока статус
# всё ещё принадлежит ЭТОМУ прогону (claim в running-публикации
# родителя): прежний безусловный mv позволял «долгоигравшему» child
# (старше таймаута 900 c) затереть running нового прогона своим
# устаревшим «done»
# r98 (аудит r97, AUD-R97-01/KZ97-01 — решение владельца 04.11.2026):
# публикация финала — python-хелпером под flock(2) по СТАБИЛЬНОМУ
# lock-файлу (никем не переименовывается/не удаляется): сверка claim
# (точное JSON-поле, не подстрока grep) и атомарная замена — одна
# kernel-сериализованная секция. Прежний mkdir-guard (r97) имел окна
# mkdir→запись-owner (публикация «по имени» попадала в чужой каталог
# — два токена) и реклейм по одному PID (same-PID подмена удаляла
# свежий guard). BusyBox-апплет flock на прошивке Keenetic не
# гарантируется, python3 — жёсткая зависимость панели: один
# кратковременный процесс на завершение обновления. Коды хелпера:
# 0 — опубликовано; 24 — чужой claim; 3 — guard занят (fail-closed,
# чужой статус не трогаем; temp уберёт trap TS-1).
# r99 (аудит r98, AUD-R98-02): интерпретатор работающей панели —
# KZ_PY=sys.executable (S99 find_python допускает versioned
# /opt/bin/python3.13/.12/.11 без симлинка python3 в PATH; прежде
# literal python3 в such окружении терял финал — статус висел в
# running до stale 900 c). Fallback python3 — для ручных запусков.
if KZ_S="$S" KZ_TS="$TS" KZ_ACT="$ACT" KZ_MSG="$M" KZ_GUARD="$ST.lockfile" "${KZ_PY:-python3}" -S -c '
import os, sys, json, time, fcntl
ST = os.environ["KZ_ST"]; GU = os.environ["KZ_GUARD"]
CL = os.environ.get("KZ_CLAIM", ""); S = os.environ["KZ_S"]
TS = os.environ["KZ_TS"]; ACT = os.environ["KZ_ACT"]
MSG = os.environ["KZ_MSG"]; TMP = os.environ["KZ_TMP"]
fd = None
dl = time.monotonic() + 6.0
while True:
    try:
        fd = os.open(GU, os.O_RDWR | os.O_CREAT
                     | getattr(os, "O_NOFOLLOW", 0), 0o600)
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        break
    except OSError:
        if fd is not None:
            os.close(fd)
            fd = None
        if time.monotonic() >= dl:
            sys.exit(3)
        time.sleep(0.1)
try:
    try:
        with open(ST) as f:
            cur = json.load(f)
    except Exception:
        cur = {}
    if not CL:
        # r99 (аудит r98, KZ98-01): пустого claim не существует —
        # нет доказательства владения; публикация невозможна
        # (дубль shell-проверки env — защита от будущих регрессий)
        sys.exit(24)
    if (not isinstance(cur, dict)
            or cur.get("claim") != CL):
        sys.exit(24)
    with open(TMP, "w") as f:
        json.dump({"status": S, "ts": int(TS),
                   "action": ACT, "message": MSG}, f,
                  separators=(",", ":"))
    os.replace(TMP, ST)
finally:
    try:
        fcntl.flock(fd, fcntl.LOCK_UN)
    except OSError:
        pass
    os.close(fd)
'; then
  :
else
  _GRC=$?
  if [ "$_GRC" = 24 ]; then
    echo "keenzoo: статус обновления принадлежит другому прогону — результат не опубликован" >&2
  else
    echo "keenzoo: guard статуса занят — результат не опубликован" >&2
  fi
  rm -f "$TMP"
fi
exit "$RC"
'''
        try:
            subprocess.Popen(
                # FB-121 (аудит-42): argv строго три элемента — см. выше.
                ['/bin/sh', '-c', body],
                # FB-129 (аудит-43, вариант A): та же политика наследования
                # окружения, что у обёртки списков — update_protocols.sh тоже
                # читает операторские KEENZOO_* (например, DLTMP).
                env={**os.environ,
                     'PATH': '/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                     'KZ_SC': sc,
                     'KZ_ACT': action,
                     'KZ_ST': PROTO_UPD_STATUS,
                     'KZ_TMP': tmp_status,
                     # r96 (аудит r95, KZ95-03): claim этой попытки —
                     # финализатор обёртки сверяет его перед mv
                     'KZ_CLAIM': _claim_id or '',
                     # r99 (AUD-R98-02): финализатор зовёт хелпер
                     # интерпретатором самой панели
                     'KZ_PY': sys.executable},
                start_new_session=True,
                stdin=subprocess.DEVNULL,
                stdout=(log_fd if log_fd >= 0
                        else subprocess.DEVNULL),
                stderr=subprocess.STDOUT)
            # Успех: temp-файл принадлежит обёртке (KZ_TMP + trap TS-1) —
            # родитель его не убирает.
            tmp_status = None
        except OSError as _e:
            # TS-1 (аудит-22): обёртка не стартовала — её temp убираем
            # здесь (trap не выполнится).
            try:
                os.unlink(tmp_status)
            except OSError:
                pass
            # FB-187 (аудит-48, A-R81-PROTO-02/KZ81-02): если error
            # опубликовать не удалось (helper вернул False —
            # persistent ENOSPC), снимаем running-клейм ЭТОЙ попытки:
            # child не запущен, файл принадлежит нам — повтор не
            # блокируется таймаутом 900 секунд.
            if not _kz_proto_publish_error(
                    action, f'Запуск не удался: {_e}',
                    claim=_claim_id):
                # r93 (аудит r92, KZ92-03/E): клейм снимаем, только
                # если файл статуса всё ещё принадлежит ЭТОЙ попытке
                # (running + action + ts нашей публикации) — прежде
                # unlink снимал и чужой клейм. Штатно панель одна
                # (singleton S99generator), это защита на всякий.
                # r97 (аудит r96, KZ96-02): проверка и unlink — под
                # межпроцессным guard (прежде read→unlink окно могло
                # удалить свежий чужой running, опубликованный между
                # ними); guard не взят — пропускаем, best-effort
                _g = _kz_proto_guard()
                if _g is not False:
                    try:
                        try:
                            with open(PROTO_UPD_STATUS, 'r') as f:
                                _cur = json.load(f)
                            if (_cur.get('status') == 'running'
                                    and _cur.get('action') == action
                                    and _cur.get('ts') == _claim_ts
                                    and _cur.get('claim') == _claim_id):
                                os.unlink(PROTO_UPD_STATUS)
                        except (OSError, ValueError,
                                AttributeError):
                            pass
                    finally:
                        _kz_proto_guard_release(_g)
            raise
        finally:
            if log_fd >= 0:
                os.close(log_fd)


@app.route('/api/proto-update-status')
def api_proto_update_status():
    return jsonify(_read_proto_update())


@app.route('/update/run', methods=['POST'])
def route_update_run():
    # Изменяющее состояние действие: CSRF обязателен, доступ уже
    # ограничен LAN и Basic-авторизацией.
    _check_csrf()
    action = (request.form.get('action')
              or '').strip()
    try:
        start_proto_update(action)
    except ValueError:
        return jsonify({
            'ok': False,
            'error': 'Неизвестное действие'}), 400
    except FileNotFoundError:
        return jsonify({
            'ok': False,
            'error': 'Скрипт обновления не найден'}), 500
    except RuntimeError as e:
        return jsonify({
            'ok': False, 'error': str(e)}), 409
    except Exception as e:
        logging.error('proto update: %s', e)
        return jsonify({
            'ok': False,
            'error': 'Не удалось запустить'}), 500
    return jsonify({'ok': True})


@app.route('/api/update-status')
def api_update_status():
    return jsonify(_read_update_status())


# ── Фоновые проверки (задачи 3 и 4 этапа 2) ─────────────────────────
# Унифицированный запуск «долгих» проверок по образцу
# start_proto_update: HTTP-запрос возвращается сразу, обёртка пишет
# JSON-статус по коду возврата, панель опрашивает.
BG_CHECKS = {
    'updates': config.paths.get(
        'check_updates',
        '/opt/bin/check_updates.sh'),
    'dns-spoof': '/opt/bin/dns_spoof_check.sh',
}
BG_CHECK_TIMEOUT = 900
# rev37 (F36-05, аудит-8): единая внутрипроцессная сериализация операций
# с bg-замком и статусом (взятие, owner-check + публикация, снятие).
# Межпроцессная защита остаётся за lockdir: панель — один процесс.
_BG_SYNC = threading.Lock()
DNS_SPOOF_JSON = '/tmp/keenzoo_dns_spoof.json'
DNS_SPOOF_LOCKDIR = '/tmp/keenzoo_dns_spoof.lockdir'


def _bg_check_paths(kind):
    """Пути состояния фоновой проверки.

    rev34 (P1-3 ПА-33): без создания файлов открытием по предсказуемому
    пути (open(..., 'w')/: > шли по подставленной symlink в /tmp):
    статус — атомарный os.replace (не следует symlink), лог —
    tempfile.mkstemp, shell-обёртка не генерируется.
    """
    return (
        f'/tmp/keenzoo_bg_{kind}.json',
        f'/tmp/keenzoo_bg_{kind}.lockdir')


def _bg_check_publish(kind, payload):
    """Атомарная публикация статуса: mkstemp + os.replace."""
    fd, tmp = tempfile.mkstemp(
        prefix=f'.keenzoo_bg_{kind}.', dir='/tmp')
    try:
        with os.fdopen(fd, 'w') as f:
            json.dump(payload, f)
        os.replace(tmp, f'/tmp/keenzoo_bg_{kind}.json')
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


# rev35 (R35-6): строгий шаблон per-run лога (mkstemp:
# /tmp/keenzoo_bg_<kind>.<random>.log) — полная проверка вместо
# прежнего startswith-префикса.
_BG_LOG_RE = re.compile(r'^/tmp/keenzoo_bg_[a-z-]+\.[A-Za-z0-9_]+\.log$')


def _bg_cleanup_prev_log(kind):
    """rev35 (R35-6, аудит-6 P2.2): ротация per-run логов.

    Вызывается после успешного взятия замка: лог предыдущего прогона
    (его хвост уже отражён в предыдущем статусе) удаляется — в /tmp
    копится максимум один старый лог вместо неограниченного роста."""
    st, _lock = _bg_check_paths(kind)
    try:
        with open(st, 'r') as f:
            d = json.load(f)
    except (OSError, ValueError):
        return
    lp = d.get('log_path')
    if isinstance(lp, str) and _BG_LOG_RE.match(lp):
        try:
            os.unlink(lp)
        except OSError:
            pass


def _bg_lock_takeover(lockdir):
    """Решение о takeover существующего замка (rev35, R35-5, аудит-6 P2.1).

    Данные (pid/token/возраст) перечитываются НЕПОСРЕДСТВЕННО перед
    rename — прежний код решал по ранее прочитанным данным и мог
    переименовать уже НОВЫЙ замок победителя (двойной stale recovery).
    Возвращает True, если замок признан устаревшим и переименован нами;
    False — замок занят.
    """
    pidf = os.path.join(lockdir, 'pid')
    tokenf = os.path.join(lockdir, 'token')

    def _occupied():
        pid = None
        try:
            with open(pidf) as f:
                pid = int(f.read().strip())
        except (OSError, ValueError):
            pid = None
        try:
            has_token = os.path.isfile(tokenf)
        except OSError:
            has_token = False
        try:
            lock_age = time.time() - os.path.getmtime(lockdir)
        except OSError:
            lock_age = 0
        if pid is None:
            # pid-файла нет/битый: свежий замок — живой претендент ещё
            # пишет pid; устаревший — восстановление.
            return lock_age < BG_CHECK_TIMEOUT
        try:
            os.kill(pid, 0)
        except OSError:
            return False    # владелец мёртв — замок устарел
        # PID жив. С token-замком (rev35) PID — это ДОЧЕРНИЙ процесс
        # проверки: пока он жив, замок валиден НЕЗАВИСИМО от возраста —
        # долгая задача больше не отбирается по таймауту. Возрастная
        # эвристика остаётся только для старых r34-замков без token.
        if has_token:
            return True
        return lock_age < BG_CHECK_TIMEOUT

    if _occupied():
        return False
    stale = f'{lockdir}.stale.{os.getpid()}'
    try:
        os.rename(lockdir, stale)
    except OSError:
        return False
    # Страховка гонки: если в переименованном каталоге есть token и его
    # PID жив — мы забрали чужой НОВЫЙ замок; возвращаем на место.
    try:
        with open(os.path.join(stale, 'pid')) as f:
            spid = int(f.read().strip())
    except (OSError, ValueError):
        spid = None
    if spid is not None and os.path.isfile(os.path.join(stale, 'token')):
        try:
            os.kill(spid, 0)
            alive = True
        except OSError:
            alive = False
        if alive:
            try:
                os.rename(stale, lockdir)
            except OSError:
                pass
            return False
    shutil.rmtree(stale, ignore_errors=True)
    return True


def _bg_check_lock(kind):
    """mkdir-замок: атомарная сериализация фоновых проверок.

    rev34: пара «прочитать → проверить running → записать» не была
    атомарной — два POST запускали две копии. rev35 (R35-5): владелец —
    owner-token, liveness — по PID child; перед stale-rename данные
    перечитываются, после mkdir token сверяется обратным чтением.
    Возвращает (lockdir, token).
    """
    lockdir = f'/tmp/keenzoo_bg_{kind}.lockdir'
    pidf = os.path.join(lockdir, 'pid')
    tokenf = os.path.join(lockdir, 'token')
    if os.path.isdir(lockdir):
        if not _bg_lock_takeover(lockdir):
            raise RuntimeError('Уже выполняется')
    try:
        os.mkdir(lockdir, 0o700)
    except OSError:
        raise RuntimeError('Уже выполняется')
    token = secrets.token_hex(16)
    try:
        with open(tokenf, 'w') as f:
            f.write(token)
        with open(pidf, 'w') as f:
            f.write(str(os.getpid()))
    except OSError:
        shutil.rmtree(lockdir, ignore_errors=True)
        raise
    # Обратная сверка: если каталог между записью и чтением успел
    # переименовать конкурент — по этому пути лежит ЧУЖОЙ замок.
    # Уступаем; свой (переименованный) каталог не трогаем.
    try:
        with open(tokenf) as f:
            owner = f.read().strip()
    except OSError:
        owner = ''
    if owner != token:
        try:
            if os.path.isfile(tokenf):
                with open(tokenf) as f:
                    cur = f.read().strip()
                if cur == token:
                    shutil.rmtree(lockdir, ignore_errors=True)
        except OSError:
            pass
        raise RuntimeError('Уже выполняется')
    return lockdir, token


def _bg_still_owner(lockdir, token):
    """rev36 (F-04, аудит-7): текущее владение замком по owner-token."""
    if not lockdir or not token:
        return False
    try:
        with open(os.path.join(lockdir, 'token')) as f:
            return f.read().strip() == token
    except OSError:
        return False


def _bg_check_unlock(lockdir, token):
    """rev35 (R35-5): снятие замка только его владельцем.

    rev36 (F-04): атомарность через rename-first. rev37 (F36-06):
    чужой живой замок НЕ вытесняется из канонического пути (прежде
    rename шёл до проверки и на время уводил чужой lockdir в .rel.*).
    Теперь: чтение token по месту — чужой не трогается; совпал →
    rename → перечитывание (защита от takeover в окне) → свой:
    удалить; расхождение: вернуть обратно."""
    if not lockdir or not token:
        return
    try:
        with open(os.path.join(lockdir, 'token')) as f:
            cur = f.read().strip()
    except OSError:
        return                      # замка нет — уже снят
    if cur != token:
        return                      # чужой замок — не вытесняем
    release = f'{lockdir}.rel.{os.getpid()}.{token[:8]}'
    try:
        os.rename(lockdir, release)
    except OSError:
        return
    try:
        with open(os.path.join(release, 'token')) as f:
            cur2 = f.read().strip()
    except OSError:
        cur2 = ''
    if cur2 == token:
        shutil.rmtree(release, ignore_errors=True)
    else:
        # Между чтением и rename замок перехвачен — вернуть владельцу.
        try:
            os.rename(release, lockdir)
        except OSError:
            logging.error(
                'bg unlock: foreign lock %s not restorable', release)


def _bg_check_wait(kind, proc, log_path, lockdir, token):
    """Финальный статус по коду возврата; снятие замка в finally
    (только владельцем — rev35 R35-5).

    rev36 (F-04, аудит-7): финальный статус публикуется только при
    подтверждённом владении замком. Прежде старый waiter мог перезаписать
    статус `running` новой задачи своим `done`/`error` после того, как
    его замок был корректно забран stale-takeover'ом."""
    try:
        rc = proc.wait()
        if rc == 0:
            status, message = 'done', 'Готово'
        else:
            status, message = 'error', f'Код возврата {rc}'
        # rev37 (F36-05): owner-check и публикация — одна атомарная
        # секция: новый запуск не может вклиниться между проверкой и
        # записью статуса.
        with _BG_SYNC:
            if _bg_still_owner(lockdir, token):
                _bg_check_publish(kind, {
                    'status': status,
                    'ts': int(time.time()),
                    'action': kind,
                    'message': message,
                    'rc': rc,
                    'log_path': log_path})
            else:
                logging.error(
                    'bg check wait: lock ownership lost — '
                    'final status not published')
    except Exception as e:
        logging.error('bg check wait: %s', e)
    finally:
        with _BG_SYNC:
            _bg_check_unlock(lockdir, token)


def _read_bg_check(kind):
    st, _lock = _bg_check_paths(kind)
    try:
        with open(st, 'r') as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {'status': 'idle', 'ts': 0,
             'message': ''}
    if d.get('status') == 'running':
        age = time.time() - d.get('ts', 0)
        if age > BG_CHECK_TIMEOUT:
            d['status'] = 'error'
            d['message'] = 'Таймаут'
    log_path = d.get('log_path')
    if not (isinstance(log_path, str)
            and _BG_LOG_RE.match(log_path)):
        # До rev34 лог лежал по фиксированному пути — читаем его для
        # отображения статуса старых прогонов.
        log_path = f'/tmp/keenzoo_bg_{kind}.log'
    d['log'] = _tail_file(log_path)
    return d


def start_bg_check(kind):
    script = BG_CHECKS.get(kind)
    if not script:
        raise ValueError('kind')
    if not os.path.exists(script):
        raise FileNotFoundError(script)
    # rev34 (P1-3): сериализация до любых записей.
    # rev35 (R35-5): замок с owner-token.
    # rev37 (F36-05): взятие замка и ротация — под внутрипроцессной
    # блокировкой: атомарны относительно owner-check/публикации waiter'ов.
    with _BG_SYNC:
        lockdir, token = _bg_check_lock(kind)
        # rev35 (R35-6): ротация — лог предыдущего прогона удаляется.
        _bg_cleanup_prev_log(kind)
    fd = None
    log_path = None
    proc = None
    try:
        # rev34 (P1-3): per-run лог — непредсказуемое имя, режим 0600.
        fd, log_path = tempfile.mkstemp(
            prefix=f'keenzoo_bg_{kind}.', suffix='.log',
            dir='/tmp')
        _bg_check_publish(kind, {
            'status': 'running',
            'ts': int(time.time()),
            'action': kind,
            'message': 'Запуск...',
            'log_path': log_path})
        argv = [script]
        if kind == 'dns-spoof':
            argv.append('manual')
        # Прямой запуск без shell-обёртки: вывод — в уже открытый fd
        # лога (никаких промежуточных записей по предсказуемым путям).
        proc = subprocess.Popen(
            argv,
            stdout=fd,
            stderr=fd,
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            close_fds=True)
        # rev35 (R35-5): liveness замка — по ДОЧЕРНЕМУ процессу:
        # обновляем pid-файл после успешного запуска. Живой child
        # держит замок независимо от возраста каталога.
        try:
            with open(os.path.join(lockdir, 'pid'), 'w') as f:
                f.write(str(proc.pid))
        except OSError:
            pass
    except BaseException as e:
        # rev35 (R35-6): финальный error публикуется всегда — прежде
        # при сбое Popen статус зависал в running до 900-сек таймаута.
        _bg_start_failure(kind, proc, log_path, lockdir, token,
                          f'Не удалось запустить: {e}')
        raise
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass
    try:
        threading.Thread(
            target=_bg_check_wait,
            args=(kind, proc, log_path, lockdir, token),
            daemon=True).start()
    except BaseException as e:
        # rev35 (R35-6): отказ Thread.start() — child не должен
        # остаться без waiter'а: останавливаем его и публикуем error.
        _bg_start_failure(kind, proc, log_path, lockdir, token,
                          f'Не удалось запустить контрольный поток: {e}')
        raise


def _bg_group_executable(pgid, procfs='/proc'):
    """rev38 (F37-04): члены группы, способные исполняться.

    killpg(pgid, 0) не отличает зомби от живого (D-state) — ревизия
    читает /proc/<pid>/stat каждого члена: Z/X код не исполняют,
    прочие состояния (R/S/D/T/…) — незавершённые. Возвращает список
    'pid:state'; [] — пусто/только зомби; None — состояние не
    определено (fail-closed: остановка не подтверждается).
    rev39 (R38-04): ENOENT — допустимая гонка исчезновения процесса;
    прочие ошибки чтения/разбора stat — НЕИЗВЕСТНО (прежде молча
    пропускались, и [] ложно подтверждало остановку)."""
    try:
        entries = os.listdir(procfs)
    except OSError:
        return None
    alive = []
    undetermined = False
    for entry in entries:
        if not entry.isdigit():
            continue
        try:
            with open('%s/%s/stat' % (procfs, entry), 'rb') as f:
                data = f.read()
        except OSError as e:
            if e.errno == 2:            # ENOENT: процесс исчез — гонка
                continue
            undetermined = True         # EACCES и прочее — неизвестно
            continue
        rb = data.rfind(b')')
        if rb < 0:
            undetermined = True
            continue
        fields = data[rb + 1:].split()
        if len(fields) < 3:
            undetermined = True
            continue
        try:
            state = fields[0].decode('ascii', 'replace')
            pgrp = int(fields[2])
        except (ValueError, IndexError):
            undetermined = True
            continue
        if pgrp == pgid and state not in ('Z', 'X', 'x'):
            alive.append('%s:%s' % (entry, state))
    if undetermined:
        return None
    return alive


def _bg_stop_child(proc):
    """rev37 (F36-07): останавливается ВСЯ process group.

    Child — лидер группы (start_new_session=True), его потомки в той
    же группе; прежний proc.terminate() убивал только прямой PID —
    grandchild выживал, lock/log очищались при живом процессе.
    Теперь: SIGTERM группе → wait direct child → grace до опустошения
    группы (killpg(0) → ESRCH) → SIGKILL группе → финальная ревизия
    /proc (rev38). True — группа исчезла или остаток — только зомби."""
    if proc is None:
        return True
    pgid = proc.pid
    try:
        os.killpg(pgid, signal.SIGTERM)
    except OSError:
        pass
    try:
        proc.wait(timeout=10)
    except Exception:
        pass
    deadline = time.monotonic() + 3
    while time.monotonic() < deadline:
        try:
            os.killpg(pgid, 0)
        except OSError:
            return True              # группа опустела
        time.sleep(0.2)
    # Спустя grace после SIGTERM члены группы живы — безусловный SIGKILL.
    try:
        os.killpg(pgid, signal.SIGKILL)
    except OSError as e:
        if e.errno == 3:            # ESRCH: группы уже нет
            return True
        logging.error('bg stop: killpg SIGKILL failed: %s', e)
        return False
    try:
        proc.wait(timeout=5)         # подобрать direct child
    except Exception:
        pass
    time.sleep(0.5)
    try:
        os.killpg(pgid, 0)
    except OSError:
        return True
    # rev38 (F37-04, аудит-9): группа ещё сигнализирует — раньше это
    # молча считалось «возможными зомби» и остановка подтверждалась.
    # killpg(0) не отличает зомби от живого (напр., D-state) процесса:
    # подтверждение даёт только ревизия СОСТОЯНИЙ членов группы; пока
    # есть исполняющий член — остановка не подтверждена (замок не
    # снимается, лог не удаляется). Ошибка сканирования /proc — тоже
    # отказ от подтверждения (fail-closed).
    scan = _bg_group_executable(pgid)
    if scan is None:
        logging.error('bg stop: group %s state undetermined '
                      '(/proc scan failed) — stop NOT confirmed', pgid)
        return False
    if scan:
        logging.error('bg stop: group %s has live members after '
                      'SIGKILL (%s) — stop NOT confirmed', pgid,
                      ', '.join(scan))
        return False
    # Остаточные записи группы — неспособные исполняться зомби; честно
    # фиксируем, остановка подтверждена.
    logging.error('bg stop: group %s lingers after SIGKILL '
                  '(zombies only — not executing)', pgid)
    return True


def _bg_start_failure(kind, proc, log_path, lockdir, token, message):
    """rev35 (R35-6): единая очистка при сбое запуска фоновой проверки:
    остановка child, публикация финального error, снятие замка
    владельцем, удаление лога.
    rev36 (F-05): остановка эскалируется до SIGKILL группы процессов;
    lock/log очищаются только после подтверждённого завершения.
    rev36 (F-04): финальный статус — только при подтверждённом
    владении замком."""
    stopped = _bg_stop_child(proc)
    if not stopped:
        message = (f'{message}; дочерний процесс не подтверждён '
                   'остановленным — замок не снимается')
        logging.error('bg start failure: %s', message)
    # rev37 (F36-05): owner-check и публикация — атомарная секция.
    with _BG_SYNC:
        if _bg_still_owner(lockdir, token):
            try:
                _bg_check_publish(kind, {
                    'status': 'error',
                    'ts': int(time.time()),
                    'action': kind,
                    'message': message,
                    'log_path': log_path or ''})
            except Exception:
                pass
        if stopped:
            _bg_check_unlock(lockdir, token)
    if stopped and log_path:
        try:
            os.unlink(log_path)
        except OSError:
            pass


@app.route('/check/run', methods=['POST'])
def route_check_run():
    _check_csrf()
    kind = (request.form.get('kind')
            or '').strip()
    try:
        start_bg_check(kind)
    except ValueError:
        return jsonify({
            'ok': False,
            'error': 'Неизвестная проверка'}), 400
    except FileNotFoundError:
        return jsonify({
            'ok': False,
            'error': 'Скрипт не найден'}), 500
    except RuntimeError as e:
        return jsonify({
            'ok': False, 'error': str(e)}), 409
    except Exception as e:
        logging.error('bg check: %s', e)
        return jsonify({
            'ok': False,
            'error': 'Не удалось запустить'}), 500
    return jsonify({'ok': True})


@app.route('/api/check-status')
def api_check_status():
    kind = request.args.get('kind', '')
    if kind not in BG_CHECKS:
        return jsonify({'error': 'unknown kind'}), 400
    return jsonify(_read_bg_check(kind))


@app.route('/api/dns-spoof')
def api_dns_spoof():
    """Статус проверки подмены DNS + флаг активного прогона."""
    try:
        with open(DNS_SPOOF_JSON, 'r') as f:
            d = json.load(f)
        if not isinstance(d, dict):
            raise ValueError('bad json')
    except Exception:
        d = {'ts': 0, 'verdict': 'unknown',
             'ports': {}, 'trusted': [],
             'suspected_spoof': []}
    running = False
    try:
        if os.path.isdir(DNS_SPOOF_LOCKDIR):
            pidf = os.path.join(
                DNS_SPOOF_LOCKDIR, 'pid')
            ts_file = os.path.join(
                DNS_SPOOF_LOCKDIR, 'ts')
            alive = False
            try:
                with open(pidf) as f:
                    pid = int(f.read().strip())
                os.kill(pid, 0)
                alive = True
            except (OSError, ValueError):
                # pid-файл отсутствует/битый/процесс мёртв:
                # определяем живость по времени замка.
                try:
                    with open(ts_file) as f:
                        ts_ = int(
                            f.read().strip())
                    alive = (time.time() - ts_
                             < 300)
                except (OSError, ValueError):
                    alive = False
            running = alive
    except Exception:
        running = False
    d['running'] = running
    return jsonify(d)


# ── R6 «Активный резолвер» (слит с R3: имена upstream'ов) ────────────
# Виджет вкладки «DNS-безопасность». Источники — только state-файлы
# последнего DNS-цикла (/tmp/keenzoo_dns_state от unblock_dnsmasq.sh
# и /tmp/keenzoo_dns_spoof.json от dns_spoof_check.sh) плюс один
# локальный вызов ndmc (не DNS-прогон): новых dig-запросов эндпоинт
# не добавляет (стоящее ограничение «минимум DNS-прогонов»).
DNS_STATE_FILE = '/tmp/keenzoo_dns_state'


def _read_dns_state():
    """Решение последнего цикла unblock_dnsmasq.sh (key=value)."""
    out = {}
    try:
        with open(DNS_STATE_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if '=' in line:
                    k, v = line.split('=', 1)
                    out[k] = v
    except OSError:
        pass
    return out


def _ndm_resolver_names():
    """Привязка «порт ↔ upstream» из `ndmc -c 'show dns-proxy'` (R3).

    Формат вывода зависит от прошивки, поэтому разбор защитный:
    ищем строки с портами 4050x/4051x и в ближайшем окне строк —
    адрес upstream'а (URL/хост/IP) и тип DoT/DoH. При недоступном
    ndmc или нестандартном формате возвращаем пустой словарь —
    виджет тогда показывает порты без имён.
    """
    mapping = {}
    try:
        r = subprocess.run(
            ['ndmc', '-c', 'show dns-proxy'],
            capture_output=True, text=True, timeout=5)
        out = r.stdout or ''
    except (OSError, subprocess.SubprocessError):
        return mapping
    lines = out.splitlines()
    _bad_name_re = re.compile(
        r'(^[A-Za-z]\.[A-Za-z]|\.(?:stat|conf|kv|db|cache)$)')
    port_re = re.compile(r'\b(4050[0-9]|4051[01])\b')
    name_re = re.compile(
        r'(https?://[^\s,;"\']+'
        r'|tls://[^\s,;"\']+'
        r'|\b(?:\d{1,3}\.){3}\d{1,3}\b'
        r'|\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b)')
    for i, line in enumerate(lines):
        pm = port_re.search(line)
        if not pm:
            continue
        port = pm.group(1)
        name = ''
        kind = ''
        lo = max(0, i - 4)
        hi = min(len(lines), i + 3)
        for j in range(lo, hi):
            lw = lines[j]
            if not kind:
                if re.search(
                        r'\bDoH\b|dns-query|https://', lw):
                    kind = 'DoH'
                elif re.search(r'\bDoT\b|tls://', lw):
                    kind = 'DoT'
            if not name:
                nm = name_re.search(lw)
                if nm:
                    cand = nm.group(1)
                    # loopback, сам порт, счётчики статистики
                    # (R.Sent/Q.Sent/R.Recvd) и имена файлов
                    # профилей (*.stat/*.conf/...) именем не считаются
                    if port not in cand \
                            and not cand.startswith('127.') \
                            and not _bad_name_re.search(cand):
                        name = cand
            if name and kind:
                break
        entry = mapping.get(port) or {}
        if name and not entry.get('name'):
            entry['name'] = name
        if kind and not entry.get('kind'):
            entry['kind'] = kind
        mapping[port] = entry
    return mapping


@app.route('/api/dns-resolver')
def api_dns_resolver():
    """Решение DNS-цикла + привязка портов к именам upstream'ов."""
    state = _read_dns_state()
    try:
        with open(DNS_SPOOF_JSON, 'r') as f:
            spoof = json.load(f)
        if not isinstance(spoof, dict):
            spoof = {}
    except Exception:
        spoof = {}
    spoof_ports = spoof.get('ports') or {}
    def _toi(v):
        try:
            return int(v or 0)
        except (TypeError, ValueError):
            return 0
    ts_state = _toi(state.get('ts'))
    ts_spoof = _toi(spoof.get('ts'))
    ts = max(ts_state, ts_spoof)
    names = _ndm_resolver_names()
    # Порядок: рабочий порядок последнего цикла (strict-order),
    # хвосты из spoof-проверки, в конце аварийный 40500 — как в
    # update_dnsmasq_upstreams.
    order = []
    for src in (state.get('working', ''),
                ' '.join(spoof.get('trusted') or []),
                ' '.join(spoof.get('insecure') or []),
                '40500'):
        for p in str(src).split():
            # в spoof-списках элементы хранятся как «порт:rtt»
            p = p.split(':', 1)[0]
            if p and p not in order:
                order.append(p)
    rtt = {}
    for pair in str(state.get('ranking', '')).split(','):
        if ':' in pair:
            k, v = pair.split(':', 1)
            rtt[k] = v
    primary = state.get('primary') or spoof.get('fastest') or ''
    prtt = rtt.get(primary, '')
    if not prtt and primary:
        prtt = (spoof_ports.get(primary) or {}).get('rtt')
    trusted = [x.split(':', 1)[0]
               for x in (spoof.get('trusted') or [])]
    insecure = [x.split(':', 1)[0]
                for x in (spoof.get('insecure') or [])]
    ports_out = []
    for p in order:
        sp = spoof_ports.get(p) or {}
        entry = names.get(p) or {}
        ports_out.append({
            'port': p,
            'rtt': rtt.get(p) or sp.get('rtt'),
            'state': ('secure' if p in trusted
                      else 'insecure' if p in insecure
                      else 'unknown'),
            'reason': sp.get('reason') or '',
            'egress': sp.get('egress') or '',
            'name': entry.get('name') or
                    ('системный профиль NDMS'
                     if p == '40500' else ''),
            'kind': entry.get('kind') or
                    ('DoT' if p in (
                        '40500', '40501', '40502', '40503')
                     else 'DoH'),
        })
    mode = state.get('mode') or spoof.get('verdict') or ''
    return jsonify({
        'ok': bool(state or spoof),
        'ts': ts,
        'ts_state': ts_state,
        'ts_spoof': ts_spoof,
        'mode': mode,
        'verdict': spoof.get('verdict') or '',
        'primary': primary,
        'primary_rtt': prtt,
        'tunnel': state.get('tunnel')
                  or spoof.get('tunnel_proto') or '',
        'ports': ports_out,
        'names_from_ndm': bool(names),
        'suspected': spoof.get('suspected_spoof') or [],
    })


# ── Вкладка «Конфиги»: прямое редактирование *.json служб и мостов Tor ──
# Возможность добавлена отдельной вкладкой (уточнение 2026-10-05): окно
# ввода полного config.json для Shadowsocks/Trojan/VLESS/Hysteria и
# мостов Tor (obfs4, webtunnel). Разбор JSON — apply_direct_config из
# utils.py (валидирует и «переводит» данные в боевой файл; для VLESS
# inbound-ы пересобираются под redirect+TPROXY). Перед записью прежний
# файл сохраняется как <path>.bak, после записи служба перезапускается.
# kind: 'json' — полный конфиг; 'bridges' — строки мостов Tor.
CFG_ITEMS = {
    'ss': ('Shadowsocks',
           'shadowsocks_config',
           'shadowsocks', 'shadowsocks', 'json'),
    'tr': ('Trojan', 'trojan_config',
           'trojan', 'trojan', 'json'),
    'vl': ('VLESS (Xray)', 'vless_config',
           'vless', 'vless', 'json'),
    'hy': ('Hysteria', 'hysteria_config',
           'hysteria', 'hysteria', 'json'),
    'to': ('Tor', 'tor_config',
           'tor', None, 'bridges'),
}

# Обязательные поля каждого формата проверяются «префлайтом» внутри
# apply_direct_config (utils.py): неполный конфиг не доходит до боевого
# файла, а причина возвращается ошибкой — см. except в api_cfg_apply.


def _tor_current_bridges(path):
    """Текущие мосты из torrc (строки вида «Bridge ...»)."""
    out = []
    try:
        with open(path, 'r', encoding='utf-8',
                  errors='replace') as f:
            for ln in f:
                ln = ln.strip()
                if ln.lower().startswith('bridge '):
                    out.append(ln)
    except OSError:
        pass
    return '\n'.join(out)


@app.route('/api/cfg')
def api_cfg_read():
    """Текущее содержимое файлов конфигурации для вкладки «Конфиги»."""
    items = {}
    for key, (title, pathkey, svc, _proto,
              kind) in CFG_ITEMS.items():
        path = config.paths.get(pathkey, '')
        info = {
            'title': title, 'path': path,
            'service': svc, 'kind': kind,
            'exists': False, 'mtime': 0,
            'content': ''}
        try:
            if path and os.path.exists(path):
                st = os.stat(path)
                info['exists'] = True
                info['mtime'] = int(st.st_mtime)
                if kind == 'bridges':
                    info['content'] = \
                        _tor_current_bridges(path)
                else:
                    info['content'] = \
                        read_file_text(path)
        except OSError as e:
            info['error'] = str(e)
        items[key] = info
    return jsonify({'ok': True, 'items': items})


@app.route('/api/cfg/<which>', methods=['POST'])
def api_cfg_apply(which):
    """Записать конфигурацию (JSON или мосты Tor) и перезапустить службу."""
    _check_csrf()
    if which not in CFG_ITEMS:
        return jsonify({
            'ok': False,
            'error': 'Неизвестная цель'}), 404
    (title, pathkey, svc, proto,
     kind) = CFG_ITEMS[which]
    data = request.form.get('content') or ''
    path = config.paths.get(pathkey, '')
    if not path:
        return jsonify({
            'ok': False,
            'error': 'Путь не задан в bot_config'}), 500
    try:
        # Резервная копия прежней конфигурации (<файл>.bak, имя
        # фиксированное — перезаписывается при каждом сохранении и не
        # накапливается) создаётся централизованно в
        # ConfigWriter.write_config — только при успешной записи,
        # поэтому на провалившейся валидации .bak остаётся от прошлой
        # удачи (последний рабочий конфиг).
        # FB-213 (2026-11-01): apply_direct_config возвращает
        # неблокирующие предупреждения (вырезанные за отсутствием
        # geoip.dat geoip:-правила) — показываются вместе с
        # предупреждениями keys_bridges. Для мостов Tor — пусто.
        _apply_warns = []
        if kind == 'json':
            if not data.strip():
                raise ValueError('Пустой конфиг')
            _apply_warns = (
                apply_direct_config(proto, data) or [])
        else:
            # Строки мостов (obfs4/webtunnel по одному; пусто = снять
            # все мосты). tor_config пишет torrc по шаблону.
            tor_config(data)
        bak = (path + '.bak'
               if os.path.exists(path + '.bak') else '')
        err = None
        try:
            restart_service(svc)
        except Exception as e:
            log_error(f'[cfg]{which} restart: {e}')
            err = str(e)
        web_log(f'cfg {which} applied, restart '
                f'{"ok" if err is None else "FAIL"}')
        # FB-68 (аудит-32, R55-08): панель получает те же
        # предупреждения о ключах/мостах, что и бот (ранее JS читал
        # j.warnings, но endpoint его не возвращал — ветка UI была
        # недостижима). Реюз keys_bridges_warnings из utils, без
        # копирования regex; предупреждение НЕ подменяет блокирующий
        # preflight (он выше по ходу).
        try:
            _cfg_warnings = keys_bridges_warnings()
        except Exception as e:
            log_error(f'[cfg]{which} warnings: {e}')
            _cfg_warnings = []
        # FB-213: предупреждения применения — первыми в списке.
        _cfg_warnings = (
            list(_apply_warns) + list(_cfg_warnings))
        return jsonify({
            'ok': True, 'applied': True,
            'restart_ok': err is None,
            'error': err,
            'bak': bak, 'title': title,
            'warnings': _cfg_warnings})
    except Exception as e:
        log_error(f'[cfg]{which}: {e}')
        return jsonify({
            'ok': False,
            'error': str(e)}), 400


def _cross_list_sources(target):
    """
    N51-1 (аудит-26) + FB-39 (аудит-27, K52-6): снимок записей всех
    ДРУГИХ списков протоколов — ОДИН раз на запрос. Прежде каждая
    добавляемая запись перечитывала все файлы списков (100 записей ×
    N списков = сотни чтений; на MIPS с USB — секунды).
    Порядок правил фиксирован (shadowsocks → vless → trojan →
    hysteria), и трафик домена пойдёт по первому совпавшему списку —
    даже если его протокол выключен. Логику правил не меняем, только
    предупреждаем (список bot — не маршрутный, не проверяется).
    """
    # T-2 (аудит-28, R53-07): записи нормализуются тем же правилом,
    # что shell normalize_domain_target — снимается РОВНО одна
    # завершающая точка (прежде «dot.example» и «dot.example.» не
    # находились друг на друге); bot и как источник, и как ЦЕЛЬ не
    # маршрутный — предупреждение о порядке правил к нему неприменимо.
    if target == 'bot':
        return {}
    sources = {}
    for name, path in dict(getattr(config, 'list_files',
                                   {}) or {}).items():
        if name == target or name == 'bot':
            continue
        try:
            other = read_file_text(path).lower()
        except Exception:
            continue
        entries = set()
        for ln in other.split('\n'):
            e = ln.split('#', 1)[0].strip()
            if e.endswith('.'):
                e = e[:-1]
            if e:
                entries.add(e)
        sources[name] = entries
    return sources


def _cross_list_hint(entry, target):
    """
    N51-1 (аудит-26): entry уже есть в ДРУГОМ списке протоколов.
    Обёртка над _cross_list_sources для одиночных проверок; массовые
    добавления используют снимок напрямую (FB-39, K52-6).
    """
    return [name for name, entries in _cross_list_sources(target).items()
            if entry in entries]


@app.route('/api/lookup-add', methods=['POST'])
def api_lookup_add():
    """Добавляет выбранные записи в список обхода протокола.

    Форма: list = shadowsocks|trojan|vless|tor|hysteria|bot,
    entries = многострочный текст. Каждая запись валидируется
    (_validate_entry), дедуплицируется по точному совпадению,
    запись атомарна (_atomic_write_text). Комментарии (#...)
    пропускаются.
    """
    # FB-52 (аудит-29, K54-2): весь read-modify-write — под
    # _LISTS_WRITE_LOCK: панель работает с threaded=True, и
    # параллельные добавления читали одно базовое состояние,
    # затирая записи друг друга (замер: 20 параллельных POST —
    # в файле оставалась 1 запись из 20). Уникальный tmp (mkstemp
    # в _atomic_write_text) закрывает и коллизию временных файлов
    # (FileNotFoundError → HTTP 500).
    # FB-63 (аудит-32, R55-01): вместо одного внутрипроцессного RLock —
    # полный guard списков (RLock + межпроцессный flock по целевому
    # файлу): бот пишет те же файлы отдельным процессом.
    _lkz_files = dict(config.list_files)
    _lkz_target = (request.form.get('list') or '').strip()
    if _lkz_target in _lkz_files:
        with _list_write_guard(_lkz_files[_lkz_target]):
            return _api_lookup_add_impl()
    return _api_lookup_add_impl()


def _api_lookup_add_impl():
    _check_csrf()
    target = (request.form.get('list')
              or '').strip()
    raw = request.form.get('entries') or ''
    files = dict(config.list_files)
    if target not in files:
        return jsonify({
            'ok': False,
            'error': 'Неизвестный список'}), 400
    fp = files[target]
    added, dup, bad = [], [], []
    # FB-46 (аудит-28, R53-06): целевой файл читается ОДИН раз на запрос
    # (прежде — на каждую запись: 100 записей = 100 чтений на MIPS с
    # USB-флеш), множество существующих пополняется при добавлении.
    # T-2 (аудит-28, R53-07): нормализация как в shell
    # normalize_domain_target — РОВНО одна завершающая точка снимается
    # (прежде «dot.example.» сохранялась как есть и не схлопывалась с
    # уже лежащей «dot.example»).
    current = read_file_text(fp)
    existing_l = current.lower()
    exist_entries = set()
    for ln in existing_l.split('\n'):
        e = ln.split('#', 1)[0].strip()
        if e.endswith('.'):
            e = e[:-1]
        if e:
            exist_entries.add(e)
    for line in raw.split('\n'):
        entry = (line.split('#', 1)[0]
                 .strip().lower())
        if entry.endswith('.'):
            entry = entry[:-1]
        if not entry:
            continue
        if _validate_entry(entry) is None:
            bad.append(line.strip())
            continue
        if entry in dup or entry in added:
            continue
        if entry in exist_entries:
            dup.append(entry)
            continue
        added.append(entry)
        exist_entries.add(entry)
    if bad:
        return jsonify({
            'ok': False,
            'error': 'Невалидные записи: '
                     + ', '.join(bad[:5]),
            'invalid': bad}), 400
    if not added:
        return jsonify({
            'ok': True, 'added': [],
            'duplicates': dup,
            'message': 'Всё уже есть в списке'})
    # FB-46: лимит списка — тот же контракт, что у parse_and_save
    # (lists_core.MAX_LIST_LINES); прежде API мог вырастить список
    # за его пределы (1 MiB тела запроса не заменяет лимит строк).
    _cur_lines = len(current.splitlines())
    if _cur_lines + len(added) > MAX_LIST_LINES:
        return jsonify({
            'ok': False,
            'error': (f'Превышен лимит списка '
                      f'({MAX_LIST_LINES} строк): '
                      f'сейчас {_cur_lines}, '
                      f'добавляется {len(added)}')}), 400
    text = current
    if text and not text.endswith('\n'):
        text += '\n'
    text += '\n'.join(added) + '\n'
    _atomic_write_text(fp, text)
    # N51-1 (аудит-26): домены, уже лежащие в других списках, —
    # предупреждение в ответе (панель показывает warning, FB-38).
    # FB-39 (аудит-27, K52-6): снимок списков строится один раз на
    # запрос, а не на каждую добавляемую запись.
    _cls = _cross_list_sources(target)
    cross = []
    for e in added:
        for name, entries in _cls.items():
            if e in entries:
                cross.append(f'{e} уже в «{name}»')
    resp = {
        'ok': True, 'added': added,
        'duplicates': dup,
        'list': target,
        'message': (
            f'Добавлено: {len(added)}; '
            f'уже были: {len(dup)}. '
            'Применится при ближайшем '
            'обновлении списков '
            '(unblock_update).')}
    if cross:
        resp['warning'] = (
            'Внимание: записи пересекаются с другими списками — '
            'трафик пойдёт по порядку правил (первый совпавший '
            'список): ' + '; '.join(cross[:5]))
    return jsonify(resp)


_DNS_STATUS_LOCK = threading.Lock()
# FB-159 (аудит-45, R77-04): single-flight refresh. Прежний код
# проверял TTL под lock'ом, но сам probe (check_dns_ports — пакет
# форков dig) выполнялся ВНЕ блокировки: два одновременных запроса
# на пустом/истёкшем кэше оба проходили проверку и оба гоняли
# полный прогон. Refresh теперь под отдельным lock: параллельные
# запросы во время прогона получают последний (stale) результат;
# ждать завершения прогона приходится только если stale ещё нет.
_DNS_STATUS_REFRESH = threading.Lock()
_DNS_STATUS_CACHE = {'ts': 0.0, 'data': None}
# r93 (аудит r92, KZ92-02 — слабые устройства 64–128 МБ): дорогой
# маршрут (прогон check_dns_ports — 8 fork'ов dig) пускает не больше
# _DNS_HEAVY_MAX одновременных обработчиков; прочие получают быстрый
# 503 вместо накопления ждущих потоков (замер аудита r92: 128
# одновременных cold-запросов — 129 потоков). Кэш-попадания не
# гейтятся; лёгкие маршруты и POST-записи (lookup-add) — тоже.
_DNS_HEAVY_SEM = threading.BoundedSemaphore(4)
_DNS_HEAVY_WAIT = 2.0
# FB-155 (аудит-44, опция 4): 120 с (было 60) — вдвое реже пакет
# форков dig на дашборде и DNS-вкладке. Прямые проверки по кнопке
# остаются без кэша (K67-01).
_DNS_STATUS_TTL = 120.0


@app.route('/api/dns-status')
def api_dns_status():
    """K67-01 (аудит-43): прямой прогон = 8 fork'ов dig (4 DoT + 4
    DoH; FB-177/аудит-46 синхронизировал цифру — прежде «11»), маршрут
    поллится дашбордом (60 с) и вкладкой DNS панели — по прогону на
    каждую открытую вкладку. TTL-кэш по образцу _dash_lists_cache:
    параллельные клиенты делят один прогон, мёртвый порт не добавляет
    задержку каждому. FB-159 (аудит-45, R77-04): refresh —
    single-flight: на время прогона параллельные клиенты получают
    последний (stale) результат, timestamp кэша ставится по
    завершении probe. Прямые вызовы check_dns_ports() остаются без
    кэша — проверка по требованию остаётся честной.
    r93 (аудит r92, KZ92-02 — слабые устройства): дорогой путь —
    под семафором (_DNS_HEAVY_SEM): не больше 4 одновременных
    обработчиков этого маршрута, прочие — быстрый 503 вместо
    накопления ждущих потоков (замер аудита: 128 cold-запросов
    давали 129 потоков). Кэш-попадания не гейтятся."""
    with _DNS_STATUS_LOCK:
        now = time.time()
        if (_DNS_STATUS_CACHE['data'] is not None
                and now - _DNS_STATUS_CACHE['ts']
                < _DNS_STATUS_TTL):
            return jsonify(_DNS_STATUS_CACHE['data'])
    # r93 (KZ92-02): кэш пуст/истёк — дорогой путь только через
    # семафор; переполнение — быстрый 503 (панель повторит поллинг).
    if not _DNS_HEAVY_SEM.acquire(timeout=_DNS_HEAVY_WAIT):
        # r95 (аудит r94, KZ94-05): Retry-After для честного повтора.
        _r = jsonify({
            'status': 'busy',
            'message': 'Проверка DNS уже идёт — повторите '
                       'через несколько секунд'})
        _r.status_code = 503
        _r.headers['Retry-After'] = '1'
        return _r
    try:
        # FB-159: refresh под отдельным lock — один прогон на всех.
        if _DNS_STATUS_REFRESH.acquire(blocking=False):
            try:
                # повторная проверка после захвата: конкурент мог
                # завершить refresh, пока мы шли к блокировке.
                with _DNS_STATUS_LOCK:
                    now = time.time()
                    if (_DNS_STATUS_CACHE['data'] is not None
                            and now - _DNS_STATUS_CACHE['ts']
                            < _DNS_STATUS_TTL):
                        return jsonify(
                            _DNS_STATUS_CACHE['data'])
                data = check_dns_ports()
                # timestamp — по завершении probe, а не по началу:
                # долгий прогон не должен съедать собственный TTL.
                with _DNS_STATUS_LOCK:
                    _DNS_STATUS_CACHE['ts'] = time.time()
                    _DNS_STATUS_CACHE['data'] = data
                return jsonify(data)
            finally:
                _DNS_STATUS_REFRESH.release()
        # FB-159: refresh уже идёт — сначала отдаём последний (stale)
        # результат НЕМЕДЛЕННО, не дожидаясь прогона; ждать приходится
        # только если stale ещё нет (самый первый прогон).
        with _DNS_STATUS_LOCK:
            if _DNS_STATUS_CACHE['data'] is not None:
                return jsonify(
                    _DNS_STATUS_CACHE['data'])
        # FB-169 (аудит-46, B-R79-03): повторный probe — строго под
        # refresh-lock. Прежде fallback-прогон выполнялся уже СВОБОДНЫМ
        # от блокировки: стойкое исключение первого владельца приводило к
        # параллельному шторму probe'ов у всех ждущих (ревью r79:
        # 3 вызова, 2 параллельно, 3×500). Теперь каждый ждущий, дождавшись
        # очереди, сначала перечитывает кэш (владелец мог опубликовать
        # результат) и только при пустом кэше запускает собственный прогон —
        # последовательно, не параллельно.
        with _DNS_STATUS_REFRESH:
            with _DNS_STATUS_LOCK:
                if (_DNS_STATUS_CACHE['data']
                        is not None):
                    return jsonify(
                        _DNS_STATUS_CACHE['data'])
            data = check_dns_ports()
            with _DNS_STATUS_LOCK:
                _DNS_STATUS_CACHE['ts'] = time.time()
                _DNS_STATUS_CACHE['data'] = data
            return jsonify(data)
    finally:
        _DNS_HEAVY_SEM.release()

@app.route('/api/dashboard')
def api_dashboard():
    """Лёгкий снапшот дашборда (TTL-кэш; см. _dashboard_snapshot)."""
    return jsonify(_dashboard_snapshot())


@app.route('/dash/update-lists', methods=['POST'])
def dash_update_lists():
    # Изменяющее состояние действие: CSRF обязателен, как у всех POST.
    _check_csrf()
    try:
        apply_unblock_async()
        return jsonify({'started': True})
    except RuntimeError as e:
        return jsonify(
            {'started': False, 'message': str(e)}), 409
    except Exception as e:
        log_error(f'[w]dash-update: {e}')
        return jsonify(
            {'started': False,
             'message': 'Не удалось запустить обновление'}), 500


# Состояние доступности серверов обхода. Пишется unblock_dnsmasq.sh при
# проверке закреплённых адресов. Telegram с роутера часто заблокирован,
# поэтому панель — основной канал уведомления.
PIN_STATUS_FILE = _GS.get(
    'pin_status_file', '/tmp/keenzoo_pin_status.json')


@app.route('/api/pin-status')
def api_pin_status():
    try:
        if not os.path.exists(PIN_STATUS_FILE):
            return jsonify({'kind': 'none', 'ts': 0, 'message': ''})
        with open(PIN_STATUS_FILE, 'r') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return jsonify({'kind': 'none', 'ts': 0, 'message': ''})
        return jsonify(data)
    except (json.JSONDecodeError, IOError, ValueError):
        return jsonify({'kind': 'none', 'ts': 0, 'message': ''})


@app.route('/api/protocol-versions')
def api_protocol_versions():
    sf = config.paths.get(
        'updates_status',
        '/tmp/updates_status.json')
    if not os.path.exists(sf):
        cs = config.paths.get(
            'check_updates',
            '/opt/bin/check_updates.sh')
        if os.path.exists(cs):
            try:
                subprocess.run(
                    [cs], timeout=60, check=False)
            except (OSError, subprocess.TimeoutExpired) as e:
                web_log(f"protocol versions check: {e}")
    if os.path.exists(sf):
        try:
            with open(sf, 'r') as f:
                _d = json.load(f)
            if isinstance(_d, dict) and 'arch' not in _d:
                try:
                    _d['arch'] = os.uname().machine
                except AttributeError:
                    _d['arch'] = 'unknown'
            return jsonify(_d)
        except (OSError, ValueError, json.JSONDecodeError) as e:
            web_log(f"protocol versions status: {e}")
    return jsonify({
        'ts': 0, 'has_updates': False,
        'versions': {}, 'updates': [],
        'arch': os.uname().machine
        if hasattr(os, 'uname') else 'unknown'})


# ── Выбор протокола для трафика роутера (unblockrouter) ─────────────────
# Файл — источник выбора для 100-redirect.sh. GET отдаёт состояние и
# доступность пакетов; POST пишет файл через временный и перестраивает
# правила тем же вызовом, что и деплой (type=iptable table=nat|mangle).
ROUTER_PROTO_FILE = config.paths.get(
    'router_proto', '/opt/etc/unblock/router_proto')
ROUTER_PROTO_STATUS_FILE = '/tmp/keenzoo_router_status'
ROUTER_STATUS_MAX_AGE = 300
ROUTER_PROTOS = {
    'vl': ('S24xray', 'VLESS'),
    'tr': ('S22trojan', 'Trojan'),
    'hy': ('S57hysteria', 'Hysteria'),
}


def _router_proto_installed():
    out = {}
    for k, (initd, _lbl) in ROUTER_PROTOS.items():
        p = '/opt/etc/init.d/' + initd
        out[k] = os.path.isfile(p) and os.access(p, os.X_OK)
    return out


def _read_router_proto():
    try:
        with open(ROUTER_PROTO_FILE, 'r') as f:
            v = f.read().strip()
        if v in ROUTER_PROTOS:
            return v
    except OSError as e:
        web_log(f"router proto read: {e}")
    return 'vl'


def _router_proto_status(selected):
    """Read diagnostic-only status written atomically by netfilter hook."""
    result = {
        'effective': selected,
        'state': 'unknown',
        # None означает unknown/missing/stale. False допустим только для
        # свежего snapshot и не должен изображаться как подтверждённый down.
        'ready': {'vl': None, 'tr': None, 'hy': None},
        'status_age': None,
        'status_stale': True,
    }
    raw = {}
    try:
        with open(ROUTER_PROTO_STATUS_FILE, 'r') as f:
            for line in f:
                key, sep, value = line.strip().partition('=')
                if sep and key in {
                        'selected', 'effective', 'state',
                        'ready_vl', 'ready_tr', 'ready_hy',
                        'timestamp'}:
                    raw[key] = value
    except OSError:
        return result

    # Старый status после ручной смены файла не должен изображать новое
    # состояние: источник выбора — ROUTER_PROTO_FILE, status лишь снимок.
    if raw.get('selected') != selected:
        return result
    effective = raw.get('effective')
    state = raw.get('state')
    if effective in ROUTER_PROTOS:
        result['effective'] = effective
    if state in {'ready', 'fallback', 'blocked'}:
        result['state'] = state
    for key in ROUTER_PROTOS:
        # rev33 (P3.1): отсутствующий ready_* — unknown (None), а не
        # False: пропуск ключа ранее изображался как подтверждённый down.
        rkey = 'ready_' + key
        if rkey in raw:
            result['ready'][key] = raw[rkey] == '1'
    try:
        timestamp = int(raw.get('timestamp', '0'))
        now = int(time.time())
        if timestamp > 0:
            if timestamp > now + 30:
                # rev33 (P3.1): штамп в будущем (переведённые часы,
                # подделка) — не «свежий снимок с age=0», а недостоверный:
                # возраст отрицателен, снимок считается устаревшим.
                result['status_age'] = None
            else:
                result['status_age'] = max(0, now - timestamp)
    except (TypeError, ValueError):
        pass
    age = result['status_age']
    if age is not None and age <= ROUTER_STATUS_MAX_AGE:
        result['status_stale'] = False
    else:
        result['effective'] = selected
        result['state'] = 'unknown'
        result['ready'] = {key: None for key in ROUTER_PROTOS}
    return result


# FB-65 (аудит-32, R55-03): сериализация выбора протокола маршрутизации.
# Прежде _write_router_proto использовал фиксированный router_proto.tmp:
# два потокa POST /api/router-proto открывали/замещали один путь —
# 25–46 FileNotFoundError на 160 конкурентных вызовов (замер отчёта
# r55), а конкурентные rebuild ходили по разным выборам. Уникальный
# mkstemp (0600 — отдельный chmod не нужен) + fsync + атомарный
# replace; весь POST (проверка → запись → rebuild) — под RLock.
_ROUTER_PROTO_LOCK = threading.RLock()


def _write_router_proto(v):
    _rp_dir = os.path.dirname(ROUTER_PROTO_FILE) or '.'
    _rp_fd, _rp_tmp = tempfile.mkstemp(
        prefix='.router_proto.', suffix='.tmp', dir=_rp_dir)
    try:
        with os.fdopen(_rp_fd, 'w', encoding='utf-8') as f:
            f.write(v + '\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(_rp_tmp, ROUTER_PROTO_FILE)
    except BaseException:
        try:
            os.unlink(_rp_tmp)
        except OSError:
            pass
        raise


class RedirectRebuildError(RuntimeError):
    def __init__(self, results):
        self.results = results
        summary = ', '.join(
            f"{name}=rc{item['rc']}" for name, item in results.items())
        super().__init__('netfilter hook: ' + summary)


def _hook_table_run(tbl, timeout=90):
    # rev33 (P2.8): таймаут — параметр. nat: 90 c; mangle получает
    # max(20, 120 − время nat), чтобы связка не висела минуты на слабом
    # роутере, но у mangle всегда оставался шанс завершить cleanup.
    env = dict(os.environ)
    env.update({'type': 'iptable', 'table': tbl})
    process = subprocess.Popen(
        ['sh', '/opt/etc/ndm/netfilter.d/100-redirect.sh'],
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True)
    timed_out = False
    try:
        out, _ = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            pass
        # Parent мог завершиться, оставив потомка в своей process group.
        group_alive = False
        try:
            os.killpg(process.pid, 0)
            group_alive = True
        except ProcessLookupError:
            pass
        except OSError as e:
            logging.error('netfilter hook process-group probe: %s', e)
        if group_alive:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except OSError as e:
                logging.error('netfilter hook process-group KILL: %s', e)
        try:
            out, _ = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            out = ''
    rc = process.returncode
    if timed_out:
        rc = 124
    if rc is None:
        rc = 125
    return {
        'rc': rc,
        'timed_out': timed_out,
        'log': (out or '')[-1000:],
    }


def _rebuild_redirect():
    # Обе таблицы запускаются даже при ошибке первой: mangle может успеть
    # поставить fail-closed fallback для отказавшего nat REDIRECT.
    # rev33 (P2.8): общий бюджет ~120 c — nat до 90 c, mangle — остаток,
    # но не меньше 20 c.
    results = {}
    _rb_started = time.monotonic()
    results['nat'] = _hook_table_run('nat', timeout=90)
    _rb_elapsed = int(time.monotonic() - _rb_started)
    results['mangle'] = _hook_table_run(
        'mangle', timeout=max(20, 120 - _rb_elapsed))
    if any(item['rc'] != 0 for item in results.values()):
        raise RedirectRebuildError(results)
    return results


@app.route('/api/router-proto')
def api_router_proto():
    selected = _read_router_proto()
    status = _router_proto_status(selected)
    return jsonify({
        'proto': selected,
        'effective': status['effective'],
        'state': status['state'],
        'ready': status['ready'],
        'status_age': status['status_age'],
        'status_stale': status['status_stale'],
        'readiness_kind': 'local-listener-snapshot',
        'installed': _router_proto_installed()})


@app.route('/api/router-proto', methods=['POST'])
def api_router_proto_set():
    _check_csrf()
    # FB-65 (аудит-32, R55-03): весь POST — под RLock.
    with _ROUTER_PROTO_LOCK:
        v = (request.form.get('proto') or '').strip()
        if v not in ROUTER_PROTOS:
            return jsonify({
                'ok': False, 'error': 'Неизвестный протокол'}), 400
        if not _router_proto_installed().get(v):
            return jsonify({
                'ok': False,
                'error': 'Пакет ' + ROUTER_PROTOS[v][1]
                         + ' не установлен'}), 409
        try:
            _write_router_proto(v)
        except Exception as e:
            logging.error('router-proto write: %s', e)
            return jsonify({
                'ok': False, 'error': 'Не удалось записать файл'}), 500
        try:
            applied = _rebuild_redirect()
        except RedirectRebuildError as e:
            logging.error('router-proto rebuild: %s', e)
            return jsonify({
                'ok': False,
                'saved': True,
                'applied': e.results,
                'error': 'Выбор сохранён, но применение правил не '
                         'подтверждено. Проверьте hook status и выполните '
                         'nat/mangle rebuild вручную.'}), 500
        except Exception as e:
            logging.error('router-proto rebuild: %s', e)
            return jsonify({
                'ok': False,
                'saved': True,
                'error': 'Выбор сохранён, но перестройка правил '
                         'не удалась. Примените вручную: '
                         'type=iptable table=nat '
                         '/opt/etc/ndm/netfilter.d/100-redirect.sh'}), 500
        return jsonify({
            'ok': True, 'proto': v, 'saved': True, 'applied': applied})


@app.route('/api/lookup', methods=['POST'])
def api_lookup():
    # Единое CSRF-покрытие всех POST-маршрутов (ревью 2026-10-12):
    # раньше этот единственный endpoint был без проверки.
    _check_csrf()
    query = (request.form.get('query')
             or '').strip()
    if not query:
        return jsonify({
            'error': 'Пустой запрос'})
    return jsonify(
        _lookup_resource(query))


@app.route('/')
def index():
    # Дашборд (этап 1) — главная страница; вкладки проекта как раньше.
    active = request.args.get(
        'tab', 'dash')
    # r89 (NFQWS2): 'za' — рельс группы «Протоколы» указывает
    # на /?tab=za (как и остальные вкладки протоколов).
    if active not in (
            'dash', 'ss', 'tr', 'vl',
            'to', 'hy', 'za', 'bt', 'lk',
            'upd', 'dns', 'cfg'):
        active = 'dash'
    return _render(active)


@app.route('/panel')
def panel_embed():
    # FB-136 (вариант A): содержимое прежней панели для MD3-обёртки.
    # Прямой заход тоже работает — это полноценная прежняя страница.
    # Все POST-редиректы ведут сюда же: внутри iframe навигация не
    # выносит пользователя на оболочку (иначе вложенный хром).
    active = request.args.get('tab', 'ss')
    if active not in PANEL_TABS:
        active = 'ss'
    return _render_legacy(active)


@app.route('/key/ss', methods=['POST'])
def key_ss():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ SS', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=ss')
    try:
        shadowsocks_config(key)
        restart_service('shadowsocks')
        flash('\u2705 SS: ключ', 'ok')
    except Exception as e:
        log_error(f'[w]ss: {e}')
        flash(f'\u274c SS — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=ss')


@app.route('/key/tr', methods=['POST'])
def key_tr():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ TR', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=tr')
    try:
        trojan_config(key)
        restart_service('trojan')
        flash('\u2705 Trojan: ключ', 'ok')
    except Exception as e:
        log_error(f'[w]tr: {e}')
        flash(f'\u274c TR — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=tr')


@app.route('/key/vl', methods=['POST'])
def key_vl():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ VL', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=vl')
    try:
        vless_config(key)
        restart_service('vless')
        flash('\u2705 VLESS: ключ', 'ok')
    except Exception as e:
        log_error(f'[w]vl: {e}')
        flash(f'\u274c VL — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=vl')


@app.route('/key/to', methods=['POST'])
def key_to():
    _check_csrf()
    o = (request.form.get(
        'obfs4_bridges') or '').strip()
    w = (request.form.get(
        'webtunnel_bridges') or '').strip()
    if not o and not w:
        flash('\u274c Мост', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=to')
    parts = [p for p in [o, w] if p]
    try:
        tor_config('\n'.join(parts))
        restart_service('tor')
        flash('\u2705 Tor: мосты', 'ok')
    except Exception as e:
        log_error(f'[w]to: {e}')
        flash(f'\u274c Tor — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=to')


@app.route('/key/hy', methods=['POST'])
def key_hy():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ HY', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=hy')
    try:
        hysteria_config(key)
        restart_service('hysteria')
        flash('\u2705 Hysteria: ключ',
              'ok')
    except Exception as e:
        log_error(f'[w]hy: {e}')
        flash(f'\u274c HY — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=hy')


@app.route('/config/ss', methods=['POST'])
def config_ss():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=ss')
    try:
        apply_direct_config(
            'shadowsocks', data)
        restart_service('shadowsocks')
        flash('\u2705 SS: конфиг', 'ok')
    except Exception as e:
        log_error(f'[w]ss cfg: {e}')
        flash(f'\u274c SS — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=ss')


@app.route('/config/tr', methods=['POST'])
def config_tr():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=tr')
    try:
        apply_direct_config(
            'trojan', data)
        restart_service('trojan')
        flash('\u2705 Trojan: конфиг',
              'ok')
    except Exception as e:
        log_error(f'[w]tr cfg: {e}')
        flash(f'\u274c TR — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=tr')


@app.route('/config/vl', methods=['POST'])
def config_vl():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=vl')
    try:
        # FB-213 (2026-11-01): предупреждения apply_direct_config
        # (например, geoip:… — убрано: нет geoip.dat) добавляются
        # к сообщению об успехе; отдельной категории flash нет.
        _warns = (
            apply_direct_config(
                'vless', data) or [])
        restart_service('vless')
        _ok = '\u2705 VLESS: конфиг'
        if _warns:
            _ok += ' — ' + '; '.join(_warns)
        flash(_ok, 'ok')
    except Exception as e:
        log_error(f'[w]vl cfg: {e}')
        flash(f'\u274c VL — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=vl')


@app.route('/config/hy', methods=['POST'])
def config_hy():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=hy')
    try:
        apply_direct_config(
            'hysteria', data)
        restart_service('hysteria')
        flash('\u2705 Hysteria: конфиг',
              'ok')
    except Exception as e:
        log_error(f'[w]hy cfg: {e}')
        flash(f'\u274c HY — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + '?tab=hy')


def _nfw2_tunnel_entries():
    """r89 (П4): множество записей туннельных списков
    (unblock/{ss,tr,vl,to,hy}.txt, нижний регистр). bot.txt —
    DNS-исключение бота, не туннель: api.telegram.org должен
    иметь возможность жить в user.list (П8); nfqws2 — сам
    user.list."""
    out = set()
    for k in ('shadowsocks', 'trojan', 'vless',
              'tor', 'hysteria'):
        fp = BYPASS_FILES.get(k)
        if not fp:
            continue
        try:
            with open(fp, 'r', encoding='utf-8',
                      errors='replace') as f:
                for ln in f:
                    e = _clean_entry(ln)
                    if e:
                        out.add(e.lower())
        except OSError:
            pass
    return out


def _nfw2_cross_clean(content):
    """r89 (П4, решение владельца): при сохранении user.list записи,
    уже стоящие в списках туннелей, УДАЛЯЮТСЯ — они уходят в туннель
    (mangle PREROUTING) и nfqws2 их не увидит. Возвращает
    (очищенный content, список убранных)."""
    tunnels = _nfw2_tunnel_entries()
    removed = []
    out = []
    for ln in (content or '').splitlines():
        e = _clean_entry(ln)
        if e and e.lower() in tunnels:
            if e not in removed:
                removed.append(e)
            continue
        out.append(ln)
    return '\n'.join(out), removed


def _nfw2_clean_userlist_from(saved_path):
    """r89 (П4, обратное направление): после сохранения туннельного
    списка вычистить из user.list пересечения с ним. Ревизия user.list
    меняется — открытая вкладка NFQWS2 при следующем сохранении
    получит штатный конфликт ревизий (strict-механизм FB-70).
    Возвращает список убранных записей."""
    ul = config.list_files.get('nfqws2', '')
    if not ul or not os.path.isfile(ul) \
            or not os.path.isfile(saved_path):
        return []
    saved = set()
    try:
        with open(saved_path, 'r', encoding='utf-8',
                  errors='replace') as f:
            for ln in f:
                e = _clean_entry(ln)
                if e:
                    saved.add(e.lower())
    except OSError:
        return []
    if not saved:
        return []
    removed = []
    with _list_write_guard(ul):
        try:
            with open(ul, 'r', encoding='utf-8',
                      errors='replace') as f:
                body = f.read()
        except OSError:
            return []
        out = []
        for ln in body.splitlines():
            e = _clean_entry(ln)
            if e and e.lower() in saved:
                if e not in removed:
                    removed.append(e)
                continue
            out.append(ln)
        if removed:
            _atomic_write_text(ul, '\n'.join(out) + '\n')
    return removed


def _save_list_route(
        lk, tab, filepath=None,
        skip_global_dedup=False):
    _check_csrf()
    content = (request.form.get(
        'content') or '').strip()
    if filepath is None:
        filepath = BYPASS_FILES[lk]
    # r89 (П4): user.list — вычистить пересечения со списками туннелей
    # ДО сохранения (они уходят в туннель, nfqws2 их не увидит).
    _nfw2_removed = []
    if lk == 'nfqws2':
        content, _nfw2_removed = \
            _nfw2_cross_clean(content)
    # FB-63 (аудит-32, R55-01) → FB-70 (аудит-33, K58-1/R58-02):
    # конфликт устаревшей вкладки. Прежде rev проверялся по os.stat
    # ДО взятия guard (TOCTOU: между проверкой и записью файл успевал
    # измениться), а `if _rev:` пропускал формы с пустым rev и молча
    # затирал чужие правки. Теперь compare-and-write атомарен внутри
    # guard (parse_and_save_if_revision), ревизия = SHA-256 байтов
    # файла, режим строгий: без rev или с пустым rev при существующем
    # непустом файле — конфликт «перечитайте страницу» ( формы,
    # открытые до обновления панели, обязаны перегрузиться).
    _rev = (request.form.get('rev') or '').strip()
    try:
        result = parse_and_save_if_revision(
            filepath, content,
            expected_rev=_rev,
            skip_global_dedup=(
                skip_global_dedup))
    except ListRevisionConflict:
        flash(
            '\u26a0\ufe0f ' + lk + '.txt изменён после загрузки '
            'вкладки (другой правкой) или вкладка устарела. '
            'Перечитайте страницу и повторите.', 'err')
        return redirect(
            url_for('panel_embed') + f'?tab={tab}')
    except ValueError as e:
        # FB-87 (аудит-35, K60-03): ошибки ВАЛИДАЦИИ ввода (превышение
        # лимита строк «Строк: N», кривой путь) — это ответ
        # пользователю, а не сбой сервера. Прежде ValueError из
        # parse_and_save_if_revision не ловился вовсе: Flask отвечал
        # HTTP 500 с трейсбеком в лог, введённый текст терялся без
        # объяснения. Теперь — flash с лимитом/причиной и возврат на
        # вкладку (клиентский чек FB-46 остаётся первой линией —
        # этот перехват страхует API-бота и прямые POST).
        ve = str(e)
        if ve.startswith('Строк:'):
            try:
                n = int(ve.split(':', 1)[1])
            except (IndexError, ValueError):
                n = None
            msg = (f'\u26a0\ufe0f {lk}.txt: слишком большой список '
                   f'— {n if n is not None else "более"} строк'
                   if n is not None else
                   f'\u26a0\ufe0f {lk}.txt: слишком большой список')
            msg += (f' (лимит {MAX_LIST_LINES} строк). '
                    'Сократите список или разделите его.')
        else:
            msg = (f'\u26a0\ufe0f {lk}.txt: '
                   f'{html.escape(ve)}')
        flash(msg, 'err')
        return redirect(
            url_for('panel_embed') + f'?tab={tab}')
    try:
        # r89 (П4): сохранён туннельный список — вычистить пересечения
        # из user.list (ревизия user.list меняется, strict-конфликт
        # открытой вкладки — штатный механизм FB-70). До apply:
        # чистка не зависит от пересборки ipset.
        _nfw2_back = []
        if (lk in BYPASS_FILES
                and lk not in ('nfqws2', 'bot')):
            _nfw2_back = _nfw2_clean_userlist_from(
                os.path.abspath(filepath))
        # r89 (NFQWS2): user.list не участвует в ipset-редиректах —
        # полный цикл пересборки не запускаем.
        if lk != 'nfqws2':
            # Обновляем ТОЛЬКО затронутый набор: полный цикл резолвит
            # сотни доменов всех протоколов и занимает десятки секунд,
            # хотя изменился один список.
            apply_unblock_async(
                config.ipset_names.get(lk, ''))
        s = _format_details(
            result['domains'],
            result['ips'],
            result['cidr'])
        # r89 (za): реальное имя файла пакета — user.list
        # (lk='nfqws2' дал бы бессмысленное «nfqws2.txt»).
        _shown = ('user.list'
                  if lk == 'nfqws2'
                  else f'{lk}.txt')
        msg = f'\u2705 {_shown}: {s}'
        if result.get('cidr_report'):
            msg += '\n' + '\n'.join(
                result['cidr_report'])
        if result['duplicates']:
            msg += '\n' + '\n'.join(
                result['duplicates'])
        if result['errors']:
            msg += '\n' + '\n'.join(
                result['errors'])
        if _nfw2_removed:
            msg += ('\n\u26a0\ufe0f Убраны (уже в списках '
                    'туннелей — уходят в туннель, nfqws2 их не '
                    'увидит): ' + ', '.join(_nfw2_removed))
        if _nfw2_back:
            msg += ('\n\u26a0\ufe0f user.list: убраны '
                    + ', '.join(_nfw2_back)
                    + ' (теперь в списке туннеля)')
        flash(msg, 'ok')
    except Exception as e:
        log_error(f'[w]{lk}: {e}')
        flash(f'\u274c {lk} — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('panel_embed') + f'?tab={tab}')


# ── r87 (NFQWS2): конфликтные протоколы и toggle с автовыключением ──
# Вкладка панели — r88 (мокап на утверждение); серверная механика
# (toggle с блокирующим предупреждением, force-автовыключение
# конфликтных, JSON-статус, сохранение списка) — r87.
_NFQWS2_CONFLICTS = (
    # (имя для set_service_enabled, человекочитаемое)
    ('shadowsocks', 'Shadowsocks'),
    ('trojan', 'Trojan'),
    ('vless', 'VLESS'),
    ('tor', 'Tor'),
    ('hysteria', 'Hysteria'),
)


def _nfqws2_conflicts():
    """Активные конфликтные протоколы.
    r91 (аудит r90, Г): единый детектор с ботом и force-путями —
    utils.nfqws2_conflicts() (ENABLED=yes ИЛИ живой процесс pidof).
    Прежний локальный разбор видел только ENABLED=yes: процесс,
    оставшийся живым при ENABLED=no (отказ stop), был для панели
    невидим — NFQWS2 Глобал включался при живом туннеле."""
    import utils as _u
    titles = dict(_NFQWS2_CONFLICTS)
    return [(n, titles.get(n, n)) for n in _u.nfqws2_conflicts()]

def _nfqws2_installed():
    return os.path.isfile(
        config.paths.get(
            'init_nfqws2',
            '/opt/etc/init.d/S90nfqws2')) \
        and os.path.isfile('/opt/etc/init.d/S51nfqws2')


def _toggle_nfqws2(tab, want, force=False):
    """r87 (NFQWS2): включение — блокирующее предупреждение при
    активных туннелях (петля перехвата); force — автовыключение
    конфликтных и включение. Выключение — безусловно. IntelliQOS —
    уведомление, не блокирует (решение владельца 2026-11-01)."""
    if not _nfqws2_installed():
        flash('\u274c nfqws2 не установлен '
              '(пакеты ставит deploy_bypass.sh)', 'err')
        return redirect(url_for('panel_embed') + '?tab=' + tab)
    if not want:
        try:
            _flash_reapply_warning(
                set_service_enabled('nfqws2', False))
            flash('\u26a0\ufe0f nfqws2 отключён', 'ok')
        except Exception as e:
            log_error(f'[w]toggle nfqws2 off: {e}')
            flash(f'\u274c nfqws2 — '
                  f'{html.escape(str(e))}', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=' + tab)

    # r89 (П1): блокирующая проверка — только Глобал/Авто; в Селективе
    # туннели и nfqws2 не пересекаются (разные списки/цепи).
    conflicts = _nfqws2_conflicts() \
        if _nfqws2_status()['conflicts_required'] else []
    names = ', '.join(t for _sn, t in conflicts)
    if conflicts and not force:
        flash('\u274c NFQWS2 (Глобал/Авто) конфликтует с '
              'активными туннелями: ' + names + ' — правила '
              'затронут их соединения к VPS и DNS-апстримы. '
              'Выключите туннели или используйте автовыключение. '
              'Для одновременной работы переключите nfqws2 в '
              'селективный режим.', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=' + tab)
    _stopped_t = []
    _ra_bad = False
    try:
        if conflicts:
            for sn, _t in _nfqws2_conflicts():
                # r94 (аудит r93, KZ93-06): результат каждого stop
                # учитывается (r93 игнорировал отказ переприменения
                # правил в этом цикле), остановленные накапливаются
                # для честного сообщения при частичном сбое
                if set_service_enabled(sn, False) is False:
                    _ra_bad = True
                _stopped_t.append(_t)
            # r91 (аудит r90, Г): stop подтверждается исчезновением
            # процесса (единый детектор видит и ENABLED=no + pidof) —
            # живой остаток означает неснятый конфликт, NFQWS2 не
            # включаем.
            _alive = _nfqws2_conflicts()
            if _alive:
                # r95 (аудит r94, KZ94-03): в «выключены» — только
                # подтверждённо остановленные; живой остаток прежде
                # попадал и в «Не удалось остановить», и в «выключены»
                _alive_t = [t for _sn, t in _alive]
                _conf_t = [t for t in _stopped_t
                           if t not in _alive_t]
                flash('❌ Не удалось остановить: '
                      + ', '.join(_alive_t)
                      + ' — NFQWS2 не включён (процессы ещё живы)'
                      + ('' if not _conf_t else
                         ' (выключены: '
                         + ', '.join(_conf_t) + ')')
                      + ('' if not _ra_bad else
                         '; ⚠️ правила перехвата не переприменились'),
                      'err')
                return redirect(
                    url_for('panel_embed') + '?tab=' + tab)
        # r89 (П3): перед стартом — managed-excludes для endpoint'ов
        # роутера (VPS туннелей, DNS-апстримов): селектив без них
        # слеп к смене VPS, Глобал/Авто — модифицирует соединения
        # к VPS. Тихий вызов; пакет не установлен — no-op.
        try:
            import utils as _u
            _u.nfqws2_update_excludes_quiet()
        except Exception:  # noqa: BLE001
            pass
        _ra_ok = set_service_enabled('nfqws2', True)
        msg = '\u2705 nfqws2 включён'
        if _stopped_t:
            msg += (' (выключены: '
                    + ', '.join(_stopped_t) + ')')
        # r95 (аудит r94, KZ94-03): предупреждение определяется
        # ФИНАЛЬНЫМ результатом reapply (финальный запуск включает
        # переприменение правил): промежуточный _ra_bad здесь не
        # актуален — успешный финал переприменил правила повторно
        if _ra_ok is False:
            msg += ('\n⚠️ Правила перехвата не переприменились — '
                    'перепроверьте состояние протоколов '
                    '(подробности в логе)')
        if _nfqws2_intelliqos_suspected():
            flash('\u26a0\ufe0f IntelliQOS: вероятно, включен — '
                  'DPI-правила nfqws2 могут не срабатывать '
                  '(flow offloading). Отключите IntelliQOS в '
                  'веб-конфигураторе.', 'err')
        # r89: success-сообщение не терялось — flash здесь, а не
        # «после except» (исключение в msg-ветке гасило бы его).
        flash(msg, 'ok')
    except Exception as e:
        log_error(f'[w]toggle nfqws2 on: {e}')
        # r94 (аудит r93, KZ93-06): частичный force-stop не молчит —
        # уже остановленные перечисляются вместе с результатом
        # переприменения правил
        _em = f'\u274c nfqws2 — {html.escape(str(e))}'
        if _stopped_t:
            _em += (' (выключены: ' + ', '.join(_stopped_t) + ')')
        if _ra_bad:
            _em += '; ⚠️ правила перехвата не переприменились'
        flash(_em, 'err')
    return redirect(url_for('panel_embed') + '?tab=' + tab)


def _nfqws2_status():
    """r89 (NFQWS2): сводка состояния — /api/nfqws2 и вкладка панели.
    П1: conflicts_required — блокирующая проверка нужна только в
    Глобал/Авто; в Селективе механизмы не пересекаются (туннели —
    mangle PREROUTING по ipset, nfqws2 — POSTROUTING по hostlist)."""
    conf_dir = config.paths.get(
        'nfqws2_dir', '/opt/etc/nfqws2')
    conf = os.path.join(conf_dir, 'nfqws2.conf')
    mode = ''
    try:
        with open(conf, 'r', encoding='utf-8',
                  errors='replace') as f:
            m = re.search(
                r'(?m)^NFQWS_EXTRA_ARGS="\$MODE_([A-Z]+)"',
                f.read())
        if m:
            mode = m.group(1).lower()
    except OSError:
        pass
    version = ''
    try:
        r = subprocess.run(
            ['opkg', 'info', 'nfqws2-keenetic'],
            capture_output=True, text=True, timeout=20)
        m = re.search(r'(?m)^Version:\s*(\S+)',
                      r.stdout or '')
        if m:
            version = m.group(1)
    except (subprocess.SubprocessError, OSError):
        pass
    running = False
    try:
        r = subprocess.run(
            ['pidof', 'nfqws2'], capture_output=True,
            text=True, timeout=10)
        running = bool((r.stdout or '').strip())
    except (subprocess.SubprocessError, OSError):
        pass
    conflicts = _nfqws2_conflicts()
    return {
        'installed': _nfqws2_installed(),
        'enabled': _read_enabled('nfqws2'),
        'running': running,
        'version': version,
        'mode': mode,
        'conflicts': [t for _sn, t in conflicts],
        'conflicts_required': mode in ('all', 'auto'),
        'intelliqos_suspected':
            _nfqws2_intelliqos_suspected(),
        'gui_url': 'http://{}:90'.format(
            config.routerip),
        'list_file': config.list_files.get(
            'nfqws2', ''),
    }


@app.route('/api/nfqws2')
def api_nfqws2():
    """r87/r89 (NFQWS2): JSON-статус для UI и бота."""
    return jsonify(_nfqws2_status())


@app.route('/mode/za', methods=['POST'])
def mode_za():
    """r89 (NFQWS2, П2): переключение режима с защитой — переход на
    Глобал/Авто при включённой nfqws2 и живых туннелях блокируется
    (flash + возврат); force=1 — автовыключение туннелей и переход
    (utils.nfqws2_set_mode).
    r91 (аудит r90, Е): смена режима — под межпроцессным lock'ом
    переключений (панель+бот — одна транзакция)."""
    _check_csrf()
    tab = 'za'
    mode = (request.form.get('mode') or '').strip().lower()
    force = request.form.get('force') == '1'
    if mode not in ('list', 'all', 'auto'):
        flash('\u274c Неизвестный режим', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=' + tab)
    import utils as _u
    # r91 (Е): занято — вежливое «повторите позже».
    if not _u.acquire_toggle_lock():
        flash('⏳ Другая операция переключения уже выполняется — '
              'повторите через несколько секунд', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=' + tab)
    try:
        ok, msg = _u.nfqws2_set_mode(mode, force=force)
    finally:
        _u.release_toggle_lock()
    flash(('\u2705 ' if ok else '\u274c ')
          + html.escape(msg), 'ok' if ok else 'err')
    return redirect(
        url_for('panel_embed') + '?tab=' + tab)

@app.route('/toggle/<tab>', methods=['POST'])
def toggle_service(tab):
    _check_csrf()
    # r91 (аудит r90, Е): межпроцессная сериализация переключений
    # (панель+бот) — проверки конфликтов и применение составляют
    # одну транзакцию; занято — вежливый «повторите позже».
    import utils as _u
    if not _u.acquire_toggle_lock():
        flash('⏳ Другая операция переключения уже выполняется — '
              'повторите через несколько секунд', 'err')
        return redirect(url_for('panel_embed') + '?tab=' + tab)
    try:
        return _toggle_service_locked(tab)
    finally:
        _u.release_toggle_lock()


def _toggle_service_locked(tab):

    sn = TAB_TO_SERVICE.get(tab)
    if not sn:
        flash('\u274c Неизвестный протокол', 'err')
        return redirect(url_for('panel_embed'))

    want = request.form.get('enabled') == '1'
    if sn == 'nfqws2':
        # r87: блокирующее предупреждение/автовыключение конфликтных.
        return _toggle_nfqws2(
            tab, want,
            force=request.form.get('force') == '1')

    # r91 (аудит r90, Г): тот же guard, что у бота (protocol_configured) —
    # включение туннеля без заданного ключа/мостов блокируется;
    # прежде панель молча ставила ENABLED=yes и рапортовала «✅ включён».
    import utils as _u
    if (want and sn in dict(_NFQWS2_CONFLICTS)
            and not _u.protocol_configured(sn)):
        _t = dict(_NFQWS2_CONFLICTS)[sn]
        _hint = ('мосты' if sn == 'tor' else 'ключ')
        flash(f'❌ {_t}: {_hint} не задан. Сначала задайте его '
              f'в «🔑 Ключи и мосты».', 'err')
        return redirect(
            url_for('panel_embed') + '?tab=' + tab)
    # r90 (решение владельца 02.11.2026, зеркальный П1): включение
    # туннеля при включённом NFQWS2 в Глобал/Авто блокируется —
    # правила nfqws2 затронут соединения протокола к его VPS;
    # force=1 (кнопка в предупреждении вкладки) — выключить NFQWS2
    # и включить протокол.
    if want and sn in dict(_NFQWS2_CONFLICTS):
        if _u.nfqws2_blocks_tunnels():
            if request.form.get('force') == '1':
                try:
                    _flash_reapply_warning(
                        set_service_enabled('nfqws2', False))
                except Exception as e:
                    log_error(
                        f'[w]mirror force nfqws2 off: {e}')
                    flash('\u274c NFQWS2 \u2014 '
                          f'{html.escape(str(e))}',
                          'err')
                    return redirect(
                        url_for('panel_embed')
                        + '?tab=' + tab)
            else:
                flash('❌ NFQWS2 (Глобал/Авто) включён — его правила '
                      'затронут соединения этого протокола к его VPS. '
                      'Выключите NFQWS2, переведите его в селективный '
                      'режим или используйте кнопку ниже.', 'err')
                return redirect(
                    url_for('panel_embed') + '?tab=' + tab)
    try:
        _ra_ok = set_service_enabled(sn, want)
        flash(
            ('\u2705 ' + sn + ' включён'
             if want else
             '\u26a0\ufe0f ' + sn + ' отключён'),
            'ok')
        _flash_reapply_warning(_ra_ok)
    except Exception as e:
        log_error(f'[w]toggle {sn}: {e}')
        flash(f'\u274c {sn} — {html.escape(str(e))}', 'err')
    return redirect(
        url_for('panel_embed') + '?tab=' + tab)


@app.route('/list/ss', methods=['POST'])
def list_ss():
    return _save_list_route(
        'shadowsocks', 'ss')


@app.route('/list/tr', methods=['POST'])
def list_tr():
    return _save_list_route(
        'trojan', 'tr')


@app.route('/list/vl', methods=['POST'])
def list_vl():
    return _save_list_route(
        'vless', 'vl')


@app.route('/list/to', methods=['POST'])
def list_to():
    return _save_list_route(
        'tor', 'to')


@app.route('/list/hy', methods=['POST'])
def list_hy():
    return _save_list_route(
        'hysteria', 'hy')


@app.route('/list/bt', methods=['POST'])
def list_bt():
    return _save_list_route(
        'bot', 'bt',
        filepath=BOT_BYPASS_FILE,
        skip_global_dedup=True)


@app.route('/list/za', methods=['POST'])
def list_za():
    # r87 (NFQWS2): user.list пакета — напрямую (НЕ в unblock/):
    # список не попадает в ipset-редиректы проекта, им пользуется
    # только nfqws2 в селективном режиме.
    return _save_list_route(
        'nfqws2', 'za',
        filepath=config.list_files['nfqws2'],
        skip_global_dedup=True)


# FB-182 (аудит-47, A-R80-HTTP-01/B-R80-04): qvalue по RFC 9110 —
# 0..1, не более трёх дробных цифр, без экспоненты; всё остальное
# («q=bogus», «q=2», «q=inf», «q=1e3») — синтаксически неверно.
# FB-186 (аудит-48, A-R81-QV-01/KZ81-01): ASCII-грамматика qvalue по
# RFC 9110 — «0»/«1» либо «0.x»/«1.x» с 1–3 дробными цифрами [0-9]
# (преемник FB-182: \d матчило Unicode-цифры — 0.١ проходило как 0.1;
# 1./0. и 1.0000 отвергались неверно). Используется через fullmatch.
_QVAL_RE = re.compile(r'(?:0(?:\.[0-9]{0,3})?|1(?:\.0{0,3})?)')


def _accepts_gzip(header):
    """FB-170 (аудит-46, A-R79-04/B-R79-02): разбор Accept-Encoding
    по RFC 9110 вместо сырой подстроки. Прежние дефекты: 'gzip;q=0'
    (клиент явно запретил кодирование) и 'notgzip' приводили к сжатию,
    'GZip' — молча не сжимался. Токены регистронезависимы; явный q
    для gzip важнее '*'; без gzip и '*' — не сжимаем. FB-182
    (аудит-47): qvalue строго по RFC (см. _QVAL_RE) — мусорный или
    вне-диапазона q делает токен неприемлемым."""
    if not header:
        return False
    gzip_q = None
    star_q = 0.0
    for part in header.split(','):
        pieces = part.split(';')
        tok = pieces[0].strip().lower()
        if not tok:
            continue
        q = 1.0
        for param in pieces[1:]:
            p = param.strip()
            if p[:2].lower() == 'q=':
                # FB-182/FB-186 (аудит-47/48): строгий qvalue по RFC —
                # полное совпадение ASCII-грамматики (см. _QVAL_RE).
                # Мусорный или вне-диапазона q (bogus/2/inf/1e3/1.001/
                # Unicode-цифры) делает токен неприемлемым (fail-closed,
                # без сжатия); валидные «1.»/«0.» разбираются по смыслу.
                if _QVAL_RE.fullmatch(p[2:]):
                    q = float(p[2:])
                else:
                    q = 0.0
        if tok == 'gzip':
            gzip_q = q
        elif tok == '*':
            star_q = max(star_q, q)
    if gzip_q is not None:
        return gzip_q > 0
    return star_q > 0


@app.after_request
def gzip_response(resp):
    # FB-153 (аудит-44, опция 2): gzip крупных текстовых ответов
    # (stdlib). Страницы панели 18–106 КБ сжимаются на 68–76% — заметно
    # при доступе по Wi-Fi. Мелкие ответы (поллинг /api/dashboard,
    # <1 КБ) не сжимаются ради экономии CPU роутера.
    # FB-170 (аудит-46): неготиация по RFC 9110 + Vary:
    # Accept-Encoding на ОБЕИХ representations — представление
    # зависит от заголовка; прежде identity-вариант ≥1 КБ оставался
    # без Vary и мог потерять gzip-вариант в частном кэше, а Vary
    # перезаписывался вместо добавления.
    if resp.status_code != 200 or resp.direct_passthrough:
        return resp
    ctype = (resp.headers.get('Content-Type') or '')
    if not ctype.startswith(('text/html', 'application/json',
                             'text/css')):
        return resp
    if len(resp.data) < 1024:
        return resp
    _vary = resp.headers.get('Vary')
    _parts = ([v.strip() for v in _vary.split(',')]
              if _vary else [])
    # FB-182 (аудит-47, A-R80-HTTP-01): сравнение без учёта регистра —
    # «Accept-Encoding» и «accept-encoding» — одно поле; прежде дубль
    # с другим регистром прошёл бы в Vary.
    if not any(v.lower() == 'accept-encoding'
               for v in _parts):
        _parts.append('Accept-Encoding')
        resp.headers['Vary'] = ', '.join(_parts)
    if not _accepts_gzip(
            request.headers.get('Accept-Encoding') or ''):
        return resp
    packed = gzip.compress(resp.data, 6)
    if len(packed) >= len(resp.data):
        return resp
    resp.data = packed
    resp.headers['Content-Encoding'] = 'gzip'
    return resp


if __name__ == '__main__':
    app.config['MAX_CONTENT_LENGTH'] = (
        MAX_CONTENT_LENGTH)
    rotate_log()
    setup_firewall(LISTEN_PORT)

    # Слушаем на всех интерфейсах: у роутера несколько внутренних адресов
    # (основная сеть, гостевая, отдельный бридж для 5 ГГц, VPN-сервер
    # прошивки). При host=LAN_IP панель отвечала только по 192.168.1.1,
    # и Wi-Fi-клиенты из другой подсети получали отказ соединения.
    # Доступ извне при этом закрыт двумя рубежами: правило DROP в INPUT
    # (setup_firewall) и проверка подсети в security_checks().
    print(
        f"\n  http://{LAN_IP}"
        f":{LISTEN_PORT}\n")
    # r93 (аудит r92, KZ92-02 — слабые устройства 64–128 МБ):
    # Werkzeug (threaded=True) создаёт поток на каждое соединение;
    # системный стек потока (обычно 8 МБ) на 32-бит MIPS/ARM
    # раздувает адресное пространство при бёрсте вкладок/поллинга
    # (замер аудита r92: 129 потоков на 128 cold-запросах).
    # 256 КБ достаточно для обработчиков панели; вместе с семафором
    # дорогих маршрутов это ограничивает память панели.
    try:
        threading.stack_size(256 * 1024)
    except (ValueError, RuntimeError, OverflowError):
        pass
    app.run(
        host='0.0.0.0',
        port=LISTEN_PORT,
        debug=False,
        threaded=True,
        use_reloader=False)
