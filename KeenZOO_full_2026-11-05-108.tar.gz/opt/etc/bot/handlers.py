import subprocess
import os
import re
import time
import json
import queue
import signal
import threading
import lists_core
import bot_config as config
from menu import (
    MENU_MAIN, MENU_BYPASS_FILES, MENU_SERVICE,
    MENU_KEYS_BRIDGES, MENU_BYPASS_LIST,
    MENU_ADD_BYPASS, MENU_REMOVE_BYPASS,
    MENU_TOR, MENU_SHADOWSOCKS, MENU_VLESS,
    MENU_TROJAN, MENU_HYSTERIA, MENU_NFQWS2,
    create_bypass_files_menu, create_backup_menu,
    BackupState, create_drive_selection_menu,
    create_delete_archive_menu,
    create_dns_override_menu,
    create_install_remove_menu,
    create_protocols_toggle_menu
)
from utils import (
    download_script, vless_config, trojan_config,
    shadowsocks_config, tor_config, hysteria_config,
    get_available_drives,
    create_backup_with_params, log_error,
    keys_bridges_warnings,
    # r87 (NFQWS2): статус/конфликты/вкл-выкл без Flask-стека.
    nfqws2_status_text, nfqws2_conflicts,
    nfqws2_installed, nfqws2_enabled,
    nfqws2_set_enabled, nfqws2_user_list_preview,
    nfqws2_mode, nfqws2_set_mode,
    nfqws2_intelliqos_suspected,
    nfqws2_conflicts_required,
    protocol_enabled, active_tunnels,
    protocol_configured, protocol_set_enabled,
    nfqws2_blocks_tunnels,
    acquire_toggle_lock, release_toggle_lock,
    PROTOCOL_ORDER, PROTOCOL_TITLES
)

# Единый префикс защищённых callback-действий: любое из них выполняет
# привилегированную операцию (перезапуск, обновление, бэкап, изменение
# конфигурации) и требует проверки пользователя.

_gen = None
# Telegram обрабатывает callback-и в нескольких потоках. Не допускаем
# одновременные update/restore/remove даже до межпроцессного shell-lock.
_LIFECYCLE_LOCK = threading.Lock()


def _load_gen():
    # C9 (ревью 2026-10-12): parse_and_save живёт в lists_core без
    # Flask — теперь обработка списков не поднимает в бот-процессе
    # веб-стек (раньше import_module('generator') тянул его навсегда).
    global _gen
    if _gen is None:
        import importlib
        _gen = importlib.import_module('lists_core')
    return _gen


def _is_valid_cidr(entry):
    m = re.match(
        r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.'
        r'(\d{1,3})/(\d{1,2})$', entry)
    if not m:
        return False
    # M6/F4 (аудит rev4 #6): паритет с shell is_cidr/is_ip и
    # lists_core — октеты с ведущими нулями запрещены.
    _lz = m.groups()
    if any(len(g) > 1 and g[0] == '0' for g in _lz[:4]):
        return False
    octets = [int(m.group(i)) for i in range(1, 5)]
    prefix = int(m.group(5))
    return (all(o <= 255 for o in octets)
            and 0 <= prefix <= 32)


def _is_valid_ip(entry):
    m = re.match(
        r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.'
        r'(\d{1,3})$', entry)
    if not m:
        return False
    # M6/F4 (аудит rev4 #6): паритет с shell — октеты с ведущими
    # нулями запрещены (см. _is_valid_cidr выше).
    _lz = m.groups()
    if any(len(g) > 1 and g[0] == '0' for g in _lz):
        return False
    return all(
        int(m.group(i)) <= 255
        for i in range(1, 5))


def _is_valid_entry(clean):
    if '/' in clean:
        return _is_valid_cidr(clean)
    if _is_valid_ip(clean):
        return True
    if clean.startswith('#'):
        return False
    # K4 (повторный аудит 2026-10-12): та же семантика, что у
    # shell is_domain_core и lists_core._validate_entry —
    # одна реализация (импорт ниже — лёгкий модуль без Flask).
    from lists_core import _validate_domain_core
    host = (clean[2:]
            if clean.startswith('*.')
            else clean)
    if ' ' in host:
        return False
    return _validate_domain_core(host.lower())


class BotState:
    """
    Состояние меню. Хранится отдельно для каждого чата: раньше объект был
    один на весь процесс, и параллельная работа двух администраторов
    приводила к тому, что действие одного применялось к файлу, выбранному
    другим.
    """

    def __init__(self):
        self._by_chat = {}

    def _get(self, chat_id):
        st = self._by_chat.get(chat_id)
        if st is None:
            st = {'menu': MENU_MAIN, 'file': ''}
            self._by_chat[chat_id] = st
        return st

    def get_menu(self, chat_id):
        return self._get(chat_id)['menu']

    def set_menu(self, chat_id, menu):
        self._get(chat_id)['menu'] = menu

    def get_file(self, chat_id):
        return self._get(chat_id)['file']

    def set_file(self, chat_id, name):
        self._get(chat_id)['file'] = name


# R42-6 (аудит-12, F-7): чтение/очистка/сортировка списков — единые
# реализации lists_core (прежде — идентичные локальные копии, дрейфовавшие
# с панелью: бот сортировал строково, панель — числово по IP).
def get_clean_entry(entry):
    return lists_core._clean_entry(entry)


def load_bypass_blocks(filepath):
    return [
        {'comment': cc, 'entries': list(entries)}
        for cc, entries in lists_core._read_blocks(filepath)
    ]



def sections_to_text(sections):
    # R46-2 (аудит-16): та же логика, что у рендера parse_and_save в
    # lists_core — порядок файла; пустая строка только после блока с
    # записями (прежде вставлялась и между заголовком и подзаголовком).
    lines = []
    _prev = False
    for section in sections:
        if section['comment'] is not None:
            if lines and _prev:
                lines.append('')
            lines.append(
                f"# {section['comment']}")
        elif lines and _prev:
            lines.append('')
        for entry in section['entries']:
            lines.append(entry)
        _prev = bool(section['entries'])
    return '\n'.join(lines)


def save_via_generator(filepath, sections):
    g = _load_gen()
    text = sections_to_text(sections)
    is_bot = (
        os.path.basename(filepath) == 'bot.txt')
    return g.parse_and_save(
        filepath, text,
        skip_global_dedup=is_bot)


def parse_input_blocks(text):
    sections = []
    current_section = None
    for line in text.split('\n'):
        stripped = line.strip()
        if not stripped:
            current_section = None
            continue
        if stripped.startswith('#'):
            comment = stripped[1:].strip()
            current_section = {
                'comment': comment,
                'entries': []}
            sections.append(current_section)
        else:
            if current_section is None:
                current_section = {
                    'comment': None,
                    'entries': []}
                sections.append(current_section)
            current_section['entries'].append(
                stripped)
    return [s for s in sections if s['entries']]


def format_blocks_for_display(sections):
    # R48-5 (аудит-18): отображение выровнено с рендером сохранения
    # (R46-2): порядок файла, comment-only секции видны, записи внутри
    # секции сортируются тем же _sort_key. Прежняя версия поднимала
    # безымянные записи в конец и прятала заголовки без записей —
    # показ расходился с файлом и с тем, что пишет сохранение.
    if not sections:
        return "Список пуст"
    ordered = [
        {'comment': s['comment'],
         'entries': sorted(
             s['entries'],
             key=lists_core._sort_key)}
        for s in sections
    ]
    text = sections_to_text(ordered)
    return text if text else "Список пуст"


def _all_bypass_filepaths():
    filepaths = [
        os.path.join(
            config.paths['unblock_dir'],
            'shadowsocks.txt'),
        os.path.join(
            config.paths['unblock_dir'],
            'tor.txt'),
        os.path.join(
            config.paths['unblock_dir'],
            'vless.txt'),
        os.path.join(
            config.paths['unblock_dir'],
            'trojan.txt'),
        os.path.join(
            config.paths['unblock_dir'],
            'hysteria.txt'),
    ]
    try:
        for name in os.listdir(
                config.paths['unblock_dir']):
            if (name.startswith('vpn-')
                    and name.endswith('.txt')):
                filepaths.append(
                    os.path.join(
                        config.paths['unblock_dir'],
                        name))
    except OSError as e:
        log_error(f"log_bypass_files listdir: {e}")
    return filepaths


def _build_global_bypass_index(
        exclude_filepath=None):
    global_map = {}
    for filepath in _all_bypass_filepaths():
        if (exclude_filepath
                and os.path.realpath(filepath)
                == os.path.realpath(
                    exclude_filepath)):
            continue
        sections = load_bypass_blocks(filepath)
        file_label = os.path.splitext(
            os.path.basename(filepath))[0]
        for section in sections:
            comment = section['comment']
            for entry in section['entries']:
                clean = get_clean_entry(entry)
                if clean and clean not in global_map:
                    global_map[clean] = {
                        'file': file_label,
                        'comment': comment}
    return global_map


def setup_handlers(bot):
    state = BotState()
    backup_state = BackupState()


    def _allowed_user(user):
        try:
            allowed = {
                int(value)
                for value in getattr(
                    config,
                    'allowed_user_ids',
                    [])
            }
            user_id = int(
                getattr(user, 'id', 0))
        except (TypeError, ValueError):
            return False

        return bool(allowed) and user_id in allowed

    def is_allowed_message(message):
        if (message.chat.type != 'private'
                or not _allowed_user(message.from_user)):
            try:
                bot.send_message(
                    message.chat.id,
                    '⚠️ Нет доступа!')
            except Exception:  # noqa: BLE001
                # Уведомление «Нет доступа» обязано не мешать защите:
                # любой сбой отправки (сеть, лимиты TG) игнорируется.
                pass
            return False
        return True

    def is_allowed_call(call):
        if (not getattr(call, 'message', None)
                or call.message.chat.type != 'private'
                or not _allowed_user(call.from_user)):
            try:
                bot.answer_callback_query(
                    call.id,
                    '⚠️ Нет доступа!',
                    show_alert=True)
            except Exception:  # noqa: BLE001
                # См. is_allowed_message: сбой отправки не должен
                # уронить обработчик callback.
                pass
            return False
        return True



    def set_menu_and_reply(
            chat_id, new_menu,
            text=None, markup=None):
        state.set_menu(chat_id, new_menu)
        if not text:
            text = new_menu.name
        bot.send_message(
            chat_id, text,
            reply_markup=(
                markup if markup
                else new_menu.markup))

    def go_to_bypass_files(chat_id):
        create_bypass_files_menu()
        set_menu_and_reply(
            chat_id, MENU_BYPASS_FILES)

    def go_to_keys_bridges(chat_id):
        # При открытии меню показываем, какие конфиги содержат только
        # плейсхолдеры вместо ключей и не забыт ли Tor без мостов
        # (пункты плана №4/№15: пользователь должен сразу видеть,
        # что требует его ввода).
        warnings = keys_bridges_warnings()
        text = MENU_KEYS_BRIDGES.name
        if warnings:
            text += "\n\n" + "\n".join(warnings)
        set_menu_and_reply(
            chat_id, MENU_KEYS_BRIDGES, text)

    def handle_bypass_files_selection(message):
        # P8 (аудит rev3): путь от пользователя обязан остаться внутри
        # unblock_dir и не содержать переходов вида ../ — иначе меню
        # читало бы любой существующий файл с таким суффиксом.
        _base = os.path.realpath(
            config.paths['unblock_dir'])
        filepath = os.path.realpath(
            f"{config.paths['unblock_dir']}"
            f"{message.text}.txt")
        if (not filepath.startswith(_base + os.sep)
                or '..' in message.text):
            bot.send_message(
                message.chat.id,
                '⚠️ Некорректное имя файла.')
            return
        if not os.path.exists(filepath):
            bot.send_message(
                message.chat.id,
                "❌ Неверный выбор",
                reply_markup=(
                    MENU_BYPASS_FILES.markup))
            return
        state.set_file(message.chat.id, message.text)
        set_menu_and_reply(
            message.chat.id,
            MENU_BYPASS_LIST,
            "Меню " + state.get_file(message.chat.id))

    def send_long_message(
            chat_id, text, parse_mode=None):
        current_part = ""
        for line in text.split('\n'):
            if (len(current_part + '\n' + line)
                    > 4096):
                bot.send_message(
                    chat_id, current_part,
                    parse_mode=parse_mode)
                current_part = line
            else:
                current_part += (
                    '\n' + line
                    if current_part else line)
        if current_part:
            bot.send_message(
                chat_id, current_part,
                parse_mode=parse_mode)

    def handle_bypass_list_menu(message):
        selected = state.get_file(message.chat.id)
        filepath = (
            f"{config.paths['unblock_dir']}"
            f"{selected}.txt")
        if message.text == "📄 Показать список":
            sections = load_bypass_blocks(filepath)
            text = format_blocks_for_display(
                sections)
            send_long_message(
                message.chat.id, text)
            bot.send_message(
                message.chat.id,
                "Меню " + selected,
                reply_markup=(
                    MENU_BYPASS_LIST.markup))
        elif message.text == "➕ Добавить в список":
            set_menu_and_reply(
                message.chat.id,
                MENU_ADD_BYPASS,
                "Введите сайт, домен, IP "
                "или CIDR\n\n"
                "#Секция\ngoogle.com\nbing.com"
                "\n\n"
                "130.255.77.28 #заметка\n"
                "216.13.24.0/24\n\n"
                "💡 CIDR объединяются "
                "автоматически")
        elif message.text == "➖ Удалить из списка":
            set_menu_and_reply(
                message.chat.id,
                MENU_REMOVE_BYPASS,
                "Введите адрес для удаления")
        else:
            bot.send_message(
                message.chat.id,
                "❌ Выберите действие из меню",
                reply_markup=(
                    MENU_BYPASS_LIST.markup))

    def handle_add_to_bypass(message):
        selected = state.get_file(message.chat.id)
        filepath = (
            f"{config.paths['unblock_dir']}"
            f"{selected}.txt")
        existing_sections = load_bypass_blocks(
            filepath)
        existing_clean_map = {}
        for s in existing_sections:
            for entry in s['entries']:
                clean = get_clean_entry(entry)
                if clean not in existing_clean_map:
                    existing_clean_map[clean] = (
                        entry, s['comment'])
        is_bot = (
            os.path.basename(filepath)
            == 'bot.txt')
        if is_bot:
            global_clean_map = {}
        else:
            global_clean_map = (
                _build_global_bypass_index(
                    exclude_filepath=filepath))
        sections_map = {}
        for section in existing_sections:
            sec_key = section['comment']
            if sec_key not in sections_map:
                sections_map[sec_key] = section
        new_sections = parse_input_blocks(
            message.text)
        if not new_sections:
            bot.send_message(
                message.chat.id,
                "❕Не введено ни одного адреса",
                reply_markup=(
                    MENU_ADD_BYPASS.markup))
            return
        added_count = 0
        duplicate_msgs = []
        error_msgs = []
        input_seen = {}
        for new_section in new_sections:
            comment = new_section['comment']
            if comment in sections_map:
                target = sections_map[comment]
            else:
                target = {
                    'comment': comment,
                    'entries': []}
                sections_map[comment] = target
                if comment is None:
                    existing_sections.append(target)
                else:
                    none_idx = next(
                        (i for i, s in enumerate(
                            existing_sections)
                         if s['comment'] is None),
                        None)
                    if none_idx is not None:
                        existing_sections.insert(
                            none_idx, target)
                    else:
                        existing_sections.append(
                            target)
            for entry in new_section['entries']:
                clean = get_clean_entry(entry)
                if not clean:
                    continue
                if not _is_valid_entry(clean):
                    error_msgs.append(
                        f"⚠️ Некорректно: {clean}")
                    continue
                if clean in input_seen:
                    fc = input_seen[clean]
                    duplicate_msgs.append(
                        f"• {clean} → дубликат"
                        + (f" (#{fc})"
                           if fc else ""))
                    continue
                input_seen[clean] = comment
                if clean in existing_clean_map:
                    _, ec = (
                        existing_clean_map[clean])
                    duplicate_msgs.append(
                        f"• {clean} → уже"
                        + (f" в #{ec}" if ec
                           else " в списке"))
                    continue
                if clean in global_clean_map:
                    info = global_clean_map[clean]
                    duplicate_msgs.append(
                        f"• {clean} → в "
                        f"{info['file']}.txt"
                        + (f" (#{info['comment']})"
                           if info['comment']
                           else ""))
                    continue
                target['entries'].append(entry)
                existing_clean_map[clean] = (
                    entry, comment)
                added_count += 1
        if added_count > 0:
            result = save_via_generator(
                filepath, existing_sections)
            msg_parts = [
                "✅ Добавлено, применяю..."]
            if result.get('cidr_report'):
                msg_parts.extend(
                    result['cidr_report'])
            bot.send_message(
                message.chat.id,
                '\n'.join(msg_parts))
            subprocess.Popen(
                config.services["unblock_update"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True)
        if duplicate_msgs:
            bot.send_message(
                message.chat.id,
                "❕Дубликаты:\n"
                + "\n".join(duplicate_msgs))
        if error_msgs:
            bot.send_message(
                message.chat.id,
                "❌ Некорректные:\n"
                + "\n".join(error_msgs))
        if (added_count == 0
                and not duplicate_msgs
                and not error_msgs):
            bot.send_message(
                message.chat.id,
                "❕Было добавлено ранее")
        set_menu_and_reply(
            message.chat.id,
            MENU_BYPASS_LIST,
            "Меню " + selected)

    def handle_remove_from_bypass(message):
        selected = state.get_file(message.chat.id)
        filepath = (
            f"{config.paths['unblock_dir']}"
            f"{selected}.txt")
        to_remove = {
            get_clean_entry(line)
            for line in message.text.split('\n')
            if line.strip()
            and not line.strip().startswith('#')}
        if not to_remove:
            bot.send_message(
                message.chat.id,
                "❕Введите адрес для удаления",
                reply_markup=(
                    MENU_REMOVE_BYPASS.markup))
            return
        existing_sections = load_bypass_blocks(
            filepath)
        removed_count = 0
        for section in existing_sections:
            before = len(section['entries'])
            section['entries'] = [
                e for e in section['entries']
                if get_clean_entry(e)
                not in to_remove]
            removed_count += (
                before - len(section['entries']))
        existing_sections = [
            s for s in existing_sections
            if s['entries']]
        if removed_count > 0:
            result = save_via_generator(
                filepath, existing_sections)
            msg_parts = [
                "✅ Удалено, применяю..."]
            if result.get('cidr_report'):
                msg_parts.extend(
                    result['cidr_report'])
            bot.send_message(
                message.chat.id,
                '\n'.join(msg_parts))
            subprocess.Popen(
                config.services["unblock_update"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True)
        else:
            bot.send_message(
                message.chat.id,
                "❕Не найдено в списке")
        set_menu_and_reply(
            message.chat.id,
            MENU_BYPASS_LIST,
            "Меню " + selected)

    def handle_keys_bridges_selection(message):
        if message.text == 'Tor':
            set_menu_and_reply(
                message.chat.id, MENU_TOR,
                "🔑 Вставьте мосты Tor")
        elif message.text == 'Shadowsocks':
            set_menu_and_reply(
                message.chat.id,
                MENU_SHADOWSOCKS,
                "🔑 Вставьте ключ Shadowsocks")
        elif message.text == 'Vless':
            set_menu_and_reply(
                message.chat.id, MENU_VLESS,
                "🔑 Вставьте ключ Vless")
        elif message.text == 'Trojan':
            set_menu_and_reply(
                message.chat.id, MENU_TROJAN,
                "🔑 Вставьте ключ Trojan")
        elif message.text == 'Hysteria':
            set_menu_and_reply(
                message.chat.id,
                MENU_HYSTERIA,
                "🔑 Вставьте ключ Hysteria2\n"
                "hy2://пароль@сервер:порт"
                "?sni=домен&alpn=h3#имя")
        elif message.text == 'NFQWS2':
            # r87: пункт NFQWS2 — последний в списке протоколов.
            set_menu_and_reply(
                message.chat.id, MENU_NFQWS2,
                nfqws2_status_text())
        else:
            bot.send_message(
                message.chat.id,
                "❌ Выберите протокол",
                reply_markup=(
                    MENU_KEYS_BRIDGES.markup))

    def nfqws2_run_updater(chat_id):
        """
        r87 (NFQWS2): гибридное обновление nfqws2 —
        /opt/bin/update_protocols.sh nfqws2 (GitHub vs opkg).
        """
        script = config.paths.get(
            "update_protocols",
            "/opt/bin/update_protocols.sh")
        if not os.path.exists(script):
            bot.send_message(
                chat_id, "❌ update_protocols.sh "
                "не найден",
                reply_markup=MENU_NFQWS2.markup)
            return
        bot.send_message(
            chat_id, "⏳ Обновляю nfqws2...")
        try:
            result = subprocess.run(
                ["sh", script, "nfqws2"],
                capture_output=True, text=True,
                timeout=600)
            out = (result.stdout or "")
            err = (result.stderr or "")
            tail = "\n".join(
                (out + "\n" + err).strip().splitlines()
            )[-1500:]
            bot.send_message(
                chat_id,
                ("📄 update_protocols.sh nfqws2:\n"
                 + (tail or "без вывода")),
                reply_markup=MENU_NFQWS2.markup)
        except (subprocess.SubprocessError,
                OSError) as e:
            log_error(f"nfqws2 update: {e}")
            bot.send_message(
                chat_id,
                "❌ Ошибка обновления nfqws2",
                reply_markup=MENU_NFQWS2.markup)

    def handle_nfqws2_toggle(chat_id):
        """
        r87 (NFQWS2): единый toggle. r89 (П1): блокирующее
        предупреждение — только в Глобал/Авто; в Селективе туннели
        (mangle PREROUTING по ipset) и nfqws2 (POSTROUTING по
        user.list) не пересекаются — включаем свободно.
        """
        if not nfqws2_installed():
            bot.send_message(
                chat_id,
                "❌ nfqws2 не установлен.\n"
                "Установка — deploy_bypass.sh "
                "(установка проекта).",
                reply_markup=MENU_NFQWS2.markup)
            return
        # r91 (аудит r90, Е): toggle nfqws2 — под межпроцессным
        # lock'ом (панель+бот), проверки и применение — одна
        # транзакция.

        if not acquire_toggle_lock():
            bot.send_message(
                    chat_id, "⏳ Другая операция переключения "
                         "выполняется — попробуйте ещё раз.",
                    reply_markup=MENU_NFQWS2.markup)
            return
        try:
            if nfqws2_enabled():
                ok, msg = nfqws2_set_enabled(False)
                bot.send_message(
                    chat_id, msg,
                    reply_markup=MENU_NFQWS2.markup)
                return
            conflicts = nfqws2_conflicts()
            # r89 (П1): блокирующая проверка — только Глобал/Авто.
            required = nfqws2_conflicts_required()
            warn = ""
            if nfqws2_intelliqos_suspected():
                # IntelliQOS не блокирует — уведомление
                # с продолжением (решение владельца 01.11).
                warn += ("\n⚠️ IntelliQOS: вероятно, включен. "
                         "DPI-правила nfqws2 могут не "
                         "срабатывать (flow offloading). "
                         "Обход — отключить IntelliQOS в "
                         "веб-конфигураторе.")
            if conflicts and required:
                from telebot import types as tg_types
                markup = tg_types.InlineKeyboardMarkup(
                    row_width=1)
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "⚡ Выключить конфликтные и включить",
                        callback_data="nfqws2_force_on"))
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "❌ Отмена",
                        callback_data="nfqws2_cancel"))
                bot.send_message(
                    chat_id,
                    "🚫 NFQWS2 (Глобал/Авто) конфликтует с "
                    "активными туннелями: "
                    + ", ".join(conflicts)
                    + " — правила затронут их соединения "
                    "к VPS и DNS-апстримы.\nВыключите "
                    "туннели или используйте "
                    "автовыключение. Для одновременной "
                    "работы переключите nfqws2 в "
                    "селективный режим."
                    + warn,
                    reply_markup=markup)
                return
            ok, msg = nfqws2_set_enabled(True)
            if warn:
                msg += warn
            bot.send_message(
                chat_id, msg,
                reply_markup=MENU_NFQWS2.markup)
        finally:
            release_toggle_lock()

    def handle_nfqws2_menu(message):
        # r87 (NFQWS2): level 13.
        if message.text == '📊 Статус':
            bot.send_message(
                message.chat.id,
                nfqws2_status_text(),
                reply_markup=MENU_NFQWS2.markup)
        elif message.text == '🔀 Вкл/Выкл':
            handle_nfqws2_toggle(message.chat.id)
        elif message.text == '🔄 Обновить':
            nfqws2_run_updater(message.chat.id)
        elif message.text == '📋 Домены':
            _shown, text = (
                nfqws2_user_list_preview())
            bot.send_message(
                message.chat.id, text,
                reply_markup=MENU_NFQWS2.markup)
        elif message.text == '⚙️ Режим':
            # r87: селектив/глобал/авто — переключатель в боте
            # (решение владельца: и в панели, и в боте; панель — r88).
            from telebot import types as tg_types
            cur = nfqws2_mode() or 'неизвестен'
            markup = tg_types.InlineKeyboardMarkup(
                row_width=1)
            markup.add(
                tg_types.InlineKeyboardButton(
                    "📄 Селектив (user.list)",
                    callback_data="nfqws2_mode_list"))
            markup.add(
                tg_types.InlineKeyboardButton(
                    "🌐 Глобал (кроме exclude.list)",
                    callback_data="nfqws2_mode_all"))
            markup.add(
                tg_types.InlineKeyboardButton(
                    "🤖 Авто (автодетект)",
                    callback_data="nfqws2_mode_auto"))
            markup.add(
                tg_types.InlineKeyboardButton(
                    "❌ Отмена",
                    callback_data="nfqws2_cancel"))
            bot.send_message(
                message.chat.id,
                "⚙️ Текущий режим nfqws2: " + cur
                + "\n\nВыберите новый режим:",
                reply_markup=markup)
        else:
            bot.send_message(
                message.chat.id,
                "❌ Выберите из меню",
                reply_markup=MENU_NFQWS2.markup)

    def update_service(
            chat_id, service_name,
            config_func, restart_cmd):
        try:
            config_func()
            # Перезапуск службы не должен подвешивать бота.
            result = subprocess.run(
                restart_cmd,
                capture_output=True,
                text=True,
                timeout=120)
            if result.returncode == 0:
                bot.send_message(
                    chat_id,
                    f'✅ {service_name} '
                    f'перезапущен')
                return True, None
            else:
                err = (
                    result.stderr.strip()
                    or result.stdout.strip()
                    or "Неизвестная ошибка")
                bot.send_message(
                    chat_id,
                    f'❌ Ошибка '
                    f'{service_name}: {err}')
                return False, err
        except Exception as e:
            log_error(f"{service_name}: {e}")
            return False, str(e)

    def handle_tor_manually(message):
        success, _ = update_service(
            message.chat.id, "Tor",
            lambda: tor_config(
                message.text, bot,
                message.chat.id),
            config.services["tor_restart"])
        if success:
            set_menu_and_reply(
                message.chat.id,
                MENU_KEYS_BRIDGES)
        else:
            bot.send_message(
                message.chat.id,
                "❕Попробуйте заново",
                reply_markup=(
                    state.get_menu(
                        message.chat.id).markup))

    def handle_shadowsocks(message):
        success, _ = update_service(
            message.chat.id, "Shadowsocks",
            lambda: shadowsocks_config(
                message.text, bot,
                message.chat.id),
            config.services[
                "shadowsocks_restart"])
        if success:
            set_menu_and_reply(
                message.chat.id,
                MENU_KEYS_BRIDGES)
        else:
            bot.send_message(
                message.chat.id,
                "❕Попробуйте заново",
                reply_markup=(
                    state.get_menu(
                        message.chat.id).markup))

    def handle_vless(message):
        success, _ = update_service(
            message.chat.id, "Vless",
            lambda: vless_config(
                message.text, bot,
                message.chat.id),
            config.services["vless_restart"])
        if success:
            set_menu_and_reply(
                message.chat.id,
                MENU_KEYS_BRIDGES)
        else:
            bot.send_message(
                message.chat.id,
                "❕Попробуйте заново",
                reply_markup=(
                    state.get_menu(
                        message.chat.id).markup))

    def handle_trojan(message):
        success, _ = update_service(
            message.chat.id, "Trojan",
            lambda: trojan_config(
                message.text, bot,
                message.chat.id),
            config.services[
                "trojan_restart"])
        if success:
            set_menu_and_reply(
                message.chat.id,
                MENU_KEYS_BRIDGES)
        else:
            bot.send_message(
                message.chat.id,
                "❕Попробуйте заново",
                reply_markup=(
                    state.get_menu(
                        message.chat.id).markup))

    def handle_hysteria(message):
        success, _ = update_service(
            message.chat.id, "Hysteria",
            lambda: hysteria_config(
                message.text, bot,
                message.chat.id),
            config.services[
                "hysteria_restart"])
        if success:
            set_menu_and_reply(
                message.chat.id,
                MENU_KEYS_BRIDGES)
        else:
            bot.send_message(
                message.chat.id,
                "❕Попробуйте заново",
                reply_markup=(
                    state.get_menu(
                        message.chat.id).markup))

    def handle_restart(chat_id):
        bot.send_message(
            chat_id,
            "⏳ Бот будет перезапущен!\n"
            "Это займет 15-30 секунд",
            reply_markup=MENU_SERVICE.markup)
        with open(
                config.paths["chat_id_path"],
                'w') as f:
            f.write(str(chat_id))
        subprocess.Popen(
            config.services['service_script'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True)

    def handle_backup(chat_id):
        bot.send_message(
            chat_id,
            "Выберите файлы для бэкапа:",
            reply_markup=create_backup_menu(
                backup_state))

    def handle_install_remove(chat_id):
        bot.send_message(
            chat_id, "Выберите действие:",
            reply_markup=(
                create_install_remove_menu()))

    def handle_dns_override(chat_id):
        bot.send_message(
            chat_id, "Выберите действие:",
            reply_markup=(
                create_dns_override_menu()))

    def handle_updates(chat_id):
        """r90 (решение владельца 02.11.2026): экран «🆕 Обновления» —
        ТОЛЬКО протоколы обхода (Shadowsocks/Trojan/Vless/Hysteria/
        Tor/NFQWS2); секция версий самого бота и кнопка «Обновить
        бота» удалены (версии бота всегда совпадали — get_remote_
        версию возвращал локальную, UI был мёртвым)."""
        # Сохранить chat_id для уведомлений
        try:
            with open(
                    config.paths.get(
                        "chat_id_notify",
                        "/opt/var/run/"
                        "bot_chat_id_notify.txt"),
                    'w') as f:
                f.write(str(chat_id))
        except OSError as e:
            log_error(f"chat_id notify write: {e}")

        bot.send_message(
            chat_id, "⏳ Проверяю обновления...")

        # Запустить проверку протоколов.
        # r91 (аудит r90, Д): статус принимается только от текущего
        # запуска (ts >= момента старта) — прежде при таймауте/
        # ошибке читался прежний файл, и бот показывал его как
        # свежий результат («✅ Всё актуально» по старым данным).
        # Допуск 2 с: check_updates пишет ts = date +%s (усечённая
        # секунда), латентность запуска — иначе быстрый прогон в
        # той же секунде ложно помечался устаревшим.
        _t0 = time.time() - 2.0
        check_script = config.paths.get(
            "check_updates",
            "/opt/bin/check_updates.sh")
        if os.path.exists(check_script):
            try:
                subprocess.run(
                    [check_script], timeout=60)
            except (OSError, subprocess.SubprocessError) as e:
                log_error(f"check_updates run: {e}")

        # Прочитать результат
        updates_info = None
        _stale = False
        status_file = config.paths.get(
            "updates_status",
            "/tmp/updates_status.json")
        try:
            if os.path.exists(status_file):
                with open(status_file, 'r') as f:
                    updates_info = json.load(f)
                # r93 (аудит r92, KZ92-04): ts принимается только
                # числовым и конечным (строка/bool/NaN в валидном
                # JSON прежде давали не пойманный TypeError и
                # обрывали обработчик после «⏳ Проверяю…»).
                # r94 (аудит r93, KZ93-05): корень не объект — статуса
                # нет вовсе (прежде truthy список/строка доходили до
                # .get → AttributeError); ts из будущего (часы ушли
                # вперёд и вернулись) свежим не считается; схема
                # полей нормализуется — versions только dict, updates
                # только список полных записей (мусор не роняет
                # обработчик и не даёт ложного «✅ Всё актуально»).
                if not isinstance(updates_info, dict):
                    updates_info = None
                    _stale = True
                else:
                    _ts = updates_info.get('ts')
                    if (isinstance(_ts, bool)
                            or not isinstance(_ts, (int, float))
                            or not _ts
                            or _ts != _ts
                            or _ts == float('inf')
                            or _ts < _t0
                            or _ts > time.time() + 60.0):
                        _stale = True
                    _v = updates_info.get('versions')
                    if not isinstance(_v, dict):
                        updates_info['versions'] = {}
                    # r95 (аудит r94, KZ94-04): валидность updates
                    # отслеживается — отсутствующий/не-список/с
                    # отброшенными записями статус НЕ считается
                    # подтверждённым «нет обновлений» (прежде молчаливая
                    # нормализация к [] давала ложное «✅ Всё актуально»)
                    _upd = updates_info.get('updates')
                    _upd_ok = isinstance(_upd, list)
                    if _upd_ok:
                        _filtered = [
                            x for x in _upd
                            if isinstance(x, dict) and all(
                                k in x for k in (
                                    'name', 'current',
                                    'available', 'source'))]
                        if len(_filtered) != len(_upd):
                            _upd_ok = False
                        updates_info['updates'] = _filtered
                    else:
                        updates_info['updates'] = []
                    if not _upd_ok:
                        _stale = True
        except (OSError, ValueError) as e:
            log_error(f"updates status read: {e}")

        # Формируем сообщение (r90: только протоколы обхода)
        msg = ""
        if updates_info:
            versions = updates_info.get(
                'versions', {})
            if versions:
                msg += ("📦 <b>Версии "
                        "протоколов:</b>\n")
                for name, ver in versions.items():
                    msg += (f"• {name}: "
                            f"<code>{ver}</code>\n")

        updates = (updates_info.get('updates', [])
                   if updates_info else [])
        has_proto_updates = bool(updates)

        if has_proto_updates:
            msg += ("\n🆕 <b>Доступны "
                    "обновления:</b>\n")
            for upd in updates:
                msg += (
                    f"• <b>{upd['name']}</b>: "
                    f"{upd['current']} → "
                    f"{upd['available']} "
                    f"({upd['source']})\n")

        if _stale:
            # r91 (аудит r90, Д): файл статуса не обновился текущим
            # запуском — честная пометка вместо «✅ Всё актуально».
            msg += ("\n⏱ Проверка не завершена (таймаут или "
                    "ошибка) — показанные данные могут быть "
                    "устаревшими")
        if not has_proto_updates and not _stale:
            # FB-69 (аудит-32, R54-04): check_failed из статуса
            # check_updates (FB-47 пишет поле) прежде не читался —
            # «✅ Всё актуально» могло печататься при неудачной
            # проверке (недоступные источники). Теперь честная
            # формулировка; полный лог — в панели/файле статуса.
            # r90: статус недоступен вовсе (скрипта нет/ещё не
            # выполнялся) — не молчим и не обещаем «актуально».
            # r96 (аудит r95, KZ95-05): «актуально» — только при
            # подтверждённом bool-False: отсутствующее/не-bool поле
            # (старая схема, повреждение, 0/1) прежде трактовалось
            # по truthiness как УСПЕХ — неполная проверка давала
            # ложное «✅ Всё актуально»
            _cf = (updates_info or {}).get('check_failed')
            if _cf is True:
                msg += ("\n⚠️ Проверка обновлений не завершена "
                        "(часть источников недоступна) — "
                        "достоверность не гарантируется")
            elif _cf is not False:
                msg += ("\n⚠️ Проверка обновлений не завершена "
                        "(неполный статус проверки) — "
                        "достоверность не гарантируется")
            elif not ((updates_info or {})
                      .get('versions') or {}):
                msg = ("📦 Статус версий пока недоступен — "
                       "нажмите «🔄 Перепроверить»")
            else:
                msg += "\n✅ Всё актуально"

        # Inline-кнопки
        from telebot import types as tg_types
        markup = tg_types.InlineKeyboardMarkup(
            row_width=2)

        if has_proto_updates:
            has_github = any(
                u['source'] == 'github'
                for u in updates)
            has_opkg = any(
                u['source'] == 'opkg'
                for u in updates)
            if has_github:
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "🔄 xray/hysteria",
                        callback_data=(
                            "update_github")))
            if has_opkg:
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "🔄 opkg пакеты",
                        callback_data=(
                            "update_opkg")))
            markup.add(
                tg_types.InlineKeyboardButton(
                    "🔄 Обновить всё",
                    callback_data=(
                        "update_all")))

        markup.add(
            tg_types.InlineKeyboardButton(
                "🔄 Перепроверить",
                callback_data=(
                    "recheck_updates")))
        markup.add(
            tg_types.InlineKeyboardButton(
                "🔙 Назад",
                callback_data=(
                    "menu_service")))

        bot.send_message(
            chat_id, msg,
            parse_mode="HTML",
            reply_markup=markup)

    def _safe_reboot():
        """Перезагрузка роутера, не роняющая обработчик при сбое ndmc."""
        try:
            subprocess.run(
                ["ndmc", "-c", "system reboot"],
                timeout=60, check=False)
        except (subprocess.SubprocessError, OSError) as e:
            log_error(f"[!] reboot: {e}")

    def toggle_dns_override(chat_id, enable):
        cmd = (
            ["ndmc", "-c",
             "opkg dns-override"]
            if enable
            else ["ndmc", "-c",
                  "no opkg dns-override"])
        st = ("включен" if enable
              else "выключен")
        # ndmc обращается к службе прошивки: при её зависании бот не
        # должен блокироваться навсегда. Истёкшее ожидание — обычная
        # ошибка, о которой сообщаем пользователю, а не аварийное
        # завершение обработчика.
        try:
            subprocess.run(cmd, timeout=60, check=False)
            time.sleep(2)
            subprocess.run(
                ["ndmc", "-c",
                 "system configuration save"],
                timeout=60, check=False)
        except (subprocess.SubprocessError, OSError) as e:
            log_error(f"[!] dns-override: {e}")
            bot.send_message(
                chat_id,
                "❌ Не удалось применить DNS Override: "
                "служба ndmc не ответила.")
            return

        bot.send_message(
            chat_id,
            f'{"✅" if enable else "✖️"} '
            f'DNS Override {st}!\n'
            f'⏳ Роутер перезапускается!')
        time.sleep(5)
        try:
            subprocess.run(
                ["ndmc", "-c", "system reboot"],
                timeout=60, check=False)
        except (subprocess.SubprocessError, OSError) as e:
            log_error(f"[!] reboot: {e}")

    # ═══ r90 (решение владельца 02.11.2026): «🔌 Протоколы» —
    # inline Вкл/Выкл всех протоколов (вариант А). Порядок — как
    # в «Ключи и мосты» (+ NFQWS2). Зеркальный конфликт П1: включение
    # туннеля при NFQWS2 Глобал/Авто — блок с force (выключить
    # NFQWS2). Последний активный туннель — подтверждение.
    def _proto_states():
        states = {
            n: protocol_enabled(n)
            for n in PROTOCOL_ORDER if n != 'nfqws2'}
        states['nfqws2'] = nfqws2_enabled()
        return states

    def show_protocols_menu(chat_id):
        states = _proto_states()
        text = ["🔌 <b>Протоколы</b> — "
                "управление Вкл/Выкл:", ""]
        for n in PROTOCOL_ORDER:
            text.append(
                "• " + PROTOCOL_TITLES[n] + ": "
                + ("включен" if states[n]
                   else "выключен"))
        if (not active_tunnels()
                and states['nfqws2']):
            # П8 (r89): при выключенных туннелях домены bot.txt
            # уходят в fail-closed DROP — бот может замолчать.
            text.append(
                "\n⚠️ Все туннели выключены: домены бота "
                "(bot.txt) уходят в DROP. Рекомендация — "
                "перенести api.telegram.org в user.list "
                "(вкладка NFQWS2 панели).")
        bot.send_message(
            chat_id, "\n".join(text),
            parse_mode="HTML",
            reply_markup=(
                create_protocols_toggle_menu(states)))

    def _proto_screen(chat_id, name):
        """Экран протокола: статус + доступное действие."""
        from telebot import types as tg_types
        title = PROTOCOL_TITLES.get(name, name)
        if name == 'nfqws2':
            status = nfqws2_status_text()
            on = nfqws2_enabled()
        else:
            on = protocol_enabled(name)
            status = ("<b>" + title + "</b>: "
                      + ("включен" if on else "выключен"))
            if not protocol_configured(name):
                hint = ("мосты не заданы" if name == 'tor'
                        else "ключ не задан")
                status += ("\n⚠️ " + hint
                           + " — включение будет "
                           "заблокировано (задайте в "
                           "«🔑 Ключи и мосты»)")
        markup = tg_types.InlineKeyboardMarkup(
            row_width=2)
        if on:
            markup.add(
                tg_types.InlineKeyboardButton(
                    "⛔ Выключить",
                    callback_data="proto_off_" + name))
        else:
            markup.add(
                tg_types.InlineKeyboardButton(
                    "✅ Включить",
                    callback_data="proto_on_" + name))
        markup.add(
            tg_types.InlineKeyboardButton(
                "🔙 К списку",
                callback_data="proto_menu"))
        bot.send_message(
            chat_id, status,
            parse_mode="HTML",
            reply_markup=markup)

    def _proto_report(chat_id, msg):
        from telebot import types as tg_types
        markup = tg_types.InlineKeyboardMarkup(row_width=1)
        markup.add(
            tg_types.InlineKeyboardButton(
                "🔙 К списку протоколов",
                callback_data="proto_menu"))
        bot.send_message(
            chat_id, msg,
            reply_markup=markup)

    MENU_TRANSITIONS = {
        '🔙 Назад': lambda cid: (
            set_menu_and_reply(cid, next(
                (m for m in [
                    MENU_MAIN, MENU_SERVICE,
                    MENU_BYPASS_FILES,
                    MENU_KEYS_BRIDGES,
                    MENU_TOR,
                    MENU_SHADOWSOCKS,
                    MENU_VLESS,
                    MENU_TROJAN,
                    MENU_HYSTERIA,
                    MENU_BYPASS_LIST,
                    MENU_ADD_BYPASS,
                    MENU_REMOVE_BYPASS]
                 if m.level == (
                     state.get_menu(cid)
                     .back_level)),
                MENU_MAIN))),
        '📑 Списки обхода':
            go_to_bypass_files,
        '🔑 Ключи и мосты':
            go_to_keys_bridges,
        '⚙️ Сервис':
            lambda cid: (
                set_menu_and_reply(
                    cid, MENU_SERVICE)),
        '🤖 Перезапуск бота':
            handle_restart,
        '🔌 Перезапуск роутера':
            lambda cid: (
                bot.send_message(
                    cid,
                    "⏳ Роутер "
                    "перезапускается!",
                    reply_markup=(
                        MENU_SERVICE.markup)),
                _safe_reboot()),
        '⁉️ DNS Override':
            handle_dns_override,
        '🔁 Перезапуск сервисов':
            lambda cid: (
                bot.send_message(
                    cid,
                    '⏳ Перезапуск '
                    'сервисов...'),
                update_service(
                    cid, "Shadowsocks",
                    lambda: None,
                    config.services[
                        "shadowsocks_restart"]),
                update_service(
                    cid, "Tor",
                    lambda: None,
                    config.services[
                        "tor_restart"]),
                update_service(
                    cid, "Vless",
                    lambda: None,
                    config.services[
                        "vless_restart"]),
                update_service(
                    cid, "Trojan",
                    lambda: None,
                    config.services[
                        "trojan_restart"]),
                update_service(
                    cid, "Hysteria",
                    lambda: None,
                    config.services[
                        "hysteria_restart"]),
                bot.send_message(
                    cid,
                    '❕ Перезапуск завершен',
                    reply_markup=(
                        MENU_MAIN.markup))),
        '🆕 Обновления':
            handle_updates,
        '🔌 Протоколы':
            show_protocols_menu,
        '♻️ Восстановление и удаление':
            handle_install_remove,
        '💾 Бэкап':
            handle_backup,
    }

    LEVEL_HANDLERS = {
        1: handle_bypass_files_selection,
        2: handle_bypass_list_menu,
        3: handle_add_to_bypass,
        4: handle_remove_from_bypass,
        5: handle_keys_bridges_selection,
        8: handle_tor_manually,
        9: handle_shadowsocks,
        10: handle_vless,
        11: handle_trojan,
        12: handle_hysteria,
        13: handle_nfqws2_menu,
    }

    @bot.message_handler(commands=['start'])
    def start(message):
        if not is_allowed_message(message):
            return
        set_menu_and_reply(
            message.chat.id, MENU_MAIN)

    @bot.message_handler(
        content_types=['text'])
    def bot_message(message):
        if not is_allowed_message(message):
            return
        if message.text in MENU_TRANSITIONS:
            MENU_TRANSITIONS[message.text](
                message.chat.id)
        elif (state.get_menu(
                message.chat.id).level
              in LEVEL_HANDLERS):
            LEVEL_HANDLERS[
                state.get_menu(
                    message.chat.id).level](
                    message)
        else:
            bot.send_message(
                message.chat.id,
                "❌ Выберите из меню",
                reply_markup=(
                    state.get_menu(
                        message.chat.id).markup))

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "nfqws2_force_on")
    def handle_nfqws2_force_on(call):
        # r87 (NFQWS2): автовыключение конфликтных туннелей
        # и включение nfqws2 (кнопка блокирующего предупреждения).
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        try:
            bot.answer_callback_query(call.id)
        except Exception:  # noqa: BLE001
            pass
        try:
            bot.delete_message(cid, call.message.message_id)
        except Exception:  # noqa: BLE001
            pass
        # r91 (аудит r90, Е): под межпроцессным lock'ом.
        if not acquire_toggle_lock():
            bot.send_message(
                cid, "⏳ Другая операция переключения "
                     "выполняется — попробуйте ещё раз.",
                reply_markup=MENU_NFQWS2.markup)
            return
        try:
            bot.send_message(
                cid, "⏳ Выключаю конфликтные туннели, "
                "включаю nfqws2...")
            ok, msg = nfqws2_set_enabled(
                True, also_disable_conflicts=True)
        finally:
            release_toggle_lock()
        # IntelliQOS — уведомление с продолжением, не блокирует.
        if nfqws2_intelliqos_suspected():
            msg += ("\n⚠️ IntelliQOS: вероятно, включен — "
                    "DPI-правила могут не срабатывать "
                    "(flow offloading).")
        bot.send_message(
            cid, msg,
            reply_markup=MENU_NFQWS2.markup)

    @bot.callback_query_handler(
        func=lambda c:
            c.data.startswith("nfqws2_mode_"))
    def handle_nfqws2_mode(call):
        # r87: переключение селектив/глобал/авто. r89 (П2):
        # суффикс _force — подтверждённый переход с автовыключением
        # туннелей (кнопка блокирующего предупреждения).
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        force = call.data.endswith("_force")
        mode = call.data.replace("nfqws2_mode_", "")
        if force:
            mode = mode[:-len("_force")]
            try:
                bot.answer_callback_query(call.id)
            except Exception:  # noqa: BLE001
                pass
            try:
                bot.delete_message(cid, call.message.message_id)
            except Exception:  # noqa: BLE001
                pass
            # r91 (аудит r90, Е): под межпроцессным lock'ом.
            if not acquire_toggle_lock():
                bot.send_message(
                    cid, "⏳ Другая операция переключения "
                         "выполняется — попробуйте ещё раз.",
                    reply_markup=MENU_NFQWS2.markup)
                return
            try:
                bot.send_message(
                    cid, "⏳ Выключаю конфликтные туннели, "
                    "переключаю режим...")
                ok, msg = nfqws2_set_mode(mode, force=True)
            finally:
                release_toggle_lock()
            bot.send_message(
                cid, msg,
                reply_markup=MENU_NFQWS2.markup)
            return
        try:
            bot.answer_callback_query(call.id)
        except Exception:  # noqa: BLE001
            pass
        try:
            bot.delete_message(cid, call.message.message_id)
        except Exception:  # noqa: BLE001
            pass
        # r91 (аудит r90, Е): под межпроцессным lock'ом.
        if not acquire_toggle_lock():
            bot.send_message(
                cid, "⏳ Другая операция переключения "
                     "выполняется — попробуйте ещё раз.",
                reply_markup=MENU_NFQWS2.markup)
            return
        try:
            ok, msg = nfqws2_set_mode(mode)
        finally:
            release_toggle_lock()
        if not ok and mode in ('all', 'auto'):
            # r89 (П2): блок перехода на Глобал/Авто при живых
            # туннелях — inline-подтверждение с автовыключением.
            from telebot import types as tg_types
            markup = tg_types.InlineKeyboardMarkup(
                row_width=1)
            markup.add(
                tg_types.InlineKeyboardButton(
                    "⚡ Выключить туннели и переключить",
                    callback_data="nfqws2_mode_" + mode
                    + "_force"))
            markup.add(
                tg_types.InlineKeyboardButton(
                    "❌ Отмена",
                    callback_data="nfqws2_cancel"))
            bot.send_message(
                cid, msg,
                reply_markup=markup)
            return
        bot.send_message(
            cid, msg,
            reply_markup=MENU_NFQWS2.markup)

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "nfqws2_cancel")
    def handle_nfqws2_cancel(call):
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        try:
            bot.answer_callback_query(call.id)
        except Exception:  # noqa: BLE001
            pass
        try:
            bot.delete_message(cid, call.message.message_id)
        except Exception:  # noqa: BLE001
            pass
        bot.send_message(
            cid, "❕ Включение nfqws2 отменено",
            reply_markup=MENU_NFQWS2.markup)

    @bot.callback_query_handler(
        func=lambda c: c.data == "proto_menu")
    def handle_proto_menu(call):
        if not is_allowed_call(call):
            return
        try:
            bot.answer_callback_query(call.id)
        except Exception:  # noqa: BLE001
            pass
        cid = call.message.chat.id
        try:
            bot.delete_message(
                cid, call.message.message_id)
        except Exception:  # noqa: BLE001
            pass
        show_protocols_menu(cid)

    @bot.callback_query_handler(
        func=lambda c:
            c.data.startswith("proto_sel_"))
    def handle_proto_sel(call):
        if not is_allowed_call(call):
            return
        try:
            bot.answer_callback_query(call.id)
        except Exception:  # noqa: BLE001
            pass
        cid = call.message.chat.id
        name = call.data[len("proto_sel_"):]
        if name not in PROTOCOL_TITLES:
            return
        try:
            bot.delete_message(
                cid, call.message.message_id)
        except Exception:  # noqa: BLE001
            pass
        _proto_screen(cid, name)

    @bot.callback_query_handler(
        func=lambda c:
            c.data.startswith("proto_on_"))
    def handle_proto_on(call):
        # r90: включение протокола с проверками. _force —
        # подтверждённое автовыключение NFQWS2 (зеркальный П1).
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        force = call.data.endswith("_force")
        name = call.data[len("proto_on_"):]
        if force:
            name = name[:-len("_force")]
        if name not in PROTOCOL_TITLES:
            return
        try:
            bot.answer_callback_query(call.id)
        except Exception:  # noqa: BLE001
            pass
        try:
            bot.delete_message(
                cid, call.message.message_id)
        except Exception:  # noqa: BLE001
            pass
        title = PROTOCOL_TITLES[name]
        # r91 (аудит r90, Е): переключение целиком под
        # межпроцессным lock'ом — проверки и применение
        # составывают одну транзакцию (панель+бот).

        if not acquire_toggle_lock():
            _proto_report(
                    cid, "⏳ Другая операция переключения "
                         "выполняется — попробуйте ещё раз.")
            return
        try:

            if name == 'nfqws2':
                # Режимная логика П1 (r89) в контексте «Протоколов».
                conflicts = nfqws2_conflicts()
                if (conflicts
                        and nfqws2_conflicts_required()
                        and not force):
                    from telebot import types as tg_types
                    markup = (
                        tg_types.InlineKeyboardMarkup(
                            row_width=1))
                    markup.add(
                        tg_types.InlineKeyboardButton(
                            "⚡ Выключить туннели и включить",
                            callback_data=(
                                "proto_on_nfqws2_force")))
                    markup.add(
                        tg_types.InlineKeyboardButton(
                            "❌ Отмена",
                            callback_data=(
                                "proto_sel_nfqws2")))
                    bot.send_message(
                        cid,
                        "🚫 NFQWS2 (Глобал/Авто) "
                        "конфликтует с активными "
                        "туннелями: "
                        + ", ".join(conflicts)
                        + " — правила затронут их "
                        "соединения к VPS и DNS-апстримы. "
                        "Для одновременной работы "
                        "переключите NFQWS2 в "
                        "селективный режим.",
                        reply_markup=markup)
                    return
                ok, msg = nfqws2_set_enabled(
                    True,
                    also_disable_conflicts=(
                        bool(conflicts) and force))
                if nfqws2_intelliqos_suspected():
                    msg += ("\n⚠️ IntelliQOS: вероятно, включен — "
                            "DPI-правила могут не срабатывать "
                            "(flow offloading).")
                _proto_report(cid, msg)
                return

            # Туннель: ключ задан?
            if not protocol_configured(name):
                hint = ("мосты" if name == 'tor' else "ключ")
                _proto_report(
                    cid,
                    "❌ " + title + ": " + hint
                    + " не задан. Сначала задайте его "
                      "в «🔑 Ключи и мосты».")
                return
            # Зеркальный конфликт П1 (r90, решение владельца):
            if (nfqws2_blocks_tunnels()
                    and not force):
                from telebot import types as tg_types
                markup = (
                    tg_types.InlineKeyboardMarkup(
                        row_width=1))
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "⚡ Выключить NFQWS2 и включить",
                        callback_data=(
                            "proto_on_" + name + "_force")))
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "❌ Отмена",
                        callback_data=(
                            "proto_sel_" + name)))
                bot.send_message(
                    cid,
                    "🚫 NFQWS2 (Глобал/Авто) включён — "
                    "его правила затронут соединения "
                    + title + " к его VPS и DNS-апстримы. "
                    "Выключите NFQWS2, переведите его "
                    "в селективный режим или используйте "
                    "автовыключение.",
                    reply_markup=markup)
                return
            if force:
                bot.send_message(
                    cid, "⏳ Выключаю NFQWS2, включаю "
                    + title + "...")
                ok2, msg2 = nfqws2_set_enabled(False)
                if not ok2:
                    # r91 (аудит r90, А): NFQWS2 не погашен — туннель
                    # не включаем (прежде результат отбрасывался и
                    # включение шло в любом случае).
                    _proto_report(cid, msg2)
                    return
            ok, msg = protocol_set_enabled(name, True)
            _proto_report(cid, msg)
        finally:
            release_toggle_lock()

    @bot.callback_query_handler(
        func=lambda c:
            c.data.startswith("proto_off_"))
    def handle_proto_off(call):
        # r90: выключение. _confirm — подтверждение для
        # ПОСЛЕДНЕГО активного туннеля (решение владельца).
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        confirm = call.data.endswith("_confirm")
        name = call.data[len("proto_off_"):]
        if confirm:
            name = name[:-len("_confirm")]
        if name not in PROTOCOL_TITLES:
            return
        try:
            bot.answer_callback_query(call.id)
        except Exception:  # noqa: BLE001
            pass
        try:
            bot.delete_message(
                cid, call.message.message_id)
        except Exception:  # noqa: BLE001
            pass

        # r91 (аудит r90, Е): под межпроцессным lock'ом —
        # проверка «последний туннель» и выключение — одна
        # транзакция (панель+бот).

        if not acquire_toggle_lock():
            _proto_report(
                    cid, "⏳ Другая операция переключения "
                         "выполняется — попробуйте ещё раз.")
            return
        try:
            if name == 'nfqws2':
                ok, msg = nfqws2_set_enabled(False)
                _proto_report(cid, msg)
                return

            others = [t for t in active_tunnels()
                      if t != name]
            if not others and not confirm:
                # Последний туннель: у включённого NFQWS2 домен
                # бота (bot.txt) выпадает в fail-closed DROP —
                # связь бота может пропасть (П8, r89).
                from telebot import types as tg_types
                markup = (
                    tg_types.InlineKeyboardMarkup(
                        row_width=1))
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "⚠️ Да, выключить",
                        callback_data=(
                            "proto_off_" + name
                            + "_confirm")))
                markup.add(
                    tg_types.InlineKeyboardButton(
                        "❌ Отмена",
                        callback_data=(
                            "proto_sel_" + name)))
                warn = ("🚸 Это последний активный туннель. "
                        "После его выключения домены бота "
                        "(bot.txt) уходят в DROP — "
                        "связь бота может пропасть.")
                if nfqws2_enabled():
                    warn += (" NFQWS2 включён: перенесите "
                             "api.telegram.org из bot.txt "
                             "в user.list (вкладка NFQWS2 "
                             "панели) — бот сможет работать "
                             "через селективную модификацию.")
                bot.send_message(
                    cid, warn, reply_markup=markup)
                return
            ok, msg = protocol_set_enabled(name, False)
            _proto_report(cid, msg)
        finally:
            release_toggle_lock()

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "menu_service")
    def handle_backup_return(call):
        if not is_allowed_call(call):
            return
        state.set_menu(
            call.message.chat.id, MENU_SERVICE)
        bot.delete_message(
            call.message.chat.id,
            call.message.message_id)
        bot.send_message(
            call.message.chat.id,
            MENU_SERVICE.name,
            reply_markup=MENU_SERVICE.markup)
        backup_state.__init__()

    @bot.callback_query_handler(
        func=lambda c:
            c.data.startswith(
                "backup_toggle_"))
    def handle_backup_toggle(call):
        if not is_allowed_call(call):
            return
        bt = call.data.replace(
            "backup_toggle_", "")
        if bt == "startup":
            backup_state.startup_config = (
                not backup_state.startup_config)
        elif bt == "firmware":
            backup_state.firmware = (
                not backup_state.firmware)
        elif bt == "entware":
            backup_state.entware = (
                not backup_state.entware)
        elif bt == "custom":
            backup_state.custom_files = (
                not backup_state.custom_files)
        bot.edit_message_reply_markup(
            call.message.chat.id,
            call.message.message_id,
            reply_markup=create_backup_menu(
                backup_state))

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "backup_create")
    def handle_backup_create(call):
        if not is_allowed_call(call):
            return
        drives = get_available_drives()
        if not drives:
            bot.answer_callback_query(
                call.id,
                "❌ Нет дисков",
                show_alert=True)
            return
        msg = bot.edit_message_text(
            "Выберите диск:",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=(
                create_drive_selection_menu(
                    drives)))
        backup_state.selection_msg_id = (
            msg.message_id)

    @bot.callback_query_handler(
        func=lambda c:
            c.data.startswith(
                "backup_drive_"))
    def handle_backup_drive_select(call):
        if not is_allowed_call(call):
            return
        uuid = call.data.replace(
            "backup_drive_", "")
        drives = get_available_drives()
        sel = next(
            (d for d in drives
             if d['uuid'] == uuid), None)
        if not sel:
            bot.answer_callback_query(
                call.id,
                "❌ Диск недоступен",
                show_alert=True)
            return
        backup_state.selected_drive = sel
        bot.edit_message_text(
            f"☑️ Диск: {sel['label']}\n"
            f"Удалить архив после?",
            call.message.chat.id,
            backup_state.selection_msg_id,
            reply_markup=(
                create_delete_archive_menu()))

    @bot.callback_query_handler(
        func=lambda c: c.data in [
            "backup_delete_yes",
            "backup_delete_no"])
    def handle_delete_archive_choice(call):
        if not is_allowed_call(call):
            return
        if call.data == "backup_delete_yes":
            backup_state.delete_archive = True
            ch = "Да"
        else:
            backup_state.delete_archive = False
            ch = "Нет"
        bot.edit_message_text(
            f"☑️ Диск: "
            f"{backup_state.selected_drive['label']}"
            f"\n☑️ Удалить: {ch}",
            call.message.chat.id,
            backup_state.selection_msg_id)
        pm = bot.send_message(
            call.message.chat.id,
            "⏳ Создаю бэкап!")
        create_backup_with_params(
            bot, call.message.chat.id,
            backup_state,
            backup_state.selected_drive,
            pm.message_id)
        backup_state.__init__()

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "backup_menu")
    def handle_backup_menu_return(call):
        if not is_allowed_call(call):
            return
        bot.edit_message_text(
            "Выберите файлы:",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=create_backup_menu(
                backup_state))

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "dns_override_on")
    def handle_dns_on(call):
        if not is_allowed_call(call):
            return
        bot.edit_message_reply_markup(
            chat_id=call.message.chat.id,
            message_id=(
                call.message.message_id),
            reply_markup=None)
        toggle_dns_override(
            call.message.chat.id, True)

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "dns_override_off")
    def handle_dns_off(call):
        if not is_allowed_call(call):
            return
        bot.edit_message_reply_markup(
            chat_id=call.message.chat.id,
            message_id=(
                call.message.message_id),
            reply_markup=None)
        toggle_dns_override(
            call.message.chat.id, False)

    @bot.callback_query_handler(
        func=lambda c: c.data in [
            "update_github",
            "update_opkg",
            "update_all"])
    def handle_protocol_update(call):
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        bot.edit_message_reply_markup(
            chat_id=cid,
            message_id=(
                call.message.message_id),
            reply_markup=None)

        action_map = {
            "update_github": "xray/hysteria",
            "update_opkg": "opkg пакеты",
            "update_all": "все протоколы",
        }
        label = action_map.get(
            call.data, "протоколы")
        msg = bot.send_message(
            cid, f"⏳ Обновляю {label}...")

        script = config.paths.get(
            "update_protocols",
            "/opt/bin/update_protocols.sh")
        output = ""

        # Успех определяется кодом возврата скрипта, а не поиском
        # символа "❌" в выводе: сообщение об ошибке могло не содержать
        # этот символ, и неудачное обновление считалось успешным.
        failed = False

        if call.data == "update_github":
            for proto in ["xray", "hysteria"]:
                rc, timed_out, tail = _run_lifecycle(
                    cid, msg.message_id, [script, proto], 300)
                out = "\n".join(tail)
                if timed_out or rc != 0:
                    failed = True
                if rc is None and not timed_out:
                    out = "Другая lifecycle-операция уже выполняется"
                if out:
                    output += f"{proto}: {out}\n"
        else:
            action = ("opkg"
                      if call.data
                      == "update_opkg"
                      else "all")
            rc, timed_out, tail = _run_lifecycle(
                cid, msg.message_id, [script, action], 600)
            if timed_out or rc != 0:
                failed = True
            output = "\n".join(tail)
            if rc is None and not timed_out:
                output = "Другая lifecycle-операция уже выполняется"

        final = (
            f"❌ Обновление завершилось с ошибкой\n{output}"
            if failed
            else f"✅ Обновление завершено\n{output}")
        bot.edit_message_text(
            final[:4000], cid, msg.message_id)

        time.sleep(2)
        handle_updates(cid)

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "recheck_updates")
    def handle_recheck(call):
        if not is_allowed_call(call):
            return
        bot.delete_message(
            call.message.chat.id,
            call.message.message_id)
        handle_updates(call.message.chat.id)

    # Прогресс установки/удаления отображается правкой одного сообщения.
    # Правки Telegram API ограничены (flood-wait при ~1 правке/сек и
    # «message is not modified»), поэтому строки лога накапливаются и
    # правка выполняется не чаще _STREAM_MIN_INTERVAL секунд либо при
    # заполнении буфера — последние строки видны всегда.
    _STREAM_MIN_INTERVAL = 1.8
    _STREAM_MAX_LINES = 8

    def _stream_deploy_progress(
            cid, msg_id, process, timeout):
        """Читает stdout без риска вечной блокировки и ограничивает процесс."""
        lines = queue.Queue()
        reader_done = threading.Event()
        tail = []

        def _reader():
            try:
                for line in process.stdout:
                    lines.put(line)
            except (OSError, ValueError) as e:
                log_error(f"lifecycle stdout: {e}")
            finally:
                reader_done.set()

        threading.Thread(
            target=_reader, name="keenzoo-lifecycle-output",
            daemon=True).start()

        deadline = time.monotonic() + timeout
        last_edit = 0.0
        progress_dirty = False
        exited_at = None
        timed_out = False
        while True:
            now = time.monotonic()
            if process.poll() is None and now >= deadline:
                timed_out = True
                log_error(
                    f"lifecycle timeout after {timeout}s, pid={process.pid}")
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                except OSError as e:
                    log_error(f"lifecycle TERM: {e}")
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass

                # Parent мог штатно завершиться от TERM, пока упрямый
                # потомок в той же session/process-group остался жив.
                # Поэтому решение о KILL принимается по PGID, а не по rc
                # одного parent-процесса.
                group_alive = False
                try:
                    os.killpg(process.pid, 0)
                    group_alive = True
                except ProcessLookupError:
                    pass
                except OSError as e:
                    log_error(f"lifecycle group probe: {e}")
                if group_alive:
                    try:
                        os.killpg(process.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    except OSError as e:
                        log_error(f"lifecycle KILL: {e}")
                    kill_deadline = time.monotonic() + 5
                    while time.monotonic() < kill_deadline:
                        try:
                            os.killpg(process.pid, 0)
                        except ProcessLookupError:
                            break
                        except OSError:
                            break
                        time.sleep(0.1)
                    else:
                        log_error("lifecycle process group did not exit after KILL")
                # Не ждём EOF бесконечно: отделившийся потомок мог
                # унаследовать pipe, но уже не принадлежать process group.
                break

            try:
                line = lines.get(timeout=0.25)
            except queue.Empty:
                line = None
            if line:
                stripped = line.strip()
                if stripped:
                    tail.append(stripped)
                    tail = tail[-_STREAM_MAX_LINES:]
                    progress_dirty = True

            now = time.monotonic()
            if (progress_dirty and tail
                    and now - last_edit >= _STREAM_MIN_INTERVAL):
                try:
                    bot.edit_message_text(
                        "⏳\n" + "\n".join(tail), cid, msg_id)
                    last_edit = now
                    progress_dirty = False
                except Exception as e:  # noqa: BLE001
                    # rate-limit и «message is not modified» не критичны
                    # для прогресса — логируем и продолжаем.
                    log_error(f"deploy stream: {e}")
                    progress_dirty = False

            rc = process.poll()
            if rc is not None:
                if exited_at is None:
                    exited_at = now
                if reader_done.is_set() and lines.empty():
                    break
                # Потомок мог держать stdout открытым после выхода parent.
                if now - exited_at >= 2:
                    break

        return process.poll(), timed_out, tail

    def _run_lifecycle(cid, msg_id, argv, timeout):
        if not _LIFECYCLE_LOCK.acquire(blocking=False):
            return None, False, [
                "Другая операция установки/обновления уже выполняется"]
        try:
            try:
                process = subprocess.Popen(
                    argv,
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True, bufsize=1,
                    start_new_session=True)
            except (OSError, ValueError) as e:
                log_error(f"lifecycle start {argv!r}: {e}")
                return 127, False, [str(e)]
            return _stream_deploy_progress(
                cid, msg_id, process, timeout)
        finally:
            _LIFECYCLE_LOCK.release()

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "install")
    def handle_install(call):
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        try:
            deploy = download_script()
        except Exception as e:
            bot.send_message(
                cid, f"❌ {e}")
            return
        bot.edit_message_reply_markup(
            chat_id=cid,
            message_id=(
                call.message.message_id),
            reply_markup=None)
        msg = bot.send_message(
            cid, '⏳ Восстановление из бэкапа!')
        rc, timed_out, tail = _run_lifecycle(
            cid, msg.message_id,
            [deploy, '-restore'], 3600)
        if rc is None and not timed_out:
            result_text = '⚠️ Другая lifecycle-операция уже выполняется'
        elif timed_out:
            result_text = '❌ Timeout восстановления; process group остановлена'
        elif rc == 0:
            result_text = '✅ Восстановление завершено'
        else:
            result_text = f'❌ Ошибка восстановления (rc={rc})'
        if tail:
            result_text += '\n' + '\n'.join(tail)
        bot.send_message(
            cid, result_text[:4000],
            reply_markup=MENU_MAIN.markup)

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "remove")
    def handle_remove(call):
        if not is_allowed_call(call):
            return
        cid = call.message.chat.id
        bot.edit_message_reply_markup(
            chat_id=cid,
            message_id=(
                call.message.message_id),
            reply_markup=None)
        try:
            deploy = download_script()
        except Exception as e:
            bot.send_message(
                cid, f"❌ {e}")
            return
        msg = bot.send_message(
            cid, '⏳ Удаление!')
        rc, timed_out, tail = _run_lifecycle(
            cid, msg.message_id,
            [deploy, '-remove'], 900)
        if rc is None and not timed_out:
            result_text = '⚠️ Другая lifecycle-операция уже выполняется'
        elif timed_out:
            result_text = '❌ Timeout удаления; process group остановлена'
        elif rc == 0:
            result_text = '✅ Удаление завершено'
        else:
            result_text = f'❌ Ошибка удаления (rc={rc})'
        if tail:
            result_text += '\n' + '\n'.join(tail)
        bot.send_message(
            cid, result_text[:4000],
            reply_markup=MENU_MAIN.markup)

    @bot.callback_query_handler(
        func=lambda c:
            c.data == "menu_main")
    def handle_back_main(call):
        if not is_allowed_call(call):
            return
        state.set_menu(
            call.message.chat.id, MENU_MAIN)
        bot.delete_message(
            call.message.chat.id,
            call.message.message_id)
        bot.send_message(
            call.message.chat.id,
            MENU_MAIN.name,
            reply_markup=MENU_MAIN.markup)
