# -*- coding: utf-8 -*-
import os
import signal
import time
import threading
import subprocess
import json
import re
import socket
# F6 (аудит v4 N4-Info): import requests/urllib3 удалены — после
# P9-рефакторинга обоих имён нет в sys.modules-обращениях utils.py,
# а каждый лишний импорт на роутере = память и время старта бота.
# ВНИМАНИЕ: пакет python3-requests остаётся в bot_config.py — его
# реально грузит main.py (requests.exceptions).
import gc
import tempfile
import shutil
import html
from urllib.parse import (
    urlparse, parse_qs, unquote)
import base64
import bot_config as config


def signal_handler(sig, frame):
    log_error(
        f"Бот остановлен сигналом "
        f"{signal.Signals(sig).name}")
    raise SystemExit


# ---------------------------------------------------------------------------
# Ротация логов. Пороги настраиваются через опциональные атрибуты
# bot_config (LOG_MAX_SIZE_BYTES / LOG_KEEP_LINES) — если их нет,
# используются прежние значения по умолчанию (полная совместимость).
# Без ротации лог-файлы на Entware (часто ограниченный объём флеш/USB)
# могли бы расти неограниченно и занять всё свободное место.
# ---------------------------------------------------------------------------

_LOG_MAX_SIZE_BYTES = getattr(config, 'LOG_MAX_SIZE_BYTES', 524288)
_LOG_KEEP_LINES = getattr(config, 'LOG_KEEP_LINES', 50)


def clean_log(log_file, max_size=None, keep_lines=None):
    """
    Ограничивает размер лог-файла: при превышении max_size байт
    оставляет только последние keep_lines строк.
    """
    max_size = (
        _LOG_MAX_SIZE_BYTES if max_size is None else max_size)
    keep_lines = (
        _LOG_KEEP_LINES if keep_lines is None else keep_lines)

    if not os.path.exists(log_file):
        open(log_file, 'a').close()
        return
    try:
        if os.path.getsize(log_file) > max_size:
            # На роутере читаем только хвост файла, а не весь лог
            # целиком в память: средняя строка наших логов 100-300
            # байт, запас 512 на строку достаточен.
            with open(log_file, 'rb') as f:
                f.seek(0, os.SEEK_END)
                size = f.tell()
                f.seek(max(0, size - keep_lines * 512))
                tail = f.read().decode('utf-8', errors='replace')
            lines = tail.splitlines(keepends=True)
            with open(log_file, 'w', encoding='utf-8') as f:
                f.writelines(lines[-keep_lines:])
    except OSError:
        pass


def log_error(message):
    log_file = config.paths["error_log"]
    try:
        clean_log(log_file)
        with open(log_file, "a",
                  encoding='utf-8') as fl:
            fl.write(
                f"{time.strftime('%Y-%m-%d %H:%M:%S')}"
                f" - {message}\n")
    except Exception:  # noqa: BLE001
        # Сам логгер обязан быть непробиваемым: любая цепочка
        # (ФС/переполнение) не должна уронить бота.
        pass


# ---------------------------------------------------------------------------
# Плейсхолдеры в конфигах, сгенерированных deploy из шаблонов
# (значения-заглушки вместо реальных ключей). Те же маркеры использует
# needs_key() в deploy_bypass.sh — держим списки синхронными.
# ---------------------------------------------------------------------------

_PLACEHOLDER_MARKERS = (
    "example.com",
    "CHANGE_ME",
    "00000000-0000-0000-0000-000000000000",
)

# FB-74 (аудит-33, K58-2/R58-05): регистронезависимый матч маркеров
# (EXAMPLE.com / change_me — те же заглушки; нижний регистр как в
# preflight/needs_key/S57, которые нормализуют host перед сравнением).
_PLACEHOLDER_MARKERS_LOWER = tuple(
    m.lower() for m in _PLACEHOLDER_MARKERS)

# FB-31 (аудит-26, R51-07): example.com в полях sni/serverName —
# легальная маскировка (S57-гейт её не трогает); строки этих полей
# исключаются из поиска заглушек. Паритет с needs_key() в
# deploy_bypass.sh — списки полей держим синхронными.
# FB-36 (аудит-27, K52-1): вырезается ЗНАЧЕНИЕ поля маскировки, а не
# вся строка — минифицированный (однострочный) JSON иначе исключался
# целиком, и заглушка в server считалась настроенной.
_SNI_VALUE_RE = re.compile(r'("(?:sni|serverName|peer_name)"\s*:\s*")[^"]*(")')

# FB-89 (аудит-35, R59-04/K60-04): точечный матч маркеров — по
# ЗНАЧЕНИЯМ полей address|server|remote_addr|auth (те же поля, что в
# needs_key() deploy_bypass.sh). Прежний substring-поиск по всему
# тексту принимал за заглушки fooexample.com и поддомены
# sub.example.com, а комментарий с example.com блокировал конфиг.
_FIELD_VALUE_RE = re.compile(
    r'"(address|server|remote_addr|auth)"\s*:\s*"([^"]*)"')


def _norm_host_marker(v):
    """FB-89 (аудит-35, R59-04/K60-04): нормализация значения поля
    перед точечным сравнением с маркерами-заглушками — та же, что в
    needs_key() deploy_bypass.sh и гейте S57: нижний регистр, без
    портового суффикса, без ОДНОЙ конечной точки (FQDN-форма
    «example.com.» — та же заглушка; двойная точка — уже нет).
    FB-96 (аудит-36, K61-03): применяется ТОЛЬКО к host-полям
    (address/server/remote_addr). auth — секрет: точный
    регистронезависимый матч без среза порта/точки (паритет с
    needs_key/S57/preflight; «change_me:443» в auth — не заглушка)."""
    hv = v.lower()
    hv = re.sub(r':[0-9]+$', '', hv)
    if hv.endswith('.'):
        hv = hv[:-1]
    return hv


class _RootDupeError(ValueError):
    """FB-97 (аудит-36, K61-04): дублирующийся ключ на КОРНЕВОМ
    уровне JSON — неоднозначный конфиг; shell-валидатор
    kz_json_root_str на дубликате возвращает rc 3 (fail-closed),
    а «последний победил» у json.loads расходился с ним."""


def _json_loads_root_strict(content):
    """json.loads, отвергающий дубликаты КОРНЕВОГО уровня (FB-97).
    Вложенные объекты shell-валидатор не разбирает — их дубликаты
    по-прежнему решает json.loads (последний победил), расхождения
    с корневой семантикой это не создаёт. Корневой объект закрывается
    ПОСЛЕДНИМ (вложенные хуки срабатывают раньше), поэтому корень —
    последний вызов hook, чей результат вернулся из loads; если корень
    не объект (список/скаляр), корневой проверки нет — валидаторы
    такие корни всё равно уводят в fallback-ветку."""
    _pairs_log = []
    _objs = []

    def _hook(pairs):
        _pairs_log.append(pairs)
        d = dict(pairs)
        _objs.append(d)
        return d

    result = json.loads(content, object_pairs_hook=_hook)
    if _objs and result is _objs[-1]:
        seen = set()
        for k, _v in _pairs_log[-1]:
            if k in seen:
                raise _RootDupeError(
                    'дублирующийся корневой ключ: %s' % k)
            seen.add(k)
    return result


def config_has_placeholders(filepath, require_auth=False):
    """
    True, если конфиг не существует, пуст или содержит только
    значения-заглушки шаблона — то есть ключ/мосты ещё не введены.
    require_auth=True (hysteria): отсутствующий непустой auth — тоже
    «ключ не задан» (FB-54, аудит-29, N54-2: паритет с
    _preflight_hysteria и гейтом S57, которые такой конфиг
    отклоняют; для xray/shadowsocks/trojan поля auth нет).
    FB-89 (аудит-35, R59-04/K60-04): маркеры сверяются ТОЧЕЧНО со
    значениями полей address|server|remote_addr|auth после
    нормализации (_norm_host_marker) — substring по всему тексту
    больше не используется (fooexample.com и sub.example.com — не
    заглушки; комментарий с example.com не блокирует конфиг). Для
    hysteria (require_auth) server/auth проверяются как КОРНЕВЫЕ
    поля JSON — вложенный tls.server это маскировка, не адрес
    сервера (паритет с _preflight_hysteria и корневым гейтом S57);
    нераскрываемый JSON уходит в прежний regex-fallback.
    """
    try:
        with open(filepath, 'r', encoding='utf-8',
                  errors='replace') as f:
            content = f.read()
    except OSError:
        return True
    if not content.strip():
        return True
    if '{{' in content:
        return True
    # FB-31 (аудит-26, R51-07): example.com в sni/serverName/peer_name —
    # легальная маскировка (гейт S57 её не трогает): вырезаем ЗНАЧЕНИЯ
    # этих полей до поиска маркеров.
    # FB-36 (аудит-27, K52-1): паритет с needs_key — пустой address/
    # server тоже заглушка. FB-45 (аудит-28, R53-04): и пустой auth —
    # как в needs_key и гейте S57 (прежде расхождение на матрице).
    filtered = _SNI_VALUE_RE.sub(r'\1\2', content)
    if re.search(r'"(?:address|server|auth)"\s*:\s*""', filtered):
        return True
    if require_auth:
        # hysteria: корневые server/auth через JSON — единая матрица
        # с _preflight_hysteria (FB-89): строгие типы, точечные
        # маркеры, вложенный tls.server не считается адресом.
        try:
            data = _json_loads_root_strict(content)
        except _RootDupeError:
            # FB-97: дубликат корневого ключа — неоднозначный JSON =
            # заглушка (fail-closed, паритет с kz_json_root_str rc 3)
            return True
        except (json.JSONDecodeError, ValueError):
            data = None
        if isinstance(data, dict):
            for k in ('server', 'auth'):
                v = data.get(k)
                if not isinstance(v, str) or not v:
                    return True
                # FB-96: раздельная нормализация по типу поля —
                # server: host (порт/точка); auth: секрет (точный
                # lower-матч, «change_me:443» — не заглушка)
                hv = v.lower() if k == 'auth' else _norm_host_marker(v)
                if hv in _PLACEHOLDER_MARKERS_LOWER:
                    return True
            return False
        # FB-114 (аудит-39, K64-02): валидный JSON с корнем-НЕ-объектом
        # (непустой массив и т.п.) — конфиг непригоден для Hysteria:
        # preflight (FB-107) и shell-гейты (needs_key/S57) его отвергают.
        # Прежде такой корень уходил в regex-fallback, который находил
        # server/auth в ТЕКСТЕ массива и ложно рапортовал «заполнен» —
        # расхождение статуса панели с фактическим отказом запуска.
        # Fail-closed: любой распарсенный не-dict корень = заглушка.
        # (null-корень даёт data=None и уходит в fallback ниже — там
        # server/auth не находятся, итог тот же True.)
        if data is not None:
            return True
        # нераскрываемый JSON — regex-fallback (лучшая попытка)
        # FB-54 (аудит-29, N54-2): отсутствующий auth — заглушка.
        if not re.search(
                r'"auth"\s*:\s*"[^"]+"', filtered):
            return True
        # FB-74 (аудит-33, K58-2/R58-05): отсутствующий/нестроковый
        # server (нет закавыченного непустого значения) — тоже
        # заглушка.
        if not re.search(
                r'"server"\s*:\s*"[^"]+"', filtered):
            return True
    # FB-89: точечный матч маркеров по значениям полей
    # (address|server|remote_addr|auth) — для hysteria сюда попадаем
    # только из fallback-ветки. FB-96: auth — секрет (точный
    # lower-матч без host-нормализации), host-поля — как прежде.
    for _fm in _FIELD_VALUE_RE.finditer(filtered):
        _hv = (_fm.group(2).lower() if _fm.group(1) == 'auth'
               else _norm_host_marker(_fm.group(2)))
        if _hv in _PLACEHOLDER_MARKERS_LOWER:
            return True
    return False


def tor_has_bridges(filepath):
    """
    True, если мосты Tor не требуются или уже заданы: либо
    UseBridges выключен, либо есть хотя бы одна активная (не
    закомментированная) строка Bridge.
    """
    try:
        with open(filepath, 'r', encoding='utf-8',
                  errors='replace') as f:
            content = f.read()
    except OSError:
        return False
    if not re.search(r'^\s*UseBridges[ \t]+1[ \t]*$',
                     content, re.MULTILINE):
        return True
    for line in content.splitlines():
        stripped = line.strip()
        if (stripped.lower().startswith('bridge ')
                and not stripped.startswith('#')):
            return True
    return False


# Отображение протоколов меню «Ключи и мосты» на их конфиги и пример
# синтаксиса ключа (для подсказки пользователю).
_SERVICES_KEY_MENU = (
    ("Vless", "vless_config",
     "vless://uuid@сервер:порт?..."),
    ("Trojan", "trojan_config",
     "trojan://пароль@сервер:порт?..."),
    ("Shadowsocks", "shadowsocks_config",
     "ss://base64@сервер:порт#имя"),
    ("Hysteria", "hysteria_config",
     "hy2://пароль@сервер:порт?..."),
)


def keys_bridges_warnings():
    """
    Список предупреждений для меню «Ключи и мосты»: у каких
    протоколов конфиг содержит только плейсхолдеры, и не забыт ли
    Tor без единого активного моста (UseBridges 1).
    """
    warnings = []
    for name, path_key, syntax in _SERVICES_KEY_MENU:
        path = config.paths.get(path_key)
        # FB-54 (аудит-29, N54-2): hysteria требует непустой auth
        # (preflight и гейт S57 конфиг без auth отклоняют) —
        # предупреждение появляется и при отсутствующем поле,
        # а не только при маркерах заглушки.
        _req_auth = path_key == 'hysteria_config'
        if path and config_has_placeholders(
                path, require_auth=_req_auth):
            warnings.append(
                f"⚠️ {name}: ключ не задан ({syntax})")
    tor_path = config.paths.get("tor_config")
    if tor_path and not tor_has_bridges(tor_path):
        warnings.append(
            "⚠️ Tor: не добавлены мосты "
            "(раздел «Tor», строки Bridge)")
    return warnings


def download_script():
    """
    Ранее функция скачивала script.sh с внешнего URL и делала его
    исполняемым, после чего бот запускал его с правами root без проверки
    подписи. Внешний источник удалён: используются только локальные
    скрипты из /opt/bin, поставляемые вместе с проектом.
    Возвращает путь к локальному установочному скрипту.
    """
    deploy = config.paths.get(
        "deploy_script", "/opt/bin/deploy_bypass.sh")
    if not os.path.exists(deploy):
        raise FileNotFoundError(
            f"Не найден локальный скрипт: {deploy}")
    try:
        os.chmod(deploy, 0o755)
    except OSError as e:
        log_error(f"chmod {deploy}: {e}")
    return deploy


def check_restart(bot):
    chat_id_path = config.paths[
        "chat_id_path"]
    if os.path.exists(chat_id_path):
        # Файл живёт на flash: обрыв записи при отключении питания — и
        # int() падал до try, убивая старт бота целиком (P4).
        try:
            with open(chat_id_path, 'r') as f:
                chat_id = int(f.read().strip())
        except (ValueError, OSError) as e:
            log_error(
                f"check_restart: битый chat_id-файл: {e}")
        else:
            try:
                bot.send_message(
                    chat_id,
                    '✅ Бот перезапущен')
            except Exception as e:
                log_error(
                    f"Перезапуск: {str(e)}")
        try:
            os.remove(chat_id_path)
        except OSError as e:
            log_error(
                f"check_restart: не удалить chat_id-файл: {e}")


# ---------------------------------------------------------------------------
# Preflight-проверки бинарниками (best-effort: если бинарник не найден,
# проверка пропускается с записью в лог, а не блокирует запись конфига —
# это важно, чтобы не сломать деплой на роутерах, где xray/tor ещё не
# установлены на момент первой генерации конфига).
# ---------------------------------------------------------------------------

def _find_binary(binary_name, fallback_paths):
    """Ищет бинарник через PATH, затем по типовым путям Entware."""
    found = shutil.which(binary_name)
    if found:
        return found
    for path in fallback_paths:
        if os.path.exists(path) and os.access(path, os.X_OK):
            return path
    return None


def _xray_asset_dirs():
    """
    FB-213 (2026-11-01): каталоги, в которых Xray ищет geoip.dat и
    geosite.dat — в порядке приоритета самого Xray: переменная
    окружения XRAY_LOCATION_ASSET, каталог бинарника, стандартные
    пути. Список нужен, чтобы ДО записи конфига решить, доступны ли
    геоданные, прежде чем сохранять geoip:/geosite:-правила routing
    (без .dat Xray падает на старте: "failed to open geoip.dat").
    """
    dirs = []
    _env = os.environ.get('XRAY_LOCATION_ASSET')
    if _env:
        dirs.append(_env)
    for _b in ('/opt/sbin/xray', '/opt/bin/xray'):
        if os.path.isfile(_b):
            dirs.append(
                os.path.dirname(os.path.abspath(_b)))
            break
    dirs.extend((
        '/opt/etc/xray', '/opt/share/xray',
        '/usr/local/share/xray', '/usr/share/xray'))
    return dirs


def _xray_has_asset(filename):
    """FB-213: наличие geoip.dat/geosite.dat в каталогах поиска."""
    return any(
        os.path.isfile(os.path.join(d, filename))
        for d in _xray_asset_dirs())


def _preflight_xray(tmp_path):
    """
    Проверка конфига через xray -test.

    Формат передаётся ЯВНО через '-format json', а не через
    автоопределение по расширению файла (default 'auto' у Xray
    определяет формат по расширению, а временный файл создаётся
    tempfile.mkstemp со случайным суффиксом и может не совпадать
    с реальным расширением — при опоре на автоопределение это
    давало бы false negative на абсолютно корректных конфигах).
    Поддержаны оба синтаксиса CLI: старый 'xray -test' и новый
    'xray run -test'.
    """
    binary = _find_binary(
        'xray', ['/opt/sbin/xray', '/opt/bin/xray'])
    if not binary:
        log_error(
            "Preflight: xray не найден, проверка конфига пропущена")
        return

    last_err = ''
    for cmd in (
            [binary, 'run', '-test',
             '-format', 'json', '-config', tmp_path],
            [binary, '-test',
             '-format', 'json', '-config', tmp_path]):
        try:
            res = subprocess.run(
                cmd, capture_output=True,
                text=True, timeout=15)
        except subprocess.TimeoutExpired:
            last_err = 'timeout при проверке конфига'
            continue
        if res.returncode == 0:
            return
        last_err = (res.stderr or res.stdout or '').strip()

    raise ValueError(f"Xray validation failed: {last_err}")


def _preflight_tor(tmp_path):
    """Проверка torrc через 'tor --verify-config -f <файл>'."""
    binary = _find_binary(
        'tor', ['/opt/sbin/tor', '/opt/bin/tor'])
    if not binary:
        log_error(
            "Preflight: tor не найден, проверка конфига пропущена")
        return

    try:
        res = subprocess.run(
            [binary, '--verify-config', '-f', tmp_path],
            capture_output=True, text=True, timeout=15)
    except subprocess.TimeoutExpired:
        raise ValueError("Tor validation timeout")

    if res.returncode != 0:
        err = (res.stderr or res.stdout or '').strip()
        raise ValueError(f"Tor validation failed: {err}")


def _preflight_hysteria(tmp_path):
    """Проверка нативного конфига Hysteria2: 'hysteria client -c <файл> --help'
    не валидирует, поэтому используется JSON-схема + обязательные поля."""
    binary = _find_binary(
        'hysteria', ['/opt/sbin/hysteria', '/opt/bin/hysteria'])

    try:
        with open(tmp_path, 'r', encoding='utf-8') as f:
            _pf_content = f.read()
        # FB-97 (аудит-36, K61-04): дубликаты корневого уровня —
        # неоднозначный JSON, отказ (паритет с kz_json_root_str rc 3)
        data = _json_loads_root_strict(_pf_content)
    except _RootDupeError as e:
        raise ValueError(f"Hysteria: неоднозначный JSON: {e}")
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError(f"Hysteria: некорректный JSON: {e}")

    # FB-107 (аудит-38, JSON-02): корень обязан быть ОБЪЕКТОМ. Прежде
    # легитимный JSON с корнем [] / null / "строка" / 42 доходил до
    # data.get(...) и падал с AttributeError (необработанный traceback
    # у вышестоящих вызывающих), вместо вменяемого ValueError. Паритет
    # с kz_json_root_str (rc 1 «нет/нестроковое/вложенное») и
    # config_has_placeholders (isinstance-гейт после strict-парсинга).
    if not isinstance(data, dict):
        raise ValueError("Hysteria: корень JSON должен быть объектом")

    # FB-66 (аудит-32, R55-07): строгие ТИПЫ. Прежде preflight брал
    # truthiness: auth-число проходило, хотя needs_key и S57 считали
    # конфиг незаданным (2 расхождения из 15 в матрице отчёта r55).
    # Теперь server/auth — только непустые СТРОКИ (как у needs_key/S57,
    # которые смотрят закавыченное значение). Пробельные строки все
    # четыре валидатора пропускают согласованно — сознательно не
    # ужесточаем, чтобы не создавать новое расхождение.
    _hy_server = data.get('server')
    if not isinstance(_hy_server, str) or not _hy_server:
        raise ValueError("Hysteria: не задан server")
    _hy_auth = data.get('auth')
    if not isinstance(_hy_auth, str) or not _hy_auth:
        raise ValueError("Hysteria: не задан auth")
    # FB-45 (аудит-28, R53-04): маркеры заглушки — те же, что в
    # needs_key / config_has_placeholders / гейте S57: все четыре
    # валидатора обязаны сходиться на одной матрице (прежде preflight
    # пропускал auth=CHANGE_ME/all-zero UUID и конфиг с {{…}}).
    # FB-66: маркер проверяется и для server (прежде server=CHANGE_ME
    # проходил preflight и S57, при том что needs_key считал конфиг
    # незаданным) — матрица 15/15.
    # FB-89 (аудит-35, R59-04/K60-04): регистронезависимый матч для
    # auth И server (change_me/Change_Me — та же заглушка: прежде
    # «y»-ветка needs_key считала auth=change_me незаданным, а
    # preflight пропускал). server сравнивается ПОСЛЕ нормализации
    # (_norm_host_marker: без порта, без одной конечной точки) —
    # точечно, как во всех остальных валидаторах.
    _hy_host = _norm_host_marker(_hy_server)
    if ('{{' in json.dumps(data)
            or _hy_auth.lower() in ('change_me',
                                    '00000000-0000-0000-0000-000000000000')
            or _hy_host in ('change_me', 'example.com')):
        raise ValueError('Hysteria: конфиг-заглушка (auth/server/шаблон не заполнен)')
    if not isinstance(data.get('tcpRedirect'), dict):
        raise ValueError("Hysteria: отсутствует tcpRedirect")
    if not isinstance(data.get('udpTProxy'), dict):
        raise ValueError("Hysteria: отсутствует udpTProxy (UDP не пойдёт в туннель)")

    if not binary:
        log_error(
            "Preflight: hysteria не найден, проверка бинарником пропущена")
        return


def _preflight_trojan(tmp_path):
    """Структурная проверка конфига trojan (бинарник не имеет режима теста)."""
    try:
        with open(tmp_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError(f"Trojan: некорректный JSON: {e}")

    # Здесь важно именно OR: конфиг непригоден, если отсутствует ХОТЯ БЫ
    # одно из обязательных полей (раньше проверка через AND пропускала
    # конфиги без remote_addr или без пароля).
    if (not data.get('remote_addr')
            or not data.get('remote_port')
            or not data.get('password')):
        raise ValueError(
            "Trojan: нужны remote_addr, remote_port и password")


def _preflight_shadowsocks(tmp_path):
    """Структурная проверка конфига shadowsocks-libev."""
    try:
        with open(tmp_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError(f"Shadowsocks: некорректный JSON: {e}")

    if not data.get('server'):
        raise ValueError("Shadowsocks: не задан server")
    if not data.get('server_port'):
        raise ValueError("Shadowsocks: не задан server_port")
    if not data.get('password'):
        raise ValueError("Shadowsocks: не задан password")
    if not data.get('method'):
        raise ValueError("Shadowsocks: не задан method")


def _cleanup_stale_tmp_files(directory, basename, max_age_seconds=3600):
    """
    Удаляет "осиротевшие" временные файлы конфигурации, оставшиеся
    от прерванных (например, из-за отключения питания роутера)
    предыдущих запусков write_config. Без этой очистки такие файлы
    накапливались бы бесконечно и могли занять всё место на
    накопителе Entware. Возраст 1 час гарантированно превышает время
    любой нормальной записи (доли секунды), поэтому риска удалить
    "живой" временный файл конкурентного процесса нет.
    """
    pattern_prefix = f".{basename}.tmp_"
    try:
        now = time.time()
        for name in os.listdir(directory):
            if not name.startswith(pattern_prefix):
                continue
            full = os.path.join(directory, name)
            try:
                if now - os.path.getmtime(full) > max_age_seconds:
                    os.remove(full)
            except OSError:
                pass
    except OSError:
        pass


def _refresh_pins_if_needed(file_path):
    """
    Перечитать адреса серверов после изменения конфига протокола.

    Пиннинг хранит IP серверов в /opt/etc/hosts, а туннели ходят именно
    по ним. Раньше пин обновлялся только по крону (06:00) и при подъёме
    WAN: после ввода нового ключа с другим сервером обход не работал до
    следующего обновления. Запускается в фоне — вызывающий код (панель,
    бот) не должен ждать сетевых запросов.
    """
    watched = (
        config.paths.get("vless_config"),
        config.paths.get("hysteria_config"),
        config.paths.get("trojan_config"),
    )
    try:
        real = os.path.realpath(file_path)
    except Exception:
        real = file_path
    hit = False
    for w in watched:
        if not w:
            continue
        try:
            if os.path.realpath(w) == real:
                hit = True
                break
        except Exception:
            if w == file_path:
                hit = True
                break
    if not hit:
        return

    script = config.paths.get(
        "unblock_dnsmasq", "/opt/bin/unblock_dnsmasq.sh")
    if not os.path.exists(script):
        return
    try:
        # start_new_session отвязывает процесс: панель может быть
        # перезапущена, а обновление пина обязано завершиться.
        subprocess.Popen(
            [script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True)
    except Exception as e:
        log_error(f"pin refresh ({script}): {e}")


class ConfigWriter:
    @staticmethod
    def write_config(file_path,
                     config_data,
                     format='json'):
        """
        Атомарная запись конфигурации:
        0) удаляются "осиротевшие" временные файлы от прошлых
           прерванных записей (защита от накопления мусора на диске);
        1) содержимое пишется во временный файл в той же директории
           (нужно для атомарности os.replace на той же ФС), причём
           временный файл получает то же расширение, что и целевой
           файл (доп. защита на случай, если бинарник определяет
           формат по расширению);
        2) выполняется best-effort preflight-проверка (xray -test для
           vless_config, tor --verify-config для tor_config);
        3) только при успехе временный файл заменяет боевой путь.

        Права временного файла наследуются от уже существующего
        конфига (если есть), иначе ставятся в 0600 — конфиги содержат
        пароли/UUID/reality-ключи и не должны быть читаемы всем.
        Установка прав выполняется ПОСЛЕ передачи fd в os.fdopen()
        (через os.chmod по пути, а не os.fchmod по дескриптору) и
        обёрнута в отдельный try/except: на файловых системах без
        полноценной поддержки POSIX-прав (exFAT/NTFS — частый случай
        для внешних USB-накопителей Entware) chmod может завершиться
        ошибкой — это не должно ни прерывать запись конфига, ни
        приводить к утечке файлового дескриптора.

        Все ошибки (включая невалидный JSON на входе, ошибки создания
        каталога и preflight) логируются через log_error перед
        повторным raise.
        """
        directory = os.path.dirname(file_path) or '.'
        tmp_path = None

        try:
            os.makedirs(directory, exist_ok=True)
            _cleanup_stale_tmp_files(
                directory, os.path.basename(file_path))

            if format == 'json':
                content = json.dumps(
                    json.loads(config_data),
                    ensure_ascii=False, indent=2)
            else:
                content = config_data

            _, ext = os.path.splitext(file_path)
            fd, tmp_path = tempfile.mkstemp(
                dir=directory,
                prefix=f".{os.path.basename(file_path)}.tmp_",
                suffix=ext)

            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                try:
                    if os.path.exists(file_path):
                        mode = os.stat(file_path).st_mode & 0o777
                    else:
                        mode = 0o600
                    os.chmod(tmp_path, mode)
                except OSError as chmod_err:
                    log_error(
                        f"Preflight: chmod пропущен для "
                        f"{tmp_path}: {chmod_err}")

                f.write(content)
                f.flush()
                os.fsync(f.fileno())

            # Preflight выполняется на ВРЕМЕННОМ файле: боевой конфиг
            # заменяется только после успешной проверки, поэтому неудачная
            # генерация не оставляет сервис с нерабочим конфигом.
            real_path = os.path.realpath(file_path)
            checks = {
                os.path.realpath(config.paths.get('vless_config', '')):
                    _preflight_xray,
                os.path.realpath(config.paths.get('tor_config', '')):
                    _preflight_tor,
                os.path.realpath(config.paths.get('hysteria_config', '')):
                    _preflight_hysteria,
                os.path.realpath(config.paths.get('trojan_config', '')):
                    _preflight_trojan,
                os.path.realpath(config.paths.get('shadowsocks_config', '')):
                    _preflight_shadowsocks,
            }
            checker = checks.get(real_path)
            if checker is not None:
                checker(tmp_path)

            # Единая резервная копия прежнего содержимого. Имя
            # фиксированное (<путь>.bak): копия ПЕРЕЗАПИСЫВАЕТСЯ при
            # каждом сохранении (ключ, JSON из панели, мосты Tor) и не
            # накапливается — место на накопителе Entware ограничено.
            # Обновляется ТОЛЬКО перед успешной заменой (после
            # preflight): на провалившемся сохранении в .bak остаётся
            # прежняя рабочая версия, т.е. всегда «последний живой»
            # конфиг. (shutil.copy2 не используется: copystat падает
            # на exFAT/NTFS — частая ФС USB-накопителей.)
            if os.path.exists(file_path):
                try:
                    bak_path = file_path + '.bak'
                    with open(file_path, 'rb') as _src:
                        _prev = _src.read()
                    with open(bak_path, 'wb') as _dst:
                        _dst.write(_prev)
                        _dst.flush()
                        try:
                            os.fsync(_dst.fileno())
                        except OSError:
                            pass
                    try:
                        os.chmod(bak_path, 0o600)
                    except OSError:
                        pass
                except OSError as _bak_err:
                    # Ошибка резервной копии не должна ломать запись
                    # конфига, но обязана попасть в журнал.
                    log_error(
                        f"bak для {file_path}: {_bak_err}")

            os.replace(tmp_path, file_path)

            # Адрес сервера в конфиге только что мог смениться, а в
            # /opt/etc/hosts остался пин от прежнего ключа. Туннель пошёл
            # бы на старый IP, и обход молча не работал бы до 06:00.
            # Обновляем закреплённые адреса сразу после записи конфига
            # любого из протоколов, к которым применяется пиннинг.
            _refresh_pins_if_needed(file_path)

        except Exception as e:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError as rm_err:  # noqa: S110
                    log_error(
                        f"tmp config remove: {rm_err}")
            log_error(
                f"Failed to write config to {file_path}: {e}")
            raise


def notify_on_error():
    def decorator(func):
        def wrapper(key, bot=None,
                    chat_id=None,
                    *args, **kwargs):
            try:
                return func(
                    key, bot, chat_id,
                    *args, **kwargs)
            except Exception as e:
                if bot and chat_id:
                    if func.__name__ == (
                            "tor_config"):
                        bot.send_message(
                            chat_id,
                            f"❌ Tor: "
                            f"{str(e)}")
                    else:
                        protocol = (
                            func.__name__
                            .split('_')[1]
                            .capitalize())
                        bot.send_message(
                            chat_id,
                            f"❌ "
                            f"{protocol}: "
                            f"{str(e)}")
                raise
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# IPv4-only проверка. На роутере Keenetic IPv6 отключён на уровне системы,
# а dnsmasq/ipset в проекте работают только в режиме family inet (IPv4).
# Явный IPv6-адрес сервера в ссылке привёл бы к конфигу, который либо не
# подключится (нет IPv6-стека), либо не попадёт в анблок-списки — поэтому
# такой адрес отклоняется на этапе парсинга с понятной ошибкой.
# ---------------------------------------------------------------------------

def _is_ipv6_literal(host):
    """
    Надёжный маркер IPv6 в этом контексте — наличие ':' в host,
    т.к. ни домены, ни IPv4-адреса символ ':' не содержат (host
    на этом этапе уже отделён от порта вызывающим кодом).
    """
    return bool(host) and ':' in host


def _reject_ipv6_host(host, context="адрес сервера"):
    if _is_ipv6_literal(host):
        raise ValueError(
            f"IPv6 не поддерживается (IPv6 отключён на "
            f"роутере): {context}")


@notify_on_error()
def parse_vless_key(key, bot=None,
                    chat_id=None):
    if not key.startswith('vless://'):
        raise ValueError("vless://")
    url = key[6:]
    parsed_url = urlparse(url)
    params = parse_qs(parsed_url.query)
    if (not parsed_url.hostname
            or not parsed_url.username):
        raise ValueError("Нет адреса/ID")
    _reject_ipv6_host(parsed_url.hostname)
    port = parsed_url.port or 443
    if not (1 <= port <= 65535):
        raise ValueError(f"Порт: {port}")
    transport = params.get(
        'type', ['tcp'])[0]
    raw_path = params.get(
        'path', ['/'])[0]
    raw_host = params.get(
        'host', [''])[0]
    return {
        'address': parsed_url.hostname,
        'port': port,
        'id': parsed_url.username,
        'encryption': params.get(
            'encryption', ['none'])[0],
        'flow': params.get(
            'flow', [''])[0],
        'security': params.get(
            'security', [''])[0],
        'pbk': params.get(
            'pbk', [''])[0],
        'fp': params.get(
            'fp', [''])[0],
        'sni': params.get(
            'sni', [''])[0],
        'sid': params.get(
            'sid', [''])[0],
        'spx': params.get(
            'spx', ['/'])[0],
        'transport': transport,
        'serviceName': params.get(
            'serviceName', [''])[0],
        'ws_path': raw_path,
        'ws_host': raw_host,
        'xhttp_mode': params.get(
            'mode', ['auto'])[0],
        'xhttp_path': raw_path,
        'xhttp_host': raw_host,
    }


@notify_on_error()
def parse_trojan_key(key, bot=None,
                     chat_id=None):
    # Ключи из HTML/Telegram иногда содержат &amp; вместо '&'.
    # Нормализуем только URL-сущности, сохраняя пароль, SNI и path.
    key = key.strip()
    # Поддерживаем как обычный URL из Telegram, так и дважды HTML-
    # экранированный вариант (&amp;amp;), который появляется после
    # последовательного копирования через HTML/Markdown.
    for _ in range(3):
        _decoded_key = html.unescape(key)
        if _decoded_key == key:
            break
        key = _decoded_key
    if not key.startswith('trojan://'): 
        raise ValueError("trojan://")
    parsed_url = urlparse(key)
    params = parse_qs(
        parsed_url.query,
        keep_blank_values=True)
    pw = (unquote(parsed_url.username)
          if parsed_url.username else "")
    if not pw:
        raise ValueError("Нет пароля")
    port = parsed_url.port
    if port is None:
        raise ValueError("Нет порта")
    if not (1 <= port <= 65535):
        raise ValueError(f"Порт: {port}")
    netloc = parsed_url.netloc
    if '@' in netloc:
        hp = netloc.rsplit('@', 1)[-1]
    else:
        hp = netloc
    if hp.startswith('['):
        be = hp.find(']')
        if be == -1:
            raise ValueError("IPv6")
        host = hp[1:be]
    else:
        host = hp.rsplit(':', 1)[0]
    if not host:
        raise ValueError("Нет адреса")
    _reject_ipv6_host(host)
    sni_raw = params.get('sni', [''])[0]
    sni = (unquote(sni_raw)
           if sni_raw else '')
    path_raw = params.get(
        'path', ['/'])[0]
    path = (unquote(path_raw)
            if path_raw else '/')
    result = {
        'pw': pw, 'host': host,
        'port': port, 'sni': sni,
        'fp': params.get('fp', [''])[0],
        'alpn': params.get(
            'alpn', [''])[0],
        'type': params.get(
            'type', ['tcp'])[0],
        'security': params.get(
            'security', ['tls'])[0],
        'path': path,
        'host_header': params.get(
            'host', [''])[0],
        'allowInsecure': params.get(
            'allowInsecure', ['0'])[0],
        'serviceName': params.get(
            'serviceName', [''])[0],
    }
    if not result['sni']:
        result['sni'] = result['host']
    result['ws_enabled'] = (
        'true' if result['type'] == 'ws'
        else 'false')
    # Проверка сертификата отключается ТОЛЬКО при явном allowInsecure=1
    # в ссылке. По умолчанию (в т.ч. при отсутствии параметра) — включена:
    # прежде шаблон трояна жёстко получал verify=false, что снимало защиту
    # от подмены сертификата на всём трафике Trojan.
    result['verify'] = (
        'false'
        if str(result['allowInsecure']).lower() in ('1', 'true', 'yes')
        else 'true')
    return result


@notify_on_error()
def parse_shadowsocks_key(key, bot=None,
                          chat_id=None):
    if not key.startswith('ss://'):
        raise ValueError("ss://")

    def dec_b64(v):
        v = unquote(v.strip())
        v += '=' * ((4 - len(v) % 4) % 4)
        return base64.urlsafe_b64decode(
            v.encode('utf-8')).decode('utf-8')

    raw = key[5:].split('#', 1)[0]

    if '@' in raw:
        userinfo, server_part = raw.rsplit('@', 1)
        decoded = dec_b64(userinfo)
        if ':' not in decoded:
            raise ValueError("method:password")
        method, password = decoded.split(':', 1)
    else:
        decoded = dec_b64(raw)
        if '@' not in decoded:
            raise ValueError("server")
        userinfo, server_part = decoded.rsplit('@', 1)
        if ':' not in userinfo:
            raise ValueError("method:password")
        method, password = userinfo.split(':', 1)

    server_part = server_part.split('?', 1)[0].split('/', 1)[0]
    if server_part.startswith('['):
        end = server_part.find(']')
        if end < 0:
            raise ValueError("IPv6")
        server = server_part[1:end]
        port = server_part[end + 2:]
    else:
        if ':' not in server_part:
            raise ValueError("Порт")
        server, port = server_part.rsplit(':', 1)

    _reject_ipv6_host(server)

    if (not server or not port.isdigit()
            or not method or not password):
        raise ValueError("Некорректный")
    pn = int(port)
    if not (1 <= pn <= 65535):
        raise ValueError(f"Порт: {port}")
    return {
        'server': server, 'port': pn,
        'password': password,
        'method': method,
    }

@notify_on_error()
def parse_hysteria_key(key, bot=None,
                       chat_id=None):
    kc = key.split('#')[0].strip()
    if kc.startswith('hy2://'):
        up = kc[6:]
    elif kc.startswith('hysteria2://'):
        up = kc[12:]
    else:
        raise ValueError("hy2://")
    pu = urlparse('http://' + up)
    params = parse_qs(pu.query)
    auth = (unquote(pu.username)
            if pu.username else "")
    if not auth:
        raise ValueError("Нет пароля")
    server = pu.hostname
    if not server:
        raise ValueError("Нет адреса")
    _reject_ipv6_host(server)
    port = pu.port
    if not port:
        raise ValueError("Нет порта")
    if not (1 <= port <= 65535):
        raise ValueError(f"Порт: {port}")
    sni = params.get('sni', [''])[0]
    if not sni:
        sni = server
    ins = params.get('insecure', ['0'])[0]
    insecure = (
        'true' if str(ins).lower() in ('1', 'true', 'yes') else 'false')
    alpn_raw = params.get('alpn', [''])[0]
    if alpn_raw:
        ap = [p.strip()
              for p in alpn_raw.split(',')
              if p.strip()]
        alpn = ', '.join(
            f'"{p}"' for p in ap)
    else:
        alpn = ''
    ot = params.get('obfs', [''])[0]
    op = params.get('obfs-password', [''])[0]
    return {
        'server': server, 'port': port,
        'auth': auth, 'sni': sni,
        'insecure': insecure, 'alpn': alpn,
        'obfs_type': ot,
        'obfs_password': op,
    }


def _cleanup_empty_fields(obj):
    rif = {'flow'}
    ts = {
        'grpcSettings', 'wsSettings',
        'tcpSettings', 'httpSettings',
        'quicSettings', 'xhttpSettings',
        'httpupgradeSettings',
    }
    ss = {'realitySettings', 'tlsSettings'}
    if isinstance(obj, dict):
        cn = obj.get('network', '')
        cs = obj.get('security', '')
        kr = []
        for k, v in obj.items():
            if k in rif and v == '':
                kr.append(k)
            elif (k in ts
                  and isinstance(v, dict)):
                exp = cn + 'Settings'
                if k != exp:
                    kr.append(k)
                elif not v:
                    kr.append(k)
            elif (k in ss
                  and isinstance(v, dict)):
                exs = cs + 'Settings'
                if k != exs:
                    kr.append(k)
                elif not v:
                    kr.append(k)
            elif isinstance(v, (dict, list)):
                _cleanup_empty_fields(v)
        obfs = obj.get('obfs')
        if (isinstance(obfs, dict)
                and not obfs.get('type')):
            kr.append('obfs')
        alpn = obj.get('alpn')
        if isinstance(alpn, list):
            if (not alpn
                    or (len(alpn) == 1
                        and alpn[0] == '')):
                kr.append('alpn')
        for k in kr:
            if k in obj:
                del obj[k]
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, (dict, list)):
                _cleanup_empty_fields(item)



# Ключи, значения которых подставляются в шаблон как «сырой» JSON
# (числа, булевы литералы, готовые списки alpn), а не как строка.
_JSON_RAW_KEYS = {
    'insecure', 'alpn', 'ws_enabled',
    'verify', 'localportvless',
    'localporttrojan', 'localportsh',
    'localporthysteria',
}

# Значения этих ключей формируются кодом, а не пользователем.
_JSON_RAW_ALLOWED = {
    'true', 'false', '',
}


def _tpl_value(key, value):
    """
    Готовит значение к подстановке в JSON-шаблон.

    Строки экранируются через json.dumps (кавычки, обратные слеши,
    переводы строк). Прежняя версия для «сырых» ключей возвращала
    str(value) без проверки, поэтому специально сформированный ключ
    (например, alpn с кавычкой) ломал структуру JSON или позволял
    дописать в конфиг произвольные поля.
    """
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, (int, float)):
        return str(value)

    if key in _JSON_RAW_KEYS:
        raw = str(value)
        if raw in _JSON_RAW_ALLOWED:
            return raw
        if raw.lstrip('-').isdigit():
            return raw
        if key == 'alpn':
            # alpn собирается из уже проверенных токенов вида "h3", "h2".
            parts = []
            for token in raw.split(','):
                token = token.strip().strip('"')
                if not token:
                    continue
                if not re.match(r'^[A-Za-z0-9.\-/]+$', token):
                    raise ValueError(
                        f"Недопустимое значение alpn: {token}")
                parts.append(json.dumps(token, ensure_ascii=False))
            return ', '.join(parts)
        raise ValueError(
            f"Недопустимое значение поля {key}: {raw}")

    return json.dumps(
        str(value), ensure_ascii=False)[1:-1]


def _ensure_xray_quiet_log(parsed):
    """
    Ограничивает журналирование xray. Без секции "log" xray пишет
    предупреждения и, при access-логе, строку на КАЖДОЕ соединение —
    на накопителе с Entware это быстро съедает место. Оставляем
    только ошибки, access-лог отключаем.
    """
    if not isinstance(parsed, dict):
        return parsed
    log = parsed.get('log')
    if not isinstance(log, dict):
        log = {}
    log['access'] = 'none'
    log['loglevel'] = 'error'
    # Пустая строка означает вывод в stdout; оставляем как есть, если
    # путь задан пользователем осознанно.
    if not log.get('error'):
        log['error'] = ''
    parsed['log'] = log
    return parsed



def _remove_xray_dns_block(parsed):
    """Безусловно удаляет Xray DNS block и старые DNS inbounds.

    DNS клиентов обслуживается системным DoH/DoT proxy через dnsmasq.
    Внешние TCP/443 и TCP/853 соединения этого proxy направляются
    100-redirect.sh в активный transport. Поэтому встроенный Xray DNS
    block и raw DNS listener не должны добавляться независимо от
    версии Xray-core или формата входного JSON.
    """
    if not isinstance(parsed, dict):
        return parsed
    parsed.pop('dns', None)
    inbounds = parsed.get('inbounds')
    if isinstance(inbounds, list):
        parsed['inbounds'] = [
            ib for ib in inbounds
            if not (isinstance(ib, dict)
                    and ib.get('tag') in (
                        'dns-tunnel-tcp', 'dns-tunnel-udp'))]
    return parsed


def _ensure_xray_tproxy(parsed):
    """
    Гарантирует наличие двух inbound-ов dokodemo-door на порту
    config.localportvless:
      * TCP — приходит через nat/REDIRECT, sockopt.tproxy = "redirect";
      * UDP — приходит через mangle/TPROXY, sockopt.tproxy = "tproxy".

    Оба слушают один и тот же порт: TCP- и UDP-сокеты не конфликтуют,
    а правило TPROXY в 100-redirect.sh использует тот же номер порта.
    Без UDP-инбаунда весь UDP-трафик ресурсов из vless.txt (QUIC/HTTP3,
    DNS, игровой трафик, звонки) уходил мимо туннеля.

    Функция вызывается и при генерации из шаблона, и при вставке готового
    конфига через бота/веб-панель, поэтому UDP-инбаунд не теряется при
    смене ключа.
    """
    if not isinstance(parsed, dict):
        return parsed

    port = int(config.localportvless)
    inbounds = parsed.setdefault('inbounds', [])

    # Убрать ранее добавленные служебные inbound-ы, чтобы не плодить дубли.
    inbounds[:] = [
        ib for ib in inbounds
        if ib.get('tag') not in (
            'vless-udp-tproxy', 'vless-tcp-redirect')
    ]

    base = None
    for ib in inbounds:
        if (ib.get('protocol') == 'dokodemo-door'
                and int(ib.get('port', 0)) == port):
            base = ib
            break

    if base is None:
        base = {
            'port': port,
            # IPv6 на роутере отключён — слушаем только IPv4.
            'listen': '0.0.0.0',
            'protocol': 'dokodemo-door',
            'settings': {},
            'sniffing': {
                'enabled': True,
                'destOverride': ['http', 'tls', 'quic'],
            },
        }
        inbounds.insert(0, base)

    base['tag'] = 'vless-tcp-redirect'
    base['port'] = port
    base['listen'] = '0.0.0.0'
    base['protocol'] = 'dokodemo-door'
    base.setdefault('settings', {})
    base['settings']['network'] = 'tcp'
    base['settings']['followRedirect'] = True
    base.setdefault('sniffing', {})
    base['sniffing']['enabled'] = True
    base['sniffing']['destOverride'] = ['http', 'tls', 'quic']
    base.setdefault('streamSettings', {})
    base['streamSettings'].setdefault('sockopt', {})
    base['streamSettings']['sockopt']['tproxy'] = 'redirect'

    udp = json.loads(json.dumps(base))
    udp['tag'] = 'vless-udp-tproxy'
    udp['settings']['network'] = 'udp'
    udp['settings']['followRedirect'] = True
    # Для UDP важен sniffing по QUIC, иначе маршрутизация по доменам
    # для HTTP/3 работать не будет.
    udp['sniffing'] = {
        'enabled': True,
        'destOverride': ['quic'],
    }
    udp['streamSettings']['sockopt']['tproxy'] = 'tproxy'
    inbounds.append(udp)

    # DNS listener Xray не создаётся: dnsmasq использует системные
    # DoH/DoT upstream-ы, а их внешние TCP/443 и TCP/853 соединения
    # перенаправляет 100-redirect.sh в активный tunnel.
    _remove_xray_dns_block(parsed)
    _ensure_xray_udp_routing(parsed)

    # Пакеты, которые xray отправляет наружу, помечаются XRAY_SOCK_MARK.
    # Правило OUTPUT в 100-redirect.sh делает RETURN по этой метке, иначе
    # исходящий трафик самого xray заворачивался бы в его же inbound
    # (bot.txt перехватывается в OUTPUT) и получалась бы петля.
    _ensure_xray_outbound_mark(parsed)

    return parsed


# Должно совпадать с XRAY_MARK в /opt/etc/ndm/netfilter.d/100-redirect.sh
XRAY_SOCK_MARK = 0x2000000


def _ensure_xray_outbound_mark(parsed):
    """
    Проставляет sockopt.mark всем исходящим соединениям xray, кроме
    blackhole (у него нет сетевого выхода).
    """
    for ob in parsed.get('outbounds') or []:
        if not isinstance(ob, dict):
            continue
        # 'type' — вариант ключа в sing-box-конфигах.
        if (ob.get('protocol') or ob.get('type')) == 'blackhole':
            continue
        ss = ob.setdefault('streamSettings', {})
        sockopt = ss.setdefault('sockopt', {})
        sockopt['mark'] = XRAY_SOCK_MARK

    return parsed


def _ensure_xray_udp_routing(parsed):
    """
    Проверяет, что в routing нет правил, отбрасывающих UDP, и что
    существует общее правило на прокси-outbound. Без него UDP-инбаунд
    работал бы «в никуда» при конфигах, где правила заданы только для TCP.
    """
    outbounds = parsed.get('outbounds') or []
    if not outbounds:
        return parsed

    # Протокол берётся из 'protocol' (xray) либо 'type' (sing-box): при
    # вставке готового блока outbounds sing-box-конфига ключа 'protocol'
    # нет, из-за чего proxy_tag не находился и UDP-правило не добавлялось —
    # UDP из vless.txt приходил в inbound и отбрасывался за отсутствием
    # маршрута.
    proxy_kinds = ('vless', 'vmess', 'trojan', 'shadowsocks')
    direct_kinds = ('freedom', 'direct', 'blackhole', 'dns')

    proxy_tag = None
    for ob in outbounds:
        if not isinstance(ob, dict):
            continue
        kind = ob.get('protocol') or ob.get('type')
        if kind in proxy_kinds:
            proxy_tag = ob.get('tag') or 'proxy'
            ob['tag'] = proxy_tag
            break

    if not proxy_tag:
        # Протокол не распознан (нестандартный или новый) — берём первый
        # outbound, который заведомо не является прямым выходом.
        for ob in outbounds:
            if not isinstance(ob, dict):
                continue
            kind = ob.get('protocol') or ob.get('type')
            if kind in direct_kinds:
                continue
            proxy_tag = ob.get('tag') or 'proxy'
            ob['tag'] = proxy_tag
            break

    if not proxy_tag:
        return parsed

    routing = parsed.setdefault('routing', {})
    routing.setdefault('domainStrategy', 'IPIfNonMatch')
    rules = routing.setdefault('rules', [])

    has_catch_all = any(
        r.get('outboundTag') == proxy_tag
        and r.get('port') in ('0-65535', None)
        and not r.get('network')
        for r in rules
        if isinstance(r, dict))

    has_udp_rule = any(
        isinstance(r, dict)
        and 'udp' in str(r.get('network', ''))
        and r.get('outboundTag') == proxy_tag
        for r in rules)

    if not has_catch_all and not has_udp_rule:
        rules.append({
            'type': 'field',
            'network': 'udp,tcp',
            'outboundTag': proxy_tag,
        })

    return parsed


def _ensure_hysteria_tproxy(parsed):
    """
    Приводит нативный конфиг Hysteria2 к режиму прозрачного проксирования:
      * tcpRedirect — приём TCP из nat/REDIRECT;
      * udpTProxy   — приём UDP из mangle/TPROXY.

    Оба слушателя используют один порт config.localporthysteria, тот же,
    что указан в правилах 100-redirect.sh. Раньше udpTProxy мог
    отсутствовать (например, при вставке готового конфига), и весь UDP
    ресурсов из hysteria.txt шёл напрямую, минуя туннель.
    """
    if not isinstance(parsed, dict):
        return parsed

    port = int(config.localporthysteria)
    listen = f'0.0.0.0:{port}'

    parsed.setdefault('tcpRedirect', {})['listen'] = listen
    parsed.setdefault('udpTProxy', {})['listen'] = listen

    # Таймаут UDP-сессий: значение по умолчанию у hysteria велико для
    # роутера, 60 секунд достаточно для игр и звонков.
    parsed['udpTProxy'].setdefault('timeout', '60s')

    return parsed


def generate_config(key, template_file,
                    config_path,
                    replacements,
                    parse_func,
                    bot=None, chat_id=None):
    params = parse_func(key, bot, chat_id)

    with open(
            os.path.join(
                config.paths["templates_dir"],
                template_file),
            'r', encoding='utf-8') as f:
        template = f.read()

    cd = template

    for rk, rv in replacements.items():
        cd = cd.replace(
            "{{" + rk + "}}",
            _tpl_value(rk, rv))

    for pk, pv in params.items():
        cd = cd.replace(
            "{{" + pk + "}}",
            _tpl_value(pk, pv))

    if template_file.endswith('.json'):
        parsed = json.loads(cd)

        if template_file == 'vless_template.json':
            parsed = _remove_xray_dns_block(parsed)
            parsed = _ensure_xray_quiet_log(parsed)
            parsed = _ensure_xray_tproxy(parsed)
        elif template_file == 'hysteria_template.json':
            parsed = _ensure_hysteria_tproxy(parsed)

        _cleanup_empty_fields(parsed)
        cd = json.dumps(
            parsed,
            ensure_ascii=False,
            indent=2)

    ConfigWriter.write_config(
        config_path, cd)

def vless_config(key, bot=None,
                 chat_id=None):
    generate_config(
        key=key,
        template_file="vless_template.json",
        config_path=config.paths[
            "vless_config"],
        replacements={
            "localportvless":
                config.localportvless},
        parse_func=parse_vless_key,
        bot=bot, chat_id=chat_id)


def trojan_config(key, bot=None,
                  chat_id=None):
    generate_config(
        key=key,
        template_file=(
            "trojan_template.json"),
        config_path=config.paths[
            "trojan_config"],
        replacements={
            "localporttrojan":
                config.localporttrojan},
        parse_func=parse_trojan_key,
        bot=bot, chat_id=chat_id)


def shadowsocks_config(key, bot=None,
                       chat_id=None):
    generate_config(
        key=key,
        template_file=(
            "shadowsocks_template.json"),
        config_path=config.paths[
            "shadowsocks_config"],
        replacements={
            "localportsh":
                config.localportsh},
        parse_func=parse_shadowsocks_key,
        bot=bot, chat_id=chat_id)


def hysteria_config(key, bot=None,
                    chat_id=None):
    os.makedirs(
        config.paths.get(
            "hysteria_dir",
            "/opt/etc/hysteria"),
        exist_ok=True)
    generate_config(
        key=key,
        template_file=(
            "hysteria_template.json"),
        config_path=config.paths[
            "hysteria_config"],
        replacements={
            "localporthysteria":
                config.localporthysteria},
        parse_func=parse_hysteria_key,
        bot=bot, chat_id=chat_id)
def _convert_singbox_vless(sb):
    """sing-box vless → xray."""
    server = sb.get('server', '')
    port = sb.get('server_port', 443)
    uuid = sb.get('uuid', '')
    flow = sb.get('flow', '')
    if not server:
        raise ValueError("Нет server")
    if not uuid:
        raise ValueError("Нет uuid")
    tls = sb.get('tls', {})
    sni = tls.get('server_name', server)
    reality = tls.get('reality', {})
    utls = tls.get('utls', {})
    security = 'none'
    if reality.get('enabled'):
        security = 'reality'
    elif tls.get('enabled'):
        security = 'tls'
    # Параметры переносятся БЕЗ самодеятельности: сервер сверяет их при
    # рукопожатии, и любая подстановка «разумного» значения приводит к
    # отказу в подключении. Поэтому поля, которых нет во входном конфиге,
    # не выдумываются, а просто не попадают в выход.
    fp = utls.get('fingerprint', tls.get('fingerprint', ''))
    transport = sb.get('transport', {})
    network = transport.get('type', 'tcp')
    stream = {
        "network": network,
        "security": security,
    }
    if security == 'reality':
        rs = {
            "publicKey": reality.get('public_key', ''),
            "serverName": sni,
            "shortId": reality.get('short_id', ''),
        }
        # fingerprint подставлять нельзя: 'chrome' вместо заданного 'qq'
        # меняет отпечаток TLS ClientHello, и Reality-сервер отвергает
        # соединение. Ключ добавляется, только если задан пользователем.
        if fp:
            rs["fingerprint"] = fp
        # spiderX ("/") раньше добавлялся всегда. Это параметр Reality,
        # который сервер учитывает; навязывать его нельзя.
        spx = reality.get('spider_x', reality.get('spiderX', ''))
        if spx:
            rs["spiderX"] = spx
        stream["realitySettings"] = rs
    elif security == 'tls':
        ts = {"serverName": sni}
        if fp:
            ts["fingerprint"] = fp
        # insecure из входного конфига раньше игнорировался: жёстко
        # писалось allowInsecure=False, и конфиг с самоподписанным
        # сертификатом переставал работать.
        ts["allowInsecure"] = bool(tls.get('insecure', False))
        alpn = tls.get('alpn')
        if alpn:
            ts["alpn"] = alpn if isinstance(alpn, list) else [alpn]
        stream["tlsSettings"] = ts
    if network == 'grpc':
        stream["grpcSettings"] = {
            "serviceName":
                transport.get(
                    'service_name', ''),
        }
    elif network == 'ws':
        # R48-7 (аудит-18): форма headers.Host объявлена в Xray ≥ 25
        # устаревшей (предупреждение на каждом старте сервера);
        # актуальная — отдельное поле host, как в xhttp/httpupgrade
        # ветках. Вход sing-box может нести и старую форму — оставляем
        # её фолбэком (паттерн httpupgradeSettings ниже).
        stream["wsSettings"] = {
            "path": transport.get('path', '/'),
            "host": transport.get(
                'host',
                transport.get('headers', {}).get('Host', '')),
        }
    elif network == 'xhttp':
        # Транспорт xhttp (бывший splithttp). Без этого блока xray
        # получал "network": "xhttp" БЕЗ настроек: path и mode терялись,
        # клиент стучался в корень "/" вместо рабочего пути, и сервер
        # рвал соединение. Шаблон vless_template.json xhttpSettings уже
        # умеет — ссылки vless:// работали, а JSON sing-box нет.
        stream["xhttpSettings"] = {
            "mode": transport.get('mode', 'auto'),
            "path": transport.get('path', '/'),
            "host": transport.get(
                'host',
                transport.get('headers', {}).get('Host', '')),
        }
    elif network == 'httpupgrade':
        stream["httpupgradeSettings"] = {
            "path": transport.get('path', '/'),
            "host": transport.get(
                'host',
                transport.get('headers', {}).get('Host', '')),
        }
    elif network not in ('tcp', ''):
        # Неизвестный транспорт молча пропускать нельзя: xray получит
        # network без соответствующих настроек и будет подключаться
        # неверно. Лучше отказать сразу с понятным текстом.
        raise ValueError(
            f"Транспорт '{network}' не поддерживается. "
            "Поддерживаются: tcp, ws, grpc, xhttp, httpupgrade.")
    user = {
        "id": uuid,
        # encryption обязателен для vless и всегда "none" по спецификации
        # протокола — это не подстановка, а требование формата xray.
        "encryption": "none",
        "level": 0,
    }
    if flow:
        user["flow"] = flow
    xray = {
        "log": {
            "access": "",
            "error": "",
            "loglevel": "none",
        },
        # Inbound-ы (TCP redirect + UDP tproxy) добавит _ensure_xray_tproxy.
        "inbounds": [],
        "outbounds": [
            {
                "tag": "vless-reality",
                "protocol": "vless",
                "settings": {
                    "vnext": [{
                        "address": server,
                        "port": port,
                        "users": [user],
                    }],
                },
                "streamSettings": stream,
            },
            {
                "tag": "direct",
                "protocol": "freedom",
            },
        ],
        "routing": {
            "domainStrategy":
                "IPIfNonMatch",
            "rules": [{
                "type": "field",
                "network": "udp,tcp",
                "port": "0-65535",
                "outboundTag":
                    "vless-reality",
                "enabled": True,
            }],
        },
    }
    return xray


def _convert_xray_hysteria(xc):
    """xray hysteria → нативный hy2."""
    outbounds = xc.get('outbounds', [])
    ho = None
    for ob in outbounds:
        pr = ob.get('protocol', '')
        if pr in ('hysteria', 'hysteria2'):
            ho = ob
            break
    if not ho:
        raise ValueError("Нет outbound hy")
    settings = ho.get('settings', {})
    stream = ho.get('streamSettings', {})
    tls_s = stream.get('tlsSettings', {})
    hy_s = stream.get(
        'hysteriaSettings', {})
    address = settings.get(
        'address',
        settings.get('server', ''))
    port = settings.get('port', 443)
    if not address:
        vn = settings.get('vnext', [])
        if vn:
            address = vn[0].get(
                'address', '')
            port = vn[0].get('port', 443)
    if not address:
        raise ValueError("Нет адреса")
    auth = hy_s.get(
        'auth',
        hy_s.get(
            'auth_str',
            settings.get('auth', '')))
    if not auth:
        vn = settings.get('vnext', [])
        if vn:
            users = vn[0].get('users', [])
            if users:
                auth = users[0].get(
                    'id',
                    users[0].get(
                        'password', ''))
    if not auth:
        raise ValueError("Нет auth")
    sni = tls_s.get(
        'serverName',
        tls_s.get('sni', address))
    alpn = tls_s.get('alpn', [])
    if isinstance(alpn, str):
        alpn = [alpn]
    insecure = tls_s.get(
        'allowInsecure',
        tls_s.get('insecure', False))
    native = {
        "server": f"{address}:{port}",
        "auth": auth,
        "tls": {
            "sni": sni,
            "insecure": insecure,
        },
        "quic": {
            "initStreamReceiveWindow":
                8388608,
            "maxStreamReceiveWindow":
                8388608,
            "initConnReceiveWindow":
                20971520,
            "maxConnReceiveWindow":
                20971520,
        },
        "tcpRedirect": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}")
        },
        # UDP-приём обязателен, иначе QUIC/игровой трафик пойдёт мимо.
        "udpTProxy": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}"),
            "timeout": "60s",
        }
    }
    if alpn:
        native['tls']['alpn'] = alpn
    fm = stream.get('finalmask', {})
    qp = fm.get('quicParams', {})
    cg = qp.get('congestion', '')
    if cg:
        native['quic']['congestion'] = cg
    return native


def _convert_singbox_hysteria(sb):
    """sing-box hysteria2 → нативный hy2."""
    server = sb.get('server', '')
    port = sb.get('server_port', 443)
    password = sb.get('password', '')
    if not server:
        raise ValueError("Нет server")
    if not password:
        raise ValueError("Нет password")
    tls = sb.get('tls', {})
    sni = tls.get(
        'server_name',
        tls.get('sni', server))
    insecure = tls.get(
        'insecure', False)
    alpn = tls.get('alpn', [])
    if isinstance(alpn, str):
        alpn = [alpn]
    native = {
        "server": f"{server}:{port}",
        "auth": password,
        "tls": {
            "sni": sni,
            "insecure": insecure,
        },
        "quic": {
            "initStreamReceiveWindow":
                8388608,
            "maxStreamReceiveWindow":
                8388608,
            "initConnReceiveWindow":
                20971520,
            "maxConnReceiveWindow":
                20971520,
        },
        "tcpRedirect": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}")
        },
        "udpTProxy": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}"),
            "timeout": "60s",
        }
    }
    if alpn:
        native['tls']['alpn'] = alpn
    return native


# FB-212 (2026-11-01): разметка мессенджеров "[текст](http://…)",
# попавшая в JSON-конфиг (serverName, домены, адреса), либо роняет
# json.loads, либо проходит валидацию и молча ломает туннель
# (Reality начинает представляться SNI "[max.ru](http://max.ru)").
# Чистится ДО разбора — тот же принцип, что у чистки мостов Tor
# (tor_config). Группа text НЕ может содержать кавычку: иначе матч
# стартует с квадратной скобки JSON-массива (["…", "…"]) и поглощает
# структуру конфига — регрессия поймана стендом на конфиге с
# "domain": ["domain:[x](http://y)"]. За скобкой массива всегда
# следует кавычка, у текста ссылки внутри значения её нет.
_MD_LINK_RE = re.compile(
    r'\[([^"\]]+)\]\(https?://[^)\s]+\)')


def apply_direct_config(protocol,
                        config_data,
                        bot=None,
                        chat_id=None):
    """
    JSON конфиг напрямую.
    xray, sing-box, нативный.
    """
    cp = {
        'vless': config.paths[
            "vless_config"],
        'shadowsocks': config.paths[
            "shadowsocks_config"],
        'trojan': config.paths[
            "trojan_config"],
        'hysteria': config.paths[
            "hysteria_config"],
    }
    cdir = {
        'vless': config.paths.get(
            "xray_dir", "/opt/etc/xray"),
        'trojan': config.paths.get(
            "trojan_dir",
            "/opt/etc/trojan"),
        'hysteria': config.paths.get(
            "hysteria_dir",
            "/opt/etc/hysteria"),
    }
    if protocol not in cp:
        raise ValueError(
            f"Неизвестный: {protocol}")
    filepath = cp[protocol]
    dp = cdir.get(protocol)
    if dp:
        os.makedirs(dp, exist_ok=True)
    # FB-213: неблокирующие предупреждения для вызывающего кода
    # (панель/бот) — например, вырезанные за отсутствием geoip.dat
    # geoip:-правила. Ошибки по-прежнему идут через ValueError.
    warnings = []
    # JSON из файлов/Telegram может начинаться с UTF-8 BOM.
    # Удаляем только BOM в начале, не изменяя токены и значения полей.
    data = config_data.lstrip('\ufeff').strip()
    if not data:
        raise ValueError("Пустой конфиг")
    # FB-212 (2026-11-01): снятие markdown-ссылок мессенджеров — до
    # json.loads, чтобы значения вида "[max.ru](http://max.ru)"
    # превращались в "max.ru" во ВСЕХ полях конфига, а не ломали
    # разбор или туннель.
    data = _MD_LINK_RE.sub(r'\1', data)
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON: {e}")

    if protocol == 'vless':
        if 'outbounds' in parsed:
            # xray формат. Inbound-ы формирует _ensure_xray_tproxy ниже:
            # отдельно TCP (redirect) и UDP (tproxy). Прежняя версия
            # ставила один inbound "tcp,udp" с followRedirect, из-за чего
            # UDP приходил без оригинального адреса назначения.
            parsed['inbounds'] = []
            rt = parsed.get('routing', {})
            rules = rt.get('rules', [])
            cr = [r for r in rules
                  if 'domain' not in r]
            # FB-213 (2026-11-01): geoip:-токены в сохраняемых
            # правилах требуют geoip.dat — без него Xray падает на
            # старте ("failed to open geoip.dat"; в репозитории
            # Entware пакета геоданных нет). Если .dat отсутствует
            # во всех каталогах поиска, токены вырезаются с
            # предупреждением: RU-direct и доменную маршрутизацию
            # обслуживают списки проекта (unblock/*.txt + ipset),
            # а не routing Xray. Правило, состоящее только из
            # geoip:-токенов, удаляется целиком.
            if not _xray_has_asset('geoip.dat'):
                _kept = []
                for r in cr:
                    _ips = (
                        r.get('ip')
                        if isinstance(r, dict) else None)
                    if not isinstance(_ips, list):
                        _kept.append(r)
                        continue
                    _geo = [t for t in _ips
                            if isinstance(t, str)
                            and t.startswith('geoip:')]
                    if not _geo:
                        _kept.append(r)
                        continue
                    _msg = (
                        ', '.join(_geo)
                        + ' — убрано: нет geoip.dat '
                          '(RU-direct обслуживают списки '
                          'проекта)')
                    if _msg not in warnings:
                        warnings.append(_msg)
                    _rest = [t for t in _ips
                             if t not in _geo]
                    if _rest:
                        _kept.append(dict(r, ip=_rest))
                cr = _kept
            if cr:
                parsed['routing'][
                    'rules'] = cr
            elif 'routing' in parsed:
                del parsed['routing']
        elif (parsed.get('type') == 'vless'
              or ('server' in parsed
                  and 'uuid' in parsed)):
            # sing-box формат
            parsed = (
                _convert_singbox_vless(
                    parsed))
        else:
            raise ValueError(
                "Нет outbounds "
                "или server/uuid")

    elif protocol == 'shadowsocks':
        if 'server' not in parsed:
            raise ValueError("Нет server")
        parsed['local_port'] = (
            config.localportsh)

    elif protocol == 'trojan':
        if (not parsed.get('remote_addr')
                or 'remote_port' not in parsed
                or not parsed.get('password')):
            raise ValueError(
                "Нет remote_addr/remote_port/password")
        parsed['local_port'] = (
            config.localporttrojan)

    elif protocol == 'hysteria':
        if ('server' in parsed
                and 'auth' in parsed):
            # Нативный формат
            pass
        elif ('server' in parsed
              and 'password' in parsed):
            # sing-box формат
            parsed = (
                _convert_singbox_hysteria(
                    parsed))
        elif 'outbounds' in parsed:
            # xray формат
            parsed = (
                _convert_xray_hysteria(
                    parsed))
        else:
            raise ValueError(
                "Нет server/auth, "
                "server/password "
                "или outbounds")
        parsed.setdefault('tcpRedirect', {})['listen'] = (
            f"0.0.0.0:{config.localporthysteria}")

    if protocol == 'vless':
        parsed = _remove_xray_dns_block(parsed)
        parsed = _ensure_xray_quiet_log(parsed)
        parsed = _ensure_xray_tproxy(parsed)
    elif protocol == 'hysteria':
        parsed = _ensure_hysteria_tproxy(parsed)

    ConfigWriter.write_config(
        filepath,
        json.dumps(parsed, ensure_ascii=False))
    # FB-213: список может быть пустым; прежние вызовы, не ждущие
    # результата, совместимы (раньше функция возвращала None).
    return warnings


@notify_on_error()
def tor_config(bridges, bot=None,
               chat_id=None):
    bl = bridges.strip().split('\n')
    vt = {"obfs4", "webtunnel"}
    # Очищенные строки: в torrc должен попасть нормализованный текст,
    # иначе markdown-разметка из буфера обмена уедет в конфиг и Tor
    # не сможет разобрать мост.
    cleaned = []

    # Адрес моста: IPv4 (1.2.3.4:443) либо IPv6 в квадратных скобках
    # ([2001:db8::1]:443). Мосты webtunnel часто публикуются именно
    # с IPv6-адресами, а прежняя проверка принимала только IPv4 и
    # отвергала такие строки целиком.
    # Октеты и порт проверяются по значению: regex вида \d{1,3}
    # пропускал мусор наподобие 999.999.999.999:99999.
    def _valid_endpoint(value):
        if not value:
            return False
        if value.startswith('['):
            host, sep, port = value.rpartition(']:')
            if not sep:
                return False
            host = host[1:]
            family = socket.AF_INET6
        else:
            host, sep, port = value.rpartition(':')
            if not sep:
                return False
            family = socket.AF_INET
        if not port.isdigit() or not 1 <= int(port) <= 65535:
            return False
        try:
            socket.inet_pton(family, host)
        except (OSError, ValueError):
            return False
        return True

    urp = re.compile(
        r"^https?://[^\s/$.?#].\S*$")

    for line in bl:
        line = line.strip()
        if not line:
            continue
        # Строки часто копируют из мессенджера или веб-страницы вместе с
        # markdown-разметкой: ++[https://a/b](https://a/b)++. Tor такой
        # формат не понимает, а пользователь видел невнятную ошибку.
        # Разметка снимается, ссылка берётся из адресной части.
        if '](' in line or '++[' in line:
            line = re.sub(
                r'\+*\[([^\]]+)\]\((?:[^)]*)\)\+*', r'\1', line)
            line = line.replace('++', '').strip()
        cleaned.append(line)
        parts = line.split()
        if parts and parts[0].lower() == "bridge":
            parts = parts[1:]
        if not parts:
            raise ValueError(
                f"Мост: '{line}'")
        tt = (parts[0]
              if parts[0] in vt
              else None)
        if tt:
            if len(parts) < 2:
                raise ValueError(
                    f"IP: '{line}'")
            bd = parts[1]
        else:
            bd = parts[0]
        if tt == "webtunnel":
            # Ред. 29/G27: в части штатных Entware-feed пакет
            # webtunnel-client отсутствует. Deploy оставляет capability-
            # маркер рядом с templates; не записываем заведомо нерабочий
            # мост и не ломаем работающий obfs4/Tor.
            # dirname('/opt/etc/bot/templates/') возвращает сам каталог
            # templates; сначала снимаем завершающий slash, чтобы маркер
            # всегда искался рядом с templates: /opt/etc/bot/.
            wt_marker = os.path.join(
                os.path.dirname(os.path.normpath(
                    config.paths["templates_dir"])),
                ".webtunnel_unavailable")
            if os.path.exists(wt_marker):
                raise ValueError(
                    "WebTunnel недоступен для этой ветки Entware: "
                    "нет пакета webtunnel-client. Используйте мост obfs4")
            if not _valid_endpoint(bd):
                raise ValueError(
                    f"IP:порт: '{line}'")
            # url= может быть пустым
            # в некоторых мостах
            url_match = next(
                (p[4:]
                 for p in parts
                 if p.startswith("url=")),
                None)
            if url_match is None:
                raise ValueError(
                    f"Нет url=: '{line}'")
            # Проверять URL только если
            # он не пустой
            if (url_match
                    and not urp.match(
                        url_match)):
                raise ValueError(
                    f"URL: '{line}'")
        else:
            if not _valid_endpoint(bd):
                raise ValueError(
                    f"IP:порт: '{line}'")

    with open(
            os.path.join(
                config.paths[
                    "templates_dir"],
                "tor_template.torrc"),
            'r', encoding='utf-8') as f:
        cdata = f.read()
        cdata = cdata.replace(
            "{{localporttor}}",
            str(config.localporttor))
        cdata = cdata.replace(
            "{{dnsporttor}}",
            str(config.dnsporttor))
        bo = "\n".join(cleaned) if cleaned else bridges.strip()
        transports = ["obfs4", "webtunnel"]
        found = False
        for t in transports:
            if t in bo:
                bo = "\n".join(
                    line if line.startswith("Bridge ")
                    else (line.replace(
                        t,
                        f"Bridge {t}", 1)
                    if line.startswith(t)
                    else line)
                    for line in
                    bo.splitlines())
                cdata = cdata.replace(
                    f"#ClientTransport"
                    f"Plugin {t}",
                    f"ClientTransport"
                    f"Plugin {t}", 1)
                found = True
        cdata = cdata.replace(
            "{{bridges}}",
            bo if found else "")
    ConfigWriter.write_config(
        config.paths["tor_config"],
        cdata, format='text')



def send_archive(bot, chat_id,
                 file_path, caption):
    f = None
    try:
        f = open(file_path, "rb")
        bot.send_document(
            chat_id, f, caption=caption)
    # P9 (аудит rev3): перечень исключений покрывает весь сетевой
    # класс + API-ошибки Telegram (в том числе лимит размера файла),
    # чтобы пользователь получал понятное сообщение, а не падение.
    except Exception as e:  # noqa: BLE001
        log_error(
            f"send_archive ({file_path}): {e}")
        try:
            bot.send_message(
                chat_id, "❌ Ошибка отправки: "
                         f"{type(e).__name__}")
        except Exception:  # noqa: BLE001
            pass
        return False
    finally:
        if f:
            try:
                f.close()
            except OSError:  # noqa: S110
                # Закрытие файла в finally: ошибка закрытия после
                # записи уже сопровождается основным исключением.
                pass
            del f
            gc.collect()
    return True


def split_and_send_archive(
        bot, chat_id, archive_path,
        max_size, backup_state,
        progress_msg_id):
    sp = f"{archive_path}_part_"
    try:
        # Крупный архив делится долго, но не бесконечно.
        subprocess.run(
            ["split", "-b", str(max_size),
             archive_path, sp],
            check=True, timeout=600)
        pf = sorted([
            f for f in os.listdir(
                os.path.dirname(
                    archive_path))
            if f.startswith(
                os.path.basename(sp))])
        for part_file in pf:
            pp = os.path.join(
                os.path.dirname(
                    archive_path),
                part_file)
            if not send_archive(
                    bot, chat_id, pp,
                    f"⏳ ({part_file})"):
                return False
        bot.edit_message_text(
            f"✅ Разбит:\n"
            f"{', '.join(backup_state.get_selected_types())}",
            chat_id, progress_msg_id)
        return True
    except subprocess.TimeoutExpired as e:
        log_error(f"[!] split не завершился: {e}")
        return False
    except subprocess.CalledProcessError as e:
        log_error(f"Split: {str(e)}")
        bot.edit_message_text(
            "❌ Разбиение",
            chat_id, progress_msg_id)
        return False


def create_backup_with_params(
        bot, chat_id, backup_state,
        selected_drive, progress_msg_id):
    archive_path = None
    args = [config.paths["script_bu"]]
    ms = (config.backup_settings
          .get("MAX_SIZE_MB")
          * 1024 * 1024)
    params = {
        "LOG_FILE":
            config.backup_settings[
                "LOG_FILE"],
        "SELECTED_DRIVE":
            selected_drive["path"],
        "BACKUP_STARTUP_CONFIG": str(
            backup_state
            .startup_config).lower(),
        "BACKUP_FIRMWARE": str(
            backup_state
            .firmware).lower(),
        "BACKUP_ENTWARE": str(
            backup_state
            .entware).lower(),
        "BACKUP_CUSTOM_FILES": str(
            backup_state
            .custom_files).lower(),
    }
    args.extend(
        [f"{k}={v}"
         for k, v in params.items()])
    if (backup_state.custom_files
            and 'CUSTOM_BACKUP_PATHS'
            in config.backup_settings):
        args.append(
            f"CUSTOM_BACKUP_PATHS="
            f"{config.backup_settings['CUSTOM_BACKUP_PATHS']}")
    # KeenSnap — внешний скрипт, он НЕ входит в проект и ставится
    # отдельно. Без этой проверки Popen поднимал FileNotFoundError,
    # обработчик бота падал с необработанным исключением, и кнопка
    # «Бэкап» молча переставала отвечать.
    if not os.path.exists(args[0]):
        bot.edit_message_text(
            "❌ Не найден скрипт бэкапа:\n"
            f"{args[0]}\n"
            "Установите KeenSnap или поправьте "
            "paths['script_bu'] в bot_config.py",
            chat_id, progress_msg_id)
        log_error(f"script_bu отсутствует: {args[0]}")
        return None

    try:
        process = subprocess.Popen(
            args, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True, bufsize=1,
            universal_newlines=True)
    except OSError as e:
        bot.edit_message_text(
            f"❌ Не удалось запустить бэкап: {e}",
            chat_id, progress_msg_id)
        log_error(f"Popen {args[0]}: {e}")
        return None
    final_result = None
    try:
        for line in process.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                if data.get("type") == (
                        "progress"):
                    bot.edit_message_text(
                        f"⏳ "
                        f"{data['message']}",
                        chat_id,
                        progress_msg_id)
                elif "status" in data:
                    final_result = data
            except json.JSONDecodeError:
                continue
        process.wait()
        if (final_result
                and final_result["status"]
                == "success"):
            archive_path = (
                final_result[
                    "archive_path"])
            if not os.path.exists(
                    archive_path):
                bot.edit_message_text(
                    "❌ Не найден",
                    chat_id,
                    progress_msg_id)
                return
            asz = os.path.getsize(
                archive_path)
            if asz <= ms:
                bot.edit_message_text(
                    "✅ Отправляю...",
                    chat_id,
                    progress_msg_id)
                cap = (
                    f"✅ Бэкап:\n"
                    f"{', '.join(backup_state.get_selected_types())}")
                if send_archive(
                        bot, chat_id,
                        archive_path,
                        cap):
                    bot.edit_message_text(
                        "✅ Завершен",
                        chat_id,
                        progress_msg_id)
            else:
                bot.edit_message_text(
                    "❕ Разбиваю...",
                    chat_id,
                    progress_msg_id)
                split_and_send_archive(
                    bot, chat_id,
                    archive_path,
                    ms, backup_state,
                    progress_msg_id)
        elif final_result:
            bot.edit_message_text(
                f"❌ "
                f"{final_result.get('message', '?')}",
                chat_id,
                progress_msg_id)
        else:
            bot.edit_message_text(
                "❌ Без результата",
                chat_id,
                progress_msg_id)
    finally:
        if (archive_path
                and os.path.exists(
                    archive_path)
                and backup_state
                .delete_archive):
            try:
                os.remove(archive_path)
            except Exception as e:
                log_error(
                    f"Del: {str(e)}")
        if (archive_path
                and os.path.exists(
                    os.path.dirname(
                        archive_path))):
            dp = os.path.dirname(
                archive_path)
            bn = os.path.basename(
                archive_path)
            for pf in [
                    f for f
                    in os.listdir(dp)
                    if f.startswith(
                        f"{bn}_part_")]:
                try:
                    os.remove(
                        os.path.join(
                            dp, pf))
                except Exception as e:
                    log_error(
                        f"Part: {str(e)}")


def get_available_drives():
    drives = []
    curr = None
    cm = None
    try:
        mo = subprocess.check_output(
            ["ndmc", "-c", "show media"],
            text=True,
            stderr=subprocess.STDOUT,
            timeout=10)
    except (subprocess.CalledProcessError,
            subprocess.TimeoutExpired,
            Exception):
        return []
    for rl in mo.splitlines():
        s = rl.strip()
        if s.startswith("manufacturer:"):
            cm = s.split(":", 1)[1].strip()
        elif s.startswith("uuid:"):
            if curr:
                drives.append(curr)
            uuid = (
                s.split(":", 1)[1].strip())
            curr = {
                'uuid': uuid,
                'path': f"/tmp/mnt/{uuid}"}
        elif (s.startswith("label:")
              and curr is not None):
            curr['label'] = (
                s.split(":", 1)[1].strip())
        elif (s.startswith("fstype:")
              and curr is not None):
            ft = (
                s.split(":", 1)[1].strip())
            if ft == "swap":
                curr = None
            else:
                curr['fstype'] = ft
        elif (s.startswith("free:")
              and curr is not None):
            val = (
                s.split(":", 1)[1].strip())
            try:
                sg = round(
                    int(val)
                    / (1024*1024*1024), 1)
            except Exception:
                sg = None
            curr['size'] = sg
            if curr.get('label'):
                curr['display_name'] = (
                    curr['label'])
            elif cm:
                curr['display_name'] = cm
            else:
                curr['display_name'] = (
                    "Unknown")
    if curr:
        drives.append(curr)
    return drives


# ── r87 (NFQWS2, решение владельца 2026-11-01): детекторы состояния ──────
# Общий код для бота (handlers) и панели (generator). Пакет nfqws2-keenetic
# ставится deploy_bypass.sh, init-обёртка проекта — S90nfqws2 (ENABLED=),
# штатный init пакета — S51nfqws2 ( бит +x снят донaстройкой: единственная
# точка автозапуска — обёртка, чтобы не было двойного старта на буте).

NFQWS2_INIT = config.paths.get(
    'init_nfqws2', '/opt/etc/init.d/S90nfqws2')
NFQWS2_S51 = '/opt/etc/init.d/S51nfqws2'
# Протоколы, конфликтные с nfqws2: правила туннелей (nat REDIRECT)
# перехватывают трафик раньше mangle POSTROUTING nfqws2, а глобальный
# режим nfqws2 дополнительно «дурит» исходящие соединения самих
# туннелей к серверам (ломает маскировку Reality и handshake).
NFQWS2_CONFLICT_SERVICES = (
    ('shadowsocks', 'S65shadowsocks', 'ss-redir'),
    ('trojan', 'S22trojan', 'trojan'),
    ('vless', 'S24xray', 'xray'),
    ('tor', 'S35tor', 'tor'),
    ('hysteria', 'S57hysteria', 'hysteria'),
)


def nfqws2_installed():
    """Пакет nfqws2-keenetic установлен (штатный init на месте)."""
    return os.path.isfile(NFQWS2_S51)


def _init_enabled_yes(init_path):
    """ENABLED=yes в init-скрипте (формат обёрток проекта)."""
    try:
        with open(init_path, 'r',
                  encoding='utf-8', errors='replace') as f:
            for line in f:
                m = re.match(
                    r'^\s*ENABLED\s*=\s*(\S+)', line)
                if m:
                    return m.group(1).strip('"\'') == 'yes'
                # ENABLED обязан идти до какого-либо кода; дальше
                # не ищем, чтобы не поймать чужие вхождения.
                if line.strip() and not line.strip().startswith('#'):
                    if not re.match(
                            r'^(ENABLED|PROCS|ARGS|PREARGS|DESC|PATH)=',
                            line.strip()):
                        break
    except OSError:
        pass
    return False



def _proc_alive(proc):
    """r91 (аудит r90, А/Г): живой процесс по pidof (BusyBox). Ошибка
    запуска pidof — False (не удалось проверить — считаем
    остановленным; та же семантика, что в nfqws2_conflicts)."""
    import subprocess
    try:
        return subprocess.run(
            ['pidof', proc],
            capture_output=True, timeout=10).returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


def _run_init_cmd(init_path, action):
    """r91 (аудит r90, А): запуск init-скрипта с честным результатом —
    CompletedProcess или None (не запустился/таймаут). Прежние вызовы
    subprocess.run(...) не смотрели returncode: отказ stop/start
    маскировался ложным «✅ включен/выключен»."""
    import subprocess
    # r93 (аудит r92, А): продлить lock на время долгой init-команды.
    _toggle_lock_heartbeat()
    try:
        return subprocess.run(
            ['sh', init_path, action],
            capture_output=True, timeout=60)
    except (subprocess.SubprocessError, OSError):
        return None


# r91 (аудит r90, E — решение владельца): межпроцессная сериализация
# переключений протоколов/NFQWS2. Панель и бот — разные процессы, а
# проверка конфликтов и применение изменения не составляли транзакцию:
# два почти одновременных административных действия (двойной submit,
# панель+бот) в окне ~сотен миллисекунд могли разойтись с состоянием
# (NFQWS2 Глобал при включённом туннеле). Паттерн LIFECYCLE_LOCKDIR
# из update_protocols.sh: lockdir в /tmp с файлом owner; устойчивый
# lock (>&120 с) считается брошенным и снимается. Захват без
# ожидания: занято — вежливое «повторите позже».
_TOGGLE_LOCKDIR = '/tmp/keenzoo_toggle.lockdir'
_TOGGLE_LOCK_STALE = 120.0
# r93 (аудит r92, KZ92-01/P2-2): token текущего захвата этого
# процесса (None — не держит). Владение подтверждается при снятии.
_TOGGLE_LOCK_TOKEN = None
# r94 (аудит r93, KZ93-01): реклейм устойчивого lock сериализуется
# отдельным recovery-гейтом (mkdir-каталог); 15 с — с запасом,
# внутри только локальные файловые операции.
_TOGGLE_RECOVERY_DIR = _TOGGLE_LOCKDIR + '.recovery'
_TOGGLE_RECOVERY_STALE = 15.0
# r98 (аудит r97, AUD-R97-02 — решение владельца 04.11.2026):
# kernel-сериализация acquire/release toggle-lock: flock(2) по
# СТАБИЛЬНОМУ lock-файлу (никем не переименовывается/не удаляется —
# в отличие от каталогов dir-протокола, которые реклеймеры
# переименовывают). Все снимки/rename/публикации dir-протокола
# выполняются под этим мьютексом: окна «смещение canonical между
# mkdir и записью owner» (проба F аудита r97: два
# acquire_toggle_lock() == True) закрыты ядром. fcntl — stdlib
# Linux-CPython (Entware-профиль проекта); держится миллисекунды
# (только acquire/release, НЕ операция переключения); гибель
# держателя → ядро снимает lock само — «подвисший» flock
# невозможен по построению.
_TOGGLE_KFLOCK = '/tmp/keenzoo_toggle.lockfile'


def _kflock_acquire(path, timeout=5.0):
    """fd — kernel-lock взят; None — недоступен (вызывающие ветки
    отказывают в безопасную сторону: «повторите»). Спин короткий:
    держатели — только acquire/release (миллисекунды)."""
    import fcntl
    _deadline = time.monotonic() + timeout
    while True:
        try:
            fd = os.open(
                path, os.O_RDWR | os.O_CREAT
                | getattr(os, 'O_NOFOLLOW', 0), 0o600)
        except OSError:
            return None
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return fd
        except OSError:
            os.close(fd)
            if time.monotonic() >= _deadline:
                return None
            time.sleep(0.05)


def _kflock_release(fd):
    """Снятие kernel-lock (fd от _kflock_acquire)."""
    if fd is None:
        return
    import fcntl
    try:
        fcntl.flock(fd, fcntl.LOCK_UN)
    except OSError:
        pass
    try:
        os.close(fd)
    except OSError:
        pass
# r95 (аудит r94, KZ94-03): идентичность захваченного lockdir —
# (st_dev, st_ino); EIO-ветка release удаляет только СВОЙ каталог.
_TOGGLE_LOCK_IDENT = None
# r96 (аудит r95, KZ95-01): токен recovery-гейта — per-acquire:
# возвращается захватом и передаётся в release параметром. Глобала
# нет: mutable-глобал процесса позволял release «проснувшегося»
# потока сверить ТОКЕН КОНКУРЕНТА (перезаписавший глобал) с его же
# гейтом и удалить чужой живой гейт.


def _toggle_lock_heartbeat():
    """r93 (аудит r92, А): продление жизни lockdir в долгих операциях
    (init-команды до 60 с, netfilter-хук до 60 с на таблицу —
    штатная force-операция может идти минуты). mtime обновляется,
    только пока lock принадлежит этому процессу: легимитимная
    операция никогда не выглядит «брошенной»."""
    if _TOGGLE_LOCK_TOKEN is None:
        return
    try:
        os.utime(_TOGGLE_LOCKDIR)
    except OSError:
        pass


def _owner_pid_in(dirpath):
    """r94 (аудит r93, KZ93-01): PID из owner-файла произвольного
    каталога — пост-проверка перенесённого при реклейме."""
    try:
        with open(os.path.join(
                dirpath, 'owner'), 'r') as f:
            parts = f.read().split()
        return int(parts[0]) if parts else None
    except (OSError, ValueError, IndexError):
        return None


def _owner_raw_in(dirpath):
    """r95 (аудит r94, KZ94-01): полный owner-токен каталога (строка)
    или None — пост-проверка перенесённого при реклейме (сравнения
    только PID мало: None==None проходило)."""
    try:
        with open(os.path.join(
                dirpath, 'owner'), 'r') as f:
            return f.read().strip()
    except OSError:
        return None


def _owner_pid_of_raw(raw):
    """r96 (аудит r95, KZ95-01): PID из СТРОКИ owner или None —
    liveness проверяется по тому же снимку, что и пост-проверка
    реклейма (раздельные чтения смешивали снимки старого и нового
    каталогов — второй путь двойного acquire)."""
    try:
        parts = (raw or '').split()
        return int(parts[0]) if parts else None
    except (ValueError, IndexError):
        return None


def _toggle_owner_pid():
    """PID из owner-файла или None (нет/мусор/чужой формат)."""
    return _owner_pid_in(_TOGGLE_LOCKDIR)


def _pid_alive(pid):
    """Жив ли процесс (сигнал 0). Ошибка прав — «жив» (процесс
    существует под другим uid: не отбираем)."""
    if not pid or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except OSError:
        return True


def _recovery_gate_acquire():
    """r94 (аудит r93, KZ93-01): атомарная сериализация stale-реклейма
    (mkdir-гейт). Занятый свежий гейт → False («повторите»).
    r95 (аудит r94, KZ94-01): у гейта есть владелец — gate-файл
    (PID+token); снимается гейт только своим токеном.
    r96 (аудит r95, KZ95-01): возвращает ТОКЕН захвата (строку) —
    владение per-acquire; протухший гейт отбирается только у
    МЁРТВОГО владельца (PID из gate-файла жив → гейт держится
    независимо от возраста: просрочка — предохранитель от мёртвого
    держателя, не lease живого потока); провал записи gate-файла
    убирает каталог, созданный ЭТОЙ попыткой (прежде «пустой» гейт
    блокировал повторные захваты, пока не состарится).
    r97 (аудит r96, KZ96-01 — решение владельца 04.11.2026):
    реклейм с пост-проверкой переименованного (снимок raw+mtime_ns
    сверяется УЖЕ в перемещённом каталоге — прежде rename→rmtree
    без проверки уничтожал свежий гейт конкурента, поставленный в
    окне между чтением и rename: два токена на руках); имена
    реклейма уникальны (PID+random: у двух потоков одного процесса
    не было коллизии на общем пути); чужой при неудачном возврате
    остаётся в стороне — чужое не удаляется."""
    import secrets
    import shutil

    def _claim_gate():
        tok = '%d %s' % (os.getpid(), secrets.token_hex(8))
        try:
            with open(os.path.join(
                    _TOGGLE_RECOVERY_DIR, 'gate'), 'w') as f:
                f.write(tok)
        except OSError:
            return None
        return tok

    _ours = False
    try:
        os.mkdir(_TOGGLE_RECOVERY_DIR)
        _ours = True
    except FileExistsError:
        try:
            _graw = None
            try:
                with open(os.path.join(
                        _TOGGLE_RECOVERY_DIR, 'gate'), 'r') as f:
                    _graw = f.read().strip()
            except OSError:
                _graw = None
            _gpid = _owner_pid_of_raw(_graw)
            if _gpid is not None and _pid_alive(_gpid):
                return False
            try:
                _gmtime_ns = os.stat(
                    _TOGGLE_RECOVERY_DIR).st_mtime_ns
            except OSError:
                return False
            if (time.time() - _gmtime_ns / 1e9
                    <= _TOGGLE_RECOVERY_STALE):
                return False
        except OSError:
            return False
        # r97: уникальное имя — параллельные реклеймы одного
        # процесса не сталкиваются на общем пути
        dead = '%s.stale.%d.%s' % (
            _TOGGLE_RECOVERY_DIR, os.getpid(),
            secrets.token_hex(4))
        try:
            os.rename(_TOGGLE_RECOVERY_DIR, dead)
        except OSError:
            return False
        # r97: пост-проверка — перемещён именно снимок, который
        # проверялся; подменённый (конкурент уже реклеймил и
        # поставил свежий гейт) — вернуть на место и отказаться
        _mraw = None
        try:
            with open(os.path.join(dead, 'gate'), 'r') as f:
                _mraw = f.read().strip()
        except OSError:
            _mraw = None
        _mmtime_ns = None
        try:
            _mmtime_ns = os.stat(dead).st_mtime_ns
        except OSError:
            pass
        if _mraw != _graw or _mmtime_ns != _gmtime_ns:
            try:
                os.rename(dead, _TOGGLE_RECOVERY_DIR)
            except OSError:
                # canonical занят ещё более новым — чужое остаётся
                # в стороне под уникальным именем, не удаляем
                pass
            return False
        shutil.rmtree(dead, ignore_errors=True)
        try:
            os.mkdir(_TOGGLE_RECOVERY_DIR)
        except OSError:
            return False
        _ours = True
    except OSError:
        return False
    tok = _claim_gate()
    if tok is None:
        if _ours:
            # каталог создан ЭТОЙ попыткой — убираем свой мусор
            shutil.rmtree(_TOGGLE_RECOVERY_DIR, ignore_errors=True)
        return False
    return tok


def _recovery_gate_release(token=None):
    """r95 (аудит r94, KZ94-01): снимает только СВОЙ гейт — gate-файл
    сверяется с токеном захвата; чужой не трогаем.
    r96 (аудит r95, KZ95-01): токен — per-acquire (параметр, не
    глобал); сверка ПОСЛЕ атомарного захвата пути: каталог сначала
    переименовывается в частный, токен читается УЖЕ в нём — окно
    «прочитал совпало → конкурент подменил → rename взял чужое»
    (TOCTOU) закрыто; чужой гейт возвращается на место (если путь
    занят ещё более новым — остаётся в стороне, чужое не удаляем).
    r97 (аудит r96, KZ96-01): путь переименования уникален
    (PID+random) — прежде фиксированное .rel.<PID> позволяло
    параллельному release того же процесса молча провалиться на
    занятом имени и оставить гейт с ЖИВЫМ PID на рабочем пути
    (deadlock переключений до перезапуска процесса)."""
    if token is None:
        return
    import secrets
    import shutil
    dead = '%s.rel.%d.%s' % (
        _TOGGLE_RECOVERY_DIR, os.getpid(), secrets.token_hex(4))
    try:
        os.rename(_TOGGLE_RECOVERY_DIR, dead)
    except OSError:
        return
    try:
        with open(os.path.join(dead, 'gate'), 'r') as f:
            cur = f.read().strip()
    except OSError:
        # нечитаем — вернуть на место: чужое не удаляем
        try:
            os.rename(dead, _TOGGLE_RECOVERY_DIR)
        except OSError:
            pass
        return
    if cur != token:
        # гейт не наш — восстановить чужой
        try:
            os.rename(dead, _TOGGLE_RECOVERY_DIR)
        except OSError:
            pass
        return
    shutil.rmtree(dead, ignore_errors=True)


def _rmdir_lockdir_best_effort(token=None, ident=None):
    """Атомарное удаление lockdir: rename, затем rmtree.
    r96 (аудит r95, KZ95-02): TOCTOU-safe — каталог сначала
    переименовывается, владелец (token или идентичность
    st_dev/st_ino) сверяется УЖЕ у переименованного: подменённый в
    окне stat→rename чужой lockdir возвращается на место, а не
    удаляется. Без критерия (token/ident не заданы) — прежний
    best-effort (вызов только из свежесозданных нами каталогов).
    r97 (аудит r96, KZ96-01): путь переименования уникален
    (PID+random) — прежде фиксированное .rel.<PID> сталкивалось с
    параллельным release того же процесса: rename молча провалился,
    а новый lock с живым владельцем оставался на рабочем пути
    (deadlock переключений); застрявший мусор больше не отравляет
    последующие release."""
    import secrets
    import shutil
    dead_dir = '%s.rel.%d.%s' % (
        _TOGGLE_LOCKDIR, os.getpid(), secrets.token_hex(4))
    try:
        os.rename(_TOGGLE_LOCKDIR, dead_dir)
    except OSError:
        return
    _mine = True
    if token is not None:
        try:
            with open(os.path.join(dead_dir, 'owner'), 'r') as f:
                _mine = f.read().strip() == token
        except OSError:
            _mine = False
    elif ident is not None:
        try:
            _st = os.stat(dead_dir)
            _mine = (_st.st_dev, _st.st_ino) == ident
        except OSError:
            _mine = False
    if _mine:
        shutil.rmtree(dead_dir, ignore_errors=True)
        return
    try:
        os.rename(dead_dir, _TOGGLE_LOCKDIR)
    except OSError:
        # путь занят — чужой каталог не удаляем, остаётся в стороне
        pass


def _drop_fresh_lockdir_silent():
    """r94 (аудит r93, KZ93-03): убрать каталог, созданный ЭТОЙ
    попыткой захвата (запись owner не подтвердилась). Только если в
    нём по-прежнему нет владельца: за долгую паузу каталог
    теоретически мог быть переставлен реклеймом другого процесса."""
    try:
        if _toggle_owner_pid() is not None:
            return
    except OSError:
        pass
    _rmdir_lockdir_best_effort()


def acquire_toggle_lock():
    """True — lock захвачен; False — выполняется другая операция
    переключения (панель/бот показывают «повторите»).
    r98 (аудит r97, AUD-R97-02 — решение владельца 04.11.2026):
    вся попытка захвата (гейт, реклейм, mkdir lockdir, публикация
    owner) выполняется под kernel-мьютексом flock(2) по СТАБИЛЬНОМУ
    lock-файлу: межпроцессные интерливинги dir-протокола (смещение
    canonical между mkdir и записью owner — два True, проба F)
    невозможны. dir-протокол r93–r97 сохранён полностью
    (owner/liveness/stale/heartbeat/диагностика) — defense-in-depth
    и носитель семантики; flock держится только на время acquire
    (миллисекунды), не операции переключения; гибель процесса в
    момент acquire → ядро снимает flock само. Гейт — внутренняя
    фаза под тем же flock: прямые вызовы вне acquire_toggle_lock не
    предусмотрены. История правок r93–r97 — в докстринге
    _acquire_toggle_lock_under_kflock."""
    _kfd = _kflock_acquire(_TOGGLE_KFLOCK)
    if _kfd is None:
        return False
    try:
        return _acquire_toggle_lock_under_kflock()
    finally:
        _kflock_release(_kfd)


def _acquire_toggle_lock_under_kflock():
    """True — lock захвачен; False — выполняется другая операция
    переключения (панель/бот показывают «повторите»).
    r93 (аудит r92, KZ92-01/P2-2): устойчивый lock отбирается
    ТОЛЬКО у мёртвого владельца (PID из owner; прежде отбор по
    одному mtime вытеснял живую долгую операцию — 120 с меньше
    худшего штатного времени force-цепочки); захват атомарен
    (rename-claim: проигравший конкурент видит отказ).
    r94 (аудит r93, KZ93-01/KZ93-03): реклейм — только под
    recovery-гейтом, с ПОВТОРНЫМ чтением owner уже под гейтом и
    пост-проверкой перенесённого каталога; запись owner — атомарная
    (tmp + replace) и fail-closed: отказ файловой системы убирает
    каталог этой попытки и возвращает False.
    r95 (аудит r94, KZ94-01/KZ94-03): recovery-гейт держится ДО
    завершения атомарной публикации owner (прежде освобождался
    раньше — свежий lockdir без owner жил вне гейта, пауза давала
    вторичный реклейм и двойной acquire); пост-проверка перенесённого
    сравнивает полный owner и mtime_ns (PID-сравнения мало);
    идентичность захваченного каталога (st_dev, st_ino)
    запоминается для EIO-ветки release.
    r97 (аудит r96, KZ96-01 — решение владельца 04.11.2026):
    гейт берётся ВСЕМИ попытками захвата, включая ветку «lockdir
    отсутствует» (fast-path mkdir): прежде третий претендент мог
    создать lockdir обычным mkdir в окне, пока реклеймер держал
    canonical переименованным для пост-проверки, — два победителя.
    Компромисс: после краха acquire, оставившего свежий гейт с
    мёртвым PID (<15 с), следующий запрос получает «повторите»
    (≤15 с), прежде fast-path прошёл бы сразу. Mismatch-ветка при
    неудачном возврате чужого каталога больше НЕ удаляет его
    (прежде rmtree уничтожал чужой свежий lock — нарушало «чужое
    не удаляем»; каталог остаётся в стороне под уникальным
    именем); имя реклейма уникально (PID+random — без коллизий
    параллельных попыток одного процесса)."""
    global _TOGGLE_LOCK_TOKEN, _TOGGLE_LOCK_IDENT
    import secrets
    # r97: сериализация ВСЕХ acquire — включая fast-path
    _gate = _recovery_gate_acquire()
    if not _gate:
        return False
    try:
        try:
            os.mkdir(_TOGGLE_LOCKDIR)
        except FileExistsError:
            try:
                # повторное чтение ПОД гейтом: конкурент мог полностью
                # восстановить lock, пока мы шли сюда.
                # r96 (аудит r95, KZ95-01): liveness и цель реклейма —
                # ОДИН снимок owner: прежде PID читался отдельным
                # вызовом и мог относиться к уже заменённому каталогу
                # (смешение снимков — путь двойного acquire)
                _own_before = _owner_raw_in(_TOGGLE_LOCKDIR)
                pid = _owner_pid_of_raw(_own_before)
                if pid is not None and _pid_alive(pid):
                    return False
                try:
                    _mtime_before = os.stat(
                        _TOGGLE_LOCKDIR).st_mtime_ns
                except OSError:
                    return False
                if (pid is None
                        and time.time() - _mtime_before / 1e9
                        <= _TOGGLE_LOCK_STALE):
                    # owner не читается, но lock свежий — не трогаем
                    return False
                # r97: уникальное имя — параллельные реклеймы одного
                # процесса не сталкиваются на общем пути
                dead_dir = '%s.dead.%d.%s' % (
                    _TOGGLE_LOCKDIR, os.getpid(),
                    secrets.token_hex(4))
                try:
                    os.rename(_TOGGLE_LOCKDIR, dead_dir)
                except OSError:
                    return False
                # пост-проверка: перенесён именно проверенный lock —
                # полный owner и mtime_ns совпадают; иначе каталог под
                # нами уже переставлен — вернуть на место, отказаться
                _restored = False
                if _owner_raw_in(dead_dir) != _own_before:
                    _restored = True
                else:
                    try:
                        if (os.stat(dead_dir).st_mtime_ns
                                != _mtime_before):
                            _restored = True
                    except OSError:
                        pass
                if _restored:
                    try:
                        os.rename(dead_dir, _TOGGLE_LOCKDIR)
                    except OSError:
                        # r97 (KZ96-01): canonical занят — чужой
                        # каталог НЕ удаляем: остаётся в стороне под
                        # уникальным именем (прежде rmtree уничтожал
                        # чужой свежий lock в этой ветке)
                        pass
                    return False
                import shutil
                shutil.rmtree(dead_dir, ignore_errors=True)
                try:
                    os.mkdir(_TOGGLE_LOCKDIR)
                except OSError:
                    return False
            except OSError:
                return False
        except OSError:
            return False
        token = '%d %s' % (os.getpid(), secrets.token_hex(8))
        _tmp = None
        try:
            import tempfile
            _fd, _tmp = tempfile.mkstemp(
                prefix='owner.', dir=_TOGGLE_LOCKDIR)
            with os.fdopen(_fd, 'w') as f:
                f.write(token)
            os.replace(
                _tmp, os.path.join(_TOGGLE_LOCKDIR, 'owner'))
            _tmp = None
        except OSError:
            if _tmp is not None:
                try:
                    os.unlink(_tmp)
                except OSError:
                    pass
            _drop_fresh_lockdir_silent()
            return False
        _TOGGLE_LOCK_TOKEN = token
        try:
            _st = os.stat(_TOGGLE_LOCKDIR)
            _TOGGLE_LOCK_IDENT = (_st.st_dev, _st.st_ino)
        except OSError:
            _TOGGLE_LOCK_IDENT = None
        return True
    finally:
        # r95: гейт живёт до публикации owner (включая её отказ —
        # тогда каталог попытки убирается тоже под гейтом).
        # r96: токен per-acquire — чужой гейт не сверяется и не
        # снимается зависшим потоком.
        # r97: гейт берётся ВСЕМИ попытками (fast-path сериализован
        # тоже) — снимается всегда
        _recovery_gate_release(_gate)


def release_toggle_lock():
    """Снятие toggle-lock — под тем же kernel-мьютексом flock
    (миллисекунды; r98, аудит r97 AUD-R97-02). Семантика снятия —
    в докстринге _release_toggle_lock_under_kflock (r93–r97).
    Недоступность flock → пропуск (best-effort): lockdir остаётся
    владельцу, штатный stale-путь следующий попытки разберёт."""
    _kfd = _kflock_acquire(_TOGGLE_KFLOCK)
    if _kfd is None:
        return
    try:
        _release_toggle_lock_under_kflock()
    finally:
        _kflock_release(_kfd)


def _release_toggle_lock_under_kflock():
    """r93 (аудит r92, KZ92-01/P2-2): снимает только СВОЙ lock —
    token в owner сверяется; чужой (перехваченный новым владельцем
    после нашей «смерти») не трогаем. Снятие атомарно: rename, затем
    удаление переименованного каталога.
    r94 (аудит r93, KZ93-03): owner нечитаем (EIO) при своём token —
    lock наш: убираем best-effort, иначе каталог «зависнет».
    r95 (аудит r94, KZ94-03): при нечитаемом owner удаляем только
    каталог с ТОЙ ЖЕ идентичностью (st_dev, st_ino), что создал этот
    захват: lock мог быть штатно переклеймлен (owner нечитаем +
    mtime>120 с) — чужой новый lock не трогаем, он останется
    штатному stale-реклейму следующего владельца."""
    global _TOGGLE_LOCK_TOKEN, _TOGGLE_LOCK_IDENT
    if _TOGGLE_LOCK_TOKEN is None:
        return
    token = _TOGGLE_LOCK_TOKEN
    ident = _TOGGLE_LOCK_IDENT
    _TOGGLE_LOCK_TOKEN = None
    _TOGGLE_LOCK_IDENT = None
    try:
        with open(os.path.join(
                _TOGGLE_LOCKDIR, 'owner'), 'r') as f:
            cur = f.read().strip()
    except OSError:
        # r95: нечитаем — только при совпадении идентичности каталога.
        # r96 (аудит r95, KZ95-02): идентичность сверяется УЖЕ у
        # переименованного каталога (rename первым) — окно
        # stat→rename не позволяет удалить подменённый чужой lockdir
        if ident is not None:
            _rmdir_lockdir_best_effort(ident=ident)
        return
    if cur != token:
        # lock больше не наш — чужое не удаляем
        return
    _rmdir_lockdir_best_effort(token=token)

def nfqws2_enabled():
    """Обёртка S90 разрешает запуск (ENABLED=yes)."""
    return _init_enabled_yes(NFQWS2_INIT)


def nfqws2_running():
    try:
        res = subprocess.run(
            ['sh', NFQWS2_S51, 'status'],
            capture_output=True, text=True, timeout=15)
        return res.returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


def nfqws2_conflicts():
    """
    Активные протоколы, конфликтные с nfqws2: ENABLED=yes у обёртки
    ИЛИ живой процесс (pidof) — по любой из проверок.
    Возвращает список имён служб (shadowsocks…hysteria).
    """
    out = []
    for svc, init_name, proc in NFQWS2_CONFLICT_SERVICES:
        ipath = (init_name if init_name.startswith('/')
                 else os.path.join(
                     '/opt/etc/init.d', init_name))
        if _init_enabled_yes(ipath):
            out.append(svc)
            continue
        try:
            res = subprocess.run(
                ['pidof', proc],
                capture_output=True, timeout=10)
            if res.returncode == 0:
                out.append(svc)
        except (subprocess.SubprocessError, OSError):
            pass
    return out


_NTCE_CACHE = {'val': None, 'ts': 0.0, 'installed': None}
_NTCE_CACHE_LOCK = threading.Lock()


def _do_nfqws2_intelliqos_check():
    # 1. Основной источник правды: статус службы NTCE через ndmc
    try:
        res = subprocess.run(
            ['ndmc', '-c', 'show ntce status'],
            capture_output=True, text=True, timeout=8)
        out = (res.stdout or '').strip()
        if out:
            # Компонент не установлен в прошивке (no such command: ntce)
            if 'no such command' in out.lower() or '7405600' in out:
                _NTCE_CACHE['installed'] = False
                return False
            # JSON-ответ ndmc
            try:
                data = json.loads(out)
                if isinstance(data, list):
                    data = data[0] if data else {}
                if isinstance(data, dict):
                    inner = data.get('status')
                    if isinstance(inner, list):
                        data = inner[0] if inner and isinstance(inner[0], dict) else {}
                    elif isinstance(inner, dict):
                        data = inner
                    if data.get('status') == 'error':
                        if 'no such command' in str(data.get('message', '')).lower() or '7405600' in str(data.get('code', '')):
                            _NTCE_CACHE['installed'] = False
                        return False
                    _NTCE_CACHE['installed'] = True
                    st = str(data.get('status', data.get('state', ''))).lower()
                    en = data.get('enabled')
                    if st in ('running', 'active', 'enabled') or en is True:
                        return True
                    if st in ('stopped', 'disabled', 'inactive') or en is False:
                        return False
            except Exception:
                # Текстовый формат ndmc
                _NTCE_CACHE['installed'] = True
                if re.search(r'\b(status|state)\s*[:=]\s*(running|active|enabled)\b', out, re.I):
                    return True
                if re.search(r'\b(status|state)\s*[:=]\s*(stopped|disabled|inactive)\b', out, re.I):
                    return False
    except (subprocess.SubprocessError, OSError, FileNotFoundError):
        pass

    # 2. Проверка running-config через ndmc (активная директива ntce)
    try:
        res = subprocess.run(
            ['ndmc', '-c', 'show running-config'],
            capture_output=True, text=True, timeout=8)
        out = (res.stdout or '').strip()
        if out and 'no such command' not in out.lower():
            lines = [line.strip() for line in out.splitlines()]
            if any(line == 'ntce' or line.startswith('ntce ') for line in lines):
                if not any(line == 'no ntce' for line in lines):
                    _NTCE_CACHE['installed'] = True
                    return True
    except (subprocess.SubprocessError, OSError, FileNotFoundError):
        pass

    # 3. Запасная проверка: модуль ядра ntce (только модуль NTCE, без общих qdisc/cls)
    try:
        res = subprocess.run(
            ['lsmod'],
            capture_output=True, text=True, timeout=5)
        if re.search(r'(?im)^(ntce|kndm_ntce|kndmsvc_ntce)\s', res.stdout or ''):
            _NTCE_CACHE['installed'] = True
            return True
    except (subprocess.SubprocessError, OSError, FileNotFoundError):
        pass

    # 4. Каталог proc NTCE
    if os.path.exists('/proc/net/ntce') or os.path.exists('/proc/sys/net/ntce'):
        _NTCE_CACHE['installed'] = True
        return True

    return False


def nfqws2_intelliqos_suspected():
    """
    Проверка активности службы классификации трафика (IntelliQOS/NTCE)
    через прямой API прошивки ndmc с monotonic TTL-кэшем и single-flight lock.
    При отсутствии компонента в прошивке (no such command / 7405600) результат
    кэшируется долговременно (24ч), предотвращая повторные ошибки [E] в syslog.
    Для активной службы TTL составляет 45 секунд.
    """
    now = time.monotonic()
    ttl = 86400 if _NTCE_CACHE.get('installed') is False else 45
    if _NTCE_CACHE['val'] is not None and 0 <= (now - _NTCE_CACHE['ts']) < ttl:
        return _NTCE_CACHE['val']
    with _NTCE_CACHE_LOCK:
        now = time.monotonic()
        ttl = 86400 if _NTCE_CACHE.get('installed') is False else 45
        if _NTCE_CACHE['val'] is not None and 0 <= (now - _NTCE_CACHE['ts']) < ttl:
            return _NTCE_CACHE['val']
        _NTCE_CACHE['installed'] = None
        val = _do_nfqws2_intelliqos_check()
        _NTCE_CACHE['val'] = val
        _NTCE_CACHE['ts'] = time.monotonic()
        return val


def nfqws2_version():
    """Версия установленного пакета (opkg info), без 'x.y.z' → ''."""
    try:
        res = subprocess.run(
            ['opkg', 'info', 'nfqws2-keenetic'],
            capture_output=True, text=True, timeout=20)
        m = re.search(r'(?m)^Version:\s*(\S+)',
                      res.stdout or '')
        return m.group(1) if m else ''
    except (subprocess.SubprocessError, OSError):
        return ''


def nfqws2_mode():
    """Режим из конфига пакета: list / all / auto (или '')."""
    conf = os.path.join(
        config.paths.get('nfqws2_dir', '/opt/etc/nfqws2'),
        'nfqws2.conf')
    try:
        with open(conf, 'r',
                  encoding='utf-8', errors='replace') as f:
            body = f.read()
    except OSError:
        return ''
    m = re.search(
        r'(?m)^NFQWS_EXTRA_ARGS="\$MODE_([A-Z]+)"', body)
    return m.group(1).lower() if m else ''


def nfqws2_status_text():
    """Сводка для бота (r87): состояние, версия, режим, конфликты."""
    lines = ['📦 NFQWS2']
    if not nfqws2_installed():
        lines.append('❌ пакет не установлен (deploy)')
        return '\n'.join(lines)
    v = nfqws2_version()
    lines.append(
        f'Версия: {v}' if v else 'Версия: ?')
    lines.append(
        'Служба: '
        + ('включена (ENABLED=yes)'
           if nfqws2_enabled() else 'выключена'))
    lines.append(
        'Процесс: '
        + ('жив' if nfqws2_running() else 'не запущен'))
    mode = nfqws2_mode()
    if mode:
        ru = {'list': 'селективный (список)',
              'all': 'глобальный (весь трафик)',
              'auto': 'авто (список + автовыявление)'}
        lines.append('Режим: ' + ru.get(mode, mode))
    conf = nfqws2_conflicts()
    if nfqws2_conflicts_required():
        lines.append(
            'Конфликтные протоколы: '
            + (', '.join(conf) if conf else 'нет'))
    elif conf:
        # r89 (П6): в селективе туннели совместимы — не пугаем.
        lines.append(
            'Туннели: активны ('
            + ', '.join(conf)
            + ') — совместимо, селектив')
    lines.append(
        'Intelli QoS: '
        + ('⚠️ Включен — правила могут не работать, '
           'отключите в веб-интерфейсе Keenetic'
           if nfqws2_intelliqos_suspected() else 'Выключен'))
    lines.append(
        f'Настройка (GUI): '
        f'http://{config.routerip}:90')
    return '\n'.join(lines)


def _reapply_netfilter_light():
    """
    r87 (NFQWS2): копия generator._reapply_netfilter без импорта
    Flask-стека (правило C9 — бот не поднимает веб-модуль).
    Хук снимает правила протоколов с ENABLED=no и переприменяет
    правила включённых.
    r93 (аудит r92, P2-4): возвращает True, когда обе таблицы
    применены (хука нет — тоже True: нечего переприменять); False —
    хотя бы одна вернула ошибку/не запустилась. Вызывающие показывают
    «⚠️ не переприменились» вместо молчаливого «✅».
    """
    import subprocess
    hook = '/opt/etc/ndm/netfilter.d/100-redirect.sh'
    if not os.path.exists(hook):
        return True
    ok = True
    for table in ('nat', 'mangle'):
        # r93 (аудит r92, А): долгий хук — продлить lock.
        _toggle_lock_heartbeat()
        env = dict(os.environ, type='iptable', table=table)
        try:
            r = subprocess.run([hook], env=env,
                               capture_output=True, timeout=60)
            if r.returncode != 0:
                ok = False
        except (subprocess.SubprocessError, OSError):
            ok = False
    return ok


def _rewrite_init_enabled(init_path, value):
    """
    r87 (NFQWS2): атомарно переписывает ENABLED= в init-скрипте
    проекта (формат rc.func: ENABLED="Yes"/"No"). Возвращает True
    при успехе.
    """
    import re
    import tempfile
    try:
        with open(init_path, encoding='utf-8') as f:
            lines = f.readlines()
    except OSError:
        return False
    done = False
    for i, ln in enumerate(lines):
        if re.match(r'^\s*ENABLED=', ln):
            # Формат обёрток проекта: ENABLED=yes/no, без кавычек
            # (shell-потребители: grep '^ENABLED=yes' в
            # update_protocols.sh nfw2_is_on и пр.).
            lines[i] = 'ENABLED=%s\n' % (
                'yes' if value else 'no')
            done = True
            break
    if not done:
        return False
    try:
        d = os.path.dirname(init_path)
        fd, tmp = tempfile.mkstemp(dir=d)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        os.chmod(tmp, 0o755)
        os.replace(tmp, init_path)
    except OSError:
        return False
    return True


def nfqws2_update_excludes_quiet():
    """
    r89 (NFQWS2, П3): обновление управляемых exclude-блоков пакета
    (VPS туннелей + DNS-endpoint'ы из hosts-пинов проекта) —
    /opt/bin/nfqws2_update_excludes.sh. Тихо: нет пакета/скрипта —
    no-op. Возвращает True при успехе/пропуске.
    r91 (аудит r90, В): returncode скрипта проверяется — прежде
    любой «нормальный» выход считался успехом, и rc=1 (невозможная
    запись, повреждённый managed-блок) оставался незамеченным.
    """
    import subprocess
    script = '/opt/bin/nfqws2_update_excludes.sh'
    if not nfqws2_installed() or not os.path.isfile(script):
        return True
    try:
        r = subprocess.run(
            ['sh', script],
            capture_output=True, timeout=60)
    except (subprocess.SubprocessError, OSError):
        return False
    if r.returncode != 0:
        log_error('nfqws2_update_excludes: rc='
                  + str(r.returncode))
        return False
    return True

def nfqws2_conflicts_required():
    """
    r89 (NFQWS2, П1): блокирующая проверка конфликтов нужна ТОЛЬКО в
    Глобал/Авто — там правила nfqws2 задевают собственные соединения
    роутера (VPS туннелей, DoT/DoH-апстримы). В Селективе механизмы
    не пересекаются: туннели матчатся в mangle PREROUTING (TPROXY по
    ipset), nfqws2 — в POSTROUTING по hostlist; домены туннелей до
    nfqws2 не доходят (решение владельца 02.11.2026).
    """
    return nfqws2_mode() in ('all', 'auto')


def _nfw2_fail_with_stopped(stopped, base_msg):
    """r93 (аудит r92, P2-3): отказный выход force-операции NFQWS2 —
    правила уже остановленных служб снимаются сразу (прежде ранний
    return оставлял их редиректы в nat/mangle до следующего события
    NDM: трафик списков остановленной службы уходил в мёртвый порт),
    а сообщение честно перечисляет остановленных.
    r94 (аудит r93, KZ93-02/KZ93-04): результат переприменения
    отражается — при неудаче хука НЕ заявляется «правила сняты»
    (прежде утверждение печаталось при любом исходе); никого не
    остановили + неудача → стандартное предупреждение."""
    reapply_ok = _reapply_netfilter_light()
    msg = base_msg
    if stopped:
        if reapply_ok:
            msg += ("\nВыключены: " + ', '.join(stopped)
                    + " — правила их перехвата сняты.")
        else:
            msg += ("\nВыключены: " + ', '.join(stopped)
                    + " — ⚠️ правила перехвата не переприменились "
                    "(могут остаться до следующего события NDM; "
                    "подробности в логе).")
    elif not reapply_ok:
        msg += ("\n⚠️ Правила перехвата не переприменились — "
                "перепроверьте состояние протоколов (подробности "
                "в логе).")
    return (False, msg)


def nfqws2_set_enabled(on, also_disable_conflicts=False):
    """
    r87 (NFQWS2): включает/выключает nfqws2 (обёртка S90) и, по
    запросу, конфликтные туннели. Возвращает (ok, сообщение).
    Выключение конфликтных: ENABLED=No + <init> stop + переприменение
    правил перехвата (снимает их редиректы).
    r91 (аудит r90, А/Г): честность результата — returncode init
    проверяется, при отказе прежний ENABLED= восстанавливается и
    возвращается ошибка (прежде любой отказ маскировался «✅»);
    force-цепочка останавливает и живые процессы при ENABLED=no
    (единый детектор с nfqws2_conflicts), подтверждает исчезновение
    процесса и прерывается на первом неподавленном конфликте —
    NFQWS2 не включается при живом туннеле.
    r93 (аудит r92, P2-3/P2-4): отказные выходы снимают правила уже
    остановленных служб и перечисляют их (автоперезапуск не делаем —
    интент force «выключить конфликтные» сохраняется); результат
    переприменения правил отражается в сообщении, а не глотается.
    """
    if not nfqws2_installed():
        return (False,
                "❌ nfqws2 не установлен (нет "
                + NFQWS2_INIT + ").")
    stopped = []
    if on and also_disable_conflicts:
        for name, init_path, proc in NFQWS2_CONFLICT_SERVICES:
            if _init_enabled_yes(init_path) or _proc_alive(proc):
                was_enabled = _init_enabled_yes(init_path)
                if was_enabled and not _rewrite_init_enabled(
                        init_path, False):
                    return _nfw2_fail_with_stopped(
                        stopped, "❌ Не удалось "
                        "выключить " + name + " ("
                        + init_path + ").")
                r = _run_init_cmd(init_path, 'stop')
                if (r is None or r.returncode != 0
                        or _proc_alive(proc)):
                    if was_enabled:
                        _rewrite_init_enabled(init_path, True)
                    return _nfw2_fail_with_stopped(
                        stopped,
                        "❌ Не удалось остановить " + name
                        + " — NFQWS2 не включён (процесс "
                        "жив или init вернул ошибку).")
                stopped.append(name)
    wrapper = NFQWS2_INIT
    if not _rewrite_init_enabled(wrapper, on):
        return _nfw2_fail_with_stopped(
            stopped, "❌ Не удалось изменить "
            + wrapper + ".")
    excludes_ok = True
    if on:
        # r89 (П3): перед стартом — свежие exclude-блоки (VPS/DNS).
        excludes_ok = nfqws2_update_excludes_quiet()
    r = _run_init_cmd(wrapper, 'start' if on else 'stop')
    if r is None or r.returncode != 0:
        # r91: откат ENABLED — состояние на диске прежним.
        _rewrite_init_enabled(wrapper, not on)
        return _nfw2_fail_with_stopped(
            stopped, "❌ Не удалось "
            + ("запустить" if on else "остановить")
            + " nfqws2"
            + (" (init не выполнился)."
               if r is None else
               " (init rc=" + str(r.returncode) + ")."))
    reapply_ok = _reapply_netfilter_light()
    if on:
        msg = ("✅ nfqws2 включен."
               + (("\nВыключены: " + ", ".join(stopped)
                   + ".") if stopped else ""))
        if not excludes_ok:
            msg += ("\n⚠️ Не удалось обновить excludes nfqws2 "
                    "(подробности в логе).")
    else:
        msg = "✅ nfqws2 выключен."
    if not reapply_ok:
        msg += ("\n⚠️ Правила перехвата не переприменились — "
                "перепроверьте состояние протоколов (переприменятся "
                "следующим событием NDM; подробности в логе).")
    return (True, msg)

# ═══ r90 (решение владельца 02.11.2026): Вкл/Выкл протоколов в боте ═══
# Порядок — как в «Ключи и мосты» (+ NFQWS2 последним).
PROTOCOL_ORDER = ('tor', 'vless', 'trojan',
                  'shadowsocks', 'hysteria', 'nfqws2')
PROTOCOL_TITLES = {
    'tor': 'Tor', 'vless': 'Vless', 'trojan': 'Trojan',
    'shadowsocks': 'Shadowsocks', 'hysteria': 'Hysteria',
    'nfqws2': 'NFQWS2'}
# (init-скрипт, процесс) — те же пары, что в NFQWS2_CONFLICT_SERVICES.
_PROTOCOL_INFO = {
    'shadowsocks': ('S65shadowsocks', 'ss-redir'),
    'trojan': ('S22trojan', 'trojan'),
    'vless': ('S24xray', 'xray'),
    'tor': ('S35tor', 'tor'),
    'hysteria': ('S57hysteria', 'hysteria')}
# имя → ключ пути конфига (проверка «ключ задан»).
_PROTOCOL_CFG_KEY = {
    'vless': 'vless_config', 'trojan': 'trojan_config',
    'shadowsocks': 'shadowsocks_config',
    'hysteria': 'hysteria_config'}


def _protocol_init_path(init_name):
    return (init_name if init_name.startswith('/')
            else os.path.join('/opt/etc/init.d', init_name))


def protocol_enabled(name):
    """ENABLED=yes у обёртки протокола (туннели)."""
    info = _PROTOCOL_INFO.get(name)
    if not info:
        return False
    return _init_enabled_yes(_protocol_init_path(info[0]))


def active_tunnels():
    """Список включённых туннелей (без NFQWS2)."""
    return [n for n in PROTOCOL_ORDER
            if n != 'nfqws2' and protocol_enabled(n)]


def protocol_configured(name):
    """Ключ/мост задан — иначе включать протокол бессмысленно.
    Tor — наличие активных мостов; ss/vl/tr/hy — конфиг без
    плейсхолдеров (та же проверка, что в «Ключи и мосты»);
    NFQWS2 — пакет установлен."""
    if name == 'nfqws2':
        return nfqws2_installed()
    if name == 'tor':
        p = config.paths.get('tor_config')
        return bool(p) and tor_has_bridges(p)
    key = _PROTOCOL_CFG_KEY.get(name)
    if not key:
        return False
    p = config.paths.get(key)
    if not p or not os.path.isfile(p):
        return False
    return not config_has_placeholders(
        p, require_auth=(key == 'hysteria_config'))


def nfqws2_blocks_tunnels():
    """r90 (зеркальный конфликт П1): включение туннеля при включённом
    NFQWS2 в Глобал/Авто — правила nfqws2 затронут соединения роутера
    к VPS включаемого туннеля и DNS-апстримы."""
    return nfqws2_enabled() and nfqws2_mode() in ('all', 'auto')


def protocol_set_enabled(name, on):
    """Вкл/выкл туннеля по образцу nfqws2_set_enabled: ENABLED=,
    start/stop, переприменение правил перехвата. Возвращает
    (ok, сообщение); после старта — честная проверка процесса.
    r91 (аудит r90, А): returncode init проверяется. Отказ stop —
    ошибка с откатом ENABLED=yes (прежде молчаливый «успех» мог
    оставить «ENABLED=no + живой процесс», которого детектор
    конфликтов панели не видел); отказ start — честные
    предупреждения (rc init + pidof-статус), включение остаётся:
    ключ/VPS лечится пользователем, состояние видно на экране.
    r93 (аудит r92, P2-4): результат переприменения правил
    отражается в сообщении, а не глотается."""
    import subprocess
    info = _PROTOCOL_INFO.get(name)
    if not info:
        return (False, "❌ Неизвестный протокол: " + str(name))
    init_path = _protocol_init_path(info[0])
    if not os.path.isfile(init_path):
        return (False, "❌ init-скрипт не найден: " + init_path)
    if not _rewrite_init_enabled(init_path, on):
        return (False, "❌ Не удалось изменить " + init_path + ".")
    title = PROTOCOL_TITLES.get(name, name)
    r = _run_init_cmd(init_path, 'start' if on else 'stop')
    if not on:
        if (r is None or r.returncode != 0
                or _proc_alive(info[1])):
            # r91: остановка не подтверждена — состояние не меняем.
            _rewrite_init_enabled(init_path, True)
            return (False,
                    "❌ Не удалось остановить " + title
                    + " (процесс жив или init вернул ошибку) — "
                    "состояние не изменено.")
        reapply_ok = _reapply_netfilter_light()
        msg = "⚠️ " + title + " выключен."
        if not reapply_ok:
            msg += ("\n⚠️ Правила перехвата не переприменились — "
                    "перепроверьте состояние протоколов "
                    "(подробности в логе).")
        return (True, msg)
    reapply_ok = _reapply_netfilter_light()
    msg = "✅ " + title + " включен."
    if r is None:
        msg += "\n⚠️ Не удалось выполнить init-скрипт."
    elif r.returncode != 0:
        msg += ("\n⚠️ init-скрипт вернул ошибку (rc="
                + str(r.returncode) + ").")
    try:
        pr = subprocess.run(
            ['pidof', info[1]],
            capture_output=True, timeout=10)
        if pr.returncode != 0:
            msg += ("\n⚠️ Процесс не запущен — проверьте "
                    "ключ/VPS (статус: " + init_path
                    + " status).")
    except (subprocess.SubprocessError, OSError):
        pass
    if not reapply_ok:
        msg += ("\n⚠️ Правила перехвата не переприменились — "
                "перепроверьте состояние протоколов "
                "(подробности в логе).")
    return (True, msg)

def nfqws2_user_list_preview(limit=25):
    """
    r87 (NFQWS2): первые limit строк user.list + счётчик. Для
    кнопки «📋 Домены» бота.
    """
    import bot_config as config
    path = config.paths.get(
        'nfqws2_user_list',
        '/opt/etc/nfqws2/lists/user.list')
    try:
        with open(path, encoding='utf-8',
                  errors='replace') as f:
            entries = [ln.strip() for ln in f
                       if ln.strip()
                       and not ln.lstrip().startswith('#')]
    except OSError:
        return (None,
                "❌ Файл списка не найден: " + path)
    total = len(entries)
    shown = entries[:limit]
    text = ("📋 Домены nfqws2 ("
            + str(total) + ")\nПуть: " + path
            + "\n\n")
    text += "\n".join(shown)
    if total > limit:
        text += ("\n… и ещё "
                 + str(total - limit))
    return (shown, text)


def nfqws2_set_mode(mode, force=False):
    """
    r87: переключение режима (list/all/auto), r89 (П2): защита при
    переходе на Глобал/Авто — если nfqws2 включен и есть активные
    туннели, без force возвращается блокирующее сообщение (панель/бот
    показывают подтверждение с автовыключением); force — выключить
    конфликтные туннели и переключить.
    r91 (аудит r90, А): честность применения — результаты выключения
    конфликтов и рестарта проверяются; при отказе строка режима в
    nfqws2.conf атомарно восстанавливается и возвращается ошибка
    (прежде режим записывался до применения, и отказ оставлял конфиг
    и runtime в разных состояниях при «✅» в ответе).
    r93 (аудит r92, P2-3/P3-5): отказные выходы снимают правила уже
    остановленных служб; откат режима возвращает статус — при неудаче
    сообщение НЕ заявляет восстановления, а называет фактически
    прочитанный режим; успех с автовыключением тоже снимает правила
    остановленных и отражает результат переприменения.
    """
    import tempfile
    mode = str(mode).lower()
    if mode not in ('list', 'all', 'auto'):
        return (False,
                "❌ Неизвестный режим: " + mode)
    if not nfqws2_installed():
        return (False, "❌ nfqws2 не установлен.")
    if mode in ('all', 'auto') and not force \
            and nfqws2_enabled():
        conflicts = nfqws2_conflicts()
        if conflicts:
            return (False,
                    "🚫 Глобал/Авто затронет соединения "
                    "активных туннелей ("
                    + ', '.join(conflicts)
                    + ") и DNS-апстримы. Выключите их "
                    "или используйте автовыключение.")
    conf = os.path.join(
        config.paths.get('nfqws2_dir', '/opt/etc/nfqws2'),
        'nfqws2.conf')
    try:
        with open(conf, 'r', encoding='utf-8',
                  errors='replace') as f:
            body = f.read()
    except OSError as e:
        return (False,
                "❌ nfqws2.conf не читается: " + str(e))
    new_line = 'NFQWS_EXTRA_ARGS="$MODE_%s"' % mode.upper()
    if not re.search(
            r'(?m)^NFQWS_EXTRA_ARGS="\$MODE_[A-Z]+"',
            body):
        return (False,
                "❌ В nfqws2.conf не найдена строка "
                "NFQWS_EXTRA_ARGS (конфиг изменён?)")
    old_body = body
    new_body = re.sub(
        r'(?m)^NFQWS_EXTRA_ARGS="\$MODE_[A-Z]+"',
        new_line, body, count=1)
    try:
        d = os.path.dirname(conf)
        fd, tmp = tempfile.mkstemp(dir=d)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(new_body)
        os.chmod(tmp, 0o644)
        os.replace(tmp, conf)
    except OSError as e:
        return (False,
                "❌ Запись nfqws2.conf: " + str(e))

    def _restore_conf():
        # r91: откат строки режима при отказе применения.
        # r93 (аудит r92, P3-5): статус отката возвращается
        # вызывающему (прежде глотался — «восстановлен» печаталось и
        # при неудаче); временный файл при отказе удаляется.
        _rc_tmp = None
        try:
            fd, _rc_tmp = tempfile.mkstemp(dir=d)
            with os.fdopen(fd, 'w',
                           encoding='utf-8') as f:
                f.write(old_body)
            os.chmod(_rc_tmp, 0o644)
            os.replace(_rc_tmp, conf)
            return True
        except OSError:
            if _rc_tmp is not None:
                try:
                    os.unlink(_rc_tmp)
                except OSError:
                    pass
            return False

    def _cur_mode_str():
        # r93: фактически прочитанный режим для честного сообщения.
        try:
            with open(conf, 'r', encoding='utf-8',
                      errors='replace') as f:
                m = re.search(
                    r'(?m)^NFQWS_EXTRA_ARGS="\$MODE_([A-Z]+)"',
                    f.read())
            return m.group(1).lower() if m else '?'
        except OSError:
            return '?'

    stopped = []
    if mode in ('all', 'auto') and force and nfqws2_enabled():
        for name, init_path, proc in NFQWS2_CONFLICT_SERVICES:
            if _init_enabled_yes(init_path) or _proc_alive(proc):
                was_enabled = _init_enabled_yes(init_path)
                if was_enabled and not _rewrite_init_enabled(
                        init_path, False):
                    _rc_ok = _restore_conf()
                    return _nfw2_fail_with_stopped(
                        stopped, "❌ Не удалось "
                        "выключить " + name + " ("
                        + init_path
                        + ") — режим не переключён"
                        + (" (конфиг восстановлен)."
                           if _rc_ok else
                           " (откат режима НЕ удался, текущий: "
                           + _cur_mode_str() + ")."))
                r = _run_init_cmd(init_path, 'stop')
                if (r is None or r.returncode != 0
                        or _proc_alive(proc)):
                    if was_enabled:
                        _rewrite_init_enabled(init_path, True)
                    _rc_ok = _restore_conf()
                    return _nfw2_fail_with_stopped(
                        stopped,
                        "❌ Не удалось остановить " + name
                        + " — режим не переключён"
                        + (" (конфиг восстановлен)."
                           if _rc_ok else
                           " (откат режима НЕ удался, текущий: "
                           + _cur_mode_str() + ")."))
                stopped.append(name)
    # r89 (П3): свежие exclude-блоки перед применением режима.
    excludes_ok = nfqws2_update_excludes_quiet()
    if nfqws2_enabled():
        r = _run_init_cmd(NFQWS2_INIT, 'restart')
        if r is None or r.returncode != 0:
            _rc_ok = _restore_conf()
            return _nfw2_fail_with_stopped(
                stopped,
                "❌ Не удалось перезапустить nfqws2 после "
                "смены режима — "
                + ("прежний режим восстановлен."
                   if _rc_ok else
                   "откат режима НЕ удался, текущий режим: "
                   + _cur_mode_str() + ".")
                + " Статус: " + NFQWS2_S51 + " status.")
    titles = {
        'list': 'селектив (user.list)',
        'all': 'глобал (кроме exclude.list)',
        'auto': 'авто (автодетект)'}
    msg = "✅ Режим nfqws2: " + titles[mode]
    if stopped:
        msg += ("\nВыключены: " + ', '.join(stopped) + ".")
        # r93 (P2-3): правила остановленных снимаются и при успехе.
        if not _reapply_netfilter_light():
            msg += ("\n⚠️ Правила перехвата не переприменились — "
                    "перепроверьте состояние протоколов "
                    "(подробности в логе).")
    if not excludes_ok:
        msg += ("\n⚠️ Не удалось обновить excludes nfqws2 "
                "(подробности в логе).")
    return (True, msg)