#!/opt/bin/python3
import os
import sys

# K60-05 (аудит-35): явный минимум интерпретатора. Проект использует
# subprocess.run(capture_output=...) — Python 3.7+; Flask 3.0.x —
# 3.8+ (Flask 3.1+ требует Python 3.9+ — pip резолвит по
# Requires-Python, spec Flask>=3,<4 не меняется);
# прежде на старом интерпретаторе бот падал AttributeError/ImportError
# без объяснения. Чек до тяжёлых импортов: сообщение печатается в
# stderr и журнал даже если сами импорты не смогут выполниться.
if sys.version_info < (3, 8):
    _m = ('KeenZOO: требуется Python 3.8+ (найден '
          + sys.version.split()[0] + '). Обновите python3 в Entware')
    try:
        with open('/opt/var/log/keenzoo_python.err', 'a') as _f:
            _f.write(_m + '\n')
    except OSError:
        pass
    print(_m, file=sys.stderr)
    sys.exit(1)

import signal
import time
import logging
import telebot
import subprocess
import requests.exceptions
from handlers import setup_handlers
from utils import log_error, clean_log, check_restart, signal_handler
import bot_config as config

if not config.token or config.token.strip() == "" or ":" not in config.token or len(config.token) < 10:
    log_error("Ошибка: Токен не указан или имеет неверный формат в bot_config.py")
    sys.exit(1)
    
current_pid = str(os.getpid())
# Проверка «бот уже запущен» не должна мешать старту: если pgrep
# отсутствует или завис, считаем, что других экземпляров нет.
try:
    # Шаблон должен покрывать все формы запуска, а не только штатный
    # "python3 /opt/etc/bot/main.py": с флагом "-u" и с версионным
    # интерпретатором (/opt/bin/python3.11) прежний строгий шаблон
    # не совпадал, и второй экземпляр при ручном запуске проходил.
    pids_output = subprocess.run(
        ['pgrep', '-f', f'python.* {config.paths["bot_path"]}'],
        capture_output=True, text=True, timeout=30).stdout.strip()
except (subprocess.SubprocessError, OSError) as e:
    log_error(f"[!] pgrep недоступен: {e}")
    pids_output = ""
running_pids = [pid for pid in pids_output.splitlines() if pid and pid != current_pid]
if running_pids:
    log_error(f"Бот уже запущен с PID: {', '.join(running_pids)}")
    sys.exit(1)

if not config.allowed_user_ids:
    log_error(
        "Ошибка: не задан ни один allowed_user_ids в bot_config.py — "
        "бот не запущен, иначе доступ был бы у любого пользователя")
    sys.exit(1)


class _InfinityPollingLogFilter(logging.Filter):
    """Оставлять не чаще одной Infinity-polling ошибки за интервал.

    Сам TeleBot восстанавливает polling и повторяет запросы. Менять этот
    механизм ради журнала нельзя: ограничиваем только одинаковый ERROR-поток,
    а в следующей пропущенной строке показываем число подавленных повторов.
    monotonic не ломается при NTP-коррекции часов во время загрузки роутера.
    """

    def __init__(self, interval):
        super().__init__()
        self.interval = interval
        self.last_written = None
        self.suppressed = 0

    def filter(self, record):
        try:
            message = record.getMessage()
        except Exception:
            return True
        if not message.startswith("Infinity polling exception:"):
            return True

        now = time.monotonic()
        if (self.last_written is None
                or now - self.last_written >= self.interval):
            if self.suppressed:
                elapsed = int(now - self.last_written)
                record.msg = (
                    f"{message} [подавлено повторов: {self.suppressed} "
                    f"за {elapsed} с]")
                record.args = ()
            self.last_written = now
            self.suppressed = 0
            return True

        self.suppressed += 1
        return False


def _install_polling_log_filter():
    try:
        interval = int(getattr(
            config, 'TELEBOT_LOG_THROTTLE_SECONDS', 600))
    except (TypeError, ValueError):
        interval = 600
    # Ошибка в конфиге не должна случайно отключить ограничитель.
    interval = max(60, interval)
    telebot_logger = getattr(
        telebot, 'logger', logging.getLogger('TeleBot'))
    telebot_logger.addFilter(
        _InfinityPollingLogFilter(interval))


_install_polling_log_filter()
bot = telebot.TeleBot(config.token)
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

if __name__ == "__main__":
    clean_log(config.paths["error_log"])

    # Запуск бота и обработчиков
    setup_handlers(bot)
    check_restart(bot)

    restart_count = 0
    transient_streak = 0
    while restart_count < config.MAX_RESTARTS:
        try:
            bot.infinity_polling(
                timeout=30,
                long_polling_timeout=30)
            # Штатный выход из polling (например, по сигналу) — не ошибка.
            break
        except (telebot.apihelper.ApiException,
                requests.exceptions.RequestException) as err:
            # Сетевые сбои (нет DNS, нет WAN, туннель не поднялся)
            # НЕ считаются фатальными: при старте роутера резолвер
            # часто ещё не готов, и прежняя логика исчерпывала
            # MAX_RESTARTS за пару минут, после чего бот выходил
            # навсегда — до ручного перезапуска.
            text = str(err)
            transient = (
                'resolve' in text
                or 'Temporary failure' in text
                or 'Max retries' in text
                or 'Connection' in text
                or 'timed out' in text)
            log_error(
                f"Ошибка соединения или Telegram API: {text}")
            if transient:
                # P11 (аудит rev3): бесконечное восстановление
                # сохраняем (старт без WAN — норма роутера), но с
                # ограниченным экспоненциальным backoff и логом
                # о серии — иначе часовой отказ API держал бы цикл
                # на минимальной задержке вечно.
                transient_streak += 1
                delay = min(
                    max(config.RESTART_DELAY, 30)
                    * (2 ** min(transient_streak - 1, 5)),
                    900)
                if transient_streak % 10 == 0:
                    log_error(
                        "transient-серия: попытка "
                        f"{transient_streak}, пауза {delay} с")
                time.sleep(delay)
                continue
            transient_streak = 0
            restart_count += 1
            time.sleep(config.RESTART_DELAY)
        except SystemExit:
            raise
        except Exception as err:
            log_error(f"Неизвестная ошибка: {str(err)}")
            restart_count += 1
            time.sleep(config.RESTART_DELAY)
    else:
        log_error(
            "Бот остановлен после достижения максимального "
            "количества попыток перезапуска")
        sys.exit(1)
