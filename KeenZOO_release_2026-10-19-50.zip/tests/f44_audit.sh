#!/bin/bash
# f44_audit.sh — приёмочный стенд правок R44 (аудит-14):
#  A. f42_check в раскладке БЕЗ git (как у пользователя из ZIP) → 14/0
#  B. whitelist кэша /tmp/keenzoo_iptables_bin: 9 путей во всех 6 читателях
#     + поведенческий тест generator._iptables_bin с отравленным кэшем
#  C. kz_resolve_binaries: || true в обеих копиях + MD5-твин common↔deploy
#  D. endpoint-списки: мёртвое dns_endpoint_hosts удалено; NDM-состав ==
#     DNS-состав; tunnel_doh_hosts == DNS_ENDPOINT_HOSTS (состав+порядок)
#  E. WAN-up гвард ожидания unblock_update: моки живой/мёртвый/пустой pid
#  F. оборванные комментарии R44-6 закрыты (7 мест, по r39-оригиналам)
set -u
K=${1:-/home/user/KeenZOO}
D=$(cd "$(dirname "$0")" && pwd)
F=/tmp/f44chk
rm -rf "$F"; mkdir -p "$F"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. f42_check без git (раскладка релиза, R44-1) ═══"
rm -rf "$F/tree"; mkdir -p "$F/tree"
( cd "$K" && tar cf - opt ) | ( cd "$F/tree" && tar xf - )
OUT=$(bash "$D/f42_check.sh" "$F/tree" 2>&1)
printf '%s\n' "$OUT" | grep -q 'F42 ИТОГ: PASS=14 FAIL=0' \
    && ok "A1: f42 в gitless-дереве — 14/0" \
    || bad "A1: f42 в gitless-дереве: $(printf '%s\n' "$OUT" | tail -1)"

echo "═══ B. Whitelist кэша iptables (R44-2) ═══"
NINE="/usr/sbin/iptables /sbin/iptables /bin/iptables /usr/bin/iptables
/usr/local/sbin/iptables /tmp/sbin/iptables /tmp/usr/sbin/iptables
/opt/sbin/iptables /opt/bin/iptables"
i=1
for f in "$K/opt/etc/bot/generator.py" "$K/opt/bin/unblock_update.sh" \
         "$K/opt/bin/common.sh" "$K/opt/bin/test_udp_tunnels.sh" \
         "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" "$K/opt/bin/deploy_bypass.sh"; do
    miss=""
    for p in $NINE; do grep -qF "$p" "$f" || miss="$miss $p"; done
    if [ -z "$miss" ]; then ok "B$i: 9 путей whitelist — $(basename "$f")";
    else bad "B$i: $(basename "$f") нет:$miss"; fi
    i=$((i+1))
done
grep -q 'cached in _IPT_CACHE_PATHS and os.access' "$K/opt/etc/bot/generator.py" \
    && ok "B7: generator._iptables_bin сверяет кэш с _IPT_CACHE_PATHS" \
    || bad "B7: generator не использует whitelist для кэша"

# B8: отравленный кэш не должен приниматься (функция исполняется изолированно).
# Гигиена хоста: root-остаток кэша от sudo-фаз f16 не даёт записать poison —
# снимаем его (на обычном хосте файл либо отсутствует, либо принадлежит юзеру).
if [ -e /tmp/keenzoo_iptables_bin ] && [ ! -w /tmp/keenzoo_iptables_bin ]; then
    sudo -n rm -f /tmp/keenzoo_iptables_bin 2>/dev/null || true
fi
if [ -e /tmp/keenzoo_iptables_bin ] && [ ! -w /tmp/keenzoo_iptables_bin ]; then
    bad "B8: /tmp/keenzoo_iptables_bin недоступен для записи (root-остаток) — удалите и повторите"
else
SAVED=""
[ -e /tmp/keenzoo_iptables_bin ] && SAVED=$(cat /tmp/keenzoo_iptables_bin)
python3 - "$K" <<'PYB8' && ok "B8: _iptables_bin игнорирует путь вне whitelist" || bad "B8: отравленный кэш принят"
import ast, io, os, shutil, sys
K = sys.argv[1]
src = io.open(os.path.join(K, 'opt/etc/bot/generator.py'), encoding='utf-8').read()
segs = []
for n in ast.parse(src).body:
    if isinstance(n, ast.Assign) and any(
            getattr(t, 'id', None) == '_IPT_CACHE_PATHS' for t in n.targets):
        segs.append(ast.get_source_segment(src, n))
    if isinstance(n, ast.FunctionDef) and n.name == '_iptables_bin':
        segs.append(ast.get_source_segment(src, n))
assert len(segs) == 2, f'извлечено {len(segs)} фрагментов из 2'
ns = {'os': os, 'shutil': shutil}
exec('\n\n'.join(segs), ns)
open('/tmp/keenzoo_iptables_bin', 'w').write('/tmp/evil_kz_ipt.sh\n')
open('/tmp/evil_kz_ipt.sh', 'w').write('#!/bin/sh\necho PWNED\n')
os.chmod('/tmp/evil_kz_ipt.sh', 0o755)
try:
    res = ns['_iptables_bin']()
finally:
    os.remove('/tmp/evil_kz_ipt.sh')
    os.remove('/tmp/keenzoo_iptables_bin')
assert res != '/tmp/evil_kz_ipt.sh', f'принят отравленный путь: {res}'
print('       выбран:', res)
PYB8
if [ -n "$SAVED" ]; then printf '%s\n' "$SAVED" > /tmp/keenzoo_iptables_bin; fi
fi

echo "═══ C. kz_resolve_binaries (R44-3) ═══"
for f in "$K/opt/bin/common.sh" "$K/opt/bin/deploy_bypass.sh"; do
    grep -qF '_krb_endian="$(kz_detect_endian || true)"' "$f" \
        && ok "C: || true — $(basename "$f")" \
        || bad "C: нет || true в $(basename "$f")"
done
M1=$(sed -n '/^kz_resolve_binaries()/,/^}/p' "$K/opt/bin/common.sh" | md5sum | cut -d' ' -f1)
M2=$(sed -n '/^kz_resolve_binaries()/,/^}/p' "$K/opt/bin/deploy_bypass.sh" | md5sum | cut -d' ' -f1)
[ -n "$M1" ] && [ "$M1" = "$M2" ] \
    && ok "C3: копии kz_resolve_binaries идентичны (${M1:0:8})" \
    || bad "C3: копии kz_resolve_binaries разошлись"

echo "═══ D. Endpoint-списки (R44-4) ═══"
if grep -rn 'dns_endpoint_hosts' "$K/opt" --include='*.py' --include='*.sh' \
        | grep -vE ':[[:space:]]*#' | grep -q .; then
    bad "D1: живые вхождения dns_endpoint_hosts"
else
    ok "D1: dns_endpoint_hosts удалён (остался только надгробный комментарий)"
fi
python3 - "$K" <<'PYD' && ok "D2: NDM-состав == DNS-состав (5 хостов)" || bad "D2: составы endpoint-списков разошлись"
import io, re, sys
K = sys.argv[1]
com = io.open(K + '/opt/bin/common.sh', encoding='utf-8').read()
m = re.search(r'DNS_ENDPOINT_HOSTS="\$\{DNS_ENDPOINT_HOSTS:-\$\{TUNNEL_DOH_HOSTS:-([^}]*)\}\}"', com)
assert m, 'default DNS_ENDPOINT_HOSTS не найден'
dns = m.group(1).split()
nd = io.open(K + '/opt/bin/unblock_dnsmasq.sh', encoding='utf-8').read()
n = re.search(r'NDM_ENDPOINT_HOSTS="\$\{NDM_ENDPOINT_HOSTS:-([^}]*)\}"', nd)
assert n, 'default NDM_ENDPOINT_HOSTS не найден'
ndm = n.group(1).split()
assert sorted(dns) == sorted(ndm), f'составы: {dns} vs {ndm}'
assert len(set(dns)) == len(dns) == 5, dns
print(f'       DNS-first={dns[0]}, NDM-first={ndm[0]} (порядок закреплён комментарием)')
PYD
python3 - "$K" <<'PYD3' && ok "D3: tunnel_doh_hosts == DNS_ENDPOINT_HOSTS (состав+порядок)" || bad "D3: зеркало R42-8 разошлось"
import io, re, sys
K = sys.argv[1]
com = io.open(K + '/opt/bin/common.sh', encoding='utf-8').read()
m = re.search(r'DNS_ENDPOINT_HOSTS="\$\{DNS_ENDPOINT_HOSTS:-\$\{TUNNEL_DOH_HOSTS:-([^}]*)\}\}"', com)
dns = m.group(1).split()
bot = io.open(K + '/opt/etc/bot/bot_config.py', encoding='utf-8').read()
doh = re.findall(r"'([^']+)'", re.search(r'tunnel_doh_hosts = \[(.*?)\]', bot, re.S).group(1))
assert doh == dns, f'{doh} vs {dns}'
PYD3

echo "═══ E. WAN-up гвард ожидания (R44-5) ═══"
awk '/^    if \[ -d \/tmp\/unblock_update\.lockdir/ {f=1} f{print} f&&/^    fi$/{exit}' \
    "$K/opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh" > "$F/guard.s"
grep -q '_uvw_waits' "$F/guard.s" \
    && ok "E0: гвард извлечён из WAN-up-ветки" || bad "E0: гвард не извлёкся"
SLEEPER=$(mktemp "$F/sleeper.XXXX"); ( sleep 300 ) & SPID=$!
mkdir -p "$F/mock.lockdir"; echo "$SPID" > "$F/mock.lockdir/pid"
sed -i "s|/tmp/unblock_update.lockdir|$F/mock.lockdir|g" "$F/guard.s"
( TAG=f44test . "$F/guard.s" ) & GPID=$!
sleep 3
if kill -0 $GPID 2>/dev/null; then ok "E1: живой цикл — гвард ждёт"; else bad "E1: гвард не ждал живой замок"; fi
kill "$SPID" 2>/dev/null; wait "$SPID" 2>/dev/null; wait $GPID 2>/dev/null
echo "999999" > "$F/mock.lockdir/pid"
START=$(date +%s); ( TAG=f44test . "$F/guard.s" ); EL=$(( $(date +%s) - START ))
[ "$EL" -le 2 ] && ok "E2: мёртвый замок — проход без ожидания (${EL}s)" || bad "E2: застрял на ${EL}s"
: > "$F/mock.lockdir/pid"
START=$(date +%s); ( TAG=f44test . "$F/guard.s" ); EL=$(( $(date +%s) - START ))
[ "$EL" -le 2 ] && ok "E3: pid нечитаем — проход без ожидания" || bad "E3: застрял на ${EL}s"

echo "═══ F. Оборванные комментарии закрыты (R44-6) ═══"
chk(){ if grep -qF "$2" "$K/$1"; then ok "F: $1 — «$3»"; else bad "F: $1 — завершение не найдено"; fi; }
chk opt/bin/common.sh            '# а функция отвечала 0).'                                              'ARGS закрыт'
chk opt/bin/unblock_update.sh    '# И UDP TPROXY в mangle — TCP-правила сами по себе не обслуживают UDP.' 'контракт протокола'
chk opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh '# отказ соединения, отсутствие curl) обрабатывался как подтверждённый down.' 'RCI-timeout'
chk opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh '# в BusyBox выводе это префикс, а не слово «priority»).' '1778-приоритет'
chk opt/etc/ndm/netfilter.d/100-redirect.sh '# пустой вывод), обрабатывался как подтверждённый "down".' 'три состояния'
chk opt/bin/deploy_bypass.sh     "# -p tcp/udp -m set --match-set <set> dst -j DROP) прежде uninstall'ом"  'fallback-DROP'
chk opt/bin/deploy_bypass.sh     "# ключи ещё не добавлены) и само по себе не «небезопасный исход»."        'свежая установка'

echo "═══ F44 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
