#!/bin/bash
# f47_audit.sh v8 — приёмочный стенд правок аудитов 18/19/20/22/23/24 (r45→…→r49→кандидат r50):
#  P. Аудит-24 (повторный сбой установки, rc=3): HTTP-политика перенесена
#     в точку риска — гейт перед сетевой opkg install (установленное
#     пропускается без сети; отсутствующее при http-фиде без ALLOW —
#     warn+пропуск); rc=3 → warn+продолжение; одиночный OFFLINE-флаг
#     самодостаточен; http-проба с ensure_dns и повтором (FB-8)
#  N. Аудит-23 (сбой установки на устройстве): проверка фидов Entware —
#     https без curl = «не проверено» (не бракуется), Range-проба 256Б,
#     недоступность фидов не убивает установку (авторитет — opkg update;
#     политический rc=3 для http-фида — с явным обходом ALLOW-флагом)
#  M. Аудит-22: O-1 (Origin: SSH-туннель 127.0.0.1:любой-порт при
#     loopback-клиенте, альтернативные LAN-IP, allowed_origin_hosts;
#     request.host не возвращён), TS-1 (tmp-статус не переживает
#     прогон: trap в body, очистка при отказе Popen), AF-1 (жёсткий
#     кап _auth_fails 256), SN-1 (нормализация fallback-подсетей,
#     логирование отказов ACCEPT) — поведенчески, экстракцией helpers
#  L. Аудит-21: FW-1b (зачистка legacy-blanket в setup_firewall,
#     без fallback на ALLOWED_SUBNETS), PF-1 (preflight панели —
#     только flask+markupsafe; текст deploy раздельный), RM-1
#     (uninstall_netfilter предупреждает об остатке чужих ACCEPT
#     на :8080 — поведенчески, на моках секции A)
#  K. Аудит-20: FW-1 (нет blanket-RFC1918 в setup_firewall, подсети
#     LAN как в блоке B7 хука), TW-1 (нет root-обёрток-файлов в /tmp:
#     sh -c + O_NOFOLLOW + mkstemp; фолбэк-статус обёртки), RL-1
#     (ротация: триггер по размеру, KEEP — цель), TG-1 (общая
#     tg_send_message: urlencode + токен вне cmdline), CS-1
#     (Origin: hostname-whitelist, чистка _auth_fails), BC-1 (ранний
#     chmod 0600 bot_config.py после apply)
#  A. R47-1+R48-2: uninstall_netfilter на моках iptables/ip/ipset —
#     проектные правила сняты (negated-DROP с -i и исключениями, DNS
#     RETURN udp/53, ACCEPT 8080 по фактическим подсетям), ЧУЖИЕ правила
#     на 8080 (голый ACCEPT / udp / публичный -s) целы, прочие чужие целы,
#     регрессия прежних форм снятия, идемпотентность
#  B. N-5+R48-3: start() из S99generator ЦЕЛИКОМ (не «до первого fi»):
#     preflight до is_running-выхода; при ненастроенном конфиге и живом
#     процессе — останов; already-running при настроенном; сломанный
#     python-конфиг не отсекается (grep не исполняет код)
#  C. R45-4+R48-1: советы про секреты — реальное поле token, исключение
#     заглушки ТОКЕН_БОТА, раздельные советы (токен / пароль панели)
#  D. R48-6: сводка deploy считает ACCEPT 8080 двухступенчатым grep'ом
#     (форма хука с -s между --dport и -j видна)
#  E. R48-8: сводка различает «панель не настроена» и «не запустилась»
#  F. R48-9: test_udp_tunnels — процесс не запущен => warn, а не FAIL
#  G. R48-5: просмотр списка в боте ≡ рендеру сохранения (R46-2)
#  H. R48-7: wsSettings.host вместо headers.Host (шаблон + конвертер)
#  J. аудит-19: R49-1 (без двойного запуска unblock_update в deploy,
#     boot-путь S99unblock цел), R49-2 (версия hysteria из баннера)
#  I. маркеры правок, синтаксис, отсутствие bot_token, JSON шаблона,
#     хук 100-redirect.sh не тронут; A6-4: pidof-фолбэк через /proc
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f47chk
rm -rf "$F"; mkdir -p "$F/bin"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. R47-1+R48-2: uninstall_netfilter на моках ═══"

# мок iptables: состояние в файле, формат table|chain|-A chain spec
cat > "$F/bin/iptables" <<'EOF'
#!/bin/bash
R=${IPT_MOCK_STATE:?}
T=filter
args=("$@")
i=0
while [ $i -lt ${#args[@]} ]; do
    case "${args[$i]}" in
        -t) T=${args[$((i+1))]}; i=$((i+2)); continue ;;
        -w) i=$((i+1)); continue ;;
    esac
    break
done
act=${args[$i]}
chain=${args[$((i+1))]}
spec=""
j=$((i+2))
while [ $j -lt ${#args[@]} ]; do
    spec="$spec ${args[$j]}"
    j=$((j+1))
done
spec=${spec# }
case "$act" in
    -S)
        awk -F'|' -v t="$T" -v c="$chain" \
            '$1==t && $2==c {sub(/^[^|]*\|[^|]*\|-A [^ ]* /,""); print "-A " c " " $0}' "$R"
        ;;
    -D)
        key="${T}|${chain}|-A ${chain} ${spec}"
        if grep -qxF "$key" "$R"; then
            grep -vx "$key" "$R" > "$R.tmp" && mv "$R.tmp" "$R"
            exit 0
        fi
        exit 1
        ;;
    -C)
        grep -qxF "${T}|${chain}|-A ${chain} ${spec}" "$R" && exit 0
        exit 1
        ;;
esac
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ip6tables"
cat > "$F/bin/ip" <<'EOF'
#!/bin/sh
[ "$1" = "link" ] && [ "$2" = "show" ] && {
    case "$3" in br0|nwg0) exit 0 ;; *) exit 1 ;; esac
}
if [ "$1" = "-4" ] && [ "$2" = "addr" ]; then
    if [ "$4" = "br0" ]; then
        printf '2: br0: <BROADCAST,MULTICAST,UP> mtu 1500\n    inet 192.168.1.1/24 brd 192.168.1.255 scope global br0\n'
    fi
    exit 0
fi
[ "$1" = "rule" ] && exit 1
[ "$1" = "route" ] && exit 0
exit 0
EOF
cat > "$F/bin/ipset" <<'EOF'
#!/bin/sh
if [ "$1" = "list" ] && [ "$2" = "-n" ]; then
    printf 'unblockdns\nunblockhysteria\nunblockrouter\nunblocksh\nunblocktor\nunblocktroj\nunblockvless\n'
fi
exit 0
EOF
# моки для секции E: netstat управляется маркером, ss всегда молчит
cat > "$F/bin/netstat" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/net8080 ] || exit 1
printf 'tcp 0 0 0.0.0.0:8080 0.0.0.0:* LISTEN\n'
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ss"
# мок pidof для секции F: маркер pidup => rc 0
cat > "$F/bin/pidof" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/pidup ] && exit 0
exit 1
EOF
chmod +x "$F/bin/"*

# фикстура правил: проектные (все формы) + чужие (должны уцелеть),
# в т.ч. ТРИ чужих на 8080 (R48-2)
cat > "$F/rules.txt" <<'EOF'
nat|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -j REDIRECT --to-port 9141
nat|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockvless dst -j REDIRECT --to-port 10810
nat|PREROUTING|-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1
nat|PREROUTING|-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP
mangle|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp --dport 53 -j RETURN
mangle|PREROUTING|-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblockrouter dst -j MARK --set-mark 0xd1001/0xd1001
mangle|PREROUTING|-A PREROUTING -m conntrack --ctstate NEW -m set --match-set unblocktor dst -j CONNMARK --set-mark 0xd1001
mangle|PREROUTING|-A PREROUTING -j CONNMARK --restore-mark
mangle|PREROUTING|-A PREROUTING -p tcp --dport 5000 -j DROP
filter|INPUT|-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 192.168.0.0/16 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p udp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j DROP
filter|INPUT|-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT
filter|INPUT|-A INPUT -i br0 -p tcp --dport 9141 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 22 -j ACCEPT
nat|OUTPUT|-A OUTPUT -o lo -j RETURN
nat|OUTPUT|-A OUTPUT -d 192.168.0.0/16 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x2000000 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x9999999 -j RETURN
EOF
cp "$F/rules.txt" "$F/state.txt"

awk '/^uninstall_netfilter\(\) \{/,/^\}/' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/un.s"
UN_LINES=$(wc -l < "$F/un.s")
[ "$UN_LINES" -gt 150 ] \
    && ok "A0: экстракт uninstall_netfilter (${UN_LINES} строк)" \
    || bad "A0: экстракт подозрительно мал (${UN_LINES} строк)"

cat > "$F/runA.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runA.sh"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA.log" 2>&1
rcA=$?
LEFT=$(cat "$F/state.txt")
chk_gone(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 1 || return 0; }
chk_here(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 0 || return 1; }

[ "$rcA" = 0 ] && [ "$(grep -c '^RC=0$' "$F/runA.log")" = 1 ] \
    && ok "A1: uninstall_netfilter отработала rc=0" \
    || bad "A1: rc=$rcA ($(tail -2 "$F/runA.log"))"
chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP' \
    && chk_gone '-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP' \
    && ok "A2: negated-DROP UDP-guard снят (обе формы)" \
    || bad "A2: guard-DROP остался: $(printf '%s\n' "$LEFT" | grep 'unblocktor dst\|unblocktroj dst' | grep DROP)"
chk_gone '-A PREROUTING -p udp --dport 53 -j RETURN' \
    && ok "A3: DNS RETURN (mangle, udp/53) снят" \
    || bad "A3: DNS RETURN остался"
NACC=$(printf '%s\n' "$LEFT" | grep -c -- '--dport 8080 -j ACCEPT' || true)
[ "$NACC" = 3 ] \
    && ok "A4: проектные ACCEPT 8080 (5 приватных -s, включая 169.254) сняты, осталось ровно 3 чужих" \
    || bad "A4: осталось ACCEPT 8080: $NACC (ожидалось 3 чужих)"
chk_gone '-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4c: link-local ACCEPT (169.254.10.0/24) снят (A6-1)" \
    || bad "A4c: link-local ACCEPT пережил удаление"
chk_here '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -p udp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4b: чужие 8080 целы: голый tcp / udp / публичный -s (R48-2)" \
    || bad "A4b: чужое 8080-правило удалено: $(printf '%s\n' "$LEFT" | grep -- '--dport 8080')"
chk_gone '-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP' \
    && chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -j CONNMARK --restore-mark' \
    && chk_gone '-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1' \
    && chk_gone '-A OUTPUT -m mark --mark 0x2000000 -j RETURN' \
    && chk_gone '-A INPUT -p tcp --dport 8080 -j DROP' \
    && chk_gone '-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT' \
    && ok "A5: регрессия прежних форм: REDIRECT/TPROXY/простой DROP/CONNMARK/socket/DNAT/OUTPUT/8080-DROP сняты" \
    || bad "A5: что-то из прежних форм осталось"
chk_here '-A PREROUTING -p tcp --dport 5000 -j DROP' \
    && chk_here '-A INPUT -p tcp --dport 22 -j ACCEPT' \
    && chk_here '-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4' \
    && chk_here '-A OUTPUT -m mark --mark 0x9999999 -j RETURN' \
    && ok "A6: прочие чужие правила целы (DROP 5000 / ACCEPT 22 / DNAT 9999 / RETURN 0x9999999)" \
    || bad "A6: чужое правило удалено"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA2.log" 2>&1
rcA2=$?
LEFT2=$(cat "$F/state.txt")
if [ "$rcA2" = 0 ] && [ "$LEFT2" = "$LEFT" ]; then
    ok "A7: идемпотентность — повторный прогон rc=0, состояние не изменилось"
else
    bad "A7: rc=$rcA2, дельта: $(diff <(printf '%s\n' "$LEFT") <(printf '%s\n' "$LEFT2") | head -5)"
fi

echo "═══ B. N-5+R48-3: start() целиком (S99generator) ═══"
awk '/^start\(\) \{/,/^\}/' "$K/opt/etc/init.d/S99generator" > "$F/start.fn"
grep -q 'R48-3 (аудит-18)' "$F/start.fn" && grep -q 'SKIPPED' "$F/start.fn" \
    && ok "B0: экстракт start() ($(wc -l < "$F/start.fn") строк), preflight внутри" \
    || bad "B0: экстракт неполон"
runB(){
    CFG="$1"; ISRUN="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/start.fn" > "$F/start.case"
    {
        echo 'NAME=generator'
        echo "PIDFILE=$F/pid"
        echo "LOGFILE=$F/gen.log"
        echo "WORKDIR=$F/wd"
        echo "APP=$F/app"
        echo "is_running(){ [ -f '$F/isrun' ]; }"
        echo "kill_app(){ echo kill >> '$F/kills'; }"
        echo 'find_python(){ printf "/bin/echo\n"; }'
        echo ". '$F/start.case'"
        echo 'start'
        echo 'echo "RC=$?"'
    } > "$F/runB.sh"
    rm -f "$F/kills" "$F/pid" "$F/isrun" "$F/gen.log"
    [ "$ISRUN" = 1 ] && { : > "$F/isrun"; echo 12345 > "$F/pid"; }
    mkdir -p "$F/wd"; : > "$F/app"
    ( bash "$F/runB.sh" ) 2>/dev/null
}
mkdir -p "$F/cfg"
printf "web_username = 'admin'\nweb_password = ''\n" > "$F/cfg/empty_pass.py"
printf "web_username = ''\nweb_password = 'x'\n" > "$F/cfg/empty_user.py"
printf "web_username = 'admin'\nweb_password = 'secret'\n" > "$F/cfg/ok.py"
printf "web_username = 'admin'\nweb_password = 'x'\nэтот файл не python !!!\n" > "$F/cfg/broken.py"
O1=$(runB "$F/cfg/empty_pass.py" 0)
printf '%s' "$O1" | grep -q 'SKIPPED' && [ -z "$(printf '%s' "$O1" | grep 'Stopping')" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B1: пустой пароль, процесса нет → SKIPPED, никто не тронут" \
    || bad "B1: $O1 kills=$(cat "$F/kills" 2>/dev/null)"
O2=$(runB "$F/cfg/empty_pass.py" 1)
printf '%s' "$O2" | grep -q 'Stopping' && printf '%s' "$O2" | grep -q 'SKIPPED' \
    && [ -f "$F/kills" ] && [ ! -f "$F/pid" ] \
    && ok "B2: пустой пароль, панель жива → останов (kill_app, pidfile снят) + SKIPPED (R48-3)" \
    || bad "B2: $O2 kills=$(cat "$F/kills" 2>/dev/null) pid=$(cat "$F/pid" 2>/dev/null)"
O3=$(runB "$F/cfg/ok.py" 1)
printf '%s' "$O3" | grep -q 'already running' && [ -z "$(printf '%s' "$O3" | grep SKIPPED)" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B3: настроено, панель жива → already running, без SKIPPED/kill" \
    || bad "B3: $O3"
O4=$(runB "$F/cfg/ok.py" 0)
[ -z "$(printf '%s' "$O4" | grep SKIPPED)" ] && printf '%s' "$O4" | grep -q 'Starting' \
    && ok "B4: настроено, процесса нет → preflight пройден, старт (Starting…)" \
    || bad "B4: $O4"
O5=$(runB "$F/cfg/broken.py" 0)
[ -z "$(printf '%s' "$O5" | grep SKIPPED)" ] && printf '%s' "$O5" | grep -q 'Starting' \
    && ok "B5: сломанный python-конфиг НЕ отсекается (grep не исполняет код)" \
    || bad "B5: $O5"
L1=$(grep -n 'web_username' "$F/start.fn" | head -1 | cut -d: -f1)
L2=$(grep -n 'if is_running; then' "$F/start.fn" | head -1 | cut -d: -f1)
[ -n "$L1" ] && [ -n "$L2" ] && [ "$L1" -lt "$L2" ] \
    && ok "B6: preflight стоит ДО is_running-выхода (строки $L1 < $L2)" \
    || bad "B6: порядок нарушен ($L1 vs $L2)"

echo "═══ C. R45-4+R48-1: советы про секреты ═══"
awk '/# R45-4 \(аудит-17\)/{f=1} f{print} f && /^fi$/{n++; if (n==2) exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/sec.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/sec.body" | grep -c '__CFG__')
[ "$SUBS" = 3 ] \
    && ok "C0: экстракт блока секретов, 3 grep-условия ведут на bot_config.py" \
    || bad "C0: замен путей = $SUBS (ожидалось 3)"
runC(){
    CFG="$1"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/sec.body" > "$F/sec.run"
    ( . "$F/sec.run" )
}
printf "token = '123456:REAL-KEY'\nweb_password = ''\n" > "$F/cfg/tok.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = 'p'\n" > "$F/cfg/ph.py"
printf "token = '123456:REAL-KEY'\nweb_password = 'p'\n" > "$F/cfg/both.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = ''\n" > "$F/cfg/none.py"
printf "token='ТОКЕН_БОТА'\n" > "$F/cfg/ph2.py"
C1=$(runC "$F/cfg/tok.py")
printf '%s' "$C1" | grep -q 'перевыпустите токен' && [ -z "$(printf '%s' "$C1" | grep 'смените пароль')" ] \
    && ok "C1: токен заполнен, пароль пуст → совет про токен, без совета про пароль" \
    || bad "C1: $C1"
C2=$(runC "$F/cfg/ph.py")
printf '%s' "$C2" | grep -q 'смените пароль' && [ -z "$(printf '%s' "$C2" | grep 'перевыпустите токен')" ] \
    && ok "C2: заглушка токена, пароль заполнен → совет про пароль, без токена" \
    || bad "C2: $C2"
C3=$(runC "$F/cfg/both.py")
printf '%s' "$C3" | grep -q 'перевыпустите токен' && printf '%s' "$C3" | grep -q 'смените пароль' \
    && ok "C3: оба заполнены → оба совета" \
    || bad "C3: $C3"
C4=$(runC "$F/cfg/none.py"); C5=$(runC "$F/cfg/missing.py"); C6=$(runC "$F/cfg/ph2.py")
[ -z "$C4" ] && [ -z "$C5" ] && [ -z "$C6" ] \
    && ok "C4: заглушка+пустой пароль / нет файла / заглушка без пробелов → тишина" \
    || bad "C4: напечатано: C4=[$C4] C5=[$C5] C6=[$C6]"
NB=$(grep 'bot_token' "$K/opt/bin/deploy_bypass.sh" | grep -vc '^[[:space:]]*#' || true)
[ "${NB:-0}" = 0 ] \
    && ok "C5: несуществующего поля bot_token больше нет вне комментариев" \
    || bad "C5: bot_token вне комментариев: $NB"

echo "═══ D. R48-6: подсчёт ACCEPT 8080 в сводке ═══"
awk '/# R48-6 \(аудит-18\)/{f=1} f{ if ($0 ~ /^if \[/) exit; print }' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.block"
grep -c 'WEB_ACC=' "$F/webacc.block" | grep -q '^2$' \
    && ok "D0: экстракт присваивания WEB_ACC (обе строки)" \
    || bad "D0: экстракт неполон"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
{ echo 'IPT_BIN=/tmp/f47chk/bin/ipt_web'; cat "$F/webacc.block"; echo 'echo "WEB_ACC=$WEB_ACC"'; } > "$F/runD.sh"
D1=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=' )
[ "$D1" = "WEB_ACC=4" ] \
    && ok "D1: форма хука с -s считается (4 ACCEPT из 5 правил; старая склейка дала бы 1)" \
    || bad "D1: $D1"
printf '#!/bin/sh\nexit 0\n' > "$F/bin/ipt_web"
D2=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=')
[ "$D2" = "WEB_ACC=0" ] \
    && ok "D2: пустой вывод → WEB_ACC=0 (без unbound variable/ошибок)" \
    || bad "D2: $D2"

# A6-2: счётчик остаётся фактом, но вердикт «Доступ из LAN» не выдаётся
awk '/# R48-6 \(аудит-18\)/{f=1} f{print} f && /^fi$/{exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.full"
runD3(){
    MOCK="$1"
    {
        echo "IPT_BIN=$MOCK"
        echo 'warn(){ echo "WARN: $*"; }'
        cat "$F/webacc.full"
    } > "$F/runD3.sh"
    bash "$F/runD3.sh" 2>/dev/null
}
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
D3=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D3" | grep -q 'Найдены ACCEPT-правила на :8080 (2)' \
    && [ -z "$(printf '%s' "$D3" | grep 'Доступ из LAN')" ] \
    && ok "D3: WEB_ACC>0 → ℹ️ «Найдены ACCEPT-правила…», без вердикта «Доступ из LAN» (A6-2)" \
    || bad "D3: $D3"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT'
exit 0
EOF
D4=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D4" | grep -q 'Найдены ACCEPT-правила на :8080 (1)' \
    && [ -z "$(printf '%s' "$D4" | grep 'Доступ из LAN')" ] \
    && ok "D4: только loopback-ACCEPT → ℹ️ (не «доступ из LAN разрешён»)" \
    || bad "D4: $D4"

echo "═══ E. R48-8: сводка про порт 8080 ═══"
awk '/# Панель обязана СЛУШАТЬ/,/^fi$/' "$K/opt/bin/deploy_bypass.sh" > "$F/lstn.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/lstn.body" | grep -c '__CFG__')
[ "$SUBS" = 2 ] \
    && ok "E0: экстракт блока слушателя, оба условия (A6-3) ведут на bot_config.py" \
    || bad "E0: замен путей = $SUBS (ожидалось 2)"
runE(){
    CFG="$1"; NET="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/lstn.body" > "$F/lstn.run"
    rm -f "$F/net8080"
    [ "$NET" = 1 ] && : > "$F/net8080"
    (
        PATH="$F/bin:/usr/bin:/bin"
        warn(){ echo "WARN: $*"; }
        . "$F/lstn.run"
    )
}
E1=$(runE "$F/cfg/ok.py" 1)
printf '%s' "$E1" | grep -q '8080 слушается' \
    && ok "E1: порт слушается → ✅ (пароль не важен)" \
    || bad "E1: $E1"
E2=$(runE "$F/cfg/ok.py" 0)
printf '%s' "$E2" | grep -q 'НЕ слушается' && [ -z "$(printf '%s' "$E2" | grep 'не настроена')" ] \
    && ok "E2: пароль задан, порт молчит → предупреждение с логом" \
    || bad "E2: $E2"
E3=$(runE "$F/cfg/empty_pass.py" 0)
printf '%s' "$E3" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E3" | grep 'НЕ слушается')" ] \
    && ok "E3: пароль пуст, порт молчит → ℹ️ «не настроена», без поиска ошибки в логе (R48-8)" \
    || bad "E3: $E3"
E4=$(runE "$F/cfg/missing.py" 0)
printf '%s' "$E4" | grep -q 'не настроена' \
    && ok "E4: конфига нет → ℹ️ «не настроена»" \
    || bad "E4: $E4"
E5=$(runE "$F/cfg/empty_user.py" 0)
printf '%s' "$E5" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E5" | grep 'НЕ слушается')" ] \
    && ok "E5: пустой web_username + пароль → «не настроена», не «НЕ слушается» (A6-3)" \
    || bad "E5: $E5"

echo "═══ F. R48-9: градация test_udp_tunnels ═══"
awk '/# R48-9 \(аудит-18\)/{f=1} f{print} f && /^    fi$/{n++; if (n==4) exit}' \
    "$K/opt/bin/test_udp_tunnels.sh" > "$F/udp.block"
grep -q '_proc_up' "$F/udp.block" && grep -q 'A6-4 (аудит-19)' "$F/udp.block" \
    && [ "$(grep -c 'не проверяем' "$F/udp.block")" = 2 ] \
    && ok "F0: экстракт сокетных проверок с градацией и /proc-фолбэком" \
    || bad "F0: экстракт неполон"
runF(){
    LU="$1"; LT="$2"; PUP="$3"
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    [ "$PUP" = 1 ] && : > "$F/pidup"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"$LU\"; _lt=\"$LT\""
        echo ". '$F/udp.block'"
    } > "$F/runF.sh"
    ( PATH="$F/bin:/usr/bin:/bin" bash "$F/runF.sh" ) 2>/dev/null
}
runF "10.0.0.1:10810" "10.0.0.1:10810" 1
[ "$(wc -l < "$F/f.ok")" = 3 ] && [ ! -f "$F/f.bad" ] \
    && ok "F1: процесс жив, сокеты слушают → 3×OK" \
    || bad "F1: ok=$(cat "$F/f.ok" 2>/dev/null | wc -l) bad=$(cat "$F/f.bad" 2>/dev/null | wc -l)"
runF "" "10.0.0.1:10810" 1
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" \
    && ok "F2: процесс жив, udp-сокета нет → FAIL сохранён (реальный дефект)" \
    || bad "F2: bad=$(cat "$F/f.bad" 2>/dev/null)"
runF "" "" 0
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F3: процесс не запущен → warn, сокеты не проверяем, FAIL нет (R48-9)" \
    || bad "F3: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

# A6-4: PATH без pidof вовсе — живость через /proc-скан (имитатор xray)
_BASH4="$(command -v bash)"
mkdir -p "$F/bin2"
ln -sf "$(command -v tr)" "$F/bin2/tr"
ln -sf "$(command -v head)" "$F/bin2/head"
cp /bin/sleep "$F/bin2/xray" && chmod +x "$F/bin2/xray"
"$F/bin2/xray" 30 & _IMPID=$!
runFP(){
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"\"; _lt=\"\""
        echo ". '$F/udp.block'"
    } > "$F/runFP.sh"
    # bash по абсолютному пути: VAR=x cmd резолвит cmd уже в новом PATH
    ( PATH="$F/bin2" "$_BASH4" "$F/runFP.sh" ) 2>/dev/null
}
runFP
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" && grep -q 'запущен' "$F/f.ok" \
    && ok "F4: без pidof живой процесс найден через /proc → udp-FAIL сохранён (A6-4)" \
    || bad "F4: ok=$(cat "$F/f.ok" 2>/dev/null) bad=$(cat "$F/f.bad" 2>/dev/null)"
kill "$_IMPID" 2>/dev/null; wait "$_IMPID" 2>/dev/null
runFP
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F5: без pidof процесс отсутствует → warn, FAIL нет" \
    || bad "F5: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

echo "═══ J. Аудит-19: R49-1 (дубль unblock_update), R49-2 (hysteria) ═══"
NB1=$(grep 'safe_start_service "S99unblock"' "$K/opt/bin/deploy_bypass.sh" \
    | grep -vc '^[[:space:]]*#' || true)
[ "${NB1:-0}" = 0 ] && grep -q 'R49-1 (аудит-19)' "$K/opt/bin/deploy_bypass.sh" \
    && ok "J1: deploy не запускает S99unblock в фоне (дубль исключён, контракт-комментарий на месте)" \
    || bad "J1: живых вызовов S99unblock: $NB1"
grep -q '/opt/bin/unblock_update.sh >/dev/null 2>&1 &' \
    "$K/opt/etc/init.d/S99unblock" \
    && ok "J2: boot-путь S99unblock не тронут (фоновый запуск при загрузке)" \
    || bad "J2: S99unblock изменился"
# NB: head -1|awk для XRAY корректен (первая строка без баннера) —
# инвариант только про hysteria-строку
HYLINE=$(grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1)
printf '%s' "$HYLINE" | grep -qF "head -1 | awk" \
    && bad "J3: hysteria-строка всё ещё парсится по первому полю баннера" \
    || ok "J3: парсинг версии hysteria — grep -oE (xray-строки не тронуты)"
mkdir -p "$F/bin3"
cat > "$F/bin3/hysteria" <<'HYS'
#!/bin/sh
printf 'Hysteria2 \xe2\x9c\x93\n'
printf 'Version:        app/v2.13.0\n'
printf 'Platform:       linux/amd64\n'
exit 0
HYS
chmod +x "$F/bin3/hysteria"
grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1 > "$F/hy.echo"
( PATH="$F/bin3:/usr/bin:/bin" sh -c ". '$F/hy.echo'" ) > "$F/hy.out" 2>/dev/null
grep -q 'уже установлена (2.13.0), скачивание пропущено' "$F/hy.out" \
    && ok "J4: hysteria 2.x (баннер первой строкой) → «уже установлена (2.13.0)» (R49-2)" \
    || bad "J4: вывод: $(cat "$F/hy.out" 2>/dev/null)"
ND=$(grep -c 'аудит-19' "$K/opt/bin/deploy_bypass.sh" || true)
NT=$(grep -c 'аудит-19' "$K/opt/bin/test_udp_tunnels.sh" || true)
[ "$ND" -ge 5 ] && [ "$NT" -ge 1 ] \
    && ok "J5: маркеры аудита-19: deploy=$ND, test_udp_tunnels=$NT" \
    || bad "J5: deploy=$ND test_udp=$NT"

echo "═══ K. Аудит-20: firewall панели, /tmp-обёртки, ротация, TG, CSRF ═══"
GEN="$K/opt/etc/bot/generator.py"

# K1 (FW-1): в setup_firewall нет blanket-цикла по ALLOWED_SUBNETS;
# подсети берутся из LAN-интерфейсов (паритет с B7 хука).
K1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'for net in \[str(n) for n in ALLOWED_SUBNETS\]' || true)
K1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "proto kernel\|'inet'" || true)
grep -q 'веб-панель доступна только с 127.0.0.1' "$GEN" && K1C=1 || K1C=0
[ "$K1A" = 0 ] && [ "$K1B" -ge 2 ] && [ "$K1C" = 1 ] \
    && ok "K1: setup_firewall — подсети LAN-интерфейсов (B7-паритет), без blanket" \
    || bad "K1: blanket=$K1A lan_list=$K1B degr=$K1C"

# K2 (TW-1): нет файлов-обёрток в /tmp; sh -c + O_NOFOLLOW + mkstemp.
K2A=$(grep -c 'WRAPPER' "$GEN" || true)
K2B=$(grep -c "'-c', body," "$GEN" || true)
K2C=$(grep -c 'O_NOFOLLOW' "$GEN" || true)
K2D=$(grep -c 'mkstemp' "$GEN" || true)
if [ "$K2A" = 0 ] && [ "$K2B" = 2 ] && [ "$K2C" -ge 2 ] && [ "$K2D" -ge 3 ]; then
    # поведенческий прогон точного body обёртки unblock
    KF2="$(mktemp -d)"
    sed -n "/^    body = '\{3\}/,/^'\{3\}$/p" "$GEN" \
        | sed "1s/^    body = '\{3\}//; \$d" > "$KF2/body.sh"
    dash -n "$KF2/body.sh" 2>/dev/null
    printf '#!/bin/sh\necho out; echo err >&2; exit 7\n' > "$KF2/s.sh"
    chmod +x "$KF2/s.sh"
    sh "$KF2/body.sh" "$KF2/st.json" "$KF2/tm" "$KF2/s.sh" "" \
        > "$KF2/run.log" 2>&1
    K2RC=$?
    if [ "$K2RC" = 7 ] \
        && grep -q 'out' "$KF2/run.log" \
        && grep -q '"status":"error"' "$KF2/st.json" \
        && grep -q 'exit code 7' "$KF2/st.json"; then
        ok "K2: обёртки — sh -c + O_NOFOLLOW; body: rc/log/фолбэк-статус верны"
    else
        bad "K2: body-прогон rc=$K2RC: $(cat "$KF2/st.json" 2>/dev/null)"
    fi
    rm -rf "$KF2"
else
    bad "K2: WRAPPER=$K2A sh-c=$K2B nofollow=$K2C mkstemp=$K2D"
fi

# K3 (RL-1): триггер ротации — только размер; KEEP — цель обрезки.
K3T=$(grep -c 'if \[ "$_sz" -gt "$MAX" \]' "$K/opt/bin/rotate_logs.sh" || true)
K3L=$(grep -c -- '-gt "$KEEP"' "$K/opt/bin/rotate_logs.sh" || true)
KF3="$(mktemp -d)"
sed 's|^rotate /opt/etc/bot/error.log$|rotate "$TGT"|; s|^rotate /opt/root/KeenSnap/backup.log$|:|; s|^rotate /opt/var/log/100-redirect.log$|:|; s|^rotate /tmp/unblock_update.log$|:|; s|^MAX=.* rotate |: # |; s|^find /tmp -maxdepth 1|: find /nonexistent|' \
    "$K/opt/bin/rotate_logs.sh" > "$KF3/rot.sh"
sed -i "s|^umask 022|umask 022\nTGT=\"$KF3/error.log\"|" "$KF3/rot.sh"
dash -n "$KF3/rot.sh" 2>/dev/null
awk 'BEGIN{for(i=1;i<=150;i++)print "line"i}' > "$KF3/error.log"
MAX=524288 KEEP=100 sh "$KF3/rot.sh"
K3A=$(wc -l < "$KF3/error.log")
awk 'BEGIN{for(i=1;i<=1000;i++)print "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}' \
    > "$KF3/error.log"
MAX=50000 KEEP=100 sh "$KF3/rot.sh"
K3B=$(wc -l < "$KF3/error.log")
if [ "$K3T" = 1 ] && [ "$K3L" = 0 ] && [ "$K3A" = 150 ] && [ "$K3B" = 100 ]; then
    ok "K3: ротация по размеру: 150 строк<MAX не тронуты, >MAX → KEEP=100"
else
    bad "K3: триггер=$K3T keep-триггер=$K3L A=$K3A B=$K3B"
fi
rm -rf "$KF3"

# K4 (TG-1): общая tg_send_message; urlencode; токен вне cmdline.
K4A=$(grep -c 'tg_send_message()' "$K/opt/bin/common.sh" || true)
K4B=$(grep -c -- '--data-urlencode' "$K/opt/bin/common.sh" || true)
K4C=$(grep -c -- '-K -' "$K/opt/bin/common.sh" || true)
K4D=$(( $(grep -c 'text=\${' "$K/opt/bin/check_updates.sh" || true) \
    + $(grep -c 'text=\${' "$K/opt/bin/unblock_dnsmasq.sh" || true) ))
KF4="$(mktemp -d)"; mkdir -p "$KF4/bin" "$KF4/run"
sed "s|/opt/etc/bot/bot_config.py|$KF4/bot_config.py|g; s|/opt/var/run/|$KF4/run/|g" \
    "$K/opt/bin/common.sh" > "$KF4/common_m.sh"
printf 'token = "ABC123TOKEN"\n' > "$KF4/bot_config.py"
echo "-100200300" > "$KF4/run/bot_chat_id_notify.txt"
printf '#!/bin/sh\necho "ARGV:$@" >> "$MOCKLOG"\ncat > "$MOCKCFG"\nexit 0\n' \
    > "$KF4/bin/curl"
chmod +x "$KF4/bin/curl"
export MOCKLOG="$KF4/argv.log" MOCKCFG="$KF4/cfg.txt"
K4E=$(PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_urlencode 'a&b%c+d<e>'")
PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_send_message 'обновление & готово 100%' HTML"
K4G=0; grep -q 'ABC123TOKEN' "$KF4/argv.log" 2>/dev/null || K4G=1
K4H=0; grep -q 'url = "https://api.telegram.org/botABC123TOKEN/sendMessage"' \
    "$KF4/cfg.txt" 2>/dev/null && K4H=1
if [ "$K4A" = 1 ] && [ "$K4B" -ge 1 ] && [ "$K4C" -ge 1 ] && [ "$K4D" = 0 ] \
    && [ "$K4E" = 'a%26b%25c%2Bd%3Ce%3E' ] && [ "$K4G" = 1 ] && [ "$K4H" = 1 ]; then
    ok "K4: tg_send_message: -K -, --data-urlencode, urlencode, токен вне argv"
else
    bad "K4: fn=$K4A ue=$K4B K=$K4C oldtext=$K4D enc=$K4E tok=$K4G url=$K4H"
fi
rm -rf "$KF4"

# K5 (CS-1+O-1/AF-1): request.host не источник доверия; политика в
# helpers; sweep вызывается из security_checks.
K5A=$(grep -c 'str(request.host)' "$GEN" || true)
K5B=$(grep -c 'def _csrf_origin_allowed' "$GEN" || true)
K5C=$(grep -c 'def _auth_fails_sweep' "$GEN" || true)
K5D=$(grep -c '_auth_fails_sweep(' "$GEN" || true)
[ "$K5A" = 0 ] && [ "$K5B" = 1 ] && [ "$K5C" = 1 ] && [ "$K5D" -ge 2 ] \
    && ok "K5: Origin/_auth_fails — политика в helpers, вызов на месте (L-1+O-1/AF-1)" \
    || bad "K5: reqhost=$K5A origin_h=$K5B sweep_h=$K5C calls=$K5D"

# K6 (BC-1): ранний chmod 0600 bot_config.py сразу после apply.
K6A=$(grep -c 'chmod 0600 /opt/etc/bot/bot_config.py' "$K/opt/bin/deploy_bypass.sh" || true)
K6B=$(sed -n "$(grep -n 'if busybox cp -a' "$K/opt/bin/deploy_bypass.sh" | head -1 | cut -d: -f1),+22p" \
    "$K/opt/bin/deploy_bypass.sh" | grep -c 'BC-1' || true)
[ "$K6A" -ge 4 ] && [ "$K6B" -ge 2 ] \
    && ok "K6: chmod 0600 bot_config.py после apply (BC-1, до аварийных выходов)" \
    || bad "K6: chmod-строк=$K6A маркеров-возле-apply=$K6B"

echo "═══ L. Аудит-21: legacy-blanket, preflight, предупреждение -remove ═══"

# L1 (FW-1b): зачистка legacy-blanket в setup_firewall; fallback нет.
L1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "legacy_net in ('192.168.0.0/16', '10.0.0.0/8'," || true)
L1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'ALLOWED_SUBNETS' || true)
[ "$L1A" = 1 ] && [ "$L1B" = 0 ] \
    && ok "L1: legacy-blanket снимается панелью; fallback на ALLOWED_SUBNETS нет" \
    || bad "L1: legacy=$L1A fallback=$L1B"

# L2 (PF-1): preflight — только flask+markupsafe; текст deploy раздельный.
L2A=$(grep -c 'import flask, markupsafe' "$K/opt/etc/init.d/S99generator" || true)
L2B=$(grep -c 'import flask, requests' "$K/opt/etc/init.d/S99generator" || true)
L2C=$(grep -c 'Панели нужен flask (+markupsafe); боту — telebot и requests' \
    "$K/opt/bin/deploy_bypass.sh" || true)
L2D=$(grep -c 'Веб-панель и бот без этих модулей не запустятся' \
    "$K/opt/bin/deploy_bypass.sh" || true)
[ "$L2A" = 1 ] && [ "$L2B" = 0 ] && [ "$L2C" = 1 ] && [ "$L2D" = 0 ] \
    && ok "L2: preflight flask+markupsafe (без requests); текст deploy раздельный" \
    || bad "L2: preflight=$L2A/$L2B текст=$L2C/$L2D"

# L3 (RM-1): uninstall_netfilter предупреждает об остатке чужих ACCEPT.
# Поведенчески: тот же экстракт/мок, что в секции A.
cat > "$F/runL.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/l3state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runL.sh"
cp "$F/rules.txt" "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3a.log" 2>&1
L3A=$(grep -c 'вне формы проекта: 3' "$F/l3a.log" || true)
grep -v -- '--dport 8080 -j ACCEPT' "$F/rules.txt" > "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3b.log" 2>&1
L3B=$(grep -c 'вне формы проекта' "$F/l3b.log" || true)
L3RC=$(grep -c '^RC=0$' "$F/l3a.log" || true)
if [ "$L3A" = 1 ] && [ "$L3B" = 0 ] && [ "$L3RC" = 1 ]; then
    ok "L3: -remove предупреждает о 3 чужих ACCEPT; без чужих — молчит; rc=0"
else
    bad "L3: с-чужими=$L3A без-чужих=$L3B rc=$L3RC"
fi

echo "═══ M. Аудит-22: Origin-туннель, tmp-статус, кап, нормализация ═══"

# M1 (O-1): поведенческая матрица _csrf_origin_allowed (экстракция).
python3 - "$GEN" > "$F/m1.out" 2>&1 <<'PYM1'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _csrf_origin_allowed\(.*?(?=^def )', src, re.M | re.S)
assert m, 'no _csrf_origin_allowed'
import ipaddress
from urllib.parse import urlparse
g = {
    'ipaddress': ipaddress, 'urlparse': urlparse,
    'LAN_IP': '192.168.1.1', 'LISTEN_PORT': 8080,
    '_lan_host_addresses': lambda: {'192.168.2.1'},
    '_ORIGIN_EXTRA_HOSTS': ['my.keenetic.net'],
}
exec(m.group(0), g)
f = g['_csrf_origin_allowed']
cases = [
    ('http://192.168.1.1:8080', '192.168.1.5', True),
    ('http://127.0.0.1:18080', '127.0.0.1', True),
    ('http://localhost:19000', '127.0.0.1', True),
    ('http://127.0.0.1:18080', '192.168.1.5', False),
    ('http://192.168.2.1:8080', '192.168.1.5', True),
    ('http://my.keenetic.net:8080', '192.168.1.5', True),
    ('http://evil.example:8080', '192.168.1.5', False),
    ('http://192.168.1.1', '192.168.1.5', False),
    ('ftp://192.168.1.1:8080', '192.168.1.5', False),
]
bad = [i for i, (o, c, want) in enumerate(cases) if f(o, c) != want]
if bad:
    print('BAD=%s' % ','.join(map(str, bad)))
else:
    print('MATRIX_OK(%d)' % len(cases))
PYM1
grep -q 'MATRIX_OK(9)' "$F/m1.out" \
    && ok "M1: Origin: туннель 127.0.0.1:любой-порт ✓ (loopback-клиент), альт-LAN-IP ✓, конфиг-имя ✓, чужие ✗" \
    || bad "M1: $(cat "$F/m1.out")"

# M2 (TS-1): tmp-статус не переживает прогон (успех и fallback).
KF6="$(mktemp -d)"
python3 - "$GEN" > "$KF6/body.sh" <<'PYM2'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search('body = ' + Q + '(.*?)' + Q, src, re.S)
assert m, 'no body'
sys.stdout.write(m.group(1))
PYM2
dash -n "$KF6/body.sh" 2>/dev/null
printf '{"status":"done","ts":1,"message":"by script"}\n' > "$KF6/st1.json"
printf '#!/bin/sh\nexit 0\n' > "$KF6/s0.sh"; chmod +x "$KF6/s0.sh"
sh "$KF6/body.sh" "$KF6/st1.json" "$KF6/tmp1" "$KF6/s0.sh" "" \
    > "$KF6/a.log" 2>&1
printf '#!/bin/sh\nexit 7\n' > "$KF6/s7.sh"; chmod +x "$KF6/s7.sh"
sh "$KF6/body.sh" "$KF6/st2.json" "$KF6/tmp2" "$KF6/s7.sh" "" \
    > "$KF6/b.log" 2>&1
if [ ! -e "$KF6/tmp1" ] && [ ! -e "$KF6/tmp2" ] \
    && grep -q 'by script' "$KF6/st1.json" \
    && grep -q '"status":"error"' "$KF6/st2.json" \
    && grep -q 'exit code 7' "$KF6/st2.json"; then
    ok "M2: tmp-статус удалён и при успехе (trap), и при fallback (mv); статусы верны"
else
    bad "M2: tmp1=$([ -e "$KF6/tmp1" ] && echo есть || echo нет) tmp2=$([ -e "$KF6/tmp2" ] && echo есть || echo нет)"
fi
rm -rf "$KF6"
K2TRAP=$(grep -c "trap 'rm -f" "$GEN" || true)
K2EXC=$(grep -c 'os.unlink(tmp_status)' "$GEN" || true)
[ "$K2TRAP" = 2 ] && [ "$K2EXC" = 2 ] \
    && ok "M2b: trap в обоих body + очистка при отказе Popen (TS-1)" \
    || bad "M2b: trap=$K2TRAP unlink=$K2EXC"

# M3 (AF-1): жёсткий кап 256; истёкшие чистятся.
python3 - "$GEN" > "$F/m3.out" 2>&1 <<'PYM3'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
mc = re.search(r'^_AUTH_FAILS_MAX = (\d+)$', src, re.M)
mf = re.search(r'^def _auth_fails_sweep\(.*?(?=^def )', src, re.M | re.S)
assert mc and mf, 'no const/func'
g = {'_AUTH_FAILS_MAX': int(mc.group(1))}
exec(mf.group(0), g)
sweep = g['_auth_fails_sweep']
d = {('10.%d.0.1' % i): (5, 2e9) for i in range(300)}
sweep(d, '10.0.0.1', 1e9)
cap_ok = len(d) == 256
d2 = {'a': (0, 100.0), 'b': (5, 2e9)}
r = sweep(d2, 'a', 1e9)
exp_ok = 'a' not in d2 and 'b' in d2 and r == (0, 0.0)
print('OK' if cap_ok and exp_ok else 'BAD cap=%d exp=%s' % (len(d), exp_ok))
PYM3
grep -q '^OK$' "$F/m3.out" \
    && ok "M3: _auth_fails: 300 активных → 256; истёкшая запись сброшена (AF-1)" \
    || bad "M3: $(cat "$F/m3.out")"

# M4 (SN-1): fallback-нормализация host-bits; невалидные пропущены.
python3 - "$GEN" > "$F/m4.out" 2>&1 <<'PYM4'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _lan_subnet_list\(.*?(?=^def )', src, re.M | re.S)
assert m, 'no func'
import ipaddress
class _R:
    def __init__(self, out): self.stdout = out
class _SP:
    def run(self, args, **kw):
        if args[:4] == ['ip', '-4', 'route', 'show']:
            return _R('')
        if args[:4] == ['ip', '-4', 'addr', 'show']:
            return _R(
                '2: br9: <BROADCAST,MULTICAST,UP>\n'
                '    inet 192.168.2.1/24 brd 192.168.2.255 br9\n'
                '    inet 10.0.0.99/8 brd 10.255.255.255 br9\n'
                '    inet frog/24 br9\n')
        return _R('')
class _C:
    lan_ifaces = ['br9']
g = {'subprocess': _SP(), 'ipaddress': ipaddress, 'config': _C()}
exec(m.group(0), g)
nets, found = g['_lan_subnet_list']()
ok1 = '192.168.2.1/24' not in nets and '192.168.2.0/24' in nets
ok2 = '10.0.0.0/8' in nets
ok3 = not any('frog' in n for n in nets)
ok4 = nets and nets[0] == '127.0.0.0/8' and found is True
print('OK' if ok1 and ok2 and ok3 and ok4 else
      'BAD %r' % (nets,))
PYM4
grep -q '^OK$' "$F/m4.out" \
    && ok "M4: fallback: 192.168.2.1/24 → 192.168.2.0/24; 10.0.0.99/8 → 10.0.0.0/8; frog пропущен (SN-1)" \
    || bad "M4: $(cat "$F/m4.out")"
grep -q 'ACCEPT не создан' "$GEN" \
    && ok "M4b: отказ создания ACCEPT логируется (SN-1)" \
    || bad "M4b: нет логирования отказа ACCEPT"

echo "═══ N. Аудит-23: проверка фидов Entware (сбой установки r48) ═══"
NB="$F/nb"; mkdir -p "$NB/bin" "$NB/dl"
DEP="$K/opt/bin/deploy_bypass.sh"
# экстракция функций блока зеркал
for _nfn in _entware_stock_feeds _entware_feed_base _entware_probe_feed_url \
            _entware_feeds_reachable _entware_prepare_candidate pick_entware_base; do
    awk "/^${_nfn}\(\) \{/,/^\}/" "$DEP" >> "$NB/fns.sh"
    echo >> "$NB/fns.sh"
done
grep -q '^pick_entware_base()' "$NB/fns.sh" || bad "N0: экстракция блока зеркал не удалась"

# N1 (FB-2): https-проба без curl → «не проверено» (rc 2), не «нет».
printf '#!/bin/sh\nexit 1\n' > "$NB/bin/wget"; chmod +x "$NB/bin/wget"
cat > "$NB/run1.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD=""
export KEENZOO_DLTMP DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run1.sh"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run1.sh" 2>/dev/null | tail -1)
[ "$NBRC" = "PROBE_RC=2" ] \
    && ok "N1: https без curl → «не проверено» (rc 2), зеркало не бракуется (FB-2)" \
    || bad "N1: $NBRC (ожидался PROBE_RC=2)"

# N2 (FB-3): curl-проба лёгкая (Range 256Б), а не полная загрузка.
printf '#!/bin/sh\necho "ARGV:$@" >> /tmp/f47chk/nb/curl.log\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c 256 /dev/zero > "$2"; shift; done\nexit 0\n' \
    > "$NB/bin/curl"; chmod +x "$NB/bin/curl"
cat > "$NB/run2.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD="curl"
export KEENZOO_DLTMP DL_CMD
have_cmd() { command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run2.sh"
rm -f "$NB/curl.log"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run2.sh" 2>/dev/null | tail -1)
if [ "$NBRC" = "PROBE_RC=0" ] && grep -q -- '-r 0-255' "$NB/curl.log" 2>/dev/null; then
    ok "N2: curl-проба — Range 256Б (не полная загрузка Packages.gz) (FB-3)"
else
    bad "N2: rc=$NBRC; curl-лог: $(cat "$NB/curl.log" 2>/dev/null | head -1)"
fi
rm -f "$NB/bin/curl"

# N3/N4/N5: поведенческие сценарии pick_entware_base (как на устройстве).
cat > "$NB/pick.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl
KZ_DEPLOY_OPKG_CONF="$1"
ENTWARE_ARCH=aarch64-k3.10; DL_CMD=""
export KEENZOO_DLTMP KZ_DEPLOY_OPKG_CONF ENTWARE_ARCH DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { echo "WARN: $*"; }
die()   { echo "DIE: $*"; exit 42; }
ENTWARE_MIRRORS="https://bin.entware.net https://entware.diversion.ch"
_ENTWARE_BASE_REQUESTED=""
ENTWARE_BASE=""; ENTWARE_MIRROR_SWITCH_NEEDED=0; ENTWARE_MIRROR_CHANGED=0
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
pick_entware_base >/dev/null 2>&1
echo "PICK_RC=$?"
EOF
chmod +x "$NB/pick.sh"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc/gz keendev http://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\nsrc/gz keendev https://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/https.conf"
RC_A=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/http.conf" 2>/dev/null | tail -1)
RC_B=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/https.conf" 2>/dev/null | tail -1)
[ "$RC_A" = "PICK_RC=0" ] \
    && ok "N3: сценарий устройства (http-фиды, curl нет) → rc 0, установка не гибнет (FB-6 аудита-24)" \
    || bad "N3: $RC_A (ожидался PICK_RC=0)"
[ "$RC_B" = "PICK_RC=0" ] \
    && ok "N4: https-фиды без curl → rc 0: установка НЕ гибнет, решает opkg update (FB-1/FB-2)" \
    || bad "N4: $RC_B (ожидался PICK_RC=0)"

# N5 (FB-1/FB-5): инварианты текстов и семантики в самом deploy.
N5A=$(grep -c 'ни один HTTPS-кандидат не прошёл' "$DEP" || true)
N5B=$(grep -c 'Разрешить осознанно: KEENZOO_ALLOW_HTTP_FEED=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5C=$(grep -c 'KEENZOO_OPKG_OFFLINE=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5D=$(grep -c 'Ни один кандидат не подтверждён; opkg.conf остаётся прежним' "$DEP" || true)
[ "$N5A" = 0 ] && [ "$N5B" = 1 ] && [ "$N5C" -ge 1 ] && [ "$N5D" = 1 ] \
    && ok "N5: старые немые die убраны; подсказки-обходы на месте (FB-1/FB-5/FB-6)" \
    || bad "N5: старый-die=$N5A allow-hint=$N5B offline-hint=$N5C fb1-warn=$N5D"

echo "═══ P. Аудит-24: HTTP-гейт в точке риска, retry пробы ═══"
PB="$F/pb"; mkdir -p "$PB/bin" "$PB/dl"
# экстракция гейт-хелперов
for _pfn in _kz_pkg_installed _kz_http_feed_active _kz_http_install_gate; do
    awk "/^${_pfn}\(\) \{/,/^\}/" "$DEP" >> "$PB/gate.sh"
    echo >> "$PB/gate.sh"
done
grep -q '^_kz_http_install_gate()' "$PB/gate.sh" || bad "P0: экстракция гейтов не удалась"

# фейковый opkg: list-installed знает только tor; /var/opkg/status недоступен
printf '#!/bin/sh\n[ "$1" = list-installed ] && { echo "tor - 1.0"; exit 0; }\nexit 0\n' \
    > "$PB/bin/opkg"; chmod +x "$PB/bin/opkg"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\n' > "$PB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$PB/https.conf"

cat > "$PB/g.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/pb/bin:/bin"; export PATH
warn() { echo "WARN: $*"; }
. /tmp/f47chk/pb/gate.sh >/dev/null 2>&1
case "$1" in
    installed) _kz_pkg_installed "$2"; echo "RC=$?";;
    gate)      KZ_DEPLOY_OPKG_CONF="$2" KEENZOO_ALLOW_HTTP_FEED="${3:-0}" \
                   _kz_http_install_gate testpkg; echo "RC=$?";;
esac
EOF
chmod +x "$PB/g.sh"
GR1=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed tor 2>/dev/null | tail -1)
GR2=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed xray 2>/dev/null | tail -1)
GR3=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 0 2>/dev/null | tail -1)
GR4=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 1 2>/dev/null | tail -1)
GR5=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/https.conf 0 2>/dev/null | tail -1)
if [ "$GR1" = "RC=0" ] && [ "$GR2" = "RC=1" ] && [ "$GR3" = "RC=1" ] \
    && [ "$GR4" = "RC=0" ] && [ "$GR5" = "RC=0" ]; then
    ok "P1: гейт: установлен→пропуск; http без ALLOW→warn+пропуск; http+ALLOW/https→можно (FB-6)"
else
    bad "P1: inst=$GR1/$GR2 http0=$GR3 http1=$GR4 https=$GR5"
fi
GATE_WARNS=$(PATH=/usr/bin:/bin KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/pb/http.conf bash -c \
    'warn(){ echo "WARN:$*"; }; PATH="/tmp/f47chk/pb/bin:/bin"; . /tmp/f47chk/pb/gate.sh >/dev/null 2>&1; _kz_http_install_gate testpkg' 2>/dev/null)
printf '%s' "$GATE_WARNS" | grep -q 'KEENZOO_ALLOW_HTTP_FEED=1' \
    && ok "P2: warn гейта несёт обход KEENZOO_ALLOW_HTTP_FEED=1 (FB-7)" \
    || bad "P2: warn гейта без подсказки: $GATE_WARNS"

# P3: гейт вызван во всех сетевых opkg install шага пакетов.
P3A=$(grep -c '_kz_http_install_gate' "$DEP" || true)
P3B=$(grep -c '_kz_pkg_installed "\$pkg" && continue' "$DEP" || true)
[ "$P3A" -ge 10 ] && [ "$P3B" = 1 ] \
    && ok "P3: гейт на всех местах установок ($P3A); цикл пакетов: skip-if-installed" \
    || bad "P3: gate=$P3A skip=$P3B"

# P4 (FB-8): http-проба — ensure_dns + повтор.
P4A=$(awk '/http:\/\/\*\)/,/;;/' "$DEP" | grep -c 'ensure_dns' || true)
P4B=$(awk '/http:\/\/\*\)/,/;;/' "$DEP" | grep -c '_epf_try' || true)
[ "$P4A" -ge 1 ] && [ "$P4B" -ge 3 ] \
    && ok "P4: http-проба: ensure_dns + 2 попытки (FB-8)" \
    || bad "P4: dns=$P4A retry=$P4B"

# P5: формулировки.
P5A=$(grep -c 'Текущий фид Entware работает по HTTP' "$DEP" || true)
[ "$P5A" -ge 1 ] \
    && ok "P5: формулировка «работает по HTTP» вместо «не разрешён» (FB-9)" \
    || bad "P5: формулировки нет"

echo "═══ G. R48-5: просмотр списка ≡ сохранению ═══"
python3 - "$K" "$F" <<'PYB'
import ast, io, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import lists_core as lc

src = io.open(os.path.join(K, 'opt/etc/bot/handlers.py'), encoding='utf-8').read()
names = {'load_bypass_blocks', 'sections_to_text', 'format_blocks_for_display'}
segs = [ast.get_source_segment(src, n) for n in ast.parse(src).body
        if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(segs) == 3, 'не все функции извлечены'
ns = {'lists_core': lc, 'os': os}
exec('import os\n', ns)
exec('\n\n'.join(segs), ns)

tf = os.path.join(F, 'disp.txt')
io.open(tf, 'w', encoding='utf-8').write(
    '9.example.com\n1.example.com\n# Группа 1\n8.8.8.8\n1.1.1.1\n'
    '# Пометка без записей\n7.7.7.7\n')
secs = ns['load_bypass_blocks'](tf)
disp = ns['format_blocks_for_display'](secs)
expect = ('1.example.com\n9.example.com\n\n# Группа 1\n1.1.1.1\n8.8.8.8\n\n'
          '# Пометка без записей\n7.7.7.7')
if disp == expect:
    ok('G1: просмотр = порядок файла + сортировка в секции + comment-only видны')
else:
    bad(f'G1: {disp!r} != {expect!r}')
if disp.startswith('1.example.com\n9.example.com'):
    ok('G2: безымянные записи не «всплыли» в конец')
else:
    bad('G2: порядок безымянных нарушен')
if '# Пометка без записей' in disp:
    ok('G3: comment-only секция показывается (N-3 паритет)')
else:
    bad('G3: comment-only скрыт')
if ns['format_blocks_for_display']( []) == 'Список пуст':
    ok('G4: пустой список — «Список пуст»')
else:
    bad('G4: пустой список не обработан')
# Настоящий контракт R48-5: то, что пользователь ВИДИТ, равно тому,
# что оказалось бы в файле после сохранения (round-trip через
# parse_and_save — рендер сохранения сортирует записи так же).
d2 = os.path.join(F, 'lists'); os.makedirs(d2)
lc.UNBLOCK_DIR = d2
tf2 = os.path.join(d2, 'vless.txt')
lc.parse_and_save(tf2, ns['sections_to_text'](secs))
saved = io.open(tf2, encoding='utf-8').read()
if disp == saved.rstrip('\n'):
    ok('G5: просмотр ≡ файлу после сохранения (round-trip parse_and_save)')
else:
    bad(f'G5: {disp!r} != {saved!r}')
io.open(os.path.join(F, 'g.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
GP=0; GF=1
[ -s "$F/g.counts" ] && read GP GF < "$F/g.counts"
PASS=$((PASS+GP)); FAIL=$((FAIL+GF))

echo "═══ H. R48-7: wsSettings.host ═══"
TPL="$K/opt/etc/bot/templates/vless_template.json"
grep -q '"host":"{{ws_host}}"' "$TPL" \
    && ok "H1: шаблон: wsSettings.host (новая форма)" \
    || bad "H1: шаблон не содержит host"
NOLD=$(grep -c '"headers"\|"Host"' "$TPL" || true)
[ "$NOLD" = 0 ] \
    && ok "H2: шаблон: headers/Host отсутствуют" \
    || bad "H2: устаревшая форма в шаблоне ($NOLD)"
python3 - "$K" "$F" <<'PYB'
import ast, io, json, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

grep_tpl = io.open(os.path.join(
    K, 'opt/etc/bot/templates/vless_template.json'),
    encoding='utf-8').read()
if '"path":"{{ws_path}}"' in grep_tpl and '{{ws_host}}' in grep_tpl:
    ok('H3: ws-блок шаблона структурно цел (path+host; рендер — f41)')
else:
    bad('H3: ws-блок шаблона повреждён')

src = io.open(os.path.join(K, 'opt/etc/bot/utils.py'), encoding='utf-8').read()
seg = [ast.get_source_segment(src, n) for n in ast.parse(src).body
       if isinstance(n, ast.FunctionDef) and n.name == '_convert_singbox_vless'][0]
ns = {}
exec(seg, ns)
fn = ns['_convert_singbox_vless']

sb_old = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/ws',
                        'headers': {'Host': 'cdn.example.org'}}}
ws = fn(sb_old)['outbounds'][0]['streamSettings']['wsSettings']
if ws == {'path': '/ws', 'host': 'cdn.example.org'}:
    ok('H4: sing-box headers.Host → wsSettings.host (фолбэк старой формы)')
else:
    bad(f'H4: {ws!r}')

sb_new = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/w', 'host': 'h.example'}}
ws2 = fn(sb_new)['outbounds'][0]['streamSettings']['wsSettings']
if ws2 == {'path': '/w', 'host': 'h.example'}:
    ok('H5: sing-box host → wsSettings.host (приоритет новой формы)')
else:
    bad(f'H5: {ws2!r}')
io.open(os.path.join(F, 'h.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
HP=0; HF=1
[ -s "$F/h.counts" ] && read HP HF < "$F/h.counts"
PASS=$((PASS+HP)); FAIL=$((FAIL+HF))

echo "═══ I. Маркеры, синтаксис, контракты ═══"
MD=$(grep -c 'R48-[1268] (аудит-18)' "$K/opt/bin/deploy_bypass.sh" || true)
[ "$MD" = 4 ] \
    && ok "I1: маркеры R48-1/2/6/8 в deploy (4)" \
    || bad "I1: маркеров в deploy = $MD (ожидалось 4)"
grep -q 'R48-3 (аудит-18)' "$K/opt/etc/init.d/S99generator" \
    && grep -q 'R48-9 (аудит-18)' "$K/opt/bin/test_udp_tunnels.sh" \
    && grep -q 'R48-5 (аудит-18)' "$K/opt/etc/bot/handlers.py" \
    && grep -q 'R48-7 (аудит-18)' "$K/opt/etc/bot/utils.py" \
    && ok "I2: маркеры R48-3/9/5/7 на местах" \
    || bad "I2: какой-то маркер отсутствует"
dash -n "$K/opt/bin/deploy_bypass.sh" && dash -n "$K/opt/etc/init.d/S99generator" \
    && dash -n "$K/opt/bin/test_udp_tunnels.sh" \
    && ok "I3: синтаксис правленых shell-файлов (dash -n)" \
    || bad "I3: dash -n упал"
python3 -m py_compile "$K/opt/etc/bot/handlers.py" "$K/opt/etc/bot/utils.py" \
    && ok "I4: py_compile handlers.py + utils.py" \
    || bad "I4: py_compile упал"
grep -q 'web INPUT DROP add/verify failed' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    && ok "I5: хук 100-redirect.sh на месте (правки аудита-18 его не касались)" \
    || bad "I5: хук неожиданно изменён"
if git -C "$K" rev-parse --git-dir >/dev/null 2>&1; then
    if git -C "$K" diff --quiet HEAD -- opt/etc/ndm/netfilter.d/100-redirect.sh; then
        ok "I6: хук не отличается от Git HEAD"
    else
        bad "I6: хук изменён относительно HEAD"
    fi
else
    ok "I6: [SKIP] git-раскладка — сверка с HEAD не требуется"
fi
grep -q 'safe_start_service "S99generator"' "$K/opt/bin/deploy_bypass.sh" \
    && grep -A3 'safe_start_service() {' "$K/opt/bin/deploy_bypass.sh" | grep -q '|| true' \
    && ok "I7: deploy не падает от SKIPPED (safe_start_service глотает rc)" \
    || bad "I7: контракт safe_start_service изменён"

echo "═══ F47 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
