#!/bin/bash
# f42_check.sh — приёмочный стенд правок R42 (аудит-12):
#  A. is_public_ipv4/is_public_ipv4_py: спец-диапазоны (192.88.99, RFC 7526)
#  B. handlers.py: делегирование lists_core — паритет чтения/очистки со
#     старыми локальными копиями (фикстура ред. 40, R44-1 — без git),
#     сортировка показа = _sort_key
#  C. dns_spoof_check: гвард ожидания цикла unblock_update (живой/мёртвый pid)
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f42chk
rm -rf "$F"; mkdir -p "$F"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. Публичность IP: shell (common.sh) ↔ python (lists_core) ═══"
sed -n '/^is_ip()/,/^}/p' "$K/opt/bin/common.sh" > "$F/pub.s"
sed -n '/^is_public_ipv4()/,/^}/p' "$K/opt/bin/common.sh" >> "$F/pub.s"
sh_pub(){ sh -c ". '$F/pub.s'; is_public_ipv4 '$1' >/dev/null 2>&1 && echo pub || echo priv"; }
py_pub(){ python3 -c "
import sys; sys.path.insert(0, '$K/opt/etc/bot')
import lists_core as lc
print('pub' if lc.is_public_ipv4_py(tuple(int(x) for x in '$1'.split('.'))) else 'priv')"; }
t(){ # $1 ip $2 ожидание
  s=$(sh_pub "$1"); p=$(py_pub "$1")
  if [ "$s" = "$p" ] && [ "$s" = "$2" ]; then ok "$1 → $2 (shell=py)"; else bad "$1: shell=$s py=$p (ждали $2)"; fi
}
t 8.8.8.8 pub
t 1.1.1.1 pub
t 10.0.0.1 priv
t 192.168.1.1 priv
t 198.51.100.1 priv
t 203.0.113.1 priv
t 192.88.99.1 priv
t 192.0.2.1 priv
t 100.64.1.1 priv
t 224.0.0.1 priv

echo "═══ B. handlers: паритет чтения/очистки + сортировка = _sort_key ═══"
cat > "$F/sample.txt" <<'EOF'
# Секция один
93.184.216.34
8.8.8.8 # comment
example.com
10.0.0.0/8

# Секция два
9.9.9.9
*.wild.example
2001:db8::1
EOF
# R44-1 (аудит-14, N-1): эталон — функции ред. 40 (bef01f5), вшиты
# фикстурой: в раскладке релиза (ZIP) git-истории нет, а сравнение
# «HEAD ↔ worktree» после релизного коммита вырождалось в сравнение
# дерева с самим собой. Функции дословные, внешних зависимостей нет.
cat > "$F/handlers_r40.py" <<'R40HANDLERS'
# Эталон ред. 40 (bef01f5:opt/etc/bot/handlers.py) — локальные
# реализации до делегирования в lists_core (R42-6/F-7).
def get_clean_entry(entry):
    return entry.split('#')[0].strip()


def load_bypass_blocks(filepath):
    if not os.path.exists(filepath):
        return []
    sections = []
    current_section = None
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            stripped = (
                line.rstrip('\n')
                .rstrip('\r').strip())
            if not stripped:
                current_section = None
                continue
            if stripped.startswith('#'):
                comment = stripped[1:].strip()
                current_section = {
                    'comment': comment,
                    'entries': []}
                sections.append(current_section)
            else:
                if current_section is None:
                    current_section = {
                        'comment': None,
                        'entries': []}
                    sections.append(current_section)
                current_section['entries'].append(
                    stripped)
    return sections


def parse_input_blocks(text):
    sections = []
    current_section = None
    for line in text.split('\n'):
        stripped = line.strip()
        if not stripped:
            current_section = None
            continue
        if stripped.startswith('#'):
            comment = stripped[1:].strip()
            current_section = {
                'comment': comment,
                'entries': []}
            sections.append(current_section)
        else:
            if current_section is None:
                current_section = {
                    'comment': None,
                    'entries': []}
                sections.append(current_section)
            current_section['entries'].append(
                stripped)
    return [s for s in sections if s['entries']]


def format_blocks_for_display(sections):
    if not sections:
        return "Список пуст"
    lines = []
    named = [
        s for s in sections
        if s['comment'] is not None
        and s['entries']]
    unnamed = [
        e for s in sections
        if s['comment'] is None
        for e in s['entries']]
    for i, section in enumerate(named):
        if i > 0:
            lines.append('')
        lines.append(
            f"#{section['comment']}")
        for entry in sorted(
                section['entries'],
                key=lambda e:
                    get_clean_entry(e).lower()):
            lines.append(entry)
    if unnamed:
        if named:
            lines.append('')
        for entry in sorted(
                unnamed,
                key=lambda e:
                    get_clean_entry(e).lower()):
            lines.append(entry)
    return ('\n'.join(lines)
            if lines else "Список пуст")
R40HANDLERS
python3 - "$K" "$F" <<'PYB' || bad "паритет handlers"
import ast, io, os, sys, tempfile
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import lists_core

def extract(src, names):
    tree = ast.parse(src)
    out = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in names:
            out.append(ast.get_source_segment(src, node))
    return out

names = {'load_bypass_blocks', 'get_clean_entry', 'format_blocks_for_display', 'parse_input_blocks',
       'sections_to_text'}  # R48-5 (аудит-18): display делегирует рендер twin-у R46-2
old_src = io.open(os.path.join(F, 'handlers_r40.py'), encoding='utf-8').read()
new_src = io.open(os.path.join(K, 'opt/etc/bot/handlers.py'), encoding='utf-8').read()

def load_module(src, label):
    fn_defs = extract(src, names)
    ns = {'lists_core': lists_core, 'os': os}
    exec('import os\n', ns)
    exec('\n\n'.join(fn_defs), ns)
    return ns

old = load_module(old_src, 'old')
new = load_module(new_src, 'new')

sample = os.path.join(F, 'sample.txt')
ob, nb = old['load_bypass_blocks'](sample), new['load_bypass_blocks'](sample)
assert ob == nb, f'load_bypass_blocks разошёлся:\n{ob}\n---\n{nb}'

for entry in ['8.8.8.8 # comment', 'Example.COM.', '*.wild.example', '10.0.0.0/8']:
    assert old['get_clean_entry'](entry) == new['get_clean_entry'](entry), entry
assert new['get_clean_entry']('8.8.8.8 # x') == lists_core._clean_entry('8.8.8.8 # x')

blocks = new['parse_input_blocks'](io.open(sample, encoding='utf-8').read())
disp_new = new['format_blocks_for_display'](blocks)
sec = blocks[0]
expect = sorted(sec['entries'], key=lists_core._sort_key)
got = [l for l in disp_new.split('\n') if l and not l.startswith('#')]
assert got[:len(expect)] == expect, f'сортировка ≠ _sort_key:\n{got}\n---\n{expect}'
print('[OK]   B: чтение/очистка/сортировка ≡ lists_core (старые копии = новые)')
PYB
[ $? -eq 0 ] && ok "B: handlers ≡ lists_core (паритет сохранён, сортировка числовая)"

echo "═══ C. dns_spoof_check: гвард ожидания unblock_update ═══"
# извлекаем гвард по маркеру R42-2 и гоняем его с мок-замком
awk '/^if \[ -d \/tmp\/unblock_update\.lockdir/ {f=1} f{print} f&&/^fi$/{exit}' \
    "$K/opt/bin/dns_spoof_check.sh" > "$F/guard.s"
grep -q '_dsc_waits' "$F/guard.s" || { bad "гвард не извлёкся"; }
SLEEPER=$(mktemp "$F/sleeper.XXXX"); ( sleep 300 ) & SPID=$!
mkdir -p "$F/mock.lockdir"; echo "$SPID" > "$F/mock.lockdir/pid"
sed -i "s|/tmp/unblock_update.lockdir|$F/mock.lockdir|g" "$F/guard.s"
# живой pid: гвард ждёт (дольше 3 с), потом «без ожидания» — таймаут не ждём 5 мин,
# проверяем только факт входа в ожидание: убиваем sleeper через 3 с
( UNBLOCK_LOG_TAG=f42test . "$F/guard.s" ) & GPID=$!
sleep 3
if kill -0 $GPID 2>/dev/null; then ok "C1: живой цикл — гвард ждёт"; else bad "C1: гвард не ждал живой замок"; fi
kill "$SPID" 2>/dev/null; wait "$SPID" 2>/dev/null
wait $GPID 2>/dev/null
# мёртвый pid: гвард проходит сразу
echo "999999" > "$F/mock.lockdir/pid"
START=$(date +%s)
( UNBLOCK_LOG_TAG=f42test . "$F/guard.s" )
ELAPSED=$(( $(date +%s) - START ))
[ "$ELAPSED" -le 2 ] && ok "C2: мёртвый замок — проход без ожидания (${ELAPSED}s)" || bad "C2: застрял на ${ELAPSED}s"
# пустой pid-файл: сразу
: > "$F/mock.lockdir/pid"
START=$(date +%s); ( . "$F/guard.s" ); ELAPSED=$(( $(date +%s) - START ))
[ "$ELAPSED" -le 2 ] && ok "C3: pid нечитаем — проход без ожидания" || bad "C3: застрял"

echo "═══ F42 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
