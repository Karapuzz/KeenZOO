#!/bin/bash
# verify42.sh — поведенческий верификатор мини-аудита r68 (FB-121/FB-124).
# Воспроизводит живой инцидент: «sh -c body имя арг…» на Keenetic-прошивке
# теряет имя/аргументы — новая обёртка обязана работать в режиме «только -c
# body» и диагностировать отсутствие переменных явным error-статусом.
set -u
K=${1:-/home/user/KeenZOO}
GEN="$K/opt/etc/bot/generator.py"
F=/tmp/verify42
rm -rf "$F"; mkdir -p "$F"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

# V1: python-синтаксис (FB-178/аудит-46: кэш компиляции — во временный
# каталог, проверяемое дерево не трогается; прежде py_compile писал
# __pycache__ прямо в $K и скрипт удалял его же из чужого дерева).
_V1C="$F/v1pyc"; mkdir -p "$_V1C"
PYTHONPYCACHEPREFIX="$_V1C" python3 -m py_compile "$GEN" 2>/dev/null \
    && ok "V1: py_compile generator.py" \
    || bad "V1: py_compile"
rm -rf "$_V1C"

# V2: маркеры аудита и отсутствие старого argv-контракта
V2=1
grep -q 'FB-121 (аудит-42' "$GEN" || V2=0
grep -q 'FB-124 (аудит-42' "$GEN" || V2=0
[ "$(grep -c 'keenzoo-update' "$GEN" || true)" = 0 ] || V2=0
[ "$(grep -c 'keenzoo-proto-update' "$GEN" || true)" = 0 ] || V2=0
[ "$(grep -cF "'/bin/sh', '-c', body]," "$GEN" || true)" = 2 ] || V2=0
[ "$(grep -c 'env={' "$GEN" || true)" = 2 ] || V2=0
[ "$V2" = 1 ] && ok "V2: маркеры FB-121/124; argv 3-элементный ×2; env= ×2; старые argv-маркеры удалены" \
    || bad "V2: контракт статических маркеров"

Q="'''"
# V3: обёртка списков — режим прошивки (sh -c body, без argv), rc=7 → фолбэк
python3 - "$GEN" > "$F/body1.sh" <<'PYV'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
b = re.findall('body = ' + Q + '(.*?)' + Q, src, re.S)
assert len(b) == 2
sys.stdout.write(b[0])
PYV
python3 - "$GEN" > "$F/body2.sh" <<'PYV'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
b = re.findall('body = ' + Q + '(.*?)' + Q, src, re.S)
assert len(b) == 2
sys.stdout.write(b[1])
PYV
dash -n "$F/body1.sh" 2>/dev/null && dash -n "$F/body2.sh" 2>/dev/null \
    && ok "V3: dash -n обоих тел обёрток" || bad "V3: dash -n"

printf '#!/bin/sh\necho out; echo err >&2; exit 7\n' > "$F/s7.sh"; chmod +x "$F/s7.sh"
KZ_STATUS_FILE="$F/st.json" KZ_TMP_STATUS="$F/tm" KZ_SCRIPT="$F/s7.sh" KZ_ONLY= \
    sh -c "$(cat "$F/body1.sh")" > "$F/run.log" 2>&1
V3R=$?
if [ "$V3R" = 7 ] && grep -q 'out' "$F/run.log" \
    && grep -q '"status":"error"' "$F/st.json" \
    && grep -q 'exit code 7' "$F/st.json" && [ ! -e "$F/tm" ]; then
    ok "V4: обёртка списков в режиме прошивки (без argv): rc=7, фолбэк-статус, tmp потреблён"
else
    bad "V4: rc=$V3R st=$(cat "$F/st.json" 2>/dev/null)"
fi

# V5: обёртка списков — СТАРЫЙ режим (argv с именем) больше не нужен:
#     те же значения через env при «лишних» argv-параметрах не ломают прогон
KZ_STATUS_FILE="$F/st2.json" KZ_TMP_STATUS="$F/tm2" KZ_SCRIPT="$F/s7.sh" KZ_ONLY= \
    sh -c "$(cat "$F/body1.sh")" keenzoo-update A1 A2 A3 > "$F/run2.log" 2>&1
V5R=$?
if [ "$V5R" = 7 ] && grep -q 'exit code 7' "$F/st2.json"; then
    ok "V5: argv-хвост игнорируется (прошивка/здоровый sh — один результат)"
else
    bad "V5: rc=$V5R"
fi

# V6: FB-124 — окружение не дошло → error-статус rc=3 (обе обёртки)
sed "s|/tmp/unblock_update_status.json|$F/g1.json|g" "$F/body1.sh" > "$F/g1.sh"
sed "s|/tmp/proto_update_status.json|$F/g2.json|g" "$F/body2.sh" > "$F/g2.sh"
env -i PATH="$PATH" sh -c "$(cat "$F/g1.sh")" > "$F/gr1.log" 2>&1; V6A=$?
env -i PATH="$PATH" sh -c "$(cat "$F/g2.sh")" > "$F/gr2.log" 2>&1; V6B=$?
if [ "$V6A" = 3 ] && grep -q 'FB-124' "$F/g1.json" 2>/dev/null \
    && [ "$V6B" = 3 ] && grep -q 'FB-124' "$F/g2.json" 2>/dev/null \
    && grep -Fq 'не получила KZ_*-переменные' "$F/gr1.log" \
    && grep -Fq 'не получила KZ_*-переменные' "$F/gr2.log"; then
    ok "V6: FB-124 — обе обёртки: пустое окружение → error-статус с маркером, rc=3, диагноз в логе"
else
    bad "V6: rc1=$V6A rc2=$V6B g1=$(cat "$F/g1.json" 2>/dev/null) g2=$(cat "$F/g2.json" 2>/dev/null)"
fi

# V7: обёртка протоколов — полный цикл в режиме прошивки
printf '#!/bin/sh\necho proto-out\nexit 0\n' > "$F/p.sh"; chmod +x "$F/p.sh"
KZ_SC="$F/p.sh" KZ_ACT=hysteria KZ_ST="$F/pst.json" KZ_TMP="$F/ptm" \
    sh -c "$(cat "$F/body2.sh")" > "$F/prun.log" 2>&1
V7R=$?
if [ "$V7R" = 0 ] && grep -q 'proto-out' "$F/prun.log" \
    && grep -q '"status":"done"' "$F/pst.json" \
    && grep -q '"action":"hysteria"' "$F/pst.json" && [ ! -e "$F/ptm" ]; then
    ok "V7: обёртка протоколов: done + action, tmp потреблён (кнопка «Обновить протоколы»)"
else
    bad "V7: rc=$V7R st=$(cat "$F/pst.json" 2>/dev/null)"
fi

echo "═══ VERIFY42 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
