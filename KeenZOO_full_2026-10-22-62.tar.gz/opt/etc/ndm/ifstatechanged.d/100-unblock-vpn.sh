#!/bin/sh
# /opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh
# Реакция на изменение состояния интерфейсов прошивки.
#   Клиентский VPN (выход в интернет через туннель) -> таблица маршрутизации,
#   fwmark-правило и список /opt/etc/unblock/vpn-<описание>-<id>.txt.
#   Серверный VPN (WireGuard для удалённого доступа к роутеру) -> НЕ создаёт
#   таблицу и список; его клиенты обслуживаются общими правилами обхода
#   из 100-redirect.sh (интерфейс входит в LAN_IFACE_PATTERNS).
# Оболочка: BusyBox ash.

set -eu

PATH="/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

TAG="100-unblock-vpn.sh"
RT_TABLES="/opt/etc/iproute2/rt_tables"
BOT_CONFIG="/opt/etc/bot/bot_config.py"
RCI="localhost:79/rci"

sleep 1

# rev34 (P1-2 ПА-33): rc curl фиксируется отдельно от вывода. Прежний
# rci_get() глотал rc (|| true), и пустой ответ при сбое RCI (timeout,
# отказ соединения, отсутствие curl) обрабатывался как подтверждённый down.
_RCI_CURL_OK=0
command -v curl >/dev/null 2>&1 && _RCI_CURL_OK=1

rci_get() {
    curl -s --max-time 5 "${RCI}/$1" 2>/dev/null || true
}

# Раздельный захват вывода и rc: присваивание в if-условии не рвёт
# set -e, а конвейер внутри $() не маскирует статус curl статусом tr.
_rci_query() {
    _RQ_OUT=""
    _RQ_RC=1
    [ "$_RCI_CURL_OK" = 1 ] || return 0
    if _RQ_OUT="$(curl -s --max-time 5 "${RCI}/$1" 2>/dev/null)"; then
        _RQ_RC=0
    else
        _RQ_RC=$?
    fi
    return 0
}

check_allow_vpn_in_config="$(
    grep 'vpn_allowed' "$BOT_CONFIG" 2>/dev/null \
        | head -1 | sed 's/=/ /g' | tr -d '"' | awk '{print $2}' || true
)"

if [ -z "$check_allow_vpn_in_config" ]; then
    vpn_services="IKE|SSTP|OpenVPN|Wireguard|L2TP"
else
    vpn_services="$check_allow_vpn_in_config"
fi

# Нельзя искать VPN глобальным grep по show/interface: RCI возвращает
# интерфейсы вложенными блоками, и строка id соседнего блока WAN/Bridge
# ошибочно приклеивалась к найденному типу VPN. Сначала извлекаем id из
# собственных строк id, затем проверяем конфигурацию именно этого id.
rci_interface_ids() {
    rci_get "show/interface" | sed -nE \
        -e 's/.*[" ]id[" ]*[=:][ ]*"?([^",} ]+)"?.*/\1/p' \
        -e 's/^[[:space:]]*id[[:space:]]*[=:][[:space:]]*"?([^",} ]+)"?.*/\1/p' \
        | sed '/^$/d' | sort -u
}

interface_cfg() {
    rci_get "show/rc/interface/$1"
}

# Физические WAN, мосты и системные зоны никогда не являются клиентскими
# VPN policy-интерфейсами. Это явное исключение защищает даже при странном
# или неполном RCI-ответе.
is_forbidden_interface() {
    # ВАЖНО: UsbModem* стоит перед Usb* — более общий шаблон Usb* иначе
    # перехватывает USB-модемы до специализированной ветки (ash case
    # проверяет шаблоны по порядку). Комментарии нельзя размещать
    # внутри многострочного списка шаблонов case — это синтаксическая
    # ошибка для ash.
    case "$1" in
        GigabitEthernet*|Ethernet*|Bridge*|ISP|Home|Guest|WifiMaster*|\
        WifiStation*|AccessPoint*|Mobile*|Cellular*|LTE*|Lte*|\
        UsbModem*|Usb*|CdcEthernet*|Qmi*|Mbim*|Modem*|Pppoe*) return 0 ;;
    esac
    return 1
}

is_vpn_interface() {
    _ivi_id="$1"
    is_forbidden_interface "$_ivi_id" && return 1

    _ivi_cfg="$(interface_cfg "$_ivi_id")"
    # Дополнительная защита для LTE/USB-модемов, чьи логические имена
    # различаются между моделями Keenetic. Они являются WAN, даже если RCI
    # отдал их рядом с VPN-блоком.
    _ivi_link_kind="$(printf '%s\n' "$_ivi_cfg" \
        | grep -Ei 'type|technology|kind|transport|device' | head -20 || true)"
    printf '%s\n' "$_ivi_link_kind" \
        | grep -Eiq 'ethernet|usb|mobile|cellular|lte|modem|qmi|mbim' \
        && return 1

    # ID Wireguard0 есть в NDM, тогда как kernel-имя его устройства в
    # приложенном выводе — nwg0. Не отбрасываем его из-за несовпадения имён.
    case "$_ivi_id" in
        Wireguard*|OpenVPN*|SSTP*|L2TP*|IKE*) return 0 ;;
    esac

    printf '%s\n' "$_ivi_cfg" \
        | grep -Eiq "${vpn_services}|wireguard|openvpn|sstp|l2tp|ike"
}

# Удаление ошибочно созданного состояния выполняется только после проверки
# policy table и правил. В частности, это чистит старый набор
# unblockvpn-Подключение_Ethernet-GigabitEthernet1, если он пережил старый
# запуск проекта.
remove_rt_table_name() {
    _rrtn_name="$1"
    _rrtn_tmp="${RT_TABLES}.tmp.$$"
    awk -v n="$_rrtn_name" '$2 != n' "$RT_TABLES" > "$_rrtn_tmp" 2>/dev/null \
        && mv -f "$_rrtn_tmp" "$RT_TABLES" || rm -f "$_rrtn_tmp"
}

purge_forbidden_vpn_file() {
    _pf_file="$1"
    _pf_base="$(basename "$_pf_file" .txt)"
    _pf_if="${_pf_base##*-}"
    is_forbidden_interface "$_pf_if" || return 0

    _pf_set="unblock${_pf_base}"
    _pf_table_name="$(printf '%s' "$_pf_if" | tr '[:upper:]' '[:lower:]')"
    _pf_table_id="$(grep -w "$_pf_table_name" "$RT_TABLES" 2>/dev/null \
        | awk '{print $1}' | head -n1 || true)"
    if [ -n "$_pf_table_id" ]; then
        _pf_mark="0xd${_pf_table_id}"
        _pf_routes="$(ip -4 route show table "$_pf_table_id" 2>/dev/null \
            | wc -l | awk '{print $1}')"
        _pf_rules="$(ip -4 rule show 2>/dev/null \
            | grep -cE "table $_pf_table_id|fwmark $_pf_mark" || true)"
        logger -t "$TAG" "prune forbidden VPN $_pf_if: table=$_pf_table_id routes=$_pf_routes rules=$_pf_rules set=$_pf_set"

        # Сначала снимаем iptables references, затем уничтожаем ipset.
        # Иначе ipset destroy может быть отвергнут ядром как busy.
        if [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ]; then
            PURGE_VPN_SET="$_pf_set" PURGE_VPN_MARK="$_pf_mark" \
                type=iptable table=mangle \
                /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
        fi
        ip -4 rule del from all table "$_pf_table_id" priority 1778 \
            >/dev/null 2>&1 || true
        ip -4 rule del fwmark "$_pf_mark" lookup "$_pf_table_id" priority 1778 \
            >/dev/null 2>&1 || true
        ip -4 route flush table "$_pf_table_id" >/dev/null 2>&1 || true
        remove_rt_table_name "$_pf_table_name"
    else
        logger -t "$TAG" "prune forbidden VPN $_pf_if: policy table absent, set=$_pf_set"
    fi

    ipset flush "$_pf_set" >/dev/null 2>&1 || true
    ipset destroy "${_pf_set}_new" >/dev/null 2>&1 || true
    ipset destroy "$_pf_set" >/dev/null 2>&1 || true
    rm -f "$_pf_file"
    logger -t "$TAG" "forbidden VPN state removed: $_pf_if / $_pf_set"
}

mkdir -p /opt/etc/iproute2
[ -f "$RT_TABLES" ] || : > "$RT_TABLES"
chmod 644 "$RT_TABLES"

# Убираем только заведомо запрещённые WAN/Bridge-файлы. Валидные client VPN
# не трогаются, даже если сейчас disconnected.
for _pf_file in /opt/etc/unblock/vpn-*.txt; do
    [ -f "$_pf_file" ] || continue
    purge_forbidden_vpn_file "$_pf_file"
done

# unblock_update.sh вызывает этот скрипт в режиме только очистки перед
# сборкой списков, чтобы старый WAN-set не успел попасть в dnsmasq/ipset.
[ "${PRUNE_ONLY:-0}" = "1" ] && exit 0

vpn_check="$(
    for _rci_id in $(rci_interface_ids); do
        is_vpn_interface "$_rci_id" && printf '%s\n' "$_rci_id"
    done
)"

# ═════════════════════════════════════════════════════════════════════════
# Определение роли интерфейса: клиент (выход в интернет) или сервер (доступ)
# ═════════════════════════════════════════════════════════════════════════
# Роль определяется по роли самого интерфейса и маршрутизации. Endpoint
# peer НИКОГДА не используется как единственный признак client: у
# серверного WireGuard endpoint может появляться после handshake.
# rev37 (F36-01, аудит-8): токен-точная проверка наличия policy rule
# в выводе `ip -4 rule show`. Приоритет — ПЕРВОЕ поле строки («1778:»,
# в BusyBox выводе это префикс, а не слово «priority»).
# rev38 (F37-01, аудит-9): проверяется КАНОНИЧЕСКАЯ ПОЛНАЯ форма —
# ровно семь токенов «1778: from all fwmark <m> lookup <t>». Прежняя
# rev39 (R38-02, аудит-10): rc=0 — на 1778 присутствуют ТОЛЬКО точные
# канонические формы (дубликаты канона безвредны); rc=2 — на 1778 есть
_rule_exact_present() {
    _rep_mark="$1"
    _rep_table="$2"
    _rep_tname="$3"
    ip -4 rule show 2>/dev/null | awk \
        -v p="1778:" -v m="$_rep_mark" -v t="$_rep_table" \
        -v n="$_rep_tname" '
        $1 == p {
            if ($2 == "from" && $3 == "all" && $4 == "fwmark" && $5 == m \
                && $6 == "lookup" && NF == 7 \
                && ($7 == t || ($7 == n && n != ""))) {
                found = 1
            } else {
                foreign = 1
            }
        }
        END { exit(found ? (foreign ? 2 : 0) : (foreign ? 2 : 1)) }'
}

# rev38 (F37-03, аудит-9): сериализация rule-транзакции по таблице.
# rev39 (R38-03, аудит-10): захват обязан подтверждаться записью pid
# (прежде сбой записи игнорировался — оставался ownerless-замок, который
_rule_tx_claim() {
    # mv-claim $_rtl_dir: вернуть 0, если замок изъят (можно захватывать)
    _rtc_cl="${_rtl_dir}.reap.$$"
    mv "$_rtl_dir" "$_rtc_cl" 2>/dev/null || return 1
    _rtc_pid="$(cat "${_rtc_cl}/pid" 2>/dev/null || true)"
    if [ -n "$_rtc_pid" ] && kill -0 "$_rtc_pid" 2>/dev/null; then
        # владелец жив (гонка с моментом проверки) — вернуть на место
        mv "$_rtc_cl" "$_rtl_dir" 2>/dev/null || true
        return 1
    fi
    rm -rf "$_rtc_cl" 2>/dev/null || true
    return 0
}

_rule_tx_lock() {
    _rtl_dir="/tmp/keenzoo_rule_${1}.lockdir"
    _rtl_n=0
    _rtl_iter=0
    while [ "$_rtl_n" -le 5 ]; do
        _rtl_iter=$((_rtl_iter + 1))
        [ "$_rtl_iter" -gt 25 ] && break
        if mkdir "$_rtl_dir" 2>/dev/null; then
            if printf '%s\n' "$$" > "${_rtl_dir}/pid" 2>/dev/null; then
                return 0
            fi
            # замок без pid бесполезен (stale-детект невозможен) —
            # снимаем СВОЙ незавершённый каталог и считаем захват не
            # состоявшимся
            rm -rf "$_rtl_dir" 2>/dev/null || true
        elif [ -f "${_rtl_dir}/pid" ]; then
            _rtl_pid="$(cat "${_rtl_dir}/pid" 2>/dev/null || true)"
            if [ -n "$_rtl_pid" ] && kill -0 "$_rtl_pid" 2>/dev/null; then
                _rtl_n=$((_rtl_n + 1))
                sleep 1
                continue
            fi
            _rule_tx_claim || { _rtl_n=$((_rtl_n + 1)); sleep 1; }
        else
            # ownerless: дать владельцу мгновение дописать pid
            sleep 1
            [ -f "${_rtl_dir}/pid" ] && continue
            _rule_tx_claim || { _rtl_n=$((_rtl_n + 1)); sleep 1; }
        fi
    done
    logger -t "$TAG" \
        "rule-транзакция table ${1}: замок не получен за 5 с"
    return 1
}

_rule_tx_unlock() {
    _rtu_dir="/tmp/keenzoo_rule_${1}.lockdir"
    _rtu_pid="$(cat "${_rtu_dir}/pid" 2>/dev/null || true)"
    [ "$_rtu_pid" = "$$" ] \
        && rm -rf "$_rtu_dir" 2>/dev/null || true
}

# rev35 (R35-2, аудит-6 P1.1): строгая проверка IPv4 без regex (BusyBox
# ash): разбор по IFS='.', 4 поля, только цифры, каждое 0-255. Частичное
_valid_ipv4() {
    _v4_cnt=0
    _v4_oldifs="$IFS"
    IFS=.
    for _v4_o in $1; do
        _v4_cnt=$((_v4_cnt + 1))
        case "$_v4_o" in
            ''|*[!0-9]*) IFS="$_v4_oldifs"; return 1 ;;
        esac
        [ "$_v4_o" -le 255 ] || { IFS="$_v4_oldifs"; return 1; }
    done
    IFS="$_v4_oldifs"
    [ "$_v4_cnt" -eq 4 ]
}

# rev35 (R35-1, аудит-6 P1.1): роль трёхсостоятельна.
is_client_tunnel() {
    _ict_id="$1"
    _ict_cfg="$(interface_cfg "$_ict_id")"

    # Listen-port/server/listen признаки относятся к локальному серверу
    # WireGuard. Allowed IP и endpoint peer здесь намеренно не проверяются:
    # у серверного WireGuard могут быть peers с endpoint после handshake.
    case "$_ict_id" in
        Wireguard*)
            if printf '%s\n' "$_ict_cfg" \
                | grep -Eiq 'listen[-_ ]?port|listen[=:]|server[=:]'; then
                return 1
            fi
            ;;
    esac

    # Роль по RCI: global, затем defaultgw. _rci_query сохраняет rc curl
    # отдельно от вывода. rc!=0, пусто или не true/false — unknown;
    # true — client; оба подтверждённо false — server.
    for _ict_q in global defaultgw; do
        _rci_query "show/interface/${_ict_id}/${_ict_q}"
        _ict_val="$(printf '%s' "$_RQ_OUT" | tr -d '"' | tr -d ' ' \
            | tr '[:upper:]' '[:lower:]')"
        if [ "$_RQ_RC" -ne 0 ] || [ -z "$_ict_val" ]; then
            return 2
        fi
        case "$_ict_val" in
            true) return 0 ;;
            false) ;;
            *) return 2 ;;
        esac
    done
    return 1
}

# Очистка состояния клиентского VPN при disconnected/down. Файл списка
# сохраняется: при следующем подключении он снова может быть заполнен, но
# policy rule, маршруты, mark и старые адреса не должны переживать туннель.
cleanup_client_vpn() {
    _cc_vpn="$1"
    _cc_table_name="$(printf '%s' "$_cc_vpn" | tr '[:upper:]' '[:lower:]')"
    _cc_table_id="$(grep -w "$_cc_table_name" "$RT_TABLES" 2>/dev/null \
        | awk '{print $1}' | head -n1 || true)"
    [ -n "$_cc_table_id" ] || return 0

    _cc_mark="0xd${_cc_table_id}"
    ip -4 rule del from all table "$_cc_table_id" priority 1778 \
        >/dev/null 2>&1 || true
    ip -4 rule del fwmark "$_cc_mark" lookup "$_cc_table_id" priority 1778 \
        >/dev/null 2>&1 || true
    ip -4 route flush table "$_cc_table_id" >/dev/null 2>&1 || true

    # Все списки, созданные для этого интерфейса, имеют суффикс -<id>.
    for _cc_list in /opt/etc/unblock/vpn-*-"$_cc_vpn".txt; do
        [ -f "$_cc_list" ] || continue
        _cc_set="unblock$(basename "$_cc_list" .txt)"
        ipset flush "$_cc_set" >/dev/null 2>&1 || true
    done
    # M2/F1: hash-имена суффикса не содержат — читаем их sidecar-маппинг.
    for _cc_sc in /opt/etc/unblock/.vpn-*.iface; do
        [ -f "$_cc_sc" ] || continue
        _cc_sc_if="$(sed -n '1p' "$_cc_sc" 2>/dev/null)"
        [ "$_cc_sc_if" = "$_cc_vpn" ] || continue
        # F4 (аудит rev4 #4): ${_cc_sc#.} НЕ снимал точку — первый
        # символ пути абсолютный ('/'), поэтому собиралось несуществующее
        _cc_base="${_cc_sc##*/}"
        _cc_base="${_cc_base#.}"
        _cc_base="${_cc_base%.iface}"
        ipset flush "unblock${_cc_base}" >/dev/null 2>&1 || true
        ipset flush "unblock${_cc_base}_new" >/dev/null 2>&1 || true
    done

    logger -t "$TAG" "VPN $_cc_vpn OFF: policy rules, routes and ipset cleared"
    if [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ]; then
        type=iptable table=nat \
            /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
        type=iptable table=mangle \
            /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
    fi
}

# RCI может на короткое время убрать интерфейс из show/interface раньше,
# чем hook передаст disconnected. Добавляем переданный id в обработку.
if [ "${1:-}" = "hook" ] && [ -n "${id:-}" ]; then
    # RCI иногда сообщает id до того, как он появился в show/interface,
    # но добавлять можно только структурно подтверждённый VPN id.
    if is_vpn_interface "$id"; then
        case " $vpn_check " in
            *" $id "*) ;;
            *) vpn_check="$vpn_check $id" ;;
        esac
    fi
fi

for vpn in $vpn_check; do
    [ "${1:-}" = "hook" ] || continue
    [ "${id:-}" = "$vpn" ] || continue

    case "${change:-}" in
        disconnected|down|stopped)
            # Серверный WireGuard не создаёт таблицу, поэтому наличие
            # записи в rt_tables безопасно отличает клиентский туннель.
            cleanup_client_vpn "$vpn"
            continue
            ;;
        connected) ;;
        *) continue ;;
    esac

    _vpn_role_rc=0
    is_client_tunnel "$vpn" || _vpn_role_rc=$?
    case "$_vpn_role_rc" in
        2)
            # rev35 (R35-1): роль неизвестна (RCI rc!=0/пусто/неожиданный
            # ответ) — прежнее состояние сохранено, настройка отложена до
            logger -t "$TAG" "VPN $vpn: роль неизвестна (RCI global/defaultgw не ответили) — настройка отложена, прежнее состояние сохранено"
            continue
            ;;
        1)
            # Подтверждённый серверный туннель (например, WireGuard для
            # удалённого управления). Никаких таблиц/списков — только
            # сообщение в лог. Клиенты такого туннеля получают обход
            # через общие правила 100-redirect.sh.
            logger -t "$TAG" "VPN $vpn: серверный режим, policy routing пропущен"
            [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ] \
                && type=iptable table=nat /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 \
                || true
            continue
            ;;
    esac

    vpn_table="$(printf '%s' "$vpn" | tr '[:upper:]' '[:lower:]')"

    if grep -qw "$vpn_table" "$RT_TABLES" 2>/dev/null; then
        logger -t "$TAG" "VPN $vpn: таблица уже есть"
    else
        get_last_fwmark_id="$(awk '/^[0-9]+/ {print $1}' "$RT_TABLES" 2>/dev/null | tail -1 || true)"
        if [ -n "$get_last_fwmark_id" ]; then
            counter_new=$((get_last_fwmark_id + 1))
        else
            counter_new=1001
        fi
        printf '%s %s\n' "$counter_new" "$vpn_table" >> "$RT_TABLES"
        logger -t "$TAG" "VPN $vpn: создана таблица $counter_new"
    fi

    sleep 1
    vpn_table_id="$(grep -w "$vpn_table" "$RT_TABLES" | awk '{print $1}' | head -n1)"
    [ -n "$vpn_table_id" ] || continue
    get_fwmark_id="0xd${vpn_table_id}"

    # rev34 (P1-2): три состояния connected-проверки. unknown (rc≠0,
    # пусто, нет curl, неожиданный формат) — сохраняем всё, очистки нет.
    _rci_query "show/interface/${vpn}/connected"
    vpn_link_up="$(printf '%s' "$_RQ_OUT" | tr -d '"' 2>/dev/null || true)"

    if [ "$_RQ_RC" -ne 0 ] || [ -z "$vpn_link_up" ]; then
        logger -t "$TAG" "VPN $vpn: состояние unknown (RCI connected: rc=${_RQ_RC}); policy, правила и списки сохранены"
        continue
    fi

    case "$vpn_link_up" in
        yes|up) ;;
        no|down)
            # Подтверждённый down: точный ответ RCI при rc=0.
            cleanup_client_vpn "$vpn"
            continue
            ;;
        *)
            logger -t "$TAG" "VPN $vpn: RCI connected неожиданный ответ «${vpn_link_up}» — состояние unknown, очистки нет"
            continue
            ;;
    esac

    # F6 (аудит v4, облегчение): два подряд sleep объединены — BusyBox
    # запускает один процесс вместо двух. Суммарная задержка 5с тут же.
    sleep 5
    # rev34 (P1-2): пустой адрес при сбое RCI — unknown, а не
    # подтверждённое отсутствие: настройка откладывается до следующего
    _rci_query "show/interface/${vpn}/address"
    vpn_ip="$(printf '%s' "$_RQ_OUT" | tr -d '"' 2>/dev/null || true)"
    if [ -z "$vpn_ip" ] || [ "$_RQ_RC" -ne 0 ]; then
        logger -t "$TAG" "VPN $vpn: адрес неизвестен/недостоверен (RCI rc=${_RQ_RC}) — настройка отложена, очистки нет"
        continue
    fi
    # rev35 (R35-2): частичное тело ответа (rc=28, «10.23.4.») прежде
    # проходило дальше и давало молча падающий route replace.
    if ! _valid_ipv4 "$vpn_ip"; then
        logger -t "$TAG" "VPN $vpn: адрес некорректного формата («${vpn_ip}») — настройка отложена, очистки нет"
        continue
    fi

    vpn_dev="$(rci_get "show/interface/${vpn}/interface-name" | tr -d '"')"
    if [ -z "$vpn_dev" ]; then
        vpn_dev="$(ip -4 addr show 2>/dev/null \
            | awk -v a="$vpn_ip" '/^[0-9]+:/{dev=$2} $1=="inet" && $2 ~ "^"a"/" {gsub(":","",dev); print dev; exit}')"
    fi
    # rev34 (P1-2): имя устройства не определено — unknown: без очистки.
    [ -n "$vpn_dev" ] || {
        logger -t "$TAG" "VPN $vpn: имя устройства не определено — настройка отложена, очистки нет"
        continue
    }

    vpn_name="$(rci_get "show/interface/${vpn}/description" | tr -d '"' | tr ' ' '_' \
        | tr -cd '[:alnum:]_' | cut -c1-8)"
    [ -n "$vpn_name" ] || vpn_name="vpn"

    # P2 (ревью 2026-10-05): ядро лимитирует имя набора ipset 31 символом
    # (IPSET_MAXNAMELEN c NUL); обновлятор добавляет суффикс "_new" (4), поэтому
    _vpn_budget=$((15 - ${#vpn}))
    if [ "$_vpn_budget" -ge 1 ] && [ "${#vpn_name}" -gt "$_vpn_budget" ]; then
        _vpn_short="$(printf '%s' "$vpn_name" | cut -c1-"$_vpn_budget")"
        logger -t keenzoo \
            "VPN set name truncated: ${vpn_name}->${_vpn_short} (${vpn})"
        vpn_name="$_vpn_short"
    fi

    if [ $((12 + ${#vpn_name} + ${#vpn})) -gt 27 ]; then
        # Очень длинные имена интерфейсов (GigabitEthernet1+): не влезает
        # даже пустое имя. Детерминированный cksum-суффикс — имя стабильно
        # между перезагрузками и повторными NDM-событиями.
        _vpn_hash="$(printf '%s' "${vpn_name}-${vpn}" | cksum \
            | cut -d' ' -f1 | cut -c1-4)"
        _vpn_hash="${_vpn_hash:-0}"
        logger -t keenzoo \
            "VPN set name hashed for ${vpn}: unblockvpn-*-h${_vpn_hash}"
        _vpn_base="vpn-$(printf '%s' "$vpn_name" | cut -c1-8)-h${_vpn_hash}"
    else
        _vpn_base="vpn-${vpn_name}-${vpn}"
    fi

    # Единая точка генерации: unblock_update.sh/unblock_ipset.sh выводят
    # имя набора из имени файла (unblock + basename), поэтому обе строки
    # ниже обязаны строиться из одного значения.
    unblockvpn="unblock${_vpn_base}"
    vpn_list="/opt/etc/unblock/${_vpn_base}.txt"

    # N2/R2-A (повторное ревью 2026-10-12): миграция legacy-списков v1.
    # Файлы, созданные версией до P2-бюджета имён (напр.
    # vpn-a1b2c3d4-Wireguard0.txt), давали наборы длиной >31 (_new),
    # ipset create молча падал, и список этого VPN не применялся никогда.
    # Для ТЕКУЩЕГО интерфейса ищем старые варианты vpn-*-${vpn}.txt,
    # которые не совпадают со штатным vpn_list, и переносим в новое имя.
    # mv официально не чистит старое имя (точно «переезд», а не копия).
    for _mig in /opt/etc/unblock/vpn-*-"${vpn}.txt"; do
        [ -f "$_mig" ] || continue
        [ "$_mig" = "$vpn_list" ] && continue
        # На всякий случай не затираем уже существующее штатное имя.
        if [ -f "$vpn_list" ]; then
            logger -t keenzoo \
                "VPN list NOT migrated: $(basename "$_mig") (target exists)"
            continue
        fi
        mv -f "$_mig" "$vpn_list" 2>/dev/null \
            && logger -t keenzoo \
                "VPN list migrated: $(basename "$_mig") -> $(basename "$vpn_list")"
    done

    # rev35 (R35-3, аудит-6 P1.1): установка policy route верифицируется,
    # а не подавляется `|| true`. Прежний отказ route/rule был невидим.
    # rev36 (F-01, аудит-7): прежняя схема этой же правки «del → add»
    # rev38 (F37-03): транзакция сериализуется mkdir-замком по таблице
    # (см. _rule_tx_lock) — параллельные запуски hook'а и конкурентные
    # rev39 (R38-03): мутации policy rule без замка не выполняются
    if _rule_tx_lock "$vpn_table_id"; then
        _rule_locked=1
    else
        _rule_locked=0
        logger -t "$TAG" \
            "VPN $vpn: НЕБЕЗОПАСНО — замок rule-транзакции table $vpn_table_id не получен — настройка policy route пропущена (повторное событие NDM восстановит)"
        continue
    fi
    _rule_had=0
    _rule_pre_rc=0
    _rule_exact_present "$get_fwmark_id" "$vpn_table_id" "$vpn_table" \
        || _rule_pre_rc=$?
    if [ "$_rule_pre_rc" = 0 ]; then
        _rule_had=1
    elif [ "$_rule_pre_rc" = 2 ]; then
        # rev39 (R38-02, аудит-10): ЛЮБОЕ неканоническое правило на
        # priority 1778 останавливает настройку набора ДО route replace:
        _rule_tx_unlock "$vpn_table_id"
        logger -t "$TAG" \
            "VPN $vpn: НЕБЕЗОПАСНО — на priority 1778 обнаружено постороннее/конфликтное правило (ожидается только «from all fwmark $get_fwmark_id lookup $vpn_table_id») — настройка policy route остановлена, правило не изменено; выполните «ip -4 rule show» и устраните конфликт"
        continue
    fi
    _rt_ok=1
    ip -4 route replace table "$vpn_table_id" default via "$vpn_ip" dev "$vpn_dev" >/dev/null 2>&1 \
        || _rt_ok=0
    if [ "$_rt_ok" = 1 ]; then
        ip -4 route show table "$vpn_table_id" 2>/dev/null | grep -q '^default' || _rt_ok=0
    fi
    # rev37 (F36-02, аудит-8): откат привязан к ФАКТУ успешного add этой
    # попыткой (_rule_added), а не к исходному отсутствию правила. Прежний
    _rule_added=0
    if [ "$_rt_ok" = 1 ]; then
        ip -4 route show table main 2>/dev/null | grep -Ev '^default' | while read -r ROUTE; do
            [ -n "$ROUTE" ] || continue
            ip -4 route replace table "$vpn_table_id" $ROUTE >/dev/null 2>&1 || true
        done
        if [ "$_rule_had" != 1 ]; then
            if ip -4 rule add fwmark "$get_fwmark_id" lookup "$vpn_table_id" priority 1778 >/dev/null 2>&1; then
                _rule_added=1
                # Верификация добавленного правила (каноническая форма).
                _rule_vrf_rc=0
                _rule_exact_present "$get_fwmark_id" "$vpn_table_id" "$vpn_table" \
                    || _rule_vrf_rc=$?
                [ "$_rule_vrf_rc" = 0 ] || _rt_ok=0
            else
                _rt_ok=0
            fi
        fi
    fi
    if [ "$_rt_ok" != 1 ]; then
        # Откат только СОБСТВЕННОГО добавления: правило, существовавшее
        # до этой попытки (_rule_had=1), и правило, которого мы не
        # добавляли (_rule_added=0), не удаляются.
        if [ "$_rule_added" = 1 ]; then
            # rev38 (F37-03): перед разрушающим del — повторная проверка.
            _rule_rb_rc=0
            _rule_exact_present "$get_fwmark_id" "$vpn_table_id" "$vpn_table" \
                || _rule_rb_rc=$?
            # rev39 (R38-02): rc=0 — правило снова присутствует (конкурент
            # вернул/тень отсутствует), rc=2 — присутствует + посторонняя
            if [ "$_rule_rb_rc" != 1 ]; then
                logger -t "$TAG" \
                    "VPN $vpn: НЕБЕЗОПАСНО — конкурентная смена состояния policy rule после провала верификации — откат добавления не выполнен"
            else
                ip -4 rule del fwmark "$get_fwmark_id" lookup "$vpn_table_id" priority 1778 >/dev/null 2>&1 || true
            fi
        fi
        _rule_tx_unlock "$vpn_table_id"
        logger -t "$TAG" "VPN $vpn: НЕБЕЗОПАСНО — policy route не установлен (route/rule отказ) — трафик списка «${vpn_name}» пойдёт через основной маршрут"
        continue
    fi
    _rule_tx_unlock "$vpn_table_id"
    ip -4 route flush cache 2>/dev/null || true

    [ -f "$vpn_list" ] || : > "$vpn_list"
    chmod 0644 "$vpn_list"

    # M2/F1 (аудит rev3): у hash-имён (vpn-<имя>-h<cksum>) последним
    # сегментом стоит не ID интерфейса, поэтому ведём sidecar-файл —
    _scside="/opt/etc/unblock/.${_vpn_base}.iface"
    if [ "${_vpn_base##*-}" != "$vpn" ]; then
        _sc_tmp="/opt/etc/unblock/.${_vpn_base}.iface.$$"
        printf '%s\n%s\n' "$vpn" "$vpn_table_id" > "$_sc_tmp" 2>/dev/null \
            && mv -f "$_sc_tmp" "$_scside" || rm -f "$_sc_tmp"
    else
        rm -f "$_scside" 2>/dev/null || true
    fi

    ipset create "$unblockvpn" hash:net family inet hashsize 1024 maxelem 65536 -exist 2>/dev/null || true

    logger -t "$TAG" "VPN $vpn ON: $vpn_name $vpn_ip via $vpn_dev"

    # F7 (аудит rev5 #8): на connected переустанавливаем ВСЕ таблицы,
    # а не только nat. MARK/CONNMARK-правила VPN-наборов живут в mangle;
    if [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ]; then
        type=iptable table=nat /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
        type=iptable table=mangle /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
        type=iptable table=filter /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
    fi
done

# ═════════════════════════════════════════════════════════════════════════
# Восстановление после смены канала (актуально для LTE/USB-модема)
# ═════════════════════════════════════════════════════════════════════════
# Все сервисы, кроме hysteria, переживают разрыв WAN сами (ленивая
# связь по первому запросу); hysteria держит QUIC-сессию сразу и при
# обрыве умирает — перезапускать было некому (init-скрипты в этом хуке
# не вызывались, 100-redirect.sh лишь снимал правила): UDP из
# hysteria.txt шёл напрямую. Поднимаются ТОЛЬКО мёртвые сервисы:
# безусловный перезапуск рвал бы рабочие соединения на каждом событии.

# Событие приходит пачками: в журнале зафиксировано до 8 срабатываний за
# минуту на одно переподключение. Без защиты сервисы перезапускались бы
# каскадом. Каталог-замок атомарен в BusyBox ash (mkdir), stale-замок
# старше 5 минут снимается.
WD_LOCK="/tmp/unblock_ifup.lockdir"
WD_STAMP="/tmp/unblock_ifup.stamp"
# Интервал больше, чем длится фоновая работа. Родитель завершается сразу
# (иначе прошивка убивает хук по таймауту) и снимает замок, поэтому от
# наложения двух фоновых веток защищает именно эта пауза: запуск пяти
# init-скриптов занимает до ~40 с (hysteria одна поднималась 17 с),
# плюс sleep 5 и переустановка правил.
WD_MIN_INTERVAL=90

if [ -d "$WD_LOCK" ]; then
    # Сначала проверяем живость владельца по pid-файлу: только время —
    # недостаточно, длительный прогон (пять init-скриптов до ~40 с плюс
    # паузы) мог бы быть ошибочно снят чужим событием. Живой владелец
    # сохраняет замок независимо от возраста; мёртвый — замок снимается
    # по прежней проверке возраста ts-файла.
    _wd_lock_pid="$(cat "$WD_LOCK/pid" 2>/dev/null || true)"
    case "$_wd_lock_pid" in
        ''|*[!0-9]*) _wd_lock_alive=0 ;;
        *)
            if kill -0 "$_wd_lock_pid" 2>/dev/null; then
                _wd_lock_alive=1
            else
                _wd_lock_alive=0
            fi
            ;;
    esac
    if [ "$_wd_lock_alive" = "1" ]; then
        exit 0
    fi

    _wd_age_ok=0
    if [ -f "$WD_LOCK/ts" ]; then
        _wd_t="$(cat "$WD_LOCK/ts" 2>/dev/null || echo 0)"
        case "$_wd_t" in ''|*[!0-9]*) _wd_t=0 ;; esac
        _wd_now="$(date +%s 2>/dev/null || echo 0)"
        [ $((_wd_now - _wd_t)) -gt 300 ] && _wd_age_ok=1
    else
        _wd_age_ok=1
    fi
    if [ "$_wd_age_ok" = "1" ]; then
        rm -rf "$WD_LOCK" 2>/dev/null || true
    else
        exit 0
    fi
fi

mkdir "$WD_LOCK" 2>/dev/null || exit 0
date +%s > "$WD_LOCK/ts" 2>/dev/null || true
echo $$ > "$WD_LOCK/pid" 2>/dev/null || true
# Замок снимается при любом выходе, включая ошибку, но только свой:
# иначе короткоживущий родитель при выходе удалил бы замок нового
# владельца. $$ в фоновых подоболочках совпадает с родителем — общий
# замок прогона снимается как и раньше.
trap 'if [ ! -f "$WD_LOCK/pid" ] \
        || [ "$(cat "$WD_LOCK/pid" 2>/dev/null)" = "$$" ]; then \
        rm -rf "$WD_LOCK" 2>/dev/null || true; \
    fi' EXIT INT TERM

# Антидребезг: не чаще одного прогона в WD_MIN_INTERVAL секунд.
_wd_now="$(date +%s 2>/dev/null || echo 0)"
if [ -f "$WD_STAMP" ]; then
    _wd_prev="$(cat "$WD_STAMP" 2>/dev/null || echo 0)"
    case "$_wd_prev" in ''|*[!0-9]*) _wd_prev=0 ;; esac
    if [ $((_wd_now - _wd_prev)) -lt "$WD_MIN_INTERVAL" ]; then
        exit 0
    fi
fi

# Есть ли вообще выход в интернет: без маршрута по умолчанию поднимать
# сервисы бессмысленно — они снова упадут. Событие «интерфейс погас»
# отсекается здесь же.
if ! ip -4 route show default 2>/dev/null | grep -q .; then
    exit 0
fi

# rev33 (P1.2): штамп антидребезга — через приватный mktemp + атомарный
# mv вместо `printf >` по фиксированному /tmp-пути (следовал symlink).
_wd_stamp_tmp="$(mktemp /tmp/.kz_vpn_stamp.XXXXXX 2>/dev/null)" || _wd_stamp_tmp=""
if [ -n "$_wd_stamp_tmp" ]; then
    printf '%s' "$_wd_now" > "$_wd_stamp_tmp" 2>/dev/null \
        && mv -f "$_wd_stamp_tmp" "$WD_STAMP" 2>/dev/null \
        || rm -f "$_wd_stamp_tmp"
fi

# Живость определяется так же, как в 100-redirect.sh: по argv[0] в /proc.
# Подстрочный поиск по всей командной строке принимал бы за живой сервис
# посторонний процесс (например "vi /opt/etc/hysteria/config.json").
wd_proc_alive() {
    _wd_p="$1"
    for _wd_d in /proc/[0-9]*; do
        # Читаем через cat: процесс может исчезнуть между раскрытием
        # маски и открытием файла, а сообщение оболочки о неудачном
        # перенаправлении "< файл" не подавляется через 2>/dev/null
        # у команды — оно попадало в журнал роутера как ошибка скрипта.
        _wd_a0="$(cat "$_wd_d/cmdline" 2>/dev/null | tr '\0' '\n' | head -1)"
        [ -n "$_wd_a0" ] || continue
        [ "${_wd_a0##*/}" = "$_wd_p" ] && return 0
    done
    return 1
}

# Отключённый в панели сервис (ENABLED=no) поднимать нельзя: это штатный
# признак того, что пользователь выключил протокол.
wd_revive() {
    _wd_init="/opt/etc/init.d/$1"
    _wd_procs="$2"

    [ -x "$_wd_init" ] || return 0
    grep -qE '^[[:space:]]*ENABLED[[:space:]]*=[[:space:]]*no' \
        "$_wd_init" 2>/dev/null && return 0
    wd_proc_alive "$_wd_procs" && return 0

    "$_wd_init" start >/dev/null 2>&1 || true
    WD_REVIVED=1
    logger -t "$TAG" "WAN up: перезапущен $1"
}

WD_REVIVED=0

# ВСЯ восстановительная работа выполняется в фоне: синхронный wd_revive
# (пять init-скриптов; hysteria одна — 17 с) не укладывался в лимит
# прошивки, ndm убивал хук («Opkg shell has been killed») посередине —
# сервис стартовал, а переустановка правил уже не выполнялась, и в
# журнале бесконечно повторялось «hysteria не запущен».
# Замок снимается в самом фоновом процессе: trap EXIT родителя сработает
# при его выходе, дочерний удалит каталог повторно — rm -rf терпим.
(
    trap '' HUP

    wd_revive S57hysteria hysteria
    wd_revive S24xray     xray
    wd_revive S22trojan   trojan
    wd_revive S65shadowsocks ss-redir
    wd_revive S35tor      tor

    # Если сервис был поднят — правила перехвата для него ещё не созданы.
    # 100-redirect.sh намеренно пропускает мёртвые сервисы (правило на
    # неслушающий порт = чёрная дыра), поэтому на момент его прошлого
    # запуска правил для лежавшего сервиса не появилось. Без повторного
    # вызова они не возникнут до следующего события прошивки.
    #
    # Пауза нужна, чтобы сервис успел открыть слушающий сокет:
    # svc_enabled проверяет живость процесса, а стартует он не мгновенно.
    if [ "$WD_REVIVED" = "1" ]; then
        sleep 5
        if [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ]; then
            type=iptable table=nat \
                /opt/etc/ndm/netfilter.d/100-redirect.sh \
                >/dev/null 2>&1 || true
            type=iptable table=mangle \
                /opt/etc/ndm/netfilter.d/100-redirect.sh \
                >/dev/null 2>&1 || true
            type=iptable table=filter \
                /opt/etc/ndm/netfilter.d/100-redirect.sh \
                >/dev/null 2>&1 || true
            logger -t "$TAG" "WAN up: правила перехвата переустановлены"
        fi
    fi
) >/dev/null 2>&1 </dev/null &

# Смена канала = новый внешний адрес: пин адресов серверов обновляется
# (пара DNS-запросов; устаревший IP рвёт туннели). unblock_update.sh
# здесь НЕ вызывается: списки от разрыва не меняются, а полный прогон
# (сотни резолвов, пересоздание 12 наборов) на «моргающем» LTE давал
# непрерывные обновления и «locked» в панели; ipset-наборы живут в
# ядре, новые адреса dnsmasq докладывает сам (ipset=/домен/набор).
# Списки обновляет штатный cron 06:00, S99unblock и кнопка панели.
# Запуск в фоне — хук не задерживает обработку события прошивкой.
(
    trap '' HUP
    # Сервисам нужно время подняться, а каналу — стабилизироваться.
    sleep 10
    # R44-5 (аудит-14, N-5): остаток F-5 — WAN-up-ветка ждёт живой цикл
    # unblock_update так же, как реакции dns_spoof_check (R42-2):
    # /tmp/unblock_update.lockdir с живым pid => ожидание до ~5 минут;
    # мёртвый/чужой замок не мешает; по таймауту refresh выполняется —
    # endpoint-pin не должен теряться. Ветка фоновая, прошивку не
    # задерживает.
    if [ -d /tmp/unblock_update.lockdir ]; then
        _uvw_waits=0
        while [ "$_uvw_waits" -lt 60 ]; do
            _uvw_lpid="$(cat /tmp/unblock_update.lockdir/pid 2>/dev/null || true)"
            if [ -z "$_uvw_lpid" ] || ! kill -0 "$_uvw_lpid" 2>/dev/null; then
                break
            fi
            if [ "$_uvw_waits" = 0 ]; then
                logger -t "$TAG" \
                    "WAN up: ожидание цикла unblock_update (pid=$_uvw_lpid)"
            fi
            sleep 5
            _uvw_waits=$((_uvw_waits + 1))
        done
        if [ "$_uvw_waits" -ge 60 ]; then
            logger -t "$TAG" \
                "unblock_update всё ещё выполняется — refresh без ожидания"
        fi
    fi
    [ -x /opt/bin/unblock_dnsmasq.sh ] \
        && /opt/bin/unblock_dnsmasq.sh >/dev/null 2>&1 || true
    logger -t "$TAG" "WAN up: endpoint pin and dnsmasq interfaces refreshed"
) >/dev/null 2>&1 </dev/null &

exit 0
