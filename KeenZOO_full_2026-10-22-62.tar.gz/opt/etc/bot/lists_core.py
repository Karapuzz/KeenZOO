# -*- coding: utf-8 -*-
"""
lists_core.py — логика списков обхода БЕЗ Flask (ревью 2026-10-12, C9)

Сюда вынесено всё, что нужно Telegram-боту для сохранения списков:
валидаторы записей, атомарная запись, parse_and_save. Раньше бот
поднимал весь generator.py ради одной функции — а тот импортирует
Flask и весь стек панели (≈15–25 МБ RAM навсегда). Теперь бот через
lists_core получает ту же parse_and_save с полным поведением, но без
веб-зависимостей. generator.py ре-экспортирует эти имена, поэтому
существующие обращения панели не меняются.

C8 (из того же ревью): валидатор домена требует минимум ДВЕ метки и
TLD длиной не менее 2 символов — как shell-функция is_domain_core
в скриптах обхода. Однословные записи («localhost», «router»)
принимались раньше ботом, а shell их молча игнорировал: в панели
домен «есть», в стейте — нет.
"""

import ipaddress
import os
import re
import tempfile
import threading
import fcntl
import hashlib
import time
from contextlib import contextmanager

import bot_config as config

UNBLOCK_DIR = config.paths.get(
    'unblock_dir', '/opt/etc/unblock').rstrip('/')

BYPASS_FILES = {
    key: path
    for key, path in config.list_files.items()
    if key != 'bot'}

BOT_BYPASS_FILE = config.list_files['bot']

_GS = getattr(config, 'generator_settings', {})
MAX_LIST_LINES = int(_GS.get('max_list_lines', 5000))


def _clean_entry(entry):
    return entry.split('#')[0].strip()


def _validate_cidr(entry):
    m = re.match(
        r'^(\d{1,3})\.(\d{1,3})\.'
        r'(\d{1,3})\.(\d{1,3})'
        r'/(\d{1,2})$', entry)
    if not m:
        return False
    # M6/F4 (аудит rev4 #6): паритет с shell is_cidr (common.sh) —
    # октет с ведущим нулём («192.168.001.0/24») там отклоняется, а
    # Python принимал: строка проходила панель и потом молча
    # отбрасывалась генератором (правило исчезало без диагностики).
    _lz = m.groups()
    if any(len(g) > 1 and g[0] == '0' for g in _lz[:4]):
        return False
    o = [int(m.group(i))
         for i in range(1, 5)]
    p = int(m.group(5))
    return (all(x <= 255 for x in o)
            and 0 <= p <= 32)


def _validate_ip(entry):
    m = re.match(
        r'^(\d{1,3})\.(\d{1,3})\.'
        r'(\d{1,3})\.(\d{1,3})$', entry)
    if not m:
        return False
    # M6/F4 (аудит rev4 #6): паритет с shell is_ip (common.sh) —
    # октеты с ведущими нулями запрещены (см. _validate_cidr выше).
    _lz = m.groups()
    if any(len(g) > 1 and g[0] == '0' for g in _lz):
        return False
    return all(
        int(m.group(i)) <= 255
        for i in range(1, 5))


# F8 (аудит-6 M-4): паритет python-валидатора с runtime-политикой
# cidr_policy_ok (common.sh). Раньше панель принимала любой синтаксис —
# «0.0.0.0/0» или «8.0.0.0/5» в статическом списке молча исчезали в
# генераторе (shell их отбрасывал), у пользователя «записал» ≠ «работает».
_DENY_NETS = (
    (0, 0, 0, 0, 8), (10, 0, 0, 0, 8), (100, 64, 0, 0, 10),
    (127, 0, 0, 0, 8), (169, 254, 0, 0, 16), (172, 16, 0, 0, 12),
    (192, 0, 0, 0, 16), (192, 168, 0, 0, 16), (198, 18, 0, 0, 15),
    (198, 51, 100, 0, 24), (203, 0, 113, 0, 24), (224, 0, 0, 0, 3),
)


def _ipv4_int(o):
    return ((o[0] * 256 + o[1]) * 256 + o[2]) * 256 + o[3]


def _cidr_range_lohi(o, p):
    size = 1 << (32 - p)
    lo = (_ipv4_int(o) // size) * size
    return lo, lo + size - 1


def _range_overlaps_net(lo, hi, net4, p):
    nlo, nhi = _cidr_range_lohi(net4, p)
    return lo <= nhi and hi >= nlo


def is_public_cidr(o, p):
    """Весь диапазон CIDR избегает приватных/служебных сетей."""
    lo, hi = _cidr_range_lohi(o, p)
    return not any(
        _range_overlaps_net(lo, hi, n[:4], n[4])
        for n in _DENY_NETS)


def cidr_hits_multicast(o, p):
    """Диапазон пересекается с 224.0.0.0/3 (мультикаст и резерв)."""
    lo, hi = _cidr_range_lohi(o, p)
    return _range_overlaps_net(lo, hi, (224, 0, 0, 0), 3)


def cidr_policy_ok_py(basename, cl):
    """None — допустимо; строка — причина отказа (как runtime политика)."""
    if '/' in cl and _validate_cidr(cl):
        o = [int(x) for x in cl.split('/')[0].split('.')]
        p = int(cl.split('/')[1])
        if basename.startswith('vpn-'):
            if cidr_hits_multicast(o, p):
                return (
                    "пересекает мультикаст-диапазон 224.0.0.0/3 — "
                    "углублять за его пределы туннель всё равно не умеет")
            return None
        if not is_public_cidr(o, p):
            return (
                "диапазон не целиком публичный — суммарный список "
                "обхода его отбрасывает; делите на публичные куски "
                "или прокидывайте через vpn-файл")
        return None
    # F9 (аудит rev10 M-2): одиночные IP шли мимо политики — панель
    # «принимала» адрес, который runtime (is_public_ipv4, обе фазы
    # «одиночный IP кладёт только unblock_ipset.sh») молча отбрасывал
    # у ЛЮБОГО набора. Паритет: только публичные одиночные адреса;
    # приватный хост в VPN — однохостовым CIDR /32.
    if _validate_ip(cl):
        o = [int(x) for x in cl.split('.')]
        if not is_public_ipv4_py(o):
            return (
                "приватный/служебный адрес — обход его отбрасывает у "
                "любого набора; для приватного host-маршрута в VPN "
                "используйте однохостовый CIDR, например 10.0.0.1/32")
    return None


def is_public_ipv4_py(o):
    """Публичность одиночного IPv4 (паритет common.sh:is_public_ipv4)."""
    o1, o2, o3 = o[:3]
    if o1 in (0, 10, 127):
        return False
    if o1 == 100 and 64 <= o2 <= 127:
        return False
    if o1 == 169 and o2 == 254:
        return False
    if o1 == 172 and 16 <= o2 <= 31:
        return False
    if o1 == 192 and o2 in (0, 168):
        return False
    if o1 == 198 and (o2 in (18, 19) or (o2 == 51 and o3 == 100)):
        return False
    if (o1, o2, o3) == (203, 0, 113):
        return False
    if (o1, o2, o3) == (192, 88, 99):
        # R42-7 (аудит-12, F-12): RFC 7526 (deprecated 6to4 anycast) —
        # паритет с common.sh:is_public_ipv4.
        return False
    return o1 < 224


# Структурно-«доменная» строка (для C8-пояснения в ошибке).
RE_DOMAIN_LIKE = re.compile(r'^[a-zA-Z0-9.*\-]+$')

_DOMAIN_STRUCT = re.compile(
    r'^(\*\.)?[a-zA-Z0-9]'
    r'([a-zA-Z0-9\-]*[a-zA-Z0-9])?'
    r'(\.[a-zA-Z0-9]'
    r'([a-zA-Z0-9\-]*'
    r'[a-zA-Z0-9])?)*$')


_LABEL_RE = re.compile(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]*'
                       r'[a-zA-Z0-9])?$')


def _validate_domain_core(host):
    """Точный паритет с shell is_domain_core (common.sh:91–116):

    длина имени ≤253; ≥2 метки; метка 1..63, без дефисов по краям,
    символы a-z0-9-; последняя метка не полностью цифровая.
    K4 (повторный аудит): промежуточная версия C8 требовала ещё и
    TLD ≥2 символов — это расходилось с shell («a.b» shell принимает).
    Теперь вердикты совпадают по всем полям таблицы аудита.
    """
    # R4 (аудит rev3): shell normalize_domain_target снимает
    # РОВНО одну завершающую точку (sed 's/\.$//'), а rstrip('.')
    # снимал бы все — «example.com..» стал бы валидным в панели.
    if host.endswith('.'):
        host = host[:-1]
    if not (1 <= len(host) <= 253):
        return False
    labels = host.split('.')
    if len(labels) < 2:
        return False
    for lb in labels:
        if not (1 <= len(lb) <= 63):
            return False
        if not _LABEL_RE.match(lb):
            return False
    if labels[-1].isdigit():
        return False
    return True


def _validate_entry(ce):
    if '/' in ce:
        return (('cidr', ce)
                if _validate_cidr(ce)
                else None)
    if _validate_ip(ce):
        return ('ip', ce)
    if ce.startswith('#'):
        return None
    host = (ce[2:]
            if ce.startswith('*.')
            else ce)
    # shell normalize_domain_target снимает хвостовую точку и
    # приводит регистр — делаем то же самое при проверке.
    if ' ' in host:
        return None
    if _validate_domain_core(host.lower()):
        return ('domain', ce)
    return None


def read_file_text(fp):
    if not os.path.exists(fp):
        return ''
    with open(fp, 'r',
              encoding='utf-8') as f:
        return f.read().rstrip('\n\r')


def _atomic_write_text(filepath, text):
    # FB-52 (аудит-29, K54-2): tmp уникален на ВЫЗОВ (mkstemp), а не
    # по PID процесса. Панель работает с threaded=True, и все потоки
    # делили один .{base}.{pid}.tmp: finally одного потока удалял tmp
    # другого (os.replace → FileNotFoundError → HTTP 500), а наложение
    # самих записей рвало содержимое. Замер до правки: 20 параллельных
    # POST /api/lookup-add — 13×500 и 1 запись из 20 в файле.
    directory = os.path.dirname(filepath)
    base = os.path.basename(filepath)
    # FB-67 (аудит-32, R55-06): возрастная уборка сирот. Шаблон tmp
    # lists_core (.{base}.<random>.tmp) не совпадает с шаблоном
    # уборщика utils (.{basename}.tmp_), поэтому после SIGKILL/потери
    # питания в момент записи файлы оставались навсегда (замер: 3
    # kill -9 → 3 сироты, уборщик не тронул ни один). Убираем только
    # свои точные шаблоны старше часа — активный tmp свежего writer'а
    # не затрагивается.
    try:
        _st_now = time.time()
        for _st_name in os.listdir(directory or '.'):
            if not (_st_name.startswith(f'.{base}.')
                    and _st_name.endswith('.tmp')):
                continue
            _st_path = os.path.join(directory, _st_name)
            try:
                if _st_now - os.stat(_st_path).st_mtime > 3600:
                    os.unlink(_st_path)
            except OSError:
                pass
    except OSError:
        pass
    fd, tmp = tempfile.mkstemp(
        prefix=f'.{base}.', suffix='.tmp', dir=directory)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        # mkstemp создаёт 0600; списки читаются root-процессами
        # проекта, но сохраняем привычные права (режим существующего
        # файла, иначе 0644 — как давал open('w') при umask 022).
        try:
            _mode = os.stat(filepath).st_mode & 0o777
        except OSError:
            _mode = 0o644
        os.chmod(tmp, _mode)
        os.replace(tmp, filepath)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            # Best-effort cleanup: исходная ошибка записи важнее
            # ошибки удаления временного файла (после успешного
            # replace tmp уже не существует — гасится и это).
            pass


# FB-52 (аудит-29, K54-2): сериализация read-modify-write списков
# внутри процесса (панель threaded=True). RLock — на случай вложенных
# вызовов. Межпроцессная гонка (панель + бот — разные процессы) не
# сериализуется потоковой блокировкой: правки бота идут через
# parse_and_save (полная замена текста), атомарность каждой записи
# даёт mkstemp+replace, «последний писатель» для редактора списка —
# штатная семантика полной замены.
_LISTS_WRITE_LOCK = threading.RLock()


@contextmanager
def _list_write_guard(filepath):
    """FB-63 (аудит-32, R55-01): единая сериализация записи списков.

    Прежде lock стоял только в /api/lookup-add: редактор /list/<lk>
    (parse_and_save) и Telegram-бот (save_via_generator) писали без
    сериализации, а бот — вообще отдельным процессом, который
    внутрипроцессный RLock не останавливает (замер отчёта r55: потеря
    записи редактора при гонке с add, потеря панельной записи при
    гонке с ботом). Guard = внутрипроцессный _LISTS_WRITE_LOCK +
    межпроцессный flock на lock-файл рядом со списком (dot-файл в
    каталоге списков: пути у панели и бота совпадают). Держится ВЕСЬ
    read-modify-write вызова, а не только os.replace. Отдельный
    конфликт устаревшей вкладки редактора решается revision-полем
    (generator), этот lock его не заменяет.
    """
    with _LISTS_WRITE_LOCK:
        _lw_dir = os.path.dirname(filepath) or '.'
        _lw_lock = os.path.join(
            _lw_dir,
            '.listwrite.' + os.path.basename(filepath) + '.lock')
        _lw_fd = -1
        try:
            _lw_fd = os.open(
                _lw_lock, os.O_CREAT | os.O_WRONLY, 0o600)
            fcntl.flock(_lw_fd, fcntl.LOCK_EX)
            yield
        finally:
            if _lw_fd >= 0:
                try:
                    fcntl.flock(_lw_fd, fcntl.LOCK_UN)
                finally:
                    os.close(_lw_fd)


def _read_blocks(fp):
    if not os.path.exists(fp):
        return []
    secs = []
    cc = None
    ce = []
    with open(fp, 'r',
              encoding='utf-8') as f:
        for raw in f:
            s = (raw.rstrip('\n')
                 .rstrip('\r').strip())
            if not s:
                if ce:
                    secs.append((cc, ce))
                    cc = None
                    ce = []
                continue
            if s.startswith('#'):
                if ce:
                    secs.append((cc, ce))
                    ce = []
                elif cc is not None:
                    # N-3 (аудит-13): комментарий без записей не
                    # выбрасываем — иначе правка списка в боте молча
                    # стирает заголовки и хвостовые пометки.
                    secs.append((cc, []))
                cc = s[1:].strip()
            else:
                ce.append(s)
    if ce or cc is not None:
        secs.append((cc, ce))
    return secs


def _all_bypass_filepaths():
    fps = list(BYPASS_FILES.values())
    try:
        for n in os.listdir(UNBLOCK_DIR):
            if (n.startswith('vpn-')
                    and n.endswith('.txt')):
                fps.append(os.path.join(
                    UNBLOCK_DIR, n))
    except OSError:
        # Каталог может отсутствовать на самой ранней стадии установки.
        pass
    return fps


def _build_global_bypass_index(
        exclude_filepath=None):
    gm = {}
    for fp in _all_bypass_filepaths():
        if (exclude_filepath
                and os.path.realpath(fp)
                == os.path.realpath(
                    exclude_filepath)):
            continue
        fl = os.path.splitext(
            os.path.basename(fp))[0]
        for comment, entries in (
                _read_blocks(fp)):
            for entry in entries:
                c = _clean_entry(entry)
                if c and c not in gm:
                    gm[c] = {
                        'file': fl,
                        'comment': comment}
    return gm


def _optimize_networks(sections):
    an = []
    nte = {}
    for _c, entries in sections:
        for entry in entries:
            cl = _clean_entry(entry)
            r = _validate_entry(cl)
            if r and r[0] in ('ip', 'cidr'):
                try:
                    net = ipaddress.ip_network(
                        cl if '/' in cl
                        else cl + '/32',
                        strict=False)
                    if net not in nte:
                        an.append(net)
                        nte[net] = entry
                except ValueError:
                    pass
    if len(an) < 2:
        return sections, []
    oc = len(nte)
    col = set(
        ipaddress.collapse_addresses(an))
    cc = len(col)
    if cc >= oc:
        return sections, []
    os_set = set(nte.keys())
    surv = os_set & col
    nfm = col - os_set
    del an, os_set
    rt = 0
    ns = []
    bi = 0
    bd = 0
    for idx, (comment, entries) in (
            enumerate(sections)):
        ne = []
        sr = 0
        for entry in entries:
            cl = _clean_entry(entry)
            r = _validate_entry(cl)
            if r and r[0] in ('ip', 'cidr'):
                try:
                    net = ipaddress.ip_network(
                        cl if '/' in cl
                        else cl + '/32',
                        strict=False)
                    if net in surv:
                        ne.append(entry)
                    else:
                        sr += 1
                except ValueError:
                    ne.append(entry)
            else:
                ne.append(entry)
        rt += sr
        ns.append((comment, ne))
        if sr > bd:
            bd = sr
            bi = idx
    del surv, nte
    if nfm:
        merged = []
        for net in sorted(nfm):
            merged.append(
                str(net.network_address)
                if net.prefixlen == 32
                else str(net))
        if bd > 0:
            c, e = ns[bi]
            ns[bi] = (c, e + merged)
        else:
            ns.append((
                'Оптимизированные', merged))
    rep = []
    saved = oc - cc
    if rt > 0:
        rep.append(
            f"\U0001f4e6 CIDR: "
            f"удалено {rt}")
    if nfm:
        rep.append(
            f"\U0001f4e6 CIDR: "
            f"создано {len(nfm)}")
    if saved > 0:
        rep.append(
            f"\U0001f4e6 {oc}"
            f"\u2192{cc} "
            f"(\u2248"
            f"{saved*100//oc}%)")
    return ns, rep


def _sort_key(entry):
    cl = _clean_entry(entry)
    try:
        net = ipaddress.ip_network(
            cl, strict=False)
        return (
            1,
            net.network_address.packed,
            net.prefixlen)
    except ValueError:
        pass
    try:
        addr = ipaddress.ip_address(cl)
        return (1, addr.packed, 32)
    except ValueError:
        pass
    return (0, cl.lower().encode(), 0)


def parse_and_save(
        filepath, text,
        skip_global_dedup=False):
    # FB-63 (аудит-32, R55-01): весь разбор+запись — под общим guard
    # списков (RLock + flock): редактор панели, бот и lookup-add
    # сериализованы и внутри процесса, и между процессами.
    with _list_write_guard(filepath):
        return _parse_and_save_impl(
            filepath, text, skip_global_dedup)


class ListRevisionConflict(RuntimeError):
    """FB-70 (аудит-33, K58-1/R58-02): устаревшая вкладка редактора.

    Содержимое файла на диске не совпадает с ревизией, которую форма
    принесла со страницы (файл успел изменить бот, вторая вкладка или
    lookup-add). Затирать чужую правку устаревшим полным текстом
    нельзя — маршрут обязан отказать и попросить перечитать страницу.
    """


def _list_content_rev(filepath):
    """FB-70 (аудит-33, K58-1/R58-02): ревизия содержимого списка.

    SHA-256 байтов файла (не mtime_ns: mtime меняется от касаний,
    которых содержимое не меняло, и НЕ меняется при записи того же
    текста за ту же наносекунду). Отсутствующий файл — ''.
    """
    try:
        h = hashlib.sha256()
        with open(filepath, 'rb') as f:
            for chunk in iter(
                    lambda: f.read(8192), b''):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return ''


def parse_and_save_if_revision(
        filepath, text, expected_rev,
        skip_global_dedup=False):
    """FB-70 (аудит-33, K58-1/R58-02): атомарный compare-and-write.

    Прежняя схема имела два окна: (1) rev-проверка в маршруте по
    os.stat ДО взятия guard — между проверкой и записью файл успевал
    измениться (TOCTOU); (2) `if _rev:` пропускал формы с пустым rev
    и молча затирал правки. Теперь guard берётся ровно один раз,
    сравнение ревизии и запись — внутри одной критической секции;
    пустой/несовпавший rev при существующем файле — конфликт (строгий
    режим), отсутствие и пустота файла различаются пустой ревизией.
    Внешний guard поверх недопустим: nested flock по тому же lock-файлу
    на другом fd = self-deadlock, поэтому public-helper именно такой.
    """
    with _list_write_guard(filepath):
        if _list_content_rev(filepath) != expected_rev:
            raise ListRevisionConflict(filepath)
        return _parse_and_save_impl(
            filepath, text, skip_global_dedup)


def _parse_and_save_impl(
        filepath, text,
        skip_global_dedup=False):
    rb = os.path.realpath(UNBLOCK_DIR)
    rp = os.path.realpath(filepath)
    if not rp.startswith(rb + os.sep):
        raise ValueError("Путь")
    lines = text.split('\n')
    if len(lines) > MAX_LIST_LINES:
        raise ValueError(
            f"Строк: {len(lines)}")
    os.makedirs(UNBLOCK_DIR, exist_ok=True)
    secs = []
    cc = None
    ce = []
    errors = []
    dups = []
    seen = {}
    gs = (
        {} if skip_global_dedup
        else _build_global_bypass_index(
            exclude_filepath=filepath))
    for line in lines:
        s = line.strip()
        if not s:
            if ce:
                secs.append((cc, ce))
                cc = None
                ce = []
            continue
        if s.startswith('#'):
            if ce:
                secs.append((cc, ce))
                ce = []
            elif cc is not None:
                # N-3 (аудит-13): комментарий без записей сохраняется.
                secs.append((cc, []))
            cc = s[1:].strip()
        else:
            cl = _clean_entry(s)
            if not cl:
                continue
            r = _validate_entry(cl)
            if r is None:
                # C8: однословная запись (без точки) поясняется
                # прямо в ошибке — раньше она принималась, а shell
                # её молча отбрасывал, и списки «расходились».
                hint = (
                    RE_DOMAIN_LIKE.match(cl)
                    and '.' not in cl
                    and '/' not in cl
                    and not _validate_ip(cl))
                if hint:
                    errors.append(
                        f"⚠️ {cl} "
                        "(нужна точка: домен из "
                        "одной метки обход "
                        "игнорирует)")
                else:
                    errors.append(
                        f"⚠️ {cl}")
                continue
            # F8 (аудит-6 M-4): после синтаксиса — политика набора.
            _pp_reason = cidr_policy_ok_py(
                os.path.basename(filepath), cl)
            if _pp_reason is not None:
                errors.append(
                    f"⚠️ {cl} ({_pp_reason})")
                continue
            if cl in seen:
                c = seen[cl]
                dups.append(
                    f"⚠️ {cl}"
                    + (f" (#{c})"
                       if c else ""))
                continue
            if cl in gs:
                info = gs[cl]
                dups.append(
                    f"⚠️ {cl}"
                    f" ({info['file']}.txt"
                    + (f", #{info['comment']}"
                       if info['comment']
                       else "")
                    + ")")
                continue
            seen[cl] = cc
            ce.append(s)
    if ce or cc is not None:
        secs.append((cc, ce))
    del seen, gs
    secs, cr = _optimize_networks(secs)
    out = []
    cd = ci = cc2 = 0
    # R46-2 (аудит-16): рендер строго по порядку файла; пустая строка —
    # только перед блоком, которому предшествовал блок с записями.
    # Прежде named-секции сортировались по алфавиту, а безымянные записи
    # сгребались в конец: заголовки разделов перемещались, «висящий»
    # хвостовой комментарий становился шапкой. Сортировка записей внутри
    # блока (R42-6), дедуп и политика CIDR не меняются.
    _prev = False
    for comment, entries in secs:
        if comment is not None:
            if out and _prev:
                out.append('')
            out.append(f'# {comment}')
        elif out and _prev:
            out.append('')
        for entry in sorted(
                entries, key=_sort_key):
            out.append(entry)
            cl = _clean_entry(entry)
            r = _validate_entry(cl)
            if r:
                if r[0] == 'cidr':
                    cc2 += 1
                elif r[0] == 'ip':
                    ci += 1
                else:
                    cd += 1
        _prev = bool(entries)
    _atomic_write_text(
        filepath,
        '\n'.join(out) + '\n'
        if out else '')
    return {
        'total': cd + ci + cc2,
        'domains': cd, 'ips': ci,
        'cidr': cc2, 'errors': errors,
        'duplicates': dups,
        'cidr_report': cr,
    }
