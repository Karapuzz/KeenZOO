#!/usr/bin/env python3
# verify43_ext.py — поведенческий верификатор аудита-43 (r70, post-fix):
#   A. FB-126: stale-running больше не блокирует retry
#   B. FB-127: сбой запуска пишет error; живой pid даёт честный 409
#   C. FB-129(A): операторские env-переменные доходят до updater'а
#   D. FB-128: статические ARP-записи (0x6) видны в устройствах
import base64, json, os, shutil, subprocess, sys, tempfile, time

# FB-179 (аудит-46, B-R79-05): корень проверяемого дерева — первый
# аргумент (по умолчанию /home/user/KeenZOO); изолированная копия bot/
# с тестовыми кредами — во временном каталоге. Прежде корень и копия
# были жёстко зашиты (/home/user/KeenZOO, /tmp/a43x) и каталог даже не
# удалялся перед копированием.
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/user/KeenZOO'
# FB-184 (аудит-47, B-R80-05): временные каталоги (копия bot/ и
# фикстуры) убираются при выходе, а секрет панели читается/пишется в
# копии — не /opt/etc/bot/.secret_key целевого устройства.
_TMPDIR = tempfile.mkdtemp(prefix='verify43x_')
import atexit
atexit.register(shutil.rmtree, _TMPDIR, ignore_errors=True)
B = os.path.join(_TMPDIR, 'bot')
shutil.copytree(os.path.join(ROOT, 'opt/etc/bot'), B,
                ignore=shutil.ignore_patterns('__pycache__'))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username': lines[i] = "web_username = 'admin'"
    elif k == 'web_password': lines[i] = "web_password = 'testpass'"
    elif ("'secret_file':" in ln
            and '/opt/etc/bot/.secret_key' in ln):
        lines[i] = "    'secret_file': %r," % os.path.join(
            B, '.secret_key')
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g
# FB-184: тестовая копия — единственный источник модулей (generator.py
# при импорте вставляет '/opt/etc/bot' в начало sys.path).
sys.path[:] = [p2 for p2 in sys.path if p2 != '/opt/etc/bot']

_p = [0]; _f = [0]
def ok(m): _p[0] += 1; print('[OK]  ', m)
def bad(m): _f[0] += 1; print('[FAIL]', m)

D = tempfile.mkdtemp(prefix='a43x_')
atexit.register(shutil.rmtree, D, ignore_errors=True)  # FB-184
g.UPDATE_STATUS_FILE = os.path.join(D, 'status.json')
g.UPDATE_LOG_FILE = os.path.join(D, 'update.log')
g.LOCK_DIR = os.path.join(D, 'lock')
c = g.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}

_oex, _och, _op = os.path.exists, os.chmod, subprocess.Popen
os.path.exists = lambda p: (True if p == '/opt/bin/unblock_update.sh' else _oex(p))
os.chmod = lambda p, m: (None if p == '/opt/bin/unblock_update.sh' else _och(p, m))

def set_status(st, ts, msg=''):
    with open(g.UPDATE_STATUS_FILE, 'w') as f:
        json.dump({'status': st, 'ts': ts, 'message': msg}, f)

# ── A. FB-126: API помечает stale; JS-блокировка учитывает stale ──
set_status('running', int(time.time()) - 3600)
time.sleep(1.05)  # TTL снапшота
j = c.get('/api/dashboard', headers=H).get_json()
up = j.get('update', {})
src = open(B + '/generator.py', encoding='utf-8').read()
js_ok = ("&&!d.update.stale" in src and "var staleUpd" in src
         and 'Обновление зависло' in src)
a_ok = (up.get('status') == 'running' and up.get('stale') is True
        and js_ok)
if a_ok:
    ok('A. FB-126: старый running → /api/dashboard отдаёт stale=true; JS блокирует кнопки только при running&&!stale, hero/лента/виджет показывают «Обновление зависло» и кнопка повтора доступна — UI-тупик устранён')
else:
    bad(f'A. stale={up.get("stale")} js={js_ok}')

# ── B. FB-127 + FB-158: живой СВОЙ pid → 409-ветка; Popen-сбой →
#    error-статус. FB-158 (аудит-45, R77-03): «свой» = unblock_update.sh
#    в /proc/<pid>/cmdline (exec -a); getpid() теперь законно идёт
#    дальше — живой ЧУЖОЙ pid = переиспользованный, lock снимается
#    (полная матрица фикстур — f47 Z53-4).
os.makedirs(g.LOCK_DIR, exist_ok=True)
set_status('running', int(time.time()) - 3600)
_own = _op(['bash', '-c', 'exec -a unblock_update.sh sleep 30'])
time.sleep(0.1)
with open(os.path.join(g.LOCK_DIR, 'pid'), 'w') as f:
    f.write(str(_own.pid))
dup = True
msg = ''
try:
    g.apply_unblock_async()
except RuntimeError as e:
    dup = False
    msg = str(e)
b1 = (not dup and 'ещё выполняется' in msg
      and json.load(open(g.UPDATE_STATUS_FILE))['status'] == 'running'
      and os.path.isdir(g.LOCK_DIR))
_own.terminate(); _own.wait()
class _Boom:
    def __init__(self, *a, **k): raise OSError('exec format error')
subprocess.Popen = _Boom
set_status('idle', 0)
try:
    g.apply_unblock_async()
except OSError:
    pass
subprocess.Popen = _op
st = json.load(open(g.UPDATE_STATUS_FILE))
b2 = st['status'] == 'error' and 'запуск не удался' in st['message']
if b1 and b2:
    ok('B. FB-127/158: живой СВОЙ pid (cmdline unblock_update.sh) при просроченном статусе — RuntimeError «ещё выполняется» (роут → 409), статус/lock не тронуты; Popen-сбой — атомарный error-статус с диагнозом; ложный running невозможен')
else:
    bad(f'B. pid409={b1} popen_error={b2}')

# ── C. FB-129(A): env-наследование ──
os.environ['KEENZOO_TEST_OVERRIDE'] = '42'
captured = {}
class _PopenCap:
    def __init__(self, argv, **k):
        captured['argv'] = argv; captured['env'] = k.get('env')
subprocess.Popen = _PopenCap
set_status('idle', 0)
g.apply_unblock_async()
subprocess.Popen = _op
del os.environ['KEENZOO_TEST_OVERRIDE']
env = captured.get('env') or {}
c_ok = ('KEENZOO_TEST_OVERRIDE' in env
        and all(k in env for k in ('KZ_STATUS_FILE', 'KZ_TMP_STATUS',
                                   'KZ_SCRIPT', 'KZ_ONLY'))
        and env['PATH'].startswith('/opt')
        and len(captured.get('argv', [])) == 3)
if c_ok:
    ok('C. FB-129(A): env={**os.environ, PATH, KZ_*} — операторские KEENZOO_*, http_proxy, TZ, HOME доходят до updater\'а; argv строго 3 элемента (FB-121 сохранён)')
else:
    bad(f'C. env-наследование: {c_ok}')

# ── D. FB-128: статические ARP ──
arp = os.path.join(D, 'arp')
open(arp, 'w').write(
    'IP address       HW type     Flags       HW address            Mask     Device\n'
    '192.168.1.76     0x1         0x2         aa:bb:cc:dd:ee:01    *        br0\n'
    '192.168.1.50     0x1         0x6         aa:bb:cc:dd:ee:07    *        br0\n'
    '192.168.1.99     0x1         0x0         aa:bb:cc:dd:ee:03    *        br0\n'
    'мусорная-строка\n')
leases = os.path.join(D, 'leases')
open(leases, 'w').write(
    '1792900000 aa:bb:cc:dd:ee:01 192.168.1.76 iphone-elena 01:aa:bb:cc:dd:ee:01\n')
dev = g._dash_devices(lease_paths=[leases], arp_path=arp)
ips = [d['ip'] for d in dev['top']]
d_ok = (dev['count'] == 2 and '192.168.1.76' in ips
        and '192.168.1.50' in ips and '192.168.1.99' not in ips
        and dev['top'][0]['name'] == 'iphone-elena')
if d_ok:
    ok('D. FB-128: бит ATF_COM: динамическая 0x2 и статическая 0x6 в карточке (count=2), incomplete 0x0 и мусор мимо, имя из lease сохранено')
else:
    bad(f'D. count={dev["count"]} ips={ips}')

print(f'═══ VERIFY43-EXT (post-fix) ИТОГ: PASS={_p[0]} FAIL={_f[0]} ═══')
sys.exit(0 if _f[0] == 0 else 1)
