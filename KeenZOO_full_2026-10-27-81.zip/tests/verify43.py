#!/usr/bin/env python3
# verify43.py — поведенческий стенд аудита-43 (r69): дашборд-маршруты,
# положительный CSRF-путь, 409/500-контракты, конкурентность, /proc-устойчивость.
import base64, json, os, shutil, sys, threading, time, re, tempfile

# FB-179 (аудит-46, B-R79-05): корень проверяемого дерева — первый
# аргумент (по умолчанию /home/user/KeenZOO); изолированная копия bot/
# с тестовыми кредами — во временном каталоге. Прежде требовался
# вручную подготовленный /tmp/a43 — опубликованный скрипт падал на
# импорте (ModuleNotFoundError) в любом другом окружении.
ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/user/KeenZOO'
# FB-184 (аудит-47, B-R80-05): временные каталоги убираются при выходе
# (прежде mkdtemp-каталоги оставались после прогона), а секрет панели
# читается/пишется в изолированной копии — не
# /opt/etc/bot/.secret_key целевого устройства.
_TMPDIR = tempfile.mkdtemp(prefix='verify43_')
import atexit
atexit.register(shutil.rmtree, _TMPDIR, ignore_errors=True)
B = os.path.join(_TMPDIR, 'bot')
shutil.copytree(os.path.join(ROOT, 'opt/etc/bot'), B,
                ignore=shutil.ignore_patterns('__pycache__'))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
    elif ("'secret_file':" in ln
            and '/opt/etc/bot/.secret_key' in ln):
        lines[i] = "    'secret_file': %r," % os.path.join(
            B, '.secret_key')
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g
# FB-184: тестовая копия — единственный источник модулей (generator.py
# при импорте вставляет '/opt/etc/bot' в начало sys.path — на хосте с
# реальным /opt это затеняло бы копию).
sys.path[:] = [p for p in sys.path if p != '/opt/etc/bot']

_p = [0]; _f = [0]
def ok(m): _p[0] += 1; print('[OK]  ', m)
def bad(m): _f[0] += 1; print('[FAIL]', m)

c = g.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode(),
     'Origin': 'http://localhost'}

# ── 1. Положительный CSRF-путь /dash/update-lists (кнопка дашборда) ──
html = c.get('/', headers=H).data.decode()
mt = re.search(r'<meta name="kz-csrf" content="([^"]+)"', html)
tok = mt.group(1) if mt else ''
calls = []
def _fake_apply(only_sets=''):
    calls.append(only_sets)
g.apply_unblock_async = _fake_apply
r = c.post('/dash/update-lists', data={'csrf_token': tok}, headers=H)
j = r.get_json() if r.status_code == 200 else {}
ok1 = r.status_code == 200 and j.get('started') is True and calls == ['']
(r1s, j1) = (r.status_code, j)
# 409: RuntimeError (уже идёт)
def _busy(only_sets=''):
    raise RuntimeError('Уже идёт (42с).')
g.apply_unblock_async = _busy
r409 = c.post('/dash/update-lists', data={'csrf_token': tok}, headers=H)
j409 = r409.get_json()
ok2 = (r409.status_code == 409 and j409.get('started') is False
       and isinstance(j409.get('message'), str))
# 500: прочее исключение
def _boom(only_sets=''):
    raise OSError('boom')
g.apply_unblock_async = _boom
r500 = c.post('/dash/update-lists', data={'csrf_token': tok}, headers=H)
j500 = r500.get_json()
ok3 = (r500.status_code == 500 and j500.get('started') is False)
if ok1 and ok2 and ok3:
    ok('POST /dash/update-lists: валидный csrf_token → 200 {started:true}+вызов apply_unblock_async(); RuntimeError → 409 JSON {started:false,message}; иное → 500 JSON (контракт кнопки дашборда)')
else:
    bad(f'CSRF-путь: ok1={ok1}(rc={r1s}) 409={ok2}(rc={r409.status_code}) 500={ok3}(rc={r500.status_code})')
g.apply_unblock_async = _fake_apply

# ── 2. /api/update-status: форма, ожидаемая JS (st.status) ──
ru = c.get('/api/update-status', headers=H)
ju = ru.get_json() if ru.status_code == 200 else {}
if ru.status_code == 200 and isinstance(ju, dict) and 'status' in ju:
    ok(f'/api/update-status: 200, статус={ju.get("status")!r}, ключи={sorted(ju.keys())} — JS-контракт st.status/ст.timeout соблюдён')
else:
    bad(f'/api/update-status: rc={ru.status_code} keys={list(ju)}')

# ── 3. Конкурентность: 8 потоков × 12 поллов /api/dashboard + 4 рендера '/' ──
errs = [0]
def hammer():
    cc = g.app.test_client()
    for _ in range(12):
        rr = cc.get('/api/dashboard', headers=H)
        if rr.status_code != 200:
            errs[0] += 1
def render():
    cc = g.app.test_client()
    for _ in range(4):
        rr = cc.get('/', headers=H)
        if rr.status_code != 200 or b'dashRoot' not in rr.data:
            errs[0] += 1
ts = [threading.Thread(target=hammer) for _ in range(8)] + \
     [threading.Thread(target=render) for _ in range(4)]
t0 = time.time()
for t in ts: t.start()
for t in ts: t.join()
dt = time.time() - t0
if errs[0] == 0:
    ok(f'конкурентность: 8×12 GET /api/dashboard + 4×4 рендера "/" параллельно — 112/112 ответов 200 без 500 ({dt:.2f}s)')
else:
    bad(f'конкурентность: {errs[0]} сбоев из 112')

# ── 4. Устойчивость к отсутствию /proc-файлов (первый старт/странный роутер) ──
D = tempfile.mkdtemp(prefix='a43_')
kw = dict(stat_path=D + '/no_stat', mem_path=D + '/no_mem',
          net_path=D + '/no_net', route_path=D + '/no_route',
          arp_path=D + '/no_arp', lease_paths=[D + '/no_leases'])
try:
    snap = g._dashboard_snapshot(force=True, **kw)
    keys_ok = set(snap.keys()) == {'ts', 'uptime', 'host', 'arch', 'cpu_pct',
        'ram', 'rate', 'wan_up', 'devices', 'services', 'update', 'lists'}
    graceful = (snap['wan_up'] is False and snap['cpu_pct'] is None
                and snap['rate']['down'] is None
                and snap['devices']['count'] == 0)
    if keys_ok and graceful:
        ok('отсутствующие /proc-файлы: снапшот без исключения; wan_up=False, cpu/rate=None, devices=0 — JS-гарды (—/Нет связи) отработают')
    else:
        bad(f'отсутствующие /proc: keys={keys_ok} graceful={graceful}')
except Exception as e:
    bad(f'отсутствующие /proc: ИСКЛЮЧЕНИЕ {e!r}')

# ── 5. Тайминги и кэш ──
t0 = time.perf_counter(); g._dashboard_snapshot(); t_cache = time.perf_counter() - t0
t0 = time.perf_counter()
for _ in range(20):
    g._dashboard_snapshot(force=True)
t_force = (time.perf_counter() - t0) / 20
ok(f'тайминги снапшота: из кэша {t_cache*1000:.2f} мс; force-пересборка {t_force*1000:.2f} мс (поллинг 2 с → загрузка < 0.1%)')

# ── 6. Память: RSS процесса с импортированной панелью ──
def rss_mb():
    with open('/proc/self/status') as f:
        for ln in f:
            if ln.startswith('VmRSS'):
                return int(ln.split()[1]) / 1024
import importlib
base = rss_mb()
r = c.get('/', headers=H)
r2 = c.get('/?tab=ss', headers=H)
after = rss_mb()
ok(f'память: RSS после импорта+рендера обоих шаблонов = {after:.1f} МБ (дельта от py-базы {after-base:+.1f}; обе строки шаблонов в памяти одновременно)')

print(f'═══ VERIFY43 ИТОГ: PASS={_p[0]} FAIL={_f[0]} ═══')
sys.exit(0 if _f[0] == 0 else 1)
