#!/bin/bash
# f47_audit.sh — приёмочный стенд правок аудита-17 (r43 → r44):
#  A. R47-1: uninstall_netfilter снимает ВСЕ проектные правила —
#     поведенческий прогон реальной функции на моках iptables/ip/ipset:
#     negated-DROP с `-i` и исключениями, DNS RETURN (udp/53, mangle),
#     ACCEPT 8080 по фактическим подсетям; регрессия прежних циклов
#     (REDIRECT/TPROXY/простой DROP/socket-MARK/DNAT/OUTPUT);
#     чужие правила не тронуты; идемпотентность повторным прогоном
#  B. N-5: preflight S99generator — оба web_username/web_password
#     непусты, иначе SKIPPED rc=0; сломанный python-конфиг не отсекается
#  C. R45-4: призыв перевыпустить секреты только при заполненных
#     bot_token/web_password в живом bot_config.py
#  D. R45-5: opkg_installed() удалена, opkg_available() и вызовы живы
#  E. стат. маркеры правок + синтаксис + контракт deploy (|| true)
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f47chk
rm -rf "$F"; mkdir -p "$F/bin"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. R47-1: uninstall_netfilter на моках (реальная функция) ═══"

# ── мок iptables: состояние в файле, формат table|chain|-A chain spec ──
cat > "$F/bin/iptables" <<'EOF'
#!/bin/bash
R=${IPT_MOCK_STATE:?}
T=filter
args=("$@")
i=0
while [ $i -lt ${#args[@]} ]; do
    case "${args[$i]}" in
        -t) T=${args[$((i+1))]}; i=$((i+2)); continue ;;
        -w) i=$((i+1)); continue ;;
    esac
    break
done
act=${args[$i]}
chain=${args[$((i+1))]}
spec=""
j=$((i+2))
while [ $j -lt ${#args[@]} ]; do
    spec="$spec ${args[$j]}"
    j=$((j+1))
done
spec=${spec# }
case "$act" in
    -S)
        awk -F'|' -v t="$T" -v c="$chain" \
            '$1==t && $2==c {sub(/^[^|]*\|[^|]*\|-A [^ ]* /,""); print "-A " c " " $0}' "$R"
        ;;
    -D)
        key="${T}|${chain}|-A ${chain} ${spec}"
        if grep -qxF "$key" "$R"; then
            grep -vx "$key" "$R" > "$R.tmp" && mv "$R.tmp" "$R"
            exit 0
        fi
        exit 1
        ;;
    -C)
        grep -qxF "${T}|${chain}|-A ${chain} ${spec}" "$R" && exit 0
        exit 1
        ;;
esac
exit 0
EOF
# мок ip6tables: правил нет — каждый -D завершает цикл (детерминизм)
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ip6tables"
# мок ip: живые интерфейсы br0/nwg0, адрес br0, rule del пуст, flush ок
cat > "$F/bin/ip" <<'EOF'
#!/bin/sh
[ "$1" = "link" ] && [ "$2" = "show" ] && {
    case "$3" in br0|nwg0) exit 0 ;; *) exit 1 ;; esac
}
if [ "$1" = "-4" ] && [ "$2" = "addr" ]; then
    if [ "$4" = "br0" ]; then
        printf '2: br0: <BROADCAST,MULTICAST,UP> mtu 1500\n    inet 192.168.1.1/24 brd 192.168.1.255 scope global br0\n'
    fi
    exit 0
fi
[ "$1" = "rule" ] && exit 1
[ "$1" = "route" ] && exit 0
exit 0
EOF
# мок ipset: 7 канонических наборов проекта
cat > "$F/bin/ipset" <<'EOF'
#!/bin/sh
if [ "$1" = "list" ] && [ "$2" = "-n" ]; then
    printf 'unblockdns\nunblockhysteria\nunblockrouter\nunblocksh\nunblocktor\nunblocktroj\nunblockvless\n'
fi
exit 0
EOF
chmod +x "$F/bin/iptables" "$F/bin/ip6tables" "$F/bin/ip" "$F/bin/ipset"

# фикстура правил: проектные (все формы) + чужие (должны уцелеть)
cat > "$F/rules.txt" <<'EOF'
nat|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -j REDIRECT --to-port 9141
nat|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockvless dst -j REDIRECT --to-port 10810
nat|PREROUTING|-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1
nat|PREROUTING|-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP
mangle|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp --dport 53 -j RETURN
mangle|PREROUTING|-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblockrouter dst -j MARK --set-mark 0xd1001/0xd1001
mangle|PREROUTING|-A PREROUTING -m conntrack --ctstate NEW -m set --match-set unblocktor dst -j CONNMARK --set-mark 0xd1001
mangle|PREROUTING|-A PREROUTING -j CONNMARK --restore-mark
mangle|PREROUTING|-A PREROUTING -p tcp --dport 5000 -j DROP
filter|INPUT|-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 192.168.0.0/16 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j DROP
filter|INPUT|-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT
filter|INPUT|-A INPUT -i br0 -p tcp --dport 9141 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 22 -j ACCEPT
nat|OUTPUT|-A OUTPUT -o lo -j RETURN
nat|OUTPUT|-A OUTPUT -d 192.168.0.0/16 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x2000000 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x9999999 -j RETURN
EOF
cp "$F/rules.txt" "$F/state.txt"

# экстракт реальной uninstall_netfilter из deploy_bypass.sh
awk '/^uninstall_netfilter\(\) \{/,/^\}/' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/un.s"
UN_LINES=$(wc -l < "$F/un.s")
[ "$UN_LINES" -gt 150 ] \
    && ok "A0: экстракт uninstall_netfilter (${UN_LINES} строк)" \
    || bad "A0: экстракт подозрительно мал (${UN_LINES} строк)"

cat > "$F/runA.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runA.sh"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA.log" 2>&1
rcA=$?

LEFT=$(cat "$F/state.txt")
chk_gone(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 1 || return 0; }
chk_here(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 0 || return 1; }

[ "$rcA" = 0 ] && [ "$(grep -c '^RC=0$' "$F/runA.log")" = 1 ] \
    && ok "A1: uninstall_netfilter отработала rc=0" \
    || bad "A1: rc=$rcA ($(tail -2 "$F/runA.log"))"
chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP' \
    && chk_gone '-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP' \
    && ok "A2: negated-DROP UDP-guard снят (обе формы: -i + исключения)" \
    || bad "A2: guard-DROP остался: $(printf '%s\n' "$LEFT" | grep 'unblocktor dst\|unblocktroj dst' | grep DROP)"
chk_gone '-A PREROUTING -p udp --dport 53 -j RETURN' \
    && ok "A3: DNS RETURN (mangle, udp/53) снят" \
    || bad "A3: DNS RETURN остался"
N8080=$(printf '%s\n' "$LEFT" | grep -c -- '--dport 8080 -j ACCEPT' || true)
[ "$N8080" = 0 ] \
    && ok "A4: ACCEPT 8080 сняты все три (факт. подсети + legacy)" \
    || bad "A4: осталось ACCEPT 8080: $N8080"
chk_gone '-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP' \
    && chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -j CONNMARK --restore-mark' \
    && chk_gone '-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1' \
    && chk_gone '-A OUTPUT -m mark --mark 0x2000000 -j RETURN' \
    && chk_gone '-A INPUT -p tcp --dport 8080 -j DROP' \
    && chk_gone '-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT' \
    && ok "A5: регрессия прежних циклов: REDIRECT/TPROXY/простой DROP/CONNMARK/socket/DNAT/OUTPUT/8080-DROP сняты" \
    || bad "A5: что-то из прежних форм осталось: $(printf '%s\n' "$LEFT" | grep -c unblock) unblock-строк"
chk_here '-A PREROUTING -p tcp --dport 5000 -j DROP' \
    && chk_here '-A INPUT -p tcp --dport 22 -j ACCEPT' \
    && chk_here '-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4' \
    && chk_here '-A OUTPUT -m mark --mark 0x9999999 -j RETURN' \
    && ok "A6: чужие правила целы (DROP 5000 / ACCEPT 22 / DNAT 9999 / RETURN 0x9999999)" \
    || bad "A6: чужое правило удалено: $(printf '%s\n' "$LEFT" | grep -v unblock)"
LEFTCNT=$(printf '%s\n' "$LEFT" | grep -c '^-A\|^[a-z]*|' || true)
# идемпотентность: повторный прогон по оставшемуся состоянию
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA2.log" 2>&1
rcA2=$?
LEFT2=$(cat "$F/state.txt")
if [ "$rcA2" = 0 ] && [ "$LEFT2" = "$LEFT" ]; then
    ok "A7: идемпотентность — повторный прогон rc=0, состояние не изменилось"
else
    bad "A7: rc=$rcA2, дельта: $(diff <(printf '%s\n' "$LEFT") <(printf '%s\n' "$LEFT2") | head -5)"
fi

echo "═══ B. N-5: preflight панели в S99generator ═══"
awk '/# N-5 \(аудит-17\)/,/^    fi$/' "$K/opt/etc/init.d/S99generator" > "$F/pref.body"
# 3 вхождения пути: два grep-условия + текст подсказки SKIPPED
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/pref.body" | grep -c '__CFG__')
[ "$SUBS" = 3 ] \
    && ok "B0: экстракт preflight, оба grep + подсказка ведут на bot_config.py" \
    || bad "B0: замен путей = $SUBS (ожидалось 3)"
run_preflight(){
    CFG="$1"
    # тело оборачиваем в функцию: `return 0` в sourced-файле завершает
    # только sourcing, а не вызывающую функцию — без обёртки STARTED
    # печатался бы и после SKIPPED
    {
        echo '__preflight(){'
        sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/pref.body"
        echo '  echo CONTINUES'
        echo '}'
        echo '__preflight'
    } > "$F/pref.run"
    ( . "$F/pref.run" )
}
mkdir -p "$F/cfg"
printf "web_username = 'admin'\nweb_password = ''\n" > "$F/cfg/empty_pass.py"
printf "web_username = ''\nweb_password = 'x'\n" > "$F/cfg/empty_user.py"
printf "web_username = 'admin'\nweb_password = 'secret'\n" > "$F/cfg/ok.py"
printf "web_username = 'admin'\nweb_password = 'x'\nэтот файл не python !!!\n" > "$F/cfg/broken.py"
O1=$(run_preflight "$F/cfg/empty_pass.py")
O2=$(run_preflight "$F/cfg/empty_user.py")
O3=$(run_preflight "$F/cfg/ok.py")
O4=$(run_preflight "$F/cfg/missing.py")
O5=$(run_preflight "$F/cfg/broken.py")
printf '%s' "$O1" | grep -q 'SKIPPED' && [ -z "$(printf '%s' "$O1" | grep CONTINUES)" ] \
    && ok "B1: пустой web_password → SKIPPED, старт отменён" \
    || bad "B1: $O1"
printf '%s' "$O2" | grep -q 'SKIPPED' && [ -z "$(printf '%s' "$O2" | grep CONTINUES)" ] \
    && ok "B2: пустой web_username → SKIPPED" \
    || bad "B2: $O2"
printf '%s' "$O3" | grep -q "CONTINUES" && [ -z "$(printf '%s' "$O3" | grep SKIPPED)" ] \
    && ok "B3: оба заполнены → старт (без SKIPPED)" \
    || bad "B3: $O3"
printf '%s' "$O4" | grep -q 'SKIPPED' && [ -z "$(printf '%s' "$O4" | grep CONTINUES)" ] \
    && ok "B4: конфига нет → SKIPPED (rc=0)" \
    || bad "B4: $O4"
printf '%s' "$O5" | grep -q "CONTINUES" \
    && ok "B5: сломанный python-конфиг НЕ отсекается (grep не исполняет код)" \
    || bad "B5: $O5"

echo "═══ C. R45-4: призыв отозвать секреты — по условию ═══"
awk '/# R45-4 \(аудит-17\)/,/^fi$/' "$K/opt/bin/deploy_bypass.sh" > "$F/sec.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/sec.body" | grep -c '__CFG__')
[ "$SUBS" = 1 ] \
    && ok "C0: экстракт R45-4, условие читает живой bot_config.py" \
    || bad "C0: замен путей = $SUBS (ожидалось 1)"
run_secrets(){
    CFG="$1"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/sec.body" > "$F/sec.run"
    ( . "$F/sec.run" )
}
printf "bot_token = '123:ABC'\nweb_password = 'x'\n" > "$F/cfg/sec_ok.py"
printf "bot_token = ''\nweb_password = ''\n" > "$F/cfg/sec_no.py"
printf "web_password = 'onlypass'\n" > "$F/cfg/sec_wp.py"
C1=$(run_secrets "$F/cfg/sec_ok.py")
C2=$(run_secrets "$F/cfg/sec_no.py")
C3=$(run_secrets "$F/cfg/missing.py")
C4=$(run_secrets "$F/cfg/sec_wp.py")
printf '%s' "$C1" | grep -q 'перевыпустите токен' \
    && ok "C1: секреты заполнены → подсказка печатается" \
    || bad "C1: нет подсказки при заполненных секретах"
[ -z "$C2" ] \
    && ok "C2: секреты пусты → тишина" \
    || bad "C2: напечатал: $C2"
[ -z "$C3" ] \
    && ok "C3: конфига нет → тишина" \
    || bad "C3: напечатал: $C3"
printf '%s' "$C4" | grep -q 'перевыпустите токен' \
    && ok "C4: заполнен только web_password → подсказка есть" \
    || bad "C4: нет подсказки при web_password"

echo "═══ D. R45-5: мёртвая opkg_installed удалена ═══"
D1=$(grep -c 'opkg_installed' "$K/opt/bin/check_updates.sh" || true)
[ "$D1" = 0 ] \
    && ok "D1: упоминаний opkg_installed в check_updates.sh нет" \
    || bad "D1: осталось упоминаний: $D1"
D2=$(grep -c 'opkg_available' "$K/opt/bin/check_updates.sh" || true)
[ "$D2" -ge 5 ] \
    && ok "D2: opkg_available на месте (определение + 4 вызова = $D2)" \
    || bad "D2: opkg_available упомянута $D2 раз"
grep -q 'list-installed' "$K/opt/bin/check_updates.sh" \
    && bad "D3: list-installed всё ещё используется" \
    || ok "D3: list-installed больше не вызывается в check_updates.sh"

echo "═══ E. Маркеры, синтаксис, контракты ═══"
R47N=$(grep -c 'R47-1 (аудит-17)' "$K/opt/bin/deploy_bypass.sh" || true)
[ "$R47N" = 3 ] \
    && ok "E1: маркеры R47-1 в deploy: 3 блока" \
    || bad "E1: маркеров R47-1 = $R47N (ожидалось 3)"
grep -q 'N-5 (аудит-17)' "$K/opt/etc/init.d/S99generator" \
    && grep -q 'R45-4 (аудит-17)' "$K/opt/bin/deploy_bypass.sh" \
    && ok "E2: маркеры N-5 (S99generator) и R45-4 (deploy) на месте" \
    || bad "E2: маркер N-5/R45-4 не найден"
dash -n "$K/opt/bin/deploy_bypass.sh" && dash -n "$K/opt/bin/check_updates.sh" \
    && dash -n "$K/opt/etc/init.d/S99generator" \
    && ok "E3: синтаксис правленых файлов (dash -n) без ошибок" \
    || bad "E3: dash -n упал"
grep -q 'safe_start_service "S99generator"' "$K/opt/bin/deploy_bypass.sh" \
    && grep -A3 'safe_start_service() {' "$K/opt/bin/deploy_bypass.sh" | grep -q '|| true' \
    && ok "E4: deploy не упадёт от SKIPPED (safe_start_service глотает rc)" \
    || bad "E4: контракт safe_start_service изменён"
grep -q 'web INPUT DROP add/verify failed' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    && ok "E5: хук 100-redirect.sh не тронут (аудит-17 правки только в uninstall)" \
    || bad "E5: хук неожиданно изменён"

echo "═══ F47 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
