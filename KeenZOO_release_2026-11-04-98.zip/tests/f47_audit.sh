#!/bin/bash
# f47_audit.sh v53 — приёмочный стенд правок аудитов 18/…/42 + фича-r69 + аудит-43 + ревью-r70/-r71/-r72 + UX-r73/-r74 + дашборд-r75 + панель-r77 + облегчение-r78 + надёжность-r79 + закрытие-аудита-46-r80 + закрытие-аудита-47-r81 + закрытие-аудита-48-r82 + панель-r83 + правки-отображения-r84..86 + r87-nfqws2 + r89-nfqws2-selective + r90-protocols-menu + r91-hardening + r92-boot-consistency + r93-audit-fixes + r94-audit-fixes + r95-audit-fixes + r96-audit-fixes (аудит r95 — подтверждённые ошибки: А lock per-acquire токен гейта/единый снимок/rename-first/отбор только у мёртвого PID/уборка своего каталога при провале записи gate/Б ts-границы (OverflowError+будущее)/В claim=None+KZ_CLAIM в child/Г check_failed is False/Д busy-остатки JS (pollUpdate/runUpd/chkRun/fetchVer); Ж/U0/README/IPv6 — по прежним решениям владельца) + r97-audit-fixes (аудит r96 — подтверждённые живьём: KZ96-01 deadlock коллизий .rel.<PID>/двойной захват гейта/два победителя fast-path/разрушение чужого lock → уникальные имена .rel/.stale/.dead (PID+random), пост-проверка реклейма гейта, fast-path под гейтом, mismatch без rmtree; KZ96-02 неатомарность claim-публикации → межпроцессный guard статуса у ВСЕХ writers (Python: publish_error/публикация running/снятие клейма + BusyBox-ash финализатор обёртки); KZ96-03 fetchVer тихий сбой → честный catch + busy-терминал; WSGI-потоки/IPv6/README/U0 — прежние решения владельца) + r98-audit-fixes (аудит r97 — подтверждённые живьём: AUD-R97-01/02 mkdir-окна → ДВА токена status-guard/гейта, ДВА True у toggle-lock; KZ97-01 shell-реклейм по одному PID удалял свежий guard → статус-guard и acquire/release toggle переведены на flock(2) по СТАБИЛЬНЫМ lock-файлам: kernel-мьютекс, авто-снятие при гибели держателя, слой stale-реклейма guard удалён; dir-протокол toggle сохранён как defense-in-depth (liveness/stale/heartbeat); ash-финализатор — python-хелпер с тем же lock-файлом (точная JSON-сверка claim, компактный формат); WSGI/IPv6/README/U0 — прежние решения владельца) (аудит r94 — подтверждённые ошибки: А lock-идентичность (st_dev/st_ino) + гейт-токен/Б force-фильтр подтверждённо-остановленных + финальный _ra_ok/В updates-валидность/Г _read_proto_update-валидация/Д JS busy-гарды+Retry-After/Е claim-id; Ж — оставить как есть, З — отклонено, решения владельца 03.11.2026; пороги Z62-2/Z62-5 пересчитаны под r95) (аудит r90 пакеты А-Д + Е; r92 — автостарт после разворачивания; r93 — подтверждённые ошибки аудита r92; r94 — подтверждённые ошибки аудита r93: А lock recovery-гейт+fail-closed owner/Б JS busy-503/В честный reapply-отказ/Г перечень остановленных в панели/Д схема статуса+будущий ts/Ж(а) глобальный гейт 8+503 — Е claim-id отложен, З IPv6 не меняем; счётчики Q4 15+7/Q12 8/Z45-1 30+3/Z57 r89/Z58 r90/Z59 r91/Z60 r92/Z61 r93/Z62 r94/Z63 r95; r45→…→r87→r89→r90→r91→r92→r93→r94→r95):
#  Z51. Панель-r77 (макеты v1–v6, решение владельца): FB-149
#     левое меню с группами «Статус/Протоколы/Настройки» и
#     подпунктами, видимыми сразу; ☰-меню вкладок и сайдбар
#     панели удалены (навигация одна); мобильный режим: ☰
#     слева вверху, меню выезжает слева (260 px, прокрутка);
#     FB-150 DNS-панель только во вкладке DNS, кнопка «Версии
#     и обновления» убрана; FB-151 гамма/шрифты по эталону
#     владельца (panel_preview_r78: #1b2433/#1e293b/#00a8e8,
#     Arial 15, fs 13/14.5/15/17), кнопки «Применить…» в
#     уровень (:has); FB-148 сетка дашборда сохранена.
#  Z52. Облегчение-r78 (аудит-44, решение владельца): FB-152
#     прекомпиляция .pyc при установке (deploy); FB-153 gzip
#     текстовых ответов ≥1 КБ (stdlib after_request); FB-154
#     TTL дашборда 2.5 с (каждый второй поллинг — кэш-хит);
#     FB-155 TTL DNS-статуса 120 с; «ред. 78».
#  Z53. Надёжность-r79 (аудит-45 = внешний отчёт r77, решение
#     владельца — этапы 1–3): FB-156 чёрный список ndmc-парсера
#     +invalid/unknown/unrecognized/unsupported (R77-01/K69-01);
#     FB-157 single-flight старт обновления (R77-02); FB-158 lock
#     без pid/мусор → UNKNOWN + PID-личность по /proc/cmdline
#     (R77-03); FB-159 single-flight refresh dns-status + stale
#     (R77-04); FB-160 RTF_UP/REJECT + ppp*-дефолт (R77-05);
#     FB-161 legacy-meminfo ≈-оценка (R77-06); FB-162 «счётчики
#     интерфейса» (R77-07); FB-163 «Маршрут по умолчанию найден»
#     (R77-08); FB-164 CR→\r в deploy (R77-09); FB-165 verify42/43
#     в tests/ (R77-10); FB-166 except сужен + noqa снят (R77-11);
#     «ред. 79».
#  Z54. Закрытие-аудита-46-r80 (внешние аудиты r79, этапы 1–3,
#     решение владельца): FB-167 readback-транзакция включения
#     Override при rc≠0 (A-R79-01); FB-168 single-flight старт
#     обновления протоколов + атомарный error при сбое Popen
#     (A-R79-03); FB-169 сериализация DNS-повторов + hosts
#     errors='replace' (B-R79-03); FB-170 gzip-неготиация q=0/токены/
#     регистр + Vary на обеих representations (A-R79-04/B-R79-02);
#     FB-171 RAM free+buffers+cached + сброс виджета при null
#     (A-R79-05/B-R79-01); FB-172 смерть pid — только ESRCH
#     (A-R79-06); FB-173 счётчики wg-дефолта (A-R79-08); FB-174
#     «Нет IPv4-маршрута по умолчанию» (A-R79-09); FB-175 откат
#     compileall (A-R79-07); FB-176 +Command not found/Not supported
#     (A-R79-02); FB-177 «8 fork'ов»; FB-178/179 — тесты без
#     сайд-эффектов, verify43 переносимы; «ред. 80».
#  Z54-дополнение (v39, закрытие-аудита-47-r81 — внешние отчёты
#     r80, все этапы, решение владельца): FB-180 recovery-команды
#     FB-167 в копируемой форме — текст проверяется в обеих ветках
#     (A-R80-DNS-02/B-R80-02); FB-181 failure-атомарность
#     start_proto_update: провал публикации running → отказ без
#     Popen и без сирот .wtmp, провал подготовки после running →
#     атомарный error вместо застрявшего статуса, fd без утечки
#     (A-R80-PROTO-01/B-R80-03); FB-182 строгий qvalue RFC 9110
#     (bogus/2/inf/1e3/.5 → без сжатия) + Vary-дедуп без регистра
#     (A-R80-HTTP-01/B-R80-04); FB-183 точные формы «Command not
#     found»/«Not supported» + негативные фикстуры Notice/Nothing/
#     Not-in (B-R80-06); FB-184 verify43 — очистка каталогов +
#     секрет в копии (B-R80-05); FB-185 — релизный прогон по f47,
#     извлечённому из собранного ZIP; «ред. 81».
#  Z54-дополнение-2 (v40, закрытие-аудита-48-r82 — внешние отчёты
#     r81, реальные исправления, решение владельца): FB-186 qvalue
#     — точная ASCII-грамматика RFC 9110 (полное совпадение: «0» с
#     0–3 цифрами либо «1» с 0–3 нулями; прежде «1.001»/«1.999»
#     проходили как >1, валидные «1.»/«0.» отвергались, \d
#     принимал Unicode-цифры); FB-187 persistent-ENOSPC — вся
#     подготовка временных ресурсов ДО публикации running, error-
#     публикация возвращает успех, при провале running-клейм этой
#     попытки снимается (повтор не блокируется 900 с); FB-188
#     изоляция импорта — sys.path из каталога САМОГО generator
#     (dirname abspath __file__), verify43 — preflight-ассерты
#     (модуль/конфиг/секрет из тестовой копии); FB-189 fixture
#     verify43 внутри очищаемого _TMPDIR; «ред. 82».
#  Z49. UX-r74 (r75): FB-141 контрасты (faint → 4.89:1/5.48:1,
#     тёмный текст на filled в dark 6.65:1); FB-142 шкалы
#     токенов --fs-*/--sp-*/--z-*/--ease/--dur в 3 шаблонах;
#     FB-143 kzFetch (лоадер+блокировка, мин. 600 мс) на 4
#     точках; FB-144 «Назад»: pushState #tab- + popstate;
#     FB-145 черновики textarea (localStorage, toast,
#     «Очистить»); FB-146 скелетон DNS-проверок + пустое
#     состояние. У-14 (инлайн-confirm) — вне релиза, отдельное
#     решение по каждому месту.
#  Z48. UX-r73, вариант B владельца (r74): FB-140 — вкладки-
#     пилюли 44px, активная filled primary (dark — тон
#     primary-c); У-6 touch-цели 44px; У-7 ARIA-табы (tablist/
#     tab/tabpanel, aria-selected, roving tabindex); У-8
#     aria-live на сообщениях; У-12 стрелки ←/→/Home/End;
#     У-15 валидация ключей (пустой → submit неактивен,
#     счётчик); У-17 toast-дубликат серверных сообщений.
#  Z47. Ревью r72 (r73): FB-139 — стиль вкладок (/panel)
#     приведён к стилю дашборда: токены MD3 (primary/surface/
#     outline/тени), сайдбар — светлый рельс, плитки — карточки,
#     кнопки — пилюли ghost/tonal/filled, вкладки — тон
#     primary-c, тонированные баннеры; масштабирование
#     (media 960/700/420, fluid-гриды) и плотность пикселей
#     (text-size-adjust, tap-highlight, векторные иконки).
#  Z46. Ревью r71 на устройстве (r72): FB-138 мобильный пакет
#     стоял выше базовых правил и каскадом отменялся — перенесён
#     в конец стиля дашборда и оболочки; kmap колонкой (коннекторы
#     скрыты), hover-подсказки скрыты, заголовки карточек
#     переносятся, эллипсис топбара, компактные кольца.
#  Z45. Ревью развёртывания r70 (r71): FB-130 диагностика отказов
#     opkg install (повтор+вывод); FB-131 проба фида без curl —
#     пометка ненадёжности; FB-132 нормализация ответов (CRLF/\n,
#     пробелы, «да», эхо нераспознанного) — 5 вопросов деплоя;
#     FB-133/134 лишние надписи убраны; FB-135 подписи рельса при
#     сворачивании (общее .rail .lbl); FB-136(A) MD3-оболочка
#     вкладок: SHELL_TEMPLATE + /panel + редиректы/навигация;
#     FB-137 мобильная вёрстка (топбар/отступы/hero/подложка).
#  Z44. Аудит-43 + внешнее ревью r69 (r70): FB-125 позитивный CSRF
#     кнопки дашборда; FB-126 stale-running (вычисляемый stale, JS
#     не блокирует повтор); FB-127 error-статус при сбое запуска и
#     честный 409 при живом pid; FB-128 ARP-бит ATF_COM (статические
#     записи 0x6); FB-129 наследование окружения обёрток; K67-01
#     TTL-кэш /api/dns-status; K67-02 мёртвые ре-экспорты; K67-03
#     JS-wait останавливается.
#  Z43. Дашборд r69 (этап 1, «KeeneticOS Hybrid»): лёгкая телеметрия
#     /proc (uptime/CPU/RAM/скорости WAN), устройства (ARP+leases),
#     счётчики списков (TTL-кэш), маршруты /api/dashboard и
#     /dash/update-lists, самодостаточный шаблон без внешних ассетов.
#     T4/U0 адаптированы: csrf_token берётся с /?tab=ss (главная — дашборд).
#  Z42. Аудит-42 (мини-аудит спиннера «Обновление…», FB-121/FB-124):
#     значения обёрток панельных обновлений (списки и протоколы) —
#     через окружение KZ_*, argv строго «/bin/sh -c body» без хвостовых
#     аргументов (Keenetic-прошивка их теряет — инцидент 2026-10-24/25);
#     пустые KZ_* → немедленный error-статус и rc 3 (FB-124).
#  Z41. Аудит-41 (внешние отчёты r66): диагностический чёрный список в
#     _kz_dns_override_state — строка, начинающаяся со слова error/warn/
#     usage (любой регистр и суффиксы: ERROR:, Error:, WARNING:, Usage:…),
#     → UNKNOWN(2); приоритет ON сохранён (директива + ERROR-строка → ON);
#     чистый конфиг без подстроки → OFF — детекция OFF жива (FB-119,
#     K66-01 «no opkg rc=0 без применения + мусорный readback → ложное
#     „отключён“ + SELF=0» и P2-initial «чужой ON + мусорный первый
#     readback → предложение включения → откат отключал чужой Override»,
#     вариант А — чёрный список, белый не выдумывается до образцов NDMS);
#     сброс DNS_OVERRIDE_LAST=2 в начале шага до ветки have_cmd —
#     унаследованное из окружения значение не строит ложный диагноз
#     финализатора (FB-120, P3 stale-env).
#  Z40. Аудит-40 (внешние отчёты по r65): readback-OFF после применённой
#     команды включения не доверять — проверяемый откат, SELF=0 только
#     после подтверждённого OFF: «unowned ON невозможен» (FB-117/K65-01,
#     вариант А — поведенческий, парсер FB-116 не меняется); tri-state
#     _kz_dns_self_revert (0 no-op / 1 откат подтверждён / 2 нет) +
#     DNS_OVERRIDE_LAST в state — финализатор формулирует судьбу порта 53
#     по факту: утверждение «за системным DNS» только при подтверждённом
#     OFF, при провале отката/чужом ON/UNKNOWN — честные тексты и ручная
#     проверка (FB-118/K65-02); защищённая форма всех вызовов self_revert.
#  Z39. Аудит-39 (внешние отчёты по r64): step DNS Override под
#     set -eu — защищённый захват tri-state «|| st=$?» (OFF/UNKNOWN
#     прежде убивали deploy ДО чтения $; FB-112/P1-01); транзакционный
#     enable — ownership SELF сразу после применённой команды, post-save
#     tri-state: UNKNOWN → проверяемый откат, подтверждённый OFF →
#     честный отказ, финализатор при OK=0 зовёт self_revert при SELF=1
#     (FB-113/P1-02/K64-01); config_has_placeholders — распарсенный
#     не-dict корень = заглушка, паритет с preflight (FB-114/K64-02);
#     комментарии Flask 3.0.x/3.9+ (FB-115); точная строка директивы
#     «opkg dns-override», не-директивная подстрока → UNKNOWN
#     (FB-116)
#  Z38. Аудит-38 (внешние отчёты по r63): BusyBox-awk совместимый
#     escape-детектор kz_json_root_str + escape в ИМЕНИ ключа → rc 2
#     (FB-100), полный root-dup guard — дубликат любого корневого
#     ключа при любом типе значения → rc 3 (FB-103); ensure_dns
#     fail-closed без /etc/resolv.conf (FB-101) и флаг транзакции
#     ДО записи с немедленным откатом (FB-102); tri-state
#     _kz_dns_override_state 0/1/2 (FB-104), проверяемый откат
#     enable (FB-105), self_revert в проваленных путях финализатора
#     (FB-106); корень-не-объект → ValueError, не AttributeError
#     (FB-107); хвост /keenetic в пробах и флипе (FB-108); S57 без
#     common.sh → SKIPPED validator missing (FB-110); server+auth
#     одним субшеллом с LF-гейтом (FB-111)
#  W. Аудит-34 (перестройка деплоя по распоряжению): авто-бутстрап HTTPS
#     (FB-78) — 4 пакета с текущего фида, фолбэк на зеркала (bin → bfsu
#     → cqupt → nju → diversion, https + http-вариант), флип entware|
#     keendev на https с контрольным opkg update и байт-точным откатом;
#     вопрос согласия упразднён (pty и не-tty выполняются полностью);
#     DNS Override (FB-79) — явное согласие y/N со стартом S56dnsmasq и
#     проверкой живости; перезагрузка — отдельный запрос последним
#     шагом; FB-80 — тихий режим (загрузчик/WebTunnel/crond/ipset/
#     сервисы молчат, предупреждения остаются); FB-81 — пробы фидов
#     печатаются только при ошибке; Q4: 14 установок deploy (2 —
#     авто-бутстрап без гейта, прямое распоряжение); V1/P5/N5 —
#     формулировки факта
#  Y. Аудит-33 (внешние отчёты по r58): атомарный compare-and-write
#     списков (rev = SHA-256 содержимого, проверка+запись под общим
#     guard, strict no-rev), resolv.conf только при DNS_OVERRIDE_OK=1
#     (проба 127.0.0.1 до записи, бэкап+откат), консент бутстрапа не
#     переносится на остаточные сторонние HTTP-фиды, per-source статусы
#     check_updates (частичный провал = check_failed, na для BE-MIPS),
#     паритет example.com до конца (порт/регистр/конечная точка/
#     нестроковый server; sni-исключение), procfs-fallback
#     _kz_dns_live, явный KEENZOO_DLTMP (абсолютный/mkdir/writable),
#     INSTALL: menu-SHA/подписи редакции сверяются с фактом
#  R. Аудит-26 (внешние отчёты по r51): S57-гейт заглушки с портом
#     (K51-1), PID-личность при останове (K51-3), HTTP-гейт — обе
#     копии, 6 форм opkg.conf + fail-closed на нечитаемом (R51-02),
#     мемоизация opkg list-installed (K51-2), порог Range (R51-07),
#     SKIPPED_HTTP со всех точек (R51-05), SNI-исключение needs_key
#     (R51-06), CFG_STATE web_username + баннер (R50-UX-1), LAN-lock
#     (N51-2), _auth_cmp (FB-33), cross-list warning (N51-1),
#     benchmark-диапазон (R50-FW-1), wget-warn (FB-34), маркеры
#  X. Аудит-32 (внешний отчёт по r55): полный lock writers списков
#     (flock панель+бот, revision редактора против stale-вкладки),
#     401 без sleep для отсутствующих кредов, mkstemp+lock
#     router-proto, паритет валидаторов hysteria 15/15 (тип auth,
#     server=CHANGE_ME), уборка сиротливых tmp, warnings в /api/cfg,
#     check_failed потребителю бота
#  W. Аудит-31: одноразовый https-бутстрап фида (4 пакета по HTTP
#     под единым согласием → флип entware|keendev в opkg.conf с копией
#     → контрольный opkg update; провал = откат байт-в-байт) и DNS
#     Override только при живом dnsmasq (мёртвый = пропуск + подсказка
#     + вопрос; заклинивший override предлагается отключить; 127.0.0.1
#     в resolv.conf только при живом dnsmasq)
#  V. Аудит-30 (разбор живой установки r55): tty-согласие на
#     установки из штатного HTTP-фида (вопрос один раз за прогон,
#     не-tty — прежний fail-closed); честная укомплектованность
#     вместо статического «Пакеты уже стоят»; дедуп сводки пропусков;
#     вердикты сервисов по бинарнику (ss-redir/trojan как xray) и
#     ps-матчер без самосопоставления grep ([p]-трюк)
#  U. Аудит-29 (внешний отчёт по r54): гонка записи списков (общий
#     pid-tmp + несериализованный read-modify-write: 20 параллельных
#     POST давали 13×500 и 1 запись из 20) — mkstemp + _LISTS_WRITE_LOCK;
#     _write_enabled — тот же pid-tmp; счётчик неудачных входов считает
#     только предъявленные неверные креды (без Authorization — 401 без
#     счётчика); паритет 4 валидаторов на «auth отсутствует» (needs_key
#     с флагом hysteria, placeholders с require_auth)
#  T. Аудит-28 (внешний отчёт по r53): регресс JS addToList (лишняя })
#     ловится рендером + node --check; HTTP-гейт — 11 форм opkg.conf ×
#     обе копии (кавычки вокруг типа, dist/dist/gz, каталог); порядок
#     «модули → проба» и вердикт пробы в решении deploy (|0 не «✅»);
#     паритет 4 валидаторов hysteria; lookup-add: 1 чтение + лимит;
#     check_updates «проверка не удалась»; PID-личность по /proc/exe;
#     баннер «панель не настроена»; _kz_pkg_installed литерально; Range
#     по коду 206; маркеры FB-43..FB-51
#  S. Аудит-27 (внешний отчёт по r52): проба iptables вставкой правила
#     (K52-7), минифицированный JSON в детекторах заглушек (K52-1),
#     честный вердикт dnsmasq при отсутствии (K52-4), JS warning (K52-3),
#     снимок списков cross-check (K52-6), opkg list-installed ×1 (K52-5),
#     tty-вывод check_updates (N52-8), маркеры FB-35..41
#  Q. Аудит-25 (внешние отчёты по r50): декоратор before_request на
#     security_checks (P0), семантика _auth_fails (K50-2/A9-5), гейт
#     заглушки hysteria в S57 (K50-3), покрытие HTTP-гейта всеми
#     opkg install/upgrade (A9-2), Origin my.keenetic.net/loopback
#     (K50-4/A9-4), канонический путь hysteria (K50-5), форма src
#     фида (A9-3), честность заметки Range (A9-6), учёт гейт-пропусков
#     в сводке (A9-7), фильтр токена-заглушки (K50-7), shlex (K50-8),
#     кэш LAN-адресов (K50-9)
#  P. Аудит-24 (повторный сбой установки, rc=3): HTTP-политика перенесена
#     в точку риска — гейт перед сетевой opkg install (установленное
#     пропускается без сети; отсутствующее при http-фиде без ALLOW —
#     warn+пропуск); rc=3 → warn+продолжение; одиночный OFFLINE-флаг
#     самодостаточен; http-проба с ensure_dns и повтором (FB-8)
#  N. Аудит-23 (сбой установки на устройстве): проверка фидов Entware —
#     https без curl = «не проверено» (не бракуется), Range-проба 256Б,
#     недоступность фидов не убивает установку (авторитет — opkg update;
#     политический rc=3 для http-фида — с явным обходом ALLOW-флагом)
#  M. Аудит-22: O-1 (Origin: SSH-туннель 127.0.0.1:любой-порт при
#     loopback-клиенте, альтернативные LAN-IP, allowed_origin_hosts;
#     request.host не возвращён), TS-1 (tmp-статус не переживает
#     прогон: trap в body, очистка при отказе Popen), AF-1 (жёсткий
#     кап _auth_fails 256), SN-1 (нормализация fallback-подсетей,
#     логирование отказов ACCEPT) — поведенчески, экстракцией helpers
#  L. Аудит-21: FW-1b (зачистка legacy-blanket в setup_firewall,
#     без fallback на ALLOWED_SUBNETS), PF-1 (preflight панели —
#     только flask+markupsafe; текст deploy раздельный), RM-1
#     (uninstall_netfilter предупреждает об остатке чужих ACCEPT
#     на :8080 — поведенчески, на моках секции A)
#  K. Аудит-20: FW-1 (нет blanket-RFC1918 в setup_firewall, подсети
#     LAN как в блоке B7 хука), TW-1 (нет root-обёрток-файлов в /tmp:
#     sh -c + O_NOFOLLOW + mkstemp; фолбэк-статус обёртки), RL-1
#     (ротация: триггер по размеру, KEEP — цель), TG-1 (общая
#     tg_send_message: urlencode + токен вне cmdline), CS-1
#     (Origin: hostname-whitelist, чистка _auth_fails), BC-1 (ранний
#     chmod 0600 bot_config.py после apply)
#  A. R47-1+R48-2: uninstall_netfilter на моках iptables/ip/ipset —
#     проектные правила сняты (negated-DROP с -i и исключениями, DNS
#     RETURN udp/53, ACCEPT 8080 по фактическим подсетям), ЧУЖИЕ правила
#     на 8080 (голый ACCEPT / udp / публичный -s) целы, прочие чужие целы,
#     регрессия прежних форм снятия, идемпотентность
#  B. N-5+R48-3: start() из S99generator ЦЕЛИКОМ (не «до первого fi»):
#     preflight до is_running-выхода; при ненастроенном конфиге и живом
#     процессе — останов; already-running при настроенном; сломанный
#     python-конфиг не отсекается (grep не исполняет код)
#  C. R45-4+R48-1: советы про секреты — реальное поле token, исключение
#     заглушки ТОКЕН_БОТА, раздельные советы (токен / пароль панели)
#  D. R48-6: сводка deploy считает ACCEPT 8080 двухступенчатым grep'ом
#     (форма хука с -s между --dport и -j видна)
#  E. R48-8: сводка различает «панель не настроена» и «не запустилась»
#  F. R48-9: test_udp_tunnels — процесс не запущен => warn, а не FAIL
#  G. R48-5: просмотр списка в боте ≡ рендеру сохранения (R46-2)
#  H. R48-7: wsSettings.host вместо headers.Host (шаблон + конвертер)
#  J. аудит-19: R49-1 (без двойного запуска unblock_update в deploy,
#     boot-путь S99unblock цел), R49-2 (версия hysteria из баннера)
#  I. маркеры правок, синтаксис, отсутствие bot_token, JSON шаблона,
#     хук 100-redirect.sh не тронут; A6-4: pidof-фолбэк через /proc
set -u
# FB-178 (аудит-46, B-R79-04): импорты/компиляция тестов не должны
# оставлять __pycache__ в проверяемом дереве.
export PYTHONDONTWRITEBYTECODE=1
K=${1:-/home/user/KeenZOO}
F=/tmp/f47chk
rm -rf "$F"; mkdir -p "$F/bin"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. R47-1+R48-2: uninstall_netfilter на моках ═══"

# мок iptables: состояние в файле, формат table|chain|-A chain spec
cat > "$F/bin/iptables" <<'EOF'
#!/bin/bash
R=${IPT_MOCK_STATE:?}
T=filter
args=("$@")
i=0
while [ $i -lt ${#args[@]} ]; do
    case "${args[$i]}" in
        -t) T=${args[$((i+1))]}; i=$((i+2)); continue ;;
        -w) i=$((i+1)); continue ;;
    esac
    break
done
act=${args[$i]}
chain=${args[$((i+1))]}
spec=""
j=$((i+2))
while [ $j -lt ${#args[@]} ]; do
    spec="$spec ${args[$j]}"
    j=$((j+1))
done
spec=${spec# }
case "$act" in
    -S)
        awk -F'|' -v t="$T" -v c="$chain" \
            '$1==t && $2==c {sub(/^[^|]*\|[^|]*\|-A [^ ]* /,""); print "-A " c " " $0}' "$R"
        ;;
    -D)
        key="${T}|${chain}|-A ${chain} ${spec}"
        if grep -qxF "$key" "$R"; then
            grep -vx "$key" "$R" > "$R.tmp" && mv "$R.tmp" "$R"
            exit 0
        fi
        exit 1
        ;;
    -C)
        grep -qxF "${T}|${chain}|-A ${chain} ${spec}" "$R" && exit 0
        exit 1
        ;;
esac
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ip6tables"
cat > "$F/bin/ip" <<'EOF'
#!/bin/sh
[ "$1" = "link" ] && [ "$2" = "show" ] && {
    case "$3" in br0|nwg0) exit 0 ;; *) exit 1 ;; esac
}
if [ "$1" = "-4" ] && [ "$2" = "addr" ]; then
    if [ "$4" = "br0" ]; then
        printf '2: br0: <BROADCAST,MULTICAST,UP> mtu 1500\n    inet 192.168.1.1/24 brd 192.168.1.255 scope global br0\n'
    fi
    exit 0
fi
[ "$1" = "rule" ] && exit 1
[ "$1" = "route" ] && exit 0
exit 0
EOF
cat > "$F/bin/ipset" <<'EOF'
#!/bin/sh
if [ "$1" = "list" ] && [ "$2" = "-n" ]; then
    printf 'unblockdns\nunblockhysteria\nunblockrouter\nunblocksh\nunblocktor\nunblocktroj\nunblockvless\n'
fi
exit 0
EOF
# моки для секции E: netstat управляется маркером, ss всегда молчит
cat > "$F/bin/netstat" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/net8080 ] || exit 1
printf 'tcp 0 0 0.0.0.0:8080 0.0.0.0:* LISTEN\n'
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ss"
# мок pidof для секции F: маркер pidup => rc 0
cat > "$F/bin/pidof" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/pidup ] && exit 0
exit 1
EOF
chmod +x "$F/bin/"*

# фикстура правил: проектные (все формы) + чужие (должны уцелеть),
# в т.ч. ТРИ чужих на 8080 (R48-2)
cat > "$F/rules.txt" <<'EOF'
nat|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -j REDIRECT --to-port 9141
nat|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockvless dst -j REDIRECT --to-port 10810
nat|PREROUTING|-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1
nat|PREROUTING|-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP
mangle|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp --dport 53 -j RETURN
mangle|PREROUTING|-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblockrouter dst -j MARK --set-mark 0xd1001/0xd1001
mangle|PREROUTING|-A PREROUTING -m conntrack --ctstate NEW -m set --match-set unblocktor dst -j CONNMARK --set-mark 0xd1001
mangle|PREROUTING|-A PREROUTING -j CONNMARK --restore-mark
mangle|PREROUTING|-A PREROUTING -p tcp --dport 5000 -j DROP
filter|INPUT|-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 192.168.0.0/16 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p udp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j DROP
filter|INPUT|-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT
filter|INPUT|-A INPUT -i br0 -p tcp --dport 9141 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 22 -j ACCEPT
nat|OUTPUT|-A OUTPUT -o lo -j RETURN
nat|OUTPUT|-A OUTPUT -d 192.168.0.0/16 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x2000000 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x9999999 -j RETURN
EOF
cp "$F/rules.txt" "$F/state.txt"

awk '/^uninstall_netfilter\(\) \{/,/^\}/' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/un.s"
UN_LINES=$(wc -l < "$F/un.s")
[ "$UN_LINES" -gt 150 ] \
    && ok "A0: экстракт uninstall_netfilter (${UN_LINES} строк)" \
    || bad "A0: экстракт подозрительно мал (${UN_LINES} строк)"

cat > "$F/runA.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runA.sh"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA.log" 2>&1
rcA=$?
LEFT=$(cat "$F/state.txt")
chk_gone(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 1 || return 0; }
chk_here(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 0 || return 1; }

[ "$rcA" = 0 ] && [ "$(grep -c '^RC=0$' "$F/runA.log")" = 1 ] \
    && ok "A1: uninstall_netfilter отработала rc=0" \
    || bad "A1: rc=$rcA ($(tail -2 "$F/runA.log"))"
chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP' \
    && chk_gone '-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP' \
    && ok "A2: negated-DROP UDP-guard снят (обе формы)" \
    || bad "A2: guard-DROP остался: $(printf '%s\n' "$LEFT" | grep 'unblocktor dst\|unblocktroj dst' | grep DROP)"
chk_gone '-A PREROUTING -p udp --dport 53 -j RETURN' \
    && ok "A3: DNS RETURN (mangle, udp/53) снят" \
    || bad "A3: DNS RETURN остался"
NACC=$(printf '%s\n' "$LEFT" | grep -c -- '--dport 8080 -j ACCEPT' || true)
[ "$NACC" = 3 ] \
    && ok "A4: проектные ACCEPT 8080 (5 приватных -s, включая 169.254) сняты, осталось ровно 3 чужих" \
    || bad "A4: осталось ACCEPT 8080: $NACC (ожидалось 3 чужих)"
chk_gone '-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4c: link-local ACCEPT (169.254.10.0/24) снят (A6-1)" \
    || bad "A4c: link-local ACCEPT пережил удаление"
chk_here '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -p udp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4b: чужие 8080 целы: голый tcp / udp / публичный -s (R48-2)" \
    || bad "A4b: чужое 8080-правило удалено: $(printf '%s\n' "$LEFT" | grep -- '--dport 8080')"
chk_gone '-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP' \
    && chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -j CONNMARK --restore-mark' \
    && chk_gone '-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1' \
    && chk_gone '-A OUTPUT -m mark --mark 0x2000000 -j RETURN' \
    && chk_gone '-A INPUT -p tcp --dport 8080 -j DROP' \
    && chk_gone '-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT' \
    && ok "A5: регрессия прежних форм: REDIRECT/TPROXY/простой DROP/CONNMARK/socket/DNAT/OUTPUT/8080-DROP сняты" \
    || bad "A5: что-то из прежних форм осталось"
chk_here '-A PREROUTING -p tcp --dport 5000 -j DROP' \
    && chk_here '-A INPUT -p tcp --dport 22 -j ACCEPT' \
    && chk_here '-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4' \
    && chk_here '-A OUTPUT -m mark --mark 0x9999999 -j RETURN' \
    && ok "A6: прочие чужие правила целы (DROP 5000 / ACCEPT 22 / DNAT 9999 / RETURN 0x9999999)" \
    || bad "A6: чужое правило удалено"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA2.log" 2>&1
rcA2=$?
LEFT2=$(cat "$F/state.txt")
if [ "$rcA2" = 0 ] && [ "$LEFT2" = "$LEFT" ]; then
    ok "A7: идемпотентность — повторный прогон rc=0, состояние не изменилось"
else
    bad "A7: rc=$rcA2, дельта: $(diff <(printf '%s\n' "$LEFT") <(printf '%s\n' "$LEFT2") | head -5)"
fi

echo "═══ B. N-5+R48-3: start() целиком (S99generator) ═══"
awk '/^start\(\) \{/,/^\}/' "$K/opt/etc/init.d/S99generator" > "$F/start.fn"
grep -q 'R48-3 (аудит-18)' "$F/start.fn" && grep -q 'SKIPPED' "$F/start.fn" \
    && ok "B0: экстракт start() ($(wc -l < "$F/start.fn") строк), preflight внутри" \
    || bad "B0: экстракт неполон"
runB(){
    CFG="$1"; ISRUN="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/start.fn" > "$F/start.case"
    {
        echo 'NAME=generator'
        echo "PIDFILE=$F/pid"
        echo "LOGFILE=$F/gen.log"
        echo "WORKDIR=$F/wd"
        echo "APP=$F/app"
        echo "is_running(){ [ -f '$F/isrun' ]; }"
        echo "kill_app(){ echo kill >> '$F/kills'; }"
        echo 'find_python(){ printf "/bin/echo\n"; }'
        echo ". '$F/start.case'"
        echo 'start'
        echo 'echo "RC=$?"'
    } > "$F/runB.sh"
    rm -f "$F/kills" "$F/pid" "$F/isrun" "$F/gen.log"
    [ "$ISRUN" = 1 ] && { : > "$F/isrun"; echo 12345 > "$F/pid"; }
    mkdir -p "$F/wd"; : > "$F/app"
    ( bash "$F/runB.sh" ) 2>/dev/null
}
mkdir -p "$F/cfg"
printf "web_username = 'admin'\nweb_password = ''\n" > "$F/cfg/empty_pass.py"
printf "web_username = ''\nweb_password = 'x'\n" > "$F/cfg/empty_user.py"
printf "web_username = 'admin'\nweb_password = 'secret'\n" > "$F/cfg/ok.py"
printf "web_username = 'admin'\nweb_password = 'x'\nэтот файл не python !!!\n" > "$F/cfg/broken.py"
O1=$(runB "$F/cfg/empty_pass.py" 0)
printf '%s' "$O1" | grep -q 'SKIPPED' && [ -z "$(printf '%s' "$O1" | grep 'Stopping')" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B1: пустой пароль, процесса нет → SKIPPED, никто не тронут" \
    || bad "B1: $O1 kills=$(cat "$F/kills" 2>/dev/null)"
O2=$(runB "$F/cfg/empty_pass.py" 1)
printf '%s' "$O2" | grep -q 'Stopping' && printf '%s' "$O2" | grep -q 'SKIPPED' \
    && [ -f "$F/kills" ] && [ ! -f "$F/pid" ] \
    && ok "B2: пустой пароль, панель жива → останов (kill_app, pidfile снят) + SKIPPED (R48-3)" \
    || bad "B2: $O2 kills=$(cat "$F/kills" 2>/dev/null) pid=$(cat "$F/pid" 2>/dev/null)"
O3=$(runB "$F/cfg/ok.py" 1)
printf '%s' "$O3" | grep -q 'already running' && [ -z "$(printf '%s' "$O3" | grep SKIPPED)" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B3: настроено, панель жива → already running, без SKIPPED/kill" \
    || bad "B3: $O3"
O4=$(runB "$F/cfg/ok.py" 0)
[ -z "$(printf '%s' "$O4" | grep SKIPPED)" ] && printf '%s' "$O4" | grep -q 'Starting' \
    && ok "B4: настроено, процесса нет → preflight пройден, старт (Starting…)" \
    || bad "B4: $O4"
O5=$(runB "$F/cfg/broken.py" 0)
[ -z "$(printf '%s' "$O5" | grep SKIPPED)" ] && printf '%s' "$O5" | grep -q 'Starting' \
    && ok "B5: сломанный python-конфиг НЕ отсекается (grep не исполняет код)" \
    || bad "B5: $O5"
L1=$(grep -n 'web_username' "$F/start.fn" | head -1 | cut -d: -f1)
L2=$(grep -n 'if is_running; then' "$F/start.fn" | head -1 | cut -d: -f1)
[ -n "$L1" ] && [ -n "$L2" ] && [ "$L1" -lt "$L2" ] \
    && ok "B6: preflight стоит ДО is_running-выхода (строки $L1 < $L2)" \
    || bad "B6: порядок нарушен ($L1 vs $L2)"

echo "═══ C. R45-4+R48-1: советы про секреты ═══"
awk '/# R45-4 \(аудит-17\)/{f=1} f{print} f && /^fi$/{n++; if (n==2) exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/sec.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/sec.body" | grep -c '__CFG__')
[ "$SUBS" = 3 ] \
    && ok "C0: экстракт блока секретов, 3 grep-условия ведут на bot_config.py" \
    || bad "C0: замен путей = $SUBS (ожидалось 3)"
runC(){
    CFG="$1"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/sec.body" > "$F/sec.run"
    ( . "$F/sec.run" )
}
printf "token = '123456:REAL-KEY'\nweb_password = ''\n" > "$F/cfg/tok.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = 'p'\n" > "$F/cfg/ph.py"
printf "token = '123456:REAL-KEY'\nweb_password = 'p'\n" > "$F/cfg/both.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = ''\n" > "$F/cfg/none.py"
printf "token='ТОКЕН_БОТА'\n" > "$F/cfg/ph2.py"
C1=$(runC "$F/cfg/tok.py")
printf '%s' "$C1" | grep -q 'перевыпустите токен' && [ -z "$(printf '%s' "$C1" | grep 'смените пароль')" ] \
    && ok "C1: токен заполнен, пароль пуст → совет про токен, без совета про пароль" \
    || bad "C1: $C1"
C2=$(runC "$F/cfg/ph.py")
printf '%s' "$C2" | grep -q 'смените пароль' && [ -z "$(printf '%s' "$C2" | grep 'перевыпустите токен')" ] \
    && ok "C2: заглушка токена, пароль заполнен → совет про пароль, без токена" \
    || bad "C2: $C2"
C3=$(runC "$F/cfg/both.py")
printf '%s' "$C3" | grep -q 'перевыпустите токен' && printf '%s' "$C3" | grep -q 'смените пароль' \
    && ok "C3: оба заполнены → оба совета" \
    || bad "C3: $C3"
C4=$(runC "$F/cfg/none.py"); C5=$(runC "$F/cfg/missing.py"); C6=$(runC "$F/cfg/ph2.py")
[ -z "$C4" ] && [ -z "$C5" ] && [ -z "$C6" ] \
    && ok "C4: заглушка+пустой пароль / нет файла / заглушка без пробелов → тишина" \
    || bad "C4: напечатано: C4=[$C4] C5=[$C5] C6=[$C6]"
NB=$(grep 'bot_token' "$K/opt/bin/deploy_bypass.sh" | grep -vc '^[[:space:]]*#' || true)
[ "${NB:-0}" = 0 ] \
    && ok "C5: несуществующего поля bot_token больше нет вне комментариев" \
    || bad "C5: bot_token вне комментариев: $NB"

echo "═══ D. R48-6: подсчёт ACCEPT 8080 в сводке ═══"
awk '/# R48-6 \(аудит-18\)/{f=1} f{ if ($0 ~ /^if \[/) exit; print }' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.block"
grep -c 'WEB_ACC=' "$F/webacc.block" | grep -q '^2$' \
    && ok "D0: экстракт присваивания WEB_ACC (обе строки)" \
    || bad "D0: экстракт неполон"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
{ echo 'IPT_BIN=/tmp/f47chk/bin/ipt_web'; cat "$F/webacc.block"; echo 'echo "WEB_ACC=$WEB_ACC"'; } > "$F/runD.sh"
D1=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=' )
[ "$D1" = "WEB_ACC=4" ] \
    && ok "D1: форма хука с -s считается (4 ACCEPT из 5 правил; старая склейка дала бы 1)" \
    || bad "D1: $D1"
printf '#!/bin/sh\nexit 0\n' > "$F/bin/ipt_web"
D2=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=')
[ "$D2" = "WEB_ACC=0" ] \
    && ok "D2: пустой вывод → WEB_ACC=0 (без unbound variable/ошибок)" \
    || bad "D2: $D2"

# A6-2: счётчик остаётся фактом, но вердикт «Доступ из LAN» не выдаётся
awk '/# R48-6 \(аудит-18\)/{f=1} f{print} f && /^fi$/{exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.full"
runD3(){
    MOCK="$1"
    {
        echo "IPT_BIN=$MOCK"
        echo 'warn(){ echo "WARN: $*"; }'
        cat "$F/webacc.full"
    } > "$F/runD3.sh"
    bash "$F/runD3.sh" 2>/dev/null
}
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
D3=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D3" | grep -q 'Найдены ACCEPT-правила на :8080 (2)' \
    && [ -z "$(printf '%s' "$D3" | grep 'Доступ из LAN')" ] \
    && ok "D3: WEB_ACC>0 → ℹ️ «Найдены ACCEPT-правила…», без вердикта «Доступ из LAN» (A6-2)" \
    || bad "D3: $D3"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT'
exit 0
EOF
D4=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D4" | grep -q 'Найдены ACCEPT-правила на :8080 (1)' \
    && [ -z "$(printf '%s' "$D4" | grep 'Доступ из LAN')" ] \
    && ok "D4: только loopback-ACCEPT → ℹ️ (не «доступ из LAN разрешён»)" \
    || bad "D4: $D4"

echo "═══ E. R48-8: сводка про порт 8080 ═══"
awk '/# Панель обязана СЛУШАТЬ/,/^fi$/' "$K/opt/bin/deploy_bypass.sh" > "$F/lstn.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/lstn.body" | grep -c '__CFG__')
[ "$SUBS" = 2 ] \
    && ok "E0: экстракт блока слушателя, оба условия (A6-3) ведут на bot_config.py" \
    || bad "E0: замен путей = $SUBS (ожидалось 2)"
runE(){
    CFG="$1"; NET="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/lstn.body" > "$F/lstn.run"
    rm -f "$F/net8080"
    [ "$NET" = 1 ] && : > "$F/net8080"
    (
        PATH="$F/bin:/usr/bin:/bin"
        warn(){ echo "WARN: $*"; }
        . "$F/lstn.run"
    )
}
E1=$(runE "$F/cfg/ok.py" 1)
printf '%s' "$E1" | grep -q '8080 слушается' \
    && ok "E1: порт слушается → ✅ (пароль не важен)" \
    || bad "E1: $E1"
E2=$(runE "$F/cfg/ok.py" 0)
printf '%s' "$E2" | grep -q 'НЕ слушается' && [ -z "$(printf '%s' "$E2" | grep 'не настроена')" ] \
    && ok "E2: пароль задан, порт молчит → предупреждение с логом" \
    || bad "E2: $E2"
E3=$(runE "$F/cfg/empty_pass.py" 0)
printf '%s' "$E3" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E3" | grep 'НЕ слушается')" ] \
    && ok "E3: пароль пуст, порт молчит → ℹ️ «не настроена», без поиска ошибки в логе (R48-8)" \
    || bad "E3: $E3"
E4=$(runE "$F/cfg/missing.py" 0)
printf '%s' "$E4" | grep -q 'не настроена' \
    && ok "E4: конфига нет → ℹ️ «не настроена»" \
    || bad "E4: $E4"
E5=$(runE "$F/cfg/empty_user.py" 0)
printf '%s' "$E5" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E5" | grep 'НЕ слушается')" ] \
    && ok "E5: пустой web_username + пароль → «не настроена», не «НЕ слушается» (A6-3)" \
    || bad "E5: $E5"

echo "═══ F. R48-9: градация test_udp_tunnels ═══"
awk '/# R48-9 \(аудит-18\)/{f=1} f{print} f && /^    fi$/{n++; if (n==4) exit}' \
    "$K/opt/bin/test_udp_tunnels.sh" > "$F/udp.block"
grep -q '_proc_up' "$F/udp.block" && grep -q 'A6-4 (аудит-19)' "$F/udp.block" \
    && [ "$(grep -c 'не проверяем' "$F/udp.block")" = 2 ] \
    && ok "F0: экстракт сокетных проверок с градацией и /proc-фолбэком" \
    || bad "F0: экстракт неполон"
runF(){
    LU="$1"; LT="$2"; PUP="$3"
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    [ "$PUP" = 1 ] && : > "$F/pidup"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"$LU\"; _lt=\"$LT\""
        echo ". '$F/udp.block'"
    } > "$F/runF.sh"
    ( PATH="$F/bin:/usr/bin:/bin" bash "$F/runF.sh" ) 2>/dev/null
}
runF "10.0.0.1:10810" "10.0.0.1:10810" 1
[ "$(wc -l < "$F/f.ok")" = 3 ] && [ ! -f "$F/f.bad" ] \
    && ok "F1: процесс жив, сокеты слушают → 3×OK" \
    || bad "F1: ok=$(cat "$F/f.ok" 2>/dev/null | wc -l) bad=$(cat "$F/f.bad" 2>/dev/null | wc -l)"
runF "" "10.0.0.1:10810" 1
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" \
    && ok "F2: процесс жив, udp-сокета нет → FAIL сохранён (реальный дефект)" \
    || bad "F2: bad=$(cat "$F/f.bad" 2>/dev/null)"
runF "" "" 0
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F3: процесс не запущен → warn, сокеты не проверяем, FAIL нет (R48-9)" \
    || bad "F3: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

# A6-4: PATH без pidof вовсе — живость через /proc-скан (имитатор xray)
_BASH4="$(command -v bash)"
mkdir -p "$F/bin2"
ln -sf "$(command -v tr)" "$F/bin2/tr"
ln -sf "$(command -v head)" "$F/bin2/head"
cp /bin/sleep "$F/bin2/xray" && chmod +x "$F/bin2/xray"
"$F/bin2/xray" 30 & _IMPID=$!
runFP(){
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"\"; _lt=\"\""
        echo ". '$F/udp.block'"
    } > "$F/runFP.sh"
    # bash по абсолютному пути: VAR=x cmd резолвит cmd уже в новом PATH
    ( PATH="$F/bin2" "$_BASH4" "$F/runFP.sh" ) 2>/dev/null
}
runFP
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" && grep -q 'запущен' "$F/f.ok" \
    && ok "F4: без pidof живой процесс найден через /proc → udp-FAIL сохранён (A6-4)" \
    || bad "F4: ok=$(cat "$F/f.ok" 2>/dev/null) bad=$(cat "$F/f.bad" 2>/dev/null)"
kill "$_IMPID" 2>/dev/null; wait "$_IMPID" 2>/dev/null
runFP
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F5: без pidof процесс отсутствует → warn, FAIL нет" \
    || bad "F5: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

echo "═══ J. Аудит-19: R49-1 (дубль unblock_update), R49-2 (hysteria) ═══"
NB1=$(grep 'safe_start_service "S99unblock"' "$K/opt/bin/deploy_bypass.sh" \
    | grep -vc '^[[:space:]]*#' || true)
[ "${NB1:-0}" = 0 ] && grep -q 'R49-1 (аудит-19)' "$K/opt/bin/deploy_bypass.sh" \
    && ok "J1: deploy не запускает S99unblock в фоне (дубль исключён, контракт-комментарий на месте)" \
    || bad "J1: живых вызовов S99unblock: $NB1"
grep -q '/opt/bin/unblock_update.sh >/dev/null 2>&1 &' \
    "$K/opt/etc/init.d/S99unblock" \
    && ok "J2: boot-путь S99unblock не тронут (фоновый запуск при загрузке)" \
    || bad "J2: S99unblock изменился"
# NB: head -1|awk для XRAY корректен (первая строка без баннера) —
# инвариант только про hysteria-строку
HYLINE=$(grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1)
printf '%s' "$HYLINE" | grep -qF "head -1 | awk" \
    && bad "J3: hysteria-строка всё ещё парсится по первому полю баннера" \
    || ok "J3: парсинг версии hysteria — grep -oE (xray-строки не тронуты)"
mkdir -p "$F/bin3"
cat > "$F/bin3/hysteria" <<'HYS'
#!/bin/sh
printf 'Hysteria2 \xe2\x9c\x93\n'
printf 'Version:        app/v2.13.0\n'
printf 'Platform:       linux/amd64\n'
exit 0
HYS
chmod +x "$F/bin3/hysteria"
grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1 > "$F/hy.echo"
( PATH="$F/bin3:/usr/bin:/bin" sh -c "_hy_bin='$F/bin3/hysteria'; . '$F/hy.echo'" ) > "$F/hy.out" 2>/dev/null
grep -q 'уже установлена (2.13.0), скачивание пропущено' "$F/hy.out" \
    && ok "J4: hysteria 2.x (баннер первой строкой) → «уже установлена (2.13.0)» (R49-2)" \
    || bad "J4: вывод: $(cat "$F/hy.out" 2>/dev/null)"
ND=$(grep -c 'аудит-19' "$K/opt/bin/deploy_bypass.sh" || true)
NT=$(grep -c 'аудит-19' "$K/opt/bin/test_udp_tunnels.sh" || true)
[ "$ND" -ge 5 ] && [ "$NT" -ge 1 ] \
    && ok "J5: маркеры аудита-19: deploy=$ND, test_udp_tunnels=$NT" \
    || bad "J5: deploy=$ND test_udp=$NT"

echo "═══ K. Аудит-20: firewall панели, /tmp-обёртки, ротация, TG, CSRF ═══"
GEN="$K/opt/etc/bot/generator.py"

# K1 (FW-1): в setup_firewall нет blanket-цикла по ALLOWED_SUBNETS;
# подсети берутся из LAN-интерфейсов (паритет с B7 хука).
K1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'for net in \[str(n) for n in ALLOWED_SUBNETS\]' || true)
K1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "proto kernel\|'inet'" || true)
grep -q 'веб-панель доступна только с 127.0.0.1' "$GEN" && K1C=1 || K1C=0
[ "$K1A" = 0 ] && [ "$K1B" -ge 2 ] && [ "$K1C" = 1 ] \
    && ok "K1: setup_firewall — подсети LAN-интерфейсов (B7-паритет), без blanket" \
    || bad "K1: blanket=$K1A lan_list=$K1B degr=$K1C"

# K2 (TW-1 + FB-121): без файлов-обёрток в /tmp; sh -c + O_NOFOLLOW +
# mkstemp; значения body — из env, прогон в режиме «sh -c без argv».
K2A=$(grep -c 'WRAPPER' "$GEN" || true)
K2B=$(grep -c "'-c', body]," "$GEN" || true)
K2C=$(grep -c 'O_NOFOLLOW' "$GEN" || true)
K2D=$(grep -c 'mkstemp' "$GEN" || true)
if [ "$K2A" = 0 ] && [ "$K2B" = 2 ] && [ "$K2C" -ge 2 ] && [ "$K2D" -ge 3 ]; then
    # поведенческий прогон точного body обёртки unblock
    KF2="$(mktemp -d)"
    sed -n "/^ *body = '\{3\}/,/^'\{3\}$/p" "$GEN" \
        | sed "1s/^ *body = '\{3\}//; \$d" > "$KF2/body.sh"
    dash -n "$KF2/body.sh" 2>/dev/null
    printf '#!/bin/sh\necho out; echo err >&2; exit 7\n' > "$KF2/s.sh"
    chmod +x "$KF2/s.sh"
    KZ_STATUS_FILE="$KF2/st.json" KZ_TMP_STATUS="$KF2/tm" \
        KZ_SCRIPT="$KF2/s.sh" KZ_ONLY= \
        sh -c "$(cat "$KF2/body.sh")" > "$KF2/run.log" 2>&1
    K2RC=$?
    if [ "$K2RC" = 7 ] \
        && grep -q 'out' "$KF2/run.log" \
        && grep -q '"status":"error"' "$KF2/st.json" \
        && grep -q 'exit code 7' "$KF2/st.json"; then
        ok "K2: обёртки — sh -c + O_NOFOLLOW; body (env, без argv): rc/log/фолбэк-статус верны (FB-121)"
    else
        bad "K2: body-прогон rc=$K2RC: $(cat "$KF2/st.json" 2>/dev/null)"
    fi
    rm -rf "$KF2"
else
    bad "K2: WRAPPER=$K2A sh-c=$K2B nofollow=$K2C mkstemp=$K2D"
fi

# K3 (RL-1): триггер ротации — только размер; KEEP — цель обрезки.
K3T=$(grep -c 'if \[ "$_sz" -gt "$MAX" \]' "$K/opt/bin/rotate_logs.sh" || true)
K3L=$(grep -c -- '-gt "$KEEP"' "$K/opt/bin/rotate_logs.sh" || true)
KF3="$(mktemp -d)"
sed 's|^rotate /opt/etc/bot/error.log$|rotate "$TGT"|; s|^rotate /opt/root/KeenSnap/backup.log$|:|; s|^rotate /opt/var/log/100-redirect.log$|:|; s|^rotate /tmp/unblock_update.log$|:|; s|^MAX=.* rotate |: # |; s|^find /tmp -maxdepth 1|: find /nonexistent|' \
    "$K/opt/bin/rotate_logs.sh" > "$KF3/rot.sh"
sed -i "s|^umask 022|umask 022\nTGT=\"$KF3/error.log\"|" "$KF3/rot.sh"
dash -n "$KF3/rot.sh" 2>/dev/null
awk 'BEGIN{for(i=1;i<=150;i++)print "line"i}' > "$KF3/error.log"
MAX=524288 KEEP=100 sh "$KF3/rot.sh"
K3A=$(wc -l < "$KF3/error.log")
awk 'BEGIN{for(i=1;i<=1000;i++)print "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}' \
    > "$KF3/error.log"
MAX=50000 KEEP=100 sh "$KF3/rot.sh"
K3B=$(wc -l < "$KF3/error.log")
if [ "$K3T" = 1 ] && [ "$K3L" = 0 ] && [ "$K3A" = 150 ] && [ "$K3B" = 100 ]; then
    ok "K3: ротация по размеру: 150 строк<MAX не тронуты, >MAX → KEEP=100"
else
    bad "K3: триггер=$K3T keep-триггер=$K3L A=$K3A B=$K3B"
fi
rm -rf "$KF3"

# K4 (TG-1): общая tg_send_message; urlencode; токен вне cmdline.
K4A=$(grep -c 'tg_send_message()' "$K/opt/bin/common.sh" || true)
K4B=$(grep -c -- '--data-urlencode' "$K/opt/bin/common.sh" || true)
K4C=$(grep -c -- '-K -' "$K/opt/bin/common.sh" || true)
K4D=$(( $(grep -c 'text=\${' "$K/opt/bin/check_updates.sh" || true) \
    + $(grep -c 'text=\${' "$K/opt/bin/unblock_dnsmasq.sh" || true) ))
KF4="$(mktemp -d)"; mkdir -p "$KF4/bin" "$KF4/run"
sed "s|/opt/etc/bot/bot_config.py|$KF4/bot_config.py|g; s|/opt/var/run/|$KF4/run/|g" \
    "$K/opt/bin/common.sh" > "$KF4/common_m.sh"
printf 'token = "ABC123TOKEN"\n' > "$KF4/bot_config.py"
echo "-100200300" > "$KF4/run/bot_chat_id_notify.txt"
printf '#!/bin/sh\necho "ARGV:$@" >> "$MOCKLOG"\ncat > "$MOCKCFG"\nexit 0\n' \
    > "$KF4/bin/curl"
chmod +x "$KF4/bin/curl"
export MOCKLOG="$KF4/argv.log" MOCKCFG="$KF4/cfg.txt"
K4E=$(PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_urlencode 'a&b%c+d<e>'")
PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_send_message 'обновление & готово 100%' HTML"
K4G=0; grep -q 'ABC123TOKEN' "$KF4/argv.log" 2>/dev/null || K4G=1
K4H=0; grep -q 'url = "https://api.telegram.org/botABC123TOKEN/sendMessage"' \
    "$KF4/cfg.txt" 2>/dev/null && K4H=1
if [ "$K4A" = 1 ] && [ "$K4B" -ge 1 ] && [ "$K4C" -ge 1 ] && [ "$K4D" = 0 ] \
    && [ "$K4E" = 'a%26b%25c%2Bd%3Ce%3E' ] && [ "$K4G" = 1 ] && [ "$K4H" = 1 ]; then
    ok "K4: tg_send_message: -K -, --data-urlencode, urlencode, токен вне argv"
else
    bad "K4: fn=$K4A ue=$K4B K=$K4C oldtext=$K4D enc=$K4E tok=$K4G url=$K4H"
fi
rm -rf "$KF4"

# K5 (CS-1+O-1/AF-1): request.host не источник доверия; политика в
# helpers; sweep вызывается из security_checks.
K5A=$(grep -c 'str(request.host)' "$GEN" || true)
K5B=$(grep -c 'def _csrf_origin_allowed' "$GEN" || true)
K5C=$(grep -c 'def _auth_fails_sweep' "$GEN" || true)
K5D=$(grep -c '_auth_fails_sweep(' "$GEN" || true)
[ "$K5A" = 0 ] && [ "$K5B" = 1 ] && [ "$K5C" = 1 ] && [ "$K5D" -ge 2 ] \
    && ok "K5: Origin/_auth_fails — политика в helpers, вызов на месте (L-1+O-1/AF-1)" \
    || bad "K5: reqhost=$K5A origin_h=$K5B sweep_h=$K5C calls=$K5D"

# K6 (BC-1): ранний chmod 0600 bot_config.py сразу после apply.
K6A=$(grep -c 'chmod 0600 /opt/etc/bot/bot_config.py' "$K/opt/bin/deploy_bypass.sh" || true)
K6B=$(sed -n "$(grep -n 'if busybox cp -a' "$K/opt/bin/deploy_bypass.sh" | head -1 | cut -d: -f1),+42p" \
    "$K/opt/bin/deploy_bypass.sh" | grep -c 'BC-1' || true)
[ "$K6A" -ge 4 ] && [ "$K6B" -ge 2 ] \
    && ok "K6: chmod 0600 bot_config.py после apply (BC-1, до аварийных выходов)" \
    || bad "K6: chmod-строк=$K6A маркеров-возле-apply=$K6B"

echo "═══ L. Аудит-21: legacy-blanket, preflight, предупреждение -remove ═══"

# L1 (FW-1b): зачистка legacy-blanket в setup_firewall; fallback нет.
L1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "legacy_net in ('192.168.0.0/16', '10.0.0.0/8'," || true)
L1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'ALLOWED_SUBNETS' || true)
[ "$L1A" = 1 ] && [ "$L1B" = 0 ] \
    && ok "L1: legacy-blanket снимается панелью; fallback на ALLOWED_SUBNETS нет" \
    || bad "L1: legacy=$L1A fallback=$L1B"

# L2 (PF-1): preflight — только flask+markupsafe; текст deploy раздельный.
L2A=$(grep -c 'import flask, markupsafe' "$K/opt/etc/init.d/S99generator" || true)
L2B=$(grep -c 'import flask, requests' "$K/opt/etc/init.d/S99generator" || true)
L2C=$(grep -c 'Панели нужен flask (+markupsafe); боту — telebot и requests' \
    "$K/opt/bin/deploy_bypass.sh" || true)
L2D=$(grep -c 'Веб-панель и бот без этих модулей не запустятся' \
    "$K/opt/bin/deploy_bypass.sh" || true)
[ "$L2A" = 1 ] && [ "$L2B" = 0 ] && [ "$L2C" = 1 ] && [ "$L2D" = 0 ] \
    && ok "L2: preflight flask+markupsafe (без requests); текст deploy раздельный" \
    || bad "L2: preflight=$L2A/$L2B текст=$L2C/$L2D"

# L3 (RM-1): uninstall_netfilter предупреждает об остатке чужих ACCEPT.
# Поведенчески: тот же экстракт/мок, что в секции A.
cat > "$F/runL.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/l3state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runL.sh"
cp "$F/rules.txt" "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3a.log" 2>&1
L3A=$(grep -c 'вне формы проекта: 3' "$F/l3a.log" || true)
grep -v -- '--dport 8080 -j ACCEPT' "$F/rules.txt" > "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3b.log" 2>&1
L3B=$(grep -c 'вне формы проекта' "$F/l3b.log" || true)
L3RC=$(grep -c '^RC=0$' "$F/l3a.log" || true)
if [ "$L3A" = 1 ] && [ "$L3B" = 0 ] && [ "$L3RC" = 1 ]; then
    ok "L3: -remove предупреждает о 3 чужих ACCEPT; без чужих — молчит; rc=0"
else
    bad "L3: с-чужими=$L3A без-чужих=$L3B rc=$L3RC"
fi

echo "═══ M. Аудит-22: Origin-туннель, tmp-статус, кап, нормализация ═══"

# M1 (O-1): поведенческая матрица _csrf_origin_allowed (экстракция).
python3 - "$GEN" > "$F/m1.out" 2>&1 <<'PYM1'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _csrf_origin_allowed\(.*?(?=^(?:@app\.before_request\n)?def )', src, re.M | re.S)
assert m, 'no _csrf_origin_allowed'
import ipaddress
from urllib.parse import urlparse
g = {
    'ipaddress': ipaddress, 'urlparse': urlparse,
    'LAN_IP': '192.168.1.1', 'LISTEN_PORT': 8080,
    '_lan_host_addresses': lambda: {'192.168.2.1'},
    '_ORIGIN_EXTRA_HOSTS': ['my.keenetic.net'],
}
exec(m.group(0), g)
f = g['_csrf_origin_allowed']
cases = [
    ('http://192.168.1.1:8080', '192.168.1.5', True),
    ('http://127.0.0.1:18080', '127.0.0.1', True),
    ('http://localhost:19000', '127.0.0.1', True),
    ('http://127.0.0.1:18080', '192.168.1.5', False),
    ('http://127.0.0.1:8080', '192.168.1.5', False),
    ('http://localhost:8080', '192.168.1.5', False),
    ('http://192.168.2.1:8080', '192.168.1.5', True),
    ('http://my.keenetic.net:8080', '192.168.1.5', True),
    ('http://evil.example:8080', '192.168.1.5', False),
    ('http://192.168.1.1', '192.168.1.5', False),
    ('ftp://192.168.1.1:8080', '192.168.1.5', False),
]
bad = [i for i, (o, c, want) in enumerate(cases) if f(o, c) != want]
if bad:
    print('BAD=%s' % ','.join(map(str, bad)))
else:
    print('MATRIX_OK(%d)' % len(cases))
PYM1
grep -q 'MATRIX_OK(11)' "$F/m1.out" \
    && ok "M1: Origin: туннель ✓ (loopback-клиент), удалённый loopback ✗ на любом порту (A9-4), альт-LAN-IP ✓, конфиг-имя ✓, чужие ✗" \
    || bad "M1: $(cat "$F/m1.out")"

# M2 (TS-1): tmp-статус не переживает прогон (успех и fallback).
KF6="$(mktemp -d)"
python3 - "$GEN" > "$KF6/body.sh" <<'PYM2'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search('body = ' + Q + '(.*?)' + Q, src, re.S)
assert m, 'no body'
sys.stdout.write(m.group(1))
PYM2
dash -n "$KF6/body.sh" 2>/dev/null
printf '{"status":"done","ts":1,"message":"by script"}\n' > "$KF6/st1.json"
printf '#!/bin/sh\nexit 0\n' > "$KF6/s0.sh"; chmod +x "$KF6/s0.sh"
KZ_STATUS_FILE="$KF6/st1.json" KZ_TMP_STATUS="$KF6/tmp1" \
    KZ_SCRIPT="$KF6/s0.sh" KZ_ONLY= \
    sh -c "$(cat "$KF6/body.sh")" > "$KF6/a.log" 2>&1
printf '#!/bin/sh\nexit 7\n' > "$KF6/s7.sh"; chmod +x "$KF6/s7.sh"
KZ_STATUS_FILE="$KF6/st2.json" KZ_TMP_STATUS="$KF6/tmp2" \
    KZ_SCRIPT="$KF6/s7.sh" KZ_ONLY= \
    sh -c "$(cat "$KF6/body.sh")" > "$KF6/b.log" 2>&1
if [ ! -e "$KF6/tmp1" ] && [ ! -e "$KF6/tmp2" ] \
    && grep -q 'by script' "$KF6/st1.json" \
    && grep -q '"status":"error"' "$KF6/st2.json" \
    && grep -q 'exit code 7' "$KF6/st2.json"; then
    ok "M2: tmp-статус удалён и при успехе (trap), и при fallback (mv); статусы верны"
else
    bad "M2: tmp1=$([ -e "$KF6/tmp1" ] && echo есть || echo нет) tmp2=$([ -e "$KF6/tmp2" ] && echo есть || echo нет)"
fi
rm -rf "$KF6"
K2TRAP=$(grep -c "trap 'rm -f" "$GEN" || true)
K2EXC=$(grep -c 'os.unlink(tmp_status)' "$GEN" || true)
[ "$K2TRAP" = 2 ] && [ "$K2EXC" = 2 ] \
    && ok "M2b: trap в обоих body + очистка при отказе Popen (TS-1)" \
    || bad "M2b: trap=$K2TRAP unlink=$K2EXC"

# M3 (AF-1 + FB-11): кап 256; истёкшие блокировки чистятся; активный
# счётчик НЕ сбрасывается (K50-2); 429 достижим; предел после вставки.
python3 - "$GEN" > "$F/m3.out" 2>&1 <<'PYM3'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
mc = re.search(r'^_AUTH_FAILS_MAX = (\d+)$', src, re.M)
mt = re.search(r'^def _auth_fails_trim\(.*?(?=^def )', src, re.M | re.S)
mf = re.search(r'^def _auth_fails_sweep\(.*?(?=^def )', src, re.M | re.S)
assert mc and mt and mf, 'no const/funcs'
g = {'_AUTH_FAILS_MAX': int(mc.group(1))}
exec(mt.group(0), g)
exec(mf.group(0), g)
trim, sweep = g['_auth_fails_trim'], g['_auth_fails_sweep']
d = {('10.%d.0.1' % i): (5, 2e9) for i in range(300)}
sweep(d, '10.0.0.1', 1e9)
cap_ok = len(d) == 256
d2 = {'a': (0, 100.0), 'b': (5, 2e9)}
r = sweep(d2, 'a', 1e9)
exp_ok = 'a' not in d2 and 'b' in d2 and r == (0, 0.0)
d3 = {'c': (3, 0.0)}
r3 = sweep(d3, 'c', 1e9)
keep_ok = r3 == (3, 0.0) and 'c' in d3
fm = {}
hist = []
for i in range(6):
    f, b = sweep(fm, 'c', 1000.0 + i)
    if b > 1000.0 + i:
        hist.append('429')
        continue
    f += 1
    if f >= 5:
        fm['c'] = (0, 1000.0 + i + 300)
        hist.append('B')
    else:
        fm['c'] = (f, 0.0)
        hist.append(str(f))
    trim(fm)
sim_ok = hist == ['1', '2', '3', '4', 'B', '429']
fm2 = {('c%d' % i): (1, 0.0) for i in range(256)}
sweep(fm2, 'new', 1e9)
fm2['new'] = (1, 0.0)
trim(fm2)
ins_ok = len(fm2) == 256
res = (cap_ok, exp_ok, keep_ok, sim_ok, ins_ok)
print('OK' if all(res) else
      'BAD cap=%s exp=%s keep=%s sim=%s(%s) ins=%s(%d)' % (
          cap_ok, exp_ok, keep_ok, sim_ok, hist, ins_ok, len(fm2)))
PYM3
grep -q '^OK$' "$F/m3.out" \
    && ok "M3: кап 256; истёкшая снята; активный счётчик жив; 6 неудачных → блок+429; предел после вставки (AF-1+FB-11)" \
    || bad "M3: $(cat "$F/m3.out")"

# M4 (SN-1): fallback-нормализация host-bits; невалидные пропущены.
python3 - "$GEN" > "$F/m4.out" 2>&1 <<'PYM4'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _lan_subnet_list\(.*?(?=^def )', src, re.M | re.S)
assert m, 'no func'
import ipaddress, threading
class _R:
    def __init__(self, out): self.stdout = out
class _SP:
    def run(self, args, **kw):
        if args[:4] == ['ip', '-4', 'route', 'show']:
            return _R('')
        if args[:4] == ['ip', '-4', 'addr', 'show']:
            return _R(
                '2: br9: <BROADCAST,MULTICAST,UP>\n'
                '    inet 192.168.2.1/24 brd 192.168.2.255 br9\n'
                '    inet 10.0.0.99/8 brd 10.255.255.255 br9\n'
                '    inet frog/24 br9\n')
        return _R('')
class _C:
    lan_ifaces = ['br9']
g = {'subprocess': _SP(), 'ipaddress': ipaddress, 'config': _C(),
     'threading': threading}
exec(m.group(0), g)
nets, found = g['_lan_subnet_list']()
ok1 = '192.168.2.1/24' not in nets and '192.168.2.0/24' in nets
ok2 = '10.0.0.0/8' in nets
ok3 = not any('frog' in n for n in nets)
ok4 = nets and nets[0] == '127.0.0.0/8' and found is True
print('OK' if ok1 and ok2 and ok3 and ok4 else
      'BAD %r' % (nets,))
PYM4
grep -q '^OK$' "$F/m4.out" \
    && ok "M4: fallback: 192.168.2.1/24 → 192.168.2.0/24; 10.0.0.99/8 → 10.0.0.0/8; frog пропущен (SN-1)" \
    || bad "M4: $(cat "$F/m4.out")"
grep -q 'ACCEPT не создан' "$GEN" \
    && ok "M4b: отказ создания ACCEPT логируется (SN-1)" \
    || bad "M4b: нет логирования отказа ACCEPT"

echo "═══ N. Аудит-23: проверка фидов Entware (сбой установки r48) ═══"
NB="$F/nb"; mkdir -p "$NB/bin" "$NB/dl"
DEP="$K/opt/bin/deploy_bypass.sh"
# экстракция функций блока зеркал
for _nfn in _entware_stock_feeds _entware_feed_base _entware_probe_feed_url \
            _entware_feeds_reachable _entware_prepare_candidate pick_entware_base; do
    awk "/^${_nfn}\(\) \{/,/^\}/" "$DEP" >> "$NB/fns.sh"
    echo >> "$NB/fns.sh"
done
grep -q '^pick_entware_base()' "$NB/fns.sh" || bad "N0: экстракция блока зеркал не удалась"

# N1 (FB-2): https-проба без curl → «не проверено» (rc 2), не «нет».
printf '#!/bin/sh\nexit 1\n' > "$NB/bin/wget"; chmod +x "$NB/bin/wget"
cat > "$NB/run1.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD=""
export KEENZOO_DLTMP DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run1.sh"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run1.sh" 2>/dev/null | tail -1)
[ "$NBRC" = "PROBE_RC=2" ] \
    && ok "N1: https без curl → «не проверено» (rc 2), зеркало не бракуется (FB-2)" \
    || bad "N1: $NBRC (ожидался PROBE_RC=2)"

# N2 (FB-3): curl-проба лёгкая (Range 256Б), а не полная загрузка.
printf '#!/bin/sh\necho "ARGV:$@" >> /tmp/f47chk/nb/curl.log\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c 256 /dev/zero > "$2"; shift; done\nexit 0\n' \
    > "$NB/bin/curl"; chmod +x "$NB/bin/curl"
cat > "$NB/run2.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD="curl"
export KEENZOO_DLTMP DL_CMD
have_cmd() { command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run2.sh"
rm -f "$NB/curl.log"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run2.sh" 2>/dev/null | tail -1)
if [ "$NBRC" = "PROBE_RC=0" ] && grep -q -- '-r 0-255' "$NB/curl.log" 2>/dev/null; then
    ok "N2: curl-проба — Range 256Б (не полная загрузка Packages.gz) (FB-3)"
else
    bad "N2: rc=$NBRC; curl-лог: $(cat "$NB/curl.log" 2>/dev/null | head -1)"
fi
rm -f "$NB/bin/curl"

# N3/N4/N5: поведенческие сценарии pick_entware_base (как на устройстве).
cat > "$NB/pick.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl
KZ_DEPLOY_OPKG_CONF="$1"
ENTWARE_ARCH=aarch64-k3.10; DL_CMD=""
export KEENZOO_DLTMP KZ_DEPLOY_OPKG_CONF ENTWARE_ARCH DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { echo "WARN: $*"; }
die()   { echo "DIE: $*"; exit 42; }
ENTWARE_MIRRORS="https://bin.entware.net https://entware.diversion.ch"
_ENTWARE_BASE_REQUESTED=""
ENTWARE_BASE=""; ENTWARE_MIRROR_SWITCH_NEEDED=0; ENTWARE_MIRROR_CHANGED=0
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
pick_entware_base >/dev/null 2>&1
echo "PICK_RC=$?"
EOF
chmod +x "$NB/pick.sh"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc/gz keendev http://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\nsrc/gz keendev https://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/https.conf"
RC_A=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/http.conf" 2>/dev/null | tail -1)
RC_B=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/https.conf" 2>/dev/null | tail -1)
[ "$RC_A" = "PICK_RC=0" ] \
    && ok "N3: сценарий устройства (http-фиды, curl нет) → rc 0, установка не гибнет (FB-6 аудита-24)" \
    || bad "N3: $RC_A (ожидался PICK_RC=0)"
[ "$RC_B" = "PICK_RC=0" ] \
    && ok "N4: https-фиды без curl → rc 0: установка НЕ гибнет, решает opkg update (FB-1/FB-2)" \
    || bad "N4: $RC_B (ожидался PICK_RC=0)"

# N5 (FB-1/FB-5): инварианты текстов и семантики в самом deploy.
N5A=$(grep -c 'ни один HTTPS-кандидат не прошёл' "$DEP" || true)
N5B=$(grep -c 'Разрешить осознанно: KEENZOO_ALLOW_HTTP_FEED=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5C=$(grep -c 'KEENZOO_OPKG_OFFLINE=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5D=$(grep -c 'Автоматический бутстрап HTTPS ниже попробует зеркала' "$DEP" || true)
[ "$N5A" = 0 ] && [ "$N5B" = 1 ] && [ "$N5C" -ge 1 ] && [ "$N5D" = 1 ] \
    && ok "N5: старые немые die убраны; подсказки-обходы на месте; недоступность фида → авто-бутстрап зеркал (FB-1/FB-5/FB-6/FB-78)" \
    || bad "N5: старый-die=$N5A allow-hint=$N5B offline-hint=$N5C fb78-hint=$N5D"

echo "═══ P. Аудит-24: HTTP-гейт в точке риска, retry пробы ═══"
PB="$F/pb"; mkdir -p "$PB/bin" "$PB/dl"
# экстракция гейт-хелперов
for _pfn in _kz_pkg_installed _kz_http_feed_active _kz_http_install_gate; do
    awk "/^${_pfn}\(\) \{/,/^\}/" "$DEP" >> "$PB/gate.sh"
    echo >> "$PB/gate.sh"
done
grep -q '^_kz_http_install_gate()' "$PB/gate.sh" || bad "P0: экстракция гейтов не удалась"

# фейковый opkg: list-installed знает только tor; /var/opkg/status недоступен
printf '#!/bin/sh\n[ "$1" = list-installed ] && { echo "tor - 1.0"; exit 0; }\nexit 0\n' \
    > "$PB/bin/opkg"; chmod +x "$PB/bin/opkg"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\n' > "$PB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$PB/https.conf"

cat > "$PB/g.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/pb/bin:/bin"; export PATH
warn() { echo "WARN: $*"; }
. /tmp/f47chk/pb/gate.sh >/dev/null 2>&1
case "$1" in
    installed) _kz_pkg_installed "$2"; echo "RC=$?";;
    gate)      KZ_DEPLOY_OPKG_CONF="$2" KEENZOO_ALLOW_HTTP_FEED="${3:-0}" \
                   _kz_http_install_gate testpkg; echo "RC=$?";;
esac
EOF
chmod +x "$PB/g.sh"
GR1=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed tor 2>/dev/null | tail -1)
GR2=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed xray 2>/dev/null | tail -1)
GR3=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 0 2>/dev/null | tail -1)
GR4=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 1 2>/dev/null | tail -1)
GR5=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/https.conf 0 2>/dev/null | tail -1)
if [ "$GR1" = "RC=0" ] && [ "$GR2" = "RC=1" ] && [ "$GR3" = "RC=1" ] \
    && [ "$GR4" = "RC=0" ] && [ "$GR5" = "RC=0" ]; then
    ok "P1: гейт: установлен→пропуск; http без ALLOW→warn+пропуск; http+ALLOW/https→можно (FB-6)"
else
    bad "P1: inst=$GR1/$GR2 http0=$GR3 http1=$GR4 https=$GR5"
fi
GATE_WARNS=$(PATH=/usr/bin:/bin KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/pb/http.conf bash -c \
    'warn(){ echo "WARN:$*"; }; PATH="/tmp/f47chk/pb/bin:/bin"; . /tmp/f47chk/pb/gate.sh >/dev/null 2>&1; _kz_http_install_gate testpkg' 2>/dev/null)
printf '%s' "$GATE_WARNS" | grep -q 'KEENZOO_ALLOW_HTTP_FEED=1' \
    && ok "P2: warn гейта несёт обход KEENZOO_ALLOW_HTTP_FEED=1 (FB-7)" \
    || bad "P2: warn гейта без подсказки: $GATE_WARNS"

# P3: гейт вызван во всех сетевых opkg install шага пакетов.
P3A=$(grep -c '_kz_http_install_gate' "$DEP" || true)
P3B=$(grep -c '_kz_pkg_installed "\$pkg" && continue' "$DEP" || true)
[ "$P3A" -ge 10 ] && [ "$P3B" = 1 ] \
    && ok "P3: гейт на всех местах установок ($P3A); цикл пакетов: skip-if-installed" \
    || bad "P3: gate=$P3A skip=$P3B"

# P4 (FB-8): http-проба — ensure_dns + повтор.
# FB-51 (аудит-28) добавил внутрь http-ветки case с собственными ;;,
# поэтому прежний awk-диапазон до первого ;; обрезался — считаем по
# всей функции пробы.
awk 'index($0, "_entware_probe_feed_url() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$F/p4fn.sh"
P4A=$(grep -c 'ensure_dns' "$F/p4fn.sh" || true)
P4B=$(grep -c '_epf_try' "$F/p4fn.sh" || true)
P4C=$(grep -c 'while \[ "\$_epf_try" -le 2 \]' "$F/p4fn.sh" || true)
[ "$P4A" -ge 1 ] && [ "$P4B" -ge 3 ] && [ "$P4C" -ge 1 ] \
    && ok "P4: http-проба: ensure_dns + 2 попытки (FB-8; диапазон уточнён под case FB-51)" \
    || bad "P4: dns=$P4A retry=$P4B loops=$P4C"

# P5: формулировки.
P5A=$(grep -c 'Пакеты бутстрапа HTTPS установлены' "$DEP" || true)
P5B=$(grep -c 'Пакеты бутстрапа HTTPS не установлены' "$DEP" || true)
[ "$P5A" -ge 2 ] && [ "$P5B" -ge 1 ] \
    && ok "P5: формулировки факта авто-бутстрапа: установка (текущий фид/зеркало) и провал — честные вердикты (FB-9/FB-78/FB-81)" \
    || bad "P5: установлены=$P5A провал=$P5B"

echo "═══ Q. Аудит-25: панель, HTTP-политика, Origin, гейты ═══"

# Q0 (FB-10): единственный @app.before_request стоит на security_checks().
python3 - "$GEN" > "$F/q0.out" 2>&1 <<'PYQ0'
import sys
lines = open(sys.argv[1], encoding='utf-8').read().split('\n')
dec = [i for i, l in enumerate(lines) if l.strip() == '@app.before_request']
ok = (len(dec) == 1 and dec[0] + 1 < len(lines)
      and lines[dec[0] + 1].startswith('def security_checks():'))
print('OK' if ok else 'BAD dec=%r' % [lines[i] for i in dec])
PYQ0
grep -q '^OK$' "$F/q0.out" \
    && ok "Q0: @app.before_request — единственный и на security_checks() (K50-1)" \
    || bad "Q0: $(cat "$F/q0.out")"

# Q1 (FB-11): lock вокруг sweep+вставки; предел после вставки.
Q1A=$(grep -c '^_AUTH_FAILS_LOCK = threading.Lock()' "$GEN" || true)
Q1B=$(grep -c 'with _AUTH_FAILS_LOCK:' "$GEN" || true)
Q1C=$(grep -c '_auth_fails_trim(_auth_fails)' "$GEN" || true)
[ "$Q1A" = 1 ] && [ "$Q1B" = 1 ] && [ "$Q1C" = 1 ] \
    && ok "Q1: sweep+вставка под _AUTH_FAILS_LOCK; trim после вставки (K50-2/A9-5)" \
    || bad "Q1: lock=$Q1A with=$Q1B trim=$Q1C"

# Q2 (FB-14): базовое имя, ключ конфига, нет портового фолбэка loopback.
Q2A=$(grep -c "_ORIGIN_EXTRA_HOSTS = \['my.keenetic.net'\] + \[" "$GEN" || true)
Q2B=$(grep -c "'allowed_origin_hosts'" "$K/opt/etc/bot/bot_config.py" || true)
Q2C=$(grep -c 'return port == str(LISTEN_PORT)' "$GEN" || true)
[ "$Q2A" = 1 ] && [ "$Q2B" -ge 1 ] && [ "$Q2C" = 0 ] \
    && ok "Q2: my.keenetic.net в базовом наборе; ключ в bot_config; loopback — только loopback-клиент (K50-4/A9-4)" \
    || bad "Q2: base=$Q2A cfg=$Q2B fallback=$Q2C"

# Q3 (FB-12): гейт заглушки в S57hysteria — статика и поведение.
S57="$K/opt/etc/init.d/S57hysteria"
Q3A=$(grep -c 'SKIPPED: hysteria не настроена' "$S57" || true)
Q3B=$(grep -c 'CHANGE_ME' "$S57" || true)
Q3C=$(grep -n 'case "${1:-}" in' "$S57" | head -1 | cut -d: -f1)
Q3D=$(grep -n '^\. /opt/etc/init.d/rc\.func' "$S57" | head -1 | cut -d: -f1)
QB="$F/qb"; mkdir -p "$QB"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$QB/gate.sh"
printf '{\n  "server": "example.com:443",\n  "auth": "CHANGE_ME"\n}\n' > "$QB/ph.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k"\n}\n' > "$QB/ok.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k",\n  "tls": {"sni": "example.com"}\n}\n' > "$QB/sni.json"
printf '{\n  "server": "",\n  "auth": "k"\n}\n' > "$QB/empty.json"
cat > "$QB/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/qb/gate.sh
echo "GATE_RC=PASS"
EOF
chmod +x "$QB/run.sh"
Q3R1=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$QB/ph.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R2=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$QB/ok.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R3=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$QB/sni.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R4=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$QB/empty.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R5=$(KEENZOO_HYSTERIA_CONFIG="$QB/ph.json" sh "$QB/run.sh" stop 2>&1; echo "rc=$?")
if [ "$Q3A" -ge 1 ] && [ "$Q3B" -ge 1 ] && [ -n "$Q3C" ] && [ -n "$Q3D" ] \
    && [ "$Q3C" -lt "$Q3D" ] \
    && printf '%s' "$Q3R1" | grep -q 'SKIPPED: hysteria не настроена' \
    && printf '%s' "$Q3R1" | grep -q 'rc=0' \
    && printf '%s' "$Q3R2" | grep -q 'GATE_RC=PASS' \
    && printf '%s' "$Q3R3" | grep -q 'GATE_RC=PASS' \
    && printf '%s' "$Q3R4" | grep -q 'SKIPPED' \
    && printf '%s' "$Q3R5" | grep -q 'GATE_RC=PASS'; then
    ok "Q3: S57-гейт: заглушка/пустой server → SKIPPED (rc0); валидный и SNI-маскировка → старт; stop не задет (K50-3)"
else
    bad "Q3: A=$Q3A B=$Q3B case=$Q3C rcfunc=$Q3D r1=$(echo "$Q3R1" | tail -1) r2=$(echo "$Q3R2" | tail -1) r3=$(echo "$Q3R3" | tail -1) r4=$(echo "$Q3R4" | tail -1) r5=$(echo "$Q3R5" | tail -1)"
fi

# Q4 (FB-13): перечислитель ВСЕХ opkg install/upgrade — гейт обязателен.
python3 - "$K" > "$F/q4.out" 2>&1 <<'PYQ4'
import re, sys
PAT = re.compile(r'opkg\s+(?:-f\s+\S+\s+)?(?:install|upgrade)\b')
def check(path, want):
    lines = open(path, encoding='utf-8').read().split('\n')
    sites, ungated = [], []
    for n, line in enumerate(lines):
        t = line.strip()
        if not t or t.startswith('#') or t.startswith(('echo', 'warn', 'printf')):
            continue
        if PAT.search(t):
            sites.append(n + 1)
            ctx = '\n'.join(lines[max(0, n - 10):n])
            if not ('_kz_http_install_gate' in ctx
                    or '_upd_http_install_gate' in ctx
                    or 'FB-78-авто' in ctx):
                ungated.append(n + 1)
    return sites, ungated, want
root = sys.argv[1]
# r87 (NFQWS2): +1 deploy (install nfqws2+GUI под гейтом),
# +3 updater (GitHub-ipk, upgrade nfqws2, upgrade GUI — все под
# HTTP-гейтом).
ds, du, dw = check(root + '/opt/bin/deploy_bypass.sh', 15)
us, uu, uw = check(root + '/opt/bin/update_protocols.sh', 7)
ok = (not du and not uu and len(ds) == dw and len(us) == uw)
print('OK deploy=%d updater=%d' % (len(ds), len(us)) if ok else
      'BAD deploy=%d(%s) updater=%d(%s) ungated=%r/%r' % (
          len(ds), dw, len(us), uw, du, uu))
PYQ4
grep -q '^OK deploy=15 updater=7' "$F/q4.out" \
    && ok "Q4: все 22 opkg install/upgrade (15 deploy: 13 под HTTP-гейтом + 1 изолированный авто-сайт бутстрапа FB-78-авто — K60-01; + 1 повтор с диагностикой FB-130 внутри гейта — r71; + 7 updater: 4 прежних + r87-nfqws2 GitHub-ipk/upgrade/upgrade-GUI — все под гейтом) (A9-2/FB-78/FB-130/r87)" \
    || bad "Q4: $(cat "$F/q4.out")"

# Q5 (FB-17): форма src распознаётся гейтом.
Q5="$F/q5"; mkdir -p "$Q5/bin"
for _pfn in _kz_http_feed_active _kz_http_install_gate; do
    awk "/^${_pfn}\(\) \{/,/^\}/" "$DEP" >> "$Q5/gate.sh"
    echo >> "$Q5/gate.sh"
done
printf '#!/bin/sh\nexit 0\n' > "$Q5/bin/opkg"; chmod +x "$Q5/bin/opkg"
printf 'src custom http://bin.entware.net/aarch64-k3.10\n' > "$Q5/src-http.conf"
printf 'src custom https://bin.entware.net/aarch64-k3.10\n' > "$Q5/src-https.conf"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc custom https://mirror.example/x\n' > "$Q5/mixed.conf"
cat > "$Q5/g.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/q5/bin:/bin"; export PATH
warn() { echo "WARN: $*"; }
. /tmp/f47chk/q5/gate.sh >/dev/null 2>&1
KZ_DEPLOY_OPKG_CONF="$1" KEENZOO_ALLOW_HTTP_FEED="${2:-0}" _kz_http_install_gate testpkg
echo "RC=$?"
EOF
chmod +x "$Q5/g.sh"
Q5R1=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/src-http.conf 0 2>/dev/null | tail -1)
Q5R2=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/src-https.conf 0 2>/dev/null | tail -1)
Q5R3=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/mixed.conf 0 2>/dev/null | tail -1)
[ "$Q5R1" = "RC=1" ] && [ "$Q5R2" = "RC=0" ] && [ "$Q5R3" = "RC=1" ] \
    && ok "Q5: src-форма фида: http → skip, https → ок, mixed → skip (A9-3)" \
    || bad "Q5: http=$Q5R1 https=$Q5R2 mixed=$Q5R3"

# Q6 (FB-18): сервер без Range — честная заметка, rc 0.
Q6="$F/q6"; mkdir -p "$Q6/bin" "$Q6/dl"
printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c 100000 /dev/zero > "$2"; shift; done\nexit 0\n' \
    > "$Q6/bin/curl"; chmod +x "$Q6/bin/curl"
cat > "$Q6/run.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/q6/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/q6/dl; DL_CMD="curl"
export KEENZOO_DLTMP DL_CMD
have_cmd() { command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
echo "NOTE=$_EPF_NOTE"
EOF
chmod +x "$Q6/run.sh"
Q6OUT=$(PATH=/usr/bin:/bin bash "$Q6/run.sh" 2>/dev/null | tail -2)
if printf '%s' "$Q6OUT" | grep -q 'PROBE_RC=0' \
    && printf '%s' "$Q6OUT" | grep -q 'полная загрузка (сервер без Range)'; then
    ok "Q6: сервер игнорирует Range → rc0 + честная «полная загрузка» (не «range 256Б») (A9-6)"
else
    bad "Q6: $Q6OUT"
fi

# Q7 (FB-19): гейт-пропуски видны в сводке.
Q7A=$(grep -c '^SKIPPED_HTTP=""' "$DEP" || true)
Q7B=$(grep -c '_kz_skip_note "\$pkg"' "$DEP" || true)
Q7E=$(grep -c '_kz_skip_note() {' "$DEP" || true)
Q7C=$(grep -c 'Пакеты не установлены из-за HTTP-политики' "$DEP" || true)
Q7D=$(grep -c '\[ -z "$SKIPPED_HTTP" \]' "$DEP" || true)
[ "$Q7A" = 1 ] && [ "$Q7B" = 1 ] && [ "$Q7C" = 1 ] && [ "$Q7D" = 1 ] \
    && [ "$Q7E" = 1 ] \
    && ok "Q7: SKIPPED_HTTP копится (_kz_skip_note, FB-57 дедуп), ⚠️-строка есть, «✅ Пакеты» подавлен (A9-7)" \
    || bad "Q7: init=$Q7A acc=$Q7B warn=$Q7C guard=$Q7D helper=$Q7E"

# Q8 (FB-20): заглушки токена не покидают tg_bot_token.
Q8="$F/q8"; mkdir -p "$Q8"
awk '/^tg_bot_token\(\) \{/,/^\}/' "$K/opt/bin/common.sh" > "$Q8/tok.sh"
sed -i "s#/opt/etc/bot/bot_config.py#$Q8/cfg.py#" "$Q8/tok.sh"
printf 'tg_bot_token\n' >> "$Q8/tok.sh"
printf "token = 'ТОКЕН_БОТА'\n" > "$Q8/cfg.py"; Q8R1=$(sh "$Q8/tok.sh" | wc -c)
printf "token = 'CHANGE_ME'\n" > "$Q8/cfg.py"; Q8R2=$(sh "$Q8/tok.sh" | wc -c)
printf "token = '12345:ABC-DEF'\n" > "$Q8/cfg.py"; Q8R3=$(sh "$Q8/tok.sh")
[ "$Q8R1" = 0 ] && [ "$Q8R2" = 0 ] && [ "$Q8R3" = "12345:ABC-DEF" ] \
    && ok "Q8: ТОКЕН_БОТА/CHANGE_ME → пусто; реальный токен проходит (K50-7)" \
    || bad "Q8: r1=$Q8R1 r2=$Q8R2 r3=[$Q8R3]"

# Q9 (FB-21/FB-22): shlex убран; кэш адресов LAN (включая пустой результат).
python3 - "$GEN" > "$F/q9.out" 2>&1 <<'PYQ9'
import sys, re, types, ipaddress, threading
src = open(sys.argv[1], encoding='utf-8').read()
shlex_n = len([l for l in src.split('\n') if 'shlex' in l])
mfunc = re.search(r'^def _lan_host_addresses\(.*?(?=^def )', src, re.M | re.S)
mcache1 = re.search(r'^_LAN_HOSTS_CACHE = \{.*$', src, re.M)
mcache2 = re.search(r'^_LAN_HOSTS_CACHE_TTL = [\d.]+$', src, re.M)
# FB-30 (аудит-26): функция берёт модульный _LAN_HOSTS_LOCK —
# экстракция Q9 обязана дать его неймспейсу.
mlock = re.search(r'^_LAN_HOSTS_LOCK = threading\.Lock\(\)$', src, re.M)
assert mfunc and mcache1 and mcache2 and mlock, 'no cache/lock/func'
import time as _time
def make_env(stdout):
    calls = {'n': 0}
    class _R:
        def __init__(self, out):
            self.stdout = out
    class _SP:
        TimeoutExpired = Exception
        def run(self, args, **kw):
            calls['n'] += 1
            return _R(stdout)
    class _C:
        lan_ifaces = ['br0', 'br1', 'nwg0']
    g = {'time': _time, 'subprocess': _SP(), 'config': _C(),
         'ipaddress': ipaddress, 'threading': threading}
    exec(mcache1.group(0), g)
    exec(mcache2.group(0), g)
    exec(mlock.group(0), g)
    exec(mfunc.group(0), g)
    return g['_lan_host_addresses'], calls
f, calls = make_env('    inet 192.168.1.1/24 brd x br0\n')
a = f()
same = all(f() == a for _ in range(19))
fe, ce = make_env('')
fe()
fe(); fe(); fe()
print('OK shlex=%d forks=%d stable=%s empty_forks=%d' % (
    shlex_n, calls['n'], same, ce['n']) if (
    shlex_n == 0 and calls['n'] == 3 and same and ce['n'] == 3) else
    'BAD shlex=%d forks=%d stable=%s empty_forks=%d' % (
        shlex_n, calls['n'], same, ce['n']))
PYQ9
grep -q '^OK ' "$F/q9.out" \
    && ok "Q9: import shlex убран; кэш LAN: 3 форка на 20 вызовов, пустой результат кэшируется (K50-8/K50-9)" \
    || bad "Q9: $(cat "$F/q9.out")"

# Q10 (FB-15): канонический путь hysteria.
Q10A=$(grep -c -- '-x /opt/sbin/hysteria' "$DEP" || true)
Q10B=$(grep -c '_hy_canon_ok' "$DEP" || true)
Q10C=$(grep -c '/opt/sbin/hysteria version' "$DEP" || true)
Q10D=$(grep -c 'DEPLOY_MODE" = "restore"' "$DEP" || true)
[ "$Q10A" -ge 2 ] && [ "$Q10B" -ge 2 ] && [ "$Q10C" -ge 4 ] && [ "$Q10D" -ge 1 ] \
    && ok "Q10: гейты/версии hysteria — по /opt/sbin; послабление только restore (K50-5)" \
    || bad "Q10: canon=$Q10A flag=$Q10B ver=$Q10C restore=$Q10D"

# Q11 (FB-16): сводка называет оба поля.
Q11A=$(grep -c 'задайте web_username и web_password' "$DEP" || true)
[ "$Q11A" = 1 ] \
    && ok "Q11: сводка: «задайте web_username и web_password» (K50-6)" \
    || bad "Q11: $Q11A"

# Q12 (FB-13): гейт в update_protocols + граница политики задокументирована.
Q12A=$(grep -c '_upd_http_install_gate' "$K/opt/bin/update_protocols.sh" || true)
Q12B=$(grep -c 'opkg update (загрузка индекса) НЕ гейтится' "$K/opt/bin/update_protocols.sh" || true)
# r87 (NFQWS2): +3 вызова (GitHub-ipk, upgrade nfqws2, upgrade GUI).
[ "$Q12A" = 8 ] && [ "$Q12B" = 1 ] \
    && ok "Q12: updater: гейт-хелпер + 7 вызовов (4 + r87-nfqws2); граница политики описана (A9-2/r87)" \
    || bad "Q12: gate=$Q12A boundary=$Q12B"

# Q13 (FB-10, опционально): реальный Flask-смоук, если flask доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/q13.out" 2>&1 <<'PYQ13'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g
reg = g.app.before_request_funcs.get(None) or list(
    g.app.before_request_funcs.values())[0]
names = [f.__name__ for f in reg]
c = g.app.test_client()
r1 = c.get('/')
r2 = c.get('/api/cfg')
ok = (names == ['security_checks'] and r1.status_code != 500
      and r2.status_code != 500)
print('OK registry=%s /=%s cfg=%s' % (names, r1.status_code, r2.status_code)
      if ok else 'BAD registry=%s /=%s cfg=%s' % (
          names, r1.status_code, r2.status_code))
PYQ13
    grep -q '^OK ' "$F/q13.out" \
        && ok "Q13: Flask: before_request=[security_checks], GET без 5xx (K50-1)" \
        || bad "Q13: $(cat "$F/q13.out")"
else
    echo "[SKIP] Q13: Flask-смоук — flask не установлен на хосте (инвариант Q0 покрывает класс)"
fi

echo "═══ G. R48-5: просмотр списка ≡ сохранению ═══"
python3 - "$K" "$F" <<'PYB'
import ast, io, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import lists_core as lc

src = io.open(os.path.join(K, 'opt/etc/bot/handlers.py'), encoding='utf-8').read()
names = {'load_bypass_blocks', 'sections_to_text', 'format_blocks_for_display'}
segs = [ast.get_source_segment(src, n) for n in ast.parse(src).body
        if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(segs) == 3, 'не все функции извлечены'
ns = {'lists_core': lc, 'os': os}
exec('import os\n', ns)
exec('\n\n'.join(segs), ns)

tf = os.path.join(F, 'disp.txt')
io.open(tf, 'w', encoding='utf-8').write(
    '9.example.com\n1.example.com\n# Группа 1\n8.8.8.8\n1.1.1.1\n'
    '# Пометка без записей\n7.7.7.7\n')
secs = ns['load_bypass_blocks'](tf)
disp = ns['format_blocks_for_display'](secs)
expect = ('1.example.com\n9.example.com\n\n# Группа 1\n1.1.1.1\n8.8.8.8\n\n'
          '# Пометка без записей\n7.7.7.7')
if disp == expect:
    ok('G1: просмотр = порядок файла + сортировка в секции + comment-only видны')
else:
    bad(f'G1: {disp!r} != {expect!r}')
if disp.startswith('1.example.com\n9.example.com'):
    ok('G2: безымянные записи не «всплыли» в конец')
else:
    bad('G2: порядок безымянных нарушен')
if '# Пометка без записей' in disp:
    ok('G3: comment-only секция показывается (N-3 паритет)')
else:
    bad('G3: comment-only скрыт')
if ns['format_blocks_for_display']( []) == 'Список пуст':
    ok('G4: пустой список — «Список пуст»')
else:
    bad('G4: пустой список не обработан')
# Настоящий контракт R48-5: то, что пользователь ВИДИТ, равно тому,
# что оказалось бы в файле после сохранения (round-trip через
# parse_and_save — рендер сохранения сортирует записи так же).
d2 = os.path.join(F, 'lists'); os.makedirs(d2)
lc.UNBLOCK_DIR = d2
tf2 = os.path.join(d2, 'vless.txt')
lc.parse_and_save(tf2, ns['sections_to_text'](secs))
saved = io.open(tf2, encoding='utf-8').read()
if disp == saved.rstrip('\n'):
    ok('G5: просмотр ≡ файлу после сохранения (round-trip parse_and_save)')
else:
    bad(f'G5: {disp!r} != {saved!r}')
io.open(os.path.join(F, 'g.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
GP=0; GF=1
[ -s "$F/g.counts" ] && read GP GF < "$F/g.counts"
PASS=$((PASS+GP)); FAIL=$((FAIL+GF))

echo "═══ H. R48-7: wsSettings.host ═══"
TPL="$K/opt/etc/bot/templates/vless_template.json"
grep -q '"host":"{{ws_host}}"' "$TPL" \
    && ok "H1: шаблон: wsSettings.host (новая форма)" \
    || bad "H1: шаблон не содержит host"
NOLD=$(grep -c '"headers"\|"Host"' "$TPL" || true)
[ "$NOLD" = 0 ] \
    && ok "H2: шаблон: headers/Host отсутствуют" \
    || bad "H2: устаревшая форма в шаблоне ($NOLD)"
python3 - "$K" "$F" <<'PYB'
import ast, io, json, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

grep_tpl = io.open(os.path.join(
    K, 'opt/etc/bot/templates/vless_template.json'),
    encoding='utf-8').read()
if '"path":"{{ws_path}}"' in grep_tpl and '{{ws_host}}' in grep_tpl:
    ok('H3: ws-блок шаблона структурно цел (path+host; рендер — f41)')
else:
    bad('H3: ws-блок шаблона повреждён')

src = io.open(os.path.join(K, 'opt/etc/bot/utils.py'), encoding='utf-8').read()
seg = [ast.get_source_segment(src, n) for n in ast.parse(src).body
       if isinstance(n, ast.FunctionDef) and n.name == '_convert_singbox_vless'][0]
ns = {}
exec(seg, ns)
fn = ns['_convert_singbox_vless']

sb_old = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/ws',
                        'headers': {'Host': 'cdn.example.org'}}}
ws = fn(sb_old)['outbounds'][0]['streamSettings']['wsSettings']
if ws == {'path': '/ws', 'host': 'cdn.example.org'}:
    ok('H4: sing-box headers.Host → wsSettings.host (фолбэк старой формы)')
else:
    bad(f'H4: {ws!r}')

sb_new = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/w', 'host': 'h.example'}}
ws2 = fn(sb_new)['outbounds'][0]['streamSettings']['wsSettings']
if ws2 == {'path': '/w', 'host': 'h.example'}:
    ok('H5: sing-box host → wsSettings.host (приоритет новой формы)')
else:
    bad(f'H5: {ws2!r}')
io.open(os.path.join(F, 'h.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
HP=0; HF=1
[ -s "$F/h.counts" ] && read HP HF < "$F/h.counts"
PASS=$((PASS+HP)); FAIL=$((FAIL+HF))

echo "═══ I. Маркеры, синтаксис, контракты ═══"
MD=$(grep -c 'R48-[1268] (аудит-18)' "$K/opt/bin/deploy_bypass.sh" || true)
[ "$MD" = 4 ] \
    && ok "I1: маркеры R48-1/2/6/8 в deploy (4)" \
    || bad "I1: маркеров в deploy = $MD (ожидалось 4)"
grep -q 'R48-3 (аудит-18)' "$K/opt/etc/init.d/S99generator" \
    && grep -q 'R48-9 (аудит-18)' "$K/opt/bin/test_udp_tunnels.sh" \
    && grep -q 'R48-5 (аудит-18)' "$K/opt/etc/bot/handlers.py" \
    && grep -q 'R48-7 (аудит-18)' "$K/opt/etc/bot/utils.py" \
    && ok "I2: маркеры R48-3/9/5/7 на местах" \
    || bad "I2: какой-то маркер отсутствует"
dash -n "$K/opt/bin/deploy_bypass.sh" && dash -n "$K/opt/etc/init.d/S99generator" \
    && dash -n "$K/opt/bin/test_udp_tunnels.sh" \
    && ok "I3: синтаксис правленых shell-файлов (dash -n)" \
    || bad "I3: dash -n упал"
# FB-178 (аудит-46, B-R79-04): кэш компиляции — во временный каталог
# (прежде py_compile писал __pycache__ прямо в проверяемое дерево).
I4C="$F/i4pyc"; mkdir -p "$I4C"
PYTHONPYCACHEPREFIX="$I4C" python3 -m py_compile \
    "$K/opt/etc/bot/handlers.py" "$K/opt/etc/bot/utils.py" \
    && ok "I4: py_compile handlers.py + utils.py (кэш — вне дерева; FB-178)" \
    || bad "I4: py_compile упал"
rm -rf "$I4C"
grep -q 'web INPUT DROP add/verify failed' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    && ok "I5: хук 100-redirect.sh на месте (правки аудита-18 его не касались)" \
    || bad "I5: хук неожиданно изменён"
# FB-43 (аудит-28): единственная правка хука в r54 — гейт кэша (_IPT_CAPABLE);
# всё прочее содержимое обязано совпадать с HEAD.
if git -C "$K" rev-parse --git-dir >/dev/null 2>&1; then
    I6D=$(git -C "$K" diff HEAD -- opt/etc/ndm/netfilter.d/100-redirect.sh \
        | grep -E '^[+-]' | grep -vE '^(\+\+\+|---)')
    I6N=$(printf '%s\n' "$I6D" | grep -c '^-')
    I6M=$(printf '%s\n' "$I6D" | grep -c '^+if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]')
    I6C=$(printf '%s\n' "$I6D" | grep -c '^+#')
    I6T=$(printf '%s\n' "$I6D" | grep -vcE '^(\+#|\+if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]|-if \[ -n "\$_KZ_HOOK_TMPDIR" \]; then$)')
    if [ -z "$I6D" ]; then
        ok "I6: хук не отличается от Git HEAD"
    elif [ "$I6N" = 1 ] && [ "$I6M" = 1 ] && [ "$I6T" = 0 ] && [ "$I6C" -ge 1 ]; then
        ok "I6: диф хука = только гейт кэша FB-43 (1 строка ужесточена, прочее = HEAD)"
    else
        bad "I6: неожиданный диф хука (n=$I6N m=$I6M c=$I6C t=$I6T)"
    fi
else
    ok "I6: [SKIP] git-раскладка — сверка с HEAD не требуется"
fi
grep -q 'safe_start_service "S99generator"' "$K/opt/bin/deploy_bypass.sh" \
    && grep -A3 'safe_start_service() {' "$K/opt/bin/deploy_bypass.sh" | grep -q '|| true' \
    && ok "I7: deploy не падает от SKIPPED (safe_start_service глотает rc)" \
    || bad "I7: контракт safe_start_service изменён"

echo "═══ R. Аудит-26: S57-гейт с портом, PID-личность, гейты/кэш/панель ═══"

# R0 (FB-23/K51-1/R51-01): заглушка сервера с ПОРТОМ и валидным auth
# тоже отсекается гейтом S57 (ранее example.com:443 проходил на старт).
RB="$F/rb"; mkdir -p "$RB"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$RB/gate.sh"
cat > "$RB/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/rb/gate.sh
echo "GATE_RC=PASS"
EOF
chmod +x "$RB/run.sh"
printf '{\n  "server": "example.com:443",\n  "auth": "realkey"\n}\n' > "$RB/p1.json"
printf '{\n  "server": "example.com:8443",\n  "auth": "realkey"\n}\n' > "$RB/p2.json"
printf '{\n  "server": "example.com",\n  "auth": "realkey"\n}\n' > "$RB/p3.json"
printf '{\n  "server": "",\n  "auth": "realkey"\n}\n' > "$RB/p4.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "realkey",\n  "tls": {"sni": "example.com"}\n}\n' > "$RB/p5.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "realkey"\n}\n' > "$RB/p6.json"
R0A=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" sh "$RB/run.sh" start 2>&1)
R0B=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p2.json" sh "$RB/run.sh" start 2>&1)
R0C=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p3.json" sh "$RB/run.sh" start 2>&1)
R0D=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p4.json" sh "$RB/run.sh" start 2>&1)
R0E=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p5.json" sh "$RB/run.sh" start 2>&1)
R0F=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p6.json" sh "$RB/run.sh" start 2>&1)
if printf '%s\n%s' "$R0A" "$R0B" | grep -q 'SKIPPED: hysteria не настроена' \
    && printf '%s\n%s' "$R0C" "$R0D" | grep -q 'SKIPPED: hysteria не настроена' \
    && ! printf '%s\n%s\n%s\n%s' "$R0A" "$R0B" "$R0C" "$R0D" | grep -q GATE_RC \
    && printf '%s' "$R0E" | grep -q GATE_RC=PASS \
    && printf '%s' "$R0F" | grep -q GATE_RC=PASS; then
    ok "R0: S57: example.com:443/:8443/без-порта/пустой + валидный auth → SKIPPED; SNI-маскировка и реальный → старт (K51-1/R51-01)"
else
    bad "R0: a=$(echo "$R0A" | tail -1) b=$(echo "$R0B" | tail -1) c=$(echo "$R0C" | tail -1) d=$(echo "$R0D" | tail -1) e=$(echo "$R0E" | tail -1) f=$(echo "$R0F" | tail -1)"
fi

# R1 (FB-25/K51-3/R51-03): pid-файл — только подсказка: сигнал только
# процессу, чей /proc/PID/cmdline относится к hysteria; сам pid-файл
# снимается при любом исходе; PID 0/мусор безопасны; stop не задет.
R1STATE(){ [ -r "/proc/$1/stat" ] && awk '{print $3}' "/proc/$1/stat" 2>/dev/null || echo X; }
RP="$F/rp"; mkdir -p "$RP"
# FB-48 (аудит-28, R53-05): личность процесса — по /proc/PID/exe, поэтому
# «свой» фейкуется РЕАЛЬНЫМ исполняемым файлом с именем hysteria (прежний
# скрипт-фейк имел exe=/bin/sh и по exe-признаку «своим» не является).
cp /bin/sleep "$RP/hysteria" 2>/dev/null \
    || cp /usr/bin/sleep "$RP/hysteria" 2>/dev/null \
    || cp "$(command -v sleep)" "$RP/hysteria"
chmod +x "$RP/hysteria"
# a) чужой живой процесс — не тронут, pid снят
sleep 60 & R1P1=$!
printf '%s\n' "$R1P1" > "$RP/pid"
R1A=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
R1A1=$(R1STATE "$R1P1"); [ -e "$RP/pid" ] && R1A2=present || R1A2=removed
kill "$R1P1" 2>/dev/null; wait "$R1P1" 2>/dev/null
# b) свой процесс (exe = .../hysteria) — снят с «Stopping»
"$RP/hysteria" 600 & R1P2=$!
sleep 1
printf '%s\n' "$R1P2" > "$RP/pid"
R1B=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
sleep 1
R1B1=$(R1STATE "$R1P2"); [ -e "$RP/pid" ] && R1B2=present || R1B2=removed
wait "$R1P2" 2>/dev/null
# b2) чужой процесс с подстрокой hysteria в argv, но чужим exe —
#     НЕ убит (FB-48: прежний матч *hysteria* по cmdline убивал бы его)
bash -c 'exec -a hysteria-marker sleep 60' & R1P3=$!
sleep 1
printf '%s\n' "$R1P3" > "$RP/pid"
R1F=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
R1F1=$(R1STATE "$R1P3")
kill "$R1P3" 2>/dev/null; wait "$R1P3" 2>/dev/null
# c) PID 0 (kill 0 = process-group) и d) мусорный PID — никто не тронут
printf '0\n' > "$RP/pid"
R1C=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1); R1C1=$?
[ -e "$RP/pid" ] && R1C2=present || R1C2=removed
printf '999999999\n' > "$RP/pid"
R1D=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1); R1D1=$?
[ -e "$RP/pid" ] && R1D2=present || R1D2=removed
# e) stop не задет гейтом
R1E=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" sh "$RB/run.sh" stop 2>&1)
if [ "$R1A1" != Z ] && [ "$R1A1" != X ] && [ "$R1A2" = removed ] \
    && { [ "$R1B1" = Z ] || [ "$R1B1" = X ]; } && [ "$R1B2" = removed ] \
    && printf '%s' "$R1B" | grep -q 'Stopping hysteria' \
    && [ "$R1F1" != Z ] && [ "$R1F1" != X ] \
    && [ "$R1C1" = 0 ] && [ "$R1C2" = removed ] \
    && [ "$R1D1" = 0 ] && [ "$R1D2" = removed ] \
    && printf '%s' "$R1E" | grep -q GATE_RC=PASS; then
    ok "R1: S57 PID: чужой жив+pid снят; свой (exe) снят с «Stopping»; argv-подстрока чужого не убита; 0/мусор безопасны; stop цел (K51-3/R51-03+FB-48)"
else
    bad "R1: a1=$R1A1/$R1A2 b1=$R1B1/$R1B2 f1=$R1F1 c=$R1C1/$R1C2 d=$R1D1/$R1D2 e=$(echo "$R1E" | tail -1)"
fi

# R2 (FB-24/R51-02): HTTP-гейт — обе копии, 6 форм opkg.conf.
RG="$F/rg"; mkdir -p "$RG"
awk '/^_kz_http_feed_active\(\) \{/,/^\}$/' "$DEP" > "$RG/dep.sh"
awk '/^_kz_http_install_gate\(\) \{/,/^\}$/' "$DEP" >> "$RG/dep.sh"
awk '/^_upd_http_feed_active\(\) \{/,/^\}$/' "$K/opt/bin/update_protocols.sh" > "$RG/upd.sh"
awk '/^_upd_http_install_gate\(\) \{/,/^\}$/' "$K/opt/bin/update_protocols.sh" >> "$RG/upd.sh"
printf 'src/gz entware http://bin.entware.net/x\n' > "$RG/plain"
printf '   src/gz entware http://bin.entware.net/x\n' > "$RG/lead"
printf 'src/gz "entware" "http://bin.entware.net/x"\n' > "$RG/quoted"
printf '\t src "entware" http://bin.entware.net/x\n' > "$RG/mixed"
printf 'src/gz entware https://bin.entware.net/x\n' > "$RG/https"
cat > "$RG/depdrv.sh" <<'EOF'
#!/bin/sh
warn(){ echo "WARN: $*"; }
. /tmp/f47chk/rg/dep.sh
KZ_DEPLOY_OPKG_CONF="$1"; export KZ_DEPLOY_OPKG_CONF
_kz_http_install_gate testpkg; echo "rc=$?"
EOF
cat > "$RG/upddrv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/rg/upd.sh
KZ_DEPLOY_OPKG_CONF="$1"; export KZ_DEPLOY_OPKG_CONF
_upd_http_install_gate testpkg; echo "rc=$?"
EOF
chmod +x "$RG/depdrv.sh" "$RG/upddrv.sh"
R2RES=""
for cfg in plain lead quoted mixed https missing; do
    [ "$cfg" = missing ] && conf="$F/rg/no-such-file" || conf="$RG/$cfg"
    unset KEENZOO_ALLOW_HTTP_FEED
    D=$(sh "$RG/depdrv.sh" "$conf" 2>&1 | tail -1)
    U=$(sh "$RG/upddrv.sh" "$conf" 2>&1 | tail -1)
    case "$cfg" in
        https) EXP="rc=0|rc=0" ;;
        *) EXP="rc=1|rc=1" ;;
    esac
    R2RES="$R2RES $cfg=${D#rc=}/${U#rc=}"
    [ "$D|$U" = "$EXP" ] || R2BAD="$R2BAD $cfg"
done
unset KEENZOO_ALLOW_HTTP_FEED
R2M=$(sh "$RG/depdrv.sh" "$F/rg/no-such-file" 2>&1; sh "$RG/upddrv.sh" "$F/rg/no-such-file" 2>&1)
if [ -z "${R2BAD:-}" ] && printf '%s' "$R2M" | grep -q 'не читается'; then
    ok "R2: HTTP-гейт (deploy+updater): plain/lead/quoted/mixed → блок, https → rc0, missing → fail-closed warn (R51-02)"
else
    bad "R2:$R2RES bad=[$R2BAD] missing_warn=$(printf '%s' "$R2M" | grep -c 'не читается')"
fi

# R3 (FB-26/K51-2): мемоизация opkg list-installed.
RM="$F/rm"; mkdir -p "$RM/bin"
awk '/^_kz_pkg_installed\(\) \{/,/^\}$/' "$DEP" > "$RM/fns.sh"
awk '/^_kz_pkg_cache_note\(\) \{/,/^\}$/' "$DEP" >> "$RM/fns.sh"
cat > "$RM/bin/opkg" <<'EOF'
#!/bin/sh
echo "opkg-call $*" >> /tmp/f47chk/rm/opkg.log
printf 'tor - 0.1\nxray - 1.0\n'
exit 0
EOF
chmod +x "$RM/bin/opkg"
cat > "$RM/drv.sh" <<'EOF'
#!/bin/sh
PATH="/tmp/f47chk/rm/bin:$PATH"; export PATH
. /tmp/f47chk/rm/fns.sh
_kz_pkg_installed tor; echo "tor=$?"
_kz_pkg_installed xray; echo "xray=$?"
_kz_pkg_installed tor; echo "tor2=$?"
_kz_pkg_installed dnsmasq-full; echo "dns=$?"
_kz_pkg_cache_note dnsmasq-full
_kz_pkg_installed dnsmasq-full; echo "dns2=$?"
EOF
R3OUT=$(sh "$RM/drv.sh" 2>&1)
R3N=$(wc -l < "$RM/opkg.log" 2>/dev/null || echo 0)
if printf '%s' "$R3OUT" | grep -q 'tor=0' && printf '%s' "$R3OUT" | grep -q 'xray=0' \
    && printf '%s' "$R3OUT" | grep -q 'tor2=0' && printf '%s' "$R3OUT" | grep -q 'dns=1' \
    && printf '%s' "$R3OUT" | grep -q 'dns2=0' && [ "$R3N" = 1 ]; then
    ok "R3: мемоизация: 6 проверок → 1 вызов opkg list-installed; cache_note виден (K51-2)"
else
    bad "R3: out=$(echo "$R3OUT" | tr '\n' ' ') calls=$R3N"
fi

# R4 (FB-28/R51-07): порог тела для вердикта Range — ≤256 Б.
RR="$F/rr"; mkdir -p "$RR/bin" "$RR/dl"
awk '/^_entware_probe_feed_url\(\) \{/,/^\}$/' "$DEP" > "$RR/fn.sh"
cat > "$RR/drv.sh" <<'EOF'
#!/bin/sh
PATH="/tmp/f47chk/rr/bin:/bin:/usr/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/rr/dl; export KEENZOO_DLTMP
DL_CMD=curl; export DL_CMD
have_cmd(){ command -v "$1" >/dev/null 2>&1; }
warn(){ :; }
ensure_dns(){ :; }
. /tmp/f47chk/rr/fn.sh
_entware_probe_feed_url "https://bin.entware.net/armv7sf-k3.2/Packages.gz"
echo "rc=$? note=${_EPF_NOTE}"
EOF
R4R=""; R4BAD=""
for sz in 256 1000; do
    printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c %s /dev/zero > "$2"; shift; done\nexit 0\n' "$sz" > "$RR/bin/curl"
    chmod +x "$RR/bin/curl"
    OUT=$(sh "$RR/drv.sh" 2>&1)
    R4R="$R4R [$sz] $(echo "$OUT" | tail -1)"
    if [ "$sz" = 256 ]; then
        echo "$OUT" | grep -q 'range' || R4BAD="$R4BAD $sz"
    else
        echo "$OUT" | grep -q 'полная загрузка' || R4BAD="$R4BAD $sz"
    fi
done
if [ -z "$R4BAD" ]; then
    ok "R4: Range-проба: 256Б → range-вердикт, 1000Б → полная загрузка (R51-07)"
else
    bad "R4:$R4R bad=[$R4BAD]"
fi

# R5 (FB-29/R51-05): SKIPPED_HTTP — сбор со всех гейтов шага, сводка в конце.
R5A=$(grep -c '^SKIPPED_HTTP=""$' "$DEP")
R5B=$(grep -cE '_kz_skip_note (ca-bundle|curl|"\$pkg"|webtunnel-client|python3-requests|dnsmasq-full)' "$DEP")
R5I=$(grep -n '^SKIPPED_HTTP=""$' "$DEP" | head -1 | cut -d: -f1)
R5L=$(grep -nE '_kz_skip_note (ca-bundle|curl|"\$pkg"|webtunnel-client|python3-requests|dnsmasq-full)' "$DEP" | tail -1 | cut -d: -f1)
R5S=$(grep -n 'Пакеты не установлены из-за HTTP-политики' "$DEP" | head -1 | cut -d: -f1)
if [ "$R5A" = 1 ] && [ "$R5B" = 6 ] && [ -n "$R5I" ] && [ -n "$R5L" ] && [ -n "$R5S" ] \
    && [ "$R5I" -lt "$R5L" ] && [ "$R5L" -lt "$R5S" ]; then
    ok "R5: SKIPPED_HTTP: 6 точек сбора (_kz_skip_note, дедуп FB-57), сводка после последней (dnsmasq-full) (R51-05)"
else
    bad "R5: init=$R5A points=$R5B i=$R5I last=$R5L summary=$R5S"
fi

# R6 (FB-31/R51-06): example.com в sni/serverName/peer_name — не заглушка.
RN="$F/rn"; mkdir -p "$RN"
awk '/^needs_key\(\) \{/,/^\}$/' "$DEP" > "$RN/nk.sh"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k",\n  "tls": {"sni": "example.com"}\n}\n' > "$RN/sni.json"
printf '{\n  "server": "example.com:443",\n  "auth": "k"\n}\n' > "$RN/stub.json"
cat > "$RN/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/rn/nk.sh
needs_key /tmp/f47chk/rn/sni.json; echo "sni=$?"
needs_key /tmp/f47chk/rn/stub.json; echo "stub=$?"
EOF
R6OUT=$(sh "$RN/drv.sh" 2>&1)
R6GREP=$(grep -c '_SNI_VALUE_RE' "$K/opt/etc/bot/utils.py" || true)
if printf '%s' "$R6OUT" | grep -q 'sni=1' && printf '%s' "$R6OUT" | grep -q 'stub=0' \
    && [ "$R6GREP" -ge 1 ]; then
    ok "R6: needs_key: SNI-маскировка не «заглушка», server-stub — заглушка; _SNI_VALUE_RE в utils (R51-06+FB-36)"
else
    bad "R6: out=$(echo "$R6OUT" | tr '\n' ' ') utils_re=$R6GREP"
fi

# R7 (FB-32/R50-UX-1): CFG_STATE несёт web_username; баннер — фактическое имя.
RQ="$F/rq"; mkdir -p "$RQ"
sed -n "/^CFG_STATE=\"\$(python3 -/,/^PYEOF$/p" "$DEP" | sed '1d;$d' | sed "s|'/opt/etc/bot'|'$RQ'|" > "$RQ/cfgstate.py"
printf 'token = "X"\nallowed_user_ids = [1]\nweb_password = "Y"\n' > "$RQ/bot_config.py"
R7A=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
printf 'web_username = "ivan"\n' >> "$RQ/bot_config.py"
R7B=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
# FB-49 (аудит-28, R53-10): баннер — ветка if/else (пустое имя = «панель
# не настроена», семантика S99/CFG_STATE), а не молчаливый «admin».
sed -n "/^_panel_user=\"\$(grep/,/^fi$/p" "$DEP" | sed "s|/opt/etc/bot/bot_config.py|$RQ/bot_config.py|" > "$RQ/banner.sh"
R7C=$(sh "$RQ/banner.sh" 2>/dev/null)
sed -i 's/^web_username.*/web_username = ""/' "$RQ/bot_config.py"
R7D=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
R7E=$(grep -c '\[ "\${4:-empty}" = "ok" \] || NEED_CONFIG=1' "$DEP" || true)
R7F=$(sh "$RQ/banner.sh" 2>/dev/null)
if [ "$R7A" = "ok ok ok empty" ] && [ "$R7B" = "ok ok ok ok" ] && [ "$R7D" = "ok ok ok empty" ] \
    && printf '%s' "$R7C" | grep -q '(ivan,' \
    && printf '%s' "$R7F" | grep -q 'панель не настроена: web_username пуст' \
    && [ "$R7E" = 1 ]; then
    ok "R7: CFG_STATE 4-й токен web_username; баннер: имя или «панель не настроена» (R50-UX-1+FB-49)"
else
    bad "R7: a=[$R7A] b=[$R7B] d=[$R7D] ivan=[$R7C] empty=[$R7F] tok4=$R7E"
fi

# R8+R9+R10 (FB-30/FB-33/N51-1): панель — если flask доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/r8.out" 2>&1 <<'PYR8'
import sys, time, threading
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g

# R8 (FB-30/N51-2): lock + повторная проверка; конкурентный шторм → 3 форка.
lock_ok = ('_LAN_HOSTS_LOCK = threading.Lock()' in open(
    sys.argv[1] + '/opt/etc/bot/generator.py', encoding='utf-8').read())
calls = {'n': 0}
class _R:
    def __init__(self, out): self.stdout = out
class _SP:
    TimeoutExpired = Exception
    def run(self, args, **kw):
        calls['n'] += 1; time.sleep(0.05)
        return _R('    inet 192.168.1.1/24 brd x br0\n')
g.subprocess = _SP()
g._LAN_HOSTS_CACHE['ts'] = 0.0
for _ in range(8):
    threading.Thread(target=lambda: g._lan_host_addresses()).start()
while threading.active_count() > 1:
    time.sleep(0.02)
print('R8 %s forks=%d' % ('OK' if lock_ok and calls['n'] == 3 else 'BAD',
                          calls['n']))

# R9 (FB-33): _auth_cmp — модульное сравнение, не-ASCII не роняет.
try:
    r9 = (g._auth_cmp('a', 'a') is True and g._auth_cmp('a', 'b') is False
          and g._auth_cmp('пароль', 'пароль') is True)
    print('R9 %s' % ('OK' if r9 else 'BAD'))
except Exception as e:
    print('R9 BAD %s' % e)

# R10 (N51-1): cross-list warning; маршрут на api_lookup_add; декораторы целы.
lines = open(sys.argv[1] + '/opt/etc/bot/generator.py',
             encoding='utf-8').read().split('\n')
bad_dec = []
for i, l in enumerate(lines):
    if l.strip().startswith('@app.route'):
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines) or not lines[j].startswith('def '):
            bad_dec.append(i + 1)
g.config.web_username = 'admin'; g.config.web_password = 'testpass'
g.config.list_files = {'vless': '/tmp/f47chk/rl_vless.txt',
                       'hysteria': '/tmp/f47chk/rl_hy.txt',
                       'bot': '/tmp/f47chk/rl_bot.txt'}
open('/tmp/f47chk/rl_vless.txt', 'w').write('crossdup.example\n')
open('/tmp/f47chk/rl_hy.txt', 'w').write('')
c = g.app.test_client()
TOK = 'a' * 64
with c.session_transaction() as s:
    s['csrf_token'] = TOK
r = c.post('/api/lookup-add', headers={'Origin': 'http://127.0.0.1'},
           auth=('admin', 'testpass'),
           data={'list': 'hysteria', 'entries': 'crossdup.example',
                 'csrf_token': TOK})
b = r.get_json() or {}
r3 = c.post('/api/lookup-add', headers={'Origin': 'http://127.0.0.1'},
            auth=('admin', 'testpass'),
            data={'list': 'hysteria', 'entries': 'fresh.example',
                  'csrf_token': TOK})
b3 = r3.get_json() or {}
r2 = c.post('/api/lookup-add', headers={'Origin': 'http://evil.example'},
            auth=('admin', 'testpass'),
            data={'list': 'hysteria', 'entries': 'x.example',
                  'csrf_token': TOK})
ok10 = (not bad_dec and r.status_code == 200 and b.get('added') == ['crossdup.example']
        and 'vless' in (b.get('warning') or '')
        and r3.status_code == 200 and 'warning' not in b3
        and r2.status_code == 403)
print('R10 %s status=%s warn=%s fresh=%s evil=%s dec=%s' % (
    'OK' if ok10 else 'BAD', r.status_code,
    'vless' in (b.get('warning') or ''), 'warning' not in b3,
    r2.status_code, bad_dec))
PYR8
    grep -q '^R8 OK' "$F/r8.out" \
        && ok "R8: LAN-кэш под lock; 8 потоков → 3 форка (N51-2)" \
        || bad "R8: $(grep '^R8' "$F/r8.out")"
    grep -q '^R9 OK' "$F/r8.out" \
        && ok "R9: _auth_cmp модульная, ASCII/не-ASCII (FB-33)" \
        || bad "R9: $(grep '^R9' "$F/r8.out")"
    grep -q '^R10 OK' "$F/r8.out" \
        && ok "R10: N51-1: cross-list warning в ответе; свежие — без warning; чужой Origin 403; все @app.route ведут на def (маршрут lookup-add цел)" \
        || bad "R10: $(grep '^R10' "$F/r8.out")"
else
    echo "[SKIP] R8/R9/R10: Flask-смоук — flask не установлен на хосте"
fi

# R11 (FB-27/R50-FW-1): benchmark-диапазон в matcher снятия ACCEPT.
R11A=$(grep -c '198\.1\[89\]\.\*' "$DEP" || true)
[ "$R11A" -ge 1 ] \
    && ok "R11: 198.18.0.0/15 в matcher проектных ACCEPT (R50-FW-1)" \
    || bad "R11: matcher=[$R11A]"

# R12 (FB-34/N51-2): wget-ветка tg_send_message предупреждает про argv.
R12A=$(grep -c 'токен кратко виден в argv' "$K/opt/bin/common.sh" || true)
[ "$R12A" -ge 1 ] \
    && ok "R12: warn в wget-ветке tg_send_message (FB-34)" \
    || bad "R12: warn=[$R12A]"

# R13: маркеры правок аудита-26 на местах (карта «маркер → файл»).
R13B=""
for m in FB-24 FB-26 FB-27 FB-28 FB-29 FB-31 FB-32; do
    grep -q "$m (аудит-26" "$DEP" || R13B="$R13B $m(dep)"
done
grep -q 'FB-24 (аудит-26' "$K/opt/bin/update_protocols.sh" || R13B="$R13B FB-24(upd)"
grep -q 'FB-23 (аудит-26' "$S57" || R13B="$R13B FB-23(S57)"
grep -q 'FB-25 (аудит-26' "$S57" || R13B="$R13B FB-25(S57)"
grep -q 'FB-30 (аудит-26' "$GEN" || R13B="$R13B FB-30(gen)"
grep -q 'FB-33 (аудит-26' "$GEN" || R13B="$R13B FB-33(gen)"
grep -q 'N51-1 (аудит-26' "$GEN" || R13B="$R13B N51-1(gen)"
grep -q 'FB-31 (аудит-26' "$K/opt/etc/bot/utils.py" || R13B="$R13B FB-31(utils)"
grep -q 'FB-34 (аудит-26' "$K/opt/bin/common.sh" || R13B="$R13B FB-34(common)"
if [ -z "$R13B" ]; then
    ok "R13: маркеры FB-23..FB-34 + N51-1 во всех правленых файлах"
else
    bad "R13: отсутствуют:[$R13B]"
fi

echo "═══ S. Аудит-27: проба iptables, детекторы заглушек, честные вердикты ═══"

# S0 (FB-35/K52-7): справка --help не доказывает вставку — проба правилом.
SB="$F/sb"; mkdir -p "$SB/bin"
for fn in ipt_has_target ipt_has_match ipt_is_capable _ipt_probe_ok _ipt_candidate_ok; do
    awk -v f="$fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$SB/fns.sh"
    echo >> "$SB/fns.sh"
done
dash -n "$SB/fns.sh" || { bad "S0: экстракция проб-функций невалидна"; }
cat > "$SB/bin/ipset" <<EOF
#!/bin/sh
echo "ipset \$*" >> "$SB/ipset.log"
exit 0
EOF
cat > "$SB/bin/iptables.good" <<EOF
#!/bin/sh
echo "ipt \$*" >> "$SB/ipt.log"
case "\$1 \$2" in
  "-j TPROXY") echo "TPROXY target options:"; echo "  --on-port port"; exit 0;;
  "-m set") echo "set match options:"; exit 0;;
esac
exit 0
EOF
cat > "$SB/bin/iptables.nft" <<'EOF'
#!/bin/sh
# «nft-подобный»: справку печатает (юзерспейс-плагин), вставку — нет
case "$1 $2" in
  "-j TPROXY") echo "TPROXY target options:"; echo "  --on-port port"; exit 0;;
  "-m set") echo "set match options:"; exit 0;;
esac
case " $* " in
  *" -I "*) echo "Warning: Extension TPROXY revision 0 not supported, missing kernel module?" >&2
            echo "iptables v1.8.11 (nf_tables): RULE_APPEND failed" >&2; exit 4;;
esac
exit 0
EOF
chmod +x "$SB/bin/"*
# a) нет ipset → rc 2 (доверяем справке — холодная установка не ломается)
S0A=$(env -i PATH=/usr/bin:/bin sh -c ". '$SB/fns.sh'; _ipt_probe_ok '$SB/bin/iptables.good'; echo \$?" 2>/dev/null)
# b) рабочий бинарник → кандидат rc 0; вставка/удаление и create/destroy парны
: > "$SB/ipt.log"; : > "$SB/ipset.log"
S0B=$(PATH="$SB/bin:/usr/bin:/bin" sh -c ". '$SB/fns.sh'; _ipt_candidate_ok '$SB/bin/iptables.good'; echo \$?" 2>/dev/null)
S0BI=$(grep -c ' -I ' "$SB/ipt.log" || true)
S0BD=$(grep -c ' -D ' "$SB/ipt.log" || true)
S0BC=$(grep -c ' create ' "$SB/ipset.log" || true)
S0BX=$(grep -c ' destroy ' "$SB/ipset.log" || true)
# c) nft-подобный (справка проходит!) → кандидат rc 1 — отвергнут пробой
S0C=$(PATH="$SB/bin:/usr/bin:/bin" sh -c ". '$SB/fns.sh'; _ipt_candidate_ok '$SB/bin/iptables.nft'; echo \$?" 2>/dev/null)
# d) гейт кандидата стоит на всех точках выбора (deploy 5, хук 4) и в хуке есть проба
S0D=$(grep -c '_ipt_candidate_ok "$_c"' "$DEP" || true)
S0E=$(grep -c '_ipt_candidate_ok "$_c"' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || true)
S0F=$(grep -c '^_ipt_probe_ok() {' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || true)
if [ "$S0A" = 2 ] && [ "$S0B" = 0 ] && [ "$S0C" = 1 ] \
    && [ "$S0BI" = "$S0BD" ] && [ "$S0BI" -ge 1 ] && [ "$S0BC" = "$S0BX" ] \
    && [ "$S0D" = 5 ] && [ "$S0E" = 4 ] && [ "$S0F" = 1 ]; then
    ok "S0: проба iptables: без ipset rc2; рабочий rc0 (вставка/удаление парны); nft-подобный rc1; гейт на 5+4 точках, проба в хуке (K52-7)"
else
    bad "S0: a=$S0A b=$S0B c=$S0C i/d=$S0BI/$S0BD c/x=$S0BC/$S0BX sites=$S0D/$S0E hookprobe=$S0F"
fi

# S1 (FB-36/K52-1): минифицированный JSON — значение поля, а не строка.
SC="$F/sc"; mkdir -p "$SC"
# FB-95 (аудит-36) + FB-111 (аудит-38): needs_key зовёт
# _nk_root_two (lazy-хелпер, один субшелл на server+auth)
awk 'index($0, "_nk_root_two() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$SC/nk.sh"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$SC/nk.sh"
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$SC/nk.sh"
cat > "$SC/mk.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/sc/nk.sh
i=0; fail=0
t(){ i=$((i+1)); printf '%s' "$2" > /tmp/f47chk/sc/c$i.json
     needs_key /tmp/f47chk/sc/c$i.json; r=$?
     [ "$r" = "$3" ] || { echo "case$i($1):rc=$r,want=$3"; fail=1; } }
t 'mini-stub+mask'  '{"server":"example.com:443","auth":"s3cret","tls":{"sni":"vpn.example.org"}}' 0
t 'mini-stub'       '{"server":"example.com","auth":"s3cret"}' 0
t 'mini-empty-srv'  '{"server":"","auth":"s3cret"}' 0
t 'mini-empty-addr' '{"address":"","password":"x"}' 0
t 'multi-stub'      '{
 "server": "example.com:443",
 "auth": "s3cret",
 "tls": {"sni": "vpn.example.org"}
}' 0
t 'multi-stub2'     '{
 "server": "example.com",
 "auth": "k"
}' 0
t 'mini-real+mask'  '{"server":"real.example.org:443","auth":"k","tls":{"sni":"example.com"}}' 1
t 'multi-real+mask' '{
 "server": "real.example.org:443",
 "auth": "k",
 "tls": {"sni": "example.com"}
}' 1
t 'mini-serverName' '{"server":"real.example.org:443","auth":"k","transport":{"tls":{"serverName":"example.com"}}}' 1
t 'mini-sni-clean'  '{"server":"real.example.org:443","auth":"k","tls":{"sni":"ex-ample.com"}}' 1
# FB-89: маркеры — только в полях-ключах address|server|remote_addr|auth;
t 'mini-CHANGE_ME'  '{"password":"CHANGE_ME"}' 1
t 'mini-zero-uuid'  '{"server":"real.example.org:443","uuid":"00000000-0000-0000-0000-000000000000"}' 1
echo "fail=$fail"
EOF
chmod +x "$SC/mk.sh"
S1S=$(sh "$SC/mk.sh" 2>/dev/null | tail -1)
python3 - "$K" > "$F/s1py.out" 2>&1 <<'PYS1'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import importlib.util
spec = importlib.util.spec_from_file_location('u27', sys.argv[1] + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
# FB-89: кейсы 11/12 — заглушки вне полей-ключей более не
# блокируют конфиг (точечный матч значений полей) — паритет с
# needs_key/S57/preflight, которые password/uuid не смотрят
cases = [(1, True), (2, True), (3, True), (4, True), (5, True), (6, True),
         (7, False), (8, False), (9, False), (10, False), (11, False), (12, False)]
bad = []
for i, want in cases:
    got = u.config_has_placeholders(f'/tmp/f47chk/sc/c{i}.json')
    if got != want:
        bad.append(i)
print('OK' if not bad else 'BAD %r' % bad)
PYS1
if [ "$S1S" = "fail=0" ] && grep -q '^OK$' "$F/s1py.out"; then
    ok "S1: needs_key+utils: 12 кейсов мини/мульти — заглушка в server видна, sni/serverName/peer_name-маскировка чиста; password/uuid-маркеры вне полей-ключей не блокируют (K52-1+FB-89)"
else
    bad "S1: shell=[$S1S] py=$(cat "$F/s1py.out")"
fi

# S2 (FB-37/K52-4): dnsmasq — честный вердикт при отсутствии бинарника.
SD="$F/sd"; mkdir -p "$SD/bin"
awk '/^DNSMASQ_IPSET_OK=0$/{f=1} f{print} /dnsmasq с поддержкой ipset/{if(f)exit}' "$DEP" > "$SD/blk.sh"
{ echo 'warn(){ echo "WARN: $*"; }'
  echo 'have_cmd(){ command -v "$1" >/dev/null 2>&1; }'
  echo '_kz_http_install_gate(){ return 1; }'
  echo '_kz_pkg_cache_note(){ :; }'
  echo 'SKIPPED_HTTP=""'
  cat "$SD/blk.sh"; } > "$SD/run.sh"
printf '#!/bin/sh\necho "dnsmasq 2.90"\n' > "$SD/bin/dnsmasq.ok"; chmod +x "$SD/bin/dnsmasq.ok"
printf '#!/bin/sh\necho "dnsmasq 2.90 (no-ipset)"\n' > "$SD/bin/dnsmasq.noip"; chmod +x "$SD/bin/dnsmasq.noip"
ln -sf "$SD/bin/dnsmasq.ok" "$SD/bin/dnsmasq"
S2A=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
ln -sf "$SD/bin/dnsmasq.noip" "$SD/bin/dnsmasq"
S2B=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
rm -f "$SD/bin/dnsmasq"
S2C=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
if printf '%s' "$S2A" | grep -q '✅ dnsmasq с поддержкой ipset' \
    && ! printf '%s' "$S2B" | grep -q '✅' \
    && printf '%s' "$S2B" | grep -q 'БЕЗ ipset' \
    && ! printf '%s' "$S2C" | grep -q '✅' \
    && printf '%s' "$S2C" | grep -q 'не найден в PATH'; then
    ok "S2: dnsmasq: есть+ipset → ✅; no-ipset → warn без ✅; отсутствует → warn без ✅ (K52-4)"
else
    bad "S2: a=$(echo "$S2A" | head -1) b=$(echo "$S2B" | grep -c WARN) c=$(echo "$S2C" | head -1)"
fi

# S3 (FB-38/K52-3): JS addToList показывает warning из ответа.
S3A=$(grep -c "j.warning?' \\\\u26A0 '+j.warning:''" "$GEN" || true)
[ "$S3A" = 1 ] \
    && ok "S3: addToList: warning отображается (JS-ветка на месте) (K52-3)" \
    || bad "S3: js_branch=$S3A"

# S4 (FB-40/K52-5): единственный opkg list-installed — внутри мемоизации.
# только код: комментарий FB-40 тоже упоминает opkg list-installed
S4A=$(grep -v '^[[:space:]]*#' "$DEP" | grep -c 'opkg list-installed' || true)
[ "$S4A" = 1 ] \
    && ok "S4: opkg list-installed ×1 (мемоизация; ветки iptables закрыты) (K52-5)" \
    || bad "S4: calls=$S4A"

# S5 (FB-41/N52-8): check_updates — tty печатает, не-tty молчит.
SE="$F/se"; mkdir -p "$SE"
awk '/# ── Уведомление ──/{f=1} f{print}' "$K/opt/bin/check_updates.sh" > "$SE/tail.sh"
{ echo 'HAS_UPDATES=true'
  echo 'ARCH=x64'
  echo 'MSG="🆕 <b>Обновления (x64):</b>"'
  echo 'send_telegram(){ echo "TG" >> "'"$SE"'/tg.log"; }'
  cat "$SE/tail.sh"; } > "$SE/drv.sh"
dash -n "$SE/drv.sh" || bad "S5: драйвер невалиден"
rm -f "$SE/tg.log"; sh "$SE/drv.sh" > "$SE/notty.out" 2>/dev/null
S5A=$(wc -c < "$SE/notty.out" | tr -d ' ')
S5B=$([ -f "$SE/tg.log" ] && echo tg || echo notg)
if command -v script >/dev/null 2>&1; then
    S5C=$(script -qec "sh '$SE/drv.sh'" /dev/null 2>/dev/null | tr -d '\r' | grep -c 'Обновления (x64)')
else
    S5C=1  # pty-утилита недоступна — проверяем только не-tty ветку
fi
if [ "$S5A" = 0 ] && [ "$S5B" = tg ] && [ "$S5C" = 1 ]; then
    ok "S5: check_updates: не-tty молчит (Telegram вызван); tty печатает без HTML-тегов (N52-8)"
else
    bad "S5: notty_bytes=$S5A tg=$S5B tty=$S5C"
fi

# S6 (FB-39/K52-6): снимок списков — по Flask, если доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/s6.out" 2>&1 <<'PYS6'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g
g.config.list_files = {n: f'/tmp/f47chk/sf_{n}.txt' for n in
                       ('shadowsocks', 'vless', 'trojan', 'hysteria', 'tor', 'bot')}
for n in g.config.list_files:
    open(g.config.list_files[n], 'w').write(
        '\n'.join(f'd{i}.example' for i in range(500)) + '\n')
calls = {'n': 0}
orig = g.read_file_text
def counting(p):
    calls['n'] += 1
    return orig(p)
g.read_file_text = counting
_cls = g._cross_list_sources('hysteria')
snap_reads = calls['n']
cross = [e for e in (f'd{i}.example' for i in range(100))
         for name, entries in _cls.items() if e in entries]
calls['n'] = 0
wrap = g._cross_list_hint('d0.example', 'hysteria')
ok6 = (snap_reads == 4 and calls['n'] == 4 and len(cross) == 400
       and wrap == ['shadowsocks', 'vless', 'trojan', 'tor'])
print('OK snap=%d wrap_reads=%d cross=%d' % (snap_reads, calls['n'], len(cross))
      if ok6 else 'BAD snap=%d wrap_reads=%d cross=%d wrap=%s' % (
          snap_reads, calls['n'], len(cross), wrap))
PYS6
    grep -q '^OK ' "$F/s6.out" \
        && ok "S6: cross-list: 100 записей → 4 чтения (снимок), предупреждения те же; обёртка жива (K52-6)" \
        || bad "S6: $(cat "$F/s6.out")"
else
    echo "[SKIP] S6: Flask-смоук — flask не установлен на хосте"
fi

# S7: маркеры правок аудита-27 на местах.
S7B=""
for m in FB-35 FB-36 FB-37 FB-40; do
    grep -q "$m (аудит-27" "$DEP" || S7B="$S7B $m(dep)"
done
grep -q 'FB-35 (аудит-27' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || S7B="$S7B FB-35(hook)"
grep -q 'FB-36 (аудит-27' "$K/opt/etc/bot/utils.py" || S7B="$S7B FB-36(utils)"
grep -q 'FB-38' "$GEN" || S7B="$S7B FB-38(gen)"
grep -q 'FB-39' "$GEN" || S7B="$S7B FB-39(gen)"
grep -q 'FB-41 (аудит-27' "$K/opt/bin/check_updates.sh" || S7B="$S7B FB-41(cu)"
if [ -z "$S7B" ]; then
    ok "S7: маркеры FB-35..FB-41 во всех правленых файлах (deploy, хук, utils, generator, check_updates)"
else
    bad "S7: отсутствуют:[$S7B]"
fi

# ═══ T. Аудит-28: регресс JS, HTTP-гейт, вердикт пробы, паритет валидаторов ═══
echo "═══ T. Аудит-28 (r53): JS, гейт 11 форм, |0-вердикт, валидаторы, лимиты ═══"

# T0 (FB-42/R53-01): регресс JS — рендер + node --check каждого блока.
if python3 -c 'import flask' >/dev/null 2>&1 \
    && command -v node >/dev/null 2>&1; then
    python3 - "$K" > "$F/t0.out" 2>&1 <<'PYT0'
import sys, re, subprocess, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
html = c.get('/', auth=('a', 'b')).data.decode()
blocks = re.findall(r'<script[^>]*>(.*?)</script>', html, re.S)
assert blocks, 'нет script-блоков'
for i, b in enumerate(blocks, 1):
    p = f'/tmp/f47chk/t0js{i}.js'
    open(p, 'w').write(b)
    r = subprocess.run(['node', '--check', p], capture_output=True)
    assert r.returncode == 0, 'блок %d: %s' % (
        i, r.stderr.decode()[-140:])
print('OK blocks=%d' % len(blocks))
PYT0
    if grep -q '^OK' "$F/t0.out"; then
        ok "T0: все inline <script> панели валидны (node --check) — регресс FB-38 пойман и закрыт (R53-01)"
    else
        bad "T0: $(tail -1 "$F/t0.out")"
    fi
else
    if ! grep -Fq ":'')}}" "$GEN" && grep -Fq ":'')}" "$GEN"; then
        ok "T0: [частично, без flask/node] исходник addToList без лишней } (R53-01)"
    else
        bad "T0: паттерн регресса JS на месте (R53-01)"
    fi
fi

# T1 (FB-43/R53-03): модули ДО пробы; вердикт пробы — в решении deploy/хука.
T1B=""
_s2=$(grep -n '⏳ \[2/11\]' "$DEP" | head -1 | cut -d: -f1)
_lk=$(grep -n '^load_kmod() {' "$DEP" | head -1 | cut -d: -f1)
_pk=$(awk -v s="$_s2" 'NR>s && /_IPT_PICK="\$\(pick_iptables\)"/{print NR; exit}' "$DEP")
[ -n "$_lk" ] && [ "$_lk" -lt "$_pk" ] || T1B="$T1B load_kmod<pick"
awk -v s="$_s2" -v p="$_pk" 'NR>=s&&NR<p&&/for _dep in nf_defrag_ipv4/{f=1} END{exit !f}' "$DEP" \
    || T1B="$T1B mods-before-pick"
[ "$(grep -c 'if \[ "\$_IPT_CAPABLE" != 1 \]; then' "$DEP")" = 2 ] \
    || T1B="$T1B flag-accept"
grep -q '\[ "\${_ipt_re#\*|}" = 1 \]' "$DEP" || T1B="$T1B repick-flag"
grep -q 'пригодность не подтверждена (гейт справка+проба)' "$DEP" \
    || T1B="$T1B honest-verdict"
grep -q 'if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    || T1B="$T1B hook-cache-gate"
TB1="$F/t1"; mkdir -p "$TB1/bin"
cat > "$TB1/bin/iptables" <<'EOF'
#!/bin/sh
case "$*" in
    *--help*) echo "TPROXY target options:"; echo "set match options:"; exit 0 ;;
    *PREROUTING*) exit 4 ;;
esac
exit 0
EOF
cat > "$TB1/bin/ipset" <<'EOF'
#!/bin/sh
exit 0
EOF
chmod +x "$TB1/bin/iptables" "$TB1/bin/ipset"
for _fn in ipt_has_target ipt_has_match ipt_is_capable _ipt_probe_ok _ipt_candidate_ok pick_iptables; do
    awk -v f="$_fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$TB1/h.sh"
done
T1R=$(PATH="$TB1/bin:/usr/bin:/bin" sh -c ". '$TB1/h.sh'; pick_iptables" 2>/dev/null)
case "$T1R" in
    *'|0') : ;;
    *) T1B="$T1B nft-only[$T1R]" ;;
esac
if [ -z "$T1B" ]; then
    ok "T1: модули до пробы; решение по флагу (|0 ≠ ✅); кэш хука только для |1; nft-only pick → |0 (R53-03)"
else
    bad "T1:$T1B"
fi

# T2 (FB-44/R53-02): HTTP-гейт — 11 форм opkg.conf × обе копии.
T2D=""
extract_fn() { awk -v f="$1" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$2"; }
{ extract_fn _kz_http_feed_active "$DEP"; extract_fn _kz_http_install_gate "$DEP"; } > "$F/t2dep.sh"
{ extract_fn _upd_http_feed_active "$K/opt/bin/update_protocols.sh"; extract_fn _upd_http_install_gate "$K/opt/bin/update_protocols.sh"; } > "$F/t2upd.sh"
warn() { :; }
. "$F/t2dep.sh"
. "$F/t2upd.sh"
T2N=0
t2_case() { # $1=tag $2=content|@DIR|@MISS $3=ожидаемый rc гейта $4=dep|upd
    case "$2" in
        @DIR) rm -rf "$F/t2conf"; mkdir -p "$F/t2conf" ;;
        @MISS) rm -rf "$F/t2conf" ;;
        *) rm -rf "$F/t2conf"; printf '%s\n' "$2" > "$F/t2conf" ;;
    esac
    T2N=$((T2N+1))
    if [ "$4" = dep ]; then
        KZ_DEPLOY_OPKG_CONF="$F/t2conf" _kz_http_install_gate pkg
    else
        KZ_DEPLOY_OPKG_CONF="$F/t2conf" _upd_http_install_gate pkg
    fi
    [ $? = "$3" ] || T2D="$T2D $1-$4"
}
for _cp in dep upd; do
    t2_case srcgz_http 'src/gz entware http://foo/bar' 1 "$_cp"
    t2_case quoted_type '"src/gz" entware http://foo/bar' 1 "$_cp"
    t2_case quoted_all '"src/gz" "entware" "http://foo/bar"' 1 "$_cp"
    t2_case src_plain 'src entware http://foo/bar' 1 "$_cp"
    t2_case indent_q '   src/gz "entware" "http://foo/bar"' 1 "$_cp"
    t2_case dist_gz 'dist/gz feed http://foo/bar' 1 "$_cp"
    t2_case dist 'dist feed http://foo/bar' 1 "$_cp"
    t2_case directory @DIR 1 "$_cp"
    t2_case missing @MISS 1 "$_cp"
    t2_case https 'src/gz entware https://foo/bar' 0 "$_cp"
    t2_case commented '# src/gz entware http://foo/bar' 0 "$_cp"
done
if [ -z "$T2D" ]; then
    ok "T2: HTTP-гейт: 11 форм × deploy+update — 4 fail-open формы закрыты, https/комментарий свободны (R53-02)"
else
    bad "T2:$T2D (из $T2N)"
fi

# T3 (FB-45/R53-04): паритет 4 валидаторов hysteria на 8 конфигах.
T3="$F/t3"; mkdir -p "$T3/cfg"
T3BASE='"tcpRedirect": {"listen": "0.0.0.0:10830"}, "udpTProxy": {"listen": "0.0.0.0:10830"}'
printf '{ "server": "real.example.org:443", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c1.json"
printf '{ "server": "example.com:443", "auth": "realkey", "tls": {"sni": "example.com"}, %s }\n' "$T3BASE" > "$T3/cfg/c2.json"
printf '{ "server": "", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c3.json"
printf '{ "server": "real.example.org:443", "auth": "00000000-0000-0000-0000-000000000000", %s }\n' "$T3BASE" > "$T3/cfg/c4.json"
printf '{ "server": "real.example.org:443", "auth": "", %s }\n' "$T3BASE" > "$T3/cfg/c5.json"
printf '{ "server": "real.example.org:443", %s }\n' "$T3BASE" > "$T3/cfg/c6.json"
printf '{ "server": "real.example.org:443", "auth": "CHANGE_ME", %s }\n' "$T3BASE" > "$T3/cfg/c7.json"
printf '{ "server": "{{server}}:{{port}}", "auth": "{{auth}}", %s }\n' "$T3BASE" > "$T3/cfg/c8.json"
# FB-74 (аудит-33, K58-2/R58-05): c9 — sni-исключение (real server +
# sni=example.com → старт); c10 — нестроковый server; c11 — регистр;
# c12/c13 — конечная точка FQDN-формы (без порта и с портом).
printf '{ "server": "real.example.org:443", "auth": "realkey", "tls": {"sni": "example.com"}, %s }\n' "$T3BASE" > "$T3/cfg/c9.json"
printf '{ "server": 123, "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c10.json"
printf '{ "server": "EXAMPLE.com:443", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c11.json"
printf '{ "server": "example.com.", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c12.json"
printf '{ "server": "example.com.:443", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c13.json"
# FB-96/97/98 (аудит-36): c14 — auth-секрет с портом (валиден);
# c15 — дубликат корневого auth (fail-closed у всех); c16 — маркер
# через \u-эскейп (декодируется до точного совпадения).
printf '%s\n' '{ "server": "real.example.org:443", "auth": "change_me:443", '"$T3BASE"' }' > "$T3/cfg/c14.json"
printf '%s\n' '{ "server": "real.example.org:443", "auth": "a", "auth": "realkey", '"$T3BASE"' }' > "$T3/cfg/c15.json"
printf '%s\n' '{ "server": "real.example.org:443", "auth": "change\u005fme", '"$T3BASE"' }' > "$T3/cfg/c16.json"
T3S57="$T3/rb"; mkdir -p "$T3S57"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$T3S57/gate.sh"
cat > "$T3S57/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/t3/rb/gate.sh
echo "GATE_RC=PASS"
EOF
T3B=""
for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16; do
    awk 'index($0, "_nk_root_two() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$F/t3nk.sh"
    awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$F/t3nk.sh"
    awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$F/t3nk.sh"
    . "$F/t3nk.sh"
    # FB-54 (аудит-29, N54-2): флаг hysteria включает проверку
    # отсутствующего auth (без флага — xray/ss/trojan без поля auth
    # не считаются заглушками).
    needs_key "$T3/cfg/c$i.json" hysteria
    nk=$?
    s57out=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$T3/cfg/c$i.json" sh "$T3S57/run.sh" start 2>&1)
    if printf '%s' "$s57out" | grep -q SKIPPED; then s57=SKIP; else s57=START; fi
    case "$i:$nk:$s57" in
        1:1:START|2:0:SKIP|3:0:SKIP|4:0:SKIP|5:0:SKIP|6:0:SKIP|7:0:SKIP|8:0:SKIP|9:1:START|10:0:SKIP|11:0:SKIP|12:0:SKIP|13:0:SKIP|14:1:START|15:0:SKIP|16:0:SKIP) : ;;
        *) T3B="$T3B c$i(nk=$nk,s57=$s57)" ;;
    esac
done
python3 - "$K" > "$F/t3py.out" 2>&1 <<'PYT3'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('u', K + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
exp_ph = {1: False, 2: True, 3: True, 4: True, 5: True,
          6: True, 7: True, 8: True, 9: False, 10: True,
          11: True, 12: True, 13: True,
          14: False, 15: True, 16: True}
# FB-74 (аудит-33, K58-2): c2 (example.com:443 + реальный auth) —
# прежде preflight пропускал (закреплённый дефект), теперь rej;
# c9 — sni-исключение сохранено → ok.
exp_pf = {1: 'ok', 2: 'rej', 3: 'rej', 4: 'rej', 5: 'rej',
          6: 'rej', 7: 'rej', 8: 'rej', 9: 'ok', 10: 'rej',
          11: 'rej', 12: 'rej', 13: 'rej',
          14: 'ok', 15: 'rej', 16: 'rej'}
for i in range(1, 17):
    fp = f'/tmp/f47chk/t3/cfg/c{i}.json'
    ph = u.config_has_placeholders(fp, require_auth=True)
    try:
        u._preflight_hysteria(fp)
        pf = 'ok'
    except ValueError:
        pf = 'rej'
    assert ph == exp_ph[i], f'c{i} placeholders={ph}'
    assert pf == exp_pf[i], f'c{i} preflight={pf}'
print('OK')
PYT3
grep -q '^OK' "$F/t3py.out" || T3B="$T3B py:$(tail -1 "$F/t3py.out")"
if [ -z "$T3B" ]; then
    ok "T3: 4 валидатора hysteria сходятся на 16 конфигах: отсутствующий auth, example.com (порт/регистр/точка/не-строка) — rej всеми, sni-исключение — старт, auth-секрет:443 — старт, дубликаты/эскейпы — rej (FB-54+FB-74, FB-96/97/98 аудит-36)"
else
    bad "T3:$T3B"
fi

# T4 (FB-46+T-2/R53-06-07): lookup-add — 1 чтение target, лимит, bot, точка.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/t4.out" 2>&1 <<'PYT4'
import sys, os, re, importlib.util, tempfile
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzt4_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('')
calls = {'n': 0}
_orig = g.read_file_text
def _cr(fp):
    calls['n'] += 1
    return _orig(fp)
g.read_file_text = _cr
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/panel?tab=ss', auth=('a', 'b')).data.decode()
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
H = {'Origin': 'http://localhost'}
tf = g.config.list_files['trojan']
calls['n'] = 0
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'trojan',
         'entries': '\n'.join('d%d.example' % i for i in range(100))},
         headers=H, auth=('a', 'b'))
assert r.status_code == 200 and calls['n'] == 5, (r.status_code, calls['n'])
g.MAX_LIST_LINES = 5
open(tf, 'w').write('a.example\nb.example\n')
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'trojan',
         'entries': 'x1.example\nx2.example\nx3.example\nx4.example'},
         headers=H, auth=('a', 'b'))
assert r.status_code == 400 and len(open(tf).read().splitlines()) == 2
open(g.config.list_files['vless'], 'w').write('shared.example\n')
calls['n'] = 0
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'bot',
         'entries': 'shared.example'}, headers=H, auth=('a', 'b'))
assert r.status_code == 200 and 'warning' not in r.get_json() and calls['n'] == 1
open(g.config.list_files['tor'], 'w').write('dot.example\n')
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'tor',
         'entries': 'dot.example.'}, headers=H, auth=('a', 'b'))
j = r.get_json()
assert j.get('added') == [] and j.get('duplicates') == ['dot.example']
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'tor',
         'entries': 'weird.example.'}, headers=H, auth=('a', 'b'))
assert r.get_json().get('added') == ['weird.example']
assert 'weird.example.' not in open(g.config.list_files['tor']).read()
print('OK')
PYT4
    if grep -q '^OK' "$F/t4.out"; then
        ok "T4: lookup-add: 100 записей → 5 чтений; лимит 400 без записи; bot без cross; точка нормализована (R53-06/07)"
    else
        bad "T4: $(tail -1 "$F/t4.out")"
    fi
else
    grep -q 'FB-46 (аудит-28, R53-06)' "$GEN" \
        && ok "T4: [частично, без flask] маркеры FB-46/T-2 на месте" \
        || bad "T4: маркеры FB-46/T-2 отсутствуют"
fi

# T5 (FB-47/R53-08): check_updates — «проверка не удалась» ≠ «Обновлений нет».
T5="$F/t5"; mkdir -p "$T5"
awk '/# ── Уведомление ──/{f=1} f{print}' "$K/opt/bin/check_updates.sh" > "$T5/tail.sh"
{ echo 'HAS_UPDATES=false'; echo 'ARCH=x64'
  echo 'CHECK_FAILED=1'
  echo 'send_telegram(){ :; }'
  cat "$T5/tail.sh"; } > "$T5/drv_fail.sh"
{ echo 'HAS_UPDATES=false'; echo 'ARCH=x64'
  echo 'CHECK_FAILED=0'
  echo 'send_telegram(){ :; }'
  cat "$T5/tail.sh"; } > "$T5/drv_ok.sh"
T5B=""
sh "$T5/drv_fail.sh" > "$T5/notty" 2>/dev/null
[ "$(wc -c < "$T5/notty" | tr -d ' ')" = 0 ] || T5B="$T5B fail-notty-не-молчит"
if command -v script >/dev/null 2>&1; then
    script -qec "sh '$T5/drv_fail.sh'" /dev/null 2>/dev/null | tr -d '\r' > "$T5/tty_fail"
    script -qec "sh '$T5/drv_ok.sh'" /dev/null 2>/dev/null | tr -d '\r' > "$T5/tty_ok"
    grep -q 'Проверка обновлений не удалась' "$T5/tty_fail" || T5B="$T5B fail-нет-честного-сбоя"
    grep -q 'Обновлений нет' "$T5/tty_fail" && T5B="$T5B fail-ложное-«нет»"
    grep -q 'Обновлений нет' "$T5/tty_ok" || T5B="$T5B ok-нет-«нет»"
else
    grep -q 'Проверка обновлений не удалась' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-текста-сбоя"
fi
grep -q 'OPKG_UPD_RC=0' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-захвата-rc"
grep -q '\\"check_failed\\":' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-check_failed-в-JSON"
if [ -z "$T5B" ]; then
    ok "T5: check_updates: сбой источников → «Проверка не удалась» (tty+JSON check_failed), успех → «Обновлений нет» (R53-08)"
else
    bad "T5:$T5B"
fi

# T6 (FB-48/R53-05): PID-личность по /proc/exe.
T6="$F/t6"; mkdir -p "$T6/rp"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$T6/rp/gate.sh"
cat > "$T6/rp/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
export KEENZOO_HYSTERIA_PIDFILE
. /tmp/f47chk/t6/rb/gate.sh
echo "GATE_RC=PASS"
EOF
sed -i "s|/tmp/f47chk/t6/rb/|/tmp/f47chk/t6/rp/|" "$T6/rp/run.sh"
printf '{ "server": "real.example.org:443", "auth": "00000000-0000-0000-0000-000000000000" }\n' > "$T6/stub.json"
cp /bin/sleep "$T6/rp/hysteria" 2>/dev/null || cp "$(command -v sleep)" "$T6/rp/hysteria"
chmod +x "$T6/rp/hysteria"
T6B=""
"$T6/rp/hysteria" 300 & T6P1=$!
sleep 1
printf '%s\n' "$T6P1" > "$T6/rp/pid"
T6A=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$T6/stub.json" KEENZOO_HYSTERIA_PIDFILE="$T6/rp/pid" sh "$T6/rp/run.sh" start 2>&1)
sleep 1
kill -0 "$T6P1" 2>/dev/null && T6B="$T6B свой-не-снят"
printf '%s' "$T6A" | grep -q 'Stopping hysteria' || T6B="$T6B нет-Stopping"
wait "$T6P1" 2>/dev/null
bash -c 'exec -a hysteria-marker sleep 60' & T6P2=$!
sleep 1
printf '%s\n' "$T6P2" > "$T6/rp/pid"
KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$T6/stub.json" KEENZOO_HYSTERIA_PIDFILE="$T6/rp/pid" sh "$T6/rp/run.sh" start >/dev/null 2>&1
kill -0 "$T6P2" 2>/dev/null || T6B="$T6B argv-чужой-убит"
kill "$T6P2" 2>/dev/null; wait "$T6P2" 2>/dev/null
[ -e "$T6/rp/pid" ] && T6B="$T6B pid-не-снят"
if [ -z "$T6B" ]; then
    ok "T6: S57 PID: свой (exe=hysteria) снят; argv-подстрока чужого не убита; pid снят (R53-05)"
else
    bad "T6:$T6B"
fi

# T7 (FB-49/R53-10): баннер — имя или «панель не настроена».
T7="$F/t7"; mkdir -p "$T7"
sed -n "/^_panel_user=\"\$(grep/,/^fi$/p" "$DEP" | sed "s|/opt/etc/bot/bot_config.py|$T7/bot_config.py|" > "$T7/banner.sh"
printf 'web_username = "ivan"\n' > "$T7/bot_config.py"
T7A=$(sh "$T7/banner.sh" 2>/dev/null)
printf 'web_username = ""\n' > "$T7/bot_config.py"
T7B=$(sh "$T7/banner.sh" 2>/dev/null)
if printf '%s' "$T7A" | grep -q '(ivan,' \
    && printf '%s' "$T7B" | grep -q 'панель не настроена: web_username пуст'; then
    ok "T7: сводка deploy: пустой web_username → «панель не настроена», а не «admin» (R53-10)"
else
    bad "T7: ivan=[$T7A] empty=[$T7B]"
fi

# T8 (FB-50/R53-11): _kz_pkg_installed — литерально + пустой список не залипает.
T8="$F/t8"; mkdir -p "$T8/bin"
awk 'index($0, "_kz_pkg_installed() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$T8/pki.sh"
printf '#!/bin/sh\nexit 1\n' > "$T8/bin/opkg"; chmod +x "$T8/bin/opkg"
T8B=""
(
    PATH="$T8/bin:/usr/bin:/bin"
    . "$T8/pki.sh"
    _KZ_PKG_LIST=""; unset _KZ_PKG_LIST_READY _KZ_PKG_NEW
    _kz_pkg_installed foo
    [ -z "${_KZ_PKG_LIST_READY:-}" ] || exit 3
    exit 0
) || T8B="$T8B пустой-список-залип"
printf '#!/bin/sh\necho "libstdc++ - 1.0"\necho "iptables - 1.8"\n' > "$T8/bin/opkg"; chmod +x "$T8/bin/opkg"
(
    PATH="$T8/bin:/usr/bin:/bin"
    . "$T8/pki.sh"
    _KZ_PKG_LIST=""; unset _KZ_PKG_LIST_READY _KZ_PKG_NEW
    _kz_pkg_installed 'libstdc++' || exit 4
    _kz_pkg_installed 'libstdc' && exit 5
    exit 0
) || T8B="$T8B rc=$?-литерал"
if [ -z "$T8B" ]; then
    ok "T8: _kz_pkg_installed: пустой сбойный список не кэшируется; libstdc++ найден, libstdc — нет (R53-11)"
else
    bad "T8:$T8B"
fi

# T9 (FB-51/R53-09): Range-заметка по коду ответа, а не по размеру.
T9="$F/t9"; mkdir -p "$T9/bin" "$T9/dl"
cat > "$T9/bin/curl" <<'EOF'
#!/bin/sh
out=""; code=""; body=""
for a in "$@"; do
    case "$a" in
        http*://*206*) code=206; body=bbbb ;;
        http*://*200s*) code=200; body=bb ;;
        http*://*nc*) code=""; body=bbbb ;;
        http*://*200b*) code=200; body=bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb ;;
    esac
done
prev=""
for a in "$@"; do
    [ "$prev" = "-o" ] && printf '%s' "$body" > "$a"
    prev="$a"
done
[ -n "$code" ] && printf '%s' "$code"
exit 0
EOF
chmod +x "$T9/bin/curl"
cat > "$T9/drv.sh" <<'EOF'
#!/bin/sh
DL_CMD=curl
KEENZOO_DLTMP=/tmp/f47chk/t9/dl
dl_file() { return 1; }
warn() { :; }
. /tmp/f47chk/t9/pf.sh
_entware_probe_feed_url "$1"
echo "rc=$? NOTE=[$_EPF_NOTE]"
EOF
for _fn in _entware_probe_feed_url; do
    awk -v f="$_fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$T9/pf.sh"
done
T9B=""
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f206.example/o)" = "rc=0 NOTE=[curl, range 256Б]" ] || T9B="$T9B 206"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f200s.example/o)" = "rc=0 NOTE=[curl, полная загрузка (сервер без Range)]" ] || T9B="$T9B 200-короткое"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://fnc.example/o)" = "rc=0 NOTE=[curl, range 256Б]" ] || T9B="$T9B фолбэк-без-кода"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f200b.example/o)" = "rc=0 NOTE=[curl, полная загрузка (сервер без Range)]" ] || T9B="$T9B 200-большое"
if [ -z "$T9B" ]; then
    ok "T9: Range-заметка: 206 → range; 200+короткое тело → «полная загрузка» (прежде ложный range); без кода — размер (R53-09)"
else
    bad "T9:$T9B"
fi

# T10: маркеры правок аудита-28 на местах.
T10B=""
grep -q 'FB-43 (аудит-28' "$DEP" || T10B="$T10B FB-43(dep)"
grep -q 'FB-43 (аудит-28' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || T10B="$T10B FB-43(hook)"
grep -q 'FB-44 (аудит-28' "$DEP" || T10B="$T10B FB-44(dep)"
grep -q 'FB-44 (аудит-28' "$K/opt/bin/update_protocols.sh" || T10B="$T10B FB-44(upd)"
grep -q 'FB-45 (аудит-28' "$DEP" || T10B="$T10B FB-45(dep)"
grep -q 'FB-45 (аудит-28' "$S57" || T10B="$T10B FB-45(S57)"
grep -q 'FB-45 (аудит-28' "$K/opt/etc/bot/utils.py" || T10B="$T10B FB-45(utils)"
grep -q 'FB-46 (аудит-28' "$GEN" || T10B="$T10B FB-46(gen)"
grep -q 'T-2 (аудит-28' "$GEN" || T10B="$T10B T-2(gen)"
grep -q 'FB-47 (аудит-28' "$K/opt/bin/check_updates.sh" || T10B="$T10B FB-47(cu)"
grep -q 'FB-48 (аудит-28' "$S57" || T10B="$T10B FB-48(S57)"
grep -q 'FB-49 (аудит-28' "$DEP" || T10B="$T10B FB-49(dep)"
grep -q 'FB-50 (аудит-28' "$DEP" || T10B="$T10B FB-50(dep)"
grep -q 'FB-51 (аудит-28' "$DEP" || T10B="$T10B FB-51(dep)"
if [ -z "$T10B" ]; then
    ok "T10: маркеры FB-43..FB-51 + T-2 во всех правленых файлах (FB-42 — JS-паттерн, см. T0)"
else
    bad "T10: отсутствуют:$T10B"
fi

# ═══ U. Аудит-29: гонка записи, счётчик входа, паритет auth ═══
echo "═══ U. Аудит-29 (r54): запись списков, счётчик входа, паритет auth ═══"

# U0 (FB-52/K54-2): 20 параллельных POST — 20×200 и 20/20 записей.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/u0.out" 2>&1 <<'PYU0'
import sys, os, re, importlib.util, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzu0_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('')
N = 20
results = [None] * N
barrier = threading.Barrier(N)
def worker(i):
    c = g.app.test_client()
    with c.session_transaction() as sess:
        sess['auth'] = True
    html = c.get('/panel?tab=ss', auth=('a', 'b')).data.decode()
    token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"',
                      html).group(1)
    barrier.wait()
    r = c.post('/api/lookup-add',
               data={'csrf_token': token, 'list': 'trojan',
                     'entries': 'p%d.example' % i},
               headers={'Origin': 'http://localhost'},
               auth=('a', 'b'))
    results[i] = r.status_code
ts = [threading.Thread(target=worker, args=(i,)) for i in range(N)]
for t in ts: t.start()
for t in ts: t.join()
ok = sum(1 for c in results if c == 200)
e500 = sum(1 for c in results if c == 500)
content = set(open(g.config.list_files['trojan']).read().splitlines())
landed = sum(1 for i in range(N) if ('p%d.example' % i) in content)
assert ok == N and e500 == 0 and landed == N, (ok, e500, landed)
print('OK')
PYU0
    if grep -q '^OK' "$F/u0.out"; then
        ok "U0: 20 параллельных POST /api/lookup-add: 20×200, 20/20 записей (r54: 13×500, 1/20) (K54-2)"
    else
        bad "U0: $(tail -1 "$F/u0.out")"
    fi
else
    grep -q 'mkstemp' "$K/opt/etc/bot/lists_core.py" \
        && ok "U0: [частично, без flask] mkstemp в _atomic_write_text (K54-2)" \
        || bad "U0: нет mkstemp в lists_core (K54-2)"
fi

# U1 (FB-52): прямой стресс _atomic_write_text — 24 потока, без исключений.
python3 - "$K" > "$F/u1.out" 2>&1 <<'PYU1'
import sys, importlib.util, os, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location(
    'lc', K + '/opt/etc/bot/lists_core.py')
lcm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lcm)
d = tempfile.mkdtemp(prefix='kzu1_')
fp = os.path.join(d, 'stress.txt')
open(fp, 'w').write('')
errs = []
def hammer(k):
    try:
        for j in range(30):
            lcm._atomic_write_text(fp, 't%d.%d ' % (k, j) + 'x' * 200)
    except Exception as e:
        errs.append(repr(e))
ts = [threading.Thread(target=hammer, args=(k,)) for k in range(24)]
for t in ts: t.start()
for t in ts: t.join()
left = [f for f in os.listdir(d) if '.tmp' in f]
assert not errs and not left and len(open(fp).read()) > 100, (errs[:2], left)
print('OK')
PYU1
if grep -q '^OK' "$F/u1.out"; then
    ok "U1: _atomic_write_text: 24 потока × 30 записей — 0 исключений, tmp не залипают (K54-2)"
else
    bad "U1: $(tail -1 "$F/u1.out")"
fi

# U2 (FB-52/N54-3): _write_enabled — параллельные переключения, права 0755.
python3 - "$K" > "$F/u2.out" 2>&1 <<'PYU2'
import sys, os, importlib.util, tempfile, threading, stat
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
d = tempfile.mkdtemp(prefix='kzu2_')
scripts = {}
for i in range(4):
    sp = os.path.join(d, 'S99svc%d' % i)
    open(sp, 'w').write('#!/bin/sh\nENABLED=yes\nPROCS=svc%d\n' % i)
    os.chmod(sp, 0o755)
    scripts['svc%d' % i] = sp
g.SERVICE_SCRIPTS = scripts
def toggle(i):
    for j in range(15):
        g._write_enabled('svc%d' % i, (j % 2 == 0))
ts = [threading.Thread(target=toggle, args=(i,)) for i in range(4)]
for t in ts: t.start()
for t in ts: t.join()
modes = {oct(stat.S_IMODE(os.stat(sp).st_mode)) for sp in scripts.values()}
heads = {open(sp).read().splitlines()[1].split('=')[0] for sp in scripts.values()}
left = [f for f in os.listdir(d) if '.tmp' in f]
assert modes == {'0o755'} and heads == {'ENABLED'} and not left, (modes, heads, left)
print('OK')
PYU2
if grep -q '^OK' "$F/u2.out"; then
    ok "U2: _write_enabled: 4×15 параллельных переключений — права 0755, без tmp-остатков (N54-3)"
else
    bad "U2: $(tail -1 "$F/u2.out")"
fi

# U3 (FB-53/N54-4): без кредов — 401 без счётчика; неверные креды — 429.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/u3.out" 2>&1 <<'PYU3'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
noauth = [c.get('/').status_code for _ in range(7)]
wrong = [c.get('/', auth=('a', 'nope')).status_code for _ in range(7)]
good = c.get('/', auth=('a', 'b')).status_code
assert noauth == [401] * 7, noauth
assert wrong[:5] == [401] * 5 and 429 in wrong[5:], wrong
assert good == 200, good
print('OK')
PYU3
    if grep -q '^OK' "$F/u3.out"; then
        ok "U3: вход: 7 без Authorization — все 401; неверные креды — 429; верный пароль — 200 (N54-4)"
    else
        bad "U3: $(tail -1 "$F/u3.out")"
    fi
else
    grep -q 'elif auth is None:' "$GEN" \
        && ok "U3: [частично, без flask] ветка «без кредов» на месте (N54-4)" \
        || bad "U3: нет ветки FB-53 (N54-4)"
fi

# U4 (FB-54/N54-2): флаг hysteria в needs_key и require_auth в placeholders.
U4="$F/u4"; mkdir -p "$U4"
printf '{ "server": "real.example.org:443", "tcpRedirect": {}, "udpTProxy": {} }\n' > "$U4/c6.json"
printf '{ "outbounds": [{ "protocol": "vless", "settings": { "vnext": [{ "address": "real.example.org", "users": [{ "id": "11111111-2222-3333-4444-555555555555" }] }] } }] }\n' > "$U4/vless.json"
awk 'index($0, "_nk_root_two() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$U4/nk.sh"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$U4/nk.sh"
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$U4/nk.sh"
U4B=""
(
    . "$U4/nk.sh"
    needs_key "$U4/c6.json" hysteria || exit 1
    needs_key "$U4/c6.json" && exit 2
    needs_key "$U4/vless.json" && exit 3
    exit 0
) || U4B="$U4B needs_key(rc=$?)"
python3 - "$K" > "$F/u4py.out" 2>&1 <<'PYU4'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('u', K + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
assert u.config_has_placeholders('/tmp/f47chk/u4/c6.json',
                                 require_auth=True) is True
assert u.config_has_placeholders('/tmp/f47chk/u4/c6.json') is False
assert u.config_has_placeholders('/tmp/f47chk/u4/vless.json') is False
print('OK')
PYU4
grep -q '^OK' "$F/u4py.out" || U4B="$U4B py:$(tail -1 "$F/u4py.out")"
if [ -z "$U4B" ]; then
    ok "U4: needs_key c флагом hysteria и placeholders(require_auth): auth отсутствует = «ключ не задан»; xray/vless не задет (N54-2)"
else
    bad "U4:$U4B"
fi

# U5: маркеры правок аудита-29 на местах.
U5B=""
grep -q 'FB-52 (аудит-29' "$K/opt/etc/bot/lists_core.py" || U5B="$U5B FB-52(lists_core)"
grep -q 'FB-52 (аудит-29' "$GEN" || U5B="$U5B FB-52(gen)"
grep -q 'N54-3' "$GEN" || U5B="$U5B FB-52(_write_enabled)"
grep -q 'FB-53 (аудит-29' "$GEN" || U5B="$U5B FB-53(gen)"
grep -q 'FB-54 (аудит-29' "$DEP" || U5B="$U5B FB-54(dep)"
grep -q 'FB-54 (аудит-29' "$K/opt/etc/bot/utils.py" || U5B="$U5B FB-54(utils)"
if [ -z "$U5B" ]; then
    ok "U5: маркеры FB-52/FB-53/FB-54 во всех правленых файлах (lists_core, generator, deploy, utils)"
else
    bad "U5: отсутствуют:$U5B"
fi

# ═══ V. Аудит-30: согласие HTTP-фида, честная сводка, дедуп, вердикты ═══
echo "═══ V. Аудит-30 (живая установка r55): согласие, честность, дедуп ═══"

# V0 (FB-55): tty-согласие в гейте — не-tty fail-closed, pty y/n/EOF.
V0="$F/v0"; mkdir -p "$V0"
extract_fn _kz_http_feed_active "$DEP" > "$V0/gate.sh"
extract_fn _kz_http_install_gate "$DEP" >> "$V0/gate.sh"
# FB-132 (r71): гейт читает ответ через kz_read_answer — нужен в драйвере
extract_fn kz_read_answer "$DEP" >> "$V0/gate.sh"
awk 'index($0, "warn() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$V0/gate.sh"
cat > "$V0/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/v0/gate.sh
_KZ_HTTP_FEED_ASKED=0
_KZ_HTTP_FEED_CONSENT=0
export KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/v0/conf
_kz_http_install_gate pkg-one; echo "RC1=$?"
_kz_http_install_gate pkg-two; echo "RC2=$?"
EOF
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\n' > "$V0/conf"
V0B=""
_o=$(sh "$V0/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'RC1=1' && printf '%s' "$_o" | grep -q 'RC2=1' \
    || V0B="$V0B notty-rc"
printf '%s' "$_o" | grep -q 'Ответ' && V0B="$V0B notty-вопрос"
if command -v script >/dev/null 2>&1; then
    _o=$(printf 'y\n' | script -qec "sh $V0/drv.sh" /dev/null 2>&1 | tr -d '\r')
    printf '%s' "$_o" | grep -q 'RC1=0' && printf '%s' "$_o" | grep -q 'RC2=0' \
        || V0B="$V0B yes-rc"
    [ "$(printf '%s' "$_o" | grep -c 'Ответ \[y/N\]')" = 1 ] || V0B="$V0B yes-вопросов-не-1"
    _o=$(printf 'n\n' | script -qec "sh $V0/drv.sh" /dev/null 2>&1 | tr -d '\r')
    printf '%s' "$_o" | grep -q 'RC1=1' && printf '%s' "$_o" | grep -q 'RC2=1' \
        || V0B="$V0B no-rc"
    [ "$(printf '%s' "$_o" | grep -c 'Ответ \[y/N\]')" = 1 ] || V0B="$V0B no-вопросов-не-1"
    _o=$(script -qec "sh $V0/drv.sh" /dev/null </dev/null 2>&1 | tr -d '\r')
    printf '%s' "$_o" | grep -q 'RC1=1' || V0B="$V0B eof-rc"
else
    grep -q '_KZ_HTTP_FEED_ASKED' "$DEP" || V0B="$V0B нет-ветки-согласия"
fi
if [ -z "$V0B" ]; then
    ok "V0: HTTP-гейт: не-tty rc1 без вопроса; pty «y»→0 «n»/EOF→1; вопрос один раз за прогон (FB-55)"
else
    bad "V0:$V0B"
fi

# V1 (FB-56): _kz_required_missing — факт вместо «Пакеты уже стоят».
V1="$F/v1"; mkdir -p "$V1/bin"
extract_fn _kz_pkg_installed "$DEP" > "$V1/rm.sh"
extract_fn _kz_required_missing "$DEP" >> "$V1/rm.sh"
grep '^KZ_PKG_REQUIRED=' "$DEP" > "$V1/req.sh"
cat > "$V1/bin/opkg" <<'EOF'
#!/bin/sh
case "$1" in list-installed) cat /tmp/f47chk/v1/installed.txt;; esac
exit 0
EOF
chmod +x "$V1/bin/opkg"
V1B=""
printf 'curl - 1\ntor - 1\nca-bundle - 1\n' > "$V1/installed.txt"
_m=$(PATH="$V1/bin:/usr/bin:/bin" sh -c ". '$V1/req.sh'; . '$V1/rm.sh'; _kz_required_missing")
[ -n "$_m" ] || V1B="$V1B пустой-список-при-частичной"
: > "$V1/installed.txt"
_m=$(PATH="$V1/bin:/usr/bin:/bin" sh -c ". '$V1/req.sh'; . '$V1/rm.sh'; _kz_required_missing")
[ "$(printf '%s' "$_m" | wc -w)" = 23 ] || V1B="$V1B полный=$(printf '%s' "$_m" | wc -w)"
printf 'tor - 1\ncurl - 1\nca-bundle - 1\nca-certificates - 1\nwget-ssl - 1\ntor-geoip - 1\nbind-dig - 1\ncron - 1\ndnsmasq-full - 1\nipset - 1\niptables - 1\nobfs4 - 1\nshadowsocks-libev-ss-redir - 1\nshadowsocks-libev-config - 1\nxray - 1\ntrojan - 1\ncoreutils-split - 1\nunzip - 1\npython3-pip - 1\npython3-requests - 1\npython3-markupsafe - 1\npython3-setuptools - 1\npython3-openssl - 1\n' > "$V1/installed.txt"
_m=$(PATH="$V1/bin:/usr/bin:/bin" sh -c ". '$V1/req.sh'; . '$V1/rm.sh'; _kz_required_missing")
[ -z "$_m" ] || V1B="$V1B непусто-при-полной:[$_m]"
grep -q 'установлены НЕ все' "$DEP" || V1B="$V1B нет-списка-недостающих"
grep -q 'Пакеты бутстрапа HTTPS не установлены' "$DEP" || V1B="$V1B нет-честного-вердикта-провала"
if [ -z "$V1B" ]; then
    ok "V1: _kz_required_missing: полная/частичная/пустая укомплектованность (23 позиции с wget-ssl); сводка честная; провал бутстрапа — вердикт факта (FB-56+FB-78)"
else
    bad "V1:$V1B"
fi

# V2 (FB-57): дедуп сводки пропусков.
V2="$F/v2"; mkdir -p "$V2"
extract_fn _kz_skip_note "$DEP" > "$V2/sn.sh"
_o=$(PATH=/usr/bin:/bin sh -c ". '$V2/sn.sh'; SKIPPED_HTTP=''; _kz_skip_note dnsmasq-full; _kz_skip_note curl; _kz_skip_note dnsmasq-full; _kz_skip_note xray; printf '%s' \"\$SKIPPED_HTTP\"")
if [ "$_o" = " dnsmasq-full curl xray" ]; then
    ok "V2: _kz_skip_note: dnsmasq-full дважды → одна запись в сводке (FB-57)"
else
    bad "V2: [$_o]"
fi

# V3 (FB-58): вердикты по бинарнику; ps-матчер без самосопоставления.
V3B=""
grep -A5 'ss-redir)' "$DEP" | grep -q 'have_cmd ss-redir' || V3B="$V3B ss-redir"
grep -A5 'trojan)' "$DEP" | grep -q 'have_cmd trojan' || V3B="$V3B trojan"
grep -q 'ставится с GitHub — шаг \[7/11\]' "$DEP" || V3B="$V3B hysteria-формулировка"
grep -q 'ps | grep -q "\[p\]ython3.\*\[m\]ain.py"' "$DEP" || V3B="$V3B ps-main"
grep -q 'ps | grep -q "\[p\]ython3.\*\[g\]enerator.py"' "$DEP" || V3B="$V3B ps-generator"
if ps | grep -q '[p]ython3.*[m]ain.py'; then
    V3B="$V3B ps-паттерн-ложный-позитив (в стенде нет python3-бота)"
fi
if [ -z "$V3B" ]; then
    ok "V3: вердикты ss-redir/trojan по have_cmd; hysteria — «GitHub [7/11]»; ps-матчер [p]-трюк без самосопоставления (FB-58)"
else
    bad "V3:$V3B"
fi

# V4: маркеры аудита-30 на местах.
V4B=""
grep -q 'FB-55 (аудит-30' "$DEP" || V4B="$V4B FB-55"
grep -q 'FB-56 (аудит-30' "$DEP" || V4B="$V4B FB-56"
grep -q 'FB-57 (аудит-30' "$DEP" || V4B="$V4B FB-57"
grep -q 'FB-58 (аудит-30' "$DEP" || V4B="$V4B FB-58"
if [ -z "$V4B" ]; then
    ok "V4: маркеры FB-55..FB-58 в deploy_bypass.sh"
else
    bad "V4: отсутствуют:$V4B"
fi

# ═══ W. Аудит-34: авто-бутстрап HTTPS (FB-78) и DNS Override (FB-79) ═══
echo "═══ W. Аудит-34: авто-бутстрап HTTPS фида + dns-override по согласию ═══"

W0="$F/w0"; mkdir -p "$W0/bin"
for _wfn in warn have_cmd _entware_stock_feeds _entware_feed_base \
    _entware_probe_feed_url _entware_prepare_candidate \
    _kz_pkg_installed _kz_pkg_cache_note _kz_http_feed_active \
    _kz_bootstrap_missing _kz_iso_conf_write \
    _kz_iso_opkg_update_install _kz_bootstrap_rollback \
    _kz_https_bootstrap_try _kz_https_bootstrap \
    _kz_http_install_gate; do
    extract_fn "$_wfn" "$DEP" >> "$W0/bs.sh"
    echo >> "$W0/bs.sh"
done
grep -q '^_kz_https_bootstrap() {' "$W0/bs.sh" || bad "W0: экстракция блока бутстрапа не удалась"
grep '^KZ_PKG_REQUIRED=' "$DEP" > "$W0/req.sh"
# K60-01 (аудит-35): вызовы opkg идут с -f <изолированный conf> —
# мок различает основной и изолированный конфиги (journal пишет
# полный вызов; update-решение — по conf кандидата)
cat > "$W0/bin/opkg" <<'EOF'
#!/bin/sh
echo "opkg $*" >> /tmp/f47chk/w0/journal
CONF="${KZ_DEPLOY_OPKG_CONF:-/tmp/f47chk/w0/opkg.conf}"
while [ $# -gt 0 ]; do
  case "$1" in
    -f) CONF="$2"; shift 2 ;;
    update|install|list-installed) break ;;
    *) shift ;;
  esac
done
case "${1:-}" in
  update)
    [ -f /tmp/f47chk/w0/update_fails ] && exit 1
    if grep -q 'https://' "$CONF" 2>/dev/null \
        && { [ -f /tmp/f47chk/w0/update_https_fails ] \
             || ! grep -q '^wget-ssl' /tmp/f47chk/w0/installed.txt 2>/dev/null; }; then
        exit 1
    fi
    exit 0 ;;
  install)
    printf 'curl - 1\nca-bundle - 1\nca-certificates - 1\nwget-ssl - 1\n' >> /tmp/f47chk/w0/installed.txt
    exit 0 ;;
  list-installed) cat /tmp/f47chk/w0/installed.txt 2>/dev/null; exit 0 ;;
esac
exit 0
EOF
chmod +x "$W0/bin/opkg"
cat > "$W0/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/w0/req.sh
. /tmp/f47chk/w0/bs.sh
KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/w0/opkg.conf
DL_CMD=""
ENTWARE_MIRRORS="https://bin.entware.net https://mirrors.bfsu.edu.cn/entware"
_ENTWARE_BASE_REQUESTED=""
export KZ_DEPLOY_OPKG_CONF DL_CMD ENTWARE_MIRRORS _ENTWARE_BASE_REQUESTED
ENTWARE_BASE=""
PATH="/tmp/f47chk/w0/bin:/usr/bin:/bin"; export PATH
_kz_https_bootstrap
_kz_http_install_gate probe-pkg && echo "GATE=PASS" || echo "GATE=SKIP"
echo "CONSENT=${_KZ_HTTP_FEED_CONSENT:-0}"
EOF
chmod +x "$W0/drv.sh"
w0reset() {
    rm -f "$W0/journal" "$W0/update_fails" "$W0/update_https_fails" "$W0/opkg.conf.bak-keenzoo"
    : > "$W0/installed.txt"
    printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc/gz keendev http://bin.entware.net/aarch64-k3.10/keenetic\nsrc custom http://third.party/feed\n' > "$W0/opkg.conf"
    cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
}

# W0 (FB-78): pty — авто-бутстрап БЕЗ вопроса: 4 пакета → флип → контроль.
# Ввод: пустая строка — бутстрап не спрашивает ничего, а гейт FB-55 про
# остаточный сторонний http-фид спрашивает отдельно и получает отказ.
w0reset
_o=$(printf '\n' | script -qec "sh $W0/drv.sh" /dev/null 2>&1 | tr -d '\r')
W0B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W0B="$W0B появился-вопрос"
printf '%s' "$_o" | grep -q 'Разрешить сетевые установки из HTTP-фида' || W0B="$W0B гейт-не-спросил-про-остаточные"
printf '%s' "$_o" | grep -q 'Пакеты бутстрапа HTTPS установлены (текущий фид)' || W0B="$W0B нет-установки-4"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W0B="$W0B нет-флипа"
# FB-72 (аудит-33): остаточный сторонний http-фид не подпадает под
# авто-бутстрап — гейт для него закрыт, предупреждение напечатано.
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W0B="$W0B гейт-открыт-для-остаточных"
printf '%s' "$_o" | grep -q 'CONSENT=0' || W0B="$W0B согласие-появилось"
printf '%s' "$_o" | grep -q 'остаются сторонние HTTP-фиды' || W0B="$W0B нет-предупреждения-об-остаточных"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W0B="$W0B install-не-4-изолированно"
# K60-01: индекс (1) и контроль флипа (3) — оба изолированным conf
[ "$(grep -cE '^opkg -f [^ ]+ update$' "$W0/journal")" = 2 ] || W0B="$W0B iso-update-не-2 (индекс+контроль)"
grep -q '^opkg update$' "$W0/journal" && W0B="$W0B основной-update-при-iso"
grep -q '^src/gz entware https://bin.entware.net/aarch64-k3.10$' "$W0/opkg.conf" || W0B="$W0B entware-не-флип"
grep -q '^src/gz keendev https://bin.entware.net/aarch64-k3.10/keenetic$' "$W0/opkg.conf" || W0B="$W0B keendev-subpath-потерян"
grep -q '^src custom http://third.party/feed$' "$W0/opkg.conf" || W0B="$W0B custom-тронут"
[ -f "$W0/opkg.conf.bak-keenzoo" ] || W0B="$W0B нет-бэкапа"
if [ -z "$W0B" ]; then
    ok "W0: авто-бутстрап pty: БЕЗ вопроса — 4 пакета → флип entware|keendev (subpath/custom целы) → контрольные iso-update ×2; основной opkg update остаётся шагу [1/11]; остаточный сторонний http-фид — гейт закрыт + предупреждение (FB-78+FB-72+K60-01)"
else
    bad "W0:$W0B"
fi

# W1 (FB-78): не-tty — бутстрап выполняется полностью (авто-режим).
w0reset
_o=$(sh "$W0/drv.sh" </dev/null 2>&1)
W1B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W1B="$W1B появился-вопрос"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W1B="$W1B нет-флипа"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W1B="$W1B нет-установки"
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W1B="$W1B гейт-пропустил-остаточные"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" && W1B="$W1B conf-не-флипнут"
if [ -z "$W1B" ]; then
    ok "W1: авто-бутстрап не-tty: полный переход без вопросов и согласий (FB-78; прежде не-tty — fail-closed по каждому пакету)"
else
    bad "W1:$W1B"
fi

# W2 (FB-78): pty с «n» — вопроса нет, ввод не влияет.
w0reset
_o=$(printf 'n\n' | script -qec "sh $W0/drv.sh" /dev/null 2>&1 | tr -d '\r')
W2B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W2B="$W2B появился-вопрос"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W2B="$W2B нет-флипа"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W2B="$W2B нет-установки"
if [ -z "$W2B" ]; then
    ok "W2: авто-бутстрап pty «n»: вопрос не задаётся — ответ не влияет (FB-78)"
else
    bad "W2:$W2B"
fi

# W3 (FB-78): env=1 не-tty — бутстрап тот же; env открывает гейт остаточным.
w0reset
_o=$(KEENZOO_ALLOW_HTTP_FEED=1 sh "$W0/drv.sh" </dev/null 2>&1)
W3B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W3B="$W3B появился-вопрос"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W3B="$W3B нет-флипа"
printf '%s' "$_o" | grep -q 'GATE=PASS' || W3B="$W3B гейт-не-открыт-env"
grep -qE '^opkg -f [^ ]+ update$' "$W0/journal" || W3B="$W3B нет-изолированного-update"
if [ -z "$W3B" ]; then
    ok "W3: env=1 не-tty: бутстрап тот же автоматический; env открывает гейт для остаточных http-установок (FB-78)"
else
    bad "W3:$W3B"
fi

# W4 (FB-84, аудит-35/R60-02): https-фид — равноправен: (a) без
# транспорта (мок https-update требует wget-ssl) пакеты не ставятся,
# но фид остаётся https, conf/bak не трогаются, основной update
# шага [1/11] сам разберётся; (b) с укомплектованным транспортом —
# тихо: ничего не флипает, журнал без установок. Пробы зеркал
# замокаены rc 2 (нет curl — «не проверено») для детерминизма.
cat > "$W0/drv4.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/w0/req.sh
. /tmp/f47chk/w0/bs.sh
KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/w0/opkg.conf
DL_CMD=""
ENTWARE_MIRRORS="https://bin.entware.net https://mirrors.bfsu.edu.cn/entware"
_ENTWARE_BASE_REQUESTED=""
export KZ_DEPLOY_OPKG_CONF DL_CMD ENTWARE_MIRRORS _ENTWARE_BASE_REQUESTED
ENTWARE_BASE=""
PATH="/tmp/f47chk/w0/bin:/usr/bin:/bin"; export PATH
_entware_probe_feed_url() { return 2; }
_kz_https_bootstrap
echo "ENTWARE_BASE=$ENTWARE_BASE"
EOF
chmod +x "$W0/drv4.sh"
w0reset
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$W0/opkg.conf"
cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
_o=$(sh "$W0/drv4.sh" </dev/null 2>&1)
W4B=""
printf '%s' "$_o" | grep -q 'не установлены' || W4B="$W4B нет-вердикта-без-транспорта"
grep -qE '^opkg -f [^ ]+ install ' "$W0/journal" && W4B="$W4B установка-без-транспорта"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W4B="$W4B conf-тронут"
[ -f "$W0/opkg.conf.bak-keenzoo" ] && W4B="$W4B лишний-бэкап"
w0reset
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$W0/opkg.conf"
cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
printf 'curl - 1\nca-bundle - 1\nca-certificates - 1\nwget-ssl - 1\n' > "$W0/installed.txt"
_o=$(sh "$W0/drv4.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'не установлены' && W4B="$W4B ложный-вердикт-при-укомплектованном"
grep -qE '^opkg -f [^ ]+ (install|update)' "$W0/journal" && W4B="$W4B лишние-вызовы-при-укомплектованном"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W4B="$W4B conf-тронут-при-укомплектованном"
[ -f "$W0/opkg.conf.bak-keenzoo" ] && W4B="$W4B лишний-бэкап-при-укомплектованном"
printf '%s' "$_o" | grep -q 'ENTWARE_BASE=https://bin.entware.net$' || W4B="$W4B base-не-зафиксирован-при-укомплектованном"
if [ -z "$W4B" ]; then
    ok "W4: https-фид (FB-84/R60-02): без транспорта — честный вердикт «не установлены», conf/bak не тронуты; укомплектованный — тихо, без флипа/бэкапа; прежде ранний return не ставил пакеты вовсе"
else
    bad "W4:$W4B"
fi

# W5 (FB-78): OFFLINE — бутстрап пропущен даже с env-разрешением.
w0reset
_o=$(KEENZOO_ALLOW_HTTP_FEED=1 KEENZOO_OPKG_OFFLINE=1 sh "$W0/drv.sh" </dev/null 2>&1)
if ! printf '%s' "$_o" | grep -q 'переведены' && [ ! -f "$W0/journal" ] \
    && cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig"; then
    ok "W5: KEENZOO_OPKG_OFFLINE=1: бутстрап пропущен целиком (FB-78)"
else
    bad "W5: offline-не-учтён"
fi

# W6 (FB-78): провалы — мёртвый фид (все update) и контрольный update
# флипа (https падает при состоявшейся установке): байт-точные откаты.
w0reset
: > "$W0/update_fails"
_o=$(sh "$W0/drv.sh" </dev/null 2>&1)
W6B=""
printf '%s' "$_o" | grep -q 'Пакеты бутстрапа HTTPS не установлены' || W6B="$W6B нет-вердикта-провала"
grep -q '^opkg install' "$W0/journal" && W6B="$W6B установка-при-мёртвом-фиде"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W6B="$W6B conf-тронут-при-провале"
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W6B="$W6B гейт-открыт-при-провале"
w0reset
: > "$W0/update_https_fails"
_o=$(sh "$W0/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'Контрольный opkg update по HTTPS не прошёл' || W6B="$W6B нет-текста-отката-флипа"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W6B="$W6B установка-не-выполнена"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W6B="$W6B флип-не-откачен-байт-в-байт"
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W6B="$W6B гейт-открыт-после-отката-флипа"
if [ -z "$W6B" ]; then
    ok "W6: провалы авто-бутстрапа: мёртвый фид → вердикт + ноль установок, conf цел; провал контрольного https-update → установка состоялась, флип откачен байт-в-байт; гейт всюду закрыт (FB-78)"
else
    bad "W6:$W6B"
fi

# W7 (FB-79): dns-override не-tty — без вопросов и без действий.
W7="$F/w7"; mkdir -p "$W7/bin"
for _wfn in warn have_cmd kz_read_answer _kz_pkg_installed _kz_required_missing \
    _kz_dns_live _kz_dns_override_state _kz_dns_override_off \
    _kz_dns_override_on _kz_dns_override_enable \
    _kz_dns_override_disable _kz_dns_self_revert \
    _kz_dns_override_step _kz_resolver_finalize; do
    extract_fn "$_wfn" "$DEP" >> "$W7/dns.sh"
    echo >> "$W7/dns.sh"
done
grep '^KZ_PKG_REQUIRED=' "$DEP" > "$W7/req.sh"
cat > "$W7/bin/ndmc" <<'EOF'
#!/bin/sh
echo "ndmc $*" >> /tmp/f47chk/w7/journal
case "$*" in
  *'show running-config'*)
    # FB-104 (аудит-38): реальный ndmc печатает КОНФИГ всегда —
    # пустой вывод = UNKNOWN (нет ndmc/отказ), а не «выключен»
    echo 'interface Bridge0'
    [ "$(cat /tmp/f47chk/w7/state 2>/dev/null)" = on ] && echo 'opkg dns-override'
    ;;
  *'no opkg dns-override'*) echo off > /tmp/f47chk/w7/state ;;
  *'opkg dns-override'*) echo on > /tmp/f47chk/w7/state ;;
esac
exit 0
EOF
cat > "$W7/bin/pidof" <<'EOF'
#!/bin/sh
[ "$(cat /tmp/f47chk/w7/pidof_mode 2>/dev/null)" = alive ] && echo 4242
exit 0
EOF
cat > "$W7/bin/opkg" <<'EOF'
#!/bin/sh
case "${1:-}" in list-installed) cat /tmp/f47chk/w7/installed.txt 2>/dev/null;; esac
exit 0
EOF
chmod +x "$W7/bin/"*
cat > "$W7/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/w7/req.sh
. /tmp/f47chk/w7/dns.sh
PATH="/tmp/f47chk/w7/bin:/usr/bin:/bin"; export PATH
W_ENSURE=0
ensure_local_resolver() { W_ENSURE=$((W_ENSURE + 1)); }
dns_ok() { return 0; }
# FB-71: проба 127.0.0.1 тестируется отдельно (Y4); здесь —
# штатное «резолвер жив», чтобы W7 остался про dns-override-шаг.
_kz_dns_probe_local() { return 0; }
DNS_OVERRIDE_OK=7
_kz_dns_override_step
echo "STEP_OK=${DNS_OVERRIDE_OK}"
_kz_resolver_finalize
echo "ENSURE=$W_ENSURE"
EOF
chmod +x "$W7/drv.sh"
w7run() {
    rm -f "$W7/journal"
    echo "$1" > "$W7/state"
    echo "$2" > "$W7/pidof_mode"
    : > "$W7/installed.txt"
}
w7run on alive
_o=$(sh "$W7/drv.sh" </dev/null 2>&1)
W7B=""
printf '%s' "$_o" | grep -q 'DNS Override уже включён' || W7B="$W7B жив+вкл-не-распознан"
printf '%s' "$_o" | grep -q 'STEP_OK=1' || W7B="$W7B жив+вкл-не-подтверждён"
printf '%s' "$_o" | grep -q 'ENSURE=1' || W7B="$W7B жив-resolv-не-подключён"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W7B="$W7B лишний-enable"
w7run off alive
_o=$(sh "$W7/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'DNS Override не включён' || W7B="$W7B выкл+жив-подсказок-нет"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W7B="$W7B включение-без-согласия"
printf '%s' "$_o" | grep -q 'STEP_OK=0' || W7B="$W7B выкл+жив-OK-не-0"
printf '%s' "$_o" | grep -q 'ENSURE=0' || W7B="$W7B выкл+жив-resolv-тронут"
w7run off dead
_o=$(sh "$W7/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'DNS Override не включён' || W7B="$W7B выкл+мёртв-подсказок-нет"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W7B="$W7B мёртв-enable-вызван"
printf '%s' "$_o" | grep -q 'ENSURE=0' || W7B="$W7B мёртв-resolv-тронут"
if [ -z "$W7B" ]; then
    ok "W7: dns-override не-tty: вкл+жив→✅+resolv; выкл (жив/мёртв)→подсказки, ни ndmc, ни resolv.conf (FB-79)"
else
    bad "W7:$W7B"
fi

# W8 (FB-79): pty — согласие «y» (+S56-старт при мёртвом), отказ, откат заклинившего.
w7run off dead
_o=$(printf 'y\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
W8B=""
printf '%s' "$_o" | grep -q 'Включить DNS Override сейчас?' || W8B="$W8B нет-вопроса"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" || W8B="$W8B нет-enable"
# FB-82 (аудит-35, R60-01): dnsmasq не поднялся после включённого
# нами override — откат на системный DNS + подсказки (прежний текст
# «resolv.conf НЕ переключён» заменён откатом самого override)
printf '%s' "$_o" | grep -q 'DNS Override отключён: системный DNS Keenetic снова' || W8B="$W8B нет-отката-override"
grep -q 'ndmc -c no opkg dns-override$' "$W7/journal" || W8B="$W8B нет-no-override-в-откате"
printf '%s' "$_o" | grep -q 'STEP_OK=0' || W8B="$W8B OK-при-мёртвом-dnsmasq"
printf '%s' "$_o" | grep -q 'ENSURE=0' || W8B="$W8B resolv-всё-же-тронут"
w7run off alive
_o=$(printf 'y\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
printf '%s' "$_o" | grep -q 'dnsmasq работает на порту 53' || W8B="$W8B жив-не-подтверждён"
printf '%s' "$_o" | grep -q 'STEP_OK=1' || W8B="$W8B жив-OK-не-1"
printf '%s' "$_o" | grep -q 'ENSURE=1' || W8B="$W8B жив-resolv-не-подключён"
w7run off dead
_o=$(printf 'n\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W8B="$W8B enable-после-отказа"
printf '%s' "$_o" | grep -q 'DNS Override не включён' || W8B="$W8B отказ-без-подсказок"
w7run on dead
_o=$(printf 'y\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
printf '%s' "$_o" | grep -q 'резолвинг на роутере сейчас сломан' || W8B="$W8B нет-диагноза"
printf '%s' "$_o" | grep -q 'отключён: системный DNS Keenetic снова' || W8B="$W8B нет-отката"
[ "$(cat "$W7/state")" = off ] || W8B="$W8B state-не-off"
grep -q 'ndmc -c no opkg dns-override$' "$W7/journal" || W8B="$W8B нет-no-вызова"
if [ -z "$W8B" ]; then
    ok "W8: dns-override pty: «y»+мёртв→enable+попытка S56 (без /opt — честный OK=0, откат override через общий хелпер FB-92); «y»+жив→OK=1+resolv; «n»→подсказки; заклинивший+«y»→откат (FB-79/FB-92)"
else
    bad "W8:$W8B"
fi

# W9 (FB-78/FB-79/FB-80/FB-81): структурные маркеры аудита-34.
W9B=""
grep -q 'wget-ssl' "$DEP" || W9B="$W9B нет-wget-ssl"
[ "$(grep -c '_kz_https_bootstrap() {' "$DEP")" = 1 ] || W9B="$W9B нет-функции-бутстрапа"
[ "$(grep -c '_kz_https_bootstrap_try() {' "$DEP")" = 1 ] || W9B="$W9B нет-хелпера-try"
[ "$(grep -c '_kz_bootstrap_missing() {' "$DEP")" = 1 ] || W9B="$W9B нет-хелпера-missing"
[ "$(grep -c '_kz_dns_override_step() {' "$DEP")" = 1 ] || W9B="$W9B нет-шага-dns"
[ "$(grep -c '_kz_resolver_finalize() {' "$DEP")" = 1 ] || W9B="$W9B нет-финализатора"
grep -q 'FB-59 (аудит-31' "$DEP" || W9B="$W9B нет-маркера-FB-59"
grep -q 'FB-62 (аудит-31' "$DEP" || W9B="$W9B нет-маркера-FB-62"
for _w9m in 'FB-78 (аудит-34' 'FB-79 (аудит-34' 'FB-80 (аудит-34' 'FB-81 (аудит-34'; do
    grep -q "$_w9m" "$DEP" || W9B="$W9B нет-маркера-$_w9m"
done
grep -q 'KEENZOO_OPKG_OFFLINE:-0.*= 1.*&& return 0' "$DEP" || W9B="$W9B нет-offline-гейта-бутстрапа"
grep -q 'Для завершения установки перезагрузить роутер сейчас' "$DEP" || W9B="$W9B нет-reboot-запроса"
grep -q '/opt/etc/init.d/S56dnsmasq start' "$DEP" || W9B="$W9B нет-старта-S56-в-шаге-dns"
if [ -z "$W9B" ]; then
    ok "W9: маркеры FB-78/79/80/81 + FB-59/62, хелперы бутстрапа, S56-старт в шаге DNS, reboot-запрос, offline-гейт (структура)"
else
    bad "W9:$W9B"
fi

# ═══ X. Аудит-32: writers списков, панель, валидаторы, сироты ═══
echo "═══ X. Аудит-32 (отчёт r55): lock writers, 401-timing, паритет 15/15 ═══"

# X0 (FB-63): межпроцессный flock — 2 субпроцесса × 30 RMW-записей.
X0="$F/x0"; mkdir -p "$X0"
cat > "$X0/child.py" <<'EOF'
import sys
sys.path.insert(0, sys.argv[3])
import lists_core as lc
fp, tag = sys.argv[1], sys.argv[2]
for i in range(30):
    with lc._list_write_guard(fp):
        t = open(fp).read()
        lc._atomic_write_text(fp, t + '%s-%d.example\n' % (tag, i))
EOF
printf 'base.example\n' > "$X0/tr.txt"
python3 "$X0/child.py" "$X0/tr.txt" A "$K/opt/etc/bot" >/dev/null 2>&1 & X0P1=$!
python3 "$X0/child.py" "$X0/tr.txt" B "$K/opt/etc/bot" >/dev/null 2>&1 & X0P2=$!
wait "$X0P1"; X0R1=$?; wait "$X0P2"; X0R2=$?
X0A=$(grep -c '^A-' "$X0/tr.txt" || true)
X0B=$(grep -c '^B-' "$X0/tr.txt" || true)
grep -q '^base.example$' "$X0/tr.txt"; X0C=$?
if [ "$X0R1" = 0 ] && [ "$X0R2" = 0 ] && [ "$X0A" = 30 ] && [ "$X0B" = 30 ] \
    && [ "$X0C" = 0 ]; then
    ok "X0: _list_write_guard: 2 процесса × 30 RMW — 60/60 записей + база (flock сериализует; R55-01)"
else
    bad "X0: rc=$X0R1/$X0R2 A=$X0A/30 B=$X0B/30 base=$X0C"
fi

# X1 (FB-63): revision редактора — stale-вкладка получает конфликт.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x1.out" 2>&1 <<'PYX1'
import sys, os, re, importlib.util, tempfile, time
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzx1_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
g.BYPASS_FILES = {n: p for n, p in g.config.list_files.items() if n != 'bot'}
g.BOT_BYPASS_FILE = g.config.list_files['bot']
import lists_core
lists_core.UNBLOCK_DIR = tmp
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('base.example\n')
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/panel?tab=tr', auth=('a', 'b')).data.decode()
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
rev = re.search(r'name="rev"[^>]*value="([^"]+)"', html).group(1)
# FB-70 (аудит-33, K58-1): rev = SHA-256 байтов содержимого файла
import hashlib
assert rev == hashlib.sha256(
    open(g.config.list_files['trojan'], 'rb').read()).hexdigest(), rev
# «другой писатель» меняет файл после загрузки вкладки
with open(g.config.list_files['trojan'], 'a') as f:
    f.write('other-writer.example\n')
time.sleep(0.01)
r = c.post('/list/tr',
           data={'csrf_token': token, 'rev': rev,
                 'content': 'stale-tab.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302, r.status_code
text = open(g.config.list_files['trojan']).read()
assert 'stale-tab.example' not in text, 'stale-вкладка перезаписала чужую правку!'
assert 'other-writer.example' in text
# свежий rev — сохранение проходит
fresh = hashlib.sha256(
    open(g.config.list_files['trojan'], 'rb').read()).hexdigest()
r = c.post('/list/tr',
           data={'csrf_token': token, 'rev': fresh,
                 'content': 'base.example\nother-writer.example\nfresh-tab.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302
text = open(g.config.list_files['trojan']).read()
assert 'fresh-tab.example' in text and 'other-writer.example' in text
# FB-70 strict (аудит-33, K58-1): форма без rev при существующем
# непустом файле — КОНФЛИКТ (прежде «совместимость со старой
# вкладкой» молча затирала чужие правки)
r = c.post('/list/tr',
           data={'csrf_token': token,
                 'content': 'base.example\ncompat-tab.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302
assert 'compat-tab.example' not in open(
    g.config.list_files['trojan']).read(), 'no-rev сохранился — strict нарушен!'
print('X1 OK')
PYX1
    grep -q '^X1 OK' "$F/x1.out" \
        && ok "X1: редактор: rev=SHA-256; stale-rev → конфликт (чужая правка цела); свежий rev → сохранение; БЕЗ rev → конфликт strict (FB-63+FB-70/R55-01, K58-1)" \
        || bad "X1: $(tail -3 "$F/x1.out" | tr '\n' ' ')"
else
    ok "X1: [SKIP] flask не установлен — ревизия проверяется структурно в X8"
fi

# X2 (FB-64): 401 без задержки для отсутствующих кредов; неверные — с ней.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x2.out" 2>&1 <<'PYX2'
import sys, time, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
t0 = time.time()
r1 = c.get('/api/update-status')
dt1 = time.time() - t0
assert r1.status_code == 401, r1.status_code
t0 = time.time()
r2 = c.get('/api/update-status', auth=('a', 'WRONG'))
dt2 = time.time() - t0
assert r2.status_code == 401, r2.status_code
assert dt1 < 0.35, dt1
assert dt2 >= 0.45, dt2
print('X2 OK %.2f/%.2f' % (dt1, dt2))
PYX2
    grep -q '^X2 OK' "$F/x2.out" \
        && ok "X2: auth=None → 401 без sleep; неверные креды → с задержкой (FB-64/R55-02)" \
        || bad "X2: $(tail -3 "$F/x2.out" | tr '\n' ' ')"
else
    ok "X2: [SKIP] flask не установлен — гейт проверяется структурно в X8"
fi

# X3 (FB-65): 160 конкурентных _write_router_proto — 0 исключений.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x3.out" 2>&1 <<'PYX3'
import sys, os, importlib.util, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
tmp = tempfile.mkdtemp(prefix='kzx3_')
g.ROUTER_PROTO_FILE = os.path.join(tmp, 'router_proto')
errs = []
def w(i):
    try:
        g._write_router_proto('xray' if i % 2 else 'trojan')
    except Exception as e:
        errs.append(repr(e))
ts = [threading.Thread(target=w, args=(i,)) for i in range(160)]
for t in ts: t.start()
for t in ts: t.join()
val = open(g.ROUTER_PROTO_FILE).read().strip()
left = [f for f in os.listdir(tmp) if f.startswith('.router_proto.')]
assert not errs and val in ('xray', 'trojan') and not left, (len(errs), val, left)
print('X3 OK')
PYX3
    grep -q '^X3 OK' "$F/x3.out" \
        && ok "X3: _write_router_proto: 160 конкурентных — 0 ошибок, 0 tmp-остатков (было 25–46 FileNotFoundError; FB-65/R55-03)" \
        || bad "X3: $(tail -3 "$F/x3.out" | tr '\n' ' ')"
else
    ok "X3: [SKIP] flask не установлен — mkstemp проверяется структурно в X8"
fi

# X4 (FB-66): паритет 4 валидаторов hysteria — 15/15 (типы и маркеры).
X4="$F/x4"; mkdir -p "$X4"
awk '/^_nk_root_two\(\) \{/,/^\}$/' "$DEP" > "$X4/nk.sh"
# FB-89/FB-95/FB-111: needs_key зовёт kz_json_root_str через _nk_root_two
awk '/^needs_key\(\) \{/,/^\}$/' "$DEP" >> "$X4/nk.sh"
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$X4/nk.sh"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$X4/s57gate.sh"
# FB-89: гейт зовёт kz_json_root_str (common.sh)
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$X4/s57gate.sh"
python3 - "$K" "$X4" > "$F/x4.out" 2>&1 <<'PYX4'
import sys, os, json, tempfile, subprocess
K, X4 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import utils as u
def mk(cfg):
    fd, p = tempfile.mkstemp(suffix='.json'); os.close(fd)
    open(p, 'w').write(json.dumps(cfg)); return p
def nk(p):
    return subprocess.run(['sh', '-c', '. "$X4/nk.sh"; needs_key "$1" hysteria'.replace('$X4', X4),
                           'sh', p]).returncode
def pf(p):
    try:
        u._preflight_hysteria(p); return 'accept'
    except ValueError:
        return 'reject'
def s57(p):
    env = dict(os.environ, KEENZOO_HYSTERIA_CONFIG=p,
               KEENZOO_HYSTERIA_COMMON=K + '/opt/bin/common.sh',
               KEENZOO_HYSTERIA_PIDFILE=os.path.join(X4, 's57.pid'))
    r = subprocess.run(['sh', '-c', '. "' + X4 + '/s57gate.sh" 2>&1 | grep -q SKIPPED',
                        'sh', 'start'], env=env).returncode
    return r == 0
def cph(p):
    return 'reject' if u.config_has_placeholders(p, require_auth=True) else 'accept'
base = {"server": "real.example.org:443", "auth": "realkey",
        "tcpRedirect": {}, "udpTProxy": {}}
cases = []
c = mk({**base, "auth": 12345})
cases.append(('auth-число', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": "CHANGE_ME"})
cases.append(('server-CHANGE_ME', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk(base)
cases.append(('валидный', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "auth": "   "})
cases.append(('auth-пробелы: все принимают согласованно',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
# FB-96 (аудит-36, K61-03): auth — секрет, точный матч без
# host-нормализации: «change_me:443» — валидное значение
c = mk({**base, "auth": "change_me:443"})
cases.append(('auth-change_me:443 (валидный секрет)',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
# FB-97 (K61-04): дубликат корневого ключа — fail-closed у всех
# (json.dumps дубликаты не создаёт — файлы пишем вручную)
fdup, fdupn = tempfile.mkstemp(suffix='.json'); os.close(fdup)
open(fdupn, 'w').write('{ "server": "real.example.org:443", "auth": "a", "auth": "realkey" }')
cases.append(('дубликат auth — fail-closed', nk(fdupn) == 0, pf(fdupn) == 'reject',
              s57(fdupn), cph(fdupn) == 'reject'))
fdup2, fdup2n = tempfile.mkstemp(suffix='.json'); os.close(fdup2)
open(fdup2n, 'w').write('{ "server": "a.com", "server": "real.example.org:443", "auth": "realkey" }')
cases.append(('дубликат server — fail-closed', nk(fdup2n) == 0, pf(fdup2n) == 'reject',
              s57(fdup2n), cph(fdup2n) == 'reject'))
# FB-98 (K61-04b): маркер через \u-эскейп декодируется и ловится
fesc, fescn = tempfile.mkstemp(suffix='.json'); os.close(fesc)
open(fescn, 'w').write('{ "server": "real.example.org:443", "auth": "change\\u005fme" }')
cases.append(('auth через u-эскейп — заглушка', nk(fescn) == 0, pf(fescn) == 'reject',
              s57(fescn), cph(fescn) == 'reject'))
# вложенный tls.auth — корневым auth не является
c = mk({**base, "tls": {"auth": "change_me"}})
cases.append(('вложенный tls.auth не отменяет валидный root auth',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "server": "   "})
cases.append(('server-пробелы: все принимают согласованно',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "auth": "CHANGE_ME"})
cases.append(('auth-CHANGE_ME', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
# FB-74 (аудит-33, K58-2/R58-05): server-заглушка example.com —
# прежде preflight пропускал; нормализация: порт/регистр/конечная
# точка/нестроковое значение. sni-исключение (FB-31) — сохранено.
c = mk({**base, "server": "example.com:443"})
cases.append(('server-example.com:443', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": "EXAMPLE.com:443"})
cases.append(('server-EXAMPLE.com (регистр)', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": "example.com."})
cases.append(('server-example.com. (FQDN-точка)', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": 123})
cases.append(('server-число', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "tls": {"sni": "example.com"}})
cases.append(('sni-example.com: легальная маскировка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
# FB-89 (аудит-35, R59-04/K60-04): точечный матч (не substring) и
# регистронезависимые auth-маркеры; вложенный tls.server — маскировка
c = mk({**base, "server": "fooexample.com"})
cases.append(('server-fooexample.com: не заглушка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "server": "sub.example.com"})
cases.append(('server-sub.example.com: не заглушка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "auth": "change_me"})
cases.append(('auth-change_me (регистр)', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "tls": {"server": "example.com"}})
cases.append(('вложенный tls.server=example.com: маскировка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
for name, a, b, cc, d in cases:
    assert a and b and cc and d, (name, a, b, cc, d)
print('X4 OK %d кейсов' % len(cases))
PYX4
grep -q '^X4 OK' "$F/x4.out" \
    && ok "X4: hysteria-валидаторы: auth-число/CHANGE_ME/change_me/пробелы, server-CHANGE_ME/example.com (порт, регистр, точка, число) — rej; fooexample/sub.example/sni/tls.server-маскировка — accept; единый вердикт у всех 4 (FB-66+FB-74+FB-89)" \
    || bad "X4: $(tail -3 "$F/x4.out" | tr '\n' ' ')"

# X5 (FB-67): возрастная уборка сирот lists_core.
X5="$F/x5"; mkdir -p "$X5"
python3 - "$K" "$X5" > "$F/x5.out" 2>&1 <<'PYX5'
import sys, os, time, tempfile
K, X5 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import lists_core as lc
fp = os.path.join(X5, 'tr.txt')
open(fp, 'w').write('base.example\n')
old = os.path.join(X5, '.tr.txt.orphan.tmp')
open(old, 'w').write('x')
os.utime(old, (time.time() - 7200, time.time() - 7200))
fresh = os.path.join(X5, '.tr.txt.fresh.tmp')
open(fresh, 'w').write('y')
lc._atomic_write_text(fp, open(fp).read() + 'more.example\n')
assert not os.path.exists(old), 'сирота не убран'
assert os.path.exists(fresh), 'свежий tmp тронут!'
assert 'more.example' in open(fp).read()
print('X5 OK')
PYX5
grep -q '^X5 OK' "$F/x5.out" \
    && ok "X5: _atomic_write_text: сирота >1ч убран, свежий tmp активного writer'а цел (FB-67/R55-06)" \
    || bad "X5: $(tail -3 "$F/x5.out" | tr '\n' ' ')"

# X6 (FB-68): /api/cfg/<which> возвращает warnings (реюз keys_bridges_warnings).
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x6.out" 2>&1 <<'PYX6'
import sys, os, re, json, importlib.util, tempfile
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzx6_')
hy_path = os.path.join(tmp, 'hysteria.json')
g.config.paths['hysteria_config'] = hy_path
g.config.paths['hysteria_dir'] = tmp
g.config.paths['init_hysteria'] = os.path.join(tmp, 'no-init-script')
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/panel?tab=hy', auth=('a', 'b')).data.decode()
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
cfg = {"server": "real.example.org:443", "auth": "realkey",
       "tcpRedirect": {}, "udpTProxy": {}}
r = c.post('/api/cfg/hy',
           data={'csrf_token': token, 'content': json.dumps(cfg)},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 200, (r.status_code, r.data[:200])
j = r.get_json()
assert 'warnings' in j and isinstance(j['warnings'], list), j
print('X6 OK warnings=%r' % j['warnings'])
PYX6
    grep -q '^X6 OK' "$F/x6.out" \
        && ok "X6: /api/cfg: успешный ответ содержит warnings (JS-ветка j.warnings достижима; FB-68/R55-08)" \
        || bad "X6: $(tail -3 "$F/x6.out" | tr '\n' ' ')"
else
    ok "X6: [SKIP] flask не установлен — warnings проверяются структурно в X8"
fi

# X7 (FB-69): check_failed читается ботом (структурно + producer).
X7B=""
grep -q "check_failed" "$K/opt/etc/bot/handlers.py" || X7B="$X7B handlers-не-читает"
grep -q 'Проверка обновлений не завершена' "$K/opt/etc/bot/handlers.py" \
    || X7B="$X7B нет-честного-текста"
grep -q 'check_failed' "$K/opt/bin/check_updates.sh" || X7B="$X7B producer-без-поля"
if [ -z "$X7B" ]; then
    ok "X7: бот: check_failed из статуса → «⚠️ Проверка не завершена» вместо «✅ Всё актуально» (FB-69/R54-04)"
else
    bad "X7:$X7B"
fi

# X8: структурные маркеры FB-63..FB-69.
X8B=""
grep -q '_list_write_guard' "$K/opt/etc/bot/lists_core.py" || X8B="$X8B нет-guard"
grep -q '_list_write_guard' "$K/opt/etc/bot/generator.py" || X8B="$X8B guard-не-в-generator"
grep -q 'name="rev"' "$GEN" || X8B="$X8B нет-rev-поля"
grep -q 'if auth is not None:' "$GEN" || X8B="$X8B нет-гейта-sleep"
grep -q '_ROUTER_PROTO_LOCK' "$GEN" || X8B="$X8B нет-lock-router-proto"
grep -q "change_me)" "$S57" || X8B="$X8B S57-без-change_me"
grep -q 'keys_bridges_warnings' "$GEN" || X8B="$X8B warnings-не-подключены"
grep -q 'FB-63 (аудит-32' "$K/opt/etc/bot/lists_core.py" || X8B="$X8B FB-63"
grep -q 'FB-64 (аудит-32' "$GEN" || X8B="$X8B FB-64"
grep -q 'FB-65 (аудит-32' "$GEN" || X8B="$X8B FB-65"
grep -q 'FB-66 (аудит-32' "$K/opt/etc/bot/utils.py" || X8B="$X8B FB-66(utils)"
grep -q 'FB-66 (аудит-32' "$S57" || X8B="$X8B FB-66(S57)"
grep -q 'FB-67 (аудит-32' "$K/opt/etc/bot/lists_core.py" || X8B="$X8B FB-67"
grep -q 'FB-68 (аудит-32' "$GEN" || X8B="$X8B FB-68"
grep -q 'FB-69 (аудит-32' "$K/opt/etc/bot/handlers.py" || X8B="$X8B FB-69"
if [ -z "$X8B" ]; then
    ok "X8: маркеры FB-63..FB-69, rev-поле, guard, lock, S57-change_me — на местах"
else
    bad "X8:$X8B"
fi

# ═══ Y. Аудит-33: атомарный rev, DNS-гейт, консент-фиды, статусы ═══
echo "═══ Y. Аудит-33 (отчёты r58): rev-атомарность, DNS-гейт, консент, частичный статус ═══"
CU="$K/opt/bin/check_updates.sh"
UPD="$K/opt/bin/update_protocols.sh"
UDNS="$K/opt/bin/unblock_dnsmasq.sh"

# Y0: структурные маркеры FB-70..FB-77 + гейты.
Y0B=""
grep -q 'FB-70 (аудит-33' "$K/opt/etc/bot/lists_core.py" || Y0B="$Y0B FB-70(lc)"
grep -q 'FB-70 (аудит-33' "$GEN" || Y0B="$Y0B FB-70(gen)"
grep -q 'ListRevisionConflict' "$GEN" || Y0B="$Y0B конфликт-класс-не-в-маршруте"
grep -q 'parse_and_save_if_revision' "$GEN" || Y0B="$Y0B маршрут-не-использует-caw"
grep -q 'FB-71 (аудит-33' "$DEP" || Y0B="$Y0B FB-71"
grep -q 'FB-72 (аудит-33' "$DEP" || Y0B="$Y0B FB-72"
grep -q 'FB-73 (аудит-33' "$CU" || Y0B="$Y0B FB-73"
grep -q 'd.check_failed' "$GEN" || Y0B="$Y0B панель-не-читает-check_failed"
grep -q 'Проверка неполная' "$CU" || Y0B="$Y0B TG-без-предупреждения"
grep -q 'FB-74 (аудит-33' "$K/opt/etc/bot/utils.py" || Y0B="$Y0B FB-74(utils)"
grep -q 'FB-74 (аудит-33' "$DEP" || Y0B="$Y0B FB-74(dep)"
grep -q 'FB-74 (аудит-33' "$S57" || Y0B="$Y0B FB-74(S57)"
grep -q 'FB-75 (аудит-33' "$DEP" || Y0B="$Y0B FB-75"
grep -q 'FB-76 (аудит-33' "$DEP" || Y0B="$Y0B FB-76"
grep -q 'DNS_OVERRIDE_OK' "$DEP" || Y0B="$Y0B нет-DNS-гейта-в-тексте"
grep -q 'KEENZOO_DLTMP должен быть абсолютным' "$DEP" || Y0B="$Y0B нет-DLTMP-отказа"
if [ -z "$Y0B" ]; then
    ok "Y0: маркеры FB-70..FB-76, конфликт-класс в маршруте, DNS-гейт, DLTMP-отказ — на местах"
else
    bad "Y0:$Y0B"
fi

# Y1 (FB-70): compare-and-write — семантика ревизий (unit).
Y1="$F/y1"; mkdir -p "$Y1"
python3 - "$K" "$Y1" > "$F/y1.out" 2>&1 <<'PYY1'
import sys, os, importlib.util
K, Y1 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import bot_config as config
for k in config.list_files:
    config.list_files[k] = os.path.join(Y1, os.path.basename(config.list_files[k]))
config.paths['hysteria_dir'] = Y1
config.paths['hysteria_config'] = os.path.join(Y1, 'hy.json')
spec = importlib.util.spec_from_file_location('lc', K + '/opt/etc/bot/lists_core.py')
lc = importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)
lc.UNBLOCK_DIR = Y1 + '/'
fp = os.path.join(Y1, 'list.txt')
# отсутствующий файл + rev='' (bootstrap) — запись проходит
r = lc.parse_and_save_if_revision(fp, 'a.example.org\nb.example.org', expected_rev='')
assert r['domains'] == 2, r
# rev содержимого — повторная запись проходит
rev = lc._list_content_rev(fp)
lc.parse_and_save_if_revision(fp, 'c.example.org', expected_rev=rev)
# идемпотентность rev: no-op перезапись НЕ меняет ревизию (прежде
# mtime_ns менялся от каждого касания — ложные конфликты рендера)
rev2 = lc._list_content_rev(fp)
lc.parse_and_save_if_revision(fp, 'c.example.org', expected_rev=rev2)
assert lc._list_content_rev(fp) == rev2, 'rev нестабилен при no-op записи'
# устаревший rev — конфликт, файл не тронут
try:
    lc.parse_and_save_if_revision(fp, 'STALE.example', expected_rev=rev)
    raise AssertionError('stale-rev прошёл!')
except lc.ListRevisionConflict:
    pass
assert 'STALE' not in open(fp).read()
# strict: пустой rev при существующем файле — конфликт
try:
    lc.parse_and_save_if_revision(fp, 'NOREV.example', expected_rev='')
    raise AssertionError('пустой rev прошёл!')
except lc.ListRevisionConflict:
    pass
assert 'NOREV' not in open(fp).read()
# различие отсутствующего и пустого файла: пустой имеет sha256('')
open(fp, 'w').close()
assert len(lc._list_content_rev(fp)) == 64 and lc._list_content_rev(fp) != ''
os.remove(fp)
assert lc._list_content_rev(fp) == ''
print('Y1 OK')
PYY1
grep -q '^Y1 OK' "$F/y1.out" \
    && ok "Y1: compare-and-write: bootstrap-запись, no-op ревизия стабильна, stale/пустой rev → конфликт, отсутствующий ≠ пустой (FB-70/K58-1)" \
    || bad "Y1: $(tail -3 "$F/y1.out" | tr '\n' ' ')"

# Y2 (FB-70): rev-проверка ВНУТРИ guard (check/lock-интерливинг закрыт).
python3 - "$K" "$Y1" > "$F/y2.out" 2>&1 <<'PYY2'
import sys, os, importlib.util
from contextlib import contextmanager
K, Y1 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('lc', K + '/opt/etc/bot/lists_core.py')
lc = importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)
lc.UNBLOCK_DIR = Y1 + '/'
fp = os.path.join(Y1, 'race.txt')
open(fp, 'w').write('x.example\n')
state = {'depth': 0, 'checked_under_guard': None}
_orig_guard, _orig_rev = lc._list_write_guard, lc._list_content_rev
@contextmanager
def probe_guard(filepath):
    state['depth'] += 1
    try:
        with _orig_guard(filepath):
            yield
    finally:
        state['depth'] -= 1
def probe_rev(p):
    if p == fp and state['checked_under_guard'] is None:
        state['checked_under_guard'] = state['depth'] > 0
    return _orig_rev(p)
lc._list_write_guard = probe_guard
lc._list_content_rev = probe_rev
lc.parse_and_save_if_revision(fp, 'y.example\n', expected_rev=_orig_rev(fp))
assert state['checked_under_guard'] is True, \
    'rev-проверка вне guard — TOCTOU-окно (check/lock-интерливинг) открыто!'
print('Y2 OK')
PYY2
grep -q '^Y2 OK' "$F/y2.out" \
    && ok "Y2: _list_content_rev вызывается под guard — сравнение и запись в одной критической секции, TOCTOU-окно закрыто (FB-70/K58-1)" \
    || bad "Y2: $(tail -3 "$F/y2.out" | tr '\n' ' ')"

# Y3 (FB-70): маршрут — bootstrap-форма без rev на ОТСУТСТВУЮЩЕМ файле.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/y3.out" 2>&1 <<'PYY3'
import sys, os, importlib.util, tempfile
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzy3_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
g.BYPASS_FILES = {n: p for n, p in g.config.list_files.items() if n != 'bot'}
g.BOT_BYPASS_FILE = g.config.list_files['bot']
import lists_core
lists_core.UNBLOCK_DIR = tmp
# файл trojan.txt НЕ создаём: bootstrap-форма (без rev) обязана
# создать список с нуля — пустой expected_rev совпадает с ''
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/panel?tab=tr', auth=('a', 'b')).data.decode()
import re
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
assert not os.path.exists(g.config.list_files['trojan'])
r = c.post('/list/tr',
           data={'csrf_token': token, 'content': 'bootstrap.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302, r.status_code
text = open(g.config.list_files['trojan']).read()
assert 'bootstrap.example' in text, 'bootstrap-форма без rev не сохранилась!'
print('Y3 OK')
PYY3
    grep -q '^Y3 OK' "$F/y3.out" \
        && ok "Y3: маршрут: отсутствующий файл + форма без rev → создание списка (bootstrap-путь strict не ломает) (FB-70)" \
        || bad "Y3: $(tail -3 "$F/y3.out" | tr '\n' ' ')"
else
    ok "Y3: [SKIP] flask не установлен — bootstrap-путь проверяется в Y1"
fi

# Y4 (FB-71): resolv.conf — гейт DNS_OVERRIDE_OK / проба до / откат после.
Y4="$F/y4"; mkdir -p "$Y4"
{ extract_fn _kz_dns_live "$DEP"; echo; extract_fn _kz_dns_probe_local "$DEP"; echo; extract_fn _kz_resolver_finalize "$DEP"; } > "$Y4/fn.sh"
cat > "$Y4/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/y4/fn.sh
warn() { printf '%s\n' "W|$*"; }
G_OK=$1; G_LIVE=$2; G_PROBE=$3; G_ENS=$4; G_POST=$5
DNS_OVERRIDE_OK=$G_OK; export DNS_OVERRIDE_OK
_kz_dns_live() { [ "$G_LIVE" = 1 ]; }
_kz_dns_probe_local() { return "$G_PROBE"; }
_kz_dns_probe_via_resolv() { return "$G_POST"; }
ensure_local_resolver() { [ "$G_ENS" = 1 ]; }
_kz_resolver_finalize
EOF
y4case() { # $1..$5 = ok/live/probe/ensure/post, $6 = ожидание, $7 = НЕДОПУСТИМОЕ, $8 = тег
    _o=$(sh "$Y4/run.sh" "$1" "$2" "$3" "$4" "$5" 2>&1)
    Y4R="$Y4R $8"
    printf '%s' "$_o" | grep -q "$6" || Y4B="$Y4B $8-нет-ожидалось"
    if [ -n "$7" ]; then
        printf '%s' "$_o" | grep -q "$7" && Y4B="$Y4B $8-лишнее"
    fi
}
Y4B=""; Y4R=""
y4case 0 1 0 1 0 'DNS Override не подтверждён' 'ENSURE' no-gate
y4case 1 0 0 1 0 'dnsmasq не работает' 'ENSURE' dead
y4case 1 1 1 1 0 'не отвечает на' 'ENSURE' probe-fail
y4case 1 1 0 0 0 'Не удалось установить nameserver' '' ensure-fail
y4case 1 1 0 1 1 'резолвинг не работает' '' post-fail
y4case 1 1 0 1 0 'работает через локальный dnsmasq' '' all-ok
# FB-83 (аудит-35, R59-01): «неизвестно» (нет nslookup/dig) —
# fail-closed: не переключаем ДО и откатываем ПОСЛЕ
y4case 1 1 2 1 0 'нет nslookup/dig' 'ENSURE' probe-unknown
y4case 1 1 0 1 2 'не подтверждён' 'работает через локальный' post-unknown
if [ -z "$Y4B" ]; then
    ok "Y4: finalize: без DNS_OVERRIDE_OK / мёртвый dnsmasq / проба fail / проба unknown (нет nslookup+dig) → resolv.conf не тронут; ensure fail → warn+восстановление; пост-чек fail/unknown → откат; всё живо → ✅ (FB-71+FB-83)"
else
    bad "Y4:$Y4B"
fi

# Y5 (FB-75): _kz_dns_live — procfs-fallback при отсутствии pidof.
Y5="$F/y5"; mkdir -p "$Y5/bin"
printf '#!/bin/sh\nexit 127\n' > "$Y5/bin/pidof"
chmod +x "$Y5/bin/pidof"
extract_fn _kz_dns_live "$DEP" > "$Y5/live.sh"
bash -c 'exec -a dnsmasq sleep 4' &
_fpid=$!
sleep 0.3
_o1=$(PATH="$Y5/bin:/usr/bin:/bin" sh -c '. /tmp/f47chk/y5/live.sh; _kz_dns_live; echo rc=$?')
kill "$_fpid" 2>/dev/null || true
wait "$_fpid" 2>/dev/null || true
_o2=$(PATH="$Y5/bin:/usr/bin:/bin" sh -c '. /tmp/f47chk/y5/live.sh; _kz_dns_live; echo rc=$?')
if [ "$_o1" = 'rc=0' ] && [ "$_o2" = 'rc=1' ]; then
    ok "Y5: _kz_dns_live без pidof: /proc/<pid>/cmdline находит dnsmasq (exec -a) и не находит после его смерти (FB-75/K57-3)"
else
    bad "Y5: found=[${_o1#rc=}] gone=[${_o2#rc=}]"
fi

# Y6 (FB-76): явный KEENZOO_DLTMP — абсолютность/mkdir/writable/die.
Y6="$F/y6"; mkdir -p "$Y6"
sed -n '/^KEENZOO_DLTMP=/,/^fi$/p' "$DEP" > "$Y6/block.sh"
cat > "$Y6/run.sh" <<'EOF'
#!/bin/sh
die() { echo "DIE|$*"; exit 1; }
KEENZOO_DLTMP="$1"
. /tmp/f47chk/y6/block.sh
echo "OK|$KEENZOO_DLTMP"
EOF
Y6B=""
_o=$(sh "$Y6/run.sh" "rel/path" 2>&1)
printf '%s' "$_o" | grep -q 'DIE|.*абсолютным' || Y6B="$Y6B relative-прошёл"
_o=$(sh "$Y6/run.sh" "/proc/nope/dl" 2>&1)
printf '%s' "$_o" | grep -q 'DIE|.*создать каталог' || Y6B="$Y6B mkdir-прошёл"
mkdir -p /tmp/f47chk/y6/ro && chmod 555 /tmp/f47chk/y6/ro
# сам каталог существует (mkdir -p ok), но не записываем — [ -w ] false
_o=$(sh "$Y6/run.sh" "/tmp/f47chk/y6/ro" 2>&1)
printf '%s' "$_o" | grep -q 'DIE|.*не доступен для записи' || Y6B="$Y6B writable-прошёл"
_o=$(sh "$Y6/run.sh" "/tmp/f47chk/y6/dl" 2>&1)
printf '%s' "$_o" | grep -q '^OK|/tmp/f47chk/y6/dl$' || Y6B="$Y6B ok-ветка-сломана"
[ -d /tmp/f47chk/y6/dl ] || Y6B="$Y6B каталог-не-создан"
# дефолт-ветка: пустое значение → прежний дефолт без DIE (mkdir в
# /opt/share или /tmp) — регресс FB-76 не ломает подбор по умолчанию
_o=$(KEENZOO_DLTMP= sh "$Y6/run.sh" "" 2>&1 || true)
case "$_o" in
    DIE*) Y6B="$Y6B дефолт-ветка-умерла" ;;
    OK\|*) : ;;
    *) : ;;
esac
if [ -z "$Y6B" ]; then
    ok "Y6: явный KEENZOO_DLTMP: относительный/несоздаваемый/незаписываемый → ранний die с причиной; валидный → mkdir+OK; дефолт-ветка не сломана (FB-76/N58-1)"
else
    bad "Y6:$Y6B"
fi

# Y7 (FB-72/FB-78): флип без сторонних фидов — http-фида больше нет:
# гейт открыт БЕЗ согласия (в авто-режиме согласия не существует вовсе).
w0reset
grep -v '^src custom' "$W0/opkg.conf" > "$W0/opkg.conf.n" && mv "$W0/opkg.conf.n" "$W0/opkg.conf"
cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
_o=$(printf '\n' | script -qec "sh $W0/drv.sh" /dev/null 2>&1 | tr -d '\r')
Y7B=""
printf '%s' "$_o" | grep -q 'GATE=PASS' || Y7B="$Y7B гейт-закрыт-без-остаточных"
printf '%s' "$_o" | grep -q 'CONSENT=1' && Y7B="$Y7B согласие-появилось-в-авто-режиме"
printf '%s' "$_o" | grep -q 'НЕ распространяется' && Y7B="$Y7B ложный-сброс"
if [ -z "$Y7B" ]; then
    ok "Y7: флип без сторонних http-фидов: гейт открыт (http-фида больше нет), согласие в авто-режиме не возникает (FB-72/FB-78/K57-1)"
else
    bad "Y7:$Y7B"
fi

# Y8 (FB-73): per-source статусы — частичный провал = check_failed.
Y8="$F/y8"; mkdir -p "$Y8"
sed -n '/^SRC_OPKG=ok/,/^    CHECK_FAILED=1$/p' "$CU" > "$Y8/src.sh"
echo 'fi' >> "$Y8/src.sh"
y8run() { # opkg_rc xgh_ok xgh hy_ok hy expected_cf tag
    _cf=$(OPKG_UPD_RC=$1 XRAY_GH_OK=$2 XRAY_GH=$3 HY_GH_OK=$4 HY_GH=$5 \
        sh -c '. /tmp/f47chk/y8/src.sh; printf %s "$CHECK_FAILED"')
    Y8R="$Y8R $7=$_cf"
    [ "$_cf" = "$6" ] || Y8B="$Y8B $7"
}
Y8B=""; Y8R=""
y8run 0 1 v25 1 v2  0 all-ok
y8run 0 1 ''  1 v2  1 gh-xray-down
y8run 1 1 v25 1 v2  1 opkg-down-gh-up
y8run 1 1 ''  1 ''  1 total-down
y8run 1 0 ''  0 ''  1 be-mips-opkg-down
y8run 0 0 ''  0 ''  0 be-mips-opkg-ok
_src=$(OPKG_UPD_RC=1 XRAY_GH_OK=1 XRAY_GH= HY_GH_OK=0 HY_GH= \
    sh -c '. /tmp/f47chk/y8/src.sh; printf "%s/%s/%s" "$SRC_OPKG" "$SRC_XRAY_GH" "$SRC_HY_GH"')
[ "$_src" = 'fail/fail/na' ] || Y8B="$Y8B sources-матрица[$_src]"
grep -q 'SRC_HY_GH' "$CU" || Y8B="$Y8B нет-SRC_HY_GH-в-JSON-строке"
if [ -z "$Y8B" ]; then
    ok "Y8: check_updates: 6 сценариев per-source (частичный провал=check_failed; BE-MIPS GH=na не ошибка; opkg-down при живом GH теперь честный fail) + sources в JSON (FB-73/R58-03)"
else
    bad "Y8:$Y8B ($Y8R)"
fi

# Y9 (FB-77, релиз; r98): INSTALL r98 — menu-SHA сверен, подписи
# редакции 98, r97-SHA отсутствует.
INS87=$(ls /home/user/INSTALL_*-98_DETAILED.md 2>/dev/null | head -1)
if [ -n "$INS87" ] && [ -f /home/user/KeenZOO_menu.sh ]; then
    Y9B=""
    _msha=$(sha256sum /home/user/KeenZOO_menu.sh | awk '{print $1}')
    grep -q "$_msha" "$INS87" || Y9B="$Y9B menu-SHA-не-сверен-с-фактом"
    grep -q 'e53dd8ca' "$INS87" && Y9B="$Y9B старый-r97-SHA-остался"
    grep -q 'редакции 98' "$INS87" || Y9B="$Y9B нет-подписей-редакции-98"
    if [ -z "$Y9B" ]; then
        ok "Y9: INSTALL_98: menu-SHA = sha256(KeenZOO_menu.sh), подписи «редакции 98», r97-SHA отсутствует (FB-77/K58-3/r98)"
    else
        bad "Y9:$Y9B"
    fi
else
    ok "Y9: [SKIP] INSTALL_92 ещё не собран — проверка сработает на релизном прогоне (FB-77)"
fi

# ═══ Z. Аудит-35 (внешние отчёты r60): FB-82..FB-90, K60-01, миноры ═══
echo "═══ Z. Аудит-35: транзакционность, fail-closed, изоляция, паритет ═══"

# Z0: структурные маркеры всех правок аудита-35.
Z0B=""
for _z0 in 'FB-82 (аудит-35' 'FB-83 (аудит-35' 'FB-84 (аудит-35' 'FB-85 (аудит-35' 'FB-89 (аудит-35'; do
    grep -q "$_z0" "$DEP" || Z0B="$Z0B нет-$_z0(deploy)"
done
grep -q 'FB-86 (аудит-35' "$GEN" || Z0B="$Z0B нет-FB-86(generator)"
grep -q 'FB-87 (аудит-35' "$GEN" || Z0B="$Z0B нет-FB-87(generator)"
grep -q 'FB-88 (аудит-35' "$CU" || Z0B="$Z0B нет-FB-88(check_updates)"
grep -q 'FB-90 (аудит-35' "$UPD" || Z0B="$Z0B нет-FB-90(update_protocols)"
grep -q 'FB-89 (аудит-35' "$S57" || Z0B="$Z0B нет-FB-89(S57)"
grep -q 'FB-89' "$UDNS" || Z0B="$Z0B нет-FB-89(unblock_dnsmasq)"
grep -q 'FB-89 (аудит-35' "$K/opt/etc/bot/utils.py" || Z0B="$Z0B нет-FB-89(utils)"
grep -q 'kz_json_root_str() {' "$K/opt/bin/common.sh" || Z0B="$Z0B нет-kz_json_root_str"
grep -q 'K60-01' "$DEP" || Z0B="$Z0B нет-K60-01"
grep -q 'K60-05' "$K/opt/etc/bot/main.py" || Z0B="$Z0B нет-K60-05(main)"
grep -q 'K60-05' "$GEN" || Z0B="$Z0B нет-K60-05(generator)"
if [ -z "$Z0B" ]; then
    ok "Z0: маркеры FB-82..FB-90 + K60-01/K60-05 + kz_json_root_str — во всех правленых файлах"
else
    bad "Z0:$Z0B"
fi

# Z1 (FB-90): KEENZOO_DLTMP в update_protocols — семантика deploy (FB-76).
Z1="$F/z1"; mkdir -p "$Z1"
sed -n '/^KEENZOO_DLTMP=/,/^fi$/p' "$UPD" > "$Z1/block.sh"
cat > "$Z1/run.sh" <<'EOF'
#!/bin/sh
KEENZOO_DLTMP="$1"
. /tmp/f47chk/z1/block.sh
echo "OK|$KEENZOO_DLTMP"
EOF
Z1B=""
_o=$(sh "$Z1/run.sh" "rel/path" 2>&1); rc=$?
[ "$rc" = 1 ] || Z1B="$Z1B relative-не-die"
printf '%s' "$_o" | grep -q 'абсолютным' || Z1B="$Z1B relative-без-причины"
printf 'x' > /tmp/f47chk/z1/afile
_o=$(sh "$Z1/run.sh" "/tmp/f47chk/z1/afile" 2>&1); rc=$?
[ "$rc" = 1 ] || Z1B="$Z1B файл-не-die"
printf '%s' "$_o" | grep -q 'файл, а не каталог' || Z1B="$Z1B файл-без-причины"
mkdir -p /tmp/f47chk/z1/ro && chmod 555 /tmp/f47chk/z1/ro
_o=$(sh "$Z1/run.sh" "/tmp/f47chk/z1/ro" 2>&1); rc=$?
[ "$rc" = 1 ] || Z1B="$Z1B ro-не-die"
printf '%s' "$_o" | grep -q 'не доступен для записи' || Z1B="$Z1B ro-без-причины"
_o=$(sh "$Z1/run.sh" "" 2>&1)
case "$_o" in
    OK\|*) : ;;
    *) Z1B="$Z1B дефолт-ветка-сломана" ;;
esac
if [ -z "$Z1B" ]; then
    ok "Z1: update_protocols KEENZOO_DLTMP: относительный/файл/незаписываемый → die с причиной; пустой → авто-выбор (FB-90/R59-05, семантика FB-76)"
else
    bad "Z1:$Z1B"
fi

# Z2 (FB-87): лимит строк → ValueError из lists_core; маршрут ловит и
# отвечает flash+redirect (не HTTP 500).
Z2="$F/z2"; mkdir -p "$Z2"
Z2B=""
python3 - "$K" "$Z2" > "$F/z2.out" 2>&1 <<'PYZ2'
import sys, os
K, Z2 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import lists_core as lc
lc.UNBLOCK_DIR = Z2
fp = os.path.join(Z2, 'big.txt')
big = '\n'.join('d%d.example' % i for i in range(lc.MAX_LIST_LINES + 5)) + '\n'
open(fp, 'w').write('old\n')
try:
    lc._parse_and_save_impl(fp, big)
    print('NO-VALUEERROR')
except ValueError as e:
    print('VE|' + str(e))
PYZ2
grep -q '^VE|Строк:' "$F/z2.out" || Z2B="$Z2B lists_core-не-кидает"
grep -q 'except ValueError' "$GEN" || Z2B="$Z2B маршрут-не-ловит"
grep -q 'слишком большой список' "$GEN" || Z2B="$Z2B нет-flash-текста"
grep -q 'MAX_LIST_LINES' "$GEN" || Z2B="$Z2B лимит-не-упомянут"
if [ -z "$Z2B" ]; then
    ok "Z2: превышение MAX_LIST_LINES → ValueError «Строк: N» (lists_core); маршрут — flash с лимитом + redirect, не 500 (FB-87/K60-03)"
else
    bad "Z2:$Z2B"
fi

# Z3 (FB-88): check_updates — единый kz_resolve_binaries, локальная
# case-матрица и cu_is_mips_le удалены; BE-MIPS Xray=GH согласован.
Z3B=""
grep -q 'kz_resolve_binaries "$ARCH"' "$CU" || Z3B="$Z3B нет-общего-резолвера"
grep -q 'cu_is_mips_le() {' "$CU" && Z3B="$Z3B осталась-локальная-is_mips_le"
grep -q 'XRAY_GH_OK=0' "$CU" || Z3B="$Z3B нет-инициализации-fail-closed"
grep -q 'FB-88 (аудит-35, R59-03' "$CU" || Z3B="$Z3B нет-комментараря-мотивации"
if [ -z "$Z3B" ]; then
    ok "Z3: check_updates: XRAY_GH_OK/HY_GH_OK из kz_resolve_binaries (rc 1 → оба 0, fail-closed; BE-MIPS Xray=GH как в deploy) (FB-88/R59-03)"
else
    bad "Z3:$Z3B"
fi

# Z4 (FB-86): _list_snap — один снимок байтов даёт и текст, и rev.
Z4="$F/z4"; mkdir -p "$Z4"
python3 - "$K" "$Z4" > "$F/z4.out" 2>&1 <<'PYZ4'
import sys, os, hashlib
K, Z4 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import generator as g
fp = os.path.join(Z4, 'l.txt')
raw = 'a.example\nb.example\n\n'
open(fp, 'wb').write(raw.encode())
text, rev = g._list_snap(fp)
assert text == 'a.example\nb.example', repr(text)
assert rev == hashlib.sha256(raw.encode()).hexdigest(), 'rev != sha256'
raw2 = 'x.example'  # без завершающего перевода строки
open(fp, 'wb').write(raw2.encode())
text, rev = g._list_snap(fp)
assert text == 'x.example' and rev == hashlib.sha256(raw2.encode()).hexdigest()
text, rev = g._list_snap(os.path.join(Z4, 'missing.txt'))
assert text == '' and rev == hashlib.sha256(b'').hexdigest(), 'нет файла'
print('Z4 OK')
PYZ4
grep -q '^Z4 OK' "$F/z4.out" \
    && ok "Z4: _list_snap: один снимок байтов → текст (rstrip-семантика read_file_text) + rev=sha256; отсутствующий файл → ('', пустой-хэш) (FB-86/R59-02)" \
    || bad "Z4: $(tail -2 "$F/z4.out" | tr '\n' ' ')"

# Z5 (FB-82): _kz_dns_override_enable — save-провал = не подтверждено
# + откат на системный DNS; успешный save → подтверждено.
Z5="$F/z5"; mkdir -p "$Z5/bin"
{ extract_fn _kz_dns_override_state "$DEP"; echo; extract_fn _kz_dns_override_off "$DEP"; echo; extract_fn _kz_dns_override_disable "$DEP"; echo; extract_fn _kz_dns_override_on "$DEP"; echo; extract_fn _kz_dns_override_enable "$DEP"; } > "$Z5/fn.sh"
cat > "$Z5/bin/ndmc" <<'EOF'
#!/bin/sh
echo "ndmc $*" >> /tmp/f47chk/z5/journal
case "$*" in
  *'show running-config'*)
    [ "$(cat /tmp/f47chk/z5/state 2>/dev/null)" = on ] && echo 'opkg dns-override'
    exit 0 ;;
  *'system configuration save'*)
    [ -f /tmp/f47chk/z5/save_fails ] && exit 1
    exit 0 ;;
  *'no opkg dns-override'*) echo off > /tmp/f47chk/z5/state ;;
  *'opkg dns-override'*) echo on > /tmp/f47chk/z5/state ;;
esac
exit 0
EOF
chmod +x "$Z5/bin/ndmc"
cat > "$Z5/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/z5/fn.sh
warn() { printf '%s\n' "W|$*"; }
PATH="/tmp/f47chk/z5/bin:/usr/bin:/bin"; export PATH
echo off > /tmp/f47chk/z5/state
_kz_dns_override_enable
echo "rc=$? state=$(cat /tmp/f47chk/z5/state)"
EOF
chmod +x "$Z5/run.sh"
Z5B=""
rm -f "$Z5/save_fails" "$Z5/journal"
_o=$(sh "$Z5/run.sh" 2>&1)
printf '%s' "$_o" | grep -q 'rc=0 state=on' || Z5B="$Z5B успешный-save-не-подтверждён"
rm -f "$Z5/journal"
: > "$Z5/save_fails"
_o=$(sh "$Z5/run.sh" 2>&1)
printf '%s' "$_o" | grep -q 'rc=1 state=off' || Z5B="$Z5B save-провал-без-отката"
printf '%s' "$_o" | grep -q 'не подтверждён' || Z5B="$Z5B нет-текста-неподтверждения"
grep -q 'ndmc -c no opkg dns-override$' "$Z5/journal" || Z5B="$Z5B нет-no-override-при-провале"
if [ -z "$Z5B" ]; then
    ok "Z5: dns-override enable: rc обоих ndmc учтён; save-провал → «не подтверждён» + возврат системного DNS (FB-82/R60-01)"
else
    bad "Z5:$Z5B"
fi

# Z6 (K60-01): изоляция бутстрапа — opkg -f с фильтром entware|keendev,
# отдельный lists_dir, `_kz_BOOTSTRAP_MISSING` без command substitution.
Z6B=""
grep -q 'opkg -f ' "$DEP" || Z6B="$Z6B нет-opkg--f"
grep -q '_kz_iso_conf_write() {' "$DEP" || Z6B="$Z6B нет-фильтра-конфига"
grep -q 'mktemp -d /tmp/.kz_iso_lists' "$DEP" || Z6B="$Z6B нет-отдельного-lists_dir"
grep -q 'KEENZOO_BOOTSTRAP_PROBE_MAX' "$DEP" || Z6B="$Z6B нет-бюджета-проб"
grep -q '_KZ_BOOTSTRAP_MISSING' "$DEP" || Z6B="$Z6B нет-глобального-missing"
printf '%s' "$(grep -c '\$(_kz_bootstrap_missing' "$DEP")" | grep -q '^0$' || Z6B="$Z6B missing-в-command-substitution"
if [ -z "$Z6B" ]; then
    ok "Z6: изолированный бутстрап: opkg -f + фильтр entware|keendev + отдельный lists_dir; список отсутствующих — глобаль (list-installed ×1); бюджет проб с KEENZOO_BOOTSTRAP_PROBE_MAX (K60-01 + миноры §5)"
else
    bad "Z6:$Z6B"
fi

# Z7 (K60-05): минимум Python в точках входа.
Z7B=""
grep -q 'sys.version_info < (3, 8)' "$K/opt/etc/bot/main.py" || Z7B="$Z7B main-без-чека"
grep -q 'sys.version_info < (3, 8)' "$GEN" || Z7B="$Z7B generator-без-чека"
grep -q 'требуется Python 3.8' "$K/opt/etc/bot/main.py" || Z7B="$Z7B main-без-сообщения"
if [ -z "$Z7B" ]; then
    ok "Z7: явный минимум Python 3.8 в main.py/generator.py с сообщением в stderr (K60-05)"
else
    bad "Z7:$Z7B"
fi


# ═══ Z-36. Аудит-36 (внешние отчёты r61): FB-91..FB-99 ═══
echo "═══ Z-36. Аудит-36: пробы ABI, override-откат, resolv-транзакция, tri-state ═══"

# Z36-1 (FB-92, R61-01): финализатор откатывает Override, включённый
# этим запуском, только при ПОДТВЕРЖДЁННОМ провале (rc=1); rc=2
# «не проверено» и чужой Override — не трогаем.
Z8="$F/z8"; mkdir -p "$Z8"
{ extract_fn _kz_dns_override_state "$DEP"; echo; extract_fn _kz_dns_override_off "$DEP"; echo; extract_fn _kz_dns_override_on "$DEP"; echo; extract_fn _kz_dns_override_disable "$DEP"; echo; extract_fn _kz_dns_self_revert "$DEP"; echo; extract_fn _kz_dns_live "$DEP"; echo; extract_fn _kz_dns_probe_local "$DEP"; echo; extract_fn _kz_resolver_finalize "$DEP"; } > "$Z8/fn.sh"
cat > "$Z8/bin-dir" <<'EOF'
EOF
mkdir -p "$Z8/bin"
cat > "$Z8/bin/ndmc" <<'EOF'
#!/bin/sh
echo "ndmc $*" >> /tmp/f47chk/z8/journal
case "$*" in
  *'show running-config'*) [ "$(cat /tmp/f47chk/z8/state 2>/dev/null)" = on ] && echo 'opkg dns-override' ;;
  *'no opkg dns-override'*) [ -f /tmp/f47chk/z8/fail_no ] && exit 1; echo off > /tmp/f47chk/z8/state ;;
  *'opkg dns-override'*) echo on > /tmp/f47chk/z8/state ;;
esac
exit 0
EOF
chmod +x "$Z8/bin/ndmc"
cat > "$Z8/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/z8/fn.sh
warn() { printf '%s
' "W|$*"; }
G_OK=$1; G_LIVE=$2; G_PROBE=$3; G_ENS=$4; G_POST=$5; G_SELF=$6
DNS_OVERRIDE_OK=$G_OK; DNS_OVERRIDE_SELF=$G_SELF; export DNS_OVERRIDE_OK DNS_OVERRIDE_SELF
_kz_dns_live() { [ "$G_LIVE" = 1 ]; }
_kz_dns_probe_local() { return "$G_PROBE"; }
_kz_dns_probe_via_resolv() { return "$G_POST"; }
ensure_local_resolver() { [ "$G_ENS" = 1 ]; }
_kz_resolver_finalize
EOF
z8case() { # ok live probe ensure post self — ждём-строка, недопустимое, тег
    _o=$(PATH="$Z8/bin:$PATH" sh "$Z8/run.sh" "$1" "$2" "$3" "$4" "$5" "$6" 2>&1)
    printf '%s' "$_o" | grep -q "$7" || Z8B="$Z8B $9-нет-ожидалось"
    if [ -n "$8" ]; then
        printf '%s' "$_o" | grep -q "$8" && Z8B="$Z8B $9-лишнее"
        grep -q 'no opkg dns-override' "$Z8/journal" && [ "$8" = "NOREVERT" ] && Z8B="$Z8B $9-лишний-no-override"
    fi
}
Z8B=""
: > "$Z8/journal"; echo on > "$Z8/state"; rm -f "$Z8/fail_no"
# пост-проба rc=1 (подтверждённый провал), наш override → откат:
# no-override + save + контроль show running-config
z8case 1 1 0 1 1 1 'откат (порт 53 возвращается системному DNS' '' self-post-fail
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B post-fail-нет-no-override"
grep -q 'system configuration save' "$Z8/journal" || Z8B="$Z8B post-fail-нет-save"
grep -q 'show running-config' "$Z8/journal" || Z8B="$Z8B post-fail-нет-контроля"
# пост-проба rc=2 (не проверено) → resolv откат, override НЕ трогаем
: > "$Z8/journal"
z8case 1 1 0 1 2 1 'не подтверждён' '' self-post-unknown
grep -q 'no opkg dns-override' "$Z8/journal" && Z8B="$Z8B post-unknown-лишний-no-override"
# dnsmasq мёртв, наш override → откат
: > "$Z8/journal"
z8case 1 0 0 1 0 1 'dnsmasq не работает' '' self-dead
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B dead-нет-no-override"
# локальная проба rc=1, наш override → откат
: > "$Z8/journal"
z8case 1 1 1 1 0 1 'не отвечает на' '' self-probe-fail
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B probe-fail-нет-no-override"
# чужой override (SELF=0) при провале → НЕ трогаем
: > "$Z8/journal"
z8case 1 1 0 1 1 0 'резолвинг не работает' '' foreign-no-revert
grep -q 'no opkg dns-override' "$Z8/journal" && Z8B="$Z8B foreign-лишний-no-override"
# откат не удался (no-override провалился) → ручные команды + честный
# вердикт; save при этом НЕ вызывается (транзакция прервана)
: > "$Z8/journal"; echo on > "$Z8/state"; : > "$Z8/fail_no"
z8case 1 1 0 1 1 1 'Не удалось отключить DNS Override' '' revert-fail
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B revert-fail-нет-попытки"
grep -q 'system configuration save' "$Z8/journal" && Z8B="$Z8B revert-fail-лишний-save"
if [ -z "$Z8B" ]; then
    ok "Z36-1: финализатор: SELF+пост-fail/dead/probe-fail → no-override+save+контроль; rc=2 и SELF=0 → override не трогаем; отказ ndmc → ручные команды (FB-92/R61-01)"
else
    bad "Z36-1:$Z8B"
fi

# Z36-2 (FB-93/R61-02): resolv.conf — транзакция (бэкап cat+cmp,
# restore с проверкой, идемпотентность) на подменённом пути стенда.
Z9="$F/z9"; mkdir -p "$Z9/bin"
for _z9fn in dns_ok ensure_dns restore_dns; do
    awk -v f="$_z9fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP"
done | sed "s#/etc/resolv.conf#$Z9/resolv.conf#g" > "$Z9/fn.sh"
printf '#!/bin/sh\n[ -s /tmp/f47chk/z9/failmark ] && exit 1\nexit 0\n' > "$Z9/bin/nslookup"
chmod +x "$Z9/bin/nslookup"
cat > "$Z9/bin/cmp" <<'EOF'
#!/bin/sh
N="$(cat /tmp/f47chk/z9/cmpn 2>/dev/null || echo 0)"
N=$((N+1)); echo "$N" > /tmp/f47chk/z9/cmpn
[ "$N" -ge 2 ] && exit 1
exec /usr/bin/cmp "$@"
EOF
chmod +x "$Z9/bin/cmp"
cat > "$Z9/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/z9/fn.sh
warn() { printf '%s
' "W|$*" >&2; }
have_cmd() { command -v "$1" >/dev/null 2>&1; }
export PATH="/tmp/f47chk/z9/bin:$PATH"
RESOLV_BACKUP=""; RESOLV_TEMP_ACTIVE=0
case "$1" in
  sub)
    echo fail > /tmp/f47chk/z9/failmark
    printf 'nameserver 192.168.1.1
' > /tmp/f47chk/z9/resolv.conf
    ensure_dns >/dev/null 2>&1
    grep -q 1.1.1.1 /tmp/f47chk/z9/resolv.conf && echo "SUB=ok"
    [ "${RESOLV_TEMP_ACTIVE:-0}" = 1 ] && echo "FLAG=1"
    [ -n "$RESOLV_BACKUP" ] && echo "BAK=1"
    echo 0 > /tmp/f47chk/z9/cmpn
    restore_dns
    grep -q 192.168.1.1 /tmp/f47chk/z9/resolv.conf && echo "REST=ok"
    [ -z "${RESOLV_BACKUP:-}" ] && echo "BAKDEL=1"
    [ "${RESOLV_TEMP_ACTIVE:-1}" = 0 ] && echo "FLAG0=1"
    ;;
  restfail)
    echo fail > /tmp/f47chk/z9/failmark
    printf 'nameserver 192.168.1.1
' > /tmp/f47chk/z9/resolv.conf
    ensure_dns >/dev/null 2>&1
    restore_dns 2>&1 | sed -n '1p'
    [ -n "${RESOLV_BACKUP:-}" ] && [ -f "$RESOLV_BACKUP" ] && echo "BAKKEPT=1"
    ;;
esac
EOF
Z9B=""
: > "$Z9/failmark"; echo 0 > "$Z9/cmpn"
_o=$(sh "$Z9/run.sh" sub 2>&1)
for _z9e in 'SUB=ok' 'FLAG=1' 'BAK=1' 'REST=ok' 'BAKDEL=1' 'FLAG0=1'; do
    printf '%s' "$_o" | grep -q "$_z9e" || Z9B="$Z9B sub-нет-$_z9e"
done
echo 0 > "$Z9/cmpn"
_o=$(sh "$Z9/run.sh" restfail 2>&1)
printf '%s' "$_o" | grep -q 'бэкап СОХРАНЁН' || Z9B="$Z9B restfail-нет-сохранения"
printf '%s' "$_o" | grep -q 'BAKKEPT=1' || Z9B="$Z9B restfail-бэкап-удалён"
if [ -z "$Z9B" ]; then
    ok "Z36-2: resolv.conf: подмена только при сверином бэкапе (cat+cmp), RESOLV_TEMP_ACTIVE, restore подтверждает и удаляет бэкап; провал restore — бэкап сохранён + подсказка (FB-93/R61-02)"
else
    bad "Z36-2:$Z9B"
fi

# Z36-3 (FB-95, R61-05): needs_key в deploy-оболочке — common.sh
# подгружается лениво из _nk_root_two, без засорения основного shell.
Z10="$F/z10"; mkdir -p "$Z10"
awk 'index($0, "_nk_root_two() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$Z10/nk.sh"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$Z10/nk.sh"
printf '%s' '{ "server": "real.example.org:443", "auth": "realkey" }' > "$Z10/valid.json"
Z10B=""
_o=$(KEENZOO_DEPLOY_COMMON="$K/opt/bin/common.sh" sh -c \
    ". '$Z10/nk.sh'; needs_key '$Z10/valid.json' hysteria </dev/null"; echo "rc=$?")
printf '%s' "$_o" | grep -q 'rc=1' || Z10B="$Z10B lazy-не-настроен($_o)"
_o=$(sh -c ". '$Z10/nk.sh'; needs_key '$Z10/valid.json' hysteria </dev/null"; echo "rc=$?")
printf '%s' "$_o" | grep -q 'rc=0' || Z10B="$Z10B без-common-не-fail-closed($_o)"
# на роутере common.sh уже установлен — путь дефолтный /opt/bin/common.sh
grep -q 'KEENZOO_DEPLOY_COMMON:-/opt/bin/common.sh' "$DEP" || Z10B="$Z10B нет-дефолт-пути"
grep -q 'command -v kz_json_root_str' "$DEP" || Z10B="$Z10B нет-прямого-вызова"
if [ -z "$Z10B" ]; then
    ok "Z36-3: needs_key без предзагруженного common: helper через _nk_root_two (lazy-source субшеллом, env-override для стендов; FB-111 — один субшелл на server+auth), отсутствие helper → rc 0 fail-closed (FB-95/R61-05/FB-111)"
else
    bad "Z36-3:$Z10B"
fi

# Z36-4 (R61-06): dns_ok — tri-state 0/1/2.
Z11="$F/z11"; mkdir -p "$Z11/bin"
awk 'index($0, "dns_ok() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" \
    | sed "s#/etc/resolv.conf#$Z11/resolv.conf#g" > "$Z11/fn.sh"
printf '#!/bin/sh\nexit %s\n' 0 > "$Z11/bin/nslookup0"
printf '#!/bin/sh\nexit %s\n' 1 > "$Z11/bin/nslookup1"
chmod +x "$Z11/bin/nslookup0" "$Z11/bin/nslookup1"
printf 'nameserver 192.168.1.1
' > "$Z11/resolv.conf"
Z11B=""
mkdir -p "$Z11/binA" "$Z11/binB"
cp "$Z11/bin/nslookup0" "$Z11/binA/nslookup"; cp "$Z11/bin/nslookup1" "$Z11/binB/nslookup"
_dnsok() { # $1=каталог-префикс PATH → rc dns_ok
    PATH="$1:/usr/bin:/bin" sh -c ". '$Z11/fn.sh'; have_cmd() { command -v \"\$1\" >/dev/null 2>&1; }; dns_ok </dev/null"
    return $?
}
_dnsok "$Z11/bin"; [ $? = 2 ] || Z11B="$Z11B нет-nslookup-не-rc2"
_dnsok "$Z11/binA"; [ $? = 0 ] || Z11B="$Z11B ok-не-rc0"
_dnsok "$Z11/binB"; [ $? = 1 ] || Z11B="$Z11B fail-не-rc1"
# без инструментов и без nameserver → rc 1
: > "$Z11/resolv.conf"
_dnsok "$Z11/bin"; [ $? = 1 ] || Z11B="$Z11B пустой-resolv-не-rc1"
if [ -z "$Z11B" ]; then
    ok "Z36-4: dns_ok tri-state: разрешение подтверждено → 0; провал → 1; нет nslookup/dig + nameserver есть → 2 «не проверено» (ранее молчаливый 0) (R61-06)"
else
    bad "Z36-4:$Z11B"
fi

# Z36-5 (FB-91, K61-01): пробы фидов — только <base>/<ABI>/Packages.gz;
# нераспознанный ABI → зеркальный механизм не запускается.
Z12="$F/z12"; mkdir -p "$Z12"
awk 'index($0, "_entware_feed_abi() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$Z12/fn.sh"
Z12B=""
z12abi() { # url → ожидание
    _v=$(sh -c ". '$Z12/fn.sh'; _entware_feed_abi '$1' </dev/null")
    [ "$_v" = "$2" ] || Z12B="$Z12B abi($1)='$_v'"
}
z12abi 'http://bin.entware.net/mipssf-k3.4' 'mipssf-k3.4'
z12abi 'https://bin.entware.net/aarch64-k3.10' 'aarch64-k3.10'
z12abi 'https://mirrors.bfsu.edu.cn/entware/armv7sf-k3.2/' 'armv7sf-k3.2'
z12abi 'http://bin.entware.net/x64-k3.2/keendev/Packages.gz' 'x64-k3.2/keendev/Packages.gz'
z12abi 'https://bin.entware.net/mipselsf-k3.4/keenetic' 'mipselsf-k3.4/keenetic'
z12abi 'https://bin.entware.net/mipselsf-k3.4/keenetic/' 'mipselsf-k3.4/keenetic'
z12abi 'https://example.org/mipselsf-k3.4//' ''
z12abi 'http://bin.entware.net/unknown-branch' ''
z12abi 'not-a-url' ''
# пробы всех трёх мест идут с ABI-сегментом
grep -q '_entware_probe_feed_url "\${_kzb_base%/}/\${_kzb_abi}"' "$DEP" || Z12B="$Z12B нет-пробы-текущего-фida-с-ABI"
grep -q '_entware_probe_feed_url "\${_kzb_cand%/}/\${_kzb_abi}"' "$DEP" || Z12B="$Z12B нет-пробы-зеркала-с-ABI"
grep -q '_entware_probe_feed_url "\${_kzf_cand%/}/\${_kzf_abi}"' "$DEP" || Z12B="$Z12B нет-пробы-флипа-с-ABI"
# ABI не распознан → зеркальный фейловер отключается
grep -q '"\$_kzb_want_mirrors" = 1 \] && \[ -z "\$_kzb_abi"' "$DEP" || Z12B="$Z12B нет-guard-кандидатов"
grep -q 'if \[ -z "\$_kzf_abi" \]; then' "$DEP" || Z12B="$Z12B нет-guard-флипа"
if [ -z "$Z12B" ]; then
    ok "Z36-5: пробы фидов во всех трёх местах идут в <base>/<ABI>[/хвост]/Packages.gz (хвост напр. /keenetic — FB-108/FEED-01); неизвестный ABI → честный отказ зеркального фейловера; полные URL-пробы — t35_bootstrap K11/K12 (FB-91/K61-01, FB-108)"
else
    bad "Z36-5:$Z12B"
fi

# ════ Z38: аудит-38 (внешние отчёты по r63) ════

# Z38-1 (FB-100/FB-103, аудит-38): kz_json_root_str — BusyBox-
# совместимый escape-детектор (index, без regex), escape в ИМЕНИ
# ключа → rc 2, дубликат ЛЮБОГО корневого ключа при ЛЮБОМ типе
# значения → rc 3, END-приоритет dup > kesc > esc/bad, валидные
# эскейпы значений проходят насквозь.
Z1="$F/z38k"; mkdir -p "$Z1"
printf '%s' '{"server":"a.org:443","auth":"k"}' > "$Z1/v.json"
printf '%s' '{"server":"a.org","auth":"x","auth":"y"}' > "$Z1/dup_s.json"
printf '%s' '{"server":"a.org","auth":"k","listen":80,"listen":81}' > "$Z1/dup_n.json"
printf '%s' '{"server":"a.org","auth":"k","meta":"a","meta":{"b":1}}' > "$Z1/dup_m.json"
printf '%s' '{"server":"a.org","auth":"k","tcpRedirect":{"a":1,"a":2}}' > "$Z1/dup_i.json"
printf '%s' '{"server":"a.org","auth":"k","serv\u0065r":"x"}' > "$Z1/kesc.json"
printf '%s' '{"server":"a.org","auth":"change\u005fme"}' > "$Z1/uesc.json"
printf '%s' '{"server":"a.org","auth":"bad\q"}' > "$Z1/besc.json"
printf '%s' '{"server":"a.org","auth":"ok \"q\" s"}' > "$Z1/okesc.json"
printf '%s' '{"server":"a.org","auth":"x","auth":"y","serv\u0065r":"z"}' > "$Z1/prio.json"
Z1B=""
z1m() { # файл ключ ожидание метка
    _rc=0
    sh -c ". '$K/opt/bin/common.sh'; kz_json_root_str '$1' '$2'" >/dev/null 2>&1 || _rc=$?
    [ "$_rc" = "$3" ] || Z1B="$Z1B $4($_rc)"
}
z1m "$Z1/v.json" server 0 norm
z1m "$Z1/dup_s.json" auth 3 dup-строки
z1m "$Z1/dup_n.json" auth 3 dup-числа
z1m "$Z1/dup_m.json" auth 3 dup-смешанный
z1m "$Z1/dup_i.json" auth 0 dup-вложенный-ок
z1m "$Z1/kesc.json" auth 2 escape-имя
z1m "$Z1/uesc.json" auth 2 u-escape
z1m "$Z1/besc.json" auth 2 битая-пара
z1m "$Z1/okesc.json" auth 0 валидные-эскейпы
z1m "$Z1/prio.json" auth 3 приоритет-dup-над-kesc
if command -v busybox >/dev/null 2>&1; then
    mkdir -p "$Z1/bb"
    ln -sf "$(command -v busybox)" "$Z1/bb/awk"
    z1mb() {
        _rc=0
        PATH="$Z1/bb:$PATH" sh -c ". '$K/opt/bin/common.sh'; kz_json_root_str '$1' '$2'" >/dev/null 2>&1 || _rc=$?
        [ "$_rc" = "$3" ] || Z1B="$Z1B busybox-$4($_rc)"
    }
    z1mb "$Z1/v.json" server 0 norm
    z1mb "$Z1/dup_s.json" auth 3 dup-строки
    z1mb "$Z1/kesc.json" auth 2 escape-имя
    z1mb "$Z1/uesc.json" auth 2 u-escape
    z1mb "$Z1/besc.json" auth 2 битая-пара
    z1mb "$Z1/okesc.json" auth 0 валидные-эскейпы
fi
if [ -z "$Z1B" ]; then
    ok "Z38-1: kz_json_root_str: escape-детектор index (BusyBox-awk совместим), escape-имя → rc 2, дубликат любого корневого ключа любого типа → rc 3, dup > kesc > esc, валидные эскейпы насквозь (FB-100/FB-103)"
else
    bad "Z38-1:$Z1B"
fi

# Z38-2 (FB-101/FB-102, аудит-38): ensure_dns — fail-closed при
# отсутствии resolv.conf; флаг транзакции ДО записи; провал записи —
# немедленный restore_dns.
Z2="$F/z38e"; mkdir -p "$Z2"
awk 'index($0, "ensure_dns() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" \
    | sed "s#/etc/resolv.conf#$Z2/rc.conf#g" > "$Z2/fn.sh"
awk 'index($0, "restore_dns() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" \
    | sed "s#/etc/resolv.conf#$Z2/rc.conf#g" >> "$Z2/fn.sh"
cat > "$Z2/run.sh" <<'R2'
#!/bin/sh
RC2="$Z2RC"
dns_ok() {
    if [ -f "$RC2" ] && grep -q '1\.1\.1\.1' "$RC2" 2>/dev/null; then return 0; fi
    return 1
}
warn() { printf '%s\n' "$*" >&2; }
RESOLV_BACKUP=""
RESOLV_TEMP_ACTIVE=0
. "$Z2FN"
ensure_dns
_r=$?
echo "FLAG=${RESOLV_TEMP_ACTIVE:-0}"
exit "$_r"
R2
Z2B=""
grep -q 'ensure_dns() {' "$Z2/fn.sh" || Z2B="$Z2B нет-ensure_dns"
grep -q 'restore_dns() {' "$Z2/fn.sh" || Z2B="$Z2B нет-restore_dns"
_i1=$(grep -n 'RESOLV_TEMP_ACTIVE=1' "$Z2/fn.sh" | head -1 | cut -d: -f1)
_i2=$(grep -n 'nameserver 1.1.1.1' "$Z2/fn.sh" | head -1 | cut -d: -f1)
{ [ -n "$_i1" ] && [ -n "$_i2" ] && [ "$_i1" -lt "$_i2" ]; } \
    || Z2B="$Z2B флаг-не-до-записи"
grep -q 'откат из бэкапа' "$Z2/fn.sh" || Z2B="$Z2B нет-текста-отката"
# (1) resolv.conf отсутствует → rc 1 + честный текст (FB-101)
rm -f "$Z2/rc.conf" /tmp/resolv.bak.* 2>/dev/null
_o=$(Z2RC="$Z2/rc.conf" Z2FN="$Z2/fn.sh" sh "$Z2/run.sh" 2>&1); _rc=$?
[ "$_rc" = 1 ] || Z2B="$Z2B нет-файла-не-rc1($_rc)"
printf '%s' "$_o" | grep -q 'отсутствует' || Z2B="$Z2B нет-текста-об-отсутствии"
# (2) файл есть, бэкап ок, запись ок → rc 0, флаг 1, публичные DNS
printf 'nameserver 192.168.1.1\n' > "$Z2/rc.conf"
rm -f /tmp/resolv.bak.* 2>/dev/null
_o=$(Z2RC="$Z2/rc.conf" Z2FN="$Z2/fn.sh" sh "$Z2/run.sh" 2>&1); _rc=$?
[ "$_rc" = 0 ] || Z2B="$Z2B норм-не-rc0($_rc)"
printf '%s' "$_o" | grep -q 'FLAG=1' || Z2B="$Z2B флаг-не-1"
grep -q '1\.1\.1\.1' "$Z2/rc.conf" 2>/dev/null || Z2B="$Z2B публичные-не-записаны"
# (3) запись провалена (файл только-чтение) → rc 1 + «откат из бэкапа»
printf 'nameserver 192.168.1.1\n' > "$Z2/rc.conf"
chmod 444 "$Z2/rc.conf"
rm -f /tmp/resolv.bak.* 2>/dev/null
_o=$(Z2RC="$Z2/rc.conf" Z2FN="$Z2/fn.sh" sh "$Z2/run.sh" 2>&1); _rc=$?
chmod 644 "$Z2/rc.conf"
[ "$_rc" = 1 ] || Z2B="$Z2B провал-записи-не-rc1($_rc)"
printf '%s' "$_o" | grep -q 'откат из бэкапа' || Z2B="$Z2B нет-немедленного-отката"
grep -q '1\.1\.1\.1' "$Z2/rc.conf" 2>/dev/null && Z2B="$Z2B подмена-при-провале-осталась"
rm -f /tmp/resolv.bak.* 2>/dev/null
if [ -z "$Z2B" ]; then
    ok "Z38-2: ensure_dns: нет resolv.conf → rc 1 честный отказ (FB-101); RESOLV_TEMP_ACTIVE до записи, провал записи → немедленный restore_dns + rc 1 (FB-102)"
else
    bad "Z38-2:$Z2B"
fi

# Z38-3 (FB-104/FB-105, аудит-38): tri-state _kz_dns_override_state
# 0/1/2; предикаты fail-closed; disable проверяем; enable save-fail —
# проверяемый откат с честным вердиктом.
Z3="$F/z38d"; mkdir -p "$Z3/bin"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_step() {")==1{p=0} p{print}' "$DEP" > "$Z3/fn.sh"
awk 'index($0, "_kz_dns_override_disable() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$Z3/fn.sh"
awk 'index($0, "_kz_dns_override_enable() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$Z3/fn.sh"
cat > "$Z3/bin/ndmc" <<'N3'
#!/bin/sh
D="$Z3DIR"
m="$(cat "$D/mode" 2>/dev/null || echo ok)"
f="$(cat "$D/failspec" 2>/dev/null || echo none)"
c="$(cat "$D/savecount" 2>/dev/null || echo 0)"
case "$1 $2" in
  "-c show running-config")
    case "$m" in
      on)    printf 'interface Bridge0\n opkg dns-override\n'; exit 0 ;;
      off)   printf 'interface Bridge0\n'; exit 0 ;;
      dead)  exit 1 ;;
      empty) exit 0 ;;
    esac ;;
  "-c opkg dns-override") echo on > "$D/mode"; exit 0 ;;
  "-c no opkg dns-override")
    [ "$f" = failno ] && exit 1
    echo off > "$D/mode"; exit 0 ;;
  "-c system configuration save")
    case "$f" in
      failsave)  exit 1 ;;
      failsave1) c=$((c+1)); echo "$c" > "$D/savecount"
                 [ "$c" -gt 1 ] && exit 0; exit 1 ;;
    esac ;;
esac
exit 0
N3
chmod +x "$Z3/bin/ndmc"
cat > "$Z3/run.sh" <<'R3'
#!/bin/sh
warn() { printf '%s\n' "$*" >&2; }
. "$Z3FN"
echo "$2" > "$Z3DIR/mode"
case "$1" in
  state)   _r=0; _kz_dns_override_state || _r=$?; echo "rc=$_r" ;;
  on)      if _kz_dns_override_on;  then echo "on=T"; else echo "on=F"; fi ;;
  off)     if _kz_dns_override_off; then echo "off=T"; else echo "off=F"; fi ;;
  disable) if _kz_dns_override_disable; then echo "dis=0"; else echo "dis=1"; fi ;;
  enable)  if _kz_dns_override_enable; then echo "en=0"; else echo "en=1"; fi ;;
esac
R3
z3() { # команда режим [failspec] → stdout+stderr
    printf '%s' "${3:-}" > "$Z3/failspec"; echo 0 > "$Z3/savecount"
    Z3DIR="$Z3" Z3FN="$Z3/fn.sh" PATH="$Z3/bin:$PATH" sh "$Z3/run.sh" "$1" "$2" 2>&1
}
Z3B=""
[ "$(z3 state on)"    = "rc=0" ] || Z3B="$Z3B state-on"
[ "$(z3 state off)"   = "rc=1" ] || Z3B="$Z3B state-off"
[ "$(z3 state dead)"  = "rc=2" ] || Z3B="$Z3B state-dead"
[ "$(z3 state empty)" = "rc=2" ] || Z3B="$Z3B state-empty"
[ "$(z3 on on)"       = "on=T" ] || Z3B="$Z3B pred-on"
[ "$(z3 on off)"      = "on=F" ] || Z3B="$Z3B pred-on-off"
[ "$(z3 on dead)"     = "on=F" ] || Z3B="$Z3B pred-on-dead"
[ "$(z3 off off)"     = "off=T" ] || Z3B="$Z3B pred-off"
[ "$(z3 off dead)"    = "off=F" ] || Z3B="$Z3B pred-off-dead"
[ "$(z3 disable on)"  = "dis=0" ] || Z3B="$Z3B disable-ok"
[ "$(z3 disable on failno)" = "dis=1" ] || Z3B="$Z3B disable-failno"
_o=$(z3 enable off failsave1)
printf '%s' "$_o" | grep -q 'en=1' || Z3B="$Z3B enable-failsave1-rc"
printf '%s' "$_o" | grep -q 'Override отключён' || Z3B="$Z3B enable-откат-не-подтверждён-текстом"
[ "$(cat "$Z3/mode")" = off ] || Z3B="$Z3B enable-откат-не-исполнен"
_o=$(z3 enable off failsave)
printf '%s' "$_o" | grep -q 'en=1' || Z3B="$Z3B enable-failsave-rc"
printf '%s' "$_o" | grep -q 'МОЖЕТ остаться включённым' || Z3B="$Z3B enable-нет-честного-вердикта"
[ "$(z3 enable off none)" = "en=0" ] || Z3B="$Z3B enable-happy"
if [ -z "$Z3B" ]; then
    ok "Z38-3: _kz_dns_override_state 0/1/2 (захват вывода ndmc), предикаты fail-closed на UNKNOWN, disable проверяем, enable save-fail → проверяемый откат с честным вердиктом (FB-104/FB-105)"
else
    bad "Z38-3:$Z3B"
fi

# Z38-4 (FB-106, аудит-38): self_revert в проваленных путях
# финализатора (бэкап-fail, ensure_local_resolver-fail) + явные
# тексты «сознательная политика» в rc=2-путях.
Z4B=""
_l_bak=$(grep -n 'Не удалось создать бэкап resolv.conf' "$DEP" | head -1 | cut -d: -f1)
_l_sr1=$(awk -v s="$_l_bak" 'NR>s && /_kz_dns_self_revert/ {print NR; exit}' "$DEP")
{ [ -n "$_l_bak" ] && [ -n "$_l_sr1" ] && [ $((_l_sr1 - _l_bak)) -le 20 ]; } \
    || Z4B="$Z4B нет-self-revert-в-бэкап-fail"
_l_ens=$(grep -n 'Не удалось установить nameserver 127.0.0.1' "$DEP" | head -1 | cut -d: -f1)
_l_sr2=$(awk -v s="$_l_ens" 'NR>s && /_kz_dns_self_revert/ {print NR; exit}' "$DEP")
{ [ -n "$_l_ens" ] && [ -n "$_l_sr2" ] && [ $((_l_sr2 - _l_ens)) -le 25 ]; } \
    || Z4B="$Z4B нет-self-revert-в-ensure-fail"
[ "$(grep -c 'сознательная политика' "$DEP")" -ge 2 ] \
    || Z4B="$Z4B нет-текстов-о-сознательной-политике"
if [ -z "$Z4B" ]; then
    ok "Z38-4: финализатор: бэкап-fail и ensure-fail откатывают включённый этим запуском Override (self_revert); rc=2-пути — без отката, с явным текстом «сознательная политика» (FB-106)"
else
    bad "Z38-4:$Z4B"
fi

# Z38-5 (FB-107, аудит-38): _preflight_hysteria — корень-не-объект
# → ValueError (не AttributeError).
Z5="$F/z38p"; mkdir -p "$Z5"
printf 'LOG_FILE="/tmp/z38p.log"\npaths = {"error_log": "/tmp/z38p.err"}\n' > "$Z5/bot_config.py"
python3 - "$K" "$Z5" > "$Z5/out.txt" 2>&1 <<'PY5'
import importlib.util, sys, json, tempfile, os
kz, z5 = sys.argv[1], sys.argv[2]
sys.path.insert(0, z5)
spec = importlib.util.spec_from_file_location('u', kz + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
for root, name in ([], 'list'), (None, 'null'), ('x', 'string'), (42, 'int'):
    with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f:
        json.dump(root, f); p = f.name
    try:
        u._preflight_hysteria(p)
        print('FAIL', name, 'прошёл')
    except ValueError:
        print('ok', name, 'ValueError')
    except AttributeError as e:
        print('FAIL', name, 'AttributeError:', e)
    os.unlink(p)
PY5
if ! grep -q '^FAIL' "$Z5/out.txt" && [ "$(grep -c '^ok' "$Z5/out.txt")" = 4 ]; then
    ok "Z38-5: _preflight_hysteria: корень []/null/«строка»/число → ValueError «корень JSON должен быть объектом», не AttributeError (FB-107)"
else
    bad "Z38-5: $(tr '\n' ';' < "$Z5/out.txt")"
fi

# Z38-6 (FB-110, аудит-38): S57 без common.sh → fail-closed SKIP,
# grep-fallback изъят.
Z6="$F/z38s"; mkdir -p "$Z6"
awk '/^_kz_hy_cfg=/{f=1} f{print} f&&/^esac$/{exit}' \
    "$K/opt/etc/init.d/S57hysteria" > "$Z6/s57.fn"
printf '%s' '{"server":"real.org:443","auth":"secret","tcpRedirect":{},"udpTProxy":{}}' > "$Z6/c.json"
cat > "$Z6/run.sh" <<'R6'
#!/bin/sh
DESC=hysteria
. "$S57FN"
R6
Z6B=""
_o=$(KEENZOO_HYSTERIA_COMMON=/nonexistent-z38 \
     KEENZOO_HYSTERIA_CONFIG="$Z6/c.json" \
     S57FN="$Z6/s57.fn" sh "$Z6/run.sh" start 2>&1)
printf '%s' "$_o" | grep -q 'SKIPPED: validator common.sh missing' \
    || Z6B="$Z6B нет-SKIP-валидатора('$_o')"
grep -q 'validator common.sh missing' "$K/opt/etc/init.d/S57hysteria" \
    || Z6B="$Z6B нет-текста-в-S57"
grep -q 'прежний grep-путь' "$K/opt/etc/init.d/S57hysteria" \
    && Z6B="$Z6B grep-fallback-остался-в-комментариях"
if [ -z "$Z6B" ]; then
    ok "Z38-6: S57 при отсутствии common.sh → SKIPPED: validator common.sh missing (fail-closed, вариант А), grep-fallback изъят (FB-110/K63-05)"
else
    bad "Z38-6:$Z6B"
fi

# Z38-7 (FB-111, аудит-38): server+auth одним субшеллом; LF-гейт
# не даёт auth принять значение server при срезанном хвостовом
# переводе строки.
Z7="$F/z38n"; mkdir -p "$Z7"
awk 'index($0, "_nk_root_two() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$Z7/nk.sh"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$Z7/nk.sh"
printf '%s' '{"server":"real.example.org:443","auth":"realkey"}' > "$Z7/valid.json"
printf '%s' '{"server":"real.example.org:443"}' > "$Z7/noauth.json"
printf '%s' '{"server":"real.example.org:443","auth":"a","auth":"b"}' > "$Z7/dupe.json"
printf '%s' '{"server":"real.example.org:443","auth":"k","serv\u0065r":"x"}' > "$Z7/kesc.json"
Z7B=""
grep -q '_nk_root_val "' "$DEP" && Z7B="$Z7B старый-хелпер-остался"
z7() { # файл ожидание-rc метка
    _o=$(KEENZOO_DEPLOY_COMMON="$K/opt/bin/common.sh" \
         sh -c ". '$Z7/nk.sh'; needs_key '$1' hysteria </dev/null"; echo "rc=$?")
    printf '%s' "$_o" | grep -q "rc=$2" || Z7B="$Z7B $3"
}
z7 "$Z7/valid.json" 1 настроен
z7 "$Z7/noauth.json" 0 нет-auth-LF-гейт
z7 "$Z7/dupe.json" 0 дубликат
z7 "$Z7/kesc.json" 0 escape-имя
if [ -z "$Z7B" ]; then
    ok "Z38-7: needs_key: один субшелл _nk_root_two на server+auth, LF-гейт (\$(…) срезает хвост) не подставляет server в auth, _nk_root_val изъят (FB-111)"
else
    bad "Z38-7:$Z7B"
fi


# ════ Z39: аудит-39 (внешние отчёты по r64) ════

# Z39-1 (FB-112, P1-01): step DNS Override под set -eu — OFF/UNKNOWN
# не убивают shell, доходят до своих веток; ON подтверждается.
Z39="$F/z39"; mkdir -p "$Z39/bin"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_step() {")==1{p=0} p{print}' "$DEP" > "$Z39/fns.sh"
awk 'index($0, "_kz_dns_override_step() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" >> "$Z39/fns.sh"
cat > "$Z39/bin/ndmc" <<'N91'
#!/bin/sh
D=/tmp/f47chk/z39
m="$(cat "$D/mode" 2>/dev/null || echo ok)"
case "$1 $2" in
  "-c show running-config")
    case "$m" in
      on)  printf 'interface Bridge0\n opkg dns-override\n'; exit 0 ;;
      off) printf 'interface Bridge0\n'; exit 0 ;;
      *)   exit 1 ;;
    esac ;;
esac
exit 1
N91
chmod +x "$Z39/bin/ndmc"
cat > "$Z39/run.sh" <<'R91'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
have_cmd() { command -v "$1" >/dev/null 2>&1; }
_kz_dns_live() { return 0; }
_kz_required_missing() { echo ""; }
. "$Z39FN"
DNS_OVERRIDE_OK=0
DNS_OVERRIDE_SELF=0
_kz_dns_override_step
echo "STEP_DONE OK=$DNS_OVERRIDE_OK"
R91
Z39B=""
z39run() { # shell-строка режим ожидание-подстрока метка
    _sh="$1"
    echo "$2" > "$Z39/mode"
    _o=$(PATH="$Z39/bin:$PATH" Z39FN="$Z39/fns.sh" $_sh "$Z39/run.sh" </dev/null 2>&1); _rc=$?
    [ "$_rc" = 0 ] || Z39B="$Z39B $4-убил-shell(rc=$_rc)"
    printf '%s' "$_o" | grep -q "$3" || Z39B="$Z39B $4-нет-«$3»"
    printf '%s' "$_o" | grep -q 'STEP_DONE' || Z39B="$Z39B $4-не-дошёл-до-конца"
}
for _z39sh in "busybox ash" dash; do
    z39run "$_z39sh" off  'DNS Override не включён'        off
    z39run "$_z39sh" dead 'определить не удалось'          unknown
    z39run "$_z39sh" on   'уже включён'                    on
done
# ON-ветка обязана выставить OK=1
echo on > "$Z39/mode"
_o=$(PATH="$Z39/bin:$PATH" Z39FN="$Z39/fns.sh" sh "$Z39/run.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'STEP_DONE OK=1' || Z39B="$Z39B on-OK-не-1"
# регресс-гейт P1-01: в deploy не осталось голых вызовов tri-state
[ "$(grep -cE '^[[:space:]]+_kz_dns_override_state$' "$DEP")" = 0 ] \
    || Z39B="$Z39B голый-вызов-остался"
if [ -z "$Z39B" ]; then
    ok "Z39-1: step под set -eu (busybox ash + dash): OFF → подсказки без действий, UNKNOWN → честный отказ, ON → OK=1; все ветки до конца, rc=0; голых вызовов tri-state в deploy нет (FB-112/P1-01)"
else
    bad "Z39-1:$Z39B"
fi

# Z39-2 (FB-113, P1-02/K64-01): транзакционный enable — post-save
# UNKNOWN → проверяемый откат; подтверждённый OFF → честный отказ;
# ownership SELF по стадиям.
Z40="$F/z40"; mkdir -p "$Z40/bin"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_step() {")==1{p=0} p{print}' "$DEP" > "$Z40/fns.sh"
cat > "$Z40/bin/ndmc" <<'N92'
#!/bin/sh
D=/tmp/f47chk/z40
m="$(cat "$D/mode" 2>/dev/null || echo ok)"
f="$(cat "$D/failspec" 2>/dev/null || echo none)"
case "$1 $2" in
  "-c show running-config")
    case "$m" in
      on)  { [ "$f" = readback ] || [ "$f" = rbno ]; } && exit 1
           printf 'interface Bridge0\n opkg dns-override\n'; exit 0 ;;
      off) printf 'interface Bridge0\n'; exit 0 ;;
    esac ;;
  "-c opkg dns-override")
    [ "$f" = noop ] || echo on > "$D/mode"
    exit 0 ;;
  "-c no opkg dns-override")
    { [ "$f" = failno ] || [ "$f" = rbno ]; } && exit 1
    echo off > "$D/mode"; exit 0 ;;
  "-c system configuration save") exit 0 ;;
esac
exit 1
N92
chmod +x "$Z40/bin/ndmc"
cat > "$Z40/run.sh" <<'R92'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
. "$Z40FN"
DNS_OVERRIDE_OK=0
DNS_OVERRIDE_SELF=0
if _kz_dns_override_enable; then echo "EN=0"; else echo "EN=1"; fi
echo "mode=$(cat /tmp/f47chk/z40/mode) SELF=$DNS_OVERRIDE_SELF"
R92
z40run() { # failspec ожидание-строки...
    echo "$1" > "$Z40/failspec"; echo off > "$Z40/mode"
    PATH="$Z40/bin:$PATH" Z40FN="$Z40/fns.sh" sh "$Z40/run.sh" </dev/null 2>&1
}
Z40B=""
_o=$(z40run readback)
printf '%s' "$_o" | grep -q 'EN=1' || Z40B="$Z40B readback-не-rc1"
printf '%s' "$_o" | grep -q 'откат из предположения' || Z40B="$Z40B readback-нет-текста-отката"
printf '%s' "$_o" | grep -q 'Override отключён — системный DNS Keenetic снова' || Z40B="$Z40B readback-откат-не-подтверждён-текстом"
printf '%s' "$_o" | grep -q 'mode=off SELF=0' || Z40B="$Z40B readback-итог($_o)"
_o=$(z40run rbno)
printf '%s' "$_o" | grep -q 'EN=1' || Z40B="$Z40B rbno-не-rc1"
printf '%s' "$_o" | grep -q 'МОЖЕТ остаться включённым' || Z40B="$Z40B rbno-нет-честного-вердикта"
printf '%s' "$_o" | grep -q 'mode=on SELF=1' || Z40B="$Z40B rbno-ownership-потерян($_o)"
# FB-117 (аудит-40, K65-01): readback без директивы после ПРИМЕНЁННОЙ
# команды включения — НЕ «состояние не изменено»: rc=0 с нераспознанным
# выводом неотличим от реального OFF (воспроизведено внешним аудитом r65:
# «ERROR: …» rc=0 → ложный OFF → unowned ON). Ожидание: неоднозначность
# + проверяемый откат, SELF=0 только после подтверждения.
_o=$(z40run noop)
printf '%s' "$_o" | grep -q 'EN=1' || Z40B="$Z40B noop-не-rc1"
printf '%s' "$_o" | grep -q 'состояние неоднозначно' || Z40B="$Z40B noop-нет-неоднозначности(FB-117)"
printf '%s' "$_o" | grep -q 'проверяемый откат к подтверждённому OFF' || Z40B="$Z40B noop-нет-отката(FB-117)"
printf '%s' "$_o" | grep -q 'состояние роутера не изменено' && Z40B="$Z40B noop-старый-текст-остался"
printf '%s' "$_o" | grep -q 'mode=off SELF=0' || Z40B="$Z40B noop-итог($_o)"
_o=$(z40run none)
printf '%s' "$_o" | grep -q 'EN=0' || Z40B="$Z40B happy-не-rc0"
printf '%s' "$_o" | grep -q 'mode=on SELF=1' || Z40B="$Z40B happy-нет-ownership($_o)"
if [ -z "$Z40B" ]; then
    ok "Z39-2: enable транзакция: post-save UNKNOWN → проверяемый откат (mode=off, SELF=0) либо честный «МОЖЕТ остаться» (SELF=1); readback без директивы → неоднозначность и проверяемый откат (FB-117/K65-01, аудит-40); happy → rc0 SELF=1 (FB-113/P1-02/K64-01)"
else
    bad "Z39-2:$Z40B"
fi

# Z39-3 (FB-114, K64-02): config_has_placeholders — распарсенный
# не-dict корень = заглушка (паритет с preflight FB-107).
Z41="$F/z41"; mkdir -p "$Z41"
printf 'LOG_FILE="/tmp/f47chk/z41.log"\npaths = {"error_log": "/tmp/f47chk/z41.err"}\n' > "$Z41/bot_config.py"
python3 - "$K" "$Z41" > "$Z41/out.txt" 2>&1 <<'PY41'
import importlib.util, sys, tempfile, os
kz, z41 = sys.argv[1], sys.argv[2]
sys.path.insert(0, z41)
spec = importlib.util.spec_from_file_location('u', kz + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
cases = [
    ('valid-obj',  '{"server":"node.example.net:443","auth":"secret-01"}', False),
    ('root-array', '[{"server":"node.example.net:443","auth":"secret-01"}]', True),
    ('empty-arr',  '[]', True),
    ('null',       'null', True),
    ('int',        '42', True),
    ('string',     '"x"', True),
    ('broken',     '{"server":', True),
    ('stub-obj',   '{"server":"example.com","auth":"k"}', True),
]
for name, raw, want in cases:
    with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f:
        f.write(raw); p = f.name
    ph = u.config_has_placeholders(p, require_auth=True)
    print('ok' if ph == want else 'FAIL', name, ph)
    os.unlink(p)
# паритет: root-array отвергается preflight
with tempfile.NamedTemporaryFile('w', suffix='.json', delete=False) as f:
    f.write('[{"server":"node.example.net:443","auth":"secret-01"}]'); p = f.name
try:
    u._preflight_hysteria(p); print('FAIL preflight-принял-root-array')
except ValueError:
    print('ok preflight-REJ-root-array')
os.unlink(p)
PY41
if ! grep -q '^FAIL' "$Z41/out.txt" && [ "$(grep -c '^ok' "$Z41/out.txt")" = 9 ]; then
    ok "Z39-3: placeholders: root-array/[]/null/скаляры/битый → True (заглушка), валидный объект → False; preflight отвергает root-array — паритет (FB-114/K64-02)"
else
    bad "Z39-3: $(tr '\n' ';' < "$Z41/out.txt")"
fi

# Z39-4 (FB-113): финализатор при OK=0 — SELF=1 откатывает, SELF=0 нет.
Z42="$F/z42"; mkdir -p "$Z42/bin"
sed 's#z40#z42#g' "$Z40/bin/ndmc" > "$Z42/bin/ndmc"; chmod +x "$Z42/bin/ndmc"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_step() {")==1{p=0} p{print}' "$DEP" > "$Z42/fns.sh"
awk 'index($0, "_kz_dns_self_revert() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" >> "$Z42/fns.sh"
awk 'index($0, "_kz_resolver_finalize() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" \
    | sed "s#/etc/resolv.conf#$Z42/rc.conf#g" >> "$Z42/fns.sh"
cat > "$Z42/run.sh" <<'R92'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
. "$Z42FN"
: "${Z42DIR:=/tmp/f47chk/z42}"
_kz_dns_live() { return 0; }
_kz_dns_probe_local() { return 0; }
_kz_dns_probe_via_resolv() { return 0; }
ensure_local_resolver() { return 0; }
printf 'nameserver 192.168.1.1\n' > "$Z42DIR/rc.conf"
DNS_OVERRIDE_OK=0
DNS_OVERRIDE_SELF=$1
echo "$2" > /tmp/f47chk/z42/mode
echo none > /tmp/f47chk/z42/failspec
_kz_resolver_finalize
echo "mode=$(cat /tmp/f47chk/z42/mode)"
R92
Z42B=""
_o=$(PATH="$Z42/bin:$PATH" Z42DIR="$Z42" Z42FN="$Z42/fns.sh" sh "$Z42/run.sh" 1 on </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'DNS Override был включён этим запуском' || Z42B="$Z42B self1-нет-отката-текста"
printf '%s' "$_o" | grep -q 'mode=off' || Z42B="$Z42B self1-не-откачен"
_o=$(PATH="$Z42/bin:$PATH" Z42DIR="$Z42" Z42FN="$Z42/fns.sh" sh "$Z42/run.sh" 0 on </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'DNS Override был включён этим запуском' && Z42B="$Z42B self0-лишний-откат"
printf '%s' "$_o" | grep -q 'mode=on' || Z42B="$Z42B self0-тронут-чужой"
if [ -z "$Z42B" ]; then
    ok "Z39-4: финализатор при OK=0: SELF=1 → проверяемый откат (mode→off), SELF=0 → чужой Override не тронут (FB-113)"
else
    bad "Z39-4:$Z42B"
fi

# Z39-5 (FB-116): state — точная строка директивы; не-директивная
# подстрока → UNKNOWN; чистый конфиг → OFF; отказ/пусто → UNKNOWN.
Z43="$F/z43"; mkdir -p "$Z43/bin"
cat > "$Z43/bin/ndmc" <<'N93'
#!/bin/sh
D=/tmp/f47chk/z43
m="$(cat "$D/mode" 2>/dev/null || echo ok)"
case "$1 $2" in
  "-c show running-config")
    case "$m" in
      on)     printf 'interface Bridge0\n opkg dns-override\n'; exit 0 ;;
      off)    printf 'interface Bridge0\n'; exit 0 ;;
      dead)   exit 1 ;;
      noform) printf 'interface Bridge0\nno opkg dns-override\n'; exit 0 ;;
      foofrm) printf 'interface Bridge0\nopkg dns-override-foo\n'; exit 0 ;;
      indent) printf 'interface Bridge0\n    opkg dns-override  \n'; exit 0 ;;
    esac ;;
esac
exit 1
N93
chmod +x "$Z43/bin/ndmc"
Z43B=""
z43st() { # режим shell-строка ожидание
    _sh="$2"
    echo "$1" > "$Z43/mode"
    _r=$(PATH="$Z43/bin:$PATH" $_sh -c '. /tmp/f47chk/z43/fns.st; _kz_dns_override_state || echo $?' </dev/null 2>&1)
    [ "${_r:-0}" = "$3" ] || Z43B="$Z43B $1($_sh)=$_r"
}
cp "$Z40/fns.sh" "$Z43/fns.st"
for _z43sh in sh "busybox ash"; do
    z43st on     "$_z43sh" 0
    z43st off    "$_z43sh" 1
    z43st dead   "$_z43sh" 2
    z43st noform "$_z43sh" 2
    z43st foofrm "$_z43sh" 2
    z43st indent "$_z43sh" 0
done
if [ -z "$Z43B" ]; then
    ok "Z39-5: state (sh + busybox ash): точная строка (с отступами) → ON; «no opkg dns-override» и «opkg dns-override-foo» → UNKNOWN; чистый конфиг → OFF; отказ → UNKNOWN (FB-116)"
else
    bad "Z39-5:$Z43B"
fi

# Z39-6 (FB-115 + маркеры): комментарии Flask, маркеры FB-112/113/114/116.
Z44B=""
grep -q 'Flask 3.0.x' "$K/opt/etc/bot/main.py" || Z44B="$Z44B main-без-3.0.x"
grep -q 'Flask 3.0.x' "$K/opt/etc/bot/generator.py" || Z44B="$Z44B generator-без-3.0.x"
grep -q 'Flask 3.1+ требует Python 3.9+' "$K/opt/etc/bot/main.py" || Z44B="$Z44B main-без-3.9"
grep -q 'FB-112 (аудит-39' "$DEP" || Z44B="$Z44B нет-FB-112"
grep -q 'FB-113 (аудит-39' "$DEP" || Z44B="$Z44B нет-FB-113"
grep -q 'FB-116 (аудит-39' "$DEP" || Z44B="$Z44B нет-FB-116"
grep -q 'FB-114 (аудит-39' "$K/opt/etc/bot/utils.py" || Z44B="$Z44B нет-FB-114"
[ "$(grep -c '_kz_dns_override_state || _kz_st=\$?' "$DEP")" = 2 ] \
    || Z44B="$Z44B защищённых-вызовов-не-2"
grep -q 'DNS_OVERRIDE_SELF=1' "$DEP" || Z44B="$Z44B нет-ownership"
if [ -z "$Z44B" ]; then
    ok "Z39-6: Flask 3.0.x/3.9+ в комментариях main/generator; маркеры FB-112/113/114/116; 2 защищённых вызова tri-state; ownership SELF (FB-115 + маркеры)"
else
    bad "Z39-6:$Z44B"
fi



# ════ Z40: аудит-40 (внешние отчёты по r65) ════

# Z40-1 (FB-117, K65-01; FB-119): readback после применённого включения —
# проверяемый откат; инвариант «unowned ON невозможен» (никогда
# mode=on при SELF=0 на readback-путях) под set -eu в busybox ash + dash.
# FB-119 (аудит-41): диагностический stdout («ERROR:…» rc=0) теперь
# UNKNOWN — откат идёт веткой FB-113; чистый конфиг без директивы —
# ветка FB-117 (см. noop в Z39-2).
Z45="$F/z45"; mkdir -p "$Z45/bin"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_step() {")==1{p=0} p{print}' "$DEP" > "$Z45/fns.sh"
cat > "$Z45/bin/ndmc" <<'N45'
#!/bin/sh
D=/tmp/f47chk/z45
m="$(cat "$D/mode" 2>/dev/null || echo off)"
f="$(cat "$D/failspec" 2>/dev/null || echo none)"
case "$1 $2" in
  "-c show running-config")
    if [ "$m" = on ] && { [ "$f" = errtext ] || [ "$f" = errfail ]; }; then
      printf 'ERROR: fake control response unavailable\n'; exit 0
    fi
    case "$m" in
      on)  printf 'interface Bridge0\n opkg dns-override\n'; exit 0 ;;
      off) printf 'interface Bridge0\n'; exit 0 ;;
    esac ;;
  "-c opkg dns-override")
    [ "$f" = noop ] || echo on > "$D/mode"
    exit 0 ;;
  "-c no opkg dns-override")
    { [ "$f" = failno ] || [ "$f" = errfail ]; } && exit 1
    echo off > "$D/mode"; exit 0 ;;
  "-c system configuration save") exit 0 ;;
esac
exit 1
N45
chmod +x "$Z45/bin/ndmc"
cat > "$Z45/run.sh" <<'R45'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
. "$Z45FN"
DNS_OVERRIDE_OK=0
DNS_OVERRIDE_SELF=0
if _kz_dns_override_enable; then echo "EN=0"; else echo "EN=1"; fi
echo "RESULT mode=$(cat /tmp/f47chk/z45/mode) SELF=$DNS_OVERRIDE_SELF"
R45
z45run() { # shell failspec
    echo "$2" > "$Z45/failspec"; echo off > "$Z45/mode"
    PATH="$Z45/bin:$PATH" Z45FN="$Z45/fns.sh" $1 "$Z45/run.sh" </dev/null 2>&1
}
Z45B=""
for _z45sh in "busybox ash" dash; do
    _t=$(echo "$_z45sh" | tr ' ' '_')
    _o=$(z45run "$_z45sh" errtext)
    printf '%s' "$_o" | grep -q 'RESULT mode=off SELF=0' \
        || Z45B="$Z45B errtext-$_t-unowned-ON($_o)"
    printf '%s' "$_o" | grep -q 'вывод не распознан' \
        || Z45B="$Z45B errtext-$_t-мусор-не-классифицирован(FB-119)"
    printf '%s' "$_o" | grep -q 'откат из предположения' \
        || Z45B="$Z45B errtext-$_t-нет-отката-UNKNOWN-ветки"
    printf '%s' "$_o" | grep -q 'Override отключён — системный DNS Keenetic снова' \
        || Z45B="$Z45B errtext-$_t-откат-не-подтверждён"
    printf '%s' "$_o" | grep -q 'состояние роутера не изменено' \
        && Z45B="$Z45B errtext-$_t-старый-текст"
    _o=$(z45run "$_z45sh" errfail)
    printf '%s' "$_o" | grep -q 'RESULT mode=on SELF=1' \
        || Z45B="$Z45B errfail-$_t-владелец-потерян($_o)"
    printf '%s' "$_o" | grep -q 'МОЖЕТ остаться включённым' \
        || Z45B="$Z45B errfail-$_t-нет-честного-вердикта"
done
if [ -z "$Z45B" ]; then
    ok "Z40-1: enable readback: диагностический stdout («ERROR:…» rc=0, K65-01/K66-01) → UNKNOWN-ветка FB-113 с проверяемым откатом → mode=off SELF=0; откат-провал → «МОЖЕТ остаться» mode=on SELF=1 — unowned ON невозможен (busybox ash + dash, set -eu; FB-117/FB-119)"
else
    bad "Z40-1:$Z45B"
fi

# Z40-2 (FB-118, K65-02): финализатор — судьба порта 53 по факту
# (rv self_revert + DNS_OVERRIDE_LAST); «за системным DNS» — только при
# подтверждённом OFF; негативные утверждения на ложные тексты.
Z46="$F/z46"; mkdir -p "$Z46/bin"
sed 's#z45#z46#g' "$Z45/bin/ndmc" > "$Z46/bin/ndmc"; chmod +x "$Z46/bin/ndmc"
cat "$Z45/fns.sh" > "$Z46/fns.sh"
awk 'index($0, "_kz_dns_self_revert() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" >> "$Z46/fns.sh"
awk 'index($0, "_kz_resolver_finalize() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" \
    | sed "s#/etc/resolv.conf#$Z46/rc.conf#g" >> "$Z46/fns.sh"
cat > "$Z46/run.sh" <<'R46'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
. "$Z46FN"
_kz_dns_live() { [ "${Z46LIVE:-0}" = 1 ]; }
_kz_dns_probe_local() { return "${Z46PL:-0}"; }
_kz_dns_probe_via_resolv() { return 0; }
ensure_local_resolver() { return 0; }
printf 'nameserver 192.168.1.1\n' > "$Z46DIR/rc.conf"
DNS_OVERRIDE_OK="${Z46OK:-0}"
DNS_OVERRIDE_SELF="${Z46SELF:-0}"
DNS_OVERRIDE_LAST="${Z46LAST:-2}"
echo "${Z46MODE:-off}" > /tmp/f47chk/z46/mode
echo none > /tmp/f47chk/z46/failspec
[ "${Z46FAILNO:-0}" = 1 ] && echo failno > /tmp/f47chk/z46/failspec
_kz_resolver_finalize
echo "FINAL_DONE mode=$(cat /tmp/f47chk/z46/mode)"
R46
z46run() { # ok self live pl mode failno last
    Z46OK="$1" Z46SELF="$2" Z46LIVE="$3" Z46PL="$4" Z46MODE="$5" Z46FAILNO="$6" \
    Z46LAST="$7" Z46DIR="$Z46" Z46FN="$Z46/fns.sh" \
    PATH="$Z46/bin:$PATH" sh "$Z46/run.sh" </dev/null 2>&1
}
z46lie() { # вывод → 0/1: есть ли запрещённое утверждение
    printf '%s' "$1" | grep -q 'порт 53 остаётся за системным DNS\|Системный DNS Keenetic продолжает обслуживать'
}
Z46B=""
_o=$(z46run 0 1 1 0 on 1 0)   # A: OK=0, свой, откат-провал
z46lie "$_o" && Z46B="$Z46B A-ложное-утверждение"
printf '%s' "$_o" | grep -q 'Откат Override НЕ подтверждён' || Z46B="$Z46B A-нет-честного-вердикта"
printf '%s' "$_o" | grep -q 'FINAL_DONE mode=on' || Z46B="$Z46B A-не-тот-режим"
_o=$(z46run 0 1 1 0 on 0 0)   # B: OK=0, свой, откат-ok
printf '%s' "$_o" | grep -q 'Override откачен — порт 53 за системным DNS' \
    || Z46B="$Z46B B-нет-утверждения-после-подтверждённого-отката"
printf '%s' "$_o" | grep -q 'FINAL_DONE mode=off' || Z46B="$Z46B B-не-откачен"
_o=$(z46run 0 0 1 0 on 0 0)   # C: чужой ON
z46lie "$_o" && Z46B="$Z46B C-ложное-утверждение"
printf '%s' "$_o" | grep -q 'включён ДО этого запуска' || Z46B="$Z46B C-чужой-ON-не-назван"
printf '%s' "$_o" | grep -q 'FINAL_DONE mode=on' || Z46B="$Z46B C-чужой-тронут"
_o=$(z46run 0 0 1 0 dead 0 2) # D: UNKNOWN
z46lie "$_o" && Z46B="$Z46B D-ложное-утверждение"
printf '%s' "$_o" | grep -q 'состояние DNS Override не подтверждено' || Z46B="$Z46B D-нет-нейтрального-текста"
_o=$(z46run 0 0 1 0 off 0 1)  # E: подтверждённый OFF, ничего не меняли
printf '%s' "$_o" | grep -q 'порт 53 остаётся за системным DNS Keenetic (opkg dns-override' \
    || Z46B="$Z46B E-нет-разрешённого-утверждения"
_o=$(z46run 1 1 0 0 on 1 0)   # F: ветка dnsmasq-мёртв, свой, откат-провал
z46lie "$_o" && Z46B="$Z46B F-ложное-утверждение"
printf '%s' "$_o" | grep -q 'Откат Override НЕ подтверждён' || Z46B="$Z46B F-нет-честного-вердикта"
_o=$(z46run 1 0 0 0 on 0 0)   # G: ветка dnsmasq-мёртв, чужой ON
z46lie "$_o" && Z46B="$Z46B G-ложное-утверждение"
printf '%s' "$_o" | grep -q 'включён ДО этого запуска' || Z46B="$Z46B G-чужой-ON-не-назван"
_o=$(z46run 1 0 0 0 off 0 1)  # H: ветка dnsmasq-мёртв, подтверждённый OFF
printf '%s' "$_o" | grep -q 'Системный DNS Keenetic продолжает обслуживать роутер' \
    || Z46B="$Z46B H-нет-разрешённого-утверждения"
_o=$(z46run 1 1 1 1 on 1 0)   # I: ветка probe-fail, свой, откат-провал
z46lie "$_o" && Z46B="$Z46B I-ложное-утверждение"
_o=$(z46run 1 0 1 1 on 0 0)   # J: ветка probe-fail, чужой ON
z46lie "$_o" && Z46B="$Z46B J-ложное-утверждение"
printf '%s' "$_o" | grep -q 'НЕ за системным DNS' || Z46B="$Z46B J-чужой-ON-не-назван"
_o=$(z46run 1 0 1 1 off 0 1)  # K: ветка probe-fail, подтверждённый OFF
printf '%s' "$_o" | grep -q 'Системный DNS Keenetic продолжает обслуживать роутер' \
    || Z46B="$Z46B K-нет-разрешённого-утверждения"
if [ -z "$Z46B" ]; then
    ok "Z40-2: финализатор state-aware (3 ветки × rv/LAST, 11 сценариев): «за системным DNS» только при подтверждённом OFF; откат-провал → честный вердикт; чужой ON назван; UNKNOWN → нейтральный текст (FB-118/K65-02)"
else
    bad "Z40-2:$Z46B"
fi

# Z40-3 (FB-118, инфраструктура): tri-state self_revert поведенчески +
# гейты защищённой формы + DNS_OVERRIDE_LAST пишется state.
Z47="$F/z47"; mkdir -p "$Z47/bin"
sed 's#z45#z47#g' "$Z45/bin/ndmc" > "$Z47/bin/ndmc"; chmod +x "$Z47/bin/ndmc"
cp "$Z46/fns.sh" "$Z47/fns.sh"
cat > "$Z47/run.sh" <<'R47'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
. "$Z47FN"
DNS_OVERRIDE_SELF="$1"
echo "${2:-on}" > /tmp/f47chk/z47/mode
echo "${3:-none}" > /tmp/f47chk/z47/failspec
_z_rv=0
_kz_dns_self_revert || _z_rv=$?
echo "REVERT_RC=$_z_rv mode=$(cat /tmp/f47chk/z47/mode)"
R47
Z47B=""
for _z47sh in "busybox ash" dash; do
    _t=$(echo "$_z47sh" | tr ' ' '_')
    _o=$(PATH="$Z47/bin:$PATH" Z47FN="$Z47/fns.sh" $_z47sh "$Z47/run.sh" 0 on none </dev/null 2>&1)
    printf '%s' "$_o" | grep -q 'REVERT_RC=0 mode=on' || Z47B="$Z47B rc0-$_t"
    _o=$(PATH="$Z47/bin:$PATH" Z47FN="$Z47/fns.sh" $_z47sh "$Z47/run.sh" 1 on none </dev/null 2>&1)
    printf '%s' "$_o" | grep -q 'REVERT_RC=1 mode=off' || Z47B="$Z47B rc1-$_t"
    _o=$(PATH="$Z47/bin:$PATH" Z47FN="$Z47/fns.sh" $_z47sh "$Z47/run.sh" 1 on failno </dev/null 2>&1)
    printf '%s' "$_o" | grep -q 'REVERT_RC=2 mode=on' || Z47B="$Z47B rc2-$_t"
done
# гейты защищённой формы (правило FB-112 распространено на self_revert)
[ "$(grep -cE '^[[:space:]]+_kz_dns_self_revert$' "$DEP")" = 0 ] \
    || Z47B="$Z47B голый-вызов-остался"
[ "$(grep -c '_kz_dns_self_revert || _kz_rv=\$?' "$DEP")" = 3 ] \
    || Z47B="$Z47B rv-форм-не-3"
[ "$(grep -c '_kz_dns_self_revert || true' "$DEP")" = 3 ] \
    || Z47B="$Z47B true-форм-не-3"
[ "$(grep -c 'DNS_OVERRIDE_LAST=' "$DEP")" = 7 ] \
    || Z47B="$Z47B LAST-присваиваний-не-7"
[ "$(grep -c '${DNS_OVERRIDE_LAST:-2}' "$DEP")" = 6 ] \
    || Z47B="$Z47B LAST-чтений-не-6"
grep -q 'FB-117 (аудит-40' "$DEP" || Z47B="$Z47B нет-FB-117"
grep -q 'FB-118 (аудит-40' "$DEP" || Z47B="$Z47B нет-FB-118"
# DNS_OVERRIDE_LAST пишется state (OFF/ON/UNKNOWN)
echo off > "$Z47/mode"
_o=$(PATH="$Z47/bin:$PATH" sh -c ". '$Z47/fns.sh'; _kz_dns_override_state; echo L=\$DNS_OVERRIDE_LAST" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'L=1' || Z47B="$Z47B state-OFF-не-пишет-LAST"
echo on > "$Z47/mode"
_o=$(PATH="$Z47/bin:$PATH" sh -c ". '$Z47/fns.sh'; _kz_dns_override_state; echo L=\$DNS_OVERRIDE_LAST" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'L=0' || Z47B="$Z47B state-ON-не-пишет-LAST"
echo dead > "$Z47/mode"
_o=$(PATH="$Z47/bin:$PATH" sh -c ". '$Z47/fns.sh'; _kz_dns_override_state || true; echo L=\$DNS_OVERRIDE_LAST" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'L=2' || Z47B="$Z47B state-UNKNOWN-не-пишет-LAST"
if [ -z "$Z47B" ]; then
    ok "Z40-3: self_revert tri-state rc 0/1/2 (busybox ash + dash, set -eu); голых вызовов 0, «|| rv=\$?» ×3 + «|| true» ×3; DNS_OVERRIDE_LAST пишется state на всех выходах (OFF/ON/UNKNOWN) + сброс в начале шага — 7 присваиваний; маркеры FB-117/118 (FB-118/FB-120)"
else
    bad "Z40-3:$Z47B"
fi


# ════ Z41: аудит-41 (внешние отчёты r66) ════

# Z41-1 (FB-119): state — диагностический чёрный список: строка,
# начинающаяся со слова error/warn/usage (любой регистр/суффиксы) →
# UNKNOWN; приоритет ON (директива + ERROR-строка → ON); чистый
# конфиг → OFF; контракт FB-116 («no …» → UNKNOWN) жив.
Z48="$F/z48"; mkdir -p "$Z48/bin"
cat > "$Z48/bin/ndmc" <<'N48'
#!/bin/sh
D=/tmp/f47chk/z48
m="$(cat "$D/mode" 2>/dev/null || echo off)"
case "$1 $2" in
  "-c show running-config")
    case "$m" in
      err1)   printf 'ERROR: fake control response unavailable\n'; exit 0 ;;
      err2)   printf 'Error: minor\n'; exit 0 ;;
      err3)   printf 'error: lowercase\n'; exit 0 ;;
      warn1)  printf 'WARNING: degraded\n'; exit 0 ;;
      warn2)  printf 'warning: low memory\n'; exit 0 ;;
      usage1) printf 'Usage: ndmc [options]\n'; exit 0 ;;
      mixed)  printf 'interface Bridge0\nWARN: partial\n'; exit 0 ;;
      inderr) printf '   ERROR: indented\n'; exit 0 ;;
      onerr)  printf 'interface Bridge0\n opkg dns-override\nERROR: late\n'; exit 0 ;;
      off)    printf 'interface Bridge0\n'; exit 0 ;;
      noform) printf 'no opkg dns-override\n'; exit 0 ;;
    esac ;;
esac
exit 1
N48
chmod +x "$Z48/bin/ndmc"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_step() {")==1{p=0} p{print}' "$DEP" > "$Z48/fns.st"
Z48B=""
z48st() { # режим shell ожидание-rc
    _sh="$2"
    echo "$1" > "$Z48/mode"
    _r=$(PATH="$Z48/bin:$PATH" $_sh -c '. /tmp/f47chk/z48/fns.st; _kz_dns_override_state; echo rc=$?; echo L=$DNS_OVERRIDE_LAST' </dev/null 2>&1)
    printf '%s' "$_r" | grep -q "rc=$3" && printf '%s' "$_r" | grep -q "L=$3" \
        || Z48B="$Z48B $1($_sh)=$_r"
}
for _z48sh in sh "busybox ash"; do
    z48st err1   "$_z48sh" 2
    z48st err2   "$_z48sh" 2
    z48st err3   "$_z48sh" 2
    z48st warn1  "$_z48sh" 2
    z48st warn2  "$_z48sh" 2
    z48st usage1 "$_z48sh" 2
    z48st mixed  "$_z48sh" 2
    z48st inderr "$_z48sh" 2
    z48st onerr  "$_z48sh" 0
    z48st off    "$_z48sh" 1
    z48st noform "$_z48sh" 2
done
if [ -z "$Z48B" ]; then
    ok "Z41-1: state (sh + busybox ash): диагностические строки ERROR/Error/error/WARNING/warning/Usage (+отступ, mixed с конфигом) → UNKNOWN(2) LAST=2; директива + ERROR-строка → ON(0) — приоритет ON; чистый конфиг → OFF(1); «no opkg dns-override» → UNKNOWN — контракт FB-116 жив (FB-119)"
else
    bad "Z41-1:$Z48B"
fi

# Z41-2 (FB-119, K66-01): «no opkg» rc=0 БЕЗ применения + диагностический
# readback rc=0 → ложного «отключён» нет, ownership сохранён; финализатор
# без ложного утверждения о порте 53.
Z49="$F/z49"; mkdir -p "$Z49/bin"
cat > "$Z49/bin/ndmc" <<'N49'
#!/bin/sh
D=/tmp/f47chk/z49
m="$(cat "$D/mode" 2>/dev/null || echo off)"
f="$(cat "$D/failspec" 2>/dev/null || echo none)"
case "$f" in *showerr*) _se=1 ;; *) _se=0 ;; esac
case "$f" in *keepno*)  _kn=1 ;; *) _kn=0 ;; esac
case "$1 $2" in
  "-c show running-config")
    if [ "$m" = on ] && [ "$_se" = 1 ]; then
      printf 'ERROR: fake control response unavailable\n'; exit 0
    fi
    case "$m" in
      on)  printf 'interface Bridge0\n opkg dns-override\n'; exit 0 ;;
      off) printf 'interface Bridge0\n'; exit 0 ;;
    esac ;;
  "-c opkg dns-override")
    echo x >> "$D/enabled.calls"; echo on > "$D/mode"; exit 0 ;;
  "-c no opkg dns-override")
    echo x >> "$D/disabled.calls"
    [ "$_kn" = 1 ] && exit 0
    echo off > "$D/mode"; exit 0 ;;
  "-c system configuration save") exit 0 ;;
esac
exit 1
N49
chmod +x "$Z49/bin/ndmc"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_step() {")==1{p=0} p{print}' "$DEP" > "$Z49/fns.sh"
awk 'index($0, "_kz_dns_self_revert() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" >> "$Z49/fns.sh"
awk 'index($0, "_kz_resolver_finalize() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" \
    | sed "s#/etc/resolv.conf#$Z49/rc.conf#g" >> "$Z49/fns.sh"
cat > "$Z49/run_en.sh" <<'R49'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
. "$Z49FN"
DNS_OVERRIDE_OK=0
DNS_OVERRIDE_SELF=0
if _kz_dns_override_enable; then echo "EN=0"; else echo "EN=1"; fi
echo "RESULT mode=$(cat /tmp/f47chk/z49/mode) SELF=$DNS_OVERRIDE_SELF LAST=$DNS_OVERRIDE_LAST"
R49
cat > "$Z49/run_fin.sh" <<'R49'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
. "$Z49FN"
_kz_dns_live() { return 1; }
_kz_dns_probe_local() { return 0; }
_kz_dns_probe_via_resolv() { return 0; }
ensure_local_resolver() { return 0; }
printf 'nameserver 192.168.1.1\n' > "$Z49DIR/rc.conf"
DNS_OVERRIDE_OK=0
DNS_OVERRIDE_SELF=1
DNS_OVERRIDE_LAST=2
_kz_resolver_finalize
echo "FINAL mode=$(cat /tmp/f47chk/z49/mode)"
R49
Z49B=""
for _z49sh in "busybox ash" dash; do
    _t=$(echo "$_z49sh" | tr ' ' '_')
    echo "showerr keepno" > "$Z49/failspec"; echo off > "$Z49/mode"
    _o=$(PATH="$Z49/bin:$PATH" Z49FN="$Z49/fns.sh" $_z49sh "$Z49/run_en.sh" </dev/null 2>&1)
    printf '%s' "$_o" | grep -q 'EN=1' || Z49B="$Z49B en-$_t-не-rc1"
    printf '%s' "$_o" | grep -q 'Override отключён — системный DNS Keenetic снова' \
        && Z49B="$Z49B en-$_t-ложное-«отключён»"
    printf '%s' "$_o" | grep -q 'МОЖЕТ остаться включённым' \
        || Z49B="$Z49B en-$_t-нет-честного-вердикта"
    printf '%s' "$_o" | grep -q 'RESULT mode=on SELF=1' \
        || Z49B="$Z49B en-$_t-ownership-потерян($_o)"
    printf '%s' "$_o" | grep -q 'LAST=2' || Z49B="$Z49B en-$_t-LAST-не-2"
    echo "showerr keepno" > "$Z49/failspec"; echo on > "$Z49/mode"
    _o=$(PATH="$Z49/bin:$PATH" Z49FN="$Z49/fns.sh" Z49DIR="$Z49" $_z49sh "$Z49/run_fin.sh" </dev/null 2>&1)
    printf '%s' "$_o" | grep -q 'Откат Override НЕ подтверждён' \
        || Z49B="$Z49B fin-$_t-нет-честного-вердикта"
    printf '%s' "$_o" | grep -q 'порт 53 остаётся за системным DNS\|Системный DNS Keenetic продолжает обслуживать' \
        && Z49B="$Z49B fin-$_t-ложное-утверждение"
    printf '%s' "$_o" | grep -q 'FINAL mode=on' || Z49B="$Z49B fin-$_t-не-тот-режим"
done
if [ -z "$Z49B" ]; then
    ok "Z41-2: K66-01 (busybox ash + dash, set -eu): «no opkg» rc=0 без применения + «ERROR:…» rc=0 readback → НЕТ ложного «отключён», честное «МОЖЕТ остаться включённым», mode=on SELF=1 LAST=2 — ownership сохранён; финализатор — «Откат НЕ подтверждён», без ложного утверждения о порте 53 (FB-119)"
else
    bad "Z41-2:$Z49B"
fi

# Z41-3 (FB-119, P2-initial): чужой ON + диагностический первый readback →
# UNKNOWN-ветка шага: без предложения включения, без мутаций.
Z50="$F/z50"; mkdir -p "$Z50/bin"
sed 's#z49#z50#g' "$Z49/bin/ndmc" > "$Z50/bin/ndmc"; chmod +x "$Z50/bin/ndmc"
cat "$Z49/fns.sh" > "$Z50/fns_core.sh"
awk 'index($0, "_kz_dns_override_step() {")==1{p=1} p{print} p&&/^}$/{exit}' "$DEP" >> "$Z50/fns_core.sh"
cat > "$Z50/run.sh" <<'R50'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
have_cmd() { command -v "$1" >/dev/null 2>&1; }
_kz_dns_live() { return 0; }
_kz_required_missing() { echo ""; }
. "$Z50FN"
_kz_dns_override_step
echo "STEP_DONE OK=$DNS_OVERRIDE_OK SELF=$DNS_OVERRIDE_SELF LAST=$DNS_OVERRIDE_LAST mode=$(cat /tmp/f47chk/z50/mode)"
R50
Z50B=""
for _z50sh in "busybox ash" dash; do
    _t=$(echo "$_z50sh" | tr ' ' '_')
    echo showerr > "$Z50/failspec"; echo on > "$Z50/mode"
    : > "$Z50/enabled.calls"; : > "$Z50/disabled.calls"
    _o=$(PATH="$Z50/bin:$PATH" Z50FN="$Z50/fns_core.sh" $_z50sh "$Z50/run.sh" </dev/null 2>&1)
    printf '%s' "$_o" | grep -q 'определить не удалось' \
        || Z50B="$Z50B $_t-нет-UNKNOWN-ветки"
    printf '%s' "$_o" | grep -q 'вывод не распознан' \
        || Z50B="$Z50B $_t-мусор-не-классифицирован"
    printf '%s' "$_o" | grep -q 'Включить DNS Override сейчас\|системный DNS Keenetic остаётся на порту 53' \
        && Z50B="$Z50B $_t-ложная-OFF-ветка"
    printf '%s' "$_o" | grep -q 'STEP_DONE OK=0 SELF=0 LAST=2 mode=on' \
        || Z50B="$Z50B $_t-итог($_o)"
    [ -s "$Z50/enabled.calls" ] && Z50B="$Z50B $_t-был-вызов-включения"
    [ -s "$Z50/disabled.calls" ] && Z50B="$Z50B $_t-был-вызов-отключения"
done
if [ -z "$Z50B" ]; then
    ok "Z41-3: P2-initial (busybox ash + dash, non-tty): чужой ON + «ERROR:…» rc=0 на первой проверке → UNKNOWN-ветка («определить не удалось… вывод не распознан»), предложения включения НЕТ, ноль opkg-мутаций, LAST=2, чужой ON не тронут (FB-119)"
else
    bad "Z41-3:$Z50B"
fi

# Z41-4 (FB-120, P3): stale DNS_OVERRIDE_LAST из окружения + отсутствующий
# ndmc → шаг сбрасывает LAST=2 до ветки have_cmd; финализатор —
# нейтральный текст; статические гейты FB-119/FB-120.
Z51="$F/z51"; mkdir -p "$Z51"
cp "$Z50/fns_core.sh" "$Z51/fns.sh"
cat > "$Z51/run.sh" <<'R51'
#!/bin/sh
set -eu
warn() { printf '%s\n' "$*" >&2; }
have_cmd() { command -v "$1" >/dev/null 2>&1; }
_kz_dns_live() { return 0; }
_kz_required_missing() { echo ""; }
_kz_dns_probe_local() { return 0; }
_kz_dns_probe_via_resolv() { return 0; }
ensure_local_resolver() { return 0; }
printf 'nameserver 192.168.1.1\n' > "$Z51DIR/rc.conf"
. "$Z51FN"
_kz_dns_override_step
_kz_resolver_finalize
echo "DONE OK=$DNS_OVERRIDE_OK SELF=$DNS_OVERRIDE_SELF LAST=$DNS_OVERRIDE_LAST"
R51
Z51B=""
_o=$(DNS_OVERRIDE_LAST=0 PATH="/usr/bin:/bin" Z51FN="$Z51/fns.sh" Z51DIR="$Z51" sh "$Z51/run.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'ndmc не найден' || Z51B="$Z51B нет-ветки-отсутствия-ndmc"
printf '%s' "$_o" | grep -q 'DONE OK=0 SELF=0 LAST=2' || Z51B="$Z51B stale-LAST-не-сброшен($_o)"
printf '%s' "$_o" | grep -q 'включён ДО этого запуска' && Z51B="$Z51B ложный-диагноз-по-stale-env"
printf '%s' "$_o" | grep -q 'состояние DNS Override не подтверждено' \
    || Z51B="$Z51B нет-нейтрального-текста"
grep -q 'FB-119 (аудит-41' "$DEP" || Z51B="$Z51B нет-FB-119"
grep -q 'FB-120 (аудит-41' "$DEP" || Z51B="$Z51B нет-FB-120"
[ "$(grep -c 'DNS_OVERRIDE_LAST=' "$DEP")" = 7 ] \
    || Z51B="$Z51B LAST-присваиваний-не-7"
grep -q 'Ee.\[Rr\]' "$DEP" || Z51B="$Z51B нет-диагностического-грепа"
if [ -z "$Z51B" ]; then
    ok "Z41-4: stale DNS_OVERRIDE_LAST=0 из окружения + нет ndmc → шаг сбрасывает LAST=2 до ветки have_cmd, финализатор — нейтральный текст без «включён ДО этого запуска»; маркеры FB-119/120; LAST= ×7; диагностический греп на месте (FB-120)"
else
    bad "Z41-4:$Z51B"
fi


# ═══ Z42. Мини-аудит r68 (спиннер «Обновление…», FB-121/FB-124) ═══
# Z42-1 (FB-121): argv обёрток строго 3 элемента, значения через env;
# хвостовые argv-маркеры из исходника удалены; маркеры аудита на месте.
Z42A=$(grep -c 'keenzoo-update' "$GEN" || true)
Z42B=$(grep -c 'keenzoo-proto-update' "$GEN" || true)
Z42C=$(grep -cF "['/bin/sh', '-c', body]," "$GEN" || true)
Z42D=$(grep -c 'env={' "$GEN" || true)
Z42E=$(grep -c 'KZ_STATUS_FILE' "$GEN" || true)
Z42F=$(grep -c 'KZ_ACT' "$GEN" || true)
Z42G=$(grep -c 'FB-121 (аудит-42' "$GEN" || true)
Z42H=$(grep -c 'FB-124 (аудит-42' "$GEN" || true)
if [ "$Z42A" = 0 ] && [ "$Z42B" = 0 ] && [ "$Z42C" = 2 ] \
    && [ "$Z42D" = 2 ] && [ "$Z42E" = 2 ] && [ "$Z42F" = 4 ] \
    && [ "$Z42G" = 4 ] && [ "$Z42H" = 2 ]; then
    ok "Z42-1: FB-121 — argv обёрток 3-элементный ×2, значения через env (KZ_*), argv-маркеры keenzoo-*-update удалены; маркеры FB-121 ×4 / FB-124 ×2"
else
    bad "Z42-1: upd=$Z42A proto=$Z42B argv3=$Z42C env=$Z42D kzst=$Z42E kzsc=$Z42F fb121=$Z42G fb124=$Z42H"
fi

# Z42-2 (FB-121): обёртка протоколов в режиме «sh -c body без argv».
KF42="$(mktemp -d)"
python3 - "$GEN" > "$KF42/pbody.sh" <<'PYM42'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
bodies = re.findall('body = ' + Q + '(.*?)' + Q, src, re.S)
assert len(bodies) == 2, len(bodies)
sys.stdout.write(bodies[1])
PYM42
dash -n "$KF42/pbody.sh" 2>/dev/null
printf '#!/bin/sh\necho proto-out\nexit 0\n' > "$KF42/p.sh"
chmod +x "$KF42/p.sh"
KZ_SC="$KF42/p.sh" KZ_ACT=xray KZ_ST="$KF42/st.json" KZ_TMP="$KF42/tm" \
    sh -c "$(cat "$KF42/pbody.sh")" > "$KF42/run.log" 2>&1
Z42R=$?
if [ "$Z42R" = 0 ] && grep -q 'proto-out' "$KF42/run.log" \
    && grep -q '"status":"done"' "$KF42/st.json" \
    && grep -q '"action":"xray"' "$KF42/st.json" \
    && [ ! -e "$KF42/tm" ]; then
    ok "Z42-2: обёртка протоколов — env-значения без argv, done-статус с action, tmp потреблён (FB-121)"
else
    bad "Z42-2: rc=$Z42R st=$(cat "$KF42/st.json" 2>/dev/null)"
fi

# Z42-3 (FB-124): пустые KZ_* у обёртки обновления → error-статус, rc=3.
sed -n "/^ *body = '\{3\}/,/^'\{3\}$/p" "$GEN" \
    | sed "1s/^ *body = '\{3\}//; \$d" \
    | sed "s|/tmp/unblock_update_status.json|$KF42/guard.json|g" > "$KF42/gbody.sh"
env -i PATH="$PATH" sh -c "$(cat "$KF42/gbody.sh")" > "$KF42/grun.log" 2>&1
Z42G2=$?
if [ "$Z42G2" = 3 ] && grep -q '"status":"error"' "$KF42/guard.json" \
    && grep -q 'FB-124' "$KF42/guard.json" \
    && grep -Fq 'не получила KZ_*-переменные' "$KF42/grun.log"; then
    ok "Z42-3: FB-124 — env не дошёл → error-статус с маркером, rc=3, диагноз в stderr/логе обёртки"
else
    bad "Z42-3: rc=$Z42G2 guard=$(cat "$KF42/guard.json" 2>/dev/null)"
fi

# Z42-4 (FB-124): пустые KZ_* у обёртки протоколов → error-статус, rc=3.
sed "s|/tmp/proto_update_status.json|$KF42/pguard.json|g" \
    "$KF42/pbody.sh" > "$KF42/pgbody.sh"
env -i PATH="$PATH" sh -c "$(cat "$KF42/pgbody.sh")" > "$KF42/pgrun.log" 2>&1
Z42P=$?
if [ "$Z42P" = 3 ] && grep -q '"status":"error"' "$KF42/pguard.json" \
    && grep -q 'FB-124' "$KF42/pguard.json" \
    && grep -Fq 'не получила KZ_*-переменные' "$KF42/pgrun.log"; then
    ok "Z42-4: FB-124 (прото) — env не дошёл → error-статус, rc=3, диагноз в логе обёртки"
else
    bad "Z42-4: rc=$Z42P pguard=$(cat "$KF42/pguard.json" 2>/dev/null)"
fi
rm -rf "$KF42"


# ═══ Z43. Дашборд r69 (этап 1, «KeeneticOS Hybrid») ═══
# Z43-1 (статика): шаблон самодостаточен, маршруты и ветки на месте.
Q3="'''"
Z43A=$(grep -c "DASH_TEMPLATE = r$Q3" "$GEN" || true)
Z43B=$(grep -c 'id="dashRoot"' "$GEN" || true)
Z43C=$(grep -c '<meta name="kz-csrf"' "$GEN" || true)
Z43D=$(grep -c "/api/dashboard" "$GEN" || true)
Z43E=$(grep -c "/dash/update-lists" "$GEN" || true)
Z43F=$(grep -c "'tab', 'dash')" "$GEN" || true)
Z43G=$(grep -c "if active == 'dash':" "$GEN" || true)
Z43H=$(grep -cE '(src|href)="https?://' "$GEN" || true)
Z43I=$(grep -c 'Дашборд (этап 1' "$GEN" || true)
if [ "$Z43A" = 1 ] && [ "$Z43B" -ge 1 ] && [ "$Z43C" = 1 ] \
    && [ "$Z43D" -ge 1 ] && [ "$Z43E" -ge 2 ] && [ "$Z43F" = 1 ] \
    && [ "$Z43G" = 1 ] && [ "$Z43H" = 0 ] && [ "$Z43I" -ge 2 ]; then
    ok "Z43-1: DASH_TEMPLATE на месте (dashRoot, csrf-meta), маршруты /api/dashboard и /dash/update-lists, '/' открывает дашборд; внешних URL нет; маркеры этапа"
else
    bad "Z43-1: tpl=$Z43A root=$Z43B csrf=$Z43C api=$Z43D upd=$Z43E idx=$Z43F rnd=$Z43G ext=$Z43H mark=$Z43I"
fi

# Z43-2/Z43-3 (поведенческие): телеметрия на фикстурах + TTL-кэш.
python3 - "$K" "$F" > "$F/z43py.out" 2>&1 <<'PYZ43'
import os, sys
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)
D = os.path.join(F, 'z43'); os.makedirs(D, exist_ok=True)

open(os.path.join(D, 'uptime'), 'w').write('12345.67 23456.78\n')
open(os.path.join(D, 'stat1'), 'w').write('cpu  100 0 0 900 0 0 0 0\n')
open(os.path.join(D, 'stat2'), 'w').write('cpu  300 0 0 1700 0 0 0 0\n')
open(os.path.join(D, 'mem'), 'w').write(
    'MemTotal:       524288 kB\nMemFree:         100000 kB\n'
    'MemAvailable:   262144 kB\n')
open(os.path.join(D, 'route'), 'w').write(
    'Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\tMTU\tWindow\tIRTT\n'
    'eth9\t00000000\t0100A8C0\t0001\t0\t0\t10\t00000000\t0\t0\t0\n'
    'eth0\t00000000\t0100A8C0\t0003\t0\t0\t0\t00000000\t0\t0\t0\n'
    'br0\t00FCA8C0\t00000000\t0001\t0\t0\t0\t00FFFFFF\t0\t0\t0\n')
open(os.path.join(D, 'net1'), 'w').write(
    'Inter-|   Receive                                                |  Transmit\n'
    ' face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed\n'
    '  eth0: 1000 10 0 0 0 0 0 0  500 8 0 0 0 0 0 0\n'
    '  tun0: 99999 99 0 0 0 0 0 0 99999 99 0 0 0 0 0 0\n'
    '    lo: 5 5 0 0 0 0 0 0 5 5 0 0 0 0 0 0\n')
open(os.path.join(D, 'net2'), 'w').write(
    'Inter-|   Receive                                                |  Transmit\n'
    ' face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed\n'
    '  eth0: 3000 30 0 0 0 0 0 0 1500 16 0 0 0 0 0 0\n')
open(os.path.join(D, 'arp'), 'w').write(
    'IP address       HW type     Flags       HW address            Mask     Device\n'
    '192.168.1.76     0x1         0x2         aa:bb:cc:dd:ee:01    *        br0\n'
    '192.168.1.34     0x1         0x2         aa:bb:cc:dd:ee:02    *        br0\n'
    '192.168.1.50     0x1         0x6         aa:bb:cc:dd:ee:07    *        br0\n'
    '192.168.1.99     0x1         0x0         aa:bb:cc:dd:ee:03    *        br0\n'
    'битая-строка\n')
open(os.path.join(D, 'leases'), 'w').write(
    '1792900000 aa:bb:cc:dd:ee:01 192.168.1.76 iphone-elena 01:aa:bb:cc:dd:ee:01\n')

r = []
r.append(('uptime', g._proc_uptime(os.path.join(D, 'uptime')) == 12345.67))
s1 = g._proc_stat_totals(os.path.join(D, 'stat1'))
s2 = g._proc_stat_totals(os.path.join(D, 'stat2'))
r.append(('stat-срезы (total,idle)', s1 == (1000, 900) and s2 == (2000, 1700)))
r.append(('cpu-дельта 20%', g._cpu_pct(s1, s2) == 20.0))
m = g._meminfo_totals(os.path.join(D, 'mem'))
r.append(('meminfo', m == (524288, 262144, False)))  # FB-161: approx
r.append(('route: eth0 по флагу 0x2, не eth9/br0',
          g._proc_route_default_iface(os.path.join(D, 'route')) == 'eth0'))
n1 = g._proc_net_bytes(os.path.join(D, 'net1'))
n2 = g._proc_net_bytes(os.path.join(D, 'net2'))
r.append(('net/dev: lo/tun исключены', set(n1) == {'eth0'}))
rate = g._net_rate(n1, n2, 'eth0', 2.0)
r.append(('rate 8000/4000 bps', rate == (8000.0, 4000.0)))
dev = g._dash_devices(lease_paths=[os.path.join(D, 'leases')],
                      arp_path=os.path.join(D, 'arp'))
r.append(('устройства: 2 dyn + статик 0x6 (бит ATF_COM), incomplete/битая мимо',
          dev['count'] == 3 and dev['top'][0]['name'] == 'iphone-elena'
          and dev['top'][0]['ip'] == '192.168.1.76'
          and '192.168.1.50' in [d['ip'] for d in dev['top']]))
if all(v for _, v in r):
    ok('Z43-2: /proc-парсеры верны: uptime, stat-дельта 20%, meminfo, default-route по флагу, net/dev без lo/tun, rate (8000/4000 bps), устройства (leases+ARP, incomplete мимо)')
else:
    bad('Z43-2: ' + ', '.join(k for k, v in r if not v))

kw = dict(stat_path=os.path.join(D, 'stat1'),
          mem_path=os.path.join(D, 'mem'),
          net_path=os.path.join(D, 'net1'),
          route_path=os.path.join(D, 'route'),
          arp_path=os.path.join(D, 'arp'),
          lease_paths=[os.path.join(D, 'leases')])
a = g._dashboard_snapshot(force=True, **kw)
b = g._dashboard_snapshot(**kw)
same = a is b
KEYS = {'ts', 'uptime', 'host', 'arch', 'cpu_pct', 'ram', 'rate',
        'wan_up', 'devices', 'services', 'update', 'lists'}
contract = (set(a.keys()) == KEYS and a['wan_up'] is True
            and a['cpu_pct'] is None and a['ram']['used_kib'] == 262144
            and a['devices']['count'] == 3
            and isinstance(a['services'], dict)
            and isinstance(a['lists'], dict) and len(a['lists']) == 7)  # r89: +za
kw['stat_path'] = os.path.join(D, 'stat2')
kw['net_path'] = os.path.join(D, 'net2')
c = g._dashboard_snapshot(force=True, **kw)
deltas = (isinstance(c['cpu_pct'], (int, float)) and c['cpu_pct'] >= 0
          and c['rate']['down'] is not None and c['rate']['down'] > 0
          and c['rate']['iface'] == 'eth0')
if same and contract and deltas:
    ok('Z43-3: снапшот: TTL-кэш (тот же объект), контракт 12 ключей, RAM/устройства (вкл. статик 0x6)/wan_up из фикстур; повторный force даёт дельты CPU и rate по eth0')
else:
    bad('Z43-3: same=%s contract=%s deltas=%s' % (same, contract, deltas))
if _f[0] == 0:
    print('OK z43-2/3 (pass=%d)' % _p[0])
else:
    print('BAD z43-2/3 (pass=%d fail=%d)' % (_p[0], _f[0]))
PYZ43
grep -q '^OK ' "$F/z43py.out" \
    && ok "Z43-2/3: телеметрия /proc на фикстурах: uptime, stat-дельта 20%, meminfo, default-route по флагу, net/dev без lo/tun, rate 8000/4000 bps, устройства (leases+ARP); снапшот: TTL-кэш, контракт 12 ключей, дельты CPU/rate" \
    || bad "Z43-2/3: $(cat "$F/z43py.out")"

# Z43-4 (живой Flask-смоук в копии с настроенными кредами).
Z43D="$F/z43bot"
rm -rf "$Z43D"
cp -r "$K/opt/etc/bot" "$Z43D"
python3 - "$Z43D" > "$F/z43smoke.out" 2>&1 <<'PYZ44'
import base64, os, re, sys
B = sys.argv[1]
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g
c = g.app.test_client()
h = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
r1 = c.get('/', headers=h)
r2 = c.get('/?tab=ss', headers=h)
r2b = c.get('/panel?tab=ss', headers=h)
r3 = c.post('/dash/update-lists', headers=h)
r4 = c.get('/api/dashboard', headers=h)
# FB-125 (аудит-43): позитивный путь кнопки — валидный csrf + Origin,
# плюс 409-контракт занятости (RuntimeError -> JSON, не HTML-abort).
hh = dict(h); hh['Origin'] = 'http://localhost'
tok = re.search(r'<meta name="kz-csrf" content="([^"]*)"',
                r1.data.decode()).group(1)
_calls = []
def _apply_ok(only_sets=''):
    _calls.append(only_sets)
    return True
g.apply_unblock_async = _apply_ok
rp = c.post('/dash/update-lists', data={'csrf_token': tok}, headers=hh)
jp = rp.get_json() if rp.status_code == 200 else {}
def _busy(only_sets=''):
    raise RuntimeError('Уже (10с).')
g.apply_unblock_async = _busy
r409 = c.post('/dash/update-lists', data={'csrf_token': tok}, headers=hh)
j409 = r409.get_json()
KEYS = {'ts', 'uptime', 'host', 'arch', 'cpu_pct', 'ram', 'rate',
        'wan_up', 'devices', 'services', 'update', 'lists'}
j = r4.get_json() if r4.status_code == 200 else {}
ok = (r1.status_code == 200 and b'dashRoot' in r1.data
      and b'kz-csrf' in r1.data
      and r2.status_code == 200 and b'panelFrame' in r2.data
      and b'src="/panel?tab=ss"' in r2.data
      and r2b.status_code == 200 and b'KeenZOO Panel' in r2b.data
      and r3.status_code == 403
      and r4.status_code == 200 and set(j.keys()) == KEYS
      and rp.status_code == 200 and jp.get('started') is True
      and _calls == ['']
      and r409.status_code == 409 and j409.get('started') is False
      and isinstance(j409.get('message'), str))
if ok:
    print('OK dash=%s shell=%s panel=%s csrf403=%s api=%s keys=True pos=%s busy409=%s'
          % (r1.status_code, r2.status_code, r2b.status_code,
             r3.status_code, r4.status_code, rp.status_code, r409.status_code))
else:
    print('BAD dash=%s shell=%s panel=%s csrf403=%s api=%s keys=%s pos=%s(%s) busy=%s(%s)'
          % (r1.status_code, r2.status_code, r2b.status_code,
             r3.status_code, r4.status_code, set(j.keys()) == KEYS,
             rp.status_code, jp.get('started'), r409.status_code,
             j409.get('started')))
PYZ44
if grep -q '^OK ' "$F/z43smoke.out"; then
    ok "Z43-4: Flask-смоук: '/' рендерит дашборд (dashRoot+csrf), '?tab=ss' — MD3-оболочку с iframe /panel?tab=ss, '/panel?tab=ss' — прежнюю панель, POST без CSRF — 403; FB-125: валидный csrf+Origin — 200 {started:true}+запуск, занятость — 409 JSON {started:false,message}; /api/dashboard — полный контракт"
else
    bad "Z43-4: $(cat "$F/z43smoke.out")"
fi


# ═══ Z44. Аудит-43 + внешнее ревью r69 (r70): FB-125..129, K67-01..03 ═══
# Z44-1..4 (поведение): stale-статус, 409 живого pid, error-статус запуска,
# env-наследование обёрток, TTL-кэш dns-статуса.
python3 - "$K" "$F" > "$F/z44py.out" 2>&1 <<'PYZ44A'
import base64, json, os, subprocess, sys, tempfile, time
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)

D = os.path.join(F, 'z44'); os.makedirs(D, exist_ok=True)
g.UPDATE_STATUS_FILE = os.path.join(D, 'st.json')
g.UPDATE_LOG_FILE = os.path.join(D, 'up.log')
g.LOCK_DIR = os.path.join(D, 'lock')

# FB-126: stale вычисляется на чтении; файл не трогается.
def rd(st, off):
    with open(g.UPDATE_STATUS_FILE, 'w') as f:
        json.dump({'status': st, 'ts': int(time.time()) - off,
                   'message': 'x'}, f)
    return g._read_update_status()
chk('FB-126 stale у старого running', rd('running', 999).get('stale') is True)
chk('FB-126 свежий running без stale', rd('running', 2).get('stale') is None)
chk('FB-126 idle/done без stale',
    rd('idle', 999).get('stale') is None and rd('done', 999).get('stale') is None)
chk('FB-126 файл без stale-поля',
    'stale' not in json.load(open(g.UPDATE_STATUS_FILE)))

# FB-127/158: живой СВОЙ pid (unblock_update.sh в cmdline, exec -a)
# -> RuntimeError (409), статус и lock не тронуты. Проверка по
# getpid() после FB-158 законно идёт дальше: живой ЧУЖОЙ pid =
# переиспользованный, lock снимается (полная матрица — Z53-4).
_own = subprocess.Popen(
    ['bash', '-c', 'exec -a unblock_update.sh sleep 30'])
os.makedirs(g.LOCK_DIR, exist_ok=True)
rd('running', 999)
try:
    with open(os.path.join(g.LOCK_DIR, 'pid'), 'w') as f:
        f.write(str(_own.pid))
    _oex, _och, _op = os.path.exists, os.chmod, subprocess.Popen
    os.path.exists = lambda p: (True if p == '/opt/bin/unblock_update.sh'
                                else _oex(p))
    os.chmod = lambda p, m: (None if p == '/opt/bin/unblock_update.sh'
                             else _och(p, m))
    try:
        g.apply_unblock_async()
        chk('FB-127 живой свой pid: дубль запущен', False)
    except RuntimeError:
        pass
    chk('FB-127 статус не сброшен при живом pid',
        json.load(open(g.UPDATE_STATUS_FILE))['status'] == 'running')
    chk('FB-158 lock цел при живом своём pid',
        os.path.isdir(g.LOCK_DIR))
finally:
    _own.terminate(); _own.wait()

# FB-127: Popen-сбой -> атомарный error-статус.
class _Boom:
    def __init__(self, *a, **k):
        raise OSError('exec format error')
subprocess.Popen = _Boom
rd('idle', 0)
try:
    g.apply_unblock_async()
except OSError:
    pass
st = json.load(open(g.UPDATE_STATUS_FILE))
chk('FB-127 Popen-сбой -> error + диагноз',
    st['status'] == 'error' and 'запуск не удался' in st['message'])

# FB-129 (вариант A): окружение наследуется, argv строго 3.
class _Cap:
    last = None
    def __init__(self, argv, **k):
        self.argv = argv; self.env = k.get('env'); _Cap.last = self
os.environ['KEENZOO_F47PROBE'] = 'z44'
subprocess.Popen = _Cap
rd('idle', 0)
g.apply_unblock_async()
subprocess.Popen = _op
del os.environ['KEENZOO_F47PROBE']
chk('FB-129 env наследуется + KZ_* + argv 3',
    _Cap.last is not None
    and _Cap.last.env.get('KEENZOO_F47PROBE') == 'z44'
    and 'KZ_ONLY' in _Cap.last.env and 'KZ_STATUS_FILE' in _Cap.last.env
    and _Cap.last.env['PATH'].startswith('/opt')
    and len(_Cap.last.argv) == 3)
os.path.exists = _oex; os.chmod = _och

# K67-01: TTL-кэш маршрута /api/dns-status; прямые вызовы без кэша.
calls = [0]
def _fake(port):
    calls[0] += 1
    return {'ok': True, 'secure': True, 'state': 'ok',
            'detail': '', 'rtt_ms': 1}
g._test_dns_port = _fake
g.config.web_username = 'a'; g.config.web_password = 'b'
c = g.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'a:b').decode()}
n0 = calls[0]; c.get('/api/dns-status', headers=H); a1 = calls[0] - n0
c.get('/api/dns-status', headers=H); a2 = calls[0] - n0 - a1
g._DNS_STATUS_CACHE['ts'] -= g._DNS_STATUS_TTL + 1
c.get('/api/dns-status', headers=H); a3 = calls[0] - n0 - a1 - a2
before = calls[0]; g.check_dns_ports(); direct = calls[0] - before
chk('K67-01 кэш dns-статуса',
    a1 > 0 and a2 == 0 and a3 == a1 and direct == a1)

if not fails:
    print('OK z44: stale=%s/%s/%s, pid409, error, env, dnscache(%d/%d/%d/%d)'
          % ('да', 'нет', 'нет', a1, a2, a3, direct))
else:
    print('BAD z44: ' + '; '.join(fails))
PYZ44A
grep -q '^OK ' "$F/z44py.out" \
    && ok "Z44-1..4: FB-126 stale вычисляется на чтении (старый running — да; свежий/idle/done — нет; файл не трогается); FB-127 живой СВОЙ pid (FB-158: cmdline-личность, exec -a) — RuntimeError (409) без сброса статуса/lock, Popen-сбой — атомарный error с диагнозом; FB-129(A) env наследуется (KEENZOO_*, PATH-pin, KZ_*), argv 3; K67-01 TTL-кэш /api/dns-status (повтор — 0 dig), прямой вызов — честный" \
    || bad "Z44-1..4: $(cat "$F/z44py.out")"

# Z44-5 (статика): маркеры правок r70 в коде и шаблоне.
Q4A=$(grep -c 'FB-126 (аудит-43)' "$GEN" || true)
Q4B=$(grep -c 'FB-127 (аудит-43)' "$GEN" || true)
Q4C=$(grep -c 'FB-128 (аудит-43)' "$GEN" || true)
Q4D=$(grep -c 'FB-129 (аудит-43' "$GEN" || true)
Q4E=$(grep -c 'K67-01 (аудит-43)' "$GEN" || true)
Q4F=$(grep -c 'K67-02 (аудит-43)' "$GEN" || true)
Q4G=$(grep -c 'UNBLOCK_DIR, BYPASS_FILES' "$GEN" || true)
Q4H=$(grep -c 'arp_flags = int(p\[2\], 16)' "$GEN" || true)
Q4I=$(grep -c '&&!d.update.stale' "$GEN" || true)
Q4J=$(grep -c 'var staleUpd' "$GEN" || true)
Q4K=$(grep -c 'env={\*\*os.environ' "$GEN" || true)
Q4L=$(grep -c '!st.stale))&&n<200' "$GEN" || true)
Q4M=$(grep -c "u.status==='running'&&u.stale" "$GEN" || true)
if [ "$Q4A" -ge 1 ] && [ "$Q4B" -ge 3 ] && [ "$Q4C" = 1 ] && [ "$Q4D" -ge 2 ] \
    && [ "$Q4E" = 1 ] && [ "$Q4F" = 1 ] && [ "$Q4G" = 0 ] \
    && [ "$Q4H" = 1 ] && [ "$Q4I" = 1 ] && [ "$Q4J" = 1 ] \
    && [ "$Q4K" = 2 ] && [ "$Q4L" = 1 ] && [ "$Q4M" = 1 ]; then
    ok "Z44-5: маркеры FB-126..129/K67-01/02 в коде; импорт-девятка убрана; JS: running&&!stale, staleUpd, updState-stale, wait-стоп (r95: +busy-ожидание); env-наследование в обеих обёртках"
else
    bad "Z44-5: f126=$Q4A f127=$Q4B f128=$Q4C f129=$Q4D k1=$Q4E k2=$Q4F imp=$Q4G arp=$Q4H js1=$Q4I js2=$Q4J env=$Q4K js3=$Q4L js4=$Q4M"
fi


# ═══ Z45. Ревью развёртывания r70 (r71): FB-130..137 ═══
# Z45-1 (статика): маркеры правок r71 в генераторе и деплое.
Q5A=$(grep -c 'SHELL_TEMPLATE = ' "$GEN" || true)
Q5B=$(grep -c "@app.route('/panel')" "$GEN" || true)
Q5C=$(grep -c 'def panel_embed' "$GEN" || true)
Q5D=$(grep -c '^PANEL_TABS = {' "$GEN" || true)
Q5E=$(grep -c "url_for('panel_embed') + '?tab=" "$GEN" || true)
Q5F=$(grep -c "url_for('panel_embed') + f'?tab=" "$GEN" || true)
Q5G=$(grep -c "'/panel?tab='+id" "$GEN" || true)
Q5R=$(grep -c "history.pushState({kzTab:id}" "$GEN" || true)
Q5H=$(grep -c 'простыми словами' "$GEN" || true)
Q5I=$(grep -c 'данные из /proc, обновление 2 с' "$GEN" || true)
Q5J=$(grep -c '\.rail \.lbl{opacity:0' "$GEN" || true)
Q5K=$(grep -c 'rail-backdrop' "$GEN" || true)
Q5L=$(grep -c 'tb-model{display:none' "$GEN" || true)
Q5M=$(grep -c 'kz_read_answer' "$DEP" || true)
Q5N=$(grep -c 'FB-130 (ревью r70)' "$DEP" || true)
Q5O=$(grep -c 'FB-131 (ревью r70)' "$DEP" || true)
Q5P=$(grep -c 'FB-132 (ревью r70)' "$DEP" || true)
Q5Q=$(grep -c 'FAILED_OPKG' "$DEP" || true)
# r87 (NFQWS2): +4 редиректа '?tab=' в _toggle_nfqws2
# (не установлен / выключение / конфликт / итог).
# r89 (П2): +2 редиректа в mode_za (неизвестный режим / итог).
# r90 (зеркальный П1): +1 однострочный редирект блока в
# toggle_service (err-ветка force — с переносом строки, не матчится).
# r91 (аудит r90, Е/Г): +4 — busy-lock в toggle_service и mode_za,
# guard «ключ не задан» в toggle_service, живой-остаток в
# _toggle_nfqws2 (err-ветка force S51 имеет перенос — не матчится).
if [ "$Q5A" = 1 ] && [ "$Q5B" = 1 ] && [ "$Q5C" = 1 ] && [ "$Q5D" = 1 ] \
    && [ "$Q5E" = 30 ] && [ "$Q5F" = 3 ] && [ "$Q5G" = 1 ] && [ "$Q5R" = 1 ] \
    && [ "$Q5H" = 0 ] && [ "$Q5I" = 0 ] && [ "$Q5J" = 2 ] \
    && [ "$Q5K" -ge 4 ] && [ "$Q5L" = 1 ] && [ "$Q5M" = 6 ] \
    && [ "$Q5N" = 1 ] && [ "$Q5O" = 1 ] && [ "$Q5P" = 1 ] \
    && [ "$Q5Q" -ge 3 ]; then
    ok "Z45-1: FB-136(A): SHELL_TEMPLATE + /panel + PANEL_TABS, 30+3 редиректа ведут в /panel (19 + r87-nfqws2 ×4 + r89-mode_za ×2 + r90-mirror + r91-hardening ×4: busy-lock toggle/режим, guard ключа, живой-остаток force); JS-fallback /panel?tab= ×1, клиентская навигация — pushState #tab- (FB-144); FB-133/134 надписи убраны; FB-135 .rail .lbl ×2; FB-137 backdrop+mobile ×2; FB-130/131/132 в деплое (kz_read_answer ×6, FAILED_OPKG)"
else
    bad "Z45-1: shell=$Q5A route=$Q5B def=$Q5C tabs=$Q5D redir=$Q5E/$Q5F js=$Q5G note1=$Q5H note2=$Q5I lbl=$Q5J bd=$Q5K mob=$Q5L kza=$Q5M f130=$Q5N f131=$Q5O f132=$Q5P fo=$Q5Q"
fi

# Z45-2 (поведение): оболочка, /panel, редиректы, мобильные маркеры.
python3 - "$K" "$F" > "$F/z45py.out" 2>&1 <<'PYZ45B'
import base64, os, re, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z45bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
# оболочка и содержимое для всех вкладок
for tab in ('ss', 'tr', 'vl', 'to', 'hy', 'bt', 'lk', 'upd', 'dns', 'cfg'):
    rs = c.get('/?tab=%s' % tab, headers=H)
    rp = c.get('/panel?tab=%s' % tab, headers=H)
    chk('оболочка/%s' % tab,
        rs.status_code == 200 and b'panelFrame' in rs.data
        and ('src="/panel?tab=%s"' % tab).encode() in rs.data)
    chk('содержимое/%s' % tab,
        rp.status_code == 200 and b'KeenZOO Panel' in rp.data)
h = c.get('/?tab=dns', headers=H).data.decode()
chk('aria-current: пункт левого меню DNS (FB-149)',
    re.findall(r'href="([^"]*)"[^>]*aria-current="page"', h) == ['/?tab=dns'])
hp = c.get('/panel?tab=tr', headers=H).data.decode()
chk('активная вкладка в /panel',
    bool(re.search(r'id="btn-tr"[^>]*class="tab-btn\s+active"', hp))
    and not re.search(r'id="btn-ss"[^>]*class="tab-btn\s+active"', hp))
# POST-редирект уводит в /panel (iframe не выпадает в оболочку)
tok = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', hp).group(1)
r5 = c.post('/key/ss', data={'key': '', 'csrf_token': tok},
            headers=dict(H, Origin='http://localhost'))
chk('редирект POST → /panel',
    r5.status_code == 302 and '/panel' in (r5.headers.get('Location') or ''))
# мобильные маркеры и удалённые надписи в рендерах
hd = c.get('/', headers=H).data.decode()
chk('FB-137 маркеры в рендере',
    'railBd' in hd and '.rail .lbl{opacity:0' in hd
    and 'tb-model{display:none' in hd and 'hero-actions{margin-left:0;width:100%}' in hd)
chk('FB-133/134 убраны',
    'простыми словами' not in hd
    and 'данные из /proc, обновление 2 с' not in hd)
chk('FB-135 подписи рельса скрываются',
    '.rail:hover .lbl,body.rail-pin .lbl{opacity:1}' in hd)
# темы: слушатели storage во всех трёх шаблонах
src = open(os.path.join(B, 'generator.py'), encoding='utf-8').read()
chk('синхронизация темы (storage)',
    src.count("addEventListener('storage'") >= 3)
if not fails:
    print('OK z45: shell+panel ×10, aria, active, redirect, mobile, notes, themes')
else:
    print('BAD z45: ' + '; '.join(fails))
PYZ45B
grep -q '^OK ' "$F/z45py.out" \
    && ok "Z45-2: '/?tab=*' ×10 — MD3-оболочка с iframe /panel?tab=*; '/panel?tab=*' ×10 — прежняя панель; aria-current на пункте левого меню (FB-149); активная вкладка рендерится; POST-редиректы ведут в /panel (iframe не выпадает в оболочку); мобильные маркеры FB-137 и отсутствие надписей FB-133/134; темы синхронизируются storage-событием" \
    || bad "Z45-2: $(cat "$F/z45py.out")"


# ═══ Z46. Ревью r71 на устройстве (r72): FB-138 — каскад мобильного пакета ═══
# Z46-1 (статика): мёртвый пакет удалён, новый — в конце стиля обоих шаблонов.
python3 - "$GEN" > "$F/z46s.out" 2>&1 <<'PYZ46A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
OLD = ('@media(max-width:760px){\n  .rail{transform:translateX(-100%);width:var(--rail-wx)!important}\n'
       '  body.rail-open .rail{transform:none}\n  body.rail-open{overflow:hidden}\n'
       '  .rail-title,.rail .lbl{opacity:1!important}\n  .main{margin-left:0!important}\n'
       '  .topbar{padding:0 14px;gap:10px}\n  .tb-model{display:none}\n'
       '  .content{padding:14px 12px 22px;gap:12px}\n  .card{padding:14px}\n'
       '  .badge{padding:5px 10px;font-size:12px}\n'
       '  .hero-actions{margin-left:0;width:100%}\n'
       '  .hero-actions .qbtn{flex:1;justify-content:center}\n'
       '  .kmap{gap:6px}\n  .knode{padding:10px 12px}\n}')
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
def t_slice(name):
    op = name + " = r'''"
    i = src.index(op) + len(op)
    return src[i:src.index("'''", i)]
chk('старый мёртвый пакет удалён', OLD not in src)
chk('пакет ровно два (дашборд+оболочка, FB-149: выезд 260px)',
    src.count('@media(max-width:700px){\n  .rail{transform:translateX(-100%)') == 2
    and src.count('.rail{transform:translateX(-100%);width:260px!important;overflow-y:auto}') == 2)
dash = t_slice('DASH_TEMPLATE')
pkg = dash.index('@media(max-width:760px){\n  .rail{transform')
for base in ('.topbar{position:sticky', '.content{flex:1', '.card{background',
             '.badge{display:inline-flex', '.hero-actions{margin-left:auto',
             '.kmap{display:flex', '.knode{flex:1', '.card-note{margin-left:auto',
             '.ring svg{width:106px'):
    chk('каскад дашборда: пакет после ' + base, dash.index(base) < pkg)
for m in ('.kmap{flex-direction:column', '.kconn{display:none}',
          '.card-note{display:none}', '.ring svg{width:88px',
          '[data-tip]::after,[data-tip]::before{display:none}',
          '<div class="tb-name">'):
    chk('маркер дашборда ' + m, m in dash)
shell = t_slice('SHELL_TEMPLATE')
pkgs = shell.index('@media(max-width:760px){\n  .rail{transform')
for base in ('.topbar{position:sticky', '.tb-title{font-size:19px'):
    chk('каскад оболочки: пакет после ' + base, shell.index(base) < pkgs)
chk('оболочка: эллипсис топбара', '.tb-title{font-size:15px;overflow:hidden' in shell)
chk('оболочка: tb-name в разметке', '<div class="tb-name">' in shell)
print('OK z46-static' if not fails else 'BAD z46-static: ' + '; '.join(fails))
PYZ46A
grep -q '^OK z46-static' "$F/z46s.out" \
    && ok "Z46-1: FB-138: мёртвый пакет (выше базовых правил) удалён из обоих шаблонов; новый — в конце стиля дашборда и оболочки, после всех перекрываемых баз; kmap колонкой, коннекторы/hover-подсказки скрыты, заголовки карточек переносятся, эллипсис топбара" \
    || bad "Z46-1: $(cat "$F/z46s.out")"

# Z46-2 (поведение): рендеры — порядок правил в выданном CSS + маркеры.
python3 - "$K" "$F" > "$F/z46py.out" 2>&1 <<'PYZ46B'
import base64, os, re, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z46bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
hd = c.get('/', headers=H).data.decode()
css = re.search(r'<style>(.*?)</style>', hd, re.S).group(1)
pkg = css.index("@media(max-width:760px){\n  .rail{transform")
for base in ('.topbar{position:sticky', '.content{flex:1', '.card{background',
             '.badge{display:inline-flex', '.hero-actions{margin-left:auto',
             '.kmap{display:flex', '.knode{flex:1'):
    chk('рендер: пакет после ' + base, css.index(base) < pkg)
for m in ('.kmap{flex-direction:column', '.kconn{display:none}',
          '.card-note{display:none}', '.ring svg{width:88px',
          '[data-tip]::after,[data-tip]::before{display:none}',
          'class="tb-name"'):
    chk('рендер: маркер ' + m, m in hd)
hs = c.get('/?tab=ss', headers=H).data.decode()
csss = re.search(r'<style>(.*?)</style>', hs, re.S).group(1)
pkgs = csss.index("@media(max-width:760px){\n  .rail{transform")
chk('оболочка: пакет после .topbar', csss.index('.topbar{position:sticky') < pkgs)
chk('оболочка: эллипсис', '.tb-title{font-size:15px;overflow:hidden' in csss)
chk('оболочка: tb-name', 'class="tb-name"' in hs)
hp = c.get('/panel?tab=ss', headers=H).data.decode()
chk('легаси-панель адаптивна (media 420)', '@media (max-width:420px)' in hp)
if not fails:
    print('OK z46-render')
else:
    print('BAD z46-render: ' + '; '.join(fails))
PYZ46B
grep -q '^OK z46-render' "$F/z46py.out" \
    && ok "Z46-2: рендеры: мобильный пакет в конце CSS дашборда и оболочки (после всех перекрываемых баз — каскад реально применяется), маркеры FB-138 в разметке; легаси-панель сохраняет адаптивность (media 420)" \
    || bad "Z46-2: $(cat "$F/z46py.out")"


# ═══ Z47. Ревью r72 (r73): FB-139 — стиль вкладок = стиль дашборда ═══
# Z47-1 (статика): токены и компоненты MD3 в PAGE_TEMPLATE.
python3 - "$GEN" > "$F/z47s.out" 2>&1 <<'PYZ47A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
def t_slice(name):
    op = name + " = r'''"
    i = src.index(op) + len(op)
    return src[i:src.index("'''", i)]
page = t_slice('PAGE_TEMPLATE')
# старая палитра (бирюза/тёмный борт) полностью ушла
for bad in ('0e7a6d', '2dd4bf', '16202b',
            'rgba(255,255,255,.08)', 'border-top:2px solid var(--accent)'):
    chk('старой палитры нет: ' + bad, bad not in page)
chk('старый тёмный борт удалён (#0b1512 — только dark-текст FB-141/FB-192)',
    page.count('#0b1512') == 3
    and 'html[data-theme="dark"] .btn-key{color:#0b1512}' in page
    and 'html[data-theme="dark"] .btn-cfg,html[data-theme="dark"] .btn-save{color:#0b1512}' in page)
# токены дашборда в светлой и тёмной темах + логотип
chk('primary панели (light, FB-151; FB-192 залитые cfg/save)', page.count('#007fb4') == 5)
chk('primary панели (dark, FB-151)', page.count('--primary:#00a8e8') == 1)
chk('градиент логотипа как у дашборда',
    'linear-gradient(135deg,#0061e6,#0043b8)' in page)
chk('тени карточек (FB-195: +kz-note)', page.count('box-shadow:var(--sh-1)') == 2)
# компоненты
chk('вкладка активная — B: filled primary',
    page.count('.tab-btn.active{background:var(--primary);color:#fff;font-weight:600}') == 1
    and page.count('html[data-theme="dark"] .tab-btn.active{background:var(--primary-c)') == 2)
chk('btn-key — filled primary', page.count('.btn-key{background:var(--primary)') == 1)
chk('кнопки — пилюли', 'border-radius:999px' in page)
chk('шапка непрозрачная, без backdrop-фильтра (FB-211)',
    page.count('backdrop-filter:blur(10px)') == 0
    and 'background:color-mix(in srgb,var(--gl) 90%,transparent)' not in page)
# масштабирование и плотность пикселей
chk('breakpoint 420px', page.count('@media (max-width:420px)') == 1)
chk('breakpoints 960/700', '@media (max-width:960px)' in page
    and '@media (max-width:700px)' in page)
chk('text-size-adjust (плотность)', page.count('-webkit-text-size-adjust:100%') == 1)
chk('tap-highlight (сенсорные)', page.count('-webkit-tap-highlight-color:transparent') == 1)
chk('заливки полей — surface-2', 'var(--bg)' not in page)
print('OK z47-static' if not fails else 'BAD z47-static: ' + '; '.join(fails))
PYZ47A
grep -q '^OK z47-static' "$F/z47s.out" \
    && ok "Z47-1: FB-139: PAGE_TEMPLATE на токенах дашборда (MD3→r78): primary #007fb4 / #00a8e8 (FB-151), surface-серия, тени sh-1/sh-2, градиент логотипа; старая бирюзовая палитра и тёмный борт удалены; плитки — карточки (без teal-полосы), кнопки — пилюли (btn-key filled, cfg/save tonal), активная вкладка — тон primary-c, топбар непрозрачный без backdrop-фильтра (FB-211); media 960/700/420, text-size-adjust, tap-highlight, заливки surface-2" \
    || bad "Z47-1: $(cat "$F/z47s.out")"

# Z47-2 (поведение): рендеры всех вкладок + разметка/логика цела.
python3 - "$K" "$F" > "$F/z47py.out" 2>&1 <<'PYZ47B'
import base64, os, re, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z47bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
for tab in ('ss', 'tr', 'vl', 'to', 'hy', 'bt', 'lk', 'upd', 'dns', 'cfg'):
    r = c.get('/panel?tab=%s' % tab, headers=H)
    chk('вкладка %s 200' % tab, r.status_code == 200)
hp = c.get('/panel?tab=ss', headers=H).data.decode()
for m in ('--primary:#007fb4', '.tab-btn.active{background:var(--primary)',
          '.btn-key{background:var(--primary)', 'text-size-adjust:100%',
          '@media (max-width:420px)', '-webkit-tap-highlight-color:transparent',
          'html[data-theme="dark"]{', '--primary:#00a8e8'):
    chk('рендер: маркер ' + m, m in hp)
# разметка и логика не тронуты (структура/логика проекта сохранены)
for m in ("id=\"btn-ss\"", "id=\"btn-cfg\"", "onclick=\"go('ss')\"",
          'class="tile', 'class="tabs"', 'name="csrf_token"'):
    chk('разметка цела: ' + m, m in hp)
hd = c.get('/', headers=H).data.decode()
chk('дашборд: новые токены FB-151', 'dashRoot' in hd and '--primary:#007fb4' in hd)
if not fails:
    print('OK z47-render')
else:
    print('BAD z47-render: ' + '; '.join(fails))
PYZ47B
grep -q '^OK z47-render' "$F/z47py.out" \
    && ok "Z47-2: рендеры: все 10 вкладок /panel 200 с токенами/маркерами FB-139 (light+dark блоки, media 420, tap-highlight); разметка и логика легаси не тронуты (btn-*, go(), tile, tabs, csrf); дашборд на новых токенах FB-151" \
    || bad "Z47-2: $(cat "$F/z47py.out")"


# ═══ Z48. UX-r73, вариант B (r74): FB-140 — пилюли + ARIA + валидация ═══
# Z48-1 (статика): маркеры FB-140 в PAGE_TEMPLATE.
python3 - "$GEN" > "$F/z48s.out" 2>&1 <<'PYZ48A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
def t_slice(name):
    op = name + " = r'''"
    i = src.index(op) + len(op)
    return src[i:src.index("'''", i)]
page = t_slice('PAGE_TEMPLATE')
# вид B
chk('пилюли: радиус 999 у вкладок', 'border-radius:999px' in page)
chk('filled primary у активной (light)',
    page.count('.tab-btn.active{background:var(--primary);color:#fff;font-weight:600}') == 1)
chk('тон primary-c у активной (dark) ×2 (осн.+мобильный)',
    page.count('html[data-theme="dark"] .tab-btn.active{background:var(--primary-c)') == 2)
chk('touch-цели 44px (--control-h)', page.count('--control-h:44px') == 1)
chk('высота вкладки 44px', page.count('height:44px') >= 2)
# ARIA (У-7/У-8)
chk('tablist', page.count('role="tablist"') == 1)
chk('10 role=tab', page.count('role="tab"') == 10)
chk('tabpanel ×7 (tid-шаблон + 5 + r89-za)', page.count('role="tabpanel"') == 7)
chk('aria-live polite (update/pin)', page.count('aria-live="polite"') == 2)
chk('role=status на .msg', '<div role="status" class="msg' in page)
# JS (У-12/У-15/У-17)
chk('kzSyncTabs в go()', page.count('kzSyncTabs();') == 2)  # вызов в go + init
chk('стрелки/ Home/End', page.count("e.key==='ArrowRight'") == 1
    and page.count("e.key==='Home'") == 1 and page.count("e.key==='End'") == 1)
chk('валидация ключей (kzKeyForms)', page.count('kzKeyForms') == 2)
chk('подсказка/счётчик CSS', page.count('.kz-hint{') == 1)
chk('toast CSS + kzToast', page.count('.kz-toast{') == 1
    and page.count('function kzToast') == 1)
print('OK z48-static' if not fails else 'BAD z48-static: ' + '; '.join(fails))
PYZ48A
grep -q '^OK z48-static' "$F/z48s.out" \
    && ok "Z48-1: FB-140 (вариант B): вкладки-пилюли 44px — активная filled primary (тёмная тема — тон primary-c, осн.+мобильный); --control-h 44px (У-6); ARIA-табы: tablist/tab ×10/tabpanel ×7 + aria-live ×2 + role=status (У-7/У-8); JS: kzSyncTabs в go(), стрелки ←/→/Home/End (У-12), kzKeyForms с подсказкой-счётчиком (У-15), kzToast + CSS (У-17)" \
    || bad "Z48-1: $(cat "$F/z48s.out")"

# Z48-2 (поведение): рендер ARIA + разметка/логика цела.
python3 - "$K" "$F" > "$F/z48py.out" 2>&1 <<'PYZ48B'
import base64, os, re, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z48bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
for tab in ('ss', 'tr', 'vl', 'to', 'hy', 'bt', 'lk', 'upd', 'dns', 'cfg'):
    chk('вкладка %s 200' % tab,
        c.get('/panel?tab=%s' % tab, headers=H).status_code == 200)
hp = c.get('/panel?tab=ss', headers=H).data.decode()
chk('рендер: tablist ×1', len(re.findall(r'role="tablist"', hp)) == 1)
chk('рендер: 10 кнопок role=tab',
    len(re.findall(r'<button id="btn-[a-z]+" class="tab-btn[^>]*role="tab"', hp)) == 10)
chk('рендер: tabpanel ×11 (jinja развёрнут; r89-za)',
    len(re.findall(r'role="tabpanel"', hp)) == 11)
chk('рендер: aria-selected true/false',
    'aria-selected="true"' in hp and 'aria-selected="false"' in hp)
chk('рендер: filled primary', '.tab-btn.active{background:var(--primary)' in hp)
chk('рендер: 44px', '--control-h:44px' in hp)
# структура/логика не тронуты
for m in ("onclick=\"go('ss')\"", "id=\"tab-bt\"", 'name="csrf_token"',
          'action="/key/ss"', 'action="/list/ss"'):
    chk('логика цела: ' + m, m in hp)
hd = c.get('/', headers=H).data.decode()
chk('дашборд не затронут', 'dashRoot' in hd)
if not fails:
    print('OK z48-render')
else:
    print('BAD z48-render: ' + '; '.join(fails))
PYZ48B
grep -q '^OK z48-render' "$F/z48py.out" \
    && ok "Z48-2: рендеры: 10/10 вкладок 200; tablist ×1 + 10 role=tab + 10 tabpanel; aria-selected true/false; filled primary; 44px; логика не тронута (go, tab-*, csrf, /key,/list); дашборд не затронут" \
    || bad "Z48-2: $(cat "$F/z48py.out")"


# ═══ Z49. UX-r74 (r75): FB-141..FB-146 — контрасты, шкалы, kzFetch, «Назад», черновики, скелетоны ═══
# Z49-1 (статика): маркеры FB-141..146 в генераторе.
python3 - "$GEN" > "$F/z49s.out" 2>&1 <<'PYZ49A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
# FB-141: контрасты
chk('faint light #546273 ×3 (5.65:1 на surface-2, FB-151)', src.count('--faint:#546273') == 3)
chk('faint dark #8a95a7 ×2 (5.42:1) + #93a5bd ×1 (6.52:1, FB-151)',
    src.count('--faint:#8a95a7') == 2 and src.count('--faint:#93a5bd') == 1)
chk('старые faint удалены', '--faint:#8b95a5' not in src and '--faint:#6b7688' not in src)
chk('dark: тёмный текст на .btn-key', src.count('html[data-theme="dark"] .btn-key{color:#0b1512}') == 1)
chk('dark: тёмный текст на .qbtn (дашборд)', src.count('html[data-theme="dark"] .qbtn{color:#0b1512}') == 1)
# FB-142: шкалы токенов
for m, n in (('--fs-caption:13px', 3), ('--fs-s:14.5px', 3), ('--fs-m:15px', 3),
             ('--fs-l:17px', 3), ('--fs-xl:18px', 3), ('--sp-6:32px', 3),
             ('--z-rail:60', 3), ('--z-toast:90', 3), ('--dur:.15s', 3),
             ('--ease:cubic-bezier(.2,.7,.3,1)', 3)):
    chk('токен %s ×%d' % (m, n), src.count(m) == n)
chk('z-index токенизирован (≥15)', src.count('z-index:var(--z-') >= 15)
chk('font-size токенизирован (≥80)', src.count('font-size:var(--fs-') >= 80)
chk('12.5px только в .za-actions .btn (r89, мокап r88-р2); 13.5px — только подпункты рельса (×2, FB-149)',
    src.count('font-size:12.5px') == 1
    and 'font-size:12.5px' in src.split('.za-actions .btn{')[1][:400]
    and src.count('font-size:13.5px') == 2)
chk('отступы: --space → --sp-3', src.count('--space:var(--sp-3)') == 1)
# FB-143: kzFetch
chk('kzFetch определён', src.count('function kzFetch') == 1)
chk('kzFetch вызовов 4', src.count('kzFetch(') == 5)  # def + 4
chk('lookup: явная кнопка', "kzFetch(document.querySelector('.lookup-submit')," in src)
chk('cfg: кнопка из обработчика', "kzFetch(btn,'/api/cfg/'" in src)
chk('router-proto: this в onclick', "setRouterProto('vl',this)" in src)
# FB-144: «Назад»
chk('pushState #tab-', src.count("history.pushState({kzTab:id},'','#tab-'+id)") == 1)
chk('popstate-слушатель', src.count("addEventListener('popstate'") == 1)
chk('replaceState удалён', 'replaceState' not in src)
chk('возврат к исходной вкладке (kzFirstTab)', src.count('kzFirstTab') >= 2)
# FB-145: черновики
chk('ключ kzdraft:', src.count("'kzdraft:'+") >= 3)
chk('кнопка «Очистить черновик» (код+коммент)', src.count('Очистить черновик') == 2)
chk('kzDrafts def+вызов', src.count('kzDrafts') == 2)
# FB-146: скелетон + пустое состояние
chk('скелетон DNS-проверок', src.count('.dns-grid .dns-port.checking') == 1)
chk('анимация kz-skel', src.count('kz-skel 1.1s') == 1)
chk('пустое состояние DNS', src.count('Пока ничего не проверено') == 1)
chk('kzEmptyState def+вызов', src.count('kzEmptyState') == 2)
# У-14 не реализован (отдельное решение): confirm-точки остались
chk('confirm-точки сохранены (У-14 на решении)', src.count('confirm(') == 3)
print('OK z49-static' if not fails else 'BAD z49-static: ' + '; '.join(fails))
PYZ49A
grep -q '^OK z49-static' "$F/z49s.out" \
    && ok "Z49-1: FB-141: faint #546273/#8a95a7+#93a5bd (5.65/5.42/6.52:1, FB-151), тёмный текст на filled-кнопках dark (6.65:1); FB-142: --fs-*/--sp-*/--z-*/--ease/--dur ×3 шаблона (FB-151: 13/14.5/15/17), 12.5 удалён, 13.5 — только рельс, z-index ≥15 и font-size ≥80 токенизированы; FB-143: kzFetch + 4 точки (lookup/lookup-add/cfg/router-proto, явные кнопки); FB-144: pushState #tab- + popstate + kzFirstTab, replaceState удалён; FB-145: kzdraft: + «Очистить черновик»; FB-146: скелетон .dns-grid .checking + пустое состояние; У-14: 3 confirm-точки нетронуты (на отдельном решении)" \
    || bad "Z49-1: $(cat "$F/z49s.out")"

# Z49-2 (поведение): рендеры всех шаблонов с маркерами FB-141..146.
python3 - "$K" "$F" > "$F/z49py.out" 2>&1 <<'PYZ49B'
import base64, os, re, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z49bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
for tab in ('ss', 'tr', 'vl', 'to', 'hy', 'bt', 'lk', 'upd', 'dns', 'cfg'):
    chk('вкладка %s 200' % tab,
        c.get('/panel?tab=%s' % tab, headers=H).status_code == 200)
hp = c.get('/panel?tab=ss', headers=H).data.decode()
for m in ('--fs-caption:13px', '--sp-6:32px', '--z-rail:60', '--faint:#546273',
          'html[data-theme="dark"] .btn-key{color:#0b1512}',
          'function kzFetch', "history.pushState({kzTab:id},'','#tab-'+id)",
          "addEventListener('popstate'", 'Очистить черновик',
          '.dns-grid .dns-port.checking', 'Пока ничего не проверено',
          'font-size:var(--fs-s)'):
    chk('рендер панели: ' + m, m in hp)
chk('панель: ARIA FB-140 цел (10 tab)',
    len(re.findall(r'<button id="btn-[a-z]+" class="tab-btn[^>]*role="tab"', hp)) == 10)
chk('панель: replaceState нет', 'replaceState' not in hp)
hd = c.get('/', headers=H).data.decode()
chk('дашборд: токены + dark qbtn', '--fs-xl:18px' in hd
    and 'html[data-theme="dark"] .qbtn{color:#0b1512}' in hd
    and 'font-size:19px' in hd)
hs = c.get('/?tab=ss', headers=H).data.decode()
chk('оболочка: токены + tb-title 19px (FB-190)', '--fs-l:17px' in hs
    and 'font-size:19px' in hs and 'z-index:var(--z-rail)' in hs)
if not fails:
    print('OK z49-render')
else:
    print('BAD z49-render: ' + '; '.join(fails))
PYZ49B
grep -q '^OK z49-render' "$F/z49py.out" \
    && ok "Z49-2: рендеры: 10/10 вкладок с токенами FB-142 и маркерами FB-141/143/144/145/146; ARIA FB-140 цел (10 tab); replaceState отсутствует; дашборд и оболочка — на токенах (--fs-xl, --fs-l, --z-rail)" \
    || bad "Z49-2: $(cat "$F/z49py.out")"

# Z51-1 (статика): маркеры FB-149/150/151 (панель-r77) в генераторе.
python3 - "$GEN" > "$F/z51s.out" 2>&1 <<'PYZ51A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
# FB-149: левое меню — единственная навигация
chk('меню tb-drop удалено (CSS и DOM)', src.count('.tb-drop{') == 0 and src.count('id="tbDrop"') == 0)
chk('пункты td-item/td-head удалены', 'td-item' not in src and 'td-head' not in src)
chk('кнопка ☰ «Открыть меню» (×2, мобильная)', src.count('aria-label="Открыть меню"') == 2)
chk('меню: JS выезжающего рельса (×2)', src.count("classList.toggle('rail-open')") == 2
    and src.count("querySelectorAll('.rail a')") == 2 and src.count('id="railBd"') == 2)
chk('группы меню: Статус/Протоколы/Настройки (×2 шаблона)', src.count('class="nav-head"') == 6)
chk('подпункты протоколов ×5 (×2 шаблона, FB-191 аббревиатуры)',
    src.count('<div class="rail-subs">') == 2
    and src.count('>Hysteria</a>') == 3 and src.count('data-abbr="HS"') == 2)
chk('редакция на панели не отображается (FB-194)', src.count('<span>ред. 82</span>') == 0)
chk('мобильный пакет: рельс 260px + прокрутка (×2)',
    src.count('.rail{transform:translateX(-100%);width:260px!important;overflow-y:auto}') == 2)
chk('панель: сайдбар скрыт на десктопе, пилюли — мобильная строка',
    src.count('.side{display:none!important}') == 2
    and src.count('.side{display:block!important') == 1
    and src.count('.tabs{flex-direction:row!important;flex-wrap:nowrap') == 1)
chk('панель: layout-колонка (пилюли сверху, контент ниже)',
    src.count('.layout{flex-direction:column!important}') == 1)
# FB-150: DNS-панель и версии
chk('DNS-панель kzDnsPanel (×2) + маркер FB-150',
    src.count('kzDnsPanel') == 2 and src.count('FB-150') == 1)
chk('кнопка «Версии и обновления» убрана (текст — только в маркере)',
    src.count('Версии и обновления') == 1)
# FB-151: гамма/шрифты/кнопки
chk('палитра эталона: primary #007fb4/#00a8e8 (×3/×3)',
    src.count('--primary:#007fb4') == 3 and src.count('--primary:#00a8e8') == 3)
chk('палитра эталона: surface #1e293b/#17202d (×3/×3)',
    src.count('--surface:#1e293b') == 3 and src.count('--surface-2:#17202d') == 3)
chk('шрифт — системный стек (×3, FB-203)',
    src.count('-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto') == 3
    and src.count('Arial,"Segoe UI"') == 0)
chk('кнопки «Применить ключ/конфигурацию» в уровень (:has ×3)',
    src.count('.tile:has(>form .btn-key)') == 3)
chk('подпись кнопки: «Применить конфигурацию»', src.count('Применить конфигурацию') == 1)
# FB-148: сетка мобильного дашборда (сохранена)
chk('мобильная сетка: карточки на всю ширину', src.count('.content > .card{grid-column:1 / -1}') == 1)
chk('hero: компактные кнопки на мобильном', src.count('.hero-actions .qbtn{flex:0 1 auto;min-height:36px') == 1)
chk('кольца нагрузки: равные половины', src.count('.rings{display:grid;grid-template-columns:1fr 1fr') == 1)
if not fails:
    print('OK z51s: FB-149/150/151 статика')
else:
    print('BAD z51s: ' + '; '.join(fails))
PYZ51A
grep -q '^OK ' "$F/z51s.out" \
    && ok "Z51-1: FB-149: левое меню с группами и подпунктами (ред. на панели не отображается — FB-194), tb-drop/сайдбар панели удалены, ☰ — мобильный выезд (260 px, прокрутка), пилюли — мобильная строка, layout-колонка; FB-150: DNS-панель, кнопка версий убрана; FB-151: палитра #007fb4/#00a8e8 + системный шрифтовой стек (FB-203) + :has-выравнивание кнопок; FB-148: сетка дашборда сохранена" \
    || bad "Z51-1: $(cat "$F/z51s.out")"

# Z51-2 (поведение): рендеры левого меню, панели, дашборда.
python3 - "$K" "$F" > "$F/z51py.out" 2>&1 <<'PYZ51B'
import base64, os, re, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z51bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
for tab in ('ss', 'tr', 'vl', 'to', 'hy', 'bt', 'lk', 'upd', 'dns', 'cfg'):
    rs = c.get('/?tab=%s' % tab, headers=H)
    chk('оболочка/%s' % tab, rs.status_code == 200 and b'class="nav-head"' in rs.data
        and ('src="/panel?tab=%s"' % tab).encode() in rs.data)
h = c.get('/?tab=ss', headers=H).data.decode()
chk('меню: группы ×3 + 6 разделов + 6 подпунктов (+NFQWS2), без ред. (FB-194)',
    h.count('class="nav-head"') == 3 and h.count('<div class="rail-subs">') == 1
    and h.count('<a href="/?tab=') == 6 and h.count('<a class="rail-item" href="/?tab=') == 5
    and h.count('<a class="rail-item" href="/"') == 1 and 'ред. 82' not in h)
chk('меню: текущий подпункт Shadowsocks подсвечен',
    re.findall(r'href="([^"]*)"[^>]*aria-current="page"', h) == ['/?tab=ss'])
chk('вордмарк Keen<b>ZOO</b>: рельс + шапка (FB-190)',
    h.count('Keen<b>ZOO</b>') == 2 and h.count('>KeenZOO<') == 0)
hd = c.get('/', headers=H).data.decode()
chk('дашборд: группы ×3 + Обзор подсвечен, без ред. (FB-194)',
    hd.count('class="nav-head"') == 3 and 'ред. 82' not in hd
    and re.findall(r'href="([^"]*)"[^>]*aria-current="page"', hd) == ['/'])
chk('FB-148: карточки на всю ширину', '.content > .card{grid-column:1 / -1}' in hd)
chk('FB-148: компактные кнопки hero', '.hero-actions .qbtn{flex:0 1 auto;min-height:36px' in hd)
chk('FB-148: кольца — половины ряда', '.rings{display:grid;grid-template-columns:1fr 1fr' in hd)
chk('FB-150: на дашборде нет «Версии и обновления»', 'Версии и обновления' not in hd)
p = c.get('/panel?tab=ss', headers=H).data.decode()
chk('панель: сайдбар скрыт на десктопе, пилюли — мобильная строка',
    '.side{display:none!important}' in p
    and '.tabs{flex-direction:row!important;flex-wrap:nowrap' in p)
chk('панель: «Применить конфигурацию» ×4 протокола', p.count('Применить конфигурацию') == 4)
chk('FB-150: kzDnsPanel скрыт вне DNS', 'id="kzDnsPanel" style="display:none"' in p)
pdns = c.get('/panel?tab=dns', headers=H).data.decode()
chk('FB-150: kzDnsPanel виден во вкладке DNS', 'id="kzDnsPanel">' in pdns)
chk('панель: бренд-блок удалён', '<div class="side-brand">' not in p and '>KEENZOO<' not in p)
chk('панель: заголовок вкладки на месте', 'class="page-title"' in p)
if not fails:
    print('OK z51: shell×10, menu, dash, panel')
else:
    print('BAD z51: ' + '; '.join(fails))
PYZ51B
grep -q '^OK ' "$F/z51py.out" \
    && ok "Z51-2: рендеры: левое меню во всех шаблонах (группы Статус/Протоколы/Настройки, 6 разделов + 5 подпунктов, подсветка текущего); дашборд: Обзор подсвечен, сетка FB-148, кнопки версий нет; панель: пилюли мобильные, «Применить конфигурацию» ×4, DNS-панель только во вкладке DNS (FB-150), бренд-блок удалён" \
    || bad "Z51-2: $(cat "$F/z51py.out")"


# Z52-1 (статика): маркеры FB-152..155 (облегчение-r78, аудит-44).
python3 - "$GEN" "$K/opt/bin/deploy_bypass.sh" > "$F/z52s.out" 2>&1 <<'PYZ52A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
dep = open(sys.argv[2], encoding='utf-8').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
chk('FB-153: import gzip + единственный after_request',
    src.count('import gzip') == 1 and src.count('@app.after_request') == 1
    and "resp.headers['Content-Encoding'] = 'gzip'" in src)
chk('FB-153/170: только 200/текст/≥1024Б; неготиация и Vary — FB-170',
    "resp.status_code != 200 or resp.direct_passthrough" in src
    and "len(resp.data) < 1024" in src
    and 'def _accepts_gzip(' in src
    and "Vary'] = 'Accept-Encoding'" not in src)
chk('FB-154: DASH_CACHE_TTL = 2.5', src.count('DASH_CACHE_TTL = 2.5') == 1)
chk('FB-155: _DNS_STATUS_TTL = 120.0', src.count('_DNS_STATUS_TTL = 120.0') == 1)
chk('FB-175: compileall откатен (deploy)',
    'compileall' not in dep and 'прекомпилирован' not in dep
    and 'FB-175' in dep)
chk('Q0 не задет: before_request единственный',
    src.count('@app.before_request') == 1)
if not fails:
    print('OK z52s: FB-152..155 статика')
else:
    print('BAD z52s: ' + '; '.join(fails))
PYZ52A
grep -q '^OK ' "$F/z52s.out" \
    && ok "Z52-1: FB-153: gzip after_request (stdlib; 200/текст/≥1КБ, мелкий API не жмётся; неготиация q=0/регистр и Vary обеих representations — FB-170); FB-154: DASH_CACHE_TTL 2.5 c; FB-155: _DNS_STATUS_TTL 120 c; FB-175: compileall откатен (S99 игнорирует .pyc); Q0-инвариант цел" \
    || bad "Z52-1: $(cat "$F/z52s.out")"

# Z52-2 (поведение): gzip, TTL-кэш, ред. 82.
python3 - "$K" "$F" > "$F/z52py.out" 2>&1 <<'PYZ52B'
import base64, os, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z52bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode()}
GZ = dict(H, **{'Accept-Encoding': 'gzip'})
r = c.get('/panel?tab=ss', headers=GZ)
# r94 (Z62-Б): JS busy-обработка панели добавила ~1 КиБ —
# охранный порог сжатой страницы 30→32 КиБ (несжатая ~124 КиБ)
chk('gzip: /panel сжат', r.headers.get('Content-Encoding') == 'gzip'
    and len(r.data) < 32000)
r0 = c.get('/panel?tab=ss', headers=H)
chk('gzip: без Accept-Encoding — не сжат',
    r0.headers.get('Content-Encoding') is None and len(r0.data) > 100000)
r = c.get('/api/dashboard', headers=GZ)
chk('gzip: мелкий API (<1КБ) не сжимается',
    r.headers.get('Content-Encoding') is None)
t1 = c.get('/api/dashboard', headers=H).get_json()['ts']
t2 = c.get('/api/dashboard', headers=H).get_json()['ts']
import time as _t
_t.sleep(3)
t3 = c.get('/api/dashboard', headers=H).get_json()['ts']
chk('TTL 2.5 c: подряд кэш-хит, через 3 с пересбор', t1 == t2 and t3 > t2)
chk('константы TTL', g2.DASH_CACHE_TTL == 2.5 and g2._DNS_STATUS_TTL == 120.0)
h = c.get('/', headers=H).data.decode()
chk('редакция на панели не отображается (FB-194)', 'ред. 82' not in h)
if not fails:
    print('OK z52: gzip, ttl, ver')
else:
    print('BAD z52: ' + '; '.join(fails))
PYZ52B
grep -q '^OK ' "$F/z52py.out" \
    && ok "Z52-2: поведение: gzip страниц (/panel 106→26 КБ, без Accept-Encoding — без сжатия), API <1КБ не жмётся; TTL 2.5 c — подряд кэш-хит, пересбор через 3 с; DNS TTL 120; редакция на панели не отображается (FB-194)" \
    || bad "Z52-2: $(cat "$F/z52py.out")"

# ═══ Z53. Аудит-45 (внешний отчёт r77, этапы 1–3): FB-156..166 ═══

# Z53-1 (статика): маркеры FB-156..166 + инварианты целости.
python3 - "$K" "$F" > "$F/z53s.out" 2>&1 <<'PYZ53A'
import sys
K = sys.argv[1]
gs = open(K + '/opt/etc/bot/generator.py',
          encoding='utf-8').read()
ds = open(K + '/opt/bin/deploy_bypass.sh', 'rb').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
# FB-156: расширенный чёрный список в ndmc-парсере (deploy)
chk('FB-156 префиксы', all(p in ds for p in (
    b'[Ii][Nn][Vv][Aa][Ll][Ii][Dd]', b'[Uu][Nn][Kk][Nn][Oo][Ww][Nn]',
    b'[Uu][Nn][Rr][Ee][Cc][Oo][Gg][Nn][Ii][Zz][Ee][Dd]',
    b'[Uu][Nn][Ss][Uu][Pp][Pp][Oo][Rr][Tt][Ee][Dd]')))
chk('FB-156 маркер-комментарий',
    'FB-156 (аудит-45, R77-01'.encode('utf-8') in ds)
# FB-164: сырого CR нет, есть текстовый \r
chk('FB-164 нет CR-байта', b'\r' not in ds)
chk('FB-164 текст \\r в комментарии',
    b'\xc2\xaby\\r\xc2\xbb' in ds
    and 'FB-164 (аудит-45, R77-09'.encode('utf-8') in ds)
# FB-157: single-flight lock старта
chk('FB-157 lock', '_UPDATE_START_LOCK = threading.Lock()' in gs
    and 'with _UPDATE_START_LOCK:' in gs
    and 'FB-157 (аудит-45, R77-02' in gs)
# FB-158: UNKNOWN-отказы + cmdline-личность
chk('FB-158 cmdline-личность',
    'def _proc_cmdline_contains(pid, marker):' in gs
    and 'FB-158 (аудит-45, R77-03' in gs)
chk('FB-158 UNKNOWN-подсказки',
    'без pid-файла' in gs and 'не читается' in gs
    and 'rm -rf {LOCK_DIR}' in gs)
# FB-159: refresh-lock
chk('FB-159 refresh-lock',
    '_DNS_STATUS_REFRESH = threading.Lock()' in gs
    and '_DNS_STATUS_REFRESH.acquire(blocking=False)' in gs
    and 'FB-159 (аудит-45, R77-04' in gs)
# FB-160: флаги маршрута
chk('FB-160 флаги',
    'if not flags & 0x1 or flags & 0x200:' in gs
    and "p[0].startswith('ppp')" in gs
    and 'FB-160 (аудит-45, R77-05' in gs)
# FB-161: approx-контракт
chk('FB-161 approx', "'approx': mem[2]" in gs
    and '(total, avail, False)' in gs
    and '(total, est, True)' in gs
    and 'FB-161 (аудит-45, R77-06' in gs)
# FB-162/163: метки
chk('FB-162 метка', 'Скорость: счётчики интерфейса' in gs
    and "счётчики интерфейса '+d.rate.iface" in gs
    and 'FB-162 (аудит-45, R77-07' in gs)
chk('FB-163 текст', 'Маршрут по умолчанию найден' in gs
    and 'Интернет подключён' not in gs
    and 'FB-163 (аудит-45, R77-08' in gs)
# FB-166: except сужен в _dash_lists_counts, noqa снят
_i = gs.index('def _dash_lists_counts')
_j = gs.index('def _dashboard_snapshot')
seg = gs[_i:_j]
chk('FB-166 except в _dash_lists_counts (r89: +za-блок)',
    'except Exception:' not in seg
    and seg.count('except (OSError, ValueError):') == 3)
chk('FB-166 noqa снят', '# noqa: F401' not in gs
    and 'from lists_core import (' in gs)
# Инварианты целости (класс Q0)
chk('Q0 before_request ×1', gs.count('@app.before_request') == 1)
chk('Q0 after_request ×1', gs.count('@app.after_request') == 1)
chk('Q0 обёртки argv-3 ×2 / env ×2',
    gs.count("'/bin/sh', '-c', body],") == 2
    and gs.count('env={**os.environ,') == 2)
chk('редакция на панели не отображается (FB-194)',
    gs.count('<span>ред. 82</span>') == 0)
if not fails:
    print('OK z53-1: static')
else:
    print('BAD z53-1: ' + '; '.join(fails))
PYZ53A
grep -q '^OK ' "$F/z53s.out" \
    && ok "Z53-1: статика: FB-156 (invalid/unknown/unrecognized/unsupported в чёрном списке deploy), FB-157 (_UPDATE_START_LOCK), FB-158 (_proc_cmdline_contains + UNKNOWN-подсказки rm -rf), FB-159 (_DNS_STATUS_REFRESH), FB-160 (RTF_UP/0x200/ppp*), FB-161 (approx), FB-162/163 (метки; «Интернет подключён» удалён), FB-164 (CR→\\r, байт-проверка), FB-166 (except (OSError, ValueError) ×2, noqa снят); Q0-инварианты целы; «ред. 82» ×2" \
    || bad "Z53-1: $(tail -2 "$F/z53s.out" | tr '\n' ' ')"

# Z53-2 (FB-156, поведение): матрица ndmc-диагностик под sh + busybox ash.
Z53D="$F/z53"; mkdir -p "$Z53D/bin"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_on() {")==1{p=0} p{print}' "$DEP" > "$Z53D/fns.st"
cat > "$Z53D/bin/ndmc" <<'EOF'
#!/bin/sh
case "$(cat /tmp/f47chk/z53/mode 2>/dev/null)" in
  invalid)      printf 'Invalid command\n'; exit 0 ;;
  unknown)      printf 'Unknown command in this context\n'; exit 0 ;;
  unrecognized) printf 'Unrecognized command\n'; exit 0 ;;
  unsupported)  printf 'Unsupported command: foo\n'; exit 0 ;;
  invalid_rc)   printf 'Invalid command\n'; exit 3 ;;
  clean)        printf 'interface Bridge0 name Home\nip name-server 127.0.0.1\n'; exit 0 ;;
  on)           printf 'interface Bridge0\nopkg dns-override\n'; exit 0 ;;
  noform)       printf 'no opkg dns-override\n'; exit 0 ;;
  mixed)        printf 'Invalid command\nopkg dns-override\n'; exit 0 ;;
  warnlc)       printf 'warning: something\n'; exit 0 ;;
  errreg)       printf 'ERROR: fake\n'; exit 0 ;;
esac
exit 1
EOF
chmod +x "$Z53D/bin/ndmc"
Z53B=""
z53st() { # $1=режим $2=shell $3=ожидаемый rc (state и LAST совпадают)
    echo "$1" > "$Z53D/mode"
    _r=$(PATH="$Z53D/bin:$PATH" $2 -c '. /tmp/f47chk/z53/fns.st; DNS_OVERRIDE_LAST=9; _kz_dns_override_state; echo rc=$?; echo L=$DNS_OVERRIDE_LAST' </dev/null 2>&1)
    printf '%s' "$_r" | grep -q "rc=$3" && printf '%s' "$_r" | grep -q "L=$3" \
        || Z53B="$Z53B $1($2)=$_r"
}
for _z53sh in sh "busybox ash"; do
    z53st invalid      "$_z53sh" 2
    z53st unknown      "$_z53sh" 2
    z53st unrecognized "$_z53sh" 2
    z53st unsupported  "$_z53sh" 2
    z53st invalid_rc   "$_z53sh" 2
    z53st clean        "$_z53sh" 1
    z53st on           "$_z53sh" 0
    z53st noform       "$_z53sh" 2
    z53st mixed        "$_z53sh" 0
    z53st warnlc       "$_z53sh" 2
    z53st errreg       "$_z53sh" 2
done
if [ -z "$Z53B" ]; then
    ok "Z53-2: FB-156 (sh + busybox ash): Invalid/Unknown/Unrecognized/Unsupported command rc=0 и Invalid rc≠0 → UNKNOWN(2) LAST=2 (fail-closed, K69-01/R77-01); чистый конфиг → OFF(1), директива → ON(0), «no …» → UNKNOWN, директива+Invalid → ON (приоритет ON), warn/ERROR-строки FB-119 живы"
else
    bad "Z53-2:$Z53B"
fi

# Z53-3 (FB-157, поведение): параллельный старт — ровно один Popen.
python3 - "$K" "$F" > "$F/z53b.out" 2>&1 <<'PYZ53B'
import json, os, subprocess, sys, threading, time
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
D = os.path.join(F, 'z53b'); os.makedirs(D, exist_ok=True)
g.UPDATE_STATUS_FILE = os.path.join(D, 'st.json')
g.UPDATE_LOG_FILE = os.path.join(D, 'up.log')
g.LOCK_DIR = os.path.join(D, 'lock')
_oex, _och, _op = os.path.exists, os.chmod, subprocess.Popen
os.path.exists = lambda p: (True if p == '/opt/bin/unblock_update.sh'
                            else _oex(p))
os.chmod = lambda p, m: (None if p == '/opt/bin/unblock_update.sh'
                         else _och(p, m))
class _Cap:
    n = 0
    def __init__(self, *a, **k):
        _Cap.n += 1
        self.pid = 4242
    def poll(self, *a):
        return None
    def wait(self, *a, **k):
        return 0
subprocess.Popen = _Cap
# Медленное чтение статуса: до правки оба потока успевали прочитать
# idle до чьей-либо записи running (ревью r77: 5/5 × 2 Popen).
_rd = g._read_update_status
def slow_rd():
    time.sleep(0.35)
    return _rd()
g._read_update_status = slow_rd
starts, errs = [], []
bar = threading.Barrier(2)
def worker():
    bar.wait()
    try:
        g.apply_unblock_async()
        starts.append(1)
    except RuntimeError as e:
        errs.append(str(e))
t1 = threading.Thread(target=worker)
t2 = threading.Thread(target=worker)
t1.start(); t2.start(); t1.join(); t2.join()
chk('FB-157 один Popen', _Cap.n == 1)
chk('FB-157 один старт и один 409',
    len(starts) == 1 and len(errs) == 1)
chk('FB-157 статус running', json.load(
    open(g.UPDATE_STATUS_FILE))['status'] == 'running')
os.path.exists = _oex; os.chmod = _och
subprocess.Popen = _op
g._read_update_status = _rd
if not fails:
    print('OK z53-3: single-flight start')
else:
    print('BAD z53-3: ' + '; '.join(fails))
PYZ53B
grep -q '^OK ' "$F/z53b.out" \
    && ok "Z53-3: FB-157: два параллельных apply_unblock_async (барьер + медленное чтение статуса) → ровно 1 Popen, 1 старт и 1×RuntimeError; проигравший внутри lock видит fresh running (R77-02)" \
    || bad "Z53-3: $(tail -2 "$F/z53b.out" | tr '\n' ' ')"

# Z53-4 (FB-158, поведение): фикстуры lock-каталога.
python3 - "$K" "$F" > "$F/z53c.out" 2>&1 <<'PYZ53C'
import json, os, subprocess, sys, time
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
D = os.path.join(F, 'z53c'); os.makedirs(D, exist_ok=True)
g.UPDATE_STATUS_FILE = os.path.join(D, 'st.json')
g.UPDATE_LOG_FILE = os.path.join(D, 'up.log')
g.LOCK_DIR = os.path.join(D, 'lock')
_oex, _och, _op = os.path.exists, os.chmod, subprocess.Popen
os.path.exists = lambda p: (True if p == '/opt/bin/unblock_update.sh'
                            else _oex(p))
os.chmod = lambda p, m: (None if p == '/opt/bin/unblock_update.sh'
                         else _och(p, m))
POPS = []
class _Cap:
    def __init__(self, *a, **k):
        POPS.append(1)
        self.pid = 4242
    def poll(self, *a):
        return None
    def wait(self, *a, **k):
        return 0
subprocess.Popen = _Cap
def stale():
    with open(g.UPDATE_STATUS_FILE, 'w') as f:
        json.dump({'status': 'running',
                   'ts': int(time.time()) - 9999,
                   'message': 'x'}, f)
def attempt():
    del POPS[:]
    try:
        g.apply_unblock_async()
        return 'start'
    except RuntimeError as e:
        return 'refuse:' + str(e)
# 1) lock-каталог без pid → UNKNOWN-отказ, каталог цел, Popen нет
os.makedirs(g.LOCK_DIR, exist_ok=True)
stale(); r1 = attempt()
chk('FB-158 без pid → отказ', r1.startswith('refuse:'))
chk('FB-158 без pid: каталог цел', os.path.isdir(g.LOCK_DIR))
chk('FB-158 без pid: Popen нет', not POPS)
chk('FB-158 без pid: подсказка rm -rf', 'rm -rf' in r1)
# 2) мусорный pid → UNKNOWN-отказ, каталог цел
with open(os.path.join(g.LOCK_DIR, 'pid'), 'w') as f:
    f.write('abc')
stale(); r2 = attempt()
chk('FB-158 мусорный pid → отказ', r2.startswith('refuse:'))
chk('FB-158 мусорный pid: каталог цел', os.path.isdir(g.LOCK_DIR))
chk('FB-158 мусорный pid: Popen нет', not POPS)
chk('FB-158 мусорный pid: подсказка rm -rf', 'rm -rf' in r2)
# 3) мёртвый pid → снятие lock, старт
dead = None
for cand in range(400000, 500000):
    try:
        os.kill(cand, 0)
    except OSError:
        dead = str(cand)
        break
chk('заготовка: мёртвый pid найден', dead is not None)
with open(os.path.join(g.LOCK_DIR, 'pid'), 'w') as f:
    f.write(dead)
stale(); r3 = attempt()
chk('FB-158 мёртвый pid → старт', r3 == 'start')
chk('FB-158 мёртвый pid: lock снят', not os.path.exists(g.LOCK_DIR))
chk('FB-158 мёртвый pid: Popen 1', len(POPS) == 1)
# 4) живой ЧУЖОЙ pid (переиспользованный) → снятие lock, старт
os.makedirs(g.LOCK_DIR, exist_ok=True)
with open(os.path.join(g.LOCK_DIR, 'pid'), 'w') as f:
    f.write(str(os.getpid()))
stale(); r4 = attempt()
chk('FB-158 живой чужой → старт', r4 == 'start')
chk('FB-158 живой чужой: lock снят', not os.path.exists(g.LOCK_DIR))
chk('FB-158 живой чужой: Popen 1', len(POPS) == 1)
# 5) живой СВОЙ pid (unblock_update.sh в cmdline, exec -a) → 409
own = _op(['bash', '-c', 'exec -a unblock_update.sh sleep 30'])
time.sleep(0.1)
os.makedirs(g.LOCK_DIR, exist_ok=True)
with open(os.path.join(g.LOCK_DIR, 'pid'), 'w') as f:
    f.write(str(own.pid))
stale(); r5 = attempt()
own.terminate(); own.wait()
chk('FB-158 живой свой → отказ', r5.startswith('refuse:'))
chk('FB-158 живой свой: каталог цел', os.path.isdir(g.LOCK_DIR))
chk('FB-158 живой свой: Popen нет', not POPS)
chk('FB-158 живой свой: «ещё выполняется»', 'ещё выполняется' in r5)
os.path.exists = _oex; os.chmod = _och
subprocess.Popen = _op
if not fails:
    print('OK z53-4: lock fixtures')
else:
    print('BAD z53-4: ' + '; '.join(fails))
PYZ53C
grep -q '^OK ' "$F/z53c.out" \
    && ok "Z53-4: FB-158: без pid и мусорный pid → UNKNOWN-отказ (каталог цел, Popen нет, rm -rf-подсказка); мёртвый и переиспользованный pid → lock снят, старт; живой свой (cmdline unblock_update.sh) → 409 (R77-03)" \
    || bad "Z53-4: $(tail -2 "$F/z53c.out" | tr '\n' ' ')"

# Z53-5 (FB-159, поведение): single-flight refresh /api/dns-status.
python3 - "$K" "$F" > "$F/z53d.out" 2>&1 <<'PYZ53D'
import base64, os, sys, threading, time
K, F = sys.argv[1], sys.argv[2]
B = os.path.join(F, 'z53bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
calls = [0]
entered = threading.Event()
def _probe():
    calls[0] += 1
    entered.set()
    time.sleep(0.45)
    return {'n': calls[0], 'ok': True}
g.check_dns_ports = _probe
H = {'Authorization': 'Basic '
     + base64.b64encode(b'admin:testpass').decode()}
# Фаза 1: пустой кэш, два одновременных запроса → один probe,
# оба получают свежие данные (ждать приходится только без stale).
g._DNS_STATUS_CACHE['ts'] = 0.0
g._DNS_STATUS_CACHE['data'] = None
res = {}
bar = threading.Barrier(2)
def get(tag):
    c = g.app.test_client()
    bar.wait()
    res[tag] = c.get('/api/dns-status', headers=H).get_json()
t1 = threading.Thread(target=get, args=('a',))
t2 = threading.Thread(target=get, args=('b',))
t1.start(); t2.start(); t1.join(); t2.join()
chk('FB-159 пустой кэш: один probe на двоих', calls[0] == 1)
chk('FB-159 пустой кэш: оба со свежими данными',
    res.get('a') == {'n': 1, 'ok': True}
    and res.get('b') == {'n': 1, 'ok': True})
# Фаза 2: refresh уже идёт → параллельный запрос получает stale.
calls[0] = 0
entered.clear()
g._DNS_STATUS_CACHE['ts'] = time.time()
g._DNS_STATUS_CACHE['data'] = {'n': 99, 'ok': True}
c1 = g.app.test_client()
chk('FB-159 кэш-хит без refresh', calls[0] == 0
    and c1.get('/api/dns-status', headers=H).get_json()['n'] == 99)
g._DNS_STATUS_CACHE['ts'] -= g._DNS_STATUS_TTL + 1
res2 = {}
def bg():
    c = g.app.test_client()
    res2['r'] = c.get('/api/dns-status', headers=H).get_json()
th = threading.Thread(target=bg)
th.start()
entered.wait(2.0)
c2 = g.app.test_client()
t0 = time.time()
j2 = c2.get('/api/dns-status', headers=H).get_json()
dt = time.time() - t0
th.join()
chk('FB-159 stale-ответ во время refresh (быстро, старые данные)',
    dt < 0.25 and j2['n'] == 99)
chk('FB-159 refresh один, итог свежий',
    calls[0] == 1 and res2.get('r', {}).get('n') == 1)
if not fails:
    print('OK z53-5: dns single-flight')
else:
    print('BAD z53-5: ' + '; '.join(fails))
PYZ53D
grep -q '^OK ' "$F/z53d.out" \
    && ok "Z53-5: FB-159: два одновременных /api/dns-status на пустом кэше → 1 check_dns_ports, оба со свежими данными; во время refresh параллельный запрос получает stale (n=99) мгновенно; timestamp — по завершении probe (R77-04)" \
    || bad "Z53-5: $(tail -2 "$F/z53d.out" | tr '\n' ' ')"

# Z53-6 (FB-160, поведение): фикстуры /proc/net/route.
python3 - "$K" "$F" > "$F/z53e.out" 2>&1 <<'PYZ53E'
import os, sys
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
D = os.path.join(F, 'z53e'); os.makedirs(D, exist_ok=True)
def route(lines):
    p = os.path.join(D, 'r')
    open(p, 'w').write(
        'Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\tMTU\tWindow\tIRTT\n'
        + ''.join(lines))
    return g._proc_route_default_iface(p)
L = lambda iface, flags: (
    iface + '\t00000000\t0100A8C0\t' + flags
    + '\t0\t0\t0\t00000000\t0\t0\t0\n')
chk('FB-160 PPP-дефолт 0001 → ppp0',
    route([L('ppp0', '0001')]) == 'ppp0')
chk('FB-160 gateway-без-UP 0002 → None',
    route([L('eth0', '0002')]) is None)
chk('FB-160 UP|GATEWAY 0003 → eth0',
    route([L('eth0', '0003')]) == 'eth0')
chk('FB-160 UP|GATEWAY|REJECT 0203 → None',
    route([L('eth0', '0203')]) is None)
chk('FB-160 ppp без UP 0000 → None',
    route([L('ppp0', '0000')]) is None)
chk('FB-160 non-ppp без gateway 0001 → None',
    route([L('eth0', '0001')]) is None)
chk('FB-160 multi: первый подходящий',
    route([L('br0', '0003'), L('ppp0', '0001')]) == 'br0')
chk('FB-160 multi: ppp раньше eth',
    route([L('ppp0', '0001'), L('eth0', '0003')]) == 'ppp0')
if not fails:
    print('OK z53-6: route flags')
else:
    print('BAD z53-6: ' + '; '.join(fails))
PYZ53E
grep -q '^OK ' "$F/z53e.out" \
    && ok "Z53-6: FB-160: PPP-дефолт (0001) → ppp*; gateway-без-UP (0002) и REJECT (0203) → None; штатный 0003 → iface; не-ppp без gateway и ppp без UP → None; multi-default — первый подходящий (R77-05)" \
    || bad "Z53-6: $(tail -2 "$F/z53e.out" | tr '\n' ' ')"

# Z53-7 (FB-161, поведение): фикстуры /proc/meminfo.
python3 - "$K" "$F" > "$F/z53f.out" 2>&1 <<'PYZ53F'
import os, sys
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
D = os.path.join(F, 'z53f'); os.makedirs(D, exist_ok=True)
def mem(text):
    p = os.path.join(D, 'm')
    open(p, 'w').write(text)
    return g._meminfo_totals(p)
modern = ('MemTotal: 100000 kB\nMemFree: 10000 kB\n'
          'Buffers: 2000 kB\nCached: 30000 kB\n'
          'MemAvailable: 40000 kB\n')
chk('FB-161 современный meminfo: точное значение, approx=False',
    mem(modern) == (100000, 40000, False))
# FB-171 (аудит-46, A-R79-05/B-R79-01): независимый oracle —
# традиционная free-style сумма MemFree+Buffers+Cached (42000), а не
# формула из кода (прежде тест повторял выбор реализации — 38000).
legacy = ('MemTotal: 100000 kB\nMemFree: 10000 kB\n'
          'Buffers: 2000 kB\nCached: 30000 kB\nSwapCached: 5 kB\n')
chk('FB-171 legacy: free-style MemFree+Buffers+Cached=42000, approx=True',
    mem(legacy) == (100000, 42000, True))
chk('FB-161/171 legacy без Buffers: Buffers=0',
    mem('MemTotal: 100000 kB\nMemFree: 10000 kB\n'
        'Cached: 30000 kB\n') == (100000, 40000, True))
chk('FB-171 clamp: оценка не выше MemTotal',
    mem('MemTotal: 100000 kB\nMemFree: 90000 kB\n'
        'Buffers: 5000 kB\nCached: 30000 kB\n')
    == (100000, 100000, True))
chk('FB-161 без MemAvailable и Cached: None',
    mem('MemTotal: 100000 kB\nMemFree: 10000 kB\n') is None)
chk('FB-161 пустой файл: None', mem('') is None)
if not fails:
    print('OK z53-7: meminfo legacy')
else:
    print('BAD z53-7: ' + '; '.join(fails))
PYZ53F
grep -q '^OK ' "$F/z53f.out" \
    && ok "Z53-7: FB-161/171: современный meminfo → (total, available, False); legacy → free-style ≈-оценка MemFree+Buffers+Cached по независимому oracle (42000; SwapCached не путается с Cached); без Buffers → Buffers=0; clamp в [0, total]; без Cached → None; пустой → None (R77-06 + A-R79-05/B-R79-01)" \
    || bad "Z53-7: $(tail -2 "$F/z53f.out" | tr '\n' ' ')"

# Z53-8 (FB-162/163/161-UI, рендер): метки дашборда.
python3 - "$K" "$F" > "$F/z53g.out" 2>&1 <<'PYZ53G'
import base64, os, sys
K, F = sys.argv[1], sys.argv[2]
B = os.path.join(F, 'z53bot8')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
c = g.app.test_client()
H = {'Authorization': 'Basic '
     + base64.b64encode(b'admin:testpass').decode()}
h = c.get('/', headers=H).data.decode('utf-8', 'replace')
chk('FB-162 h2 «Скорость: счётчики интерфейса»',
    'Скорость: счётчики интерфейса' in h)
chk('FB-162 JS «счётчики интерфейса "+iface',
    "счётчики интерфейса '+d.rate.iface" in h)
chk('FB-162 прежних меток нет',
    'Скорость интернета' not in h
    and "('интерфейс '+d.rate.iface)" not in h)
chk('FB-163 «Маршрут по умолчанию найден» ×2 (лента + heroSub)',
    h.count('Маршрут по умолчанию найден') == 2)
chk('FB-163 «Интернет подключён» удалён',
    'Интернет подключён' not in h)
chk('FB-161 RAM: разметка ≈',
    "d.ram.approx?'≈':''" in h and '≈оценка: ' in h)
chk('редакция на панели не отображается (FB-194)', 'ред. 82' not in h)
if not fails:
    print('OK z53-8: labels')
else:
    print('BAD z53-8: ' + '; '.join(fails))
PYZ53G
grep -q '^OK ' "$F/z53g.out" \
    && ok "Z53-8: рендер '/': h2 «Скорость: счётчики интерфейса» + JS-метка «счётчики интерфейса <iface>» (прежних «Скорость интернета»/«интерфейс …» нет); «Маршрут по умолчанию найден» ×2, «Интернет подключён» удалён (FB-163); RAM-виджет размечает ≈-оценку (FB-161); подвал «ред. 82»" \
    || bad "Z53-8: $(tail -2 "$F/z53g.out" | tr '\n' ' ')"

# Z53-9 (FB-165): verify42/43 входят в tests/ (поставка ZIP).
_sd=$(cd "$(dirname "$0")" && pwd)
Z53V=""
if [ -f "$_sd/verify42.sh" ]; then
    Z53DIR="$_sd"
elif [ -f "$_sd/tests/verify42.sh" ]; then
    Z53DIR="$_sd/tests"
else
    Z53DIR=""
    Z53V="$Z53V нет-verify42-в-поставке"
fi
if [ -n "$Z53DIR" ]; then
    for _vf in verify42.sh verify43.py verify43_ext.py; do
        [ -f "$Z53DIR/$_vf" ] || Z53V="$Z53V нет-$_vf"
    done
    bash -n "$Z53DIR/verify42.sh" 2>/dev/null \
        || Z53V="$Z53V verify42-не-проходит-bash-n"
    python3 - "$Z53DIR" <<'PYZ53H' 2>/dev/null || Z53V="$Z53V verify43-не-парсится"
import ast, os, sys
d = sys.argv[1]
for fn in ('verify43.py', 'verify43_ext.py'):
    ast.parse(open(os.path.join(d, fn),
                   encoding='utf-8').read())
PYZ53H
    # FB-178 (аудит-46, B-R79-04): кэш компиляции — во временный
    # каталог, дерево проекта не трогается.
    grep -q 'PYTHONPYCACHEPREFIX' "$Z53DIR/verify42.sh" \
        || Z53V="$Z53V verify42-без-pycache-prefix(FB-178)"
    grep -q 'rm -rf "$K/opt/etc/bot/__pycache__"' "$Z53DIR/verify42.sh" \
        && Z53V="$Z53V verify42-трогает-pycache-дерева(FB-178)"
    # FB-179 (B-R79-05): корень — аргумент, изоляция — mkdtemp.
    grep -q 'sys.argv\[1\]' "$Z53DIR/verify43.py" \
        || Z53V="$Z53V verify43-без-аргумента-корня(FB-179)"
    grep -q 'mkdtemp' "$Z53DIR/verify43_ext.py" \
        || Z53V="$Z53V verify43_ext-без-mkdtemp(FB-179)"
    grep -q 'rmtree' "$Z53DIR/verify43.py" \
        || Z53V="$Z53V verify43-без-очистки-каталогов(FB-184)"
    grep -q 'secret_file' "$Z53DIR/verify43.py" \
        || Z53V="$Z53V verify43-без-изоляции-секрета(FB-184)"
    grep -q 'rmtree' "$Z53DIR/verify43_ext.py" \
        || Z53V="$Z53V verify43_ext-без-очистки-каталогов(FB-184)"
    grep -q 'g.config.__file__' "$Z53DIR/verify43.py" \
        || Z53V="$Z53V verify43-без-preflight-изоляции(FB-188)"
    grep -q 'g.config.__file__' "$Z53DIR/verify43_ext.py" \
        || Z53V="$Z53V verify43_ext-без-preflight-изоляции(FB-188)"
    grep -Fq "prefix='a43_', dir=_TMPDIR" "$Z53DIR/verify43.py" \
        || Z53V="$Z53V verify43-fixture-вне-TMPDIR(FB-189)"
fi
if [ -z "$Z53V" ]; then
    ok "Z53-9: FB-165: verify42.sh + verify43.py + verify43_ext.py входят в tests/ (bash -n и ast-parse чисты); FB-178: verify42 компилирует во временный каталог (PYTHONPYCACHEPREFIX), дерево проекта не трогает; FB-179: verify43 принимают корень аргументом (sys.argv[1], mkdtemp); стенды f16/f28/f31–f33 и namespace-стенды — внешние, в ZIP не входят (R77-10 + B-R79-04/05); FB-184 (аудит-47): verify43 убирают временные каталоги (rmtree/atexit) и держат секрет в копии (B-R80-05); FB-188/189 (аудит-48): preflight-ассерты изоляции (модуль/конфиг/секрет из копии) + fixture внутри очищаемого _TMPDIR (KZ81-03/KZ81-04)"
else
    bad "Z53-9:$Z53V"
fi

# ═══ Z54. Закрытие-аудита-46 (внешние аудиты r79, этапы 1–3) ═══

# Z54-1 (FB-167, поведение): readback-транзакция включения при rc≠0.
Z54A="$F/z54"; mkdir -p "$Z54A/bin"
{ extract_fn _kz_dns_override_state "$DEP"; echo; extract_fn _kz_dns_override_off "$DEP"; echo; extract_fn _kz_dns_override_disable "$DEP"; echo; extract_fn _kz_dns_override_on "$DEP"; echo; extract_fn _kz_dns_override_enable "$DEP"; } > "$Z54A/fn.sh"
cat > "$Z54A/bin/ndmc" <<'EOF'
#!/bin/sh
J=/tmp/f47chk/z54/journal
echo "ndmc $*" >> "$J"
M=$(cat /tmp/f47chk/z54/mode 2>/dev/null)
case "$*" in
  *'show running-config'*)
    [ "$M" = rc_unknown ] && { printf 'Invalid command\n'; exit 0; }
    [ "$(cat /tmp/f47chk/z54/state 2>/dev/null)" = on ] && echo 'opkg dns-override'
    echo 'interface Bridge0'
    exit 0 ;;
  *'system configuration save'*) exit 0 ;;
  *'no opkg dns-override'*)
    [ "$M" = rc_applied_rbfail ] && exit 1
    echo off > /tmp/f47chk/z54/state
    exit 0 ;;
  *'opkg dns-override'*)
    case "$M" in
      rc_notapplied|rc_unknown) exit 1 ;;
      rc_applied|rc_applied_rbfail) echo on > /tmp/f47chk/z54/state; exit 1 ;;
      *) echo on > /tmp/f47chk/z54/state; exit 0 ;;
    esac ;;
esac
exit 0
EOF
chmod +x "$Z54A/bin/ndmc"
cat > "$Z54A/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/z54/fn.sh
warn() { printf '%s\n' "W|$*"; }
PATH="/tmp/f47chk/z54/bin:/usr/bin:/bin"; export PATH
echo off > /tmp/f47chk/z54/state
DNS_OVERRIDE_SELF=0; DNS_OVERRIDE_OK=0; DNS_OVERRIDE_LAST=9
_kz_dns_override_enable
RC=$?
echo "RESULT rc=$RC SELF=$DNS_OVERRIDE_SELF state=$(cat /tmp/f47chk/z54/state)"
EOF
chmod +x "$Z54A/run.sh"
Z54AB=""
z54_case() { # режим ожид_rc ожид_self ожид_state ожид_no-override-вызовов
    echo "$1" > "$Z54A/mode"
    rm -f "$Z54A/journal"
    _o=$(sh "$Z54A/run.sh" 2>&1)
    _ok=1
    printf '%s' "$_o" | grep -q "RESULT rc=$2 SELF=$3 state=$4" || _ok=0
    _no=$(grep -c 'ndmc -c no opkg dns-override' "$Z54A/journal" 2>/dev/null || true)
    [ "$_no" = "$5" ] || _ok=0
    [ "$_ok" = 1 ] || Z54AB="$Z54AB $1(=$2/$3/$4/no=$5;факт:$(printf '%s' "$_o" | grep RESULT | tail -1; echo j=$_no))"
}
z54_case ok 0 1 on 0
z54_case rc_notapplied 1 0 off 0
z54_case rc_applied 1 0 off 1
z54_case rc_applied_rbfail 1 1 on 1
z54_case rc_unknown 2 0 off 0
# FB-180 (аудит-47, A-R80-DNS-02/B-R80-02): текст recovery-команд —
# копируемая форма, как у соседних блоков FB-117/FB-92 (аудит r80
# печатал «ndmc -c \no opkg dns-override\» из-за лишнего экранирования).
echo rc_applied_rbfail > "$Z54A/mode"; rm -f "$Z54A/journal"
_o=$(sh "$Z54A/run.sh" 2>&1)
printf '%s' "$_o" | grep -q 'ndmc -c "no opkg dns-override"' \
    || Z54AB="$Z54AB FB180-нет-корректной-no-override"
printf '%s' "$_o" | grep -q 'ndmc -c "system configuration save"' \
    || Z54AB="$Z54AB FB180-нет-корректной-save"
printf '%s' "$_o" | grep -q 'ndmc -c "show running-config" | grep dns-override' \
    || Z54AB="$Z54AB FB180-нет-корректного-readback"
printf '%s' "$_o" | grep -q 'ndmc -c \\' \
    && Z54AB="$Z54AB FB180-старое-экранирование(on-ветка)"
echo rc_unknown > "$Z54A/mode"; rm -f "$Z54A/journal"
_o=$(sh "$Z54A/run.sh" 2>&1)
printf '%s' "$_o" | grep -q 'ndmc -c "show running-config" | grep dns-override' \
    || Z54AB="$Z54AB FB180-нет-корректного-readback(unknown)"
printf '%s' "$_o" | grep -q 'ndmc -c \\' \
    && Z54AB="$Z54AB FB180-старое-экранирование(unknown-ветка)"
if [ -z "$Z54AB" ]; then
    ok "Z54-1: FB-167: rc≠0 включения — readback-транзакция: OFF-подтверждён → rc 1 без действий; применился (partial-success) → ownership + проверяемый откат (no-override+save в журнале), откат-провал → SELF=1 «МОЖЕТ остаться»; UNKNOWN → rc 2 без утверждений о порте 53; штатный rc=0 → SELF=1 (регрессия A-R79-01); FB-180 (аудит-47): recovery-команды — копируемые, без лишнего экранирования, обе ветки (A-R80-DNS-02/B-R80-02)"
else
    bad "Z54-1:$Z54AB"
fi

# Z54-2 (FB-168, поведение): single-flight протокольного старта.
python3 - "$K" "$F" > "$F/z54b.out" 2>&1 <<'PYZ54B'
import json, os, subprocess, sys, threading, time
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond, detail=None):
    if not cond:
        fails.append(name)
D = os.path.join(F, 'z54proto'); os.makedirs(D, exist_ok=True)
g.PROTO_UPD_STATUS = os.path.join(D, 'st.json')
g.PROTO_UPD_LOG = os.path.join(D, 'run.log')
g.config.paths['update_protocols'] = os.path.join(D, 'upd.sh')
open(os.path.join(D, 'upd.sh'), 'w').write('#!/bin/sh\nexit 0\n')
_oex, _op = os.path.exists, subprocess.Popen
os.path.exists = lambda p: (True
                            if p.endswith('update_protocols.sh')
                            else _oex(p))
POPS = []
class _Cap:
    def __init__(self, *a, **k):
        POPS.append(1)
        self.pid = 4300
    def wait(self, *a, **k):
        return 0
subprocess.Popen = _Cap
_rd = g._read_proto_update
def slow_rd():
    time.sleep(0.35)
    return _rd()
g._read_proto_update = slow_rd
errs = []
def w():
    try:
        g.start_proto_update('xray')
    except RuntimeError as e:
        errs.append(str(e))
t1 = threading.Thread(target=w)
t2 = threading.Thread(target=w)
t1.start(); t2.start(); t1.join(); t2.join()
g._read_proto_update = _rd
chk('FB-168 гонка: 1 Popen + 1×RuntimeError',
    len(POPS) == 1 and len(errs) == 1,
    'popens=%d errs=%r' % (len(POPS), errs))
if os.path.exists(g.PROTO_UPD_STATUS):
    os.remove(g.PROTO_UPD_STATUS)
class _Boom:
    def __init__(self, *a, **k):
        raise OSError('exec format error')
subprocess.Popen = _Boom
popen_err = False
try:
    g.start_proto_update('xray')
except OSError:
    popen_err = True
st = json.load(open(g.PROTO_UPD_STATUS))
chk('FB-168 сбой Popen: атомарный error с диагнозом',
    popen_err and st.get('status') == 'error'
    and 'Запуск не удался' in st.get('message', '')
    and st.get('action') == 'xray', repr(st))
# FB-181 (аудит-47, A-R80-PROTO-01/B-R80-03): failure-атомарность
# подготовки — провал записи running не запускает wrapper (прежде
# второй запрос запускал второй wrapper, .wtmp сиротели), провал
# второго mkstemp после публикации running — атомарный error вместо
# застрявшего «Запуск…», без утечки fd.
import tempfile
_orep, _mks = os.replace, tempfile.mkstemp
def _fresh():
    for _f in os.listdir(D):
        os.remove(os.path.join(D, _f))
    # sc-проверка существует: upd.sh пересоздаётся (FileNotFoundError
    # на проверке скрипта — не тот отказ, который проверяет сценарий)
    open(os.path.join(D, 'upd.sh'), 'w').write('#!/bin/sh\nexit 0\n')
    POPS.clear()
_fresh()
def _bad_rep(s, d2):
    if 'st.json.wtmp' in s:
        raise OSError(28, 'No space left on device')
    return _orep(s, d2)
os.replace = _bad_rep
_ra = None
try:
    g.start_proto_update('xray')
except OSError as _e:
    _ra = _e
os.replace = _orep
_orph = [f for f in os.listdir(D) if '.wtmp' in f]
chk('FB-181(A): провал публикации running → отказ без Popen и без '
    'сирот .wtmp (прежде — второй запрос запускал второй wrapper)',
    _ra is not None
    and not isinstance(_ra, FileNotFoundError)
    and not POPS and not _orph,
    'ra=%r popens=%d orph=%r' % (_ra, len(POPS), _orph))
_fresh()
_mkc = [0]
def _bad_mk(*a, **k):
    _mkc[0] += 1
    if _mkc[0] == 2:
        raise OSError(28, 'No space left on device')
    return _mks(*a, **k)
tempfile.mkstemp = _bad_mk
_fds0 = len(os.listdir('/proc/self/fd'))
_rb = None
try:
    g.start_proto_update('xray')
except OSError as _e:
    _rb = _e
_fds1 = len(os.listdir('/proc/self/fd'))
tempfile.mkstemp = _mks
_st = None
if os.path.exists(g.PROTO_UPD_STATUS):
    _st = json.load(open(g.PROTO_UPD_STATUS))
_orph2 = [f for f in os.listdir(D) if '.wtmp' in f]
chk('FB-181/187(B): провал второго mkstemp (подготовка ДО running) → '
    'исключение + атомарный error «Не удалось зафиксировать статус '
    'запуска», fd без утечки, без сирот',
    _rb is not None and _rb.errno == 28 and not POPS
    and _st is not None and _st.get('status') == 'error'
    and 'Не удалось зафиксировать статус запуска' in _st.get('message', '')
    and _fds1 - _fds0 == 0 and not _orph2,
    'rb=%r st=%r dfds=%d orph=%r' % (_rb, _st, _fds1 - _fds0,
                                     _orph2))
# FB-187 (аудит-48, A-R81-PROTO-02/KZ81-02): ПОСТОЯННЫЙ ENOSPC — все
# mkstemp после первого отказывают: подготовки не хватило, свежего
# running нет вовсе, повтор не блокируется таймаутом 900 с (прежде
# статус застревал в «running/Запуск…», а error-публикация падала
# в том же ENOSPC).
_fresh()
_mkc2 = [0]
def _bad_mk_persist(*a, **k):
    _mkc2[0] += 1
    if _mkc2[0] >= 2:
        raise OSError(28, 'No space left on device')
    return _mks(*a, **k)
tempfile.mkstemp = _bad_mk_persist
_rc = None
try:
    g.start_proto_update('xray')
except OSError:
    _rc = True
tempfile.mkstemp = _mks
subprocess.Popen = _Cap  # место освободилось — повтор штатный
_stC = None
if os.path.exists(g.PROTO_UPD_STATUS):
    _stC = json.load(open(g.PROTO_UPD_STATUS))
_orphC = [f for f in os.listdir(D) if '.wtmp' in f]
_popsC = len(POPS)
_rr = None
try:
    g.start_proto_update('xray')
except RuntimeError as _e2:
    _rr = str(_e2)
chk('FB-187(C): persistent-ENOSPC подготовки → свежего running нет, '
    'Popen нет, повтор НЕ блокируется (прежде — до 900 с лжи)',
    _rc is True and _popsC == 0
    and not (_stC is not None and _stC.get('status') == 'running')
    and _rr is None and not _orphC,
    'rc=%s st=%r popens=%d retry=%r orph=%r'
    % (_rc, _stC, _popsC, _rr, _orphC))
# FB-187(D): running опубликован, Popen падает, и error-публикации
# не хватает места (все mkstemp после двух первых отказывают) —
# running-клейм этой попытки снимается, повтор стартует свободно.
_fresh()
_mkc3 = [0]
def _bad_mk3(*a, **k):
    _mkc3[0] += 1
    if _mkc3[0] >= 3:
        raise OSError(28, 'No space left on device')
    return _mks(*a, **k)
tempfile.mkstemp = _bad_mk3
class _BoomD:
    def __init__(self, *a, **k):
        raise OSError('exec format error')
subprocess.Popen = _BoomD
_rd = None
try:
    g.start_proto_update('xray')
except OSError:
    _rd = True
tempfile.mkstemp = _mks
subprocess.Popen = _Cap
_stD = None
if os.path.exists(g.PROTO_UPD_STATUS):
    _stD = json.load(open(g.PROTO_UPD_STATUS))
_orphD = [f for f in os.listdir(D) if '.wtmp' in f]
_popsD = len(POPS)
_rr2 = None
try:
    g.start_proto_update('xray')
except RuntimeError as _e3:
    _rr2 = str(_e3)
chk('FB-187(D): Popen-сбой + нехватка места для error-публикации → '
    'running-клейм снят (статус не running), повтор без блокировки',
    _rd is True and _popsD == 0
    and not (_stD is not None and _stD.get('status') == 'running')
    and _rr2 is None and not _orphD,
    'rd=%s st=%r popens=%d retry=%r orph=%r'
    % (_rd, _stD, _popsD, _rr2, _orphD))
os.path.exists = _oex
subprocess.Popen = _op
# FB-188 (аудит-48, KZ81-03): изоляция импорта — generator вставляет
# каталог САМОГО файла (FB-188), а не абсолютный /opt/etc/bot: при
# «враждебном» каталоге РАНЬШЕ тестовой копии в sys.path config
# берётся из копии (прежде связывался с установленной панелью, а
# sys.path-хирургия харнесса опаздывала — до import bot_config).
import importlib.util, shutil as _sh
_ISO = os.path.join(F, 'z54iso')
_sh.rmtree(_ISO, ignore_errors=True)
os.makedirs(_ISO, exist_ok=True)
_B2 = os.path.join(_ISO, 'bot')
_sh.copytree(os.path.join(K, 'opt/etc/bot'), _B2,
             ignore=_sh.ignore_patterns('__pycache__'))
_cf2 = os.path.join(_B2, 'bot_config.py')
_l2 = open(_cf2, encoding='utf-8').read().split('\n')
for _i, _ln in enumerate(_l2):
    if "'secret_file':" in _ln and '/opt/etc/bot/.secret_key' in _ln:
        _l2[_i] = "    'secret_file': %r," % os.path.join(_B2, '.sk')
open(_cf2, 'w', encoding='utf-8').write('\n'.join(_l2))
_Host = os.path.join(_ISO, 'hostile')
os.makedirs(_Host, exist_ok=True)
open(os.path.join(_Host, 'bot_config.py'), 'w').write(
    "web_username = 'HOSTILE_MARKER'\n")
_sp = list(sys.path)
# bot_config уже в кэше от основного импорта generator — на время
# пробы кэш снимается, иначе exec взял бы КАТАЛОГ-кэш, а не файлы
_sm_bc = sys.modules.pop('bot_config', None)
sys.path.insert(0, _Host)
try:
    _spec = importlib.util.spec_from_file_location(
        'g_iso_check', os.path.join(_B2, 'generator.py'))
    _mod = importlib.util.module_from_spec(_spec)
    _spec.loader.exec_module(_mod)
finally:
    sys.path[:] = _sp
    if _sm_bc is not None:
        sys.modules['bot_config'] = _sm_bc
    else:
        sys.modules.pop('bot_config', None)
chk('FB-188: config импортируется из каталога generator — не из '
    'стоящего раньше в sys.path «враждебного»/установленного',
    _mod.config.__file__ == os.path.join(_B2, 'bot_config.py')
    and _mod.config.web_username != 'HOSTILE_MARKER',
    'cfg=%r user=%r' % (_mod.config.__file__,
                        _mod.config.web_username))
_sh.rmtree(_ISO, ignore_errors=True)
if not fails:
    print('OK z54-2: proto single-flight')
else:
    print('BAD z54-2: ' + '; '.join(fails))
PYZ54B
grep -q '^OK ' "$F/z54b.out" \
    && ok "Z54-2: FB-168: два параллельных start_proto_update (медленное чтение статуса) → 1 Popen + 1×RuntimeError (повторная проверка внутри _PROTO_UPD_LOCK); сбой Popen → OSError + атомарный error-статус «Запуск не удался» вместо ложного running до таймаута 900 с (A-R79-03); FB-181 (аудит-47): провал публикации running → отказ без Popen и без сирот; провал второго mkstemp → атомарный error вместо застрявшего running, fd без утечки (A-R80-PROTO-01/B-R80-03); FB-187 (аудит-48): вся подготовка до running — persistent-ENOSPC не оставляет свежего статуса и не блокирует повтор, Popen-сбой без места для error снимает running-клейм; FB-188: config из каталога generator, не из «враждебного» (A-R81-PROTO-02/KZ81-02 + KZ81-03)" \
    || bad "Z54-2: $(tail -2 "$F/z54b.out" | tr '\n' ' ')"

# Z54-3 (FB-169, поведение): сериализация DNS-повторов + hosts UTF-8.
python3 - "$K" "$F" > "$F/z54c.out" 2>&1 <<'PYZ54C'
import base64, os, sys, threading, time
K, F = sys.argv[1], sys.argv[2]
B = os.path.join(F, 'z54bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g
fails = []
def chk(name, cond, detail=None):
    if not cond:
        fails.append(name)
calls = {'n': 0, 'cur': 0, 'max': 0}
lk = threading.Lock()
def probe():
    with lk:
        calls['n'] += 1
        calls['cur'] += 1
        calls['max'] = max(calls['max'], calls['cur'])
    time.sleep(0.2)
    with lk:
        calls['cur'] -= 1
    if calls['n'] == 1:
        raise RuntimeError('probe boom')
    return {'ok': True, 'n': calls['n']}
g.check_dns_ports = probe
g._DNS_STATUS_CACHE['ts'] = 0.0
g._DNS_STATUS_CACHE['data'] = None
H = {'Authorization': 'Basic '
     + base64.b64encode(b'admin:testpass').decode()}
res = {}
bar = threading.Barrier(3)
def get(tag):
    c = g.app.test_client()
    bar.wait()
    r = c.get('/api/dns-status', headers=H)
    res[tag] = r.status_code
ths = [threading.Thread(target=get, args=('owner',)),
       threading.Thread(target=get, args=('w1',)),
       threading.Thread(target=get, args=('w2',))]
for t in ths:
    t.start()
for t in ths:
    t.join(8)
codes = sorted(res.values())
chk('FB-169: 3 запроса при стойком исключении → 2 probe (не 3), '
    '0 параллельных (не 2), ровно один 500 и два 200 '
    '(потерпевший — победитель refresh-lock, любой из трёх)',
    calls['n'] == 2 and calls['max'] == 1
    and codes == [200, 200, 500],
    'n=%d max=%d res=%r' % (calls['n'], calls['max'], res))
hp = os.path.join(F, 'z54hosts')
open(hp, 'wb').write(
    b'# --- KeenZOO pinned\n1.2.3.4 srv.example\n\xff\xfe broken\n'
    b'# --- end KeenZOO pinned\n')
g.config.paths['hosts_file'] = hp
try:
    pins = g.read_pinned_hosts()
    chk('FB-169: битый UTF-8 в hosts не роняет читатель пинов',
        isinstance(pins, list))
except Exception as e:
    chk('FB-169: битый UTF-8 в hosts не роняет читатель пинов',
        False, repr(e))
if not fails:
    print('OK z54-3: dns serial + hosts')
else:
    print('BAD z54-3: ' + '; '.join(fails))
PYZ54C
grep -q '^OK ' "$F/z54c.out" \
    && ok "Z54-3: FB-169: холодный кэш + исключение первого probe + 2 ждущих → ровно 2 последовательных probe (прежде 3, из них 2 параллельно), повтор — под refresh-lock, ждущие получают 200 после первой удачной публикации; битый UTF-8 в /opt/etc/hosts больше не даёт UnicodeDecodeError (errors='replace') (B-R79-03)" \
    || bad "Z54-3: $(tail -2 "$F/z54c.out" | tr '\n' ' ')"

# Z54-4 (FB-170, поведение): матрица неготиации Accept-Encoding.
python3 - "$K" "$F" > "$F/z54d.out" 2>&1 <<'PYZ54D'
import base64, os, sys
K, F = sys.argv[1], sys.argv[2]
B = os.path.join(F, 'z54bot')
cf = os.path.join(B, 'bot_config.py')
sys.path.insert(0, B)
import generator as g
fails = []
def chk(name, cond, detail=None):
    if not cond:
        fails.append(name)
c = g.app.test_client()
H = {'Authorization': 'Basic '
     + base64.b64encode(b'admin:testpass').decode()}
PAGE = '/panel?tab=ss'
def hdr(h):
    hh = dict(H)
    if h is not None:
        hh['Accept-Encoding'] = h
    return hh
CASES = [
    (None, None),
    ('gzip', 'gzip'),
    ('gzip;q=0', None),
    ('gzip;q=0, *;q=1', None),
    ('notgzip', None),
    ('GZip', 'gzip'),
    ('*', 'gzip'),
    ('br', None),
    ('gzip;q=0.5', 'gzip'),
    ('identity', None),
    # FB-182 (аудит-47): строгий qvalue RFC 9110 — синтаксически
    # неверный или вне-диапазона q больше не включает сжатие
    # (прежде мусор интерпретировался как q=1.0)
    ('gzip;q=1.000', 'gzip'),
    ('gzip;q=bogus', None),
    ('gzip;q=2', None),
    ('gzip;q=inf', None),
    ('gzip;q=1e3', None),
    # FB-186 (аудит-48): точная ASCII-грамматика — «1» только с
    # нулями, «0»/«1» с пустой дробной частью валидны, [0-9]
    # вместо \d (Unicode-цифры неприемлемы)
    ('gzip;q=1.001', None),
    ('gzip;q=1.999', None),
    ('gzip;q=1.', 'gzip'),
    ('gzip;q=0.', None),
    ('gzip;q=1.0000', None),
    ('gzip;q=0.١', None),
    ('gzip;q=1.１', None),
]
for h, exp in CASES:
    r = c.get(PAGE, headers=hdr(h))
    ce = r.headers.get('Content-Encoding')
    vary = r.headers.get('Vary') or ''
    if ce != exp:
        fails.append('%r→%r (ожидалось %r)'
                     % (h, ce, exp))
    if 'Accept-Encoding' not in vary:
        fails.append('%r: Vary без Accept-Encoding' % (h,))
r = c.get('/api/dashboard', headers=hdr('gzip'))
chk('API <1КБ: без сжатия и без Vary: Accept-Encoding',
    r.headers.get('Content-Encoding') is None
    and 'Accept-Encoding' not in (r.headers.get('Vary') or ''))
# FB-182: Vary-дедуп без учёта регистра — посредник уже поставил
# accept-encoding (нижний регистр): дубль не добавляется
from flask import Response
with g.app.test_request_context('/'):
    _r = Response('x' * 3000, mimetype='text/html')
    _r.headers['Vary'] = 'accept-encoding'
    _r = g.gzip_response(_r)
    _vs = [v.strip() for v in (_r.headers.get('Vary') or '').split(',')]
    _n = sum(1 for v in _vs if v.lower() == 'accept-encoding')
    chk('FB-182: Vary-дедуп регистронезависим (ровно одно поле)',
        _n == 1, repr(_r.headers.get('Vary')))
if not fails:
    print('OK z54-4: gzip negotiation')
else:
    print('BAD z54-4: ' + '; '.join(map(str, fails)))
PYZ54D
grep -q '^OK ' "$F/z54d.out" \
    && ok "Z54-4: FB-170: неготиация RFC 9110: gzip→gzip; без заголовка/gzip;q=0/gzip;q=0,*;q=1/notgzip/br/identity → identity; GZip (регистр!) и * → gzip; gzip;q=0.5 → gzip; Vary: Accept-Encoding на обеих representations (добавлением, Cookie сохраняется); мелкий API — без сжатия и без Vary (A-R79-04/B-R79-02); FB-182 (аудит-47): qvalue строго по RFC — bogus/2/inf/1e3 → identity, 1.000 → gzip; FB-186 (аудит-48): ASCII-грамматика полным совпадением — 1.001/1.999/1.0000/Unicode-цифры → identity, валидные 1. → gzip / 0. → identity; Vary-дедуп регистронезависим (A-R80-HTTP-01/B-R80-04 + A-R81-HTTP-01/KZ81-01)" \
    || bad "Z54-4: $(tail -2 "$F/z54d.out" | tr '\n' ' ')"

# Z54-5 (FB-171, рендер): сброс RAM-виджета при ram=null.
python3 - "$K" "$F" > "$F/z54e.out" 2>&1 <<'PYZ54E'
import base64, os, sys
K, F = sys.argv[1], sys.argv[2]
B = os.path.join(F, 'z54bot')
cf = os.path.join(B, 'bot_config.py')
sys.path.insert(0, B)
import generator as g
fails = []
def chk(name, cond, detail=None):
    if not cond:
        fails.append(name)
c = g.app.test_client()
H = {'Authorization': 'Basic '
     + base64.b64encode(b'admin:testpass').decode()}
h = c.get('/', headers=H).data.decode('utf-8', 'replace')
chk('FB-171: else-ветка ram=null (сброс в «—»)',
    "else{$('ramPct').textContent='—'" in h
    and "нет данных" in h)
chk('FB-171: комментарий free-style формулы в JS',
    'free-style' in h and 'FB-171' in h)
src = open(os.path.join(K, 'opt/etc/bot/generator.py'),
           encoding='utf-8').read()
chk('FB-171: формула free + (buffers or 0) + cached; прежней нет',
    'free + (buffers or 0) + cached' in src
    and 'MemFree+Cached-Buffers' not in src)
if not fails:
    print('OK z54-5: ram null UI')
else:
    print('BAD z54-5: ' + '; '.join(fails))
PYZ54E
grep -q '^OK ' "$F/z54e.out" \
    && ok "Z54-5: FB-171: рендер '/': ram=null → «—»/«нет данных»/пустое кольцо (прежде виджет навсегда хранил последние цифры); JS-комментарий — free-style формула; в коде — free+buffers+cached, прежней формы нет (A-R79-05/B-R79-01; формула — Z53-7)" \
    || bad "Z54-5: $(tail -2 "$F/z54e.out" | tr '\n' ' ')"

# Z54-6 (FB-172, поведение): EPERM ≠ смерть pid.
python3 - "$K" "$F" > "$F/z54f.out" 2>&1 <<'PYZ54F'
import errno, json, os, subprocess, sys, time
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond, detail=None):
    if not cond:
        fails.append(name)
D = os.path.join(F, 'z54lock'); os.makedirs(D, exist_ok=True)
g.UPDATE_STATUS_FILE = os.path.join(D, 'st.json')
g.UPDATE_LOG_FILE = os.path.join(D, 'up.log')
g.LOCK_DIR = os.path.join(D, 'lockdir')
_oex, _och, _op = os.path.exists, os.chmod, subprocess.Popen
os.path.exists = lambda p: (True
                            if p == '/opt/bin/unblock_update.sh'
                            else _oex(p))
os.chmod = lambda p, m: (None
                         if p == '/opt/bin/unblock_update.sh'
                         else _och(p, m))
POPS = []
class _Cap:
    def __init__(self, *a, **k):
        POPS.append(1)
        self.pid = 4300
    def wait(self, *a, **k):
        return 0
subprocess.Popen = _Cap
def stale():
    with open(g.UPDATE_STATUS_FILE, 'w') as f:
        json.dump({'status': 'running',
                   'ts': int(time.time()) - 9999,
                   'message': 'x'}, f)
_kill = os.kill
def kill_eperm(pid, sig):
    if pid == 4321:
        raise PermissionError(1, 'Operation not permitted')
    return _kill(pid, sig)
_rdc = g._proc_cmdline_contains
g._proc_cmdline_contains = lambda pid, m: None
# EPERM: жив, но недоступен → UNKNOWN-отказ, lock цел, Popen нет
os.makedirs(g.LOCK_DIR, exist_ok=True)
open(os.path.join(g.LOCK_DIR, 'pid'), 'w').write('4321')
stale()
os.kill = kill_eperm
del POPS[:]
try:
    g.apply_unblock_async()
    r1 = 'start'
except RuntimeError as e:
    r1 = 'refuse:' + str(e)[:40]
os.kill = _kill
eperm_ok = (r1.startswith('refuse:')
            and os.path.isdir(g.LOCK_DIR)
            and not POPS)
chk('FB-172 EPERM → UNKNOWN-отказ, lock цел, Popen нет',
    eperm_ok, 'r1=%s lock=%s popens=%d'
    % (r1, os.path.isdir(g.LOCK_DIR), len(POPS)))
# ESRCH: доказанная смерть → снятие lock + старт
dead = None
for cand in range(400000, 500000):
    try:
        _kill(cand, 0)
    except OSError as e:
        if e.errno == errno.ESRCH:
            dead = str(cand)
            break
chk('заготовка: ESRCH-мёртвый pid найден', dead is not None)
if dead:
    open(os.path.join(g.LOCK_DIR, 'pid'), 'w').write(dead)
    stale()
    del POPS[:]
    try:
        g.apply_unblock_async()
        r2 = 'start'
    except RuntimeError as e:
        r2 = 'refuse:' + str(e)[:40]
    esrch_ok = (r2 == 'start' and not os.path.exists(g.LOCK_DIR)
                and len(POPS) == 1)
    chk('FB-172 ESRCH → снятие lock + старт', esrch_ok,
        'r2=%s lock=%s popens=%d' % (r2,
                                     os.path.exists(g.LOCK_DIR),
                                     len(POPS)))
g._proc_cmdline_contains = _rdc
os.path.exists = _oex
os.chmod = _och
subprocess.Popen = _op
if not fails:
    print('OK z54-6: EPERM vs ESRCH')
else:
    print('BAD z54-6: ' + '; '.join(fails))
PYZ54F
grep -q '^OK ' "$F/z54f.out" \
    && ok "Z54-6: FB-172: EPERM от os.kill(pid,0) → «жив, личность не доказана» → UNKNOWN-отказ (409) с сохранённым lockdir и без Popen; ESRCH → доказанная смерть: lock снят, старт (A-R79-06)" \
    || bad "Z54-6: $(tail -2 "$F/z54f.out" | tr '\n' ' ')"

# Z54-7 (FB-173, поведение): счётчики интерфейса wg-дефолта.
python3 - "$K" "$F" > "$F/z54g.out" 2>&1 <<'PYZ54G'
import math, os, sys
K, F = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import generator as g
fails = []
def chk(name, cond, detail=None):
    if not cond:
        fails.append(name)
D = os.path.join(F, 'z54net'); os.makedirs(D, exist_ok=True)
HEAD = ('Inter-|   Receive                                                |  Transmit\n'
        ' face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed\n')
open(os.path.join(D, 'net1'), 'w').write(HEAD
    + '  eth0: 1000 10 0 0 0 0 0 0  500 8 0 0 0 0 0 0\n'
    + '   wg0: 2000 20 0 0 0 0 0 0 1000 16 0 0 0 0 0 0\n'
    + '    lo: 5 5 0 0 0 0 0 0 5 5 0 0 0 0 0 0\n')
open(os.path.join(D, 'net2'), 'w').write(HEAD
    + '  eth0: 9000 90 0 0 0 0 0 0 4500 80 0 0 0 0 0 0\n'
    + '   wg0: 10000 100 0 0 0 0 0 0 5000 80 0 0 0 0 0 0\n'
    + '    lo: 5 5 0 0 0 0 0 0 5 5 0 0 0 0 0 0\n')
open(os.path.join(D, 'route'), 'w').write(
    'Iface\tDestination\tGateway\tFlags\tRefCnt\tUse\tMetric\tMask\tMTU\tWindow\tIRTT\n'
    'wg0\t00000000\t0100A8C0\t0003\t0\t0\t0\t00000000\t0\t0\t0\n')
nd = g._proc_net_bytes(os.path.join(D, 'net1'))
chk('по умолчанию wg0 исключён (контракт FB-162 цел)',
    'wg0' not in nd and 'eth0' in nd)
nd2 = g._proc_net_bytes(os.path.join(D, 'net1'), keep=('wg0',))
chk('FB-173: keep=("wg0",) читает wg0', 'wg0' in nd2)
rate = g._net_rate(nd2, g._proc_net_bytes(
    os.path.join(D, 'net2'), keep=('wg0',)), 'wg0', 2.0)
chk('FB-173: rate по wg0 считается (биты/с)',
    rate == (32000.0, 16000.0),
    repr(rate))
kw = dict(stat_path=os.path.join(D, 'net1'),
          mem_path=os.path.join(D, 'net1'),
          net_path=os.path.join(D, 'net1'),
          route_path=os.path.join(D, 'route'),
          arp_path=os.path.join(D, 'no_arp'),
          lease_paths=[os.path.join(D, 'no_leases')])
open(os.path.join(D, 'stat'), 'w').write('cpu  100 0 0 900 0 0 0 0\n')
open(os.path.join(D, 'mem'), 'w').write(
    'MemTotal: 100000 kB\nMemFree: 10000 kB\nMemAvailable: 40000 kB\n')
kw['stat_path'] = os.path.join(D, 'stat')
kw['mem_path'] = os.path.join(D, 'mem')
g._dashboard_snapshot(force=True, **kw)
kw['net_path'] = os.path.join(D, 'net2')
snap = g._dashboard_snapshot(force=True, **kw)
# dt между force-пересборками — реальное время, поэтому точные bps
# недетерминированы; детерминированы iface, положительность и точное
# отношение down:up = 8000:4000 = 2:1 (один и тот же dt).
chk('FB-173: снапшот при wg-дефолте: iface=wg0, rate не пуст',
    snap['rate']['iface'] == 'wg0'
    and snap['rate']['down'] is not None
    and snap['rate']['down'] > 0
    and math.isclose(snap['rate']['down'],
                     2 * snap['rate']['up'], rel_tol=1e-9)
    and snap['wan_up'] is True, repr(snap['rate']))
if not fails:
    print('OK z54-7: wg0 rate')
else:
    print('BAD z54-7: ' + '; '.join(fails))
PYZ54G
grep -q '^OK ' "$F/z54g.out" \
    && ok "Z54-7: FB-173: _proc_net_bytes(keep=(iface,)): wg0 читается при wg-дефолте (rate 4000/2000, снапшот wan_up=True, график больше не прочерк); без keep контракт FB-162 цел (wg исключён) (A-R79-08)" \
    || bad "Z54-7: $(tail -2 "$F/z54g.out" | tr '\n' ' ')"

# Z54-8 (FB-174 + FB-177, статика): тексты и документация.
Z54T=""
grep -q 'Нет IPv4-маршрута по умолчанию' "$GEN" || Z54T="$Z54T нет-текста-FB-174"
grep -q 'Нет маршрута в интернет' "$GEN" && Z54T="$Z54T старый-текст-остался"
grep -q "8 fork'ов" "$GEN" || Z54T="$Z54T нет-8-fork(FB-177)"
grep -q "11 fork'ов" "$GEN" && Z54T="$Z54T осталось-11-fork"
grep -q 'FB-174 (аудит-46' "$GEN" || Z54T="$Z54T нет-маркера-FB-174"
grep -q 'FB-180 (аудит-47' "$DEP" || Z54T="$Z54T нет-маркера-FB-180(deploy)"
grep -q 'FB-181 (аудит-47' "$GEN" || Z54T="$Z54T нет-маркера-FB-181(generator)"
grep -q 'FB-182 (аудит-47' "$GEN" || Z54T="$Z54T нет-маркера-FB-182(generator)"
grep -q 'FB-183 (аудит-47' "$DEP" || Z54T="$Z54T нет-маркера-FB-183(deploy)"
grep -q 'FB-186 (аудит-48' "$GEN" || Z54T="$Z54T нет-маркера-FB-186(generator)"
grep -q 'FB-187 (аудит-48' "$GEN" || Z54T="$Z54T нет-маркера-FB-187(generator)"
grep -q 'FB-188 (аудит-48' "$GEN" || Z54T="$Z54T нет-маркера-FB-188(generator)"
grep -q 'FB-188' "$Z53DIR/verify43.py" || Z54T="$Z54T нет-FB-188-preflight(verify43)"
grep -q 'FB-188' "$Z53DIR/verify43_ext.py" || Z54T="$Z54T нет-FB-188-preflight(verify43_ext)"
grep -q 'FB-189' "$Z53DIR/verify43.py" || Z54T="$Z54T нет-FB-189(verify43)"
if [ -z "$Z54T" ]; then
    ok "Z54-8: FB-174: «Нет IPv4-маршрута по умолчанию» (прежний «Нет маршрута в интернет» удалён; положительный текст r79 не тронут); FB-177: докстринг — «8 fork'ов (4 DoT + 4 DoH)» вместо «11» (A-R79-09 + примечание B); FB-180..FB-183 (аудит-47) + FB-186..FB-189 (аудит-48): маркеры закрытия в deploy/generator/tests на месте"
else
    bad "Z54-8:$Z54T"
fi

# Z54-9 (FB-175 + FB-176, поведение): гигиена deploy.
Z54D="$F/z54dep"; mkdir -p "$Z54D/bin"
awk 'index($0, "_kz_dns_override_state() {")==1{p=1} index($0, "_kz_dns_override_on() {")==1{p=0} p{print}' "$DEP" > "$Z54D/fns.st"
cat > "$Z54D/bin/ndmc" <<'EOF'
#!/bin/sh
case "$(cat /tmp/f47chk/z54dep/mode 2>/dev/null)" in
  cnf)    printf 'Command not found\n'; exit 0 ;;
  notsup) printf 'Not supported\n'; exit 0 ;;
  errreg) printf 'ERROR: real error\n'; exit 0 ;;
  off)    printf 'interface Bridge0\n'; exit 0 ;;
  notice)  printf 'Notice: firmware update available\ninterface Bridge0\n'; exit 0 ;;
  nothing) printf 'Nothing to report\n'; exit 0 ;;
  notin)   printf 'Not in this configuration\n'; exit 0 ;;
esac
exit 1
EOF
chmod +x "$Z54D/bin/ndmc"
Z54DB=""
z54d_case() { # режим shell ожидаемый rc
    echo "$1" > "$Z54D/mode"
    _r=$(PATH="$Z54D/bin:$PATH" $2 -c '. /tmp/f47chk/z54dep/fns.st; DNS_OVERRIDE_LAST=9; _kz_dns_override_state; echo rc=$?; echo L=$DNS_OVERRIDE_LAST' </dev/null 2>&1)
    printf '%s' "$_r" | grep -q "rc=$3" && printf '%s' "$_r" | grep -q "L=$3" \
        || Z54DB="$Z54DB $1($2)=$_r"
}
for _z54sh in sh "busybox ash"; do
    z54d_case cnf    "$_z54sh" 2
    z54d_case notsup "$_z54sh" 2
    z54d_case errreg "$_z54sh" 2
    z54d_case off    "$_z54sh" 1
    # FB-183 (аудит-47, B-R80-06): негативные фикстуры — валидные
    # «Not…»-строки НЕ диагностика (прежде ловились префиксом [Nn][Oo][Tt])
    z54d_case notice  "$_z54sh" 1
    z54d_case nothing "$_z54sh" 1
    z54d_case notin   "$_z54sh" 1
done
[ "$(grep -c 'compileall' "$DEP" || true)" = 0 ] || Z54DB="$Z54DB compileall-остался"
grep -q 'FB-175 (аудит-46' "$DEP" || Z54DB="$Z54DB нет-маркера-FB-175"
grep -q 'FB-176 (аудит-46' "$DEP" || Z54DB="$Z54DB нет-маркера-FB-176"
grep -q '\[Cc\]\[Oo\]\[Mm\]\[Mm\]\[Aa\]\[Nn\]\[Dd\]' "$DEP" || Z54DB="$Z54DB нет-Command-в-regex"
grep -Fq '[Nn][Oo][Tt][[:space:]]' "$DEP" || Z54DB="$Z54DB нет-точной-формы-Not-supported(FB-183)"
grep -Fq '[Nn][Oo][Tt])[A-Za-z]' "$DEP" && Z54DB="$Z54DB старый-широкий-префикс-Not-остался(FB-183)"
if [ -z "$Z54DB" ]; then
    ok "Z54-9: FB-175: compileall-блок и сообщение удалены из deploy (S99 игнорирует .pyc; маркер отката на месте); FB-176/183: ТОЧНЫЕ формы «Command not found»/«Not supported» → UNKNOWN(2) (sh + busybox ash), негативные фикстуры Notice/Nothing/Not-in → OFF, регрессии ERROR/чистый-OFF целы (A-R79-07/A-R79-02/B-R80-06)"
else
    bad "Z54-9:$Z54DB"
fi


# ═══ Z55: панель-r83 (решение владельца, шаблон panel_preview_r83.html):
# FB-190..FB-203 — логотип/вордмарк, меню, кнопки, плитки Обзора,
# тема/редакция, DNS-уведомление, тултипы, конфигурации, значок бота,
# «Последняя проверка DNS», заголовки протоколов, Tor, «Готово», шрифты ═══
Z55B=""
python3 - "$GEN" > "$F/z55s.out" 2>&1 <<'PYZ55A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
# FB-190: символ проекта + вордмарк + KeenZOO в шапке при свёрнутом рельсе
chk('FB-190: символ i-logo (щит+Wi-Fi, градиент) ×2 шаблона',
    src.count('<symbol id="i-logo"') == 2 and src.count('fill="url(#lgz)"') == 2)
chk('FB-190: вордмарк Keen<b>ZOO</b> в рельсе и шапке (×4)',
    src.count('Keen<b>ZOO</b>') == 4)
chk('FB-190: hero — новый логотип', '<use href="#i-logo"/></svg></span>' in src)
chk('FB-190: rail-title 20px + tb-title 19px',
    src.count('.rail-title{font-size:20px;font-weight:750') == 2
    and src.count('.tb-title{font-size:19px;font-weight:750') == 2)
chk('FB-190: свёрнутое меню — значки, развёрнутое — вордмарк в рельсе',
    src.count('body.rail-ico .tb-title{display:inline}') == 2
    and src.count('body.rail-ico .rail .lbl,body.rail-ico .rail-title{display:none}') == 2
    and src.count("classList.toggle('rail-ico')") == 2)
# FB-191: меню
chk('FB-191: «Скрыть меню» (×2), «Закрепить меню» нет',
    src.count('<span class="lbl">Скрыть меню</span>') == 2
    and 'Закрепить меню' not in src)
chk('FB-191: аббревиатуры HS/VL/TR/SS/TO (×2)',
    all(src.count('data-abbr="%s"' % a) == 2 for a in ('HS','VL','TR','SS','TO')))
chk('FB-191: свёрнутые подпункты — 14px/700',
    src.count("content:attr(data-abbr);font-size:14px;font-weight:700") == 2)
chk('FB-191/14/16: вкладки «DNS» и «Поиск»',
    src.count('<span class="lbl">DNS</span>') == 2
    and src.count('<span class="lbl">Поиск</span>') == 2
    and 'lbl">DNS-безопасность' not in src
    and "'dns':'DNS-безопасность'" not in src
    and 'Вкладка DNS-безопасность' not in src
    and 'Поиск IP и доменов' not in src)
# FB-192: залитые кнопки
chk('FB-192: hero/плитка Обзора без ghost',
    'qbtn ghost' not in src)
chk('FB-192: btn-cfg/btn-save залиты как btn-key',
    src.count('.btn-cfg,.btn-save{background:var(--primary)') == 1
    and '.btn-save,.btn-cfg{background:#007fb4' in src)
# FB-193: плитки Обзора
chk('FB-193: pgrid 2×4 (r89: +NFQWS2), кликабельные названия, «открыть →» убраны из плитки',
    src.count('<div id="listRows" class="pgrid">') == 1
    and src.count('class="pg-name" href="/?tab=') == 7)
chk('FB-193: «DNS и туннели» — ссылка; честный каденс',
    '<h2 id="h-dns"><a class="tlink" href="/?tab=dns">DNS и туннели</a></h2>' in src
    and 'автопроверка — раз в 2 ч (cron)' in src
    and 'проверка раз в минуту' not in src and 'настроить →' not in src)
chk('FB-193: «Соединение» раньше «Состояния»',
    src.index('aria-labelledby="h-map"') < src.index('aria-labelledby="h-feed"'))
# FB-194: тема + редакция
chk('FB-194: значок темы меняется в оболочке',
    "u.setAttribute('href',t==='dark'?'#i-sun':'#i-moon')" in src)
chk('FB-194: редакция на панели не отображается',
    src.count('<span>ред. 82</span>') == 0 and 'ред. 81' not in src)
# FB-195: DNS
chk('FB-195: компактная плашка + «Проверить DNS» + DNS-SEC ОК',
    "em.className='kz-note';em.id='kzEmpty'" in src
    and 'Проверить DNS' in src and "'LOCAL_DNSSEC':'DNS-SEC ОК'" in src
    and "':KZ-placeholder:'" not in src)
chk('FB-199: «Последняя проверка DNS» вместо «цикл DNS»',
    "'Последняя проверка DNS: '" in src and 'цикл DNS' not in src)
# FB-196/197/198: тултипы, свёрнутые конфигурации, значок бота
chk('FB-196: описания в подсказках (tip-b ×11 = 8 + r89-za 3; FB-207 +заголовок «Обновления»)',
    src.count('class="tip-b" role="tooltip"') == 9
    and src.count('class="tip-b za-tip" role="tooltip"') == 2)
chk('FB-196: info-box остался только на вкладке Поиск (инструкция ввода)',
    src.count('<div class="info-box">') == 1
    and 'Поиск IP и CIDR' in src)
chk('FB-197: конфигурации свёрнуты при открытии',
    '{% if loop.first %}open{% endif %}' not in src)
chk('FB-198: значок бота MD3 (наушники-антенна)',
    src.count('<circle cx="12" cy="4.5" r="1.15" fill="currentColor" stroke="none"/>') >= 2)
# FB-200: заголовки протоколов
chk('FB-200: заголовок 22px, цвет по состоянию, подсказка ON/OFF',
    src.count('.page-head h1{font-size:22px;font-weight:700') == 1
    and "{{ 'ON' if svc_enabled[tid]" in src
    and "svc_enabled[active] else 'var(--faint)'" in src)
chk('FB-200: имя только в заголовке, ON/OFF крупно, переключатель 56×30',
    'class="svc-name' not in src and '.st-lg{font-size:17px;font-weight:700' in src
    and src.count('width:56px;height:30px;flex:0 0 56px') == 1
    and 'translateX(26px)' in src)
# FB-201/202/203
chk('FB-202: «Готово» только после действий; авто-скрытие 5 с',
    '_ld=Math.floor(Date.now()/1000)' in src
    and 't.remove()},5000)' in src and "'none'},5000)}" in src)
chk('FB-203: списки протоколов 15px',
    '.list-area{min-height:250px;font-size:15px' in src)
chk('FB-203: табличные цифры + сглаживание (×3)',
    src.count('font-variant-numeric:tabular-nums;-webkit-font-smoothing:antialiased') == 3)
print('OK z55-static' if not fails else 'BAD z55-static: ' + '; '.join(fails))
PYZ55A
grep -q '^OK z55-static' "$F/z55s.out" || Z55B="$Z55B $(cat "$F/z55s.out")"

# Z55-2 (поведение): рендеры вкладок с новыми элементами.
python3 - "$K" "$F" > "$F/z55py.out" 2>&1 <<'PYZ55B'
import base64, os, re, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z55bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode(),
     'Origin': 'http://localhost'}
# оболочка: меню, аббревиатуры, «Скрыть меню», без редакции
h = c.get('/?tab=ss', headers=H).data.decode()
chk('оболочка: «Скрыть меню» + HS-аббревиатура + без «ред.»',
    'Скрыть меню' in h and 'data-abbr="HS"' in h and 'ред. 82' not in h)
chk('оболочка: вордмарк в рельсе и шапке (правила rail-ico)',
    'Keen<b>ZOO</b>' in h and 'body.rail-ico .tb-title{display:inline}' in h)
# дашборд: плитки
hd = c.get('/', headers=H).data.decode()
chk('дашборд: pgrid ×7 (+NFQWS2) + заголовок-ссылка DNS + честный каденс',
    hd.count('class="pg-name"') == 7
    and '<a class="tlink" href="/?tab=dns">DNS и туннели</a>' in hd
    and 'автопроверка — раз в 2 ч (cron)' in hd)
chk('дашборд: «Соединение» до «Состояния», кнопки без ghost',
    hd.index('aria-labelledby="h-map"') < hd.index('aria-labelledby="h-feed"')
    and 'qbtn ghost' not in hd)
# панель: протоколы (стенд — службы выключены: OFF/серый)
p = c.get('/panel?tab=ss', headers=H).data.decode()
chk('панель: заголовок серый у выключенной службы + OFF + крупный тумблер',
    "id=\"page-title\" style=\"color:var(--faint)\"" in p
    and 'OFF<span class="tip-b"' in p
    and 'width:56px;height:30px;flex:0 0 56px' in p)
chk('панель: имени протокола в svc-плитке нет',
    'class="svc-name' not in p and 'включён' not in p.split('toggle_service')[0])
chk('панель: кнопки залиты (btn-cfg/btn-save = btn-key)',
    '.btn-cfg,.btn-save{background:var(--primary)' in p
    and '.btn-save,.btn-cfg{background:#007fb4' in p)
chk('панель: список 15px + подсказка на заголовке',
    '.list-area{min-height:250px;font-size:15px' in p
    and p.count('class="tip-b" role="tooltip"') >= 7)
# включённая служба → синий заголовок + ON
g2.get_services_enabled = lambda: {'ss': True, 'tr': True, 'vl': True,
                                   'to': True, 'hy': True}
p_on = c.get('/panel?tab=hy', headers=H).data.decode()
chk('панель (вкл): заголовок синий + ON',
    "id=\"page-title\" style=\"color:var(--primary)\"" in p_on
    and 'ON<span class="tip-b"' in p_on)
g2.get_services_enabled = lambda: {'ss': False, 'tr': False, 'vl': False,
                                   'to': False, 'hy': False}
# Tor: мосты на всю ширину (tile-span, как список)
pto = c.get('/panel?tab=to', headers=H).data.decode()
chk('Tor: мосты tile-span (шириной как список)',
    pto.count('<div class="tile tile-span">') >= 3)
# DNS
pdns = c.get('/panel?tab=dns', headers=H).data.decode()
chk('DNS: заголовок «DNS», кнопка «Проверить DNS», DNS-SEC ОК, плашка',
    '<h1 class="page-title"\n    id="page-title">DNS</h1>' in pdns
    and 'Проверить DNS' in pdns and "'LOCAL_DNSSEC':'DNS-SEC ОК'" in pdns
    and "em.className='kz-note';em.id='kzEmpty'" in pdns)
chk('DNS: описание — в подсказке (info-box только в скрытой секции Поиска)',
    '<span class="tip-b" role="tooltip">Автопроверка — не чаще 1 раза в 2 часа (cron).' in pdns
    and pdns.count('<div class="info-box">') == 1)
# Обновления / Конфигурации / Поиск / Бот
pupd = c.get('/panel?tab=upd', headers=H).data.decode()
chk('Обновления: описание в подсказке (info-box только в скрытой секции Поиска)',
    '<span class="tip-b" role="tooltip">Автопроверка — еженедельно (вс 03:00) с уведомлением в панель и в Telegram.</span>' in pupd
    and pupd.count('<div class="info-box">') == 1)
pcfg = c.get('/panel?tab=cfg', headers=H).data.decode()
chk('Конфигурации: все details свёрнуты (нет open)',
    ' open>' not in pcfg.replace(' aria-open',''))
chk('Конфигурации: описание в подсказке',
    'Перезапуск' not in pcfg[:200] and 'всплывать' not in pcfg
    and 'пересобирает его под tcp+udp TPROXY' in pcfg)
plk = c.get('/panel?tab=lk', headers=H).data.decode()
chk('Поиск: заголовок «Поиск»',
    'id="page-title">Поиск</h1>' in plk)
pbt = c.get('/panel?tab=bt', headers=H).data.decode()
chk('Бот: значок MD3 + 2 подсказки (выходной трафик, fail-closed)',
    '<use href="#i-bot"/></svg> Бот' in pbt
    and 'Выходной трафик &rarr; протокол' in pbt
    and 'действует fail-closed, без прямого выхода' in pbt)
# JS-контракты «Готово»/таймеры
chk('JS: «Готово» только после действий (ld=now), таймеры 5 с',
    '_ld=Math.floor(Date.now()/1000)' in p
    and 't.remove()},5000)' in p and "'none'},5000)}" in p)
chk('JS: «Последняя проверка DNS»',
    "'Последняя проверка DNS: '" in pdns)
if not fails:
    print('OK z55-render')
else:
    print('BAD z55-render: ' + '; '.join(fails))
PYZ55B
grep -q '^OK z55-render' "$F/z55py.out" || Z55B="$Z55B $(cat "$F/z55py.out")"

if [ -z "$Z55B" ]; then
    ok "Z55-1..2: панель-r83 (решение владельца, шаблон panel_preview_r83.html): FB-190 логотип щит+Wi-Fi/вордмарк 20/19px/KeenZOO в шапке при свёрнутом меню; FB-191 «Скрыть меню» + аббревиатуры HS/VL/TR/SS/TO 14px/700 + вкладки «DNS»/«Поиск»; FB-192 все активные кнопки залиты (ghost убран, btn-cfg/btn-save = btn-key); FB-193 плитки Обзора: кликабельные названия 2×3, заголовок-ссылка «DNS и туннели», честный каденс «раз в 2 ч (cron)», Соединение↔Состояние; FB-194 значок темы в оболочке + редакция не отображается; FB-195 компактная плашка DNS + «Проверить DNS» + «DNS-SEC ОК» (только вкладка DNS); FB-196 описания в подсказках (info-box — только инструкция Поиска); FB-197 конфигурации свёрнуты; FB-198 значок бота MD3; FB-199 «Последняя проверка DNS»; FB-200 заголовки протоколов 22px синий/серый + ON/OFF 17px + тумблер 56×30 + имя без дубля; FB-201 Tor мосты tile-span; FB-202 «Готово» только после действий, авто-скрытие 5 с; FB-203 системный шрифтовой стек + списки 15px"
else
    bad "Z55:$Z55B"
fi

# ═══ Z56: правки отображения r84–r86 (решение владельца, скрины 29.10.2026,
# шаблоны panel_preview_r84/r85/r86.html, утверждены): FB-204..FB-211 ═══
Z56B=""
python3 - "$GEN" > "$F/z56s.out" 2>&1 <<'PYZ56A'
import sys
src = open(sys.argv[1], encoding='utf-8').read()
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)

# FB-204: плитка «Обход блокировок» — одна колонка на узких экранах
chk('FB-204: pgrid 1 колонка ≤760px; имя эллипсируется; счётчик несжимаем',
    '@media(max-width:760px){.pgrid{grid-template-columns:1fr}}' in src
    and '.pgw .cnt{margin-left:auto;font-size:var(--fs-caption);color:var(--muted);white-space:nowrap;flex:none}' in src
    and 'min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' in src)
# FB-205: DNS-пилюли только на вкладке DNS
chk('FB-205: пилюли hd-* только на dns; тема вправо на остальных',
    "{% if active == 'dns' %}\n  <span class=\"hd-pill ghost\" id=\"hd-mode\">DNS —</span>" in src
    and "{% if active != 'dns' %} style=\"margin-left:auto\"{% endif %}" in src)
# FB-206: разделитель — линии по бокам подписи
chk('FB-206: divider ::before/::after вместо полосы height:1px',
    '.divider::before,.divider::after{' in src
    and 'content:"";height:1px;background:var(--line);flex:1;min-width:12px' in src
    and 'height:1px;background:var(--line);margin:15px 0;display:flex' not in src)
# FB-207: пояснение версий — в подсказке заголовка вкладки
chk('FB-207: «📦 Версии (архитектура) — установка производится вручную» — в подсказке h1',
    "{% elif active == 'upd' %}<span class=\"tip t-underline\" tabindex=\"0\">{{ PT[active] }}<span class=\"tip-b\" role=\"tooltip\">&#128230; Версии (архитектура) — установка производится вручную</span></span>" in src
    and 'зелёный = актуально' not in src)
# FB-208: одна надпись вместо двух
chk('FB-208: «Проверка новых версий протоколов» + сокращённая подсказка',
    '<span>Проверка новых версий протоколов</span>' in src
    and '<span class="tip-b" role="tooltip">Автопроверка — еженедельно (вс 03:00) с уведомлением в панель и в Telegram.</span>' in src
    and 'Обновления протоколов' not in src)
# FB-209: значок темы в одной строке с заголовком (мобильная шапка — грид)
chk('FB-209: мобильная шапка — грид; тема в строке заголовка',
    '.page-head{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center}' in src
    and '.page-head .icon-btn{grid-column:2;grid-row:1;justify-self:end}' in src)
# FB-210: подсказка ключа — «Введите ключ»
chk('FB-210: подсказка ключа сокращена до «Введите ключ»',
    "'<span class=\"kz-err\">Введите ключ</span>'" in src
    and '0 симв.' not in src and 'кнопка неактивна' not in src
    and 'Формат {{ tname }}' not in src)
# FB-211: подсказка заголовка поверх контента
chk('FB-211: шапка без backdrop-фильтра (фон var(--gl)); mobile relative z1',
    'background:color-mix(in srgb,var(--gl) 90%,transparent);backdrop-filter:blur(10px)' not in src
    and '.page-head{position:relative;z-index:1;margin:-12px -12px 12px;padding:9px 12px}' in src)
print('OK z56-static' if not fails else 'BAD z56-static: ' + '; '.join(fails))
PYZ56A
grep -q '^OK z56-static' "$F/z56s.out" || Z56B="$Z56B $(cat "$F/z56s.out")"

# Z56-2 (поведение): рендеры вкладок после правок
python3 - "$K" "$F" > "$F/z56py.out" 2>&1 <<'PYZ56B'
import base64, os, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
B = os.path.join(F, 'z56bot')
os.system('rm -rf %s && cp -r %s/opt/etc/bot %s' % (B, K, B))
cf = os.path.join(B, 'bot_config.py')
lines = open(cf, encoding='utf-8').read().split('\n')
for i, ln in enumerate(lines):
    k = ln.split('=')[0].strip() if '=' in ln else ''
    if k == 'web_username':
        lines[i] = "web_username = 'admin'"
    elif k == 'web_password':
        lines[i] = "web_password = 'testpass'"
open(cf, 'w', encoding='utf-8').write('\n'.join(lines))
sys.path.insert(0, B)
import generator as g2
c = g2.app.test_client()
H = {'Authorization': 'Basic ' + base64.b64encode(b'admin:testpass').decode(),
     'Origin': 'http://localhost'}
p_upd = c.get('/panel?tab=upd', headers=H).data.decode()
p_ss = c.get('/panel?tab=ss', headers=H).data.decode()
p_dns = c.get('/panel?tab=dns', headers=H).data.decode()
# FB-205: пилюли только на DNS
chk('FB-205: на upd/ss пилюль нет, на dns есть; тема вправо на upd/ss',
    'id="hd-mode"' not in p_upd and 'id="hd-mode"' not in p_ss
    and 'id="hd-mode"' in p_dns and 'id="hd-time"' in p_dns
    and 'style="margin-left:auto"' in p_upd
    and 'style="margin-left:auto"' not in p_dns)
# FB-207/208: секция Обновлений целиком
tab = p_upd[p_upd.find('id="tab-upd"'):p_upd.find('id="tab-dns"')]
chk('FB-207/208: 1 карточка, 1 разделитель, тексты дословно',
    tab.count('<div class="tile ') == 1
    and tab.count('<div class="divider">') == 1
    and 'Проверка новых версий протоколов' in tab
    and 'Обновления протоколов' not in tab
    and 'Проверка новых версий</span>' not in tab
    and '&#128230; Версии (архитектура) — установка производится вручную' in p_upd
    and 'Автопроверка — еженедельно (вс 03:00) с уведомлением в панель и в Telegram.' in tab
    and 'зелёный = актуально' not in tab)
# FB-210: JS-подсказка ключа
chk('FB-210: JS-подсказка «Введите ключ» в рендере протокола',
    "'<span class=\"kz-err\">Введите ключ</span>'" in p_ss)
# FB-211: шапка без backdrop-фильтра в рендере
chk('FB-211: рендер без стеклянной шапки',
    'backdrop-filter:blur(10px)' not in p_ss.split('<div class="side"')[0].split('id="tab-')[0]
    or 'backdrop-filter:blur(10px);border-bottom:1px solid var(--outline)}' not in p_ss)
if not fails:
    print('OK z56-render')
else:
    print('BAD z56-render: ' + '; '.join(fails))
PYZ56B
grep -q '^OK z56-render' "$F/z56py.out" || Z56B="$Z56B $(cat "$F/z56py.out")"

if [ -z "$Z56B" ]; then
    ok "Z56-1..2: правки отображения r84–r86 (решение владельца, скрины 29.10.2026, шаблоны panel_preview_r84/r85/r86.html): FB-204 плитка «Обход блокировок» — одна колонка на ≤760px, имя эллипсируется, счётчик несжимаем (замер: было 213px контента в колонке 164px); FB-205 DNS-пилюли (LOCAL_DNSSEC/ещё не проверялось/Последняя проверка) только на вкладке DNS, кнопка темы придержана вправо на остальных; FB-206 разделитель — линии по бокам подписи (::before/::after), контейнер растёт по высоте текста (зазор +27px вместо наезда −4px); FB-207 «📦 Версии (архитектура) — установка производится вручную» — всплывающая подсказка у названия вкладки, карточки проверки и версий объединены; FB-208 одна надпись «Проверка новых версий протоколов» с подсказкой «Автопроверка — еженедельно (вс 03:00) с уведомлением в панель и в Telegram»; FB-209 значок темы в одной строке с заголовком (мобильная шапка — грид: заголовок+тема → пилюли → время); FB-210 подсказка ключа — «Введите ключ» (без «кнопка неактивна»/«0 симв.»/«Формат …»); FB-211 шапка без backdrop-фильтра + relative z1 на мобильных — подсказка заголовка рисуется поверх контента (Chromium/Brave Android)"
else
    bad "Z56:$Z56B"
fi


# ═══ Z57 (r89-nfqws2-selective, решение владельца 02.11.2026) ═══
# П1 конфликт-логика по режиму; П2 защита переключения режима;
# П3 авто-exclude endpoint'ов; П4 автоочистка пересечений user.list;
# П6 статус «совместимо» в селективе; П8 подсказка api.telegram.org;
# UI-якоря вкладки za (мокап r88, раунды 1–5).
Z57="$F/z57"; mkdir -p "$Z57"
UT="$K/opt/etc/bot/utils.py"
HN="$K/opt/etc/bot/handlers.py"
LC="$K/opt/etc/bot/lists_core.py"
SH="$K/opt/bin/nfqws2_update_excludes.sh"
python3 - "$K" "$F" > "$F/z57py.out" 2>&1 <<'PYZ57'
import os, sys
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
gs = open(K + '/opt/etc/bot/generator.py', encoding='utf-8').read()
us = open(K + '/opt/etc/bot/utils.py', encoding='utf-8').read()
hn = open(K + '/opt/etc/bot/handlers.py', encoding='utf-8').read()
lc = open(K + '/opt/etc/bot/lists_core.py', encoding='utf-8').read()
sh_path = K + '/opt/bin/nfqws2_update_excludes.sh'
sh = open(sh_path, encoding='utf-8').read() if os.path.isfile(sh_path) else ''
bc = open(K + '/opt/etc/bot/bot_config.py', encoding='utf-8').read()

# П1: блокирующая проверка только в Глобал/Авто (панель + бот)
chk('П1 панель: conflicts_required в _nfqws2_status',
    "'conflicts_required': mode in ('all', 'auto')" in gs)
chk('П1 панель: селектив не блокирует включение',
    "conflicts = _nfqws2_conflicts() \\\n        if _nfqws2_status()['conflicts_required'] else []" in gs)
chk('П1 панель: текст про селектив в блоке',
    'переключите nfqws2 в ' in gs and 'селективный режим' in gs)
chk('П1 бот: импорт nfqws2_conflicts_required',
    'nfqws2_conflicts_required' in hn.split('from utils import')[1][:900])
chk('П1 бот: блок только при required',
    'if conflicts and required:' in hn)
chk('П1 бот: старая «петля перехвата» убрана',
    'петле перехвата' not in hn)

# П2: /mode/za с force (панель + бот)
chk('П2 панель: маршрут /mode/za',
    "@app.route('/mode/za', methods=['POST'])" in gs
    and 'def mode_za():' in gs)
chk('П2 панель: force из формы',
    "request.form.get('force') == '1'" in gs)
chk('П2 бот: force-суффикс callback',
    'endswith("_force")' in hn)
chk('П2 бот: кнопка «Выключить туннели и переключить»',
    'Выключить туннели и переключить' in hn)
chk('П2 utils: nfqws2_set_mode(mode, force=...)',
    'def nfqws2_set_mode(mode, force=False):' in us
    and 'Глобал/Авто затронет соединения' in us)

# П3: авто-excludes
chk('П3 скрипт существует и исполняем',
    bool(sh) and os.access(sh_path, os.X_OK))
chk('П3 скрипт: managed-блоки',
    'BEGIN KeenZOO managed excludes' in sh
    and 'END KeenZOO managed excludes' in sh)
chk('П3 utils: тихий вызов + вызовы на включении',
    'def nfqws2_update_excludes_quiet():' in us
    and us.count('nfqws2_update_excludes_quiet()') >= 3)
chk('П3 панель: excludes перед стартом в toggle',
    'r89 (П3): перед стартом' in gs)
chk('П3 панель: excludes при рестарте протокола',
    'r89 (П3): рестарт протокола мог сменить VPS' in gs)

# П4: автоочистка пересечений user.list
chk('П4 панель: _nfw2_cross_clean (za-направление)',
    'def _nfw2_cross_clean(content):' in gs
    and 'уже в списках' in gs)
chk('П4 панель: обратная чистка _nfw2_clean_userlist_from',
    'def _nfw2_clean_userlist_from(saved_path):' in gs
    and 'теперь в списке туннеля' in gs)
chk('П4 панель: чистка до apply, только туннельные вкладки',
    "lk not in ('nfqws2', 'bot')" in gs)
chk('П4 панель: za не запускает пересборку ipset',
    "if lk != 'nfqws2':" in gs)
chk('П4 lists_core: user.list разрешён путём из config.list_files',
    'def _list_path_allowed(filepath):' in lc
    and 'config.list_files.values()' in lc)
chk('П4 lists_core: user.list вне глобального дедупа',
    "_nfw2 = BYPASS_FILES.get('nfqws2')" in lc
    and 'if fp != _nfw2' in lc)
chk('П4 панель: имя файла пакета в сообщении',
    "_shown = ('user.list'\n                  if lk == 'nfqws2'" in gs)

# П6: статус «совместимо» в селективе
chk('П6 utils: строка совместимости в статусе',
    '— совместимо, селектив' in us)
chk('П6 utils: Intelli QoS Выключен/Включен',
    "if nfqws2_intelliqos_suspected() else 'Выключен'" in us)

# П8: подсказка переноса api.telegram.org
chk('П8 вкладка: подсказка в za-ok',
    'api.telegram.org из' in gs)
chk('П8 вкладка: подсказка в hint списка',
    'перенесите api.telegram.org из bot.txt' in gs)

# UI-якоря вкладки za (мокап r88, раунды 1–5)
i = gs.index('PAGE_TEMPLATE')
page = gs[i:]
chk('UI: блоки za-ok/za-warn/za-iq/za-rows/za-mode-row',
    all(x in page for x in (
        'class="za-ok"', 'class="za-warn"', 'class="za-iq"',
        'class="za-rows"', 'class="za-mode-row"')))
chk('UI: кнопка force в za-warn',
    'Выключить протоколы и включить NFQWS2' in page)
chk('UI: brightness_auto (MD3) в кнопке «Авто»',
    'M408-412h146l25 73' in page and 'za-auto' in page)
chk('UI: tip-b унифицирован 13px (специфичность 0,2,0)',
    '.tip .tip-b{font-size:var(--fs-caption);font-weight:400;'
    'text-transform:none;letter-spacing:normal}' in gs)
chk('UI: Intelli QoS жёлтый/Выключен в za-rows',
    "style=\"color:var(--warn)\"{% endif %}>{{ 'Включен' if za.intelliqos_suspected else 'Выключен' }" in page)
chk('UI: za в индексе корня',
    "'to', 'hy', 'za', 'bt', 'lk'," in gs)
chk('UI: za в JS-карте счётчиков',
    "'hy':'hy','za':'za','bt':'bt'}" in gs)
chk('UI: za-ok независим от za-iq (r89-фикс)',
    'and not (za.conflicts and za.conflicts_required)' in page)
chk('UI: рельс NFQWS2 в обоих шаблонах + плитка дашборда',
    gs.count('href="/?tab=za"') == 3
    and gs.count('data-abbr="NZ"') == 2)
chk('UI: плитка дашборда NFQWS2',
    'href="/?tab=za">NFQWS2</a>' in gs)
chk('UI: /panel?tab=za в iframe-оболочке',
    'iframe' in gs)
chk('П2 панель: рендер вкладки через za=_nfqws2_status()',
    'za=za,' in gs)

# консистентность: конфиг знает оба списка
chk('bot_config: nfqws2 и bot в list_files',
    "'nfqws2':" in bc and "'bot':" in bc)

if not fails:
    print('OK z57-r89')
else:
    print('BAD z57-r89: ' + '; '.join(fails))
PYZ57
grep -q '^OK z57-r89' "$F/z57py.out" \
    && ok "Z57: r89-nfqws2-selective (решение владельца 02.11.2026): П1 — блокирующая проверка конфликтов только в Глобал/Авто, в Селективе туннели (mangle PREROUTING, ipset) и nfqws2 (POSTROUTING, user.list) не пересекаются (панель _toggle_nfqws2/_nfqws2_status + бот handle_nfqws2_toggle); П2 — /mode/za с force= (автовыключение туннелей, utils.nfqws2_set_mode), бот: inline «Выключить туннели и переключить»; П3 — /opt/bin/nfqws2_update_excludes.sh (hosts-пины + server/address конфигов → managed-блоки exclude.list/ipset_exclude.list), тихий вызов при включении/смене режима/рестарте протоколов; П4 — автоочистка пересечений user.list↔unblock-списков в обе стороны + user.list вне глобального дедупа (перенос домена из user.list в туннель); П6 — статус «Туннели: активны (…) — совместимо, селектив» + Intelli QoS; П8 — подсказки «api.telegram.org из bot.txt в user.list»; UI вкладки za: za-ok/za-warn/za-iq, режимные кнопки с brightness_auto, tip-b 13px (0,2,0), рельс/дашборд/iframe-оболочка" \
    || bad "Z57: $(cat "$F/z57py.out")"


# ═══ Z58 (r90-protocols-menu, решение владельца 02.11.2026, пп.1-6) ═══
python3 - "$K" "$F" > "$F/z58py.out" 2>&1 <<'PYZ58'
import os, sys, json, shutil
K, F = sys.argv[1], sys.argv[2]
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)
gs = open(K + '/opt/etc/bot/generator.py', encoding='utf-8').read()
us = open(K + '/opt/etc/bot/utils.py', encoding='utf-8').read()
hn = open(K + '/opt/etc/bot/handlers.py', encoding='utf-8').read()
mn = open(K + '/opt/etc/bot/menu.py', encoding='utf-8').read()

# п.1: конфликт-кнопки панели — grid в один ряд (десктоп)
chk('п.1 za-actions grid 1fr 1fr',
    '.za-actions{display:grid;grid-template-columns:1fr 1fr;'
    'gap:8px;margin-top:11px}' in gs)
chk('п.1 мобильный — вертикально (≤700px)',
    '@media(max-width:700px){\n .za-actions{grid-template-columns:1fr;'
    'justify-items:center}' in gs)

# п.1(реш.) «🆕 Обновления» — только протоколы, в главном меню
chk('главное меню: Обновления + Сервис одной строкой',
    '["🆕 Обновления", "⚙️ Сервис"],' in mn
    and '["♻️ Восстановление и удаление"]' in mn
    and '["🔑 Ключи и мосты", "📑 Списки обхода"],' in mn)
chk('Сервис: «🆕 Обновления» заменён на «🔌 Протоколы»',
    '["⁉️ DNS Override", "🔌 Протоколы", "💾 Бэкап"],' in mn)
chk('обновления: бот-секция удалена',
    '🤖 <b>Бот' not in hn
    and 'need_bot_update' not in hn
    and 'get_remote_version' not in hn)
chk('обновления: trigger_update удалён (мёртвый UI)',
    'trigger_update' not in hn)
chk('обновления: fallback «Статус версий пока недоступен»',
    'Статус версий пока недоступен' in hn)

# п.2/6: «🔌 Протоколы» — inline (вариант А)
chk('menu.py: create_protocols_toggle_menu',
    'def create_protocols_toggle_menu(states):' in mn
    and 'create_button("🔙 Назад", "menu_service")' in mn)
chk('порядок — как в «Ключи и мосты» (+ NFQWS2)',
    "order = ('tor', 'vless', 'trojan',\n"
    "             'shadowsocks', 'hysteria', 'nfqws2')" in mn)
chk('handlers: кнопка в MENU_TRANSITIONS',
    "'🔌 Протоколы':\n            show_protocols_menu," in hn)
chk('callbacks: proto_menu/proto_sel_/proto_on_/proto_off_',
    'c.data == "proto_menu"' in hn
    and 'c.data.startswith("proto_sel_")' in hn
    and 'c.data.startswith("proto_on_")' in hn
    and 'c.data.startswith("proto_off_")' in hn)
chk('utils: PROTOCOL_ORDER/TITLES/_PROTOCOL_INFO',
    'PROTOCOL_ORDER = ' in us and 'PROTOCOL_TITLES = ' in us
    and '_PROTOCOL_INFO = ' in us)
chk('utils: protocol_enabled/active_tunnels/'
    'protocol_configured/protocol_set_enabled/nfqws2_blocks_tunnels',
    'def protocol_enabled(name):' in us
    and 'def active_tunnels():' in us
    and 'def protocol_configured(name):' in us
    and 'def protocol_set_enabled(name, on):' in us
    and 'def nfqws2_blocks_tunnels():' in us)
chk('utils: protocol_set_enabled — честный pidof-статус',
    'Процесс не запущен — проверьте ' in us)

# п.3: зеркальный конфликт — блок с force (бот + панель)
chk('бот: зеркальный блок с force',
    'его правила затронут соединения ' in hn
    and 'Выключить NFQWS2 и включить' in hn
    and '_force' in hn)
chk('панель: зеркальная проверка в toggle_service',
    "_u.nfqws2_blocks_tunnels()" in gs
    and "затронут соединения этого протокола к его VPS" in gs)
chk('панель: warn-блок на вкладках выключенных туннелей',
    'Конфликт с NFQWS2 (Глобал/Авто)' in gs
    and 'Выключить NFQWS2 и включить {{ tname }}' in gs
    and 'nfw2_mirror and not svc_enabled[tid]' in gs)
chk('панель: nfw2_mirror из utils.nfqws2_blocks_tunnels',
    'nfw2_mirror = _u.nfqws2_blocks_tunnels()' in gs)

# п.4: подтверждение последнего туннеля
chk('бот: «Это последний активный туннель» + Да, выключить',
    'Это последний активный туннель' in hn
    and 'Да, выключить' in hn
    and '_confirm' in hn)
chk('бот: П8-подсказка при включённом NFQWS2',
    'перенесите ' in hn and 'api.telegram.org' in hn)
chk('бот: П8-подсказка в списке протоколов (туннелей нет)',
    'уходят в DROP' in hn)

# ── поведенческие проверки utils (фикстуры, без telebot/flask) ──
D = os.path.join(F, 'z58')
shutil.rmtree(D, ignore_errors=True)
os.makedirs(os.path.join(D, 'init.d'), exist_ok=True)
os.makedirs(os.path.join(D, 'unblock'), exist_ok=True)
INITS = {
    'shadowsocks': 'S65shadowsocks', 'trojan': 'S22trojan',
    'vless': 'S24xray', 'tor': 'S35tor', 'hysteria': 'S57hysteria'}
def mkinit(name, en):
    p = os.path.join(D, 'init.d', INITS[name])
    open(p, 'w').write('#!/bin/sh\nENABLED=%s\n' % ('yes' if en else 'no'))
for n in INITS:
    mkinit(n, False)
mkinit('shadowsocks', True)
mkinit('tor', True)
open(os.path.join(D, 'init.d', 'S90nfqws2'), 'w').write(
    '#!/bin/sh\nENABLED=yes\n')
open(os.path.join(D, 'nfqws2.conf'), 'w').write(
    'NFQWS_EXTRA_ARGS="$MODE_ALL"\n')

sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import utils as u
u.NFQWS2_S51 = os.path.join(D, 'init.d', 'S51nfqws2')
open(u.NFQWS2_S51, 'w').write('#!/bin/sh\n')
u.NFQWS2_INIT = os.path.join(D, 'init.d', 'S90nfqws2')
u.NFQWS2_CONFLICT_SERVICES = tuple(
    (n, os.path.join(D, 'init.d', INITS[n]), 'x') for n in INITS)
u._PROTOCOL_INFO = {
    n: (os.path.join(D, 'init.d', INITS[n]), 'x') for n in INITS}
u.nfqws2_update_excludes_quiet = lambda: None
_cfg = os.path.join(D, 'ss.json')
open(_cfg, 'w').write('{"server":"1.2.3.4","password":"real"}')
class _P: pass
u.config = _P()
u.config.paths = {
    'shadowsocks_config': _cfg,
    'vless_config': os.path.join(D, 'vl.json'),
    'trojan_config': os.path.join(D, 'tr.json'),
    'hysteria_config': os.path.join(D, 'hy.json'),
    'tor_config': os.path.join(D, 'torrc'),
    'nfqws2_dir': D}

chk('повед: active_tunnels = [tor, shadowsocks]',
    u.active_tunnels() == ['tor', 'shadowsocks'])
chk('повед: nfqws2_blocks_tunnels (вкл+глобал)',
    u.nfqws2_blocks_tunnels() is True)
def _mode(m):
    open(os.path.join(D, 'nfqws2.conf'), 'w').write(
        'NFQWS_EXTRA_ARGS="$MODE_%s"\n' % m.upper())
_mode('list')
chk('повед: селектив не блокирует', u.nfqws2_blocks_tunnels() is False)
open(os.path.join(D, 'init.d', 'S90nfqws2'), 'w').write(
    '#!/bin/sh\nENABLED=no\n')
chk('повед: NFQWS2 выкл не блокирует', u.nfqws2_blocks_tunnels() is False)
open(os.path.join(D, 'init.d', 'S90nfqws2'), 'w').write(
    '#!/bin/sh\nENABLED=yes\n')
_mode('all')

open(_cfg, 'w').write('{"server":"CHANGE_ME"}')
chk('повед: protocol_configured — заглушка = False',
    u.protocol_configured('shadowsocks') is False)
open(_cfg, 'w').write('{"server":"1.2.3.4","password":"real"}')
chk('повед: protocol_configured — ключ = True',
    u.protocol_configured('shadowsocks') is True)
open(os.path.join(D, 'torrc'), 'w').write('UseBridges 1\n')
chk('повед: protocol_configured — tor без мостов = False',
    u.protocol_configured('tor') is False)
open(os.path.join(D, 'torrc'), 'w').write(
    'UseBridges 1\nBridge obfs4 1.2.3.4:9999\n')
chk('повед: protocol_configured — tor с мостами = True',
    u.protocol_configured('tor') is True)
chk('повед: protocol_configured — nfqws2 (S51 есть)',
    u.protocol_configured('nfqws2') is True)

ok1, m1 = u.protocol_set_enabled('trojan', True)
chk('повед: protocol_set_enabled вкл (ENABLED=yes)',
    ok1 and 'ENABLED=yes' in open(
        os.path.join(D, 'init.d', 'S22trojan')).read())
ok2, m2 = u.protocol_set_enabled('trojan', False)
chk('повед: protocol_set_enabled выкл (ENABLED=no)',
    ok2 and 'ENABLED=no' in open(
        os.path.join(D, 'init.d', 'S22trojan')).read())
ok3, m3 = u.protocol_set_enabled('nosuch', True)
chk('повед: неизвестный протокол → (False, …)', ok3 is False)

if not fails:
    print('OK z58-r90')
else:
    print('BAD z58-r90: ' + '; '.join(fails))
PYZ58
grep -q '^OK z58-r90' "$F/z58py.out" \
    && ok "Z58: r90-protocols-menu (решение владельца 02.11.2026): п.1 конфликт-кнопки панели в один ряд grid 1fr 1fr (мобильный ≤700px — вертикально); «🆕 Обновления» — только протоколы обхода — перенесено в главное меню (бот-секция версий и «Обновить бота» удалены: версии бота всегда совпадали — UI был мёртвым; fallback «Статус версий пока недоступен»); «🔌 Протоколы» в Сервисе — inline-меню (вариант А) с порядком «Ключи и мосты» + NFQWS2: экран протокола (статус/ключ/мосты), ✅ Включить/⛔ Выключить; зеркальный конфликт П1 (включение туннеля при NFQWS2 Глобал/Авто) — блок с force «Выключить NFQWS2 и включить» в боте И панели (warn-блок на вкладках выключенных туннелей, toggle_service + force=); последний активный туннель — подтверждение «Да, выключить» с П8-подсказкой (api.telegram.org в user.list); utils: protocol_enabled/active_tunnels/protocol_configured/protocol_set_enabled (pidof-статус)/nfqws2_blocks_tunnels — поведенчески на фикстурах" \
    || bad "Z58: $(cat "$F/z58py.out")"

# ═══ Z59 (r91-hardening: аудит r90, решение владельца 02.11.2026 — пакеты А-Д + опция Е) ═══
python3 - "$K" "$F" > "$F/z59py.out" 2>&1 <<'PYZ59'
import os, sys, re, shutil, subprocess
K, F = sys.argv[1], sys.argv[2]
Z = os.path.join(F, 'z59')
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)

# ── статика по дереву ──
gs = open(K + '/opt/etc/bot/generator.py', encoding='utf-8').read()
us = open(K + '/opt/etc/bot/utils.py', encoding='utf-8').read()
hn = open(K + '/opt/etc/bot/handlers.py', encoding='utf-8').read()
ps = open(K + '/opt/bin/nfqws2_postinstall.sh', encoding='utf-8').read()
ex = open(K + '/opt/bin/nfqws2_update_excludes.sh', encoding='utf-8').read()
s90 = open(K + '/opt/etc/init.d/S90nfqws2', encoding='utf-8').read()
dep = open(K + '/opt/bin/deploy_bypass.sh', encoding='utf-8').read()
upd = open(K + '/opt/bin/update_protocols.sh', encoding='utf-8').read()

# А (честность rc init-операций)
chk('A: _run_init_cmd/_proc_alive',
    'def _run_init_cmd(init_path, action):' in us
    and 'def _proc_alive(proc):' in us)
chk('A: set_service_enabled откат ENABLED',
    'def _rollback_enabled(sn, prev):' in gs
    and 'prev = _read_enabled(sn)' in gs
    and gs.count('_rollback_enabled(sn, prev)') == 3)
chk('A: reapply логирует rc',
    "[w]netfilter hook {table}: " in gs
    and 'rc={r.returncode}' in gs)
chk('A: protocol_set_enabled stop-откат',
    'Не удалось остановить ' in us and 'состояние не изменено' in us)
chk('A: nfqws2_set_enabled откат+разрыв цепочки',
    'NFQWS2 не включён' in us
    and '_rewrite_init_enabled(wrapper, not on)' in us)
chk('A: nfqws2_set_mode откат режима',
    'прежний режим восстановлен' in us and 'def _restore_conf():' in us)
chk('A7: S90 передаёт rc S51', s90.count('exit "$?"') == 3)
# Б (postinstall: бинд до auth, fail-closed)
chk('Б: флаг применённого бинда', '_kz_bind_ok' in ps
    and '[ "$_kz_bind_ok" = 1 ]' in ps)
chk('Б: бинд ДО auth', ps.index('kz_nfw_lan_ip || true')
    < ps.index('"= false"'))
chk('Б: один адрес + откат + -t + рестарт с rc',
    'head -n 1' in ps and '_kz_restore_lighttpd' in ps
    and 'kzbak' in ps and '-t -f "$KZ_NFW_LIGHTTPD_CONF"' in ps
    and 'рестарт lighttpd не удался' in ps)
chk('Б: вызывающие не глушат отказ',
    dep.count('не настроен безопасно') == 2
    and upd.count('не настроен безопасно') == 3
    and 'nfqws2_postinstall.sh || true' not in dep)
# В (excludes по реальным схемам + защита блока)
chk('В: точные парсеры', '_nfw_add_endpoint' in ex
    and 'remote_addr' in ex and 'vnext' in ex
    and '"server"[[:space:]]*:[[:space:]]*\\[' in ex)
chk('В: защита маркеров + cmp-скип',
    'повреждён managed-блок' in ex
    and 'cmp -s "$_nfb_tmp" "$_nfb_file"' in ex)
chk('В: quiet() проверяет rc',
    'nfqws2_update_excludes: rc=' in us)
# Г (панель = бот)
chk('Г: guard ключа в toggle',
    'protocol_configured(sn)' in gs
    and 'def _toggle_service_locked(tab):' in gs)
chk('Г: единый детектор', 'for n in _u.nfqws2_conflicts()]' in gs)
chk('Г: force подтверждает исчезновение',
    '_alive = _nfqws2_conflicts()' in gs
    and 'Не удалось остановить: ' in gs)
# Д (свежесть статуса обновлений)
chk('Д: ts-допуск + пометка',
    '_t0 = time.time() - 2.0' in hn
    and 'Проверка не завершена' in hn
    and 'not has_proto_updates and not _stale' in hn)
# Е (межпроцессный lockdir)
chk('Е: lockdir в utils',
    '_TOGGLE_LOCKDIR' in us
    and 'def acquire_toggle_lock' in us
    and 'def release_toggle_lock' in us)
chk('Е: lock в панели и боте',
    'acquire_toggle_lock' in gs and 'acquire_toggle_lock' in hn
    and 'acquire_toggle_lock, release_toggle_lock,' in hn
    and hn.count('release_toggle_lock()') >= 6)
chk('А6: force-результат проверяется',
    'ok2, msg2 = nfqws2_set_enabled(False)' in hn)

# ── поведение на фикстурах ──
shutil.rmtree(Z, ignore_errors=True)
for d in ('init.d', 'rc', 'alive', 'nfw2/lists', 'etc/xray',
          'etc/trojan', 'etc/hysteria', 'bin'):
    os.makedirs(os.path.join(Z, d), exist_ok=True)
FIX = Z + '/init.d/'
INIT_TPL = ('#!/bin/sh\nENABLED=yes\n_name="%s"\n'
            'case "$1" in\n  start|stop|restart)\n'
            '    _rcf="%s/rc/${_name}.$1"\n'
            '    [ -f "$_rcf" ] && exit $(cat "$_rcf")\n'
            '    exit 0;;\n  *) exit 0;;\nesac\n')
for s in ('S65shadowsocks', 'S22trojan', 'S24xray', 'S35tor',
          'S57hysteria', 'S51nfqws2'):
    open(FIX + s, 'w').write(INIT_TPL % (s, Z))
open(FIX + 'S90nfqws2', 'w').write(
    open(K + '/opt/etc/init.d/S90nfqws2').read().replace(
        '/opt/etc/init.d/S51nfqws2', FIX + 'S51nfqws2')
    # r92: поставка S90 теперь ENABLED=no; фикстура моделирует
    # включённый пользователем nfqws2 (как было в r87-r91)
    .replace('\nENABLED=no\n', '\nENABLED=yes\n', 1))
open(Z + '/bin/pidof', 'w').write(
    '#!/bin/sh\n[ -f "%s/alive/$1" ] && exit 0\nexit 1\n' % Z)
os.chmod(Z + '/bin/pidof', 0o755)
os.environ['PATH'] = Z + '/bin:' + os.environ['PATH']
open(Z + '/nfw2/nfqws2.conf', 'w').write(
    'NFQWS_EXTRA_ARGS="$MODE_LIST"\n')
open(Z + '/etc/xray/config.json', 'w').write(
    '{"outbounds":[{"settings":{"vnext":[{"address":"8.8.8.8"}]}}]}')
open(Z + '/etc/trojan/config.json', 'w').write(
    '{"remote_addr":"9.9.9.9","local_addr":"0.0.0.0"}')
open(Z + '/etc/shadowsocks.json', 'w').write(
    '{"server":["1.1.1.1"],"server_port":8388}')
open(Z + '/etc/hysteria/config.json', 'w').write(
    '{"server":"hy.example.com:443"}')
for f in ('exclude.list', 'ipset_exclude.list'):
    open(Z + '/nfw2/lists/' + f, 'w').write(
        '# BEGIN KeenZOO managed excludes\n'
        '# END KeenZOO managed excludes\nuser-entry.example\n')
open(Z + '/etc/hosts', 'w').write('# hosts\n')

sys.path.insert(0, K + '/opt/etc/bot')
import utils as u
import bot_config as config
config.paths['nfqws2_dir'] = Z + '/nfw2'
u.NFQWS2_S51 = FIX + 'S51nfqws2'
u.NFQWS2_INIT = FIX + 'S90nfqws2'
u.NFQWS2_CONFLICT_SERVICES = (
    ('shadowsocks', FIX + 'S65shadowsocks', 'ss-redir'),
    ('trojan', FIX + 'S22trojan', 'trojan'),
    ('vless', FIX + 'S24xray', 'xray'),
    ('tor', FIX + 'S35tor', 'tor'),
    ('hysteria', FIX + 'S57hysteria', 'hysteria'))
u._PROTOCOL_INFO = {
    'shadowsocks': (FIX + 'S65shadowsocks', 'ss-redir'),
    'trojan': (FIX + 'S22trojan', 'trojan'),
    'vless': (FIX + 'S24xray', 'xray'),
    'tor': (FIX + 'S35tor', 'tor'),
    'hysteria': (FIX + 'S57hysteria', 'hysteria')}

def rc(svc, act, v):
    q = '%s/rc/%s.%s' % (Z, svc, act)
    if v is None:
        if os.path.exists(q):
            os.unlink(q)
    else:
        open(q, 'w').write(str(v))

def en(init):
    for ln in open(init):
        m = re.match(r'^\s*ENABLED\s*=\s*(\S+)', ln)
        if m:
            return m.group(1).strip('"\'') == 'yes'
    return False

TR, S90 = FIX + 'S22trojan', FIX + 'S90nfqws2'
rc('S22trojan', 'stop', 7)
ok, msg = u.protocol_set_enabled('trojan', False)
chk('beh: stop rc=7 → False + откат',
    (not ok) and 'Не удалось остановить' in msg and en(TR))
rc('S22trojan', 'stop', 0)
ok, msg = u.protocol_set_enabled('trojan', False)
chk('beh: stop ok → True', ok and not en(TR))
rc('S22trojan', 'stop', 7)
open(FIX + 'S22trojan', 'w').write(INIT_TPL % ('S22trojan', Z))
ok, msg = u.nfqws2_set_enabled(True, also_disable_conflicts=True)
chk('beh: force прерван на неподавленном конфликте',
    (not ok) and 'NFQWS2 не включён' in msg and en(TR))
rc('S22trojan', 'stop', 0)
rc('S51nfqws2', 'restart', 3)
ok, msg = u.nfqws2_set_mode('all', force=True)
conf = open(Z + '/nfw2/nfqws2.conf').read()
chk('beh: отказ рестарта → откат режима',
    (not ok) and 'прежний режим восстановлен' in msg
    and 'MODE_LIST' in conf and 'MODE_ALL' not in conf)
rc('S51nfqws2', 'restart', 0)
shutil.rmtree('/tmp/keenzoo_toggle.lockdir', ignore_errors=True)
chk('beh: lock захват/занятость',
    u.acquire_toggle_lock() and not u.acquire_toggle_lock())
u.release_toggle_lock()
chk('beh: lock перехват', u.acquire_toggle_lock())
u.release_toggle_lock()
stub = '/opt/bin/nfqws2_update_excludes.sh'
os.makedirs('/opt/bin', exist_ok=True)
try:
    open(stub, 'w').write('#!/bin/sh\nexit 3\n')
    u.nfqws2_installed = lambda: True
    chk('beh: quiet rc=3 → False',
        not u.nfqws2_update_excludes_quiet())
    open(stub, 'w').write('#!/bin/sh\nexit 0\n')
    chk('beh: quiet rc=0 → True',
        u.nfqws2_update_excludes_quiet())
finally:
    if os.path.exists(stub):
        os.unlink(stub)

# ── shell: excludes на реальных схемах шаблонов ──
env = dict(os.environ, NFW2_DIR=Z + '/nfw2',
           NFW2_HOSTS=Z + '/etc/hosts', NFW2_CONF_ROOT=Z + '/etc',
           NFW2_S51=FIX + 'S51nfqws2',
           NFW2_COMMON=K + '/opt/bin/common.sh')
r = subprocess.run(['sh', K + '/opt/bin/nfqws2_update_excludes.sh'],
                   capture_output=True, text=True, timeout=30, env=env)
ip = open(Z + '/nfw2/lists/ipset_exclude.list').read()
dl = open(Z + '/nfw2/lists/exclude.list').read()
chk('sh: IP-literal xray/trojan/ss в ipset-исключениях',
    r.returncode == 0 and '8.8.8.8' in ip and '9.9.9.9' in ip
    and '1.1.1.1' in ip)
chk('sh: домен hysteria + пользовательская строка',
    'hy.example.com' in dl and 'user-entry.example' in dl)
open(Z + '/nfw2/lists/exclude.list', 'w').write(
    '# BEGIN KeenZOO managed excludes\nuser-after.example\n')
r = subprocess.run(['sh', K + '/opt/bin/nfqws2_update_excludes.sh'],
                   capture_output=True, text=True, timeout=30, env=env)
dl = open(Z + '/nfw2/lists/exclude.list').read()
chk('sh: повреждённый блок → файл не тронут, rc=1',
    r.returncode == 1 and 'user-after.example' in dl
    and '# END' not in dl)
rc('S51nfqws2', 'start', 9)
r = subprocess.run(['sh', FIX + 'S90nfqws2', 'start'],
                   capture_output=True, timeout=30)
chk('sh: S90 наружу rc=9', r.returncode == 9)
rc('S51nfqws2', 'start', None)

# ── shell: postinstall fail-closed ──
PI = os.path.join(F, 'z59pi')
shutil.rmtree(PI, ignore_errors=True)
os.makedirs(PI + '/init.d', exist_ok=True)
open(PI + '/nfqws_web.conf', 'w').write('[auth]\nenabled = true\n')
open(PI + '/entware.conf', 'w').write(
    'server.port := 90\n$SERVER["socket"] == ":90" {\n}\n')
open(PI + '/init.d/S80lighttpd', 'w').write('#!/bin/sh\nexit 0\n')
os.chmod(PI + '/init.d/S80lighttpd', 0o755)
open(PI + '/init.d/S51nfqws2', 'w').write('#!/bin/sh\nexit 0\n')
pi_env = dict(os.environ,
              KZ_NFW_S51=PI + '/init.d/S51nfqws2',
              KZ_NFW_WEB_CONF=PI + '/nfqws_web.conf',
              KZ_NFW_LIGHTTPD_CONF=PI + '/entware.conf',
              KZ_NFW_LIGHTTPD_INIT=PI + '/init.d/S80lighttpd')
fake_ip = '/opt/bin/ip'
try:
    open(fake_ip, 'w').write('#!/bin/sh\nexit 0\n')
    os.chmod(fake_ip, 0o755)
    r = subprocess.run(
        ['sh', K + '/opt/bin/nfqws2_postinstall.sh'],
        capture_output=True, text=True, timeout=30, env=pi_env)
    chk('sh: postinstall без LAN-IP → rc=1, auth включён, конфиг не тронут',
        r.returncode == 1
        and 'enabled = true' in open(PI + '/nfqws_web.conf').read()
        and 'server.bind' not in open(PI + '/entware.conf').read())
    open(fake_ip, 'w').write(
        "#!/bin/sh\nprintf 'inet 192.168.1.1/24 scope global br0\n"
        "inet 10.0.0.2/24 scope global br0\n'\n")
    os.chmod(fake_ip, 0o755)
    r = subprocess.run(
        ['sh', K + '/opt/bin/nfqws2_postinstall.sh'],
        capture_output=True, text=True, timeout=30, env=pi_env)
    ec = open(PI + '/entware.conf').read()
    chk('sh: два LAN-IP → один бинд, auth off',
        r.returncode == 0
        and 'enabled = true' not in open(PI + '/nfqws_web.conf').read()
        and ec.count('server.bind :=') == 1
        and 'server.bind := "192.168.1.1"' in ec
        and '192.168.1.1:90' in ec)
finally:
    if os.path.exists(fake_ip):
        os.unlink(fake_ip)

if fails:
    print('BAD z59-r91: ' + '; '.join(fails))
else:
    print('OK z59-r91')
PYZ59
grep -q '^OK z59-r91' "$F/z59py.out" \
    && ok "Z59: r91-hardening (аудит r90, решение владельца 02.11.2026 — пакеты А-Д + опция Е): А — честность переключений (returncode init проверяется везде: set_service_enabled откатывает ENABLED и поднимает RuntimeError; protocol_set_enabled stop-откат ENABLED=yes, start — честные предупреждения; nfqws2_set_enabled откат + разрыв force-цепочки на неподавленном конфликте; nfqws2_set_mode откат строки режима при отказе рестарта; S90 передаёт rc S51; _reapply_netfilter логирует rc); Б — postinstall fail-closed (бинд lighttpd ДО auth: запись + lighttpd -t + рестарт с контролем rc + откат; нет LAN-IP → auth остаётся включённым; один адрес вместо мультистрочного бинда; вызывающие не глушат отказ); В — excludes по фактическим схемам шаблонов (vnext.address/remote_addr/ss-массив/hysteria.server — домен И IP-literal; повреждённые маркеры → файл не тронут; идентичное не перезаписывается; quiet() проверяет rc); Г — панель = бот (guard protocol_configured до включения, единый детектор конфликтов ENABLED-ИЛИ-pidof, force подтверждает исчезновение процессов); Д — свежесть статуса обновлений (ts с допуском 2 c, старый файл → «Проверка не завершена», не «Всё актуально»); Е — межпроцессный lockdir переключений (панель+бот, устойчивый lock снимается). Поведенчески на фикстурах + shell-пробы excludes/postinstall/S90" \
    || bad "Z59: $(cat "$F/z59py.out")"

# ═══ Z60 (r92-boot-consistency: решение владельца 02.11.2026 — автостарт после разворачивания) ═══
python3 - "$K" "$F" > "$F/z60py.out" 2>&1 <<'PYZ60'
import os, sys, re, shutil, subprocess
K, F = sys.argv[1], sys.argv[2]
Z = os.path.join(F, 'z60')
fails = []
def chk(name, cond):
    if not cond:
        fails.append(name)

dep = open(K + '/opt/bin/deploy_bypass.sh', encoding='utf-8').read()
s90 = open(K + '/opt/etc/init.d/S90nfqws2', encoding='utf-8').read()
upd = open(K + '/opt/bin/update_protocols.sh', encoding='utf-8').read()

# ── статика ──
chk('стат: список сохраняемых обёртек (6, вкл. S90)',
    '_KZ_ENABLED_SERVICES="S22trojan S24xray S35tor '
    'S57hysteria S65shadowsocks S90nfqws2"' in dep)
i_save = dep.index('kz_enabled_save\n')
i_cp = dep.index('busybox cp -a "$_SAFE_EXTRACT_DIR/opt/." /opt/')
i_rest = dep.index('if kz_enabled_restore; then')
chk('стат: save до apply, restore после', i_save < i_cp < i_rest)
chk('стат: гейт старта туннелей ([10/11] + рестарт S24) — 6 вызовов',
    dep.count('kz_start_if_enabled "') == 6)
chk('стат: явный пропуск в выводе', 'пропущен — выключен' in dep)
chk('стат: S90 поставка ENABLED=no + обоснование r92',
    re.search(r'(?m)^ENABLED=no$', s90) is not None and 'r92' in s90)
chk('стат: S90 rc-честность r91 не тронута',
    s90.count('exit "$?"') == 3)
chk('стат: S56dnsmasq старт без гейта (не пользовательский тумблер)',
    'safe_start_service "S56dnsmasq"' in dep)
chk('стат: update_protocols по-прежнему гейтит старт (F7)',
    "grep -qE '^[[:space:]]*ENABLED[[:space:]]*=[[:space:]]*no'" in upd)

# ── поведение: save → apply → restore + гейт старта ──
shutil.rmtree(Z, ignore_errors=True)
live = os.path.join(Z, 'live')
rel = os.path.join(Z, 'rel')
mk = os.path.join(Z, 'markers')
for d in (live, rel, mk):
    os.makedirs(d)
# живое дерево: смешанные состояния, S35tor с кавычками,
# S65shadowsocks живого нет (свежий файл релиза)
LIVE_STATE = {'S22trojan': 'no', 'S24xray': 'yes', 'S35tor': '"no"',
              'S57hysteria': 'yes', 'S90nfqws2': 'no'}
for s, v in LIVE_STATE.items():
    open(os.path.join(live, s), 'w').write(
        '#!/bin/sh\nENABLED=%s\n' % v)
for s in ('S22trojan', 'S24xray', 'S35tor', 'S57hysteria',
          'S65shadowsocks', 'S90nfqws2'):
    open(os.path.join(rel, s), 'w').write(
        '#!/bin/sh\nENABLED=yes\n'
        'case "$1" in start) touch %s.start; exit 0;; esac\n'
        'exit 0\n' % os.path.join(mk, s))
    os.chmod(os.path.join(rel, s), 0o755)


def extract(name):
    i = dep.index(name + '() {')
    j = dep.index('\n}\n', i) + 3
    return dep[i:j]


SVCS = ('S22trojan S24xray S35tor S57hysteria S65shadowsocks '
        'S90nfqws2')
harness = os.path.join(Z, 'harness.sh')
lines = ['#!/bin/sh',
         '_KZ_ENABLED_SERVICES="' + SVCS + '"',
         '_KZ_ENABLED_SAVE=""',
         extract('kz_enabled_save'),
         extract('kz_enabled_restore'),
         extract('kz_start_if_enabled'),
         'safe_start_service() {',
         '    _svc="$1"',
         '    [ -x "$KZ_INIT_ROOT/$_svc" ] && '
         '"$KZ_INIT_ROOT/$_svc" start >/dev/null 2>&1 || true',
         '}',
         'kz_enabled_save',
         'echo "SAVE=[$_KZ_ENABLED_SAVE]"',
         'cp -a ' + rel + '/. ' + live + '/',
         'kz_enabled_restore',
         'for _s in ' + SVCS + '; do '
         'echo $_s=$(sed -n "s/^ENABLED=//p" $KZ_INIT_ROOT/$_s '
         '| head -n 1); done',
         'for _s in ' + SVCS + '; do kz_start_if_enabled "$_s"; done']
open(harness, 'w').write('\n'.join(lines) + '\n')
env = dict(os.environ, KZ_INIT_ROOT=live)
r = subprocess.run(['sh', harness], capture_output=True, text=True,
                   timeout=30, env=env)
out = r.stdout
m = re.search(r'SAVE=\[([^\]]*)\]', out)
chk('beh: save снял 5 состояний, S65 живого нет',
    m is not None and 'S22trojan:no' in m.group(1)
    and 'S24xray:yes' in m.group(1) and 'S35tor:no' in m.group(1)
    and 'S57hysteria:yes' in m.group(1)
    and 'S90nfqws2:no' in m.group(1)
    and 'S65shadowsocks' not in m.group(1))
expect = {'S22trojan': 'no', 'S24xray': 'yes', 'S35tor': 'no',
          'S57hysteria': 'yes', 'S65shadowsocks': 'yes',
          'S90nfqws2': 'no'}
got = dict(re.findall(r'^(S\w+)=(\S+)$', out, re.M))
chk('beh: restore вернул состояния; S65 — дефолт релиза',
    all(got.get(k) == v for k, v in expect.items()))
started = set(os.listdir(mk))
chk('beh: старт только включённых (S24/S57/S65)',
    started == {'S24xray.start', 'S57hysteria.start',
                'S65shadowsocks.start'})
chk('beh: явные сообщения о пропуске (3)',
    out.count('пропущен — выключен') == 3)

if fails:
    print('BAD z60-r92: ' + '; '.join(fails))
else:
    print('OK z60-r92')
PYZ60
grep -q '^OK z60-r92' "$F/z60py.out" \
    && ok "Z60: r92-boot-consistency (решение владельца 02.11.2026 — проверка вопроса «после разворачивания и перезагрузки протоколы стартуют вместе с nfqws2?»): подтверждено и закрыто — deploy apply перезаписывал init-обёртки дефолтами ENABLED=yes (keep-политика C-1/C-2 берегла только конфиг бота и списки), [10/11] стартовал туннели безусловно, S90 в поставке был ENABLED=yes → после перезагрузки (а при обновлении поверх Глобал-состояния — уже в сессии deploy, т.к. nfqws2 не останавливается) туннели и nfqws2 стартовали вместе, включая сброшенное пользователем «выкл». Исправлено: kz_enabled_save/kz_enabled_restore — ENABLED= снимаются с живых обёртек до apply и возвращаются после (строго yes/no, кавычки срезаются; нет живого файла — дефолт релиза); kz_start_if_enabled — старт на [10/11] и рестарт S24 только включённых, выключенные пропускаются с явным сообщением; S90 в поставке ENABLED=no (свежая установка не включает nfqws2 сама — пакетный дефолт режима AUTO; включение — осознанный выбор панель/бот с проверкой конфликтов), существующие установки не сбрасываются; rc-честность r91 и гейт F7 update_protocols не тронуты. Поведение — на извлечённых из deploy функциях (save/restore/гейт старта, маркеры)" \
    || bad "Z60: $(cat "$F/z60py.out")"


echo "═══ Z61. r93: аудит r92 — пакеты А-Д + Е + З + И ═══"

# Статика: А — lock-владение (token/PID/heartbeat).
Z61L=$(grep -c '_TOGGLE_LOCK_TOKEN' "$K/opt/etc/bot/utils.py" || true)
Z61A1=$(grep -c 'def _toggle_lock_heartbeat' "$K/opt/etc/bot/utils.py" || true)
Z61A2=$(grep -c '_toggle_lock_heartbeat()' "$K/opt/etc/bot/utils.py" || true)
Z61A3=$(grep -c 'def _pid_alive' "$K/opt/etc/bot/utils.py" || true)
[ "$Z61L" -ge 8 ] && [ "$Z61A1" = 1 ] && [ "$Z61A2" = 3 ] && [ "$Z61A3" = 1 ] \
    && ok "Z61-1a: А — token-владение lock: owner=PID+token, heartbeat в _run_init_cmd и _reapply_netfilter_light (2 вызова), _pid_alive" \
    || bad "Z61-1a: token=$Z61L hb_def=$Z61A1 hb_calls=$Z61A2 alive=$Z61A3"
Z61A4=$(sed -n "$(grep -n 'def _release_toggle_lock_under_kflock' "$K/opt/etc/bot/utils.py" | cut -d: -f1),/^def /p" "$K/opt/etc/bot/utils.py" | grep -c 'cur != token' || true)
Z61A5=$(sed -n "$(grep -n 'def _acquire_toggle_lock_under_kflock' "$K/opt/etc/bot/utils.py" | cut -d: -f1),/^def /p" "$K/opt/etc/bot/utils.py" | grep -c '_pid_alive(pid)' || true)
[ "$Z61A4" = 1 ] && [ "$Z61A5" -ge 1 ] \
    && ok "Z61-1b: А — release сверяет token (cur != token → no-op), отбор только у мёртвого PID (r92: отбор по mtime вытеснял живую долгую операцию)" \
    || bad "Z61-1b: tokcmp=$Z61A4 steal=$Z61A5"

# Статика: В — reapply-статус + честные отказы.
Z61B1=$(grep -c 'return ok' "$K/opt/etc/bot/generator.py" || true)
Z61B2=$(grep -c 'не переприменились' "$K/opt/etc/bot/utils.py" || true)
Z61B3=$(grep -c 'не переприменились' "$K/opt/etc/bot/generator.py" || true)
Z61B4=$(grep -c '_flash_reapply_warning' "$K/opt/etc/bot/generator.py" || true)
[ "$Z61B1" -ge 1 ] && [ "$Z61B2" -ge 4 ] && [ "$Z61B3" -ge 3 ] && [ "$Z61B4" -ge 4 ] \
    && ok "Z61-2a: В — _reapply_netfilter(_light) возвращают итог; «⚠️ не переприменились» в обоих модулях; helper + все вызовы панели" \
    || bad "Z61-2a: genret=$Z61B1 u_msg=$Z61B2 g_msg=$Z61B3 helper=$Z61B4"
Z61B5=$(grep -c '_nfw2_fail_with_stopped' "$K/opt/etc/bot/utils.py" || true)
Z61B6=$(sed -n "$(grep -n 'def _restore_conf' "$K/opt/etc/bot/utils.py" | cut -d: -f1),/^def \|^    def /p" "$K/opt/etc/bot/utils.py" | grep -c 'return False' || true)
[ "$Z61B5" -ge 5 ] && [ "$Z61B6" = 1 ] \
    && ok "Z61-2b: В — отказные выходы force-цепочки → reapply + перечень «Выключены: …»; _restore_conf возвращает статус (ложное «режим восстановлен» закрыто)" \
    || bad "Z61-2b: failstop=$Z61B5 restore=$Z61B6"

# Статика: Б — потоки (слабые устройства).
Z61C1=$(grep -c 'threading.stack_size(256 \* 1024)' "$K/opt/etc/bot/generator.py" || true)
Z61C2=$(grep -c '_DNS_HEAVY_SEM = threading.BoundedSemaphore(4)' "$K/opt/etc/bot/generator.py" || true)
Z61C3=$(grep -c '_DNS_HEAVY_WAIT = 2.0' "$K/opt/etc/bot/generator.py" || true)
[ "$Z61C1" = 1 ] && [ "$Z61C2" = 1 ] && [ "$Z61C3" = 1 ] \
    && ok "Z61-3: Б — stack_size 256 КБ перед app.run; семафор(4) + ожидание 2 с на дорогом DNS-маршруте (замер r92: 129 потоков на 128 cold-запросах)" \
    || bad "Z61-3: stack=$Z61C1 sem=$Z61C2 wait=$Z61C3"

# Статика: Г — числовой ts в handlers.
Z61D1=$(grep -c 'isinstance(_ts, bool)' "$K/opt/etc/bot/handlers.py" || true)
Z61D2=$(grep -c 'isinstance(_ts, (int, float))' "$K/opt/etc/bot/handlers.py" || true)
[ "$Z61D1" = 1 ] && [ "$Z61D2" = 1 ] \
    && ok "Z61-4: Г — ts только число (bool/строка/NaN/Infinity → stale), TypeError-обрыв обработчика закрыт (KZ92-04)" \
    || bad "Z61-4: bool=$Z61D1 num=$Z61D2"

# Статика: Д + И — deploy.
Z61E1=$(sed -n "$(grep -n 'kz_enabled_restore() {' "$K/opt/bin/deploy_bypass.sh" | cut -d: -f1),/^}/p" "$K/opt/bin/deploy_bypass.sh" | grep -c '_ker_bad' || true)
Z61E2=$(sed -n "$(grep -n 'if busybox cp -a' "$K/opt/bin/deploy_bypass.sh" | head -1 | cut -d: -f1),+42p" "$K/opt/bin/deploy_bypass.sh" | grep -c 'kz_enabled_restore' || true)
Z61E3=$(grep -c 'процесс $_kie_proc не поднялся' "$K/opt/bin/deploy_bypass.sh" || true)
[ "$Z61E1" -ge 5 ] && [ "$Z61E2" -ge 2 ] && [ "$Z61E3" = 1 ] \
    && ok "Z61-5: Д+И — restore проверяет rc sed и перечитывает значение (fail-closed); error-ветка apply делает best-effort restore; [10/11] честно сообщает «процесс не поднялся»" \
    || bad "Z61-5: verify=$Z61E1 errbranch=$Z61E2 nostart=$Z61E3"

# Статика: Е — владелец перед unlink.
Z61F1=$(grep -c '_claim_ts' "$K/opt/etc/bot/generator.py" || true)
Z61F2=$(grep -c "_cur.get('ts') == _claim_ts" "$K/opt/etc/bot/generator.py" || true)
[ "$Z61F1" -ge 3 ] && [ "$Z61F2" = 1 ] \
    && ok "Z61-6: Е — клейм PROTO_UPD_STATUS снимается только при совпадении action+ts своей публикации (r92: unlink снимал чужой клейм)" \
    || bad "Z61-6: claim=$Z61F1 own=$Z61F2"

# Статика: З — поставка шести обёрток ENABLED=no.
Z61G=0
for _z in S22trojan S24xray S35tor S57hysteria S65shadowsocks S90nfqws2; do
    [ "$(sed -n 's/^ENABLED=//p' "$K/opt/etc/init.d/$_z" | head -1)" = "no" ] \
        && Z61G=$((Z61G + 1))
done
[ "$Z61G" = 6 ] \
    && ok "Z61-7: З — все шесть обёрток в поставке ENABLED=no (решение владельца 03.11.2026): свежая установка не стартит туннели/nfqws2 сама; существующие не сбрасываются (Z60 save/restore)" \
    || bad "Z61-7: no-обёрток=$Z61G из 6"

# ── поведение: lock + force-цепочка + ts + deploy-restore + dns-гейт ──
python3 - "$K" > "$F/z61py.out" 2>&1 <<'PYZ61'
import sys, os, re, json, time, shutil, subprocess
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
fails = []


def chk(name, cond):
    print(('OK ' if cond else 'BAD ') + name)
    if not cond:
        fails.append(name)


# ── А: lock-владение (реальный utils) ──
import utils as u
LD = '/tmp/keenzoo_toggle.lockdir'
shutil.rmtree(LD, ignore_errors=True)
chk('z61-a1 захват/повторный отказ',
    u.acquire_toggle_lock() and not u.acquire_toggle_lock())
u.release_toggle_lock()
chk('z61-a2 после release свободен', u.acquire_toggle_lock())
u.release_toggle_lock()
os.mkdir(LD)
open(LD + '/owner', 'w').write('%d deadbeef' % os.getpid())
chk('z61-a3 живой владелец → не отбираем',
    not u.acquire_toggle_lock())
old = time.time() - 600
os.utime(LD, (old, old))
chk('z61-a4 живой владелец + mtime 10 мин → не отбираем (r92-баг)',
    not u.acquire_toggle_lock())
shutil.rmtree(LD, ignore_errors=True)
_d = subprocess.Popen(['true'])
_d.wait()
os.mkdir(LD)
open(LD + '/owner', 'w').write('%d abcdef' % _d.pid)
chk('z61-a5 мёртвый владелец → отбор', u.acquire_toggle_lock())
u.release_toggle_lock()
chk('z61-a6 lock чист после release', not os.path.exists(LD))
u.acquire_toggle_lock()
open(LD + '/owner', 'w').write('%d foreigntoken' % os.getpid())
u.release_toggle_lock()
chk('z61-a7 чужой token → release не удаляет lock',
    os.path.exists(LD))
shutil.rmtree(LD, ignore_errors=True)
u.acquire_toggle_lock()
m1 = os.stat(LD).st_mtime
time.sleep(0.02)
u._toggle_lock_heartbeat()
chk('z61-a8 heartbeat обновляет mtime',
    os.stat(LD).st_mtime > m1)
u.release_toggle_lock()

# ── В: force-цепочка → reapply + перечень (извлечённая логика) ──
FIX = '/tmp/f47chk/z61init/'
shutil.rmtree(FIX, ignore_errors=True)
os.makedirs(FIX)
for s in ('S22trojan', 'S24xray', 'S35tor', 'S57hysteria',
          'S65shadowsocks', 'S51nfqws2', 'S90nfqws2'):
    open(FIX + s, 'w').write(
        '#!/bin/sh\nENABLED=yes\ncase "$1" in '
        'start|stop|restart) exit 0;; esac\nexit 0\n')


def en(p):
    for ln in open(p):
        m = re.match(r'^\s*ENABLED\s*=\s*(\S+)', ln)
        if m:
            return m.group(1).strip('"\'') == 'yes'
    return False


u.NFQWS2_S51 = FIX + 'S51nfqws2'
u.NFQWS2_INIT = FIX + 'S90nfqws2'
u.NFQWS2_CONFLICT_SERVICES = (
    ('shadowsocks', FIX + 'S65shadowsocks', 'ss-redir'),
    ('trojan', FIX + 'S22trojan', 'trojan'),
    ('vless', FIX + 'S24xray', 'xray'),
    ('tor', FIX + 'S35tor', 'tor'),
    ('hysteria', FIX + 'S57hysteria', 'hysteria'))
import bot_config as cfg
cfg.paths['nfqws2_dir'] = FIX
open(FIX + 'nfqws2.conf', 'w').write('NFQWS_EXTRA_ARGS="$MODE_LIST"\n')
calls = [0]
_real = u._reapply_netfilter_light
u._reapply_netfilter_light = lambda: (calls.__setitem__(
    0, calls[0] + 1), True)[1]
# первый конфликт останавливается, второй — нет (rc-файл)
_rc = {}


def _ric(init_path, action):
    class _R:
        returncode = 0
    if (init_path, action) in _rc:
        class _R2:
            returncode = _rc[(init_path, action)]
        return _R2()
    return _R()


_rc[(FIX + 'S22trojan', 'stop')] = 7
_real_ric = u._run_init_cmd
u._run_init_cmd = _ric
ok, msg = u.nfqws2_set_enabled(True, also_disable_conflicts=True)
chk('z61-b1 частичный стоп → отказ + «Выключены» + reapply',
    (not ok) and 'Выключены: shadowsocks' in msg
    and 'правила их перехвата сняты' in msg and calls[0] >= 1)
chk('z61-b2 S65 выключен, S22 откачен',
    not en(FIX + 'S65shadowsocks') and en(FIX + 'S22trojan'))
u._reapply_netfilter_light = lambda: False
ok, msg = u.nfqws2_set_enabled(False)
chk('z61-b3 reapply-отказ → ⚠️ в успехе',
    ok and 'не переприменились' in msg)
u._reapply_netfilter_light = _real
u._run_init_cmd = _real_ric

# ── Г: ts-матрица (реальный handlers, статус-файл) ──
import logging
logging.basicConfig(level=logging.CRITICAL)
import telebot
from telebot import types
tb = telebot.TeleBot('1:test', threaded=False)
cfg.allowed_user_ids = [42]
import handlers
handlers.setup_handlers(tb)
SENT = []


class M:
    message_id = 1


tb.send_message = lambda cid, text, **kw: (SENT.append(text), M())[1]
tb.answer_callback_query = lambda *a, **k: None
tb.delete_message = lambda *a, **k: None
user = types.User(id=42, is_bot=False, first_name='T')
chat = types.Chat(id=42, type='private')
mkmsg = lambda text: types.Message(
    1, user, int(time.time()), chat, 'text', {'text': text}, '')
if os.path.exists(cfg.paths['check_updates']):
    os.unlink(cfg.paths['check_updates'])
sf = cfg.paths['updates_status']
os.makedirs(os.path.dirname(sf), exist_ok=True)
for label, ts, stale in (
        ('строка', '"not-a-number"', True),
        ('bool', 'true', True),
        ('NaN', 'NaN', True),
        ('Infinity', 'Infinity', True),
        ('старое число', str(int(time.time()) - 3600), True),
        ('свежее число', str(int(time.time())), False)):
    open(sf, 'w').write(
        '{"ts": %s, "has_updates": false, "check_failed": false,'
        ' "versions": {"xray": "1.0"}, "updates": []}' % ts)
    SENT.clear()
    tb.process_new_messages([mkmsg('🆕 Обновления')])
    j = '\n'.join(SENT)
    chk('z61-c ts=%s → %s + финальное сообщение' % (
        label, 'stale' if stale else 'fresh'),
        ('Проверка не завершена' in j) == stale and len(SENT) >= 2)
os.path.exists(sf) and os.unlink(sf)

if fails:
    print('BAD z61-r93: ' + '; '.join(fails))
else:
    print('OK z61-r93')
PYZ61
grep -q '^OK z61-r93' "$F/z61py.out" \
    && ok "Z61-8: поведение r93 — lock (живой/мёртвый/чужой token/heartbeat), force→reapply+перечень, ts-матрица (6 вариантов: строка/bool/NaN/Infinity/старое/свежее — без TypeError-обрыва)" \
    || bad "Z61-8: $(cat "$F/z61py.out")"

# ── поведение: deploy restore (извлечённые функции, sed-саботаж) ──
python3 - "$K" > "$F/z61dep.out" 2>&1 <<'PYDEP'
import sys, os, shutil, subprocess
K = sys.argv[1]
dep = open(K + '/opt/bin/deploy_bypass.sh',
           encoding='utf-8').read()


def extract(name):
    i = dep.index(name + '() {')
    j = dep.index('\n}\n', i) + 3
    return dep[i:j]


Z = '/tmp/f47chk/z61dep'
shutil.rmtree(Z, ignore_errors=True)
os.makedirs(Z + '/live')
os.makedirs(Z + '/sab')
open(Z + '/sab/sed', 'w').write('#!/bin/sh\nexit 1\n')
os.chmod(Z + '/sab/sed', 0o755)
SVCS = ('S22trojan S24xray S35tor S57hysteria '
        'S65shadowsocks S90nfqws2')
open(Z + '/live/S22trojan', 'w').write(
    '#!/bin/sh\nENABLED=no\n')
h = ['#!/bin/sh',
     '_KZ_ENABLED_SERVICES="' + SVCS + '"',
     '_KZ_ENABLED_SAVE=""',
     extract('kz_enabled_save'),
     extract('kz_enabled_restore')]
# прогон 1: sed саботаж ТОЛЬКО на restore (save читает нормы)
open(Z + '/run1.sh', 'w').write('\n'.join(
    h + ['kz_enabled_save',
         'PATH="' + Z + '/sab:$PATH" kz_enabled_restore']) + '\n')
r1 = subprocess.run(
    ['sh', Z + '/run1.sh'],
    env=dict(os.environ, KZ_INIT_ROOT=Z + '/live'),
    capture_output=True, text=True, timeout=30)
ok1 = (r1.returncode == 1
       and 'не подтверждено' in r1.stdout
       and 'S22trojan' in r1.stdout)
# прогон 2: нормальный sed → rc=0, значение восстановлено
open(Z + '/run2.sh', 'w').write('\n'.join(
    h + ['kz_enabled_save',
         'sed -i "s/^ENABLED=.*/ENABLED=yes/" '
         + Z + '/live/S22trojan',
         'kz_enabled_restore',
         'echo VAL=$(sed -n "s/^ENABLED=//p" '
         + Z + '/live/S22trojan | head -n 1)']) + '\n')
r2 = subprocess.run(
    ['sh', Z + '/run2.sh'],
    env=dict(os.environ, KZ_INIT_ROOT=Z + '/live'),
    capture_output=True, text=True, timeout=30)
ok2 = (r2.returncode == 0 and 'VAL=no' in r2.stdout
       and 'не подтверждено' not in r2.stdout)
print('OK z61-dep' if ok1 and ok2 else
      'BAD z61-dep: r1=%d/%s | r2=%d/%s' % (
          r1.returncode, r1.stdout.strip()[:80],
          r2.returncode, r2.stdout.strip()[-60:]))
PYDEP
grep -q '^OK z61-dep' "$F/z61dep.out" \
    && ok "Z61-9: поведение Д — restore fail-closed: отказ sed → rc=1 + «не подтверждено» с перечнем; норма → rc=0 и значение перечитано" \
    || bad "Z61-9: $(cat "$F/z61dep.out")"

# ── поведение: dns-гейт (Flask, реальный generator) ──
if python3 -c 'import flask' >/dev/null 2>&1; then
python3 - "$K" > "$F/z61dns.out" 2>&1 <<'PYDNS'
import sys, time, base64
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g
g.config.web_username = 'admin'
g.config.web_password = 'testpass'
AUTH = {'Authorization': 'Basic ' + base64.b64encode(
    b'admin:testpass').decode()}
c = g.app.test_client()
# все 4 слота заняты → быстрый 503 busy
drained = 0
while g._DNS_HEAVY_SEM.acquire(blocking=False):
    drained += 1
r = c.get('/api/dns-status', headers=AUTH)
ok1 = (r.status_code == 503
       and (r.get_json() or {}).get('status') == 'busy')
# кэш-попадание при занятом гейте → 200
g._DNS_STATUS_CACHE['ts'] = time.time()
g._DNS_STATUS_CACHE['data'] = {'ok': True, 'cached': True}
r = c.get('/api/dns-status', headers=AUTH)
ok2 = (r.status_code == 200
       and (r.get_json() or {}).get('cached') is True)
g._DNS_STATUS_CACHE['ts'] = 0.0
g._DNS_STATUS_CACHE['data'] = None
# свободный слот → 200 (probe под моком, без форков dig)
g._DNS_HEAVY_SEM.release()
_orig = g.check_dns_ports
g.check_dns_ports = lambda: {'ok': True, 'fake': True}
r = c.get('/api/dns-status', headers=AUTH)
ok3 = (r.status_code == 200
       and (r.get_json() or {}).get('fake') is True)
g.check_dns_ports = _orig
# слоты сбалансированы (BoundedSemaphore без переполнения)
ok4 = True
for _ in range(drained - 1):
    try:
        g._DNS_HEAVY_SEM.release()
    except ValueError:
        ok4 = False
print('OK z61-dns' if ok1 and ok2 and ok3 and ok4 else
      'BAD z61-dns: 503=%s cache=%s free=%s bal=%s' % (
          ok1, ok2, ok3, ok4))
PYDNS
grep -q '^OK z61-dns' "$F/z61dns.out" \
    && ok "Z61-10: поведение Б — гейт /api/dns-status: 4 занятых слота → 503 busy (быстрый отказ); кэш-попадание не гейтится; свободный слот → 200; семафор сбалансирован" \
    || bad "Z61-10: $(cat "$F/z61dns.out")"
else
    ok "Z61-10: поведение Б — пропущено (flask не установлен; статика Z61-3 проверена)"
fi


echo "═══ Z62. r94: аудит r93 — пакеты А-Д + опция Ж(а) ═══"

# Статика: А — recovery-гейт + fail-closed owner.
Z62A1=$(grep -c "_TOGGLE_RECOVERY_DIR = _TOGGLE_LOCKDIR + '.recovery'" "$K/opt/etc/bot/utils.py" || true)
Z62A2=$(grep -c 'def _recovery_gate_acquire' "$K/opt/etc/bot/utils.py" || true)
Z62A3=$(grep -c 'def _owner_pid_in' "$K/opt/etc/bot/utils.py" || true)
Z62A4=$(grep -c "_tmp, os.path.join(_TOGGLE_LOCKDIR, 'owner'))" "$K/opt/etc/bot/utils.py" || true)
Z62A5=$(grep -c 'def _drop_fresh_lockdir_silent' "$K/opt/etc/bot/utils.py" || true)
Z62A6=$(grep -c '(_st.st_dev, _st.st_ino) == ident' "$K/opt/etc/bot/utils.py" || true)
[ "$Z62A1" = 1 ] && [ "$Z62A2" = 1 ] && [ "$Z62A3" = 1 ] && [ "$Z62A4" = 1 ] && [ "$Z62A5" = 1 ] && [ "$Z62A6" = 1 ] \
    && ok "Z62-1: А — реклейм под recovery-гейтом (mkdir) с пост-проверкой перенесённого (_owner_pid_in); owner пишется атомарно (mkstemp+replace) fail-closed (каталог попытки убирается); release при нечитаемом owner — best-effort по идентичности каталога r95 (r93-гонка двойного acquire, «зависание» после EIO и r94-удаление чужого lock закрыты)" \
    || bad "Z62-1: rec=$Z62A1 gate=$Z62A2 pidin=$Z62A3 rep=$Z62A4 drop=$Z62A5 rel=$Z62A6"

# Статика: Б — JS-обработка busy-503.
Z62B1=$(grep -c "j.status==='busy'" "$K/opt/etc/bot/generator.py" || true)
Z62B2=$(grep -c "d.status==='busy'" "$K/opt/etc/bot/generator.py" || true)
Z62B3=$(grep -c '_dnsBusyTries' "$K/opt/etc/bot/generator.py" || true)
Z62B4=$(grep -c 'setTimeout(function(){if(_dO)fetchDns()},3000)' "$K/opt/etc/bot/generator.py" || true)
Z62B5=$(grep -c 'проверка занята, повтор' "$K/opt/etc/bot/generator.py" || true)
[ "$Z62B1" = 4 ] && [ "$Z62B2" = 5 ] && [ "$Z62B3" -ge 4 ] && [ "$Z62B4" = 1 ] && [ "$Z62B5" = 1 ] \
    && ok "Z62-2: Б — дашборд: busy не затирает состояние («проверка занята, повтор»); pollNow: busy не рендерится; вкладка DNS: прямой fetch, один автоповтор через 3 с, честная ошибка вместо вечного checking (r93: «все 0 серверов живы»)" \
    || bad "Z62-2: dash=$Z62B1 now=$Z62B2 tries=$Z62B3 retry=$Z62B4 msg=$Z62B5"

# Статика: В — честный reapply в отказной ветке.
Z62V1=$(sed -n "$(grep -n 'def _nfw2_fail_with_stopped' "$K/opt/etc/bot/utils.py" | cut -d: -f1),/^def /p" "$K/opt/etc/bot/utils.py" | grep -c 'reapply_ok = _reapply_netfilter_light()' || true)
Z62V2=$(sed -n "$(grep -n 'def _nfw2_fail_with_stopped' "$K/opt/etc/bot/utils.py" | cut -d: -f1),/^def /p" "$K/opt/etc/bot/utils.py" | grep -c 'могут остаться до следующего события NDM' || true)
[ "$Z62V1" = 1 ] && [ "$Z62V2" = 1 ] \
    && ok "Z62-3: В — _nfw2_fail_with_stopped сохраняет результат reapply: при неудаче НЕ заявляется «правила сняты», а честное «могут остаться до следующего события NDM» (r93: утверждение при любом исходе)" \
    || bad "Z62-3: save=$Z62V1 warn=$Z62V2"

# Статика: Г — панель: перечень остановленных.
Z62G1=$(sed -n "$(grep -n 'def _toggle_nfqws2' "$K/opt/etc/bot/generator.py" | cut -d: -f1),/^def /p" "$K/opt/etc/bot/generator.py" | grep -c '_stopped_t' || true)
Z62G2=$(sed -n "$(grep -n 'def _toggle_nfqws2' "$K/opt/etc/bot/generator.py" | cut -d: -f1),/^def /p" "$K/opt/etc/bot/generator.py" | grep -c '_ra_bad' || true)
[ "$Z62G1" -ge 5 ] && [ "$Z62G2" -ge 5 ] \
    && ok "Z62-4: Г — force-цикл панели учитывает результат каждого stop и перечисляет подтверждённо остановленных во ВСЕХ ветках (живой остаток, исключение, успех) вместе с результатом reapply (r93: молчаливый частичный force-stop)" \
    || bad "Z62-4: stopped=$Z62G1 ra=$Z62G2"

# Статика: Д — схема статуса обновлений + верхняя граница ts.
Z62D1=$(grep -c 'updates_info = None' "$K/opt/etc/bot/handlers.py" || true)
Z62D2=$(grep -c '_ts > time.time() + 60.0' "$K/opt/etc/bot/handlers.py" || true)
Z62D3=$(grep -c 'isinstance(_v, dict)' "$K/opt/etc/bot/handlers.py" || true)
Z62D4=$(grep -c "'available', 'source'))]" "$K/opt/etc/bot/handlers.py" || true)
[ "$Z62D1" -ge 1 ] && [ "$Z62D2" = 1 ] && [ "$Z62D3" = 1 ] && [ "$Z62D4" = 1 ] \
    && ok "Z62-5: Д — корень не dict → статуса нет (без AttributeError); ts из будущего (+60 с допуск) → stale; versions только dict; updates только список полных записей, валидность отслеживается r95 (r93: обрывы на мусорном JSON и ложное «Всё актуально» по будущему ts)" \
    || bad "Z62-5: root=$Z62D1 fut=$Z62D2 ver=$Z62D3 upd=$Z62D4"

# Статика: Ж — глобальный гейт запросов.
Z62J1=$(grep -c '_REQ_GATE_MAX = 8' "$K/opt/etc/bot/generator.py" || true)
Z62J2=$(grep -c 'BoundedSemaphore(_REQ_GATE_MAX)' "$K/opt/etc/bot/generator.py" || true)
Z62J3=$(grep -c 'app.wsgi_app = _gated' "$K/opt/etc/bot/generator.py" || true)
Z62J4=$(grep -c "'503 Service Unavailable'" "$K/opt/etc/bot/generator.py" || true)
[ "$Z62J1" = 1 ] && [ "$Z62J2" = 1 ] && [ "$Z62J3" = 1 ] && [ "$Z62J4" = 1 ] \
    && ok "Z62-6: Ж(а) — WSGI-обёртка: семафор(8), ожидание 1 с, быстрый 503 busy (no-store, тот же контракт, что DNS-маршрут); Werkzeug-потоки ограничены по одновременной работе — профиль памяти панели на 64-128 МБ (решение владельца 03.11.2026)" \
    || bad "Z62-6: max=$Z62J1 sem=$Z62J2 wrap=$Z62J3 st=$Z62J4"

# ── поведение: фикстура-копия бота (для lock/В/Д/Г/Ж/Б без /opt) ──
python3 - "$K" > "$F/z62prep.out" 2>&1 <<'PYPREP'
import sys, os, shutil
K = sys.argv[1]
Z = '/tmp/f47chk/z62'
shutil.rmtree(Z, ignore_errors=True)
os.makedirs(Z + '/bot')
os.makedirs(Z + '/root/etc/init.d')
os.makedirs(Z + '/root/etc/xray')
os.makedirs(Z + '/root/etc/trojan')
os.makedirs(Z + '/root/etc/hysteria')
os.makedirs(Z + '/root/etc/nfqws2/lists')
os.makedirs(Z + '/root/rc')
os.makedirs(Z + '/root/bin')
for m in ('utils', 'handlers', 'lists_core', 'menu', 'generator'):
    shutil.copy(K + '/opt/etc/bot/%s.py' % m, Z + '/bot/')
shutil.copytree(K + '/opt/etc/bot/templates', Z + '/bot/templates')
t = open(K + '/opt/etc/bot/bot_config.py',
         encoding='utf-8').read().replace('/opt/', Z + '/root/')
open(Z + '/bot/bot_config.py', 'w', encoding='utf-8').write(t)
for s in ('S65shadowsocks', 'S22trojan', 'S24xray', 'S35tor',
          'S57hysteria', 'S51nfqws2', 'S90nfqws2'):
    open(Z + '/root/etc/init.d/' + s, 'w').write(
        '#!/bin/sh\nENABLED=yes\n_rcf="%s/rc/%s.$1"\n'
        'if [ -f "$_rcf" ]; then exit $(cat "$_rcf"); fi\nexit 0\n'
        % (Z + '/root', s))
open(Z + '/root/etc/nfqws2/nfqws2.conf', 'w').write(
    'NFQWS_EXTRA_ARGS="$MODE_LIST"\n')
for f in ('exclude.list', 'ipset_exclude.list'):
    open(Z + '/root/etc/nfqws2/lists/' + f, 'w').write(
        '# BEGIN KeenZOO managed excludes\n'
        '# END KeenZOO managed excludes\n')
open(Z + '/root/etc/hosts', 'w').write('# hosts\n')
open(Z + '/root/etc/xray/config.json', 'w').write(
    '{"outbounds":[{"settings":{"vnext":'
    '[{"address":"8.8.8.8"}]}}]}')
open(Z + '/root/etc/trojan/config.json', 'w').write(
    '{"remote_addr":"9.9.9.9"}')
open(Z + '/root/etc/hysteria/config.json', 'w').write(
    '{"server":"hy.example.com:443"}')
open(Z + '/root/shadowsocks.json', 'w').write(
    '{"server":["1.1.1.1"]}')
open(Z + '/root/bin/pidof', 'w').write('#!/bin/sh\nexit 1\n')
os.chmod(Z + '/root/bin/pidof', 0o755)
print('OK z62-prep')
PYPREP
grep -q '^OK z62-prep' "$F/z62prep.out" || bad "Z62-prep: $(cat "$F/z62prep.out")"

# ── поведение А (lock) + В (force-отказ) — utils-уровень ──
python3 - > "$F/z62utils.out" 2>&1 <<'PYUTIL'
import sys, os, time, re, json, shutil, subprocess
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)

import utils as u
FIX = Z + '/root/etc/init.d/'
u.NFQWS2_S51 = FIX + 'S51nfqws2'
u.NFQWS2_INIT = FIX + 'S90nfqws2'
u.NFQWS2_CONFLICT_SERVICES = (
    ('shadowsocks', FIX + 'S65shadowsocks', 'ss-redir'),
    ('trojan', FIX + 'S22trojan', 'trojan'),
    ('vless', FIX + 'S24xray', 'xray'),
    ('tor', FIX + 'S35tor', 'tor'),
    ('hysteria', FIX + 'S57hysteria', 'hysteria'))
import bot_config as cfg
cfg.paths['nfqws2_dir'] = Z + '/root/etc/nfqws2'

LD = '/tmp/keenzoo_toggle.lockdir'
def mkstale():
    shutil.rmtree(LD, ignore_errors=True)
    shutil.rmtree(LD + '.recovery', ignore_errors=True)
    d = subprocess.Popen(['true']); d.wait()
    os.mkdir(LD)
    open(LD + '/owner', 'w').write('%d deadbeef' % d.pid)

# гонка (интерливинг аудита r93): P2 замерает после чтения owner
# r96: acquire читает ОДИН снимок owner (_owner_raw_in) — точка
# паузы перенесена; ожидание маркера с дедлайном
open(Z + '/probe2.py', 'w').write(
    'import sys, os, time\n'
    'sys.path.insert(0, "%s/bot")\n'
    'import utils as u\n'
    'LD = "%s"\n'
    '_real = u._owner_raw_in\n'
    'def slow_read(dirpath):\n'
    '    raw = _real(dirpath)\n'
    '    if dirpath == LD:\n'
    '        open("%s/p2read", "w").write("")\n'
    '        _dl = time.time() + 30\n'
    '        while not os.path.exists("%s/go2"):\n'
    '            if time.time() > _dl:\n'
    '                break\n'
    '            time.sleep(0.01)\n'
    '    return raw\n'
    'u._owner_raw_in = slow_read\n'
    'r = u.acquire_toggle_lock()\n'
    'open("%s/r2", "w").write("True" if r else "False")\n'
    % (Z, LD, Z, Z, Z))
for f in ('p2read', 'go2', 'r2'):
    p = Z + '/' + f
    if os.path.exists(p):
        os.unlink(p)
mkstale()
p2 = subprocess.Popen([sys.executable, Z + '/probe2.py'])
_dl = time.time() + 30
while not os.path.exists(Z + '/p2read'):
    if time.time() > _dl:
        break
    time.sleep(0.01)
r1 = u.acquire_toggle_lock()
open(Z + '/go2', 'w').write('')
p2.wait(timeout=15)
r2v = open(Z + '/r2').read()
chk('z62-a1 гонка двух процессов: ровно один True (P1=%s P2=%s)'
    % (r1, r2v), (r1 is True) != (r2v == 'True'))
_own = open(LD + '/owner').read().split()[0]
chk('z62-a2 lock цел, владелец — победитель',
    _own == (str(os.getpid()) if r1 is True else str(p2.pid)))
u.release_toggle_lock()
chk('z62-a3 release проигравшего — чужой lock не тронут',
    os.path.exists(LD + '/owner'))
shutil.rmtree(LD, ignore_errors=True)

# burst: 6 процессов, барьер — все одновременно
open(Z + '/probe_burst.py', 'w').write(
    'import sys, os, time\n'
    'sys.path.insert(0, "%s/bot")\n'
    'import utils as u\n'
    'open("%s/b" + "%%d.start" %% os.getpid(), "w").write("")\n'
    'while not os.path.exists("%s/barrier"):\n'
    '    time.sleep(0.005)\n'
    'r = u.acquire_toggle_lock()\n'
    'open("%s/b" + "%%d" %% os.getpid(), "w").write("1" if r else "0")\n'
    'if r:\n'
    '    def _n():\n'
    '        return sum(1 for f in os.listdir("%s")\n'
    '                   if f.startswith("b") and f[1:].isdigit())\n'
    '    _t0 = time.time()\n'
    '    while _n() < 6 and time.time() - _t0 < 20:\n'
    '        time.sleep(0.01)\n'
    '    u.release_toggle_lock()\n'
    % (Z, Z, Z, Z, Z))
mkstale()
for f in os.listdir(Z):
    if f.startswith('b') and (f[1:].isdigit() or f.endswith('.start')):
        os.unlink(Z + '/' + f)
if os.path.exists(Z + '/barrier'):
    os.unlink(Z + '/barrier')
procs = [subprocess.Popen([sys.executable, Z + '/probe_burst.py'])
         for _ in range(6)]
_dl = time.time() + 30
while (sum(1 for f in os.listdir(Z) if f.endswith('.start')) < 6
       and time.time() < _dl):
    time.sleep(0.01)
open(Z + '/barrier', 'w').write('')
for pr in procs:
    pr.wait(timeout=30)
os.path.exists(Z + '/barrier') and os.unlink(Z + '/barrier')
_tr = sum(1 for f in os.listdir(Z)
          if f.startswith('b') and f[1:].isdigit()
          and open(Z + '/' + f).read() == '1')
for f in os.listdir(Z):
    if f.startswith('b') and (f[1:].isdigit() or f.endswith('.start')):
        os.unlink(Z + '/' + f)
chk('z62-a4 burst 6 живых процессов: ровно один True (%d)' % _tr,
    _tr == 1)
chk('z62-a5 после burst lock корректно отпущен, мусора нет',
    not os.path.exists(LD)
    and not os.path.exists(LD + '.recovery'))

# отказ атомарной публикации owner
shutil.rmtree(LD, ignore_errors=True)
_rr = os.replace
def _boom(src, dst, *a, **k):
    if str(dst) == os.path.join(LD, 'owner'):
        raise OSError(5, 'Input/output error')
    return _rr(src, dst, *a, **k)
os.replace = _boom
r = u.acquire_toggle_lock()
os.replace = _rr
chk('z62-a6 отказ записи owner: acquire=False, каталог убран',
    r is False and not os.path.exists(LD)
    and u._TOGGLE_LOCK_TOKEN is None)
r = u.acquire_toggle_lock()
chk('z62-a7 после лечения FS захват успешен', r is True)
import builtins
_ro = builtins.open
def _boomread(path, *a, **k):
    if str(path) == os.path.join(LD, 'owner'):
        raise OSError(5, 'Input/output error')
    return _ro(path, *a, **k)
builtins.open = _boomread
u.release_toggle_lock()
builtins.open = _ro
chk('z62-a8 release при EIO чтения owner: lockdir убран',
    not os.path.exists(LD))

# recovery-гейт
mkstale()
os.mkdir(LD + '.recovery')
chk('z62-a9 чужой свежий recovery-гейт → отказ',
    not u.acquire_toggle_lock())
os.rmdir(LD + '.recovery')
os.mkdir(LD + '.recovery')
_old = time.time() - 60
os.utime(LD + '.recovery', (_old, _old))
chk('z62-a10 протухший гейт → уборка, захват удался',
    u.acquire_toggle_lock())
u.release_toggle_lock()
shutil.rmtree(LD, ignore_errors=True)

# В: отказная ветка NFQWS2
def reset_inits():
    for s in ('S65shadowsocks', 'S22trojan', 'S24xray', 'S35tor',
              'S57hysteria', 'S51nfqws2', 'S90nfqws2'):
        t = open(FIX + s).read()
        t = re.sub(r'(?m)^ENABLED=.*$', 'ENABLED=yes', t, count=1)
        open(FIX + s, 'w').write(t)
    for f in os.listdir(Z + '/root/rc'):
        os.unlink(Z + '/root/rc/' + f)

reset_inits()
u._reapply_netfilter_light = lambda: False
open(Z + '/root/rc/S65shadowsocks.stop', 'w').write('0')
open(Z + '/root/rc/S22trojan.stop', 'w').write('7')
ok, msg = u.nfqws2_set_enabled(True, also_disable_conflicts=True)
chk('z62-b1 частичный стоп + reapply=False: перечень + ⚠️, БЕЗ «сняты»',
    (not ok) and 'Выключены: shadowsocks' in msg
    and 'не переприменились' in msg and 'сняты' not in msg)
ok, msg = u.nfqws2_set_enabled(False)
chk('z62-b2 никого не остановили + reapply=False → стандартное ⚠️',
    ok and 'не переприменились' in msg and 'Выключены' not in msg)
u._reapply_netfilter_light = lambda: True
reset_inits()
open(Z + '/root/rc/S22trojan.stop', 'w').write('7')
ok, msg = u.nfqws2_set_enabled(True, also_disable_conflicts=True)
chk('z62-b3 reapply ok → «правила сняты» (регресс-контроль)',
    (not ok) and 'правила их перехвата сняты' in msg)

print('OK z62-utils' if not fails else
      'BAD z62-utils: ' + '; '.join(fails))
PYUTIL
grep -q '^OK z62-utils' "$F/z62utils.out" \
    && ok "Z62-7: поведение А — гонка двух процессов (интерливинг аудита): ровно один acquire=True, lock победителя цел; burst 6 живых процессов (барьер): ровно один; отказ записи owner → False с уборкой каталога (нет зависания на 120 с); recovery-гейт: свежий занят → отказ, протухший → уборка" \
    && ok "Z62-8: поведение В — частичный force-стоп + отказ reapply → «Выключены: …» с ⚠️ «могут остаться», без ложного «правила сняты»; успех → прежнее «сняты» (регресс)" \
    || bad "Z62-7/8: $(cat "$F/z62utils.out" | tail -3)"

# ── поведение Д — handlers-матрица (telebot) ──
if python3 -c 'import telebot' >/dev/null 2>&1; then
python3 - > "$F/z62ts.out" 2>&1 <<'PYTS'
import sys, os, time, json, logging
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond):
    print(('OK ' if cond else 'BAD ') + name)
    if not cond:
        fails.append(name)
import telebot
from telebot import types
import bot_config as cfg
cfg.allowed_user_ids = [42]
tb = telebot.TeleBot('1:test', threaded=False)
import handlers
handlers.setup_handlers(tb)
SENT = []
class M: message_id = 1
tb.send_message = lambda cid, text, **kw: (SENT.append(text), M())[1]
tb.answer_callback_query = lambda *a, **k: None
user = types.User(id=42, is_bot=False, first_name='T')
chat = types.Chat(id=42, type='private')
mk = lambda t: types.Message(
    1, user, int(time.time()), chat, 'text', {'text': t}, '')
sf = cfg.paths['updates_status']
def probe(label, body, stale):
    open(sf, 'w').write(body)
    SENT.clear()
    tb.process_new_messages([mk('🆕 Обновления')])
    j = '\n'.join(SENT)
    got = 'Проверка не завершена' in j
    chk('z62-c %s → stale=%s, финал без обрыва' % (label, stale),
        len(SENT) >= 2 and got == stale)
probe('корень [1]', '[1]', True)
probe('корень "bad"', '"bad"', True)
probe('versions-строка', json.dumps(
    {'ts': int(time.time()), 'versions': 'not-a-dict',
     'updates': [], 'check_failed': False}), False)
probe('updates-мусор', json.dumps(
    {'ts': int(time.time()), 'versions': {'x': '1'},
     'updates': [{'name': 'x'}, 'junk', 5],
     'check_failed': False}), True)  # r95 (В): битые записи = проверка
                                    # не завершена
probe('будущий ts', json.dumps(
    {'ts': int(time.time()) + 86400, 'versions': {'x': '1'},
     'updates': [], 'check_failed': False}), True)
probe('строка ts (r93)', '{"ts": "abc", "versions": {}, "updates": []}', True)
probe('NaN (r93)', '{"ts": NaN, "versions": {}, "updates": []}', True)
probe('свежий (контроль)', json.dumps(
    {'ts': int(time.time()), 'versions': {'x': '1'},
     'updates': [], 'check_failed': False}), False)
open(sf, 'w').write(json.dumps(
    {'ts': int(time.time()), 'versions': 'not-a-dict',
     'updates': [], 'check_failed': False}))
SENT.clear()
tb.process_new_messages([mk('🆕 Обновления')])
chk('z62-c versions-мусор: «Статус версий пока недоступен», не «Всё актуально»',
    'Статус версий пока недоступен' in SENT[-1]
    and 'Всё актуально' not in SENT[-1])
open(sf, 'w').write(json.dumps(
    {'ts': int(time.time()) + 86400, 'versions': {'x': '1'},
     'updates': [], 'check_failed': False}))
SENT.clear()
tb.process_new_messages([mk('🆕 Обновления')])
chk('z62-c будущий ts: НЕ «Всё актуально»',
    'Всё актуально' not in SENT[-1])
os.path.exists(sf) and os.unlink(sf)
print('OK z62-ts' if not fails else 'BAD z62-ts: ' + '; '.join(fails))
PYTS
grep -q '^OK z62-ts' "$F/z62ts.out" \
    && ok "Z62-9: поведение Д — матрица статуса обновлений: корень [1]/\"bad\"/versions-строка/updates-мусор/будущий ts (+86400)/строка/NaN → финальное сообщение без обрыва; versions-мусор → «Статус версий пока недоступен»; будущий ts → НЕ «Всё актуально»; updates-мусор → stale (r95 В); свежий корректный → без stale (регресс r93)" \
    || bad "Z62-9: $(tail -3 "$F/z62ts.out")"
else
    ok "Z62-9: поведение Д — SKIP (telebot не установлен; статика Z62-5 проверена)"
fi

# ── поведение Г + Ж + Б — Flask на фикстуре-копии ──
if python3 -c 'import flask' >/dev/null 2>&1; then
python3 - > "$F/z62panel.out" 2>&1 <<'PYPANEL'
import sys, os, time, re, json, shutil, base64, logging
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)
FIX = Z + '/root/etc/init.d/'
import generator as g
import bot_config as cfg
g._nfqws2_installed = lambda: True
g.SERVICE_SCRIPTS = {
    'shadowsocks': FIX + 'S65shadowsocks', 'trojan': FIX + 'S22trojan',
    'vless': FIX + 'S24xray', 'tor': FIX + 'S35tor',
    'hysteria': FIX + 'S57hysteria', 'nfqws2': FIX + 'S90nfqws2'}
AUTH = {'Authorization': 'Basic ' + base64.b64encode(
    b'admin:testpass').decode()}
g.config.web_username = 'admin'
g.config.web_password = 'testpass'
c = g.app.test_client()

def panel_post(data):
    cc = g.app.test_client()
    d = cc.get('/panel?tab=dns', headers=AUTH).get_data(True)
    m = (re.search(r'name="kz-csrf" content="([^"]+)"', d)
         or re.search(r'name="csrf_token"[^>]*value="([^"]+)"', d))
    dd = dict(data)
    dd['csrf_token'] = m.group(1)
    return cc.post('/toggle/za', data=dd, headers=dict(
        AUTH, Origin='http://127.0.0.1:8080'),
        follow_redirects=True).get_data(True)

LD = '/tmp/keenzoo_toggle.lockdir'
# Г1: второй stop бросает исключение
shutil.rmtree(LD, ignore_errors=True)
_n = {'c': 0}
def _sse(sn, want):
    _n['c'] += 1
    if _n['c'] == 2:
        raise RuntimeError('S22trojan: init rc=7')
    return True
g._nfqws2_status = lambda: {'conflicts_required': True}
g._nfqws2_conflicts = lambda: [
    ('S65shadowsocks', 'Shadowsocks'), ('S22trojan', 'Trojan')]
g.set_service_enabled = _sse
g._nfqws2_intelliqos_suspected = lambda: False
h = panel_post({'enabled': '1', 'force': '1'})
chk('z62-d1 exception-ветка: «выключены: Shadowsocks» в flash',
    'выключены: Shadowsocks' in h and 'rc=7' in h)
# Г2: stop прошёл, процесс жив → _alive-flash с перечнем
shutil.rmtree(LD, ignore_errors=True)
_cn = {'c': 0}
def _conf2():
    _cn['c'] += 1
    if _cn['c'] <= 2:
        return [('S65shadowsocks', 'Shadowsocks'),
                ('S22trojan', 'Trojan')]
    return [('S22trojan', 'Trojan')]
g._nfqws2_conflicts = _conf2
g.set_service_enabled = lambda sn, want: True
h = panel_post({'enabled': '1', 'force': '1'})
chk('z62-d2 живой остаток: перечень остановленных в flash',
    'выключены: Shadowsocks' in h
    and 'Не удалось остановить: Trojan' in h)
# Г3: reapply-отказ → ⚠️
shutil.rmtree(LD, ignore_errors=True)
_c3 = {'c': 0}
def _conf3():
    _c3['c'] += 1
    return ([('S65shadowsocks', 'Shadowsocks'),
             ('S22trojan', 'Trojan')]
            if _c3['c'] <= 2 else [])
g._nfqws2_conflicts = _conf3
g.set_service_enabled = lambda sn, want: False
_c3['c'] = 0
h = panel_post({'enabled': '1', 'force': '1'})
chk('z62-d3 reapply-отказ: ⚠️ в flash частичного force-сбоя',
    'выключены: Shadowsocks' in h and 'не переприменились' in h)
# Г4: успех — без ⚠️
shutil.rmtree(LD, ignore_errors=True)
_c3['c'] = 0
g.set_service_enabled = lambda sn, want: True
h = panel_post({'enabled': '1', 'force': '1'})
chk('z62-d4 успех: перечень есть, ⚠️ нет',
    'выключены: Shadowsocks, Trojan' in h
    and 'не переприменились' not in h)

# Ж: глобальный гейт
drained = 0
while g._REQ_GATE.acquire(blocking=False):
    drained += 1
chk('z62-e1 гейт занимает все 8 слотов', drained == 8, drained)
_t0 = time.time()
r = c.get('/kz-gate-probe', headers=AUTH)
chk('z62-e2 насыщение → 503 busy JSON + no-store (быстро)',
    r.status_code == 503
    and (r.get_json() or {}).get('status') == 'busy'
    and 'no-store' in r.headers.get('Cache-Control', '')
    and time.time() - _t0 < 2.5)
g._REQ_GATE.release()
r = c.get('/kz-gate-probe', headers=AUTH)
chk('z62-e3 свободный слот → запрос проходит гейт (404 маршрута)',
    r.status_code == 404, r.status_code)
for _ in range(drained - 1):
    g._REQ_GATE.release()
bal = 0
while g._REQ_GATE.acquire(blocking=False):
    bal += 1
for _ in range(bal):
    g._REQ_GATE.release()
chk('z62-e4 семафор сбалансирован', bal == 8, bal)

# Б: рендер + JS-баланс + маркеры
def render_check(url, marks):
    r = c.get(url, headers=AUTH)
    if r.status_code != 200:
        return False, 'HTTP %s' % r.status_code
    h = r.get_data(True)
    blocks = re.findall(r'<script[^>]*>(.*?)</script>', h, re.S)
    balok = all(b.count('{') == b.count('}')
                and b.count('(') == b.count(')')
                for b in blocks if b.strip())
    return balok and all(m in h for m in marks), None
okd, err = render_check('/', ["j.status==='busy'",
                              'проверка занята, повтор',
                              "d.status==='busy'"])
chk('z62-f1 дашборд: рендер, JS сбалансирован, busy-обработка',
    okd, err)
okd, err = render_check('/panel?tab=dns',
                        ['_dnsBusyTries', 'fetchDns()},3000)',
                         '— проверка занята'])
chk('z62-f2 DNS-вкладка: рендер, JS сбалансирован, ретрай+ошибка',
    okd, err)
print('OK z62-panel' if not fails else
      'BAD z62-panel: ' + '; '.join(fails))
PYPANEL
grep -q '^OK z62-panel' "$F/z62panel.out" \
    && ok "Z62-10: поведение Г — панель: частичный force-stop (исключение/живой остаток) → flash перечисляет остановленных; reapply-отказ → ⚠️; успех — без ⚠️" \
    && ok "Z62-11: поведение Ж — гейт: 8 слотов → 503 busy (JSON, no-store, <2 с); свободный слот → запрос проходит (404 маршрута); семафор сбалансирован" \
    && ok "Z62-12: поведение Б — дашборд и DNS-вкладка рендерятся, JS сбалансирован (скобки), маркеры busy-обработки/автоповтора в рендере" \
    || bad "Z62-10/11/12: $(tail -3 "$F/z62panel.out")"
else
    ok "Z62-10..12: поведение Г/Ж/Б — SKIP (flask не установлен; статика Z62-2/4/6 проверена)"
fi


echo "═══ Z63. r95: аудит r94 — пакеты А-Е ═══"

# Статика: А — идентичность lock + recovery-гейт с токеном.
Z63A1=$(grep -c '_TOGGLE_LOCK_IDENT' "$K/opt/etc/bot/utils.py" || true)
Z63A2=$(grep -c 'def _owner_raw_in' "$K/opt/etc/bot/utils.py" || true)
Z63A3=$(grep -c "_TOGGLE_RECOVERY_DIR, 'gate'" "$K/opt/etc/bot/utils.py" || true)
Z63A4=$(grep -c '_gate = _recovery_gate_acquire()' "$K/opt/etc/bot/utils.py" || true)
Z63A5=$(grep -c '(_st.st_dev, _st.st_ino) == ident' "$K/opt/etc/bot/utils.py" || true)
Z63A6=$(grep -c 'mtime_ns' "$K/opt/etc/bot/utils.py" || true)
[ "$Z63A1" -ge 6 ] && [ "$Z63A2" = 1 ] && [ "$Z63A3" -ge 2 ] && [ "$Z63A4" = 1 ] && [ "$Z63A5" = 1 ] && [ "$Z63A6" -ge 3 ] \
    && ok "Z63-1: А — lock-идентичность (st_dev, st_ino): EIO-release удаляет только СВОЙ каталог (штатно переклеймленный чужой уцелевает); recovery-гейт с токеном (gate-файл PID+token; r96: токен per-acquire, глобал убран): release снимает только свой гейт (rename+rmtree), чужой — нет; пост-проверка перенесённого — полный owner + mtime_ns; гейт держится до публикации owner (r94: EIO-release вычищал чужой lock, гейт без токена снимался чужим release)" \
    || bad "Z63-1: ident=$Z63A1 rawin=$Z63A2 gate=$Z63A3 tok=$Z63A4 stcmp=$Z63A5 mns=$Z63A6"

# Статика: Б — подтверждённо-остановленные + финальный reapply.
Z63B1=$(grep -c '_alive_t' "$K/opt/etc/bot/generator.py" || true)
Z63B2=$(grep -c '_conf_t' "$K/opt/etc/bot/generator.py" || true)
Z63B3=$(grep -c 'if _ra_ok is False:' "$K/opt/etc/bot/generator.py" || true)
[ "$Z63B1" -ge 3 ] && [ "$Z63B2" -ge 3 ] && [ "$Z63B3" = 1 ] \
    && ok "Z63-2: Б — force-цикл: в «выключены» только подтверждённо остановленные (_alive_t/_conf_t-фильтр — живой остаток не числится выключенным); финальное ⚠️ определяется ФИНАЛЬНЫМ результатом reapply (if _ra_ok is False), промежуточный _ra_bad не залипает после успешного финала (r94: живой конфликт попадал в «выключены», sticky-⚠️ при успешном финальном запуске)" \
    || bad "Z63-2: alive=$Z63B1 conf=$Z63B2 ra=$Z63B3"

# Статика: В — валидность updates.
Z63V1=$(grep -c '_upd_ok = isinstance(_upd, list)' "$K/opt/etc/bot/handlers.py" || true)
Z63V2=$(grep -c 'len(_filtered) != len(_upd)' "$K/opt/etc/bot/handlers.py" || true)
[ "$Z63V1" = 1 ] && [ "$Z63V2" = 1 ] \
    && ok "Z63-3: В — updates: отсутствующий/не-список/с отброшенными записями → «Проверка не завершена»; «✅ Всё актуально» только при валидном пустом списке (r94: молчаливая нормализация к [] давала ложное «актуально»)" \
    || bad "Z63-3: ok=$Z63V1 filt=$Z63V2"

# Статика: Г — _read_proto_update.
Z63G1=$(grep -c "'running', 'done', 'error', 'idle'" "$K/opt/etc/bot/generator.py" || true)
Z63G2=$(grep -c '_tsf != _tsf' "$K/opt/etc/bot/generator.py" || true)
Z63G3=$(grep -c "_tsf == float('inf')" "$K/opt/etc/bot/generator.py" || true)
Z63G4=$(grep -c 'Файл статуса повреждён (не объект)' "$K/opt/etc/bot/generator.py" || true)
[ "$Z63G1" = 1 ] && [ "$Z63G2" = 1 ] && [ "$Z63G3" = 1 ] && [ "$Z63G4" = 1 ] \
    && ok "Z63-4: Г — _read_proto_update: корень только dict (иначе error-объект без обрыва); статус из whitelist running/done/error/idle; ts конечный не-bool (строка/NaN/±Inf → 0 → running-таймаут работает; r96: формы _tsf + верхняя граница будущего) (r94: AttributeError → HTTP 500, вечный running при NaN)" \
    || bad "Z63-4: wl=$Z63G1 nan=$Z63G2 inf=$Z63G3 root=$Z63G4"

# Статика: Д — Retry-After + JS busy-гарды.
Z63D1=$(grep -c "('Retry-After', '1')" "$K/opt/etc/bot/generator.py" || true)
Z63D2=$(grep -c "_r.headers\['Retry-After'\] = '1'" "$K/opt/etc/bot/generator.py" || true)
Z63D3=$(grep -c 'ждём статус обновления' "$K/opt/etc/bot/generator.py" || true)
Z63D4=$(grep -c 'ввод сохранён' "$K/opt/etc/bot/generator.py" || true)
Z63D5=$(grep -c "st.status==='busy'" "$K/opt/etc/bot/generator.py" || true)
[ "$Z63D1" = 1 ] && [ "$Z63D2" = 1 ] && [ "$Z63D3" = 1 ] && [ "$Z63D4" = 1 ] && [ "$Z63D5" = 1 ] \
    && ok "Z63-5: Д — busy-503 с Retry-After: 1 в WSGI-гейте и DNS-маршруте (честный повтор клиента); JS: updPoll «⏳ Панель занята — ждём статус…» с живым таймером, pollUpdate прямой fetch + busy-гард (без jget), startUpdate wait — busy продолжает ожидание, addToList «ввод сохранён» (r94: поллеры без гардов рендерили пустоту и теряли ввод)" \
    || bad "Z63-5: gate=$Z63D1 dns=$Z63D2 upd=$Z63D3 add=$Z63D4 wait=$Z63D5"

# Статика: Е — claim-id.
Z63E1=$(grep -c '_claim_id = _sec.token_hex(8)' "$K/opt/etc/bot/generator.py" || true)
Z63E2=$(grep -c 'def _kz_proto_publish_error(action, message, claim=None)' "$K/opt/etc/bot/generator.py" || true)
Z63E3=$(grep -c 'claim=_claim_id' "$K/opt/etc/bot/generator.py" || true)
Z63E4=$(grep -c "_cur.get('claim') == _claim_id" "$K/opt/etc/bot/generator.py" || true)
[ "$Z63E1" = 1 ] && [ "$Z63E2" = 1 ] && [ "$Z63E3" = 2 ] && [ "$Z63E4" = 1 ] \
    && ok "Z63-6: Е — claim-id (secrets.token_hex(8)) в running-публикации; _kz_proto_publish_error(action, message, claim=…) не перезаписывает чужой свежий running (claim не совпал → пропуск); unlink-ветка сверяет claim (r94: publish-error затирал чужой running, unlink снимал чужой клейм)" \
    || bad "Z63-6: id=$Z63E1 sig=$Z63E2 calls=$Z63E3 unlink=$Z63E4"

# ── поведение А/Г/Е — фикстура-копия z62 (utils+generator, flask) ──
if python3 -c 'import flask' >/dev/null 2>&1; then
python3 - > "$F/z63py.out" 2>&1 <<'PYZ63A'
import sys, os, time, json, shutil, subprocess, builtins, glob, logging
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)

# ═══ А: lock ═══
import utils as u
LD = u._TOGGLE_LOCKDIR
def _clean():
    for _p in glob.glob(LD + '*'):
        shutil.rmtree(_p, ignore_errors=True)
        try:
            os.unlink(_p)
        except OSError:
            pass
_clean()
assert u.acquire_toggle_lock() is True
os.rename(LD, LD + '.old'); os.mkdir(LD)
open(LD + '/owner', 'w').write('%d bbccdd00' % (os.getpid() + 1))
_ro = builtins.open
def boom(path, *a, **k):
    if str(path) == os.path.join(LD, 'owner'):
        raise OSError(5, 'Input/output error')
    return _ro(path, *a, **k)
builtins.open = boom
u.release_toggle_lock()
builtins.open = _ro
chk('z63-a1 EIO-release не удаляет переклеймленный чужой lock',
    os.path.exists(LD))
_clean()
assert u.acquire_toggle_lock() is True
builtins.open = boom
u.release_toggle_lock()
builtins.open = _ro
chk('z63-a2 EIO-release удаляет СВОЙ lock', not os.path.exists(LD))
_d = subprocess.Popen(['true']); _d.wait()
os.mkdir(LD); open(LD + '/owner', 'w').write('%d dead' % _d.pid)
_gt = u._recovery_gate_acquire()
assert _gt
_foreign = u._TOGGLE_RECOVERY_DIR
os.rename(_foreign, _foreign + '.f')
os.mkdir(_foreign)
open(_foreign + '/gate', 'w').write('%d foreigntok' % os.getpid())
u._recovery_gate_release(_gt)
chk('z63-a3 чужой recovery-гейт не снимается нашим release',
    os.path.exists(_foreign))
shutil.rmtree(_foreign, ignore_errors=True)
shutil.rmtree(_foreign + '.f', ignore_errors=True)
_gt2 = u._recovery_gate_acquire()
assert _gt2
u._recovery_gate_release(_gt2)
chk('z63-a4 свой гейт снимается (token сверяется)',
    not os.path.exists(_foreign))
_clean()
assert u.acquire_toggle_lock() is True
u.release_toggle_lock()
chk('z63-a5 реклейм+release — чисто', not os.path.exists(LD))
_d2 = subprocess.Popen(['true']); _d2.wait()
os.mkdir(LD); open(LD + '/owner', 'w').write('%d first' % _d2.pid)
_orig_raw = u._owner_raw_in
def swap_raw(dirpath):
    r = _orig_raw(dirpath)
    if dirpath == LD and r == '%d first' % _d2.pid:
        open(LD + '/owner', 'w').write('%d second' % os.getpid())
    return r
u._owner_raw_in = swap_raw
r = u.acquire_toggle_lock()
u._owner_raw_in = _orig_raw
chk('z63-a6 пост-проверка: подменённый owner → отказ', r is False)
_clean()

# ═══ Г: _read_proto_update ═══
import generator as g
g.PROTO_UPD_STATUS = Z + '/z63_proto.json'
for label, body, expect in (
    ('корень [1]', '[1]', 'error'),
    ('корень "bad"', '"bad"', 'error'),
    ('ts-строка', '{"status":"running","ts":"bad"}', 'error'),
    ('ts=NaN', '{"status":"running","ts":NaN}', 'error'),
    ('контроль running', json.dumps(
        {'status': 'running', 'ts': int(time.time()),
         'action': 'xray', 'claim': 'ab'}), 'running')):
    open(g.PROTO_UPD_STATUS, 'w').write(body)
    try:
        d = g._read_proto_update()
        chk('z63-г[%s] → %s без обрыва' % (label, expect),
            isinstance(d, dict) and d.get('status') == expect,
            str(d)[:80])
    except Exception as e:
        chk('z63-г[%s] → %s без обрыва' % (label, expect), False,
            '%s: %s' % (type(e).__name__, str(e)[:60]))
os.path.exists(g.PROTO_UPD_STATUS) and os.unlink(g.PROTO_UPD_STATUS)

# ═══ Е: claim-id ═══
import bot_config as cfg
st = g.PROTO_UPD_STATUS
fake = Z + '/z63_fake_upd.sh'
open(fake, 'w').write('#!/bin/sh\nexit 0\n')
os.chmod(fake, 0o755)
cfg.paths['update_protocols'] = fake
open(st, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()),
     'action': 'hysteria', 'claim': 'other', 'message': 'x'}))
res = g._kz_proto_publish_error('xray', 'Запуск не удался: boom',
                                claim='ours')
cur = json.load(open(st))
chk('z63-е1 чужой свежий running не перезаписан (skip → True)',
    res is True and cur.get('claim') == 'other'
    and cur.get('action') == 'hysteria')
open(st, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()),
     'action': 'xray', 'claim': 'ours', 'message': 'x'}))
res = g._kz_proto_publish_error('xray', 'Запуск не удался: boom',
                                claim='ours')
cur = json.load(open(st))
chk('z63-е2 свой running перезаписан error',
    res is True and cur.get('status') == 'error')
open(st, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()) - 10**6,
     'action': 'hysteria', 'claim': 'other', 'message': 'x'}))
res = g._kz_proto_publish_error('xray', 'boom', claim='ours')
cur = json.load(open(st))
chk('z63-е3 протухший чужой running перезаписан',
    res is True and cur.get('status') == 'error')
def _popen_fail(*a, **k):
    raise OSError('boom')
g.subprocess.Popen = _popen_fail
_orig_perr = g._kz_proto_publish_error
g._kz_proto_publish_error = lambda a, m, claim=None: False
os.path.exists(st) and os.unlink(st)
try:
    g.start_proto_update('xray')
    raised = False
except OSError:
    raised = True
chk('z63-е4 свой клейм снят при неудачной публикации', raised
    and not os.path.exists(st))
def _popen_foreign(*a, **k):
    with open(st, 'w') as f:
        json.dump({'status': 'running', 'ts': int(time.time()),
                   'action': 'xray', 'claim': 'other',
                   'message': 'x'}, f)
    raise OSError('boom')
g.subprocess.Popen = _popen_foreign
os.path.exists(st) and os.unlink(st)
try:
    g.start_proto_update('xray')
    raised = False
except OSError:
    raised = True
cur = json.load(open(st)) if os.path.exists(st) else {}
chk('z63-е5 подменённый клейм (тот же action+ts, чужой claim) не снят',
    raised and cur.get('claim') == 'other')
g.subprocess.Popen = subprocess.Popen
g._kz_proto_publish_error = _orig_perr
os.path.exists(st) and os.unlink(st)
print('OK z63-py' if not fails else
      'BAD z63-py: ' + '; '.join(fails))
PYZ63A
grep -q '^OK z63-py' "$F/z63py.out" \
    && ok "Z63-7: поведение А/Г/Е — EIO-release щадит чужой/удаляет свой; гейт снимается только свой; пост-проверка owner; _read_proto_update: [1]/\"bad\"/ts-строка/NaN → безопасный error (таймаут работает); publish-error не трогает чужой свежий running (свой/протухший — перезаписывает); unlink только свой claim, подменённый (тот же action+ts, чужой claim) — не снимается" \
    || bad "Z63-7: $(tail -3 "$F/z63py.out" | tr '\n' ' ')"
else
    ok "Z63-7: поведение А/Г/Е — SKIP (flask не установлен; статика Z63-1/4/6 проверена)"
fi

# ── поведение В — матрица updates (telebot, фикстура z62) ──
if python3 -c 'import telebot' >/dev/null 2>&1; then
python3 - > "$F/z63bot.out" 2>&1 <<'PYZ63B'
import sys, os, time, json, logging
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond):
    print(('OK ' if cond else 'BAD ') + name)
    if not cond:
        fails.append(name)
import telebot
from telebot import types
import bot_config as cfg
cfg.allowed_user_ids = [42]
tb = telebot.TeleBot('1:test', threaded=False)
import handlers
handlers.setup_handlers(tb)
SENT = []
class M: message_id = 1
tb.send_message = lambda cid, text, **kw: (SENT.append(text), M())[1]
tb.answer_callback_query = lambda *a, **k: None
user = types.User(id=42, is_bot=False, first_name='T')
chat = types.Chat(id=42, type='private')
mk = lambda t: types.Message(
    1, user, int(time.time()), chat, 'text', {'text': t}, '')
sf = cfg.paths['updates_status']
def probe(label, body, expect_actu):
    open(sf, 'w').write(body)
    SENT.clear()
    tb.process_new_messages([mk('🆕 Обновления')])
    j = SENT[-1]
    chk('z63-в[%s]: «актуально»=%s' % (label, expect_actu),
        len(SENT) >= 2
        and ('Всё актуально' in j) == expect_actu
        and ('Проверка не завершена' in j) == (not expect_actu))
probe('updates отсутствует', json.dumps(
    {'ts': int(time.time()), 'versions': {'x': '1'},
     'check_failed': False}), False)
probe('updates — строка', json.dumps(
    {'ts': int(time.time()), 'versions': {'x': '1'},
     'updates': 'junk', 'check_failed': False}), False)
probe('updates — битая запись', json.dumps(
    {'ts': int(time.time()), 'versions': {'x': '1'},
     'updates': [{'name': 'x'}], 'check_failed': False}), False)
probe('контроль: updates=[]', json.dumps(
    {'ts': int(time.time()), 'versions': {'x': '1'},
     'updates': [], 'check_failed': False}), True)
os.path.exists(sf) and os.unlink(sf)
print('OK z63-bot' if not fails else
      'BAD z63-bot: ' + '; '.join(fails))
PYZ63B
grep -q '^OK z63-bot' "$F/z63bot.out" \
    && ok "Z63-8: поведение В — updates отсутствует/строка/битая запись → «Проверка не завершена» (НЕ «Всё актуально»); валидный пустой список → «✅ Всё актуально» (r94-дефект ложного «актуально» закрыт)" \
    || bad "Z63-8: $(tail -3 "$F/z63bot.out" | tr '\n' ' ')"
else
    ok "Z63-8: поведение В — SKIP (telebot не установлен; статика Z63-3 проверена)"
fi

# ── поведение Б/Д — панель (flask, фикстура z62) ──
if python3 -c 'import flask' >/dev/null 2>&1; then
python3 - > "$F/z63panel.out" 2>&1 <<'PYZ63P'
import sys, os, time, re, json, shutil, base64, logging
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)
FIX = Z + '/root/etc/init.d/'
import generator as g
import utils as u
g._nfqws2_installed = lambda: True
g.SERVICE_SCRIPTS = {
    'shadowsocks': FIX + 'S65shadowsocks', 'trojan': FIX + 'S22trojan',
    'vless': FIX + 'S24xray', 'tor': FIX + 'S35tor',
    'hysteria': FIX + 'S57hysteria', 'nfqws2': FIX + 'S90nfqws2'}
AUTH = {'Authorization': 'Basic ' + base64.b64encode(
    b'admin:testpass').decode()}
g.config.web_username = 'admin'
g.config.web_password = 'testpass'
c = g.app.test_client()
LD = u._TOGGLE_LOCKDIR
def panel_post(data):
    cc = g.app.test_client()
    d = cc.get('/panel?tab=dns', headers=AUTH).get_data(True)
    m = (re.search(r'name="kz-csrf" content="([^"]+)"', d)
         or re.search(r'name="csrf_token"[^>]*value="([^"]+)"', d))
    dd = dict(data); dd['csrf_token'] = m.group(1)
    return cc.post('/toggle/za', data=dd, headers=dict(
        AUTH, Origin='http://127.0.0.1:8080'),
        follow_redirects=True).get_data(True)
g._nfqws2_status = lambda: {'conflicts_required': True}
g._nfqws2_intelliqos_suspected = lambda: False
# Б1: живой остаток исключается из «выключены»
shutil.rmtree(LD, ignore_errors=True)
_cn = {'c': 0}
def _conf():
    _cn['c'] += 1
    if _cn['c'] <= 2:
        return [('S65shadowsocks', 'Shadowsocks'),
                ('S22trojan', 'Trojan')]
    return [('S22trojan', 'Trojan')]
g._nfqws2_conflicts = _conf
g.set_service_enabled = lambda sn, want: True
h = panel_post({'enabled': '1', 'force': '1'})
chk('z63-б1 живой остаток НЕ в «выключены»',
    'выключены: Shadowsocks' in h
    and 'выключены: Shadowsocks, Trojan' not in h)
# Б2: успешный финальный reapply снимает промежуточное ⚠️
shutil.rmtree(LD, ignore_errors=True)
_cn['c'] = 0
def _conf2():
    _cn['c'] += 1
    return ([('S65shadowsocks', 'Shadowsocks'),
             ('S22trojan', 'Trojan')]
            if _cn['c'] <= 2 else [])
g._nfqws2_conflicts = _conf2
def _sse(sn, want):
    if sn == 'S65shadowsocks':
        return False
    return True
g.set_service_enabled = _sse
h = panel_post({'enabled': '1', 'force': '1'})
chk('z63-б2 sticky-⚠️ снят успешным финальным reapply',
    'nfqws2 включён' in h and 'не переприменились' not in h)
# Б3: финальный отказ reapply — ⚠️ остаётся
shutil.rmtree(LD, ignore_errors=True)
_cn['c'] = 0
g.set_service_enabled = lambda sn, want: False
h = panel_post({'enabled': '1', 'force': '1'})
chk('z63-б3 финальный отказ reapply → ⚠️ в успехе',
    'nfqws2 включён' in h and 'не переприменились' in h)
# Д1: WSGI-гейт busy — Retry-After
drained = 0
while g._REQ_GATE.acquire(blocking=False):
    drained += 1
r = c.get('/api/dashboard', headers=AUTH)
chk('z63-д1 busy-503 гейта: Retry-After=1', r.status_code == 503
    and r.headers.get('Retry-After') == '1'
    and (r.get_json() or {}).get('status') == 'busy')
for _ in range(drained):
    g._REQ_GATE.release()
# Д2: DNS busy — Retry-After
g._DNS_STATUS_CACHE['ts'] = 0.0
g._DNS_STATUS_CACHE['data'] = None
while g._DNS_HEAVY_SEM.acquire(blocking=False):
    pass
r = c.get('/api/dns-status', headers=AUTH)
chk('z63-д2 busy-503 DNS: Retry-After=1', r.status_code == 503
    and r.headers.get('Retry-After') == '1')
while True:
    try:
        g._DNS_HEAVY_SEM.release()
    except ValueError:
        break
def render_check(url, marks):
    r = c.get(url, headers=AUTH)
    if r.status_code != 200:
        return False, 'HTTP %s' % r.status_code
    h = r.get_data(True)
    blocks = re.findall(r'<script[^>]*>(.*?)</script>', h, re.S)
    bal = all(b.count('{') == b.count('}')
              and b.count('(') == b.count(')')
              for b in blocks if b.strip())
    return bal and all(m in h for m in marks), None
okd, err = render_check('/', ["st.status==='busy'"])
chk('z63-д4 дашборд: рендер + JS-баланс + busy-ждущий wait', okd, err)
okd, err = render_check('/panel?tab=dns',
                        ['ждём статус обновления',
                         'ввод сохранён', "d.status==='busy'"])
chk('z63-д5 панель: рендер + JS-баланс + busy-маркеры', okd, err)
print('OK z63-panel' if not fails else
      'BAD z63-panel: ' + '; '.join(fails))
PYZ63P
grep -q '^OK z63-panel' "$F/z63panel.out" \
    && ok "Z63-9: поведение Б/Д — force-«выключены» только подтверждённо остановленные; успешный финальный reapply без ⚠️, финальный отказ — с ⚠️; busy-503 (гейт и DNS) отдаёт Retry-After: 1; дашборд/панель рендерятся, JS сбалансирован, busy-маркеры на месте" \
    || bad "Z63-9: $(tail -3 "$F/z63panel.out" | tr '\n' ' ')"
else
    ok "Z63-9: поведение Б/Д — SKIP (flask не установлен; статика Z63-2/5 проверена)"
fi


echo "═══ Z64. r96: аудит r95 — пакеты А-Д + В-2 ═══"

# Статика: А — per-acquire токен гейта, единый снимок, rename-first.
Z64A1=$(grep -c 'def _owner_pid_of_raw' "$K/opt/etc/bot/utils.py" || true)
Z64A2=$(grep -c '_gate = _recovery_gate_acquire()' "$K/opt/etc/bot/utils.py" || true)
Z64A3=$(grep -c '_recovery_gate_release(_gate)' "$K/opt/etc/bot/utils.py" || true)
Z64A4=$(grep -c '_gpid is not None and _pid_alive(_gpid)' "$K/opt/etc/bot/utils.py" || true)
Z64A5=$(grep -c '_rmdir_lockdir_best_effort(ident=ident)' "$K/opt/etc/bot/utils.py" || true)
Z64A6=$(grep -c '_rmdir_lockdir_best_effort(token=token)' "$K/opt/etc/bot/utils.py" || true)
Z64A7=$(grep -c '_owner_pid_of_raw(_own_before)' "$K/opt/etc/bot/utils.py" || true)
[ "$Z64A1" = 1 ] && [ "$Z64A2" = 1 ] && [ "$Z64A3" = 1 ] && [ "$Z64A4" = 1 ] && [ "$Z64A5" = 1 ] && [ "$Z64A6" = 1 ] && [ "$Z64A7" = 1 ] \
    && ok "Z64-1: А — гейт-токен per-acquire (acquire возвращает, release принимает; глобал процесса убран — release зависшего не сверяет токен конкурента); отбор протухшего гейта только у мёртвого PID; liveness и цель реклейма — ОДИН снимок owner; снятие гейта и lockdir — rename-first со сверкой владельца у переименованного (TOCTOU-окна read→rename и stat→rename закрыты, чужое возвращается на место); провал записи gate убирает свой каталог (r95: двойной acquire, отбор у живого, TOCTOU, 15-с «пустой» гейт)" \
    || bad "Z64-1: raw=$Z64A1 gate=$Z64A2 rel=$Z64A3 live=$Z64A4 id=$Z64A5 tok=$Z64A6 snap=$Z64A7"

# Статика: Б+В — ts-границы и claim.
Z64B1=$(grep -c '_tsf > time.time() + 60.0' "$K/opt/etc/bot/generator.py" || true)
Z64B2=$(grep -c 'except (TypeError, ValueError, OverflowError)' "$K/opt/etc/bot/generator.py" || true)
Z64B3=$(grep -c -- '-60.0 <= _age <= PROTO_UPD_TIMEOUT' "$K/opt/etc/bot/generator.py" || true)
Z64B4=$(grep -c 'claim is None' "$K/opt/etc/bot/generator.py" || true)
[ "$Z64B1" = 1 ] && [ "$Z64B2" = 3 ] && [ "$Z64B3" = 1 ] && [ "$Z64B4" = 1 ] \
    && ok "Z64-2: Б+В — ts: float-конверсия под защитой (10**400 → без OverflowError/HTTP 500), конечность, верхняя граница «будущее +60 c» → 0 (вечный running и блокировка старта закрыты); publish_error: двусторонняя рамка свежести (будущее — не свежий) + claim=None — нет доказательства владения, ЛЮБОЙ свежий running не перезаписывается (r95: HTTP 500 на гигантском int, вечный running по будущему ts, затирание running без claim; ovf=3 с r97 — третий OverflowError-guard в повторной проверке старта под guard)" \
    || bad "Z64-2: fut=$Z64B1 ovf=$Z64B2 win=$Z64B3 cn=$Z64B4"

# Статика: В-2 — claim в child-обёртке.
Z64C1=$(grep -c 'KZ_CLAIM' "$K/opt/etc/bot/generator.py" || true)
[ "$Z64C1" = 2 ] \
    && ok "Z64-3: В-2 — KZ_CLAIM в окружении child-обёртки; финализатор сверяет claim в текущем статусе перед mv: «долгоигравший» child (старше таймаута 900 c) не затирает running нового прогона своим устаревшим «done» (r95: безусловный mv)" \
    || bad "Z64-3: claim=$Z64C1"

# Статика: Г — check_failed строго bool.
Z64G1=$(grep -c '_cf is not False' "$K/opt/etc/bot/handlers.py" || true)
Z64G2=$(grep -c 'неполный статус' "$K/opt/etc/bot/handlers.py" || true)
[ "$Z64G1" = 1 ] && [ "$Z64G2" = 1 ] \
    && ok "Z64-4: Г — «✅ Всё актуально» только при check_failed is False: отсутствующее/не-bool (старая схема, повреждение, 0/1) — честное «проверка не завершена (неполный статус)» (r95: truthiness-проверка давала ложное «актуально» по неполной проверке)" \
    || bad "Z64-4: cf=$Z64G1 msg=$Z64G2"

# Статика: Д — busy-остатки JS.
Z64D1=$(grep -c 'if(!_poll)_poll=setInterval(pollUpdate,2000)' "$K/opt/etc/bot/generator.py" || true)
Z64D2=$(grep -c "res.j.status==='busy'" "$K/opt/etc/bot/generator.py" || true)
Z64D3=$(grep -c "j.status==='busy'" "$K/opt/etc/bot/generator.py" || true)
Z64D4=$(grep -c 'setTimeout(fetchVer,2000)' "$K/opt/etc/bot/generator.py" || true)
Z64D5=$(grep -c 'панель занята — повторите позже' "$K/opt/etc/bot/generator.py" || true)
[ "$Z64D1" = 2 ] && [ "$Z64D2" = 1 ] && [ "$Z64D3" = 4 ] && [ "$Z64D4" = 1 ] && [ "$Z64D5" = 2 ] \
    && ok "Z64-5: Д — pollUpdate: первый busy тоже ставит retry-интервал (единственный вход — загрузка страницы); runUpd/chkRun: явные busy-ветки до error-веток («⏳ Панель занята», кнопки разблокируются); fetchVer: прямой fetch вместо jget, busy → один автоповтор 2 с, затем честная индикация вместо вечного «checking» (r95: четыре потребителя без busy-обработки)" \
    || bad "Z64-5: poll=$Z64D1 run=$Z64D2 chk=$Z64D3 fv=$Z64D4 msg=$Z64D5"

# ── поведение А/Б/В — фикстура-копия z62 (utils+generator, flask) ──
if python3 -c 'import flask' >/dev/null 2>&1; then
python3 - > "$F/z64py.out" 2>&1 <<'PYZ64A'
import sys, os, time, json, re, shutil, logging, base64
import subprocess, threading, importlib.util
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)


def load(name):
    spec = importlib.util.spec_from_file_location(
        name, Z + '/bot/utils.py')
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


u = load('z64u')
GD = u._TOGGLE_RECOVERY_DIR
LD = u._TOGGLE_LOCKDIR


def _clean():
    for _p in os.listdir('/tmp'):
        if _p.startswith('keenzoo_toggle.lockdir'):
            shutil.rmtree('/tmp/' + _p, ignore_errors=True)


# А: гейт
_clean()
tokA = u._recovery_gate_acquire()
chk('z64-a1 acquire возвращает токен per-acquire',
    isinstance(tokA, str) and tokA.split()[0] == str(os.getpid()))
os.utime(GD, (0, 0))
chk('z64-a2 протухший гейт НЕ отбирается у живого владельца',
    u._recovery_gate_acquire() is False and os.path.exists(GD))
u._recovery_gate_release('чужой-токен')
chk('z64-a3 release с чужим токеном: гейт цел',
    os.path.exists(GD))
u._recovery_gate_release(tokA)
chk('z64-a4 release со своим токеном: гейт снят',
    not os.path.exists(GD))
# TOCTOU gate-release: подмена между rename и чтением
tokA = u._recovery_gate_acquire()
_osren = os.rename


def _swap5(src, dst):
    if src == GD:
        _osren(GD, GD + '.f5')
        os.mkdir(GD)
        with open(GD + '/gate', 'w') as f:
            f.write('%d foreigntok' % os.getpid())
    return _osren(src, dst)


os.rename = _swap5
u._recovery_gate_release(tokA)
os.rename = _osren
_gtok = ''
try:
    with open(GD + '/gate') as f:
        _gtok = f.read().strip()
except OSError:
    pass
chk('z64-a5 TOCTOU release: подменённый чужой гейт восстановлен',
    _gtok == '%d foreigntok' % os.getpid())
shutil.rmtree(GD + '.f5', ignore_errors=True)
_clean()
# провал записи gate
_ro = builtins_open = open
import builtins


def _boom_gate(path, *a, **k):
    if str(path) == os.path.join(GD, 'gate'):
        raise OSError(5, 'Input/output error')
    return builtins_open(path, *a, **k)


builtins.open = _boom_gate
_r = u._recovery_gate_acquire()
builtins.open = builtins_open
chk('z64-a6 провал записи gate → False, каталог убран',
    _r is False and not os.path.exists(GD))
_t2 = u._recovery_gate_acquire()
chk('z64-a6b немедленный повтор успешен', bool(_t2))
u._recovery_gate_release(_t2)
# lock: живой/мёртвый владелец
_clean()
os.mkdir(LD)
with open(LD + '/owner', 'w') as f:
    f.write('%d livetok' % os.getpid())
chk('z64-a7 живой владелец lock → acquire False',
    u.acquire_toggle_lock() is False)
_clean()
_d = subprocess.Popen(['true'])
_d.wait()
os.mkdir(LD)
with open(LD + '/owner', 'w') as f:
    f.write('%d deadtok' % _d.pid)
chk('z64-a8 мёртвый владелец → acquire True',
    u.acquire_toggle_lock() is True)
u.release_toggle_lock()
chk('z64-a8b release чист', not os.path.exists(LD))
# EIO-release TOCTOU: подмена в окне — чужой восстановлен
_clean()
assert u.acquire_toggle_lock() is True
_orig_open = builtins.open


def _eio_owner(path, *a, **k):
    if str(path) == os.path.join(LD, 'owner'):
        raise OSError(5, 'Input/output error')
    return _orig_open(path, *a, **k)


def _swap9(src, dst):
    if src == LD and '.rel.' in str(dst):
        _osren(LD, LD + '.f9')
        os.mkdir(LD)
        _fd = os.open(LD + '/owner',
                      os.O_WRONLY | os.O_CREAT | os.O_TRUNC)
        os.write(_fd, ('%d foreigntok'
                       % os.getpid()).encode())
        os.close(_fd)
    return _osren(src, dst)


builtins.open = _eio_owner
os.rename = _swap9
u.release_toggle_lock()
os.rename = _osren
builtins.open = _orig_open
_own = ''
try:
    with open(LD + '/owner') as f:
        _own = f.read().strip()
except OSError:
    pass
chk('z64-a9 EIO-release: подменённый чужой lockdir восстановлен',
    _own == '%d foreigntok' % os.getpid())
shutil.rmtree(LD + '.f9', ignore_errors=True)
# хореография двойного захвата (аудит r95) — ровно один победитель
_clean()
uA, uB, uC = load('z64a'), load('z64b'), load('z64c')
os.mkdir(uA._TOGGLE_LOCKDIR)
with open(uA._TOGGLE_LOCKDIR + '/owner', 'w') as f:
    f.write('%d deadbeef' % _d.pid)
ev_A_ren = threading.Event()
ev_A_go = threading.Event()


class OsProxy:
    def __init__(self, real):
        self._r = real

    def __getattr__(self, n):
        if n == 'rename':
            def _ren(src, dst):
                if src == uA._TOGGLE_RECOVERY_DIR:
                    ev_A_ren.set()
                    ev_A_go.wait()
                return self._r.rename(src, dst)
            return _ren
        return getattr(self._r, n)


uA.os = OsProxy(os)
_tA = threading.Thread(target=lambda: uA._recovery_gate_release(
    uA._recovery_gate_acquire()))
_tA.start()
_deadline = time.time() + 5
while not ev_A_ren.is_set() and time.time() < _deadline:
    try:
        os.utime(uA._TOGGLE_RECOVERY_DIR, (0, 0))
    except OSError:
        pass
    time.sleep(0.02)
resB, resC = {}, {}


def _run_b():
    try:
        resB['r'] = uB.acquire_toggle_lock()
    except Exception as e:  # noqa: BLE001
        resB['r'] = 'exc:%r' % e


def _run_c():
    try:
        resC['r'] = uC.acquire_toggle_lock()
    except Exception as e:  # noqa: BLE001
        resC['r'] = 'exc:%r' % e


_tB = threading.Thread(target=_run_b)
_tB.start()
_tB.join(10)
ev_A_go.set()
_tA.join(5)
_tC = threading.Thread(target=_run_c)
_tC.start()
_tC.join(10)
_trues = [r for r in (resB.get('r'), resC.get('r')) if r is True]
chk('z64-a10 хореография аудита: РОВНО ОДИН победитель '
    '(B=%s C=%s)' % (resB.get('r'), resC.get('r')),
    len(_trues) == 1 and resC.get('r') is True
    and resB.get('r') is False)
_clean()

# Б: ts-границы
import generator as g
g.PROTO_UPD_STATUS = Z + '/z64_proto.json'
open(g.PROTO_UPD_STATUS, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()) + 86400,
     'action': 'xray', 'claim': 'ab', 'message': 'x'}))
d = g._read_proto_update()
chk('z64-б1 будущий ts → error «Таймаут», ts=0',
    d.get('status') == 'error' and d.get('ts') == 0)
open(g.PROTO_UPD_STATUS, 'w').write(
    '{"status":"running","ts":' + '1' + '0' * 400 + '}')
try:
    d = g._read_proto_update()
    chk('z64-б2 ts=10**400 → безопасный объект', isinstance(d, dict))
except OverflowError as e:
    chk('z64-б2 ts=10**400 → безопасный объект', False, repr(e))
import bot_config as cfg
g.config.web_username = 'admin'
g.config.web_password = 'testpass'
AUTH = {'Authorization': 'Basic ' + base64.b64encode(
    b'admin:testpass').decode()}
c = g.app.test_client()
r = c.get('/api/proto-update-status', headers=AUTH)
chk('z64-б3 API при ts=10**400 → HTTP 200', r.status_code == 200)

# В: claim
open(g.PROTO_UPD_STATUS, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()),
     'action': 'xray', 'message': 'без claim'}))
res = g._kz_proto_publish_error('xray', 'boom')
cur = json.load(open(g.PROTO_UPD_STATUS))
chk('z64-в1 claim=None не затирает свежий running без claim',
    res is True and cur.get('status') == 'running')
open(g.PROTO_UPD_STATUS, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()),
     'action': 'xray', 'claim': 'ours', 'message': 'x'}))
res = g._kz_proto_publish_error('xray', 'boom', claim='ours')
cur = json.load(open(g.PROTO_UPD_STATUS))
chk('z64-в2 свой claim перезаписывается error',
    res is True and cur.get('status') == 'error')
open(g.PROTO_UPD_STATUS, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()) + 86400,
     'action': 'xray', 'claim': 'other', 'message': 'x'}))
res = g._kz_proto_publish_error('xray', 'boom', claim='ours')
cur = json.load(open(g.PROTO_UPD_STATUS))
chk('z64-в3 будущий running заменяется error (рамка свежести)',
    res is True and cur.get('status') == 'error')
os.path.exists(g.PROTO_UPD_STATUS) and os.unlink(
    g.PROTO_UPD_STATUS)
print('OK z64-py' if not fails else
      'BAD z64-py: ' + '; '.join(fails))
PYZ64A
grep -q '^OK z64-py' "$F/z64py.out" \
    && ok "Z64-6: поведение А/Б/В — гейт: токен per-acquire, живой держатель не вытесняется, чужой гейт/lockdir при подмене восстанавливаются, провал записи gate убирает свой каталог, живой владелец → отказ, мёртвый → захват; хореография двойного захвата аудита — ровно один победитель; ts: будущий → «Таймаут» (старт не блокирован), 10**400 → HTTP 200; claim=None щадит свежий running, свой/будущий — перезаписываются" \
    || bad "Z64-6: $(tail -3 "$F/z64py.out" | tr '\n' ' ')"
else
    ok "Z64-6: поведение А/Б/В — SKIP (flask не установлен; статика Z64-1/2 проверена)"
fi

# ── поведение Г — матрица check_failed (telebot, фикстура z62) ──
if python3 -c 'import telebot' >/dev/null 2>&1; then
python3 - > "$F/z64bot.out" 2>&1 <<'PYZ64B'
import sys, os, time, json, logging
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:120]))
    if not cond:
        fails.append(name)
import telebot
from telebot import types
import bot_config as cfg
cfg.allowed_user_ids = [42]
tb = telebot.TeleBot('1:test', threaded=False)
import handlers
handlers.setup_handlers(tb)
SENT = []
class M: message_id = 1
tb.send_message = lambda cid, text, **kw: (SENT.append(text), M())[1]
tb.answer_callback_query = lambda *a, **k: None
user = types.User(id=42, is_bot=False, first_name='T')
chat = types.Chat(id=42, type='private')
mk = lambda t: types.Message(
    1, user, int(time.time()), chat, 'text', {'text': t}, '')
sf = cfg.paths['updates_status']
def probe(label, body, expect):
    open(sf, 'w').write(body)
    SENT.clear()
    tb.process_new_messages([mk('🆕 Обновления')])
    j = SENT[-1]
    got = ('актуально' if 'Всё актуально' in j
           else ('недоступна' if 'недоступна' in j
                 else 'незавершена'))
    chk('z64-г[%s] → %s' % (label, expect), got == expect,
        j.replace(chr(10), ' | ')[:90])
probe('check_failed отсутствует', json.dumps(
    {'ts': int(time.time()) + 1,
     'versions': {'xray': '1.2.3'}, 'updates': []}), 'незавершена')
probe('check_failed: 0', json.dumps(
    {'ts': int(time.time()) + 1,
     'versions': {'xray': '1.2.3'}, 'updates': [],
     'check_failed': 0}), 'незавершена')
probe('check_failed: true', json.dumps(
    {'ts': int(time.time()) + 1,
     'versions': {'xray': '1.2.3'}, 'updates': [],
     'check_failed': True}), 'недоступна')
probe('контроль: false', json.dumps(
    {'ts': int(time.time()) + 1,
     'versions': {'xray': '1.2.3'}, 'updates': [],
     'check_failed': False}), 'актуально')
os.path.exists(sf) and os.unlink(sf)
print('OK z64-bot' if not fails else
      'BAD z64-bot: ' + '; '.join(fails))
PYZ64B
grep -q '^OK z64-bot' "$F/z64bot.out" \
    && ok "Z64-7: поведение Г — check_failed отсутствует/0 → «неполный статус» (НЕ «актуально»); true → «часть источников недоступна»; false → «✅ Всё актуально» (r95-дефект ложного «актуально» по неполной проверке закрыт)" \
    || bad "Z64-7: $(tail -3 "$F/z64bot.out" | tr '\n' ' ')"
else
    ok "Z64-7: поведение Г — SKIP (telebot не установлен; статика Z64-4 проверена)"
fi

# ── поведение Д + В-2 — панель (flask) и обёртка (sh) ──
if python3 -c 'import flask' >/dev/null 2>&1; then
python3 - > "$F/z64panel.out" 2>&1 <<'PYZ64P'
import sys, os, time, re, json, shutil, base64, logging
import subprocess
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)
import generator as g
g.config.web_username = 'admin'
g.config.web_password = 'testpass'
AUTH = {'Authorization': 'Basic ' + base64.b64encode(
    b'admin:testpass').decode()}
c = g.app.test_client()
srcg = open(Z + '/bot/generator.py', encoding='utf-8').read()
# В-2: обёртка сверяет claim перед mv
_bodies = re.findall(r"body = '''(.*?)'''", srcg, re.S)
mbody = [b for b in _bodies if 'KZ_CLAIM' in b][0]
chk('z64-д1 обёртка: сверка claim до атомарной замены (r98 — хелпер)',
    mbody.index('cur.get("claim") != CL')
    < mbody.index('os.replace(TMP, ST)'))
ST = Z + '/z64w_st.json'
TMP = Z + '/z64w_tmp.json'
FAKE = Z + '/z64w_sc.sh'
open(FAKE, 'w').write('#!/bin/sh\nexit 0\n')
os.chmod(FAKE, 0o755)
env = dict(os.environ, KZ_SC=FAKE, KZ_ACT='xray', KZ_ST=ST,
           KZ_TMP=TMP, KZ_CLAIM='aa11bb22cc33dd44')
open(ST, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()),
     'action': 'xray', 'claim': 'aa11bb22cc33dd44'}))
rp = subprocess.run(['/bin/sh', '-c', mbody], env=env,
                    capture_output=True, text=True)
cur = json.load(open(ST))
chk('z64-д2 свой claim → done опубликован',
    rp.returncode == 0 and cur.get('status') == 'done')
open(ST, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()),
     'action': 'xray', 'claim': 'ffffffffeeeeeeee'}))
rp = subprocess.run(['/bin/sh', '-c', mbody], env=env,
                    capture_output=True, text=True)
cur = json.load(open(ST))
chk('z64-д3 чужой claim → running нового прогона не затёрт',
    rp.returncode == 0
    and cur.get('claim') == 'ffffffffeeeeeeee'
    and not os.path.exists(TMP))
for _f in (ST, TMP, FAKE):
    os.path.exists(_f) and os.unlink(_f)
# Д: рендеры с маркерами r96
def render_check(url, marks):
    r = c.get(url, headers=AUTH)
    if r.status_code != 200:
        return False, 'HTTP %s' % r.status_code
    h = r.get_data(True)
    blocks = re.findall(r'<script[^>]*>(.*?)</script>', h, re.S)
    bal = all(b.count('{') == b.count('}')
              and b.count('(') == b.count(')')
              for b in blocks if b.strip())
    return bal and all(m in h for m in marks), None
okd, err = render_check(
    '/panel?tab=upd',
    ['панель занята — повторите позже',
     'Панель занята — повторите через пару секунд',
     'setTimeout(fetchVer,2000)',
     'if(!_poll)_poll=setInterval(pollUpdate,2000)'])
chk('z64-д4 панель (upd): рендер + JS-баланс + маркеры r96',
    okd, err)
okd, err = render_check(
    '/panel?tab=ss',
    ['if(!_poll)_poll=setInterval(pollUpdate,2000)'])
chk('z64-д5 панель (ss): pollUpdate retry-маркер в рендере',
    okd, err)
okd, err = render_check('/', ["st.status==='busy'"])
chk('z64-д6 дашборд: рендер + JS-баланс', okd, err)
print('OK z64-panel' if not fails else
      'BAD z64-panel: ' + '; '.join(fails))
PYZ64P
grep -q '^OK z64-panel' "$F/z64panel.out" \
    && ok "Z64-8: поведение Д/В-2 — обёртка публикует финал только при совпадении claim (свой → done, чужой → running не тронут, temp убран); панель/дашборд рендерятся, JS сбалансирован, маркеры busy-остатков r96 на месте" \
    || bad "Z64-8: $(tail -3 "$F/z64panel.out" | tr '\n' ' ')"
else
    ok "Z64-8: поведение Д/В-2 — SKIP (flask не установлен; статика Z64-3/5 проверена)"
fi


# ══ Z65: r97-audit-fixes (аудит r96 — подтверждённые живьём пробы A/B) ══

# Статика: А — имена/реклейм/сериализация (utils).
Z65A1=$(grep -c 'secrets.token_hex(4)' "$K/opt/etc/bot/utils.py" || true)
Z65A2=$(grep -c 'shutil.rmtree(dead_dir' "$K/opt/etc/bot/utils.py" || true)
Z65A3=$(grep -c 'r97 (аудит r96' "$K/opt/etc/bot/utils.py" || true)
Z65A4a=$(grep -n '_gate = _recovery_gate_acquire()' "$K/opt/etc/bot/utils.py" | head -1 | cut -d: -f1)
Z65A4b=$(grep -n 'os.mkdir(_TOGGLE_LOCKDIR)' "$K/opt/etc/bot/utils.py" | head -1 | cut -d: -f1)
[ "$Z65A1" = 4 ] && [ "$Z65A2" = 2 ] && [ "$Z65A3" = 4 ] \
    && [ -n "$Z65A4a" ] && [ -n "$Z65A4b" ] && [ "$Z65A4a" -lt "$Z65A4b" ] \
    && ok "Z65-1: А (KZ96-01, оба механизма) — уникальные имена перемещений .rel/.stale/.dead (PID+random ×4: коллизия фиксированного .rel.<PID> больше не оставляет gate/lock с живым PID — deadlock переключений закрыт, включая самоотравление EIO-остатком); mismatch-ветка без rmtree чужого lock (3→2); гейт берётся ДО fast-path mkdir — все acquire сериализованы (второй победитель невозможен)" \
    || bad "Z65-1: uniq=$Z65A1 rmt=$Z65A2 mark=$Z65A3 gate=$Z65A4a mkdir=$Z65A4b"

# Статика: В — межпроцессный guard статуса (generator; r98 — flock).
Z65B1=$(grep -c "_PROTO_UPD_GUARD = PROTO_UPD_STATUS + '.lockfile'" "$K/opt/etc/bot/generator.py" || true)
Z65B2=$(grep -c 'def _kz_proto_guard_acquire():' "$K/opt/etc/bot/generator.py" || true)
Z65B3=$(grep -c 'def _kz_proto_guard_release(token=None):' "$K/opt/etc/bot/generator.py" || true)
Z65B4=$(grep -c 'def _kz_proto_guard(timeout=2.0):' "$K/opt/etc/bot/generator.py" || true)
Z65B5=$(grep -c '_g = _kz_proto_guard()' "$K/opt/etc/bot/generator.py" || true)
Z65B6=$(grep -c '_kz_proto_guard_release(_g)' "$K/opt/etc/bot/generator.py" || true)
Z65B7=$(grep -c 'fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)' "$K/opt/etc/bot/generator.py" || true)
Z65B8=$(grep -cF 'KZ_GUARD="$ST.lockfile"' "$K/opt/etc/bot/generator.py" || true)
[ "$Z65B1" = 1 ] && [ "$Z65B2" = 1 ] && [ "$Z65B3" = 1 ] && [ "$Z65B4" = 1 ] \
    && [ "$Z65B5" = 3 ] && [ "$Z65B6" = 3 ] && [ "$Z65B7" = 2 ] && [ "$Z65B8" = 1 ] \
    && ok "Z65-2: В (KZ96-02; r98 — AUD-R97-01/KZ97-01) — guard = flock(2) по СТАБИЛЬНОМУ lock-файлу (mkdir-модель и её окна mkdir→запись-owner/same-PID-реклейм удалены — взаимоисключение гарантирует ядро, авто-снятие при гибели держателя); writers под guard ×3 (publish_error, публикация running с повторной проверкой, снятие клейма); ash-финализатор — python-хелпер с тем же lock-файлом (KZ_GUARD, точная JSON-сверка claim, компактный формат статуса)" \
    || bad "Z65-2: konst=$Z65B1 acq=$Z65B2 rel=$Z65B3 spin=$Z65B4 w=$Z65B5 wr=$Z65B6 flk=$Z65B7 hlp=$Z65B8"

# Статика: Б — fetchVer (JS).
Z65C1=$(grep -c 'не удалось получить версии' "$K/opt/etc/bot/generator.py" || true)
Z65C2=$(grep -cF "n+' — занято'" "$K/opt/etc/bot/generator.py" || true)
Z65C3=$(grep -cF "n+' —')" "$K/opt/etc/bot/generator.py" || true)
[ "$Z65C1" = 1 ] && [ "$Z65C2" = 1 ] && [ "$Z65C3" = 1 ] \
    && ok "Z65-3: Б (KZ96-03) — fetchVer: честный catch (fail-ячейки + «не удалось получить версии» — зеркально fetchDns r94), busy-терминал fail + «— занято» вместо вечного «checking»/⏳" \
    || bad "Z65-3: msg=$Z65C1 busy=$Z65C2 cat=$Z65C3"

# Поведение: А — обычные пути + закрытые гонки (utils, без flask).
python3 - > "$F/z65u.out" 2>&1 <<'PYZ65U'
import sys, os, time, shutil, subprocess, importlib.util
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)

spec = importlib.util.spec_from_file_location('z65u', Z + '/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
GD = u._TOGGLE_RECOVERY_DIR
LD = u._TOGGLE_LOCKDIR

def dead_pid():
    for _ in range(50):
        p = subprocess.Popen(['true'])
        p.wait()
        try:
            os.kill(p.pid, 0)
        except ProcessLookupError:
            return p.pid
    raise RuntimeError('нет мёртвого PID')

def clean():
    for _p in os.listdir('/tmp'):
        if _p.startswith('keenzoo_toggle.lockdir'):
            shutil.rmtree('/tmp/' + _p, ignore_errors=True)

# обычные пути не сломаны r97-сериализацией
clean()
chk('z65-1 acquire под гейтом == True, повторный == False',
    u.acquire_toggle_lock() and u.acquire_toggle_lock() is False)
u.release_toggle_lock()
chk('z65-2 release: canonical чист; повторный захват',
    not os.path.exists(LD) and u.acquire_toggle_lock())
u.release_toggle_lock()
os.mkdir(LD)
open(LD + '/owner', 'w').write('%d deadown' % dead_pid())
os.utime(LD, (0, 0))
chk('z65-3 stale lock мёртвого владельца → реклейм',
    u.acquire_toggle_lock())
u.release_toggle_lock()
os.mkdir(GD)
open(GD + '/gate', 'w').write('%d deadgate' % dead_pid())
os.utime(GD, (0, 0))
tok = u._recovery_gate_acquire()
chk('z65-4 stale gate мёртвого владельца → токен', isinstance(tok, str))
u._recovery_gate_release(tok)
chk('z65-5 release гейта чист', not os.path.exists(GD))

# KZ96-01 механизм 1: мусор .rel.<PID>.* не отравляет release
os.mkdir('%s.rel.%d.leftover' % (LD, os.getpid()))
chk('z65-6 acquire при мусоре .rel.* == True', u.acquire_toggle_lock())
u.release_toggle_lock()
chk('z65-7 ФИКС deadlock: lock снят, повторный захват работает',
    not os.path.exists(LD) and u.acquire_toggle_lock())
u.release_toggle_lock()
shutil.rmtree('%s.rel.%d.leftover' % (LD, os.getpid()), ignore_errors=True)

# KZ96-01 механизм 2: двойной захват гейта закрыт пост-проверкой
clean()
os.mkdir(GD)
open(GD + '/gate', 'w').write('%d stalegate' % dead_pid())
os.utime(GD, (0, 0))
_orig_rename = os.rename
_state = {'injected': False, 'btok': None}
def _hooked(src, dst):
    if src == GD and '.stale.' in dst and not _state['injected']:
        _state['injected'] = True
        _state['btok'] = u._recovery_gate_acquire()
    return _orig_rename(src, dst)
os.rename = _hooked
tokA = u._recovery_gate_acquire()
os.rename = _orig_rename
tokB = _state['btok']
_g = open(GD + '/gate').read().strip()
chk('z65-8 ФИКС двойной захват: A отказан, B владеет, гейт B цел',
    tokA is False and isinstance(tokB, str) and _g == tokB,
    'A=%s B=%s g=%s' % (tokA, tokB, _g))
u._recovery_gate_release(tokB)
chk('z65-9 B снял гейт штатно', not os.path.exists(GD))

# KZ96-01 механизм 2: fast-path окно — второй победитель невозможен
clean()
rX = u.acquire_toggle_lock()
tokX = u._TOGGLE_LOCK_TOKEN
os.utime(LD, (0, 0))
_orig_ownraw = u._owner_raw_in
_snap = '%d staleown' % dead_pid()
def _hooked_raw(dirpath):
    if dirpath == LD:
        return _snap
    return _orig_ownraw(dirpath)
u._owner_raw_in = _hooked_raw
_state2 = {'c': 'notrun'}
def _hooked2(src, dst):
    if '.dead.' in src and dst == LD and _state2['c'] == 'notrun':
        _state2['c'] = u.acquire_toggle_lock()
    return _orig_rename(src, dst)
os.rename = _hooked2
rA = u.acquire_toggle_lock()
os.rename = _orig_rename
u._owner_raw_in = _orig_ownraw
rC = _state2['c']
_own = open(LD + '/owner').read().strip()
chk('z65-10 ФИКС два победителя: A и C отказаны, X единственный',
    rX and rA is False and rC is False and _own == tokX,
    'X=%s A=%s C=%s own=%s' % (rX, rA, rC, _own))
chk('z65-11 конкурентный acquire отклонён (владелец жив)',
    u.acquire_toggle_lock() is False)
u.release_toggle_lock()
_left = [p for p in os.listdir('/tmp')
         if p.startswith('keenzoo_toggle.lockdir')
         and ('.dead.' in p or '.rel.' in p or '.stale.' in p)]
chk('z65-12 мусорных перемещённых каталогов нет, canonical чист',
    not _left and not os.path.exists(LD), _left)
clean()
print('OK z65-u' if not fails else 'BAD z65-u: ' + '; '.join(fails))
PYZ65U
grep -q '^OK z65-u' "$F/z65u.out" \
    && ok "Z65-4: поведение А — обычные пути целы (acquire/release, stale-реклеймы lock и gate); коллизия имён не блокирует (deadlock закрыт); двойной захват гейта закрыт пост-проверкой (гейт конкурента цел, ровно один токен); fast-path сериализован гейтом (второй победитель невозможен), чужой lock не удаляется и возвращается" \
    || bad "Z65-4: $(tail -3 "$F/z65u.out" | tr '\n' ' ')"

# Поведение: В — guard статуса (python-часть; r98 — flock; нужен flask).
if python3 -c 'import flask' >/dev/null 2>&1; then
python3 - > "$F/z65g.out" 2>&1 <<'PYZ65G'
import sys, os, time, json, shutil, threading, logging, subprocess
Z = '/tmp/f47chk/z62'
sys.path.insert(0, Z + '/bot')
logging.basicConfig(level=logging.CRITICAL)
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)
import generator as g
ST = g.PROTO_UPD_STATUS
GUARD = g._PROTO_UPD_GUARD
PID = os.getpid()

def clean():
    for p in (ST, GUARD):
        try:
            os.unlink(p)
        except OSError:
            pass
        try:
            shutil.rmtree(p)
        except OSError:
            pass
    for p in os.listdir('/tmp'):
        if p.startswith('proto_update_status.json'):
            try:
                shutil.rmtree('/tmp/' + p)
            except OSError:
                try:
                    os.unlink('/tmp/' + p)
                except OSError:
                    pass

def read_st():
    try:
        with open(ST) as f:
            return json.load(f)
    except Exception:
        return None

clean()
tok = g._kz_proto_guard_acquire()
chk('z65g-1 flock acquire → fd (int)',
    isinstance(tok, int) and tok > 0, tok)
chk('z65g-2 конкурентный acquire → False (ядро)',
    g._kz_proto_guard_acquire() is False)
g._kz_proto_guard_release('чужой')
chk('z65g-3 посторонний token в release — безопасный no-op',
    g._kz_proto_guard_acquire() is False)
g._kz_proto_guard_release(tok)
tok = g._kz_proto_guard_acquire()
chk('z65g-4 после release повторный acquire OK',
    isinstance(tok, int))
g._kz_proto_guard_release(tok)
# гибель держателя → kernel снял lock сам
hp = subprocess.Popen([
    'python3', '-c',
    'import fcntl, os, time\n'
    'fd = os.open(%r, os.O_RDWR | os.O_CREAT, 0o600)\n'
    'fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)\n'
    'open(%r, "w").write("held")\n'
    'time.sleep(60)\n' % (GUARD, GUARD + '.held')],
    stdout=subprocess.DEVNULL)
for _ in range(200):
    if os.path.exists(GUARD + '.held'):
        break
    time.sleep(0.1)
chk('z65g-5-pre живой держатель: guard занят',
    g._kz_proto_guard_acquire() is False)
hp.kill()
hp.wait()
tok = g._kz_proto_guard_acquire()
chk('z65g-5 гибель держателя → авто-снятие ядром, acquire сразу',
    isinstance(tok, int))
g._kz_proto_guard_release(tok)
chk('z65g-6 guard — стабильный обычный файл',
    os.path.isfile(GUARD))
# AUD-R97-01 инверсия: гонка закрыта kernel-мьютексом
clean()
res = {}
def writer_a():
    tokA = g._kz_proto_guard()
    res['a'] = bool(tokA)
    time.sleep(0.4)
    with open(ST + '.race.tmp', 'w') as f:
        f.write(json.dumps({'status': 'running',
                            'ts': int(time.time()),
                            'action': 'all', 'claim': 'RACE'}))
    os.replace(ST + '.race.tmp', ST)
    g._kz_proto_guard_release(tokA)
ta = threading.Thread(target=writer_a)
ta.start()
time.sleep(0.1)
t0 = time.monotonic()
rb = g._kz_proto_publish_error('xray', 'опоздавшая', claim=None)
dt = time.monotonic() - t0
ta.join()
st = read_st()
chk('z65g-7 ФИКС AUD-R97-01: конкурент ждал секцию, running цел',
    res.get('a') and dt >= 0.3 and rb is True
    and st and st.get('status') == 'running'
    and st.get('claim') == 'RACE',
    'dt=%.2f rb=%s' % (dt, rb))
chk('z65g-8 guard-файл цел (не удалён/не переименован)',
    os.path.exists(GUARD))
# publish_error: обычные пути + регрессия r96
clean()
r = g._kz_proto_publish_error('xray', 'тест-r98', claim=None)
st = read_st()
chk('z65g-9 publish_error → error с сообщением',
    r is True and st and st.get('message') == 'тест-r98', st)
open(ST, 'w').write(json.dumps(
    {'status': 'running', 'ts': int(time.time()),
     'action': 'all', 'claim': 'OTHER'}))
r = g._kz_proto_publish_error('xray', 'позже', claim=None)
chk('z65g-10 свежий чужой running не затёрт (claim=None)',
    r is True and read_st().get('status') == 'running')
clean()
print('OK z65-g' if not fails else 'BAD z65-g: ' + '; '.join(fails))
PYZ65G
grep -q '^OK z65-g' "$F/z65g.out" \
    && ok "Z65-5: поведение В (python, r98 flock) — acquire/release/чужой token; гибель держателя → авто-снятие ядром; гонка AUD-R97-01 закрыта (конкурент ждал секцию, свежий running цел); publish_error обычные пути + claim=None-регрессия" \
    || bad "Z65-5: $(tail -3 "$F/z65g.out" | tr '\n' ' ')"
else
    ok "Z65-5: поведение В (python, r98 flock) — SKIP (flask не установлен; статика Z65-2 проверена)"
fi

# Поведение: В — ash-финализатор обёртки (r98: python-хелпер + flock).
if python3 - "/tmp/f47chk/z62/bot/generator.py" "$F/z65wrap.sh" <<'PYZ65X'
import re, sys
src = open(sys.argv[1], encoding='utf-8').read()
q = chr(39) * 3
b = [x for x in re.findall('body = ' + q + '(.*?)' + q, src, re.S)
     if 'KZ_CLAIM' in x][0]
open(sys.argv[2], 'w', encoding='utf-8').write(b)
PYZ65X
then
    command -v busybox >/dev/null 2>&1 && Z65SH="busybox ash" || Z65SH="sh"
    W="$F/z65w"; rm -rf "$W"; mkdir -p "$W"
    Z65SB=""
    printf '%s' '{"status":"running","ts":100,"action":"all","claim":"abc"}' > "$W/st.json"
    : > "$W/tmp.json"
    if env KZ_SC=/bin/true KZ_ACT=all KZ_ST="$W/st.json" KZ_TMP="$W/tmp.json" KZ_CLAIM=abc $Z65SH "$F/z65wrap.sh" >/dev/null 2>"$W/err1" \
        && grep -q '"status":"done"' "$W/st.json" \
        && [ ! -f "$W/tmp.json" ] && [ ! -d "$W/st.json.guard" ]; then :; else Z65SB="$Z65SB свой-claim"; fi
    printf '%s' '{"status":"running","ts":100,"action":"all","claim":"abc"}' > "$W/st.json"
    : > "$W/tmp.json"
    if env KZ_SC=/bin/true KZ_ACT=all KZ_ST="$W/st.json" KZ_TMP="$W/tmp.json" KZ_CLAIM=xyz $Z65SH "$F/z65wrap.sh" >/dev/null 2>"$W/err2" \
        && grep -q '"claim":"abc"' "$W/st.json" \
        && grep -q 'другому прогону' "$W/err2" \
        && [ ! -f "$W/tmp.json" ]; then :; else Z65SB="$Z65SB чужой-claim"; fi
    # живой держатель lock-файла → helper ждёт ~6 c → честный отказ
    printf '%s' '{"status":"running","ts":100,"action":"all","claim":"abc"}' > "$W/st.json"
    : > "$W/tmp.json"
    rm -f "$W/ready"
    python3 -c '
import fcntl, os, sys, time
fd = os.open(sys.argv[1], os.O_RDWR | os.O_CREAT, 0o600)
fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
open(sys.argv[2], "w").write("held")
time.sleep(60)
' "$W/st.json.lockfile" "$W/ready" &
    Z65H=$!
    for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
        [ -f "$W/ready" ] && break
        sleep 0.2
    done
    T0=$(date +%s)
    env KZ_SC=/bin/true KZ_ACT=all KZ_ST="$W/st.json" KZ_TMP="$W/tmp.json" KZ_CLAIM=abc $Z65SH "$F/z65wrap.sh" >/dev/null 2>"$W/err3"
    T1=$(date +%s)
    kill "$Z65H" 2>/dev/null; wait "$Z65H" 2>/dev/null
    if grep -q '"claim":"abc"' "$W/st.json" \
        && grep -q 'guard статуса занят' "$W/err3" \
        && [ "$((T1-T0))" -ge 5 ]; then :; else Z65SB="$Z65SB живой-держатель"; fi
    # гибель держателя → kernel снял lock → публикация прошла
    printf '%s' '{"status":"running","ts":100,"action":"all","claim":"abc"}' > "$W/st.json"
    : > "$W/tmp.json"
    rm -f "$W/ready"
    python3 -c '
import fcntl, os, sys, time
fd = os.open(sys.argv[1], os.O_RDWR | os.O_CREAT, 0o600)
fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
open(sys.argv[2], "w").write("held")
time.sleep(60)
' "$W/st.json.lockfile" "$W/ready" &
    Z65H=$!
    for _ in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
        [ -f "$W/ready" ] && break
        sleep 0.2
    done
    kill -9 "$Z65H" 2>/dev/null; wait "$Z65H" 2>/dev/null
    if env KZ_SC=/bin/true KZ_ACT=all KZ_ST="$W/st.json" KZ_TMP="$W/tmp.json" KZ_CLAIM=abc $Z65SH "$F/z65wrap.sh" >/dev/null 2>"$W/err4" \
        && grep -q '"status":"done"' "$W/st.json"; then :; else Z65SB="$Z65SB гибель-держателя"; fi
    if [ -f "$W/st.json.lockfile" ] && [ ! -d "$W/st.json.lockfile" ] \
        && [ ! -d "$W/st.json.guard" ]; then :; else Z65SB="$Z65SB стабильность-lock-файла"; fi
    rm -rf "$W/st.json.lockfile" 2>/dev/null
    if [ -z "$Z65SB" ]; then
        ok "Z65-6: поведение В (ash-финализатор, $Z65SH + python-хелпер r98) — свой claim → done (компактный JSON, temp убран, guard-каталогов нет); чужой → running не тронут, честный отказ; живой держатель lock-файла → хелпер ждал ~6 c и отказал честно; гибель держателя → kernel снял lock, финал опубликован; lock-файл стабилен"
    else
        bad "Z65-6:$Z65SB"
    fi
else
    bad "Z65-6: body обёртки не извлечён"
fi

# ══ Z66: r98-audit-fixes (аудит r97 — flock-сериализация) ══

# Статика: kernel-мьютексы r98 (utils + generator).
Z66A1=$(grep -c "_TOGGLE_KFLOCK = '/tmp/keenzoo_toggle.lockfile'" "$K/opt/etc/bot/utils.py" || true)
Z66A2=$(grep -c 'def _kflock_acquire(path, timeout=5.0):' "$K/opt/etc/bot/utils.py" || true)
Z66A3=$(grep -c 'def _kflock_release(fd):' "$K/opt/etc/bot/utils.py" || true)
Z66A4=$(grep -c 'def _acquire_toggle_lock_under_kflock():' "$K/opt/etc/bot/utils.py" || true)
Z66A5=$(grep -c 'def _release_toggle_lock_under_kflock():' "$K/opt/etc/bot/utils.py" || true)
Z66A6=$(grep -c '_kflock_acquire(_TOGGLE_KFLOCK)' "$K/opt/etc/bot/utils.py" || true)
Z66A7=$(grep -c '_kflock_release(_kfd)' "$K/opt/etc/bot/utils.py" || true)
Z66A8=$(grep -c 'import fcntl' "$K/opt/etc/bot/utils.py" || true)
Z66A9=$(grep -c 'import fcntl' "$K/opt/etc/bot/generator.py" || true)
Z66A10=$(grep -c 'r98 (аудит r97' "$K/opt/etc/bot/utils.py" || true)
Z66A11=$(grep -c 'r98 (аудит r97' "$K/opt/etc/bot/generator.py" || true)
[ "$Z66A1" = 1 ] && [ "$Z66A2" = 1 ] && [ "$Z66A3" = 1 ] && [ "$Z66A4" = 1 ] \
    && [ "$Z66A5" = 1 ] && [ "$Z66A6" = 2 ] && [ "$Z66A7" = 2 ] \
    && [ "$Z66A8" = 2 ] && [ "$Z66A9" = 2 ] \
    && [ "$Z66A10" = 2 ] && [ "$Z66A11" = 3 ] \
    && ok "Z66-1: r98 — toggle acquire/release целиком под flock(2) СТАБИЛЬНОГО lock-файла (dir-протокол r93–r97 сохранён как defense-in-depth: внутренние фазы _under_kflock; AUD-R97-02 окна закрыты ядром); fcntl-импорты ×2+×2; маркеры r98: utils ×2, generator ×3" \
    || bad "Z66-1: kf=$Z66A1 acq=$Z66A2 rel=$Z66A3 ia=$Z66A4 ir=$Z66A5 wa=$Z66A6 wr=$Z66A7 fu=$Z66A8 fg=$Z66A9 mu=$Z66A10 mg=$Z66A11"

# Поведение: toggle под flock — обычные пути + инверсия F2.
python3 - > "$F/z66u.out" 2>&1 <<'PYZ66U'
import sys, os, time, shutil, threading, subprocess, tempfile
import importlib.util
Z = '/tmp/f47chk/z62'
os.environ['PATH'] = Z + '/root/bin:' + os.environ['PATH']
sys.path.insert(0, Z + '/bot')
fails = []
def chk(name, cond, extra=''):
    print(('OK ' if cond else 'BAD ') + name
          + ('' if cond else ' :: ' + str(extra)[:150]))
    if not cond:
        fails.append(name)

spec = importlib.util.spec_from_file_location('z66u', Z + '/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
LD = u._TOGGLE_LOCKDIR
KF = u._TOGGLE_KFLOCK
PID = os.getpid()

def dead_pid():
    for _ in range(50):
        p = subprocess.Popen(['true'])
        p.wait()
        try:
            os.kill(p.pid, 0)
        except ProcessLookupError:
            return p.pid
    raise RuntimeError('нет мёртвого PID')

def clean():
    # kflock-файл и маркер держателя удаляются явно: префикс
    # 'keenzoo_toggle.lockdir' их не покрывает, а остаточный маркер
    # из прошлого прогона ломал ожидание старта держателя (z66-8-pre)
    for _p in (KF, KF + '.held'):
        try:
            os.unlink(_p)
        except OSError:
            pass
    for p in os.listdir('/tmp'):
        if p.startswith('keenzoo_toggle.lockdir'):
            shutil.rmtree('/tmp/' + p, ignore_errors=True)

clean()
chk('z66-1 acquire == True, повторный == False',
    u.acquire_toggle_lock() and u.acquire_toggle_lock() is False)
u.release_toggle_lock()
chk('z66-2 release: canonical чист, повторный захват',
    not os.path.exists(LD) and u.acquire_toggle_lock())
u.release_toggle_lock()
os.mkdir(LD)
open(LD + '/owner', 'w').write('%d deadown' % dead_pid())
os.utime(LD, (0, 0))
chk('z66-3 stale lock мёртвого владельца → реклейм',
    u.acquire_toggle_lock())
u.release_toggle_lock()

# инверсия F2: X «замерз» между mkdir(lockdir) и owner; конкурент C
# заходит параллельным потоком — под flock C получает честный отказ
_res = {'c': 'notrun'}
def _competitor():
    _res['c'] = u.acquire_toggle_lock()
_orig_mkstemp = tempfile.mkstemp
_injected = [False]
def _hooked(*a, **kw):
    if kw.get('dir') == LD and not _injected[0]:
        _injected[0] = True
        tc = threading.Thread(target=_competitor)
        tc.start()
        time.sleep(0.3)
        tc.join(timeout=10)
    return _orig_mkstemp(*a, **kw)
tempfile.mkstemp = _hooked
rX = u.acquire_toggle_lock()
tempfile.mkstemp = _orig_mkstemp
rC = _res['c']
chk('z66-4 X завершил acquire: True', rX is True, rX)
chk('z66-5 ФИКС AUD-R97-02: C из окна паузы — честный отказ, '
    'второго True нет', rC is False, rC)
_own = open(LD + '/owner').read().strip()
chk('z66-6 canonical owner — токен X (не перезаписан)',
    _own.split()[0] == str(PID), _own)
u.release_toggle_lock()
chk('z66-7 release штатен, canonical чист', not os.path.exists(LD))

# kflock: гибель держателя → авто-снятие ядром
try:
    os.unlink(KF)
except OSError:
    pass
hp = subprocess.Popen([
    'python3', '-c',
    'import fcntl, os, time\n'
    'fd = os.open(%r, os.O_RDWR | os.O_CREAT, 0o600)\n'
    'fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)\n'
    'open(%r, "w").write("held")\n'
    'time.sleep(60)\n' % (KF, KF + '.held')],
    stdout=subprocess.DEVNULL)
for _ in range(200):
    if os.path.exists(KF + '.held'):
        break
    time.sleep(0.1)
t0 = time.monotonic()
r = u.acquire_toggle_lock()
dt = time.monotonic() - t0
chk('z66-8-pre живой держатель kflock: acquire отказ за таймаут '
    '(не мгновенно — спин)', r is False and dt >= 4.0,
    'dt=%.1f' % dt)
if r is True:
    # самовосстановление: держатель не успел подняться (холодный
    # старт под нагрузкой) и захват неожиданно прошёл — снимаем,
    # чтобы z66-8 проверял реальную гибель держателя
    u.release_toggle_lock()
hp.kill()
hp.wait()
r = u.acquire_toggle_lock()
chk('z66-8 гибель держателя kflock → kernel снял, захват сразу',
    r is True)
u.release_toggle_lock()
chk('z66-9 kflock — стабильный обычный файл', os.path.isfile(KF))
clean()
print('OK z66-u' if not fails else 'BAD z66-u: ' + '; '.join(fails))
PYZ66U
grep -q '^OK z66-u' "$F/z66u.out" \
    && ok "Z66-2: поведение r98 (toggle под flock) — обычные пути и stale-реклейм целы; ИНВЕРСИЯ AUD-R97-02: конкурент в окне паузы X — честный отказ, ровно один True, owner не перезаписан; kflock: живой держатель → таймаут-отказ, гибель → авто-снятие ядром; lock-файл стабилен" \
    || bad "Z66-2: $(tail -3 "$F/z66u.out" | tr '\n' ' ')"

echo "═══ F47 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
