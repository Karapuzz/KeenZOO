#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
/opt/etc/bot/generator.py
"""

import os
import sys
import json
import ipaddress
import logging
import shutil
import shlex
import subprocess
import signal
import time
import hashlib
import hmac
import html
import re
from urllib.parse import urlparse

from flask import (
    Flask, render_template_string,
    request, flash, redirect,
    url_for, abort, session, jsonify, Response,
)

sys.path.insert(0, '/opt/etc/bot')
try:
    import bot_config as config
except Exception as _cfg_err:
    # bot_config.py общий для панели и бота. При ошибке импорта оставляем
    # только минимальную диагностическую страницу, но не раскрываем через
    # HTTP текст исключения, исходную строку или traceback: в этой строке
    # могут находиться Telegram-токен и пароль панели.
    try:
        import traceback as _em_traceback
        _em_tb = _em_traceback.format_exc()
    except Exception:  # аварийная ветка сама падать не должна
        _em_tb = ''

    _em_kind = type(_cfg_err).__name__
    _em_line = getattr(_cfg_err, 'lineno', None)
    if not isinstance(_em_line, int) or _em_line <= 0:
        # Для исключения времени исполнения SyntaxError.lineno нет. Берём
        # только номер кадра bot_config.py, не читая исходную строку.
        _em_line = None
        _em_cursor = getattr(_cfg_err, '__traceback__', None)
        while _em_cursor is not None:
            try:
                if os.path.basename(
                        _em_cursor.tb_frame.f_code.co_filename) == \
                        'bot_config.py':
                    _em_line = int(_em_cursor.tb_lineno)
            except Exception:
                pass
            _em_cursor = _em_cursor.tb_next

    _em_public = _em_kind
    if _em_line is not None:
        _em_public += ', строка %d' % _em_line

    # Полный traceback нужен администратору, но содержит потенциальные
    # секреты. Пишем его отдельно и принудительно с правами root-only.
    # Env-путь оставлен для изолированного стенда; init-скрипт его не задаёт.
    _em_log_path = os.environ.get(
        'KEENZOO_EMERGENCY_LOG',
        '/opt/etc/bot/generator-emergency.log')
    _em_log_ok = False
    _em_fd = None
    try:
        _em_flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
        if hasattr(os, 'O_NOFOLLOW'):
            _em_flags |= os.O_NOFOLLOW
        _em_fd = os.open(_em_log_path, _em_flags, 0o600)
        os.fchmod(_em_fd, 0o600)
        with os.fdopen(
                _em_fd, 'w', encoding='utf-8', errors='replace') as _em_f:
            _em_fd = None
            _em_f.write(
                '%s\nОшибка импорта bot_config.py: %s\n\n%s' % (
                    time.strftime('%Y-%m-%d %H:%M:%S'),
                    _em_public,
                    _em_tb or '(traceback недоступен)\n'))
        _em_log_ok = True
    except Exception as _em_log_err:
        if _em_fd is not None:
            try:
                os.close(_em_fd)
            except Exception:
                pass
        # Не выводим str(_em_log_err): путь/текст системной ошибки тоже не
        # нужен HTTP-клиенту и может содержать лишние данные.
        sys.stderr.write(
            '[!] Не удалось создать закрытый аварийный журнал: %s\n'
            % type(_em_log_err).__name__)

    sys.stderr.write(
        '\n[!] Ошибка в /opt/etc/bot/bot_config.py: %s\n'
        '    Аварийный HTTP-режим доступен только через loopback.\n'
        % _em_public)
    if _em_log_ok:
        sys.stderr.write(
            '    Подробный диагноз: %s (режим 0600).\n\n'
            % _em_log_path)
    else:
        sys.stderr.write(
            '    Подробный диагноз записать не удалось.\n\n')
    sys.stderr.flush()

    # Обычный порт берётся из generator_settings сломанного сейчас
    # конфига, поэтому аварийный порт — из окружения или штатный 8080.
    try:
        _em_port = int(os.environ.get('KEENZOO_PANEL_PORT') or 8080)
    except (TypeError, ValueError):
        _em_port = 8080

    _em_app = Flask(__name__)
    _em_title = html.escape(_em_public)
    _em_log_hint = (
        'Полный диагноз записан в <code>%s</code> с режимом '
        '<code>0600</code>.' % html.escape(_em_log_path)
        if _em_log_ok else
        'Закрытый диагностический журнал создать не удалось.')

    @_em_app.route('/', defaults={'_em_path': ''})
    @_em_app.route('/<path:_em_path>')
    def _emergency_page(_em_path):
        _em_body = (
            "<!doctype html><html lang=ru><meta charset=utf-8>"
            "<title>KeenZOO: ошибка bot_config.py</title>"
            "<body style='font:14px/1.5 monospace;background:#1b1b1b;"
            "color:#eee;padding:24px;max-width:900px;margin:auto'>"
            "<h2 style='color:#ff7b72'>&#9888; Панель в аварийном режиме</h2>"
            "<p>Файл <b>/opt/etc/bot/bot_config.py</b> не читается &#8212; "
            "этот модуль общий для панели и бота, поэтому оба не работают, "
            "пока ошибка не исправлена.</p>"
            "<pre style='background:#000;padding:12px;color:#ffa657'>"
            + _em_title +
            "</pre><p>Исходная строка и traceback намеренно скрыты. "
            + _em_log_hint +
            "</p>"
            "<h3>Как исправить</h3>"
            "<pre style='background:#000;padding:12px;color:#8ddb8c'>"
            "ssh root@&lt;роутер&gt;\n"
            "vi /opt/etc/bot/bot_config.py   # правим указанную строку\n"
            "cd /opt/etc/bot &amp;&amp; python3 -c 'import bot_config'\n"
            "/opt/etc/init.d/S99generator restart\n"
            "/opt/etc/init.d/S99telegram_bot restart\n"
            "</pre>"
            "<p>Аварийная страница слушает только "
            "<code>127.0.0.1:%d</code>. Для просмотра с компьютера "
            "используйте SSH-туннель:</p>"
            "<pre style='background:#000;padding:12px;color:#8ddb8c'>"
            "ssh -L 18080:127.0.0.1:%d -p 222 root@&lt;роутер&gt;\n"
            "# затем откройте http://127.0.0.1:18080/"
            "</pre>"
            "<p style='color:#9c9c9c'>Либо вернуть конфиг из бэкапа: "
            "<code>sh /opt/bin/deploy_bypass.sh -restore</code> "
            "(восстановит и остальные файлы проекта).</p>"
            % (_em_port, _em_port))
        return Response(_em_body, 503, mimetype='text/html')

    try:
        # Auth-настройки лежат в сломанном bot_config и недоступны. Поэтому
        # fail-closed: никакого LAN/WAN listener, только SSH-защищённый
        # loopback. Обычная панель ниже по файлу сохраняет 0.0.0.0 + два
        # штатных рубежа (setup_firewall и security_checks).
        _em_app.run(host='127.0.0.1', port=_em_port,
                    threaded=True, use_reloader=False)
    except OSError as _em_bind_err:
        sys.stderr.write(
            '[!] Аварийная страница не заняла loopback-порт %s: %s\n'
            % (_em_port, type(_em_bind_err).__name__))
        sys.stderr.flush()
    raise SystemExit(0)

from utils import (
    shadowsocks_config,
    trojan_config,
    vless_config,
    tor_config,
    hysteria_config,
    apply_direct_config,
    log_error,
)

# Журналирование: в лог попадают ТОЛЬКО ошибки. По умолчанию werkzeug
# пишет строку на КАЖДЫЙ HTTP-запрос, и generator.log неограниченно рос
# на накопителе с Entware. Оставляем уровень ERROR.
logging.basicConfig(level=logging.ERROR)
logging.getLogger('werkzeug').setLevel(logging.ERROR)

app = Flask(__name__)

# ── Единый источник настроек: bot_config.generator_settings ──────────────
# Раньше панель дублировала пути и порты собственными константами, из-за
# чего значения расходились с bot_config.py и shell-скриптами (характерный
# пример — lock_dir). Теперь всё читается из одного места.
_GS = getattr(config, 'generator_settings', {})

SECRET_FILE = _GS.get(
    'secret_file', '/opt/etc/bot/.secret_key')


def _load_or_create_secret():
    """
    Постоянный ключ подписи сессии. Хранится в файле, иначе при каждом
    перезапуске панели сессии (а с ними и CSRF-токены) обнулялись бы.
    Ошибки файловой системы не должны валить панель на старте: в худшем
    случае откатываемся на эфемерный ключ и пишем об этом в лог.
    """
    try:
        if os.path.exists(SECRET_FILE):
            with open(SECRET_FILE, 'r') as f:
                key = f.read().strip()
            if len(key) >= 32:
                return key

        os.makedirs(
            os.path.dirname(SECRET_FILE) or '.',
            exist_ok=True)

        key = hashlib.sha256(os.urandom(64)).hexdigest()
        # Права выставляются в момент создания, до записи содержимого.
        fd = os.open(
            SECRET_FILE,
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, 'w') as f:
            f.write(key)
        return key
    except OSError as err:
        sys.stderr.write(
            f"[!] Не удалось сохранить {SECRET_FILE}: {err}. "
            "Сессии будут сбрасываться при перезапуске панели.\n")
        return hashlib.sha256(os.urandom(64)).hexdigest()


app.secret_key = _load_or_create_secret()
app.jinja_env.autoescape = True


def generate_csrf():
    """
    CSRF-токен хранится в серверной сессии и переиспользуется в течение
    всей сессии. Ключ подписи сессии сохраняется в SECRET_FILE и не
    меняется при перезапуске панели, поэтому токен остаётся стабильным
    между открытиями страниц, а не генерируется каждый раз заново.
    """
    token = session.get('csrf_token')

    if isinstance(token, str) and len(token) >= 32:
        return token

    token = hmac.new(
        app.secret_key.encode(),
        os.urandom(32),
        hashlib.sha256).hexdigest()

    session['csrf_token'] = token
    session.permanent = True
    session.modified = True
    return token


def validate_csrf(token):
    expected = session.get(
        'csrf_token', '')
    if (not expected
            or not isinstance(token, str)):
        return False
    return hmac.compare_digest(
        token, expected)


LAN_IP = _GS.get('listen_ip', getattr(config, 'routerip', '192.168.1.1'))
LISTEN_PORT = int(_GS.get('listen_port', 8080))
MAX_CONTENT_LENGTH = 1 * 1024 * 1024
UNBLOCK_TIMEOUT = int(_GS.get('unblock_timeout', 300))

# Панель обслуживает только внутренние сети. Публичные адреса и любые
# внешние подключения отклоняются до аутентификации.
# Учёт неудачных входов: {ip: (число_неудач, заблокирован_до)}.
# Хранится в памяти процесса — перезапуск панели сбрасывает счётчики,
# что приемлемо: панель доступна только из LAN.
_auth_fails = {}
_AUTH_MAX_FAILS = 5
_AUTH_BLOCK_SEC = 300

ALLOWED_SUBNETS = [
    ipaddress.ip_network('127.0.0.0/8'),
    ipaddress.ip_network('192.168.0.0/16'),
    ipaddress.ip_network('10.0.0.0/8'),
    ipaddress.ip_network('172.16.0.0/12'),
]

GENERATOR_LOG = _GS.get(
    'log_file', '/opt/etc/bot/generator.log')
LOCK_DIR = _GS.get(
    'lock_dir', '/tmp/unblock_update.lockdir')
UPDATE_STATUS_FILE = _GS.get(
    'status_file', '/tmp/unblock_update_status.json')
UPDATE_LOG_FILE = _GS.get(
    'update_log', '/tmp/unblock_update.log')
WRAPPER_SCRIPT = (
    '/tmp/unblock_update_wrapper.sh')

# ── Обновление протоколов из веб-панели ──────────────────────────────
# Отдельные файлы состояния: обновление протоколов и пересборка списков
# запускаются независимо и не должны затирать статус друг друга.
PROTO_UPD_STATUS = (
    '/tmp/proto_update_status.json')
PROTO_UPD_LOG = (
    '/tmp/proto_update.log')
PROTO_UPD_WRAPPER = (
    '/tmp/proto_update_wrapper.sh')
# Обновление всех компонентов может занимать минуты; после этого срока
# зависший запуск считается мёртвым и разрешается новый.
PROTO_UPD_TIMEOUT = 900

DNS_PORTS_DOT = list(
    getattr(config, 'dnsovertls_ports',
            [40500, 40501, 40502, 40503]))
DNS_PORTS_DOH = list(
    getattr(config, 'dnsoverhttps_ports',
            [40508, 40509, 40510, 40511]))
# Не использовать torproject.org как health-check: домен может быть
# заблокирован в России. Контрольная зона должна быть DNSSEC-подписанной,
# стабильной и не относиться к спискам обхода.
DNS_HEALTH_DOMAIN = str(getattr(
    config, 'dns_health_domain', 'example.com'))

SERVICE_SCRIPTS = {
    'shadowsocks': config.paths['init_shadowsocks'],
    'trojan': config.paths['init_trojan'],
    'vless': config.paths['init_xray'],
    'tor': config.paths['init_tor'],
    'hysteria': config.paths['init_hysteria'],
}

BYPASS_IPSETS = dict(config.ipset_names)


# ── Логика списков вынесена в lists_core (C9, ревью 2026-10-12) ──────
# Здесь и ниже имена ре-экспортируются, чтобы сохранить прежние точки
# обращения панели. Реализация — одна, и бот подтягивает именно её.
from lists_core import (  # noqa: F401
    UNBLOCK_DIR, BYPASS_FILES, BOT_BYPASS_FILE,
    MAX_LIST_LINES, read_file_text,
    _clean_entry, _validate_cidr, _validate_ip,
    _validate_entry, _atomic_write_text, _read_blocks,
    _all_bypass_filepaths, _build_global_bypass_index,
    _optimize_networks, _sort_key, parse_and_save)



def rotate_log():
    if not os.path.exists(GENERATOR_LOG):
        return
    try:
        if os.path.getsize(
                GENERATOR_LOG) > 524288:
            with open(GENERATOR_LOG, 'r',
                      encoding='utf-8') as f:
                lines = f.readlines()
            with open(GENERATOR_LOG, 'w',
                      encoding='utf-8') as f:
                f.writelines(lines[-50:])
    except OSError as e:
        # Ротация лога — штатная фоновая операция; сбой не критичен,
        # но молча глотать ошибку ФС нельзя.
        logging.error('log rotate %s: %s', GENERATOR_LOG, e)


def web_log(message):
    """Запись в журнал панели (раньше функция была пустой заглушкой)."""
    try:
        rotate_log()
        with open(GENERATOR_LOG, 'a', encoding='utf-8') as f:
            f.write(
                f"{time.strftime('%Y-%m-%d %H:%M:%S')}"
                f" - {message}\n")
    except OSError:
        pass


def _is_local_ip(ip_str):
    try:
        addr = ipaddress.ip_address(ip_str)
    except ValueError:
        return False
    return any(
        addr in s for s in ALLOWED_SUBNETS)


def _client_ip():
    """
    Реальный адрес клиента. Заголовки X-Forwarded-For / X-Real-IP
    сознательно игнорируются: панель не работает за доверенным обратным
    прокси, а эти заголовки подделываются клиентом и позволяли бы обойти
    ограничение «только LAN».
    """
    return request.remote_addr or ''


def _is_local_request():
    ip_str = _client_ip()
    if not _is_local_ip(ip_str):
        return False

    # Решение принимается по адресу КЛИЕНТА (проверен выше): он не
    # подделывается, так как берётся из TCP-соединения.
    # Заголовок Host дополнительно НЕ ограничивается: у роутера несколько
    # внутренних адресов (гостевая сеть, отдельный бридж 5 ГГц, VPN
    # прошивки), а клиенты обращаются и по имени my.keenetic.net —
    # прежняя проверка отклоняла такие запросы с 403.
    return True


@app.before_request
def security_checks():
    # 1. Только внутренние сети.
    if not _is_local_request():
        log_error(
            f"[w] отклонён внешний запрос от {_client_ip()}")
        return ('⛔ Доступ разрешён только из локальной сети.', 403)

    # 2. Обязательная аутентификация. Пустой пароль в bot_config.py
    #    означает «панель не настроена» — доступ закрыт полностью,
    #    вместо прежнего поведения с открытым входом.
    web_user = str(getattr(config, 'web_username', '') or '')
    web_pass = str(getattr(config, 'web_password', '') or '')

    if not web_user or not web_pass:
        return (
            '⛔ Веб-панель не настроена: задайте web_username и '
            'web_password в /opt/etc/bot/bot_config.py',
            503)

    auth = request.authorization
    client = _client_ip()

    # Защита от подбора пароля. Панель доступна только из LAN, но
    # заражённое устройство внутри сети могло перебирать пароль без
    # ограничений. Счётчик неудач ведётся по адресу клиента в памяти
    # процесса; после _AUTH_MAX_FAILS попыток адрес блокируется на
    # _AUTH_BLOCK_SEC секунд. Успешный вход счётчик сбрасывает.
    now = time.time()
    fails, blocked_until = _auth_fails.get(client, (0, 0.0))

    # Сравнение строго в БАЙТАХ. hmac.compare_digest на str падает с
    # TypeError, если хоть один символ вне ASCII: пароль с кириллицей
    # ронял КАЖДЫЙ запрос к панели в 500, включая /api/dns-status.
    def _cmp(a, b):
        try:
            return hmac.compare_digest(
                str(a or '').encode('utf-8'),
                str(b or '').encode('utf-8'))
        except (UnicodeError, TypeError):
            return False

    ok = bool(
        auth
        and _cmp(auth.username, web_user)
        and _cmp(auth.password, web_pass))

    # ВАЖНО: блокировка применяется только к НЕВЕРНЫМ попыткам.
    # Если отвергать и правильный пароль, администратор запирает сам
    # себя, а злоумышленник из LAN легко устраивает отказ в
    # обслуживании, просто перебирая пароль с чужого адреса.
    if ok:
        if client in _auth_fails:
            del _auth_fails[client]
    else:
        if blocked_until > now:
            # Пауза уже идёт: не наращиваем счётчик, просто отказываем.
            return Response(
                'Too many failed attempts',
                429,
                {'Retry-After':
                 str(int(blocked_until - now)),
                 'WWW-Authenticate':
                 'Basic realm="Keenetic bypass panel"'})

        fails += 1
        if fails >= _AUTH_MAX_FAILS:
            _auth_fails[client] = (
                0, now + _AUTH_BLOCK_SEC)
            log_error(
                f'[w] {_AUTH_MAX_FAILS} неудачных входов '
                f'с {client} — пауза {_AUTH_BLOCK_SEC}с')
        else:
            _auth_fails[client] = (fails, 0.0)

        # Задержка замедляет автоматический перебор.
        time.sleep(0.5)
        return Response(
            'Authentication required',
            401,
            {'WWW-Authenticate':
             'Basic realm="Keenetic bypass panel"'})

    # 3. Защита от CSRF на уровне источника запроса.
    if request.method == 'POST':
        allowed_hosts = {
            f'{LAN_IP}:{LISTEN_PORT}',
            f'localhost:{LISTEN_PORT}',
            f'127.0.0.1:{LISTEN_PORT}',
            str(request.host),
        }

        def _same_origin(value):
            if not value:
                return False
            try:
                parsed = urlparse(value)
            except Exception:
                return False
            return (
                parsed.scheme in ('http', 'https')
                and parsed.netloc in allowed_hosts
            )

        origin = request.headers.get('Origin', '')
        referer = request.headers.get('Referer', '')

        if origin:
            if not _same_origin(origin):
                return ('⛔ CSRF.', 403)
        elif referer:
            if not _same_origin(referer):
                return ('⛔ CSRF.', 403)
        else:
            return ('⛔ CSRF.', 403)


def _iptables_bin():
    """
    Пакет Entware "iptables" кладёт /opt/sbin/iptables без расширений
    TPROXY/socket/set и перекрывает прошивочный бинарник в PATH.
    Для правил панели нужен рабочий iptables, поэтому выбираем явно.
    """
    # На Keenetic прошивочный iptables лежит НЕ в /usr/sbin: этого пути
    # там нет вовсе. Реально встречаются /opt/sbin (Entware) и внутренние
    # пути прошивки, поэтому список кандидатов расширен, а в конце —
    # поиск через PATH.
    # 100-redirect.sh пишет результат capability-проверенного выбора
    # (M6): кэш точнее перебора путей по «файл существует».
    try:
        with open('/tmp/keenzoo_iptables_bin', encoding='utf-8') as f:
            cached = f.read().strip()
        if cached and os.access(cached, os.X_OK):
            return cached
    except OSError:
        pass

    for cand in ('/usr/sbin/iptables', '/sbin/iptables',
                 '/bin/iptables', '/usr/bin/iptables',
                 '/opt/sbin/iptables', '/opt/bin/iptables'):
        if os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    found = shutil.which('iptables')
    if found:
        return found
    return 'iptables'


IPTABLES = _iptables_bin()


def _ipt(*args):
    """Вызов iptables с ограничением по времени.

    -w заставляет iptables ждать освобождения xtables-блокировки:
    без ограничения параллельный вызов из ndm-хука мог подвесить
    поток панели навсегда. Истёкшее ожидание возвращается как обычная
    неудача (returncode 1), иначе TimeoutExpired обрушил бы запуск
    панели, которая вызывает setup_firewall при старте.
    """
    try:
        return subprocess.run(
            [IPTABLES, '-w'] + list(args),
            capture_output=True, text=True,
            timeout=15)
    except subprocess.TimeoutExpired:
        log_error(
            '[!] iptables не ответил за 15 с: '
            + ' '.join(str(a) for a in args))
        return subprocess.CompletedProcess(
            args=args, returncode=1, stdout='', stderr='timeout')
    except OSError as err:
        # Бинарника может не оказаться в PATH в момент загрузки роутера
        # (USB монтируется с задержкой, PATH у init-скриптов урезан):
        # необработанный FileNotFoundError из subprocess ронял старт
        # панели до поднятия Flask. Несколько невыполненных правил —
        # деградация ACL, но не смерть сервиса.
        log_error('[!] iptables недоступен (%s): %s'
                  % (type(err).__name__, err))
        return subprocess.CompletedProcess(
            args=args, returncode=1, stdout='', stderr=str(err))


def setup_firewall(port):
    """
    Ограничивает доступ к порту панели на уровне netfilter.

    Разрешение выдаётся по ИСХОДНОЙ ПОДСЕТИ, а не по имени интерфейса.
    Прежняя версия перечисляла br0/br1/wlan0/..., после чего вешала DROP
    без "-i". На Keenetic Wi-Fi-клиенты часто приходят через другой мост
    (гостевая сеть, отдельный бридж для 5 ГГц, иные имена вида wl0/ra0),
    и тогда ACCEPT для них не создавался, а общий DROP блокировал доступ:
    панель открывалась с роутера, но не с телефона по Wi-Fi.
    Список подсетей совпадает с ALLOWED_SUBNETS, который проверяет Flask.
    """
    wan = ['eth0', 'eth1', 'ppp0', 'ppp1', 'wan0', 'usb0']

    # Снять возможные разрешения на WAN.
    for i in wan:
        while _ipt('-D', 'INPUT', '-p', 'tcp', '--dport', str(port),
                   '-i', i, '-j', 'ACCEPT').returncode == 0:
            pass

    # Снять прежний DROP, чтобы затем добавить его последним.
    while _ipt('-D', 'INPUT', '-p', 'tcp', '--dport', str(port),
               '-j', 'DROP').returncode == 0:
        pass

    # Снять устаревшие ACCEPT по именам интерфейсов, оставшиеся
    # от предыдущих версий, — иначе они накапливаются.
    for i in list(getattr(config, 'lan_ifaces', ['br0', 'br1'])) + \
            ['lo', 'wlan0', 'wlan1']:
        while _ipt('-D', 'INPUT', '-p', 'tcp', '--dport', str(port),
                   '-i', i, '-j', 'ACCEPT').returncode == 0:
            pass

    # Разрешить доступ из локальных подсетей независимо от интерфейса.
    for net in [str(n) for n in ALLOWED_SUBNETS]:
        if _ipt('-C', 'INPUT', '-p', 'tcp', '--dport', str(port),
                '-s', net, '-j', 'ACCEPT').returncode != 0:
            _ipt('-I', 'INPUT', '-p', 'tcp', '--dport', str(port),
                 '-s', net, '-j', 'ACCEPT')

    # Всё остальное (в первую очередь WAN) — запретить.
    _ipt('-A', 'INPUT', '-p', 'tcp', '--dport', str(port), '-j', 'DROP')


def _check_csrf():
    token = request.form.get(
        'csrf_token', '')
    if not validate_csrf(token):
        abort(403)


# ── Включение/отключение протоколов ──────────────────────────────────────
# Состояние хранится в самом init-скрипте (ENABLED=yes|no) — это штатный
# механизм Entware: rc.func не запускает сервис при ENABLED=no, поэтому
# выбор переживает перезагрузку роутера без отдельного файла состояния.
# Конфигурации протоколов при отключении НЕ трогаются: повторное включение
# поднимает сервис с прежними ключами.
TAB_TO_SERVICE = {
    'ss': 'shadowsocks',
    'tr': 'trojan',
    'vl': 'vless',
    'to': 'tor',
    'hy': 'hysteria',
}


def _read_enabled(sn):
    """Читает ENABLED= из init-скрипта.

    K3 (повторный аудит 2026-10-12): нет файла — протокол не
    установлен ⇒ выключен. Синхронно с shell-семантикой после
    исправления P5 (common.sh:svc_enabled, хук:svc_installed),
    иначе панель показывала «включён» у несуществующего пакета.
    """
    sc = SERVICE_SCRIPTS.get(sn)
    if not sc or not os.path.exists(sc):
        return False
    try:
        with open(sc, 'r', encoding='utf-8',
                  errors='replace') as f:
            for line in f:
                m = re.match(
                    r'\s*ENABLED\s*=\s*([A-Za-z]+)', line)
                if m:
                    return m.group(1).lower() == 'yes'
    except OSError:
        pass
    return True


def get_services_enabled():
    """Состояние всех протоколов для отрисовки ползунков."""
    return {
        tab: _read_enabled(sn)
        for tab, sn in TAB_TO_SERVICE.items()
    }


def _write_enabled(sn, value):
    """Атомарно переписывает строку ENABLED= в init-скрипте."""
    sc = SERVICE_SCRIPTS.get(sn)
    if not sc:
        raise ValueError(f"?: {sn}")
    if not os.path.exists(sc):
        raise FileNotFoundError(f"!: {sc}")

    with open(sc, 'r', encoding='utf-8',
              errors='replace') as f:
        lines = f.readlines()

    word = 'yes' if value else 'no'
    found = False
    for i, line in enumerate(lines):
        if re.match(r'\s*ENABLED\s*=', line):
            lines[i] = f'ENABLED={word}\n'
            found = True
            break
    if not found:
        # Строки нет — добавляем после shebang.
        pos = 1 if lines and lines[0].startswith('#!') else 0
        lines.insert(pos, f'ENABLED={word}\n')

    # Запись через временный файл: обрыв не оставит битый init-скрипт.
    tmp = f'{sc}.tmp.{os.getpid()}'
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            f.writelines(lines)
        os.chmod(tmp, 0o755)
        os.replace(tmp, sc)
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


def set_service_enabled(sn, value):
    """
    Переключает протокол: правит ENABLED, затем запускает или
    останавливает сервис. Правила netfilter переприменяются, чтобы
    трафик не уходил на порт остановленного сервиса.
    """
    _write_enabled(sn, value)

    sc = SERVICE_SCRIPTS.get(sn)
    action = 'start' if value else 'stop'
    try:
        subprocess.run(
            [sc, action],
            capture_output=True, text=True, timeout=30)
    except (subprocess.SubprocessError, OSError) as e:
        raise RuntimeError(f"{sn}: {e}") from e

    _reapply_netfilter()


def _reapply_netfilter():
    """
    Переприменяет правила перехвата. Хук сам пропускает протоколы,
    у которых ENABLED=no, и снимает их прежние правила.
    """
    hook = '/opt/etc/ndm/netfilter.d/100-redirect.sh'
    if not os.path.exists(hook):
        return
    for table in ('nat', 'mangle'):
        env = dict(os.environ,
                   type='iptable', table=table)
        try:
            subprocess.run(
                [hook], env=env, capture_output=True,
                text=True, timeout=60)
        except (subprocess.SubprocessError, OSError):
            pass


def restart_service(sn):
    sc = SERVICE_SCRIPTS.get(sn)
    if not sc:
        raise ValueError(f"?: {sn}")
    if not os.path.exists(sc):
        raise FileNotFoundError(f"!: {sc}")
    os.chmod(sc, 0o755)
    # Истёкшее ожидание превращается в понятную ошибку: вызывающий код
    # ловит RuntimeError и показывает её пользователю.
    try:
        r = subprocess.run(
            [sc, 'restart'],
            capture_output=True,
            text=True, timeout=30)
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(
            f'{sn}: перезапуск не завершился за 30 с') from e
    if r.returncode != 0:
        err = (r.stderr.strip()
               or r.stdout.strip())
        raise RuntimeError(f"{sn}: {err}")


def _write_update_status(
        status, message=''):
    try:
        data = {
            'status': status,
            'ts': int(time.time()),
            'message': message}
        tmp = UPDATE_STATUS_FILE + '.tmp'
        with open(tmp, 'w') as f:
            json.dump(data, f)
        os.rename(tmp, UPDATE_STATUS_FILE)
    except (OSError, TypeError, ValueError) as e:
        logging.error('update status write %s: %s',
                      UPDATE_STATUS_FILE, e)


def _read_update_status():
    if not os.path.exists(
            UPDATE_STATUS_FILE):
        return {
            'status': 'idle',
            'ts': 0, 'message': ''}
    try:
        with open(
                UPDATE_STATUS_FILE, 'r') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {
                'status': 'idle',
                'ts': 0, 'message': ''}
        return data
    except (json.JSONDecodeError,
            IOError, ValueError):
        return {
            'status': 'idle',
            'ts': 0, 'message': ''}


def _build_wrapper(sp, only_sets=''):
    # only_sets — частичное обновление: обрабатывается лишь указанный
    # набор ipset. Правка одной записи в списке раньше запускала полный
    # цикл по всем доменам всех протоколов (сотни DNS-запросов).
    lines = [
        '#!/bin/sh',
        'export PATH=/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin',]
    if only_sets:
        # shlex.quote защищает от подстановки: имя набора приходит из
        # таблицы BYPASS_FILES, но экранирование дешевле доверия.
        lines.append('export ONLY_SETS=' + shlex.quote(only_sets))
    lines += [
        'STATUS_FILE="' + UPDATE_STATUS_FILE + '"',
        'TMP_STATUS="' + UPDATE_STATUS_FILE + '.wtmp"',
        'LOG_FILE="' + UPDATE_LOG_FILE + '"',
        'SCRIPT="' + sp + '"',
        '',
        '# Lock и основной статус обслуживает SCRIPT.',
        '"$SCRIPT" >"$LOG_FILE" 2>&1',
        'RC=$?',
        '',
        '# Резервный статус только если SCRIPT не успел',
        '# записать собственный done/error.',
        'NEED_FALLBACK=0',
        '[ -f "$STATUS_FILE" ] || NEED_FALLBACK=1',
        'if [ -f "$STATUS_FILE" ]; then',
        '    grep -Eq '
        '\'"status"[[:space:]]*:[[:space:]]*"running"\' '
        '"$STATUS_FILE" && NEED_FALLBACK=1',
        'fi',
        '',
        'if [ "$NEED_FALLBACK" -eq 1 ]; then',
        '    TS=$(date +%s)',
        '    if [ "$RC" -eq 0 ]; then',
        '        printf '
        '\'{"status":"done","ts":%s,'
        '"message":"ok"}\n\' '
        '"$TS" > "$TMP_STATUS"',
        '    else',
        '        printf '
        '\'{"status":"error","ts":%s,'
        '"message":"exit code %s"}\n\' '
        '"$TS" "$RC" > "$TMP_STATUS"',
        '    fi',
        '    mv -f "$TMP_STATUS" "$STATUS_FILE"',
        'fi',
        '',
        'exit "$RC"',
    ]
    return '\n'.join(lines) + '\n'


def apply_unblock_async(only_sets=''):
    sc = '/opt/bin/unblock_update.sh'
    if not os.path.exists(sc):
        raise FileNotFoundError(sc)
    os.chmod(sc, 0o755)
    st = _read_update_status()
    if st.get('status') == 'running':
        age = time.time() - st.get('ts', 0)
        if age < UNBLOCK_TIMEOUT:
            raise RuntimeError(
                f"Уже ({int(age)}с).")
        _write_update_status('idle', 'stale')
        try:
            pf = os.path.join(
                LOCK_DIR, 'pid')
            if os.path.exists(pf):
                with open(pf, 'r') as f:
                    op = int(
                        f.read().strip())
                try:
                    os.kill(op, 0)
                except OSError:
                    import shutil
                    shutil.rmtree(
                        LOCK_DIR,
                        ignore_errors=True)
        except (OSError, ValueError) as e:
            web_log(f"stale update lock cleanup: {e}")
    _write_update_status(
        'running', 'starting')
    with open(WRAPPER_SCRIPT, 'w') as f:
        f.write(_build_wrapper(sc, only_sets))
    os.chmod(WRAPPER_SCRIPT, 0o755)
    subprocess.Popen(
        ['/bin/sh', WRAPPER_SCRIPT],
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL)


def _test_dns_port(port):
    """Проверить локальный DNS-порт на уровне DNS и DNSSEC.

    torproject.org здесь намеренно не используется: его блокировка в
    России не должна показываться как отказ локального DoT/DoH. Результат
    структурированный, чтобы панель могла отличить DNSSEC-ok, обычный
    DNS-ответ без AD и настоящий отказ/подозрительный AA-ответ.
    """
    try:
        r = subprocess.run(
            ['dig', '+dnssec', '+noall', '+comments', '+answer', '+stats',
             '+time=2', '+tries=1', DNS_HEALTH_DOMAIN,
             '@localhost', '-p', str(port)],
            capture_output=True,
            text=True, timeout=5)
        out = r.stdout or ''
        rtt_match = re.search(
            r'Query time:\s*(\d+)\s*msec', out,
            re.IGNORECASE)
        rtt_ms = (int(rtt_match.group(1))
                  if rtt_match else None)
        status = ''
        match = re.search(r'status:\s*([^,;\s]+)', out)
        if match:
            status = match.group(1).upper()

        flags_match = re.search(
            r'flags:\s*([^;\n]+)', out, re.IGNORECASE)
        flags = set()
        if flags_match:
            flags = set(
                flags_match.group(1).lower().split())

        has_a = bool(re.search(
            r'(?m)^\S+\.?\s+\d+\s+IN\s+A\s+'
            r'\d+\.\d+\.\d+\.\d+\s*$', out))
        has_aa = 'aa' in flags
        has_ad = 'ad' in flags

        if status != 'NOERROR' or not has_a:
            return {
                'ok': False,
                'secure': False,
                'state': 'dns-failed',
                'detail': status or 'no-response',
                'rtt_ms': rtt_ms,
            }
        if has_aa:
            return {
                'ok': False,
                'secure': False,
                'state': 'dns-suspect-aa',
                'detail': 'authoritative-answer',
                'rtt_ms': rtt_ms,
            }
        if has_ad:
            return {
                'ok': True,
                'secure': True,
                'state': 'dnssec-ok',
                'detail': 'NOERROR + A + AD',
                'rtt_ms': rtt_ms,
            }
        return {
            'ok': True,
            'secure': False,
            'state': 'dns-ok-no-dnssec',
            'detail': 'NOERROR + A without AD',
            'rtt_ms': rtt_ms,
        }
    except (OSError, subprocess.SubprocessError):
        return {
            'ok': False,
            'secure': False,
            'state': 'dns-failed',
            'detail': 'dig-error',
            'rtt_ms': None,
        }


def read_pinned_hosts():
    """Закреплённые адреса прокси-серверов из /opt/etc/hosts.

    Пин создаёт unblock_dnsmasq.sh, пока штатный DNS работает. Панель
    только показывает результат — если адрес сервера задан доменом,
    видно, какой IP закреплён на случай блокировки DNS.
    """
    path = config.paths.get(
        'hosts_file', '/opt/etc/hosts')
    begin = '# --- KeenZOO pinned'
    end = '# --- end KeenZOO pinned'
    out = []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            inside = False
            for line in f:
                line = line.strip()
                if line.startswith(begin):
                    inside = True
                    continue
                if line.startswith(end):
                    break
                if inside and line:
                    parts = line.split()
                    if len(parts) >= 2:
                        out.append({
                            'ip': parts[0],
                            'host': parts[1]})
    except OSError:
        pass
    return out


def check_dns_ports():
    res = {
        'dot': {},
        'doh': {},
        'health_domain': DNS_HEALTH_DOMAIN,
    }
    for p in DNS_PORTS_DOT:
        res['dot'][str(p)] = _test_dns_port(p)
    for p in DNS_PORTS_DOH:
        res['doh'][str(p)] = _test_dns_port(p)
    res['pinned'] = read_pinned_hosts()
    return res


def _count_entries(text):
    d = ip = cidr = 0
    for line in text.split('\n'):
        s = line.strip()
        if s and not s.startswith('#'):
            c = _clean_entry(s)
            if c:
                r = _validate_entry(c)
                if r:
                    if r[0] == 'cidr':
                        cidr += 1
                    elif r[0] == 'ip':
                        ip += 1
                    else:
                        d += 1
    return d, ip, cidr


def _format_details(d, ip, cidr):
    p = []
    if d:
        p.append(f'{d} доменов')
    if ip:
        p.append(f'{ip} IP')
    if cidr:
        p.append(f'{cidr} CIDR')
    return (', '.join(p)
            if p else '0 записей')


# Сколько уникальных IP обогащать RDAP/RIPEstat при поиске пулов.
# Каждый IP — до двух HTTPS-запросов к внешним сервисам; на слабом
# роутере 6 штук — разумный потолок по времени ответа панели.
_LOOKUP_RDAP_LIMIT = 6


def _curl_json(url, max_time=6):
    """GET JSON через curl; None при любой ошибке/не-JSON."""
    try:
        r = subprocess.run(
            ['curl', '-s', '--connect-timeout', '4',
             '--max-time', str(max_time), url],
            capture_output=True, text=True,
            timeout=max_time + 4,
            check=False)
        if r.returncode != 0 or not r.stdout:
            return None
        return json.loads(r.stdout)
    except (OSError, ValueError):
        # OSError — curl недоступен/убит; ValueError — тело не JSON.
        return None


def _ip_owner_info(ip_str):
    """RDAP + RIPEstat по IP: CIDR владельца, ASN, организация.

    Источники:
      * https://rdap.org/ip/{ip} — реестр (bootstrap на нужный RIR):
        имя сети, тип, страна, исходный CIDR из cidr0_cidrs либо
        start/end-адресов;
      * RIPEstat prefix-overview — анонсированный префикс и
        (asn, holder) — то, что реально маршрутизируется.
    Все ветки необязательны: чего нет — того нет.
    """
    info = {}
    rd = _curl_json(
        f'https://rdap.org/ip/{ip_str}')
    if isinstance(rd, dict):
        name = (rd.get('name')
                or rd.get('handle') or '')
        if name:
            info['rdap_name'] = str(name)
        for k in ('type', 'country'):
            if rd.get(k):
                info['rdap_' + k] = str(rd[k])
        # Современный формат: cidr0_cidrs[]
        for c in rd.get('cidr0_cidrs') or []:
            v4 = c.get('v4prefix')
            ln = c.get('length')
            if v4 and ln is not None:
                info['rdap_cidr'] = f'{v4}/{ln}'
                break
        # Старый формат: startAddress/endAddress
        if ('rdap_cidr' not in info
                and rd.get('startAddress')
                and rd.get('endAddress')):
            try:
                s = ipaddress.ip_address(
                    rd['startAddress'])
                e = ipaddress.ip_address(
                    rd['endAddress'])
                nets = [
                    str(n)
                    for n in
                    ipaddress.summarize_address_range(
                        s, e)]
                if nets:
                    info['rdap_cidr'] = nets[0]
            except (ValueError, TypeError):
                # Кривые start/end в ответе реестра — просто без CIDR.
                pass
        # Организация из entities (registrant)
        for ent in rd.get('entities') or []:
            roles = ent.get('roles') or []
            if 'registrant' not in roles:
                continue
            vc = ent.get('vcardArray')
            try:
                for row in (vc[1] if vc
                            and len(vc) > 1
                            else []):
                    if (row
                            and row[0] == 'fn'
                            and len(row) > 3):
                        info['org'] = str(row[3])
                        raise StopIteration
            except StopIteration:
                break
            except (IndexError, KeyError,
                    TypeError, ValueError):
                # Кривой vcard у entity — имя сети уже есть,
                # организацию можно пропустить.
                break
    st = _curl_json(
        'https://stat.ripe.net/data/'
        'prefix-overview/data.json'
        f'?resource={ip_str}')
    if isinstance(st, dict):
        d = st.get('data') or {}
        bl = d.get('block') or {}
        if bl.get('resource'):
            info['prefix'] = str(bl['resource'])
        asns = d.get('asns') or []
        if asns:
            first = asns[0] or {}
            if first.get('asn'):
                info['asn'] = (
                    f"AS{first['asn']}")
            if first.get('holder'):
                info['as_holder'] = str(
                    first['holder'])
    return info


def _lookup_resource(query):
    results = {
        'query': query, 'ips': [],
        'cidrs': [], 'domains': [],
        'in_lists': {}, 'errors': [],
        'missing': [], 'found': [],
        'covered': {}, 'ipinfo': {},
    }
    q = query.strip().lower()

    presets = {
        'telegram': {
            'cidr_url': (
                'https://core.telegram.org'
                '/resources/cidr.txt'),
            'domains': [
                'api.telegram.org',
                'cdn-telegram.org',
                'telegram.org', 't.me',
                'core.telegram.org',
                'telegra.ph',
                'telegram.me',
            ],
        },
        'whatsapp': {
            'domains': [
                'whatsapp.com',
                'whatsapp.net', 'wa.me',
                'web.whatsapp.com',
                'static.whatsapp.net',
                'mmg.whatsapp.net',
                'media.fna.whatsapp.net',
                'pps.whatsapp.net',
                'fbcdn.com', 'fbcdn.net',
            ],
        },
        'youtube': {
            'domains': [
                'youtube.com',
                'youtu.be',
                'googlevideo.com',
                'ytimg.com',
                'ggpht.com',
                'googleusercontent.com',
                'youtube-nocookie.com',
                'googleapis.com',
            ],
        },
    }

    # IPv4-only фильтр
    _ip4 = re.compile(
        r'^\d+\.\d+\.\d+\.\d+$')
    # Имя хоста: буквы/цифры/дефис/точка, без ведущего дефиса.
    _host_re = re.compile(
        r'^(?!-)[a-z0-9-]{1,63}'
        r'(?:\.(?!-)[a-z0-9-]{1,63})*\.?$')
    _cidr4 = re.compile(
        r'^\d+\.\d+\.\d+\.\d+/\d+$')

    if q in presets:
        preset = presets[q]
        results['domains'] = list(
            preset.get('domains', []))
        cidr_url = preset.get('cidr_url')
        if cidr_url:
            try:
                r = subprocess.run(
                    ['curl', '-s',
                     '--max-time', '10',
                     cidr_url],
                    capture_output=True,
                    check=False,
                    text=True, timeout=15)
                if r.returncode == 0:
                    for line in (
                            r.stdout.strip()
                            .split('\n')):
                        line = line.strip()
                        if (line
                                and _cidr4.match(
                                    line)):
                            results[
                                'cidrs'
                            ].append(line)
            except Exception:
                pass
        for domain in results['domains']:
            try:
                r = subprocess.run(
                    ['dig', '+short',
                     domain, '@localhost'],
                    capture_output=True,
                    text=True, timeout=10)
                for ip in (
                        r.stdout.strip()
                        .split('\n')):
                    ip = ip.strip()
                    if (_ip4.match(ip)
                            and ip not in
                            results['ips']):
                        results[
                            'ips'
                        ].append(ip)
            except Exception:
                pass
    elif _ip4.match(q):
        results['ips'] = [q]
    elif _cidr4.match(q):
        results['cidrs'] = [q]
    elif (q.startswith('as')
          and q[2:].isdigit()):
        asn = q.upper()
        try:
            r = subprocess.run(
                ['curl', '-s',
                 '--max-time', '15',
                 'https://stat.ripe.net'
                 '/data/announced-prefixes'
                 '/data.json'
                 f'?resource={asn}'],
                capture_output=True,
                text=True, timeout=20)
            if r.returncode == 0:
                data = json.loads(
                    r.stdout)
                for p in (
                        data.get('data', {})
                        .get('prefixes',
                             [])):
                    prefix = p.get(
                        'prefix', '')
                    if (prefix
                            and _cidr4.match(
                                prefix)):
                        results[
                            'cidrs'
                        ].append(prefix)
        except Exception as e:
            results['errors'].append(
                str(e))
    else:
        # Валидация домена перед передачей во внешнюю утилиту.
        # Раньше в dig уходила произвольная строка: значение вида
        # "-f/etc/passwd" трактовалось бы как ОПЦИЯ, а не имя хоста
        # (аргументы передаются списком, поэтому shell-инъекция была
        # невозможна, но подмена опции — вполне).
        if not _host_re.match(q) or len(q) > 253:
            results['errors'].append(
                'Недопустимое имя хоста')
            results['domains'] = []
            return results
        results['domains'] = [q]
        try:
            r = subprocess.run(
                ['dig', '+short', '--', q,
                 '@localhost'],
                capture_output=True,
                text=True, timeout=10)
            for ip in (
                    r.stdout.strip()
                    .split('\n')):
                ip = ip.strip()
                if _ip4.match(ip):
                    results[
                        'ips'
                    ].append(ip)
        except Exception:
            pass
        try:
            r = subprocess.run(
                ['dig', '+short', 'CNAME',
                 '--', q, '@localhost'],
                capture_output=True,
                text=True, timeout=10)
            for cname in (
                    r.stdout.strip()
                    .split('\n')):
                cname = (
                    cname.strip()
                    .rstrip('.'))
                if (cname and cname != q
                        and ':' not in
                        cname):
                    results[
                        'domains'
                    ].append(cname)
        except Exception:
            pass

    # ═══════════════════════════════
    # Загрузить все записи из списков
    # ═══════════════════════════════

    list_domains = {}  # domain → [files]
    list_cidrs = []    # [(network, file)]

    for fp in _all_bypass_filepaths():
        fname = os.path.splitext(
            os.path.basename(fp))[0]
        if not os.path.exists(fp):
            continue
        for line in (
                read_file_text(fp)
                .split('\n')):
            entry = line.split('#')[0].strip()
            if not entry:
                continue
            if _cidr4.match(entry):
                try:
                    net = (
                        ipaddress.ip_network(
                            entry,
                            strict=False))
                    list_cidrs.append(
                        (net, fname))
                except ValueError:
                    pass
            elif _ip4.match(entry):
                try:
                    net = (
                        ipaddress.ip_network(
                            entry + '/32',
                            strict=False))
                    list_cidrs.append(
                        (net, fname))
                except ValueError:
                    pass
            elif entry and '/' not in entry:
                if entry not in list_domains:
                    list_domains[entry] = []
                list_domains[entry].append(
                    fname)

    # ═══════════════════════════════
    # Проверка доменов
    # (точное + родительский домен)
    # ═══════════════════════════════

    all_items = set()
    found_anywhere = set()
    covered = {}

    for domain in results['domains']:
        all_items.add(domain)
        # Точное совпадение
        if domain in list_domains:
            found_anywhere.add(domain)
            for f in list_domains[domain]:
                results['in_lists']. \
                    setdefault(f, []) \
                    .append(domain)
            continue
        # Родительский домен
        parts = domain.split('.')
        parent_found = False
        for i in range(1, len(parts)):
            parent = '.'.join(parts[i:])
            if parent in list_domains:
                found_anywhere.add(domain)
                covered[domain] = parent
                for f in (
                        list_domains[parent]):
                    results['in_lists']. \
                        setdefault(f, []) \
                        .append(
                            f"{domain} "
                            f"({parent})")
                parent_found = True
                break
        if not parent_found:
            pass  # пойдёт в missing

    # ═══════════════════════════════
    # Проверка IP
    # (точное + вхождение в CIDR)
    # ═══════════════════════════════

    for ip_str in results['ips']:
        all_items.add(ip_str)
        try:
            ip_addr = ipaddress.ip_address(
                ip_str)
        except ValueError:
            continue
        ip_found = False
        # Точное
        if ip_str in list_domains:
            found_anywhere.add(ip_str)
            ip_found = True
            for f in list_domains[ip_str]:
                results['in_lists']. \
                    setdefault(f, []) \
                    .append(ip_str)
        # Вхождение в CIDR
        if not ip_found:
            for net, fname in list_cidrs:
                if ip_addr in net:
                    found_anywhere.add(
                        ip_str)
                    covered[ip_str] = (
                        str(net))
                    results['in_lists']. \
                        setdefault(
                            fname, []) \
                        .append(
                            f"{ip_str} "
                            f"({net})")
                    ip_found = True
                    break

    # ═══════════════════════════════
    # Проверка CIDR
    # (точное + вхождение в больший)
    # ═══════════════════════════════

    for cidr_str in results['cidrs']:
        all_items.add(cidr_str)
        try:
            check_net = (
                ipaddress.ip_network(
                    cidr_str, strict=False))
        except ValueError:
            continue
        for net, fname in list_cidrs:
            if (check_net.subnet_of(net)
                    and check_net != net):
                # Вложен в больший
                found_anywhere.add(cidr_str)
                covered[cidr_str] = (
                    str(net))
                results['in_lists']. \
                    setdefault(fname, []) \
                    .append(
                        f"{cidr_str} "
                        f"({net})")
                break
            elif check_net == net:
                # Точное совпадение
                found_anywhere.add(cidr_str)
                results['in_lists']. \
                    setdefault(fname, []) \
                    .append(cidr_str)
                break

    # ═══════════════════════════════
    # RDAP/RIPEstat обогащение IP:
    # CIDR владельца, ASN, организация.
    # Используется вкладкой поиска пулов
    # (задача: добавить выбранный
    # CIDR/домен в нужный список).
    # ═══════════════════════════════
    for ip_str in results['ips'][
            :_LOOKUP_RDAP_LIMIT]:
        info = _ip_owner_info(ip_str)
        if info:
            results['ipinfo'][ip_str] = info
            # Анонсированный префикс владельца — кандидат
            # во множество CIDR для добавления в списки.
            pfx = info.get('prefix') or info.get(
                'rdap_cidr') or ''
            if (pfx and _cidr4.match(pfx)
                    and pfx
                    not in results['cidrs']):
                results['cidrs'].append(pfx)

    results['missing'] = sorted(
        all_items - found_anywhere)
    results['found'] = sorted(
        found_anywhere)
    results['covered'] = covered

    return results


PAGE_TEMPLATE = r'''
<!DOCTYPE html><html lang="ru" data-theme="light"><head>
<meta charset="utf-8">
<meta name="viewport"
  content="width=device-width,
  initial-scale=1">
<title>KeenZOO Panel</title>
<script>
/* Тема: светлая по умолчанию, выбор хранится локально (без cookie). */
(function () {
  function applyTheme(t) {
    document.documentElement.dataset.theme = t;
    var b = document.getElementById('themeBtn');
    if (b) b.setAttribute('aria-pressed', String(t === 'dark'));
  }
  try {
    var s = localStorage.getItem('kzp-theme');
    if (s === 'dark' || s === 'light') applyTheme(s);
  } catch (e) {}
  window.toggleTheme = function () {
    var t = (document.documentElement.dataset.theme === 'dark') ? 'light' : 'dark';
    applyTheme(t);
    try { localStorage.setItem('kzp-theme', t); } catch (e) {}
  };
})();
</script>
<style>
:root{
 --txt:#1b2530;--muted:#5b6b7a;--accent:#0e7a6d;--accent2:#0c6c60;
 --green:#0a7d4b;--red:#b3261e;--orange:#a15c07;
 --gl:#fff;--gl2:#eef3f5;--brd:#dde4ea;--bg:#f7fafb;--page:#f2f5f7;
 --line:#dde4ea;--soft:#e2f2ef;--oksoft:#e1f3ea;--warnsoft:#f9ecd7;
 --badsoft:#fbe4e2;--on-accent:#fff;--radius:10px;
 --side:#16202b;--side-txt:#c8d4de;--side-mut:#7e93a5;--side-acc:#2dd4bf;
 --space:10px;--control-h:40px;--content-max:1180px;
 color-scheme:light;font-size:14px
}
html[data-theme="dark"]{
 --txt:#dfe8f0;--muted:#93a6b8;--accent:#2dd4bf;--accent2:#5eead4;
 --green:#4ade80;--red:#ff7a6e;--orange:#f2b24b;
 --gl:#1a232d;--gl2:#222e3a;--brd:#2b3947;--bg:#151d26;--page:#12181f;
 --line:#2b3947;--soft:#143a37;--oksoft:#173528;--warnsoft:#3a2e15;
 --badsoft:#3d1e1b;--on-accent:#0b1512;
 --side:#0e151c;--side-txt:#c4d2dd;--side-mut:#6e8496;--side-acc:#2dd4bf;
 color-scheme:dark
}
*{box-sizing:border-box;margin:0;padding:0}
html{min-height:100%;background:var(--page)}
body{
 background:var(--page);color:var(--txt);min-height:100vh;min-height:100dvh;
 overflow-x:hidden;font-family:ui-sans-serif,system-ui,-apple-system,"Segoe UI",
 Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif;font-size:14px;
 line-height:1.5;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility
}
h1{font-size:18px;line-height:1.25;font-weight:650;color:var(--txt)}
svg.ico{width:18px;height:18px;flex:0 0 auto;stroke:currentColor;fill:none;
 stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
button,input,textarea,select{font:inherit}
button{touch-action:manipulation}
.tab-btn:focus-visible,.btn:focus-visible,.dns-toggle:focus-visible,
.lk-presets button:focus-visible,.icon-btn:focus-visible,
details.cfg-d>summary:focus-visible,select:focus-visible,
input:focus-visible,textarea:focus-visible{
 outline:2px solid var(--accent);outline-offset:2px
}
.layout{display:flex;min-height:100vh;min-height:100dvh}
.side{
 width:208px;flex:0 0 208px;background:var(--side);display:flex;
 flex-direction:column;position:sticky;top:0;height:100vh;height:100dvh;overflow-y:auto
}
.side-brand{display:flex;align-items:center;gap:10px;padding:15px 13px 12px}
.side-logo{
 width:32px;height:32px;border-radius:9px;display:grid;place-items:center;
 background:var(--side-acc);color:#0b1512;flex:0 0 32px;font-size:0
}
.side-logo svg{width:20px;height:20px}
.brand-text{min-width:0}.brand-name{font-weight:700;font-size:15px;letter-spacing:1px;
 color:var(--side-txt);-webkit-text-fill-color:var(--side-txt)}
.brand-sub{font-size:11px;color:var(--side-mut);letter-spacing:.2px}
.tabs{display:flex;flex-direction:column;flex:1;padding:2px 9px}
.nav-group{font-size:10px;letter-spacing:1.15px;text-transform:uppercase;
 color:var(--side-mut);padding:13px 6px 5px;font-weight:700}
.tab-btn{
 width:100%;height:36px;text-align:left;display:flex;align-items:center;gap:9px;
 background:none;border:1px solid transparent;border-radius:8px;color:var(--side-txt);
 font-size:13px;padding:0 9px;margin:1px 0;cursor:pointer;transition:background .12s,color .12s
}
.tab-btn svg.ico{color:var(--side-mut)}
.tab-btn:hover{background:rgba(255,255,255,.08);color:var(--side-txt)}
.tab-btn:hover svg.ico{color:var(--side-acc)}
.tab-btn.active{background:var(--side-acc);color:#0b1512;font-weight:600;border-color:var(--side-acc)}
.tab-btn.active svg.ico{color:#0b1512}
.tab-btn:active{transform:scale(.985)}
.side-foot{
 padding:11px 13px;font-size:11px;color:var(--side-mut);border-top:1px solid rgba(255,255,255,.09);
 display:flex;gap:7px;align-items:center
}
.live-dot{width:8px;height:8px;border-radius:50%;background:var(--green);flex:0 0 8px}
.main{flex:1;min-width:0;padding:18px 22px 30px}
.page-head{
 position:sticky;top:0;z-index:30;display:flex;align-items:center;gap:10px;flex-wrap:wrap;
 margin:-18px -22px 15px;padding:10px 22px;background:var(--gl);border-bottom:1px solid var(--line)
}
.page-title{flex:0 1 auto;min-width:160px}
.hd-pill{
 display:inline-flex;align-items:center;justify-content:center;height:26px;padding:0 10px;
 border-radius:99px;font-size:12px;font-weight:600;white-space:nowrap
}
.hd-pill.ok{background:var(--oksoft);color:var(--green)}
.hd-pill.warn{background:var(--warnsoft);color:var(--orange)}
.hd-pill.bad{background:var(--badsoft);color:var(--red)}
.hd-pill.ghost{background:var(--gl2);color:var(--muted);font-weight:500}
.hd-time{
 margin-left:auto;font-family:ui-monospace,"Cascadia Mono",Consolas,monospace;
 font-size:12px;color:var(--muted);white-space:nowrap
}
.icon-btn{
 display:inline-flex;align-items:center;justify-content:center;width:var(--control-h);height:var(--control-h);
 border-radius:8px;border:1px solid var(--line);background:var(--gl2);color:var(--muted);cursor:pointer
}
.icon-btn:hover{border-color:var(--accent);color:var(--accent)}
.icon-btn .ico{width:18px;height:18px}
.icon-btn .ico-sun{display:block}.icon-btn .ico-moon{display:none}
html[data-theme="dark"] .icon-btn .ico-sun{display:none}
html[data-theme="dark"] .icon-btn .ico-moon{display:block}
.card{min-width:0;max-width:var(--content-max);margin:0 auto}
.tiles{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:var(--space);align-items:stretch}
.tile{
 grid-column:span 12;min-width:0;background:var(--gl);border:1px solid var(--line);
 border-top:2px solid var(--accent);border-radius:var(--radius);padding:14px
}
.tile:not(.tile-span){grid-column:span 6}
.tile-span{grid-column:1/-1}
.tile-hint{font-size:12px;color:var(--muted);margin:10px 0 0;line-height:1.45}
.tile-hint b{color:var(--txt)}
.tab-content{display:none}.tab-content.active{display:block}
label{display:block;font-size:13px;color:var(--muted);margin-bottom:7px}
textarea,input[type=text],select{
 width:100%;min-height:var(--control-h);padding:9px 11px;background:var(--bg);
 border:1px solid var(--line);border-radius:8px;color:var(--txt);font-size:14px
}
textarea{
 font-family:ui-monospace,Consolas,monospace;resize:vertical;line-height:1.5
}
input[type=text]{font-family:ui-monospace,Consolas,monospace}
textarea:focus,input[type=text]:focus,select:focus{
 outline:none;border-color:var(--accent);box-shadow:0 0 0 2px var(--soft)
}
textarea::placeholder,input::placeholder{color:var(--muted)}
.key-area{min-height:88px}.list-area{min-height:250px}
#lk-output,#lk-add-entries{font-family:ui-monospace,Consolas,monospace;font-size:13px}
.cfg-ta{min-height:240px}
.compact-area{min-height:120px}.config-entry{min-height:120px}.select-control{font-family:ui-sans-serif,system-ui,sans-serif}
.hint{font-size:12px;color:var(--muted);margin:5px 0 11px;line-height:1.4}
.hint code,.info-box code{background:var(--gl2);color:var(--txt);padding:1px 5px;border-radius:5px}
.divider{
 height:1px;background:var(--line);margin:15px 0;display:flex;align-items:center;justify-content:center
}
.divider span{
 background:var(--gl);color:var(--accent);font-size:12px;font-weight:600;padding:0 8px;border-radius:8px;
 max-width:100%;overflow-wrap:anywhere;text-align:center
}
.subhead{font-size:13px;color:var(--accent);font-weight:650;margin-bottom:7px}
.subhead-gap{margin:11px 0 7px}
.counter{font-size:12px;color:var(--muted);text-align:right;margin-top:4px}
.btn{
 width:100%;min-height:var(--control-h);padding:8px 12px;border:1px solid var(--line);
 border-radius:8px;background:var(--gl);color:var(--txt);font-size:14px;font-weight:600;
 cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px;
 transition:background .12s,border-color .12s,color .12s
}
.btn:hover{border-color:var(--accent)}.btn:active{transform:scale(.985)}
.btn:disabled{opacity:.55;cursor:not-allowed;transform:none}
.btn-key{border-color:var(--accent);color:var(--accent)}
.btn-cfg{border-color:var(--orange);color:var(--orange);margin-top:6px}
.btn-save{border-color:var(--green);color:var(--green);margin-top:6px}
.btn .spinner-ring{
 display:none;width:16px;height:16px;border-radius:50%;border:2px solid var(--brd);
 border-top-color:currentColor;animation:spin .6s linear infinite
}
.btn.loading .spinner-ring{display:inline-block}.btn.loading .btn-label{opacity:.7}
@keyframes spin{to{transform:rotate(360deg)}}
.action-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.action-row>.btn{width:auto;min-width:170px;flex:1 1 170px}
.action-row-auto>.btn{flex:0 1 auto}.action-row-result>.btn{flex:1 1 220px}
.action-auto{min-width:180px}
.lookup-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;margin-bottom:10px}
.lookup-submit{width:var(--control-h);min-width:var(--control-h);padding:0}
.result-info{font-size:13px;color:var(--muted);margin-bottom:7px}
.result-status{margin-bottom:9px}.result-output{min-height:200px;background:var(--bg)}
.is-hidden{display:none}.lk-presets{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px}
.lk-presets button{
 min-height:36px;padding:6px 12px;border:1px solid var(--line);border-radius:8px;
 background:var(--gl);color:var(--muted);cursor:pointer;font-size:13px;
 transition:color .12s,border-color .12s
}
.lk-presets button:hover{color:var(--accent);border-color:var(--accent)}
#update-bar,#pin-bar{display:none}
.msg,#update-bar,#pin-bar{
 max-width:var(--content-max);width:100%;margin:0 auto 10px;padding:10px 13px;
 border-radius:8px;border:1px solid var(--line);background:var(--gl);font-size:14px;white-space:pre-line
}
.msg-ok{border-left:3px solid var(--green);color:var(--green)}
.msg-err{border-left:3px solid var(--red);color:var(--red)}
#update-bar,#pin-bar{text-align:center;white-space:pre-wrap}
#update-bar.running{display:block;border-left:3px solid var(--accent);color:var(--accent)}
#update-bar.done{display:block;border-left:3px solid var(--green);color:var(--green)}
#update-bar.warn{display:block;border-left:3px solid var(--orange);color:var(--orange)}
#update-bar.error{display:block;border-left:3px solid var(--red);color:var(--red)}
#pin-bar.warn{display:block;border-left:3px solid var(--red);color:var(--red)}
#pin-bar.ok{display:block;border-left:3px solid var(--green);color:var(--green)}
.svc-row{
 display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:48px;
 background:var(--bg);border:1px solid var(--line);border-radius:8px;padding:9px 11px
}
.svc-name{font-size:14px;font-weight:650;color:var(--muted);min-width:0;overflow-wrap:anywhere}
.svc-name.on{color:var(--green)}.svc-name.off{color:var(--red)}
.switch{position:relative;display:inline-block;width:44px;height:24px;flex:0 0 44px}
.switch input{position:absolute;opacity:0;width:100%;height:100%;margin:0;cursor:pointer}
.slider{position:absolute;cursor:pointer;inset:0;background:var(--brd);border-radius:24px;transition:background .15s}
.slider:before{
 position:absolute;content:"";height:18px;width:18px;left:3px;top:3px;background:#fff;
 border-radius:50%;transition:transform .15s
}
.switch input:checked+.slider{background:var(--accent)}
.switch input:checked+.slider:before{transform:translateX(20px)}
.switch input:focus-visible+.slider{outline:2px solid var(--accent);outline-offset:2px}
.dns-panel{max-width:var(--content-max);margin:10px auto 0}
.dns-toggle{
 width:100%;min-height:38px;background:var(--gl);border:1px solid var(--line);border-radius:8px;
 padding:7px 12px;color:var(--muted);font-size:13px;cursor:pointer;text-align:center;
 transition:color .12s,border-color .12s
}
.dns-toggle:hover{color:var(--accent);border-color:var(--accent)}
.dns-grid{
 display:none;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-top:8px;
 background:var(--gl);border:1px solid var(--line);border-radius:8px;padding:10px
}
.dns-grid.open{display:grid}
.dns-port{
 text-align:center;padding:7px 6px;border-radius:8px;font-size:12px;
 font-family:ui-monospace,Consolas,monospace;background:var(--bg);border:1px solid var(--line);
 overflow-wrap:anywhere
}
.dns-port.ok{color:var(--green);border-color:var(--green)}
.dns-port.fail{color:var(--red);border-color:var(--red)}
.dns-port.insecure{color:var(--orange);border-color:var(--orange)}
.dns-port.checking{color:var(--muted)}
.dns-label{
 font-size:12px;color:var(--muted);margin:5px 0 0;font-weight:650;
 grid-column:1/-1;background:none;border:0;text-align:left
}
.ver-grid{display:none;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:8px;
 background:var(--gl);border:1px solid var(--line);border-radius:8px;padding:10px}
.ver-grid.open{display:grid}.ver-item{display:flex;flex-direction:column;gap:6px;min-width:0}
.upd-all-row{display:none;grid-column:1/-1}.upd-all-row.on{display:block}
.upd-btn{display:none;width:100%;font-size:13px;padding:7px 10px;border-color:var(--orange);color:var(--orange)}
.upd-btn.on{display:block}.upd-all-row .upd-btn{display:block}
.upd-check-result{font-size:13px;color:var(--muted)}
.upd-out{
 display:none;white-space:pre-wrap;font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.4;
 max-height:240px;overflow:auto;padding:9px 11px;border-radius:8px;background:var(--bg);
 border:1px solid var(--line);color:var(--txt);word-break:break-word
}
.upd-out.on{display:block}
.pin-box{
 display:none;grid-column:1/-1;white-space:pre-wrap;font-family:ui-monospace,Consolas,monospace;
 font-size:12px;line-height:1.5;color:var(--muted);padding:8px 10px;border-radius:8px;
 background:var(--bg);border:1px solid var(--line);word-break:break-all
}
.pin-box.on{display:block}
.spoof-verdict{font-size:17px;font-weight:650;margin:5px 0}.spoof-verdict.ok{color:var(--green)}
.spoof-verdict.warn{color:var(--orange)}.spoof-verdict.bad{color:var(--red)}
.spoof-meta{font-size:13px;color:var(--muted);margin-bottom:7px;overflow-wrap:anywhere}
.spoof-ports{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:6px;margin-bottom:9px}
.spoof-port{
 display:flex;justify-content:space-between;gap:8px;min-width:0;background:var(--bg);
 border:1px solid var(--line);border-radius:8px;padding:7px 8px;font-size:13px
}
.spoof-port>span:first-child{min-width:0;overflow-wrap:anywhere}.spoof-port .ok{color:var(--green)}
.spoof-port .warn{color:var(--orange)}.spoof-port .bad{color:var(--red)}
.rs-mode{font-size:16px;font-weight:650;margin:5px 0}.rs-mode.ok{color:var(--green)}
.rs-mode.warn{color:var(--orange)}.rs-mode.bad{color:var(--red)}
.rs-primary{font-size:14px;margin:0 0 8px;color:var(--txt);overflow-wrap:anywhere}
.spoof-port .mut{color:var(--muted)}
.spoof-port .rs-ver{border-bottom:1px dotted var(--accent);cursor:help}
details.cfg-d{
 background:var(--gl);border:1px solid var(--line);border-radius:8px;margin-bottom:8px;overflow:hidden
}
details.cfg-d>summary{
 cursor:pointer;list-style:none;display:flex;flex-wrap:wrap;gap:4px 10px;align-items:center;
 min-height:42px;padding:8px 10px;font-size:14px;user-select:none
}
details.cfg-d>summary::-webkit-details-marker{display:none}
details.cfg-d>summary::before{content:"\25B6";font-size:9px;color:var(--muted);transition:transform .15s}
details.cfg-d[open]>summary::before{transform:rotate(90deg)}
details.cfg-d>summary .cfg-path{
 font-family:ui-monospace,Consolas,monospace;font-size:12px;color:var(--muted);overflow-wrap:anywhere
}
details.cfg-d>summary .cfg-meta{font-size:12px;color:var(--muted);margin-left:auto}
.cfg-btns{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:9px 10px 0}
.cfg-btns .btn{width:100%;margin:0}
details.cfg-d>.upd-out{margin:9px 10px 10px}
.info-box{
 background:var(--warnsoft);border:1px solid var(--orange);border-radius:8px;padding:11px 12px;
 margin-bottom:13px;font-size:13px;line-height:1.5;color:var(--orange)
}
.lk-presets{margin-bottom:11px}.lk-presets button{min-width:100px}
.rp-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.rp-btn{min-width:0}.rp-btn.active{border-color:var(--accent);background:var(--soft);color:var(--accent);
 box-shadow:inset 0 0 0 1px var(--accent)}
.rp-btn:disabled{opacity:.45;cursor:not-allowed;box-shadow:none}
*::-webkit-scrollbar{width:8px;height:8px}*::-webkit-scrollbar-thumb{background:var(--brd);border-radius:4px}
*::-webkit-scrollbar-track{background:transparent}
@media (max-width:960px){
 .layout{flex-direction:column}.side{
  width:100%;flex:0 0 auto;height:auto;position:sticky;top:0;z-index:40;flex-direction:row;align-items:center;
  overflow-x:auto;scrollbar-width:none
 }
 .side::-webkit-scrollbar{display:none}.side-brand{padding:9px 11px;flex-shrink:0}.brand-sub{display:none}
 .tabs{flex-direction:row;padding:0 5px;flex:1;scroll-snap-type:x proximity}
 .nav-group{display:none}.tab-btn{width:auto;height:40px;white-space:nowrap;padding:0 10px;
  border-radius:0;scroll-snap-align:start;color:var(--side-txt)}
 .tab-btn.active{background:rgba(255,255,255,.08);color:var(--side-acc);border-color:transparent;
  box-shadow:inset 0 -2px 0 var(--side-acc)}
 .tab-btn.active svg.ico{color:var(--side-acc)}.side-foot{display:none}
 .main{padding:12px 12px 26px}.page-head{position:static;margin:-12px -12px 12px;padding:9px 12px}
 .page-title{font-size:17px}.dns-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media (max-width:700px){
 .tile:not(.tile-span){grid-column:1/-1}.cfg-btns{grid-template-columns:1fr}
 .action-row>.btn,.action-auto{flex:1 1 100%;min-width:0}.rp-row{grid-template-columns:1fr}
 .spoof-ports{grid-template-columns:1fr}.page-head{gap:8px}.page-title{flex-basis:100%;min-width:0}
 .hd-time{margin-left:0;flex:1 1 auto}.hd-pill{height:28px}
}
@media (max-width:420px){
 .main{padding-left:9px;padding-right:9px}.page-head{margin-left:-9px;margin-right:-9px;padding-left:9px;padding-right:9px}
 .side-brand{padding-left:9px;padding-right:9px}.tabs{padding-left:3px;padding-right:3px}.tab-btn{padding:0 8px;font-size:12px;gap:7px}
 .tab-btn svg.ico{width:16px;height:16px}.tile{padding:12px}.divider{margin:13px 0}.info-box{font-size:12px}
 .dns-grid,.ver-grid{padding:8px;gap:6px}.dns-port,.spoof-port{font-size:12px}
}
@media (prefers-reduced-motion:reduce){*{transition:none !important;animation:none !important}}
</style></head><body>
<div class="layout">
<aside class="side">
  <div class="side-brand">
    <span class="side-logo"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l7 4v10l-7 4-7-4V7z"/><path d="M8.5 12l2.2 2.2 4.8-4.8"/></svg></span>
    <div class="brand-text">
      <div class="brand-name">KEENZOO</div>
      <div class="brand-sub">панель обхода</div>
    </div>
  </div>
  <nav class="tabs">
    <div class="nav-group">Протоколы</div>
  <button id="btn-ss" class="tab-btn
    {% if active=='ss' %}active{% endif %}"
    onclick="go('ss')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M13 2 3 14h7l-1 8 10-12h-7z"/></svg>Shadowsocks</button>
  <button id="btn-tr" class="tab-btn
    {% if active=='tr' %}active{% endif %}"
    onclick="go('tr')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>Trojan</button>
  <button id="btn-vl" class="tab-btn
    {% if active=='vl' %}active{% endif %}"
    onclick="go('vl')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>VLESS</button>
  <button id="btn-to" class="tab-btn
    {% if active=='to' %}active{% endif %}"
    onclick="go('to')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/></svg>Tor</button>
  <button id="btn-hy" class="tab-btn
    {% if active=='hy' %}active{% endif %}"
    onclick="go('hy')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M3 8h8a3 3 0 1 0-3-3M3 12h12a3 3 0 1 1-3 3M3 16h6"/></svg>Hysteria</button>
    <div class="nav-group">Списки и поиск</div>
  <button id="btn-bt" class="tab-btn
    {% if active=='bt' %}active{% endif %}"
    onclick="go('bt')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V4m-6 4a9 9 0 0 1 12 0M9 13h.01M15 13h.01"/></svg> Бот</button>
  <button id="btn-lk" class="tab-btn
    {% if active=='lk' %}active{% endif %}"
    onclick="go('lk')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><circle cx="10" cy="10" r="6"/><path d="m21 21-6-6"/></svg> Поиск</button>
    <div class="nav-group">Система</div>
  <button id="btn-upd" class="tab-btn
    {% if active=='upd' %}active{% endif %}"
    onclick="go('upd')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12a9 9 0 1 1-2.6-6.3M21 3v6h-6"/></svg> Обновления</button>
  <button id="btn-dns" class="tab-btn
    {% if active=='dns' %}active{% endif %}"
    onclick="go('dns')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 22s8-3.6 8-10V5l-8-3-8 3v7c0 6.4 8 10 8 10z"/><path d="m9 11.5 2 2 4-4.5"/></svg> DNS</button>
  <button id="btn-cfg" class="tab-btn
    {% if active=='cfg' %}active{% endif %}"
    onclick="go('cfg')"><svg class="ico" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2"/><circle cx="15" cy="17" r="2"/></svg> Конфиги</button>
  </nav>
  <div class="side-foot">
    <span class="live-dot"></span>LAN &middot; Wi-Fi &middot; WG
  </div>
</aside>
<div class="main">
{% set PT={'ss':'Shadowsocks',
  'tr':'Trojan','vl':'VLESS','to':'Tor',
  'hy':'Hysteria','bt':'Бот — список обхода',
  'lk':'Поиск пулов','upd':'Обновления',
  'dns':'DNS-безопасность',
  'cfg':'Конфигурации'} %}
<header class="page-head">
  <h1 class="page-title"
    id="page-title">{{ PT[active] }}</h1>
  <span class="hd-pill ghost" id="hd-mode">DNS —</span>
  <span class="hd-pill ghost" id="hd-verdict">проверка подмены —</span>
  <span class="hd-time" id="hd-time"></span>
  <button id="themeBtn" class="icon-btn" type="button" title="Тёмная/светлая тема"
    aria-label="Переключить тему" aria-pressed="false" onclick="toggleTheme()">
    <svg class="ico ico-sun" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>
    <svg class="ico ico-moon" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>
  </button>
</header>
<div id="update-bar"></div>
<div id="pin-bar"></div>
{% with msgs = get_flashed_messages(
  with_categories=true) %}
{% if msgs %}{% for cat, msg in msgs %}
<div class="msg {{ 'msg-ok'
  if cat=='ok' else 'msg-err' }}">
  {{ msg }}</div>
{% endfor %}{% endif %}{% endwith %}
<div class="card">
  {% for tid, tname, fkey in [
    ('ss','Shadowsocks','shadowsocks'),
    ('tr','Trojan','trojan'),
    ('vl','VLESS','vless'),
    ('to','Tor','tor'),
    ('hy','Hysteria','hysteria')] %}
  <div id="tab-{{ tid }}"
    class="tab-content
    {% if active==tid %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span tile-ctl">
    <form method="post"
      action="{{ url_for('toggle_service',
        tab=tid) }}"
      id="tgl-{{ tid }}">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <input type="hidden" name="enabled"
        value="{{ '0' if svc_enabled[tid]
          else '1' }}">
      <div class="svc-row">
        <span class="svc-name
          {{ 'on' if svc_enabled[tid]
            else 'off' }}">
          {{ '\u25cf' }} {{ tname }}:
          {{ 'включён' if svc_enabled[tid]
            else 'отключён' }}</span>
        <label class="switch">
          <input type="checkbox"
            aria-label="Включить или отключить службу"
            {% if svc_enabled[tid] %}checked{% endif %}
            onchange="document.getElementById(
              'tgl-{{ tid }}').submit()">
          <span class="slider"></span>
        </label>
      </div>
    </form>
    <p class="hint tile-hint">
      &#128260; Отключённый протокол
      останавливается сразу и <b>не запустится
      после перезагрузки</b> (ENABLED=no
      в init-скрипте); включение — только
      этим переключателем. Конфигурация
      и ключи сохраняются.</p>
    </div>
    {% if tid == 'to' %}
    <div class="tile tile-span">
    <form method="post"
      action="{{ url_for('key_to') }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <div class="subhead">
        &#128274; obfs4</div>
      <label>Мосты (по одному)</label>
      <textarea name="obfs4_bridges"
        class="key-area"
        placeholder="obfs4 ..."></textarea>
      <div class="subhead subhead-gap">
        &#127760; Webtunnel</div>
      <label>Мосты (по одному)</label>
      <textarea name="webtunnel_bridges"
        class="key-area"
        placeholder="webtunnel ..."></textarea>
      <button type="submit"
        class="btn btn-key">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128273; Применить</span>
      </button>
    </form>
    </div>
    {% else %}
    <div class="tile">
    <form method="post"
      action="{{ url_for('key_'+tid) }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <label>Ключ {{ tname }}</label>
      <input type="text" name="key"
        placeholder="Ключ {{ tname }}">
      <p class="hint">
        Формат {{ tname }}</p>
      <button type="submit"
        class="btn btn-key">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128273; Применить ключ</span>
      </button>
    </form>
    </div>
    <div class="tile">
    <form method="post"
      action="{{ url_for('config_'+tid) }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <label>config.json</label>
      <textarea name="config_data"
        class="key-area config-entry"
        spellcheck="false"
        placeholder='{"outbounds":[...]}'></textarea>
      <p class="hint">
        Содержимое config.json.
        Inbound заменяется.</p>
      <button type="submit"
        class="btn btn-cfg">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128196; Применить конфиг</span>
      </button>
    </form>
    </div>
    {% endif %}
    <div class="tile tile-span">
    <div class="divider">
      <span>&#128195;
        {{ fkey }}.txt &mdash;
        {{ list_details[tid] }}</span>
    </div>
    <form method="post"
      action="{{ url_for('list_'+tid) }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <label>Список
        ({{ ipsets[tid] }})</label>
      <textarea name="content"
        class="list-area"
        id="ta-{{ tid }}">{{ contents[tid] }}</textarea>
      <div class="counter"
        id="cnt-{{ tid }}"></div>
      <p class="hint">
        <code>#Секция</code>
        <code>site.com #заметка</code>
        <code>1.2.3.0/24</code></p>
      <button type="submit"
        class="btn btn-save">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128190; Сохранить</span>
      </button>
    </form>
    </div>
  </div>
  </div>
  {% endfor %}
  <div id="tab-bt" class="tab-content
    {% if active=='bt' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="info-box">
      &#129302; <b>Обход роутера</b><br>
      Выходной трафик &rarr; протокол из блока ниже<br>
      (по умолчанию xray :10810).<br>
      &#9888;&#65039; Не IP VPS!<br>
      &#128204; Совпадения ОК.</div>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>&#128737;&#65039; Протокол для трафика роутера</span></div>
    <div class="rp-row">
      <button type="button" class="btn rp-btn" id="rp-vl"
        onclick="setRouterProto('vl')">VLESS :10810</button>
      <button type="button" class="btn rp-btn" id="rp-tr"
        onclick="setRouterProto('tr')">Trojan :10829</button>
      <button type="button" class="btn rp-btn" id="rp-hy"
        onclick="setRouterProto('hy')">Hysteria :10830</button>
    </div>
    <p class="hint" id="rp-status"></p>
    <p class="hint">TCP/UDP идут через выбранный готовый туннель;
      если он не готов, control-plane безопасно переходит на другой
      готовый туннель. Если готовых нет — действует fail-closed, без
      прямого выхода. У TCP-only Trojan UDP явно блокируется.</p>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>&#128195; bot.txt &mdash;
        {{ list_details.bt }}</span></div>
    <form method="post"
      action="{{ url_for('list_bt') }}"
      onsubmit="return btnLock(this)">
      <input type="hidden"
        name="csrf_token"
        value="{{ csrf_token }}">
      <label>Список
        ({{ ipsets.bt }})</label>
      <textarea name="content"
        class="list-area"
        id="ta-bt">{{ contents.bt }}</textarea>
      <div class="counter"
        id="cnt-bt"></div>
      <p class="hint">
        <code>api.telegram.org</code></p>
      <button type="submit"
        class="btn btn-save">
        <span class="spinner-ring"></span>
        <span class="btn-label">
          &#128190; Сохранить</span>
      </button>
    </form>
    </div>
  </div>
  </div>
  <div id="tab-lk" class="tab-content
    {% if active=='lk' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="info-box">
      &#128269; <b>Поиск IP и CIDR</b><br>
      Введите сайт, IP, AS-номер
      или выберите сервис.</div>
    <div class="lk-presets">
      <button type="button" onclick="lkSet('telegram')">
        Telegram</button>
      <button type="button" onclick="lkSet('whatsapp')">
        WhatsApp</button>
      <button type="button" onclick="lkSet('youtube')">
        YouTube</button>
    </div>
    <div class="lookup-row">
      <input type="text" id="lk-query"
        inputmode="search" enterkeyhint="search" autocomplete="off" spellcheck="false"
        placeholder="Сайт, IP, AS32934">
      <button type="button" class="btn btn-key lookup-submit"
        onclick="doLookup()">
        <span class="spinner-ring"
          id="lk-spin"></span>
        <span class="btn-label">
          &#128269;</span>
      </button>
    </div>
    </div>
    <div class="tile tile-span">
    <div id="lk-results" class="is-hidden">
      <div class="divider">
        <span>Результаты</span></div>
      <div id="lk-info" class="result-info"></div>
      <div id="lk-status" class="result-status"></div>
      <textarea id="lk-output" class="list-area result-output" readonly spellcheck="false"></textarea>
      <div class="action-row">
        <button type="button" class="btn btn-save"
          onclick="copyLookup(event)">
          &#128203; Копировать</button>
      </div>
      <div class="divider">
        <span>&#10133; Добавить выбранное
          в список обхода</span></div>
      <div id="lk-add" class="is-hidden">
        <select id="lk-add-list" class="key-area"
          style="min-height:auto;padding:.4rem;
          margin-bottom:.5rem">
          <option value="shadowsocks">shadowsocks.txt</option>
          <option value="trojan">trojan.txt</option>
          <option value="vless" selected>vless.txt</option>
          <option value="tor">tor.txt</option>
          <option value="hysteria">hysteria.txt</option>
          <option value="bot">bot.txt</option>
        </select>
        <textarea id="lk-add-entries" class="list-area compact-area" spellcheck="false"
          placeholder="По одной записи на строку:
домены, IP, CIDR"></textarea>
        <div class="action-row action-row-result">
          <button type="button" class="btn btn-save"
            onclick="addToList()">
            &#10133; Добавить в список</button>
          <span id="lk-add-result"
            class="upd-check-result"></span>
        </div>
        <p class="hint">Дубли отсекаются
          автоматически; применение — при
          ближайшем обновлении списков.</p>
      </div>
      <p class="hint">
        …или скопируйте вручную
        в список нужного протокола.</p>
    </div>
    </div>
  </div>
  </div>
  <!-- ==== PHASE2: вкладка «Обновления» (задача 3) ==== -->
  <div id="tab-upd" class="tab-content
    {% if active=='upd' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="info-box">
      &#128260; <b>Обновления протоколов</b><br>
      Автопроверка — еженедельно (вс 03:00),
      уведомление в панель и в Telegram.<br>
      Установка — только вручную кнопками ниже
      (скрипт перезапустит сервисы).</div>
    <div class="divider">
      <span>&#128270; Проверка новых версий</span></div>
    <div class="action-row action-row-auto">
      <button type="button" class="btn btn-save action-auto" id="upd-check-btn"
        onclick="updCheck()">&#128269; Проверить сейчас</button>
      <span id="upd-check-result"
        class="upd-check-result"></span>
    </div>
    <div class="upd-out" id="upd-check-out"></div>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>&#128230; Версии (архитектура:
        <span id="upd-arch">&hellip;</span>)
        — установка вручную; зелёный = актуально,<br>
        стрелка = доступно обновление</span></div>
    <div class="ver-grid open" id="ver-grid">
    <div class="dns-label">
      Протокол &mdash; Версия</div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-xray">xray</div>
      <button type="button" class="btn upd-btn"
        id="ub-xray"
        onclick="runUpd('xray','xray')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-hysteria">hysteria</div>
      <button type="button" class="btn upd-btn"
        id="ub-hysteria"
        onclick="runUpd('hysteria','hysteria')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-shadowsocks">ss</div>
      <button type="button" class="btn upd-btn"
        id="ub-shadowsocks"
        onclick="runUpd('opkg','shadowsocks')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-trojan">trojan</div>
      <button type="button" class="btn upd-btn"
        id="ub-trojan"
        onclick="runUpd('opkg','trojan')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-tor">tor</div>
      <button type="button" class="btn upd-btn"
        id="ub-tor"
        onclick="runUpd('opkg','tor')">
        &#8681; Обновить</button>
    </div>
    <div class="ver-item">
      <div class="dns-port checking"
        id="ver-dnsmasq">dnsmasq</div>
      <button type="button" class="btn upd-btn"
        id="ub-dnsmasq"
        onclick="runUpd('opkg','dnsmasq')">
        &#8681; Обновить</button>
    </div>
    <div class="upd-all-row" id="upd-all-row">
      <button type="button" class="btn upd-btn"
        id="ub-all"
        onclick="runUpd('all','all')">
        &#8681; Обновить всё</button>
    </div>
    <div class="upd-out" id="upd-out"></div>
    </div>
  </div>
  </div>
  </div>
  <!-- ==== PHASE2: вкладка «DNS-безопасность» (задача 4) ==== -->
  <div id="tab-dns" class="tab-content
    {% if active=='dns' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="info-box">
      &#128737; <b>Защита от подмены DoH/DoT</b><br>
      Автопроверка — не чаще 1 раза в 2 часа (cron).<br>
      Доверенный DoH/DoT: нет флага <code>aa</code>
      + валидный DNSSEC (<code>ad</code>). Выбирается
      самый быстрый доверенный резолвер.<br>
      Доверенных нет &rarr; резолв через живой туннель
      (VLESS &rarr; Trojan &rarr; Hysteria); всё недоступно
      &rarr; Google/Yandex DNS.<br>
      Исключения: <code>server=/зона/…</code> и Tor
      (:9053) не затрагиваются.</div>
    <div class="action-row action-row-auto">
      <button type="button" class="btn btn-save action-auto" id="spoof-check-btn"
        onclick="spoofCheck()">&#128737; Проверить сейчас</button>
      <span id="spoof-api-status"
        class="upd-check-result"></span>
    </div>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>Вердикт последней проверки</span></div>
    <div id="spoof-verdict"
      class="spoof-verdict">ещё не проверялось</div>
    <div id="spoof-meta" class="spoof-meta"></div>
    </div>
    <div class="tile tile-span">
    <div class="divider"><span>Активный резолвер</span></div>
    <div id="rs-mode" class="rs-mode">нет данных</div>
    <div id="rs-primary" class="rs-primary"></div>
    <div id="rs-order" class="spoof-ports"></div>
    <div id="rs-meta" class="spoof-meta"></div>
    </div>
    <div class="tile tile-span">
    <div class="divider">
      <span>Системные DoT/DoH-порты (40500–40511)</span></div>
    <div id="spoof-ports" class="spoof-ports"></div>
    <div class="upd-out" id="spoof-log"></div>
    </div>
  </div>
  </div>
  <!-- ==== TAB-CFG: вкладка «Конфиги» (редактор конфигураций) ==== -->
  <div id="tab-cfg" class="tab-content
    {% if active=='cfg' %}active{% endif %}">
  <div class="tiles">
    <div class="tile tile-span">
    <div class="info-box">
      &#9881; <b>Редактор конфигураций служб</b><br>
      Полный <code>*.json</code> службы: текст разбирается
      парсером, записывается в боевой файл, служба
      перезапускается. Перед записью прежний файл
      сохраняется как <code>.bak</code> рядом с ним.<br>
      VLESS: поле <code>inbounds</code> не задаётся вручную
      — сервер пересобирает его под tcp+udp TPROXY.<br>
      Tor: мосты <code>obfs4</code>/<code>webtunnel</code>
      по одному в строке (разметка из мессенджеров
      снимается); пустое поле — снять все мосты.</div>
    <div class="action-row action-row-auto action-row-tight">
      <button type="button" class="btn btn-key action-auto"
        id="cfg-reload-btn" onclick="loadCfg(true)">
        &#8635; Перечитать файлы</button>
      <span id="cfg-status"
        class="upd-check-result"></span>
    </div>
    </div>
  </div>
    {% for ck, ct in [
      ('ss','Shadowsocks'),
      ('tr','Trojan'),
      ('vl','VLESS (Xray)'),
      ('hy','Hysteria')] %}
    <details class="cfg-d"
      {% if loop.first %}open{% endif %}>
      <summary><b>{{ ct }}</b>
        <span class="cfg-path"
          id="cfg-path-{{ ck }}"></span>
        <span class="cfg-meta"
          id="cfg-meta-{{ ck }}"></span></summary>
      <textarea id="cfg-ta-{{ ck }}"
        class="cfg-ta key-area"
        spellcheck="false"
        placeholder='{"…json…"}'></textarea>
      <div class="cfg-btns">
        <button class="btn btn-key"
          onclick="cfgCheck('{{ ck }}')">
          &#10004; Проверить JSON</button>
        <button class="btn btn-save"
          id="cfg-save-{{ ck }}"
          onclick="cfgSave('{{ ck }}')">
          &#128190; Записать и перезапустить</button>
      </div>
      <div class="upd-out"
        id="cfg-out-{{ ck }}"></div>
    </details>
    {% endfor %}
    <details class="cfg-d">
      <summary><b>Tor &mdash; мосты</b>
        <span class="cfg-path"
          id="cfg-path-to"></span>
        <span class="cfg-meta"
          id="cfg-meta-to"></span></summary>
      <textarea id="cfg-ta-to"
        class="cfg-ta key-area"
        
        spellcheck="false"
        placeholder="obfs4 1.2.3.4:443 …&#10;webtunnel 1.2.3.4:443 url=…"></textarea>
      <div class="cfg-btns">
        <button class="btn btn-save"
          id="cfg-save-to"
          onclick="cfgSave('to')">
          &#128190; Сохранить мосты
          и перезапустить</button>
      </div>
      <div class="upd-out"
        id="cfg-out-to"></div>
    </details>
  </div>
</div>
<div class="dns-panel">
  <button type="button" class="dns-toggle"
    onclick="toggleDns()">
    &#128268; DNS (DoT/DoH)</button>
  <div class="dns-grid" id="dns-grid">
    <div class="dns-label">DoT</div>
    {% for p in dns_dot_ports %}
    <div class="dns-port checking"
      id="dp-{{ p }}">{{ p }}</div>
    {% endfor %}
    <div class="dns-label">DoH</div>
    {% for p in dns_doh_ports %}
    <div class="dns-port checking"
      id="dp-{{ p }}">{{ p }}</div>
    {% endfor %}
    <div class="dns-label is-hidden" id="pin-label">
      Закреплённые адреса серверов</div>
    <div class="pin-box" id="pin-box"></div>
  </div>
</div>
<div class="dns-panel">
  <button type="button" class="dns-toggle"
    onclick="goVer()">
    &#128230; Версии и обновления &rarr;</button>
</div>
</div>
</div>
<script>
/* Файл отдаётся роутером на каждый запрос страницы, поэтому русский
   текст пишется напрямую (страница в UTF-8), а не \uXXXX-кодами:
   так короче и не тратится время на разбор escape-последовательностей.
   Повторяющиеся операции вынесены в g/each/setCell. */
function g(i){return document.getElementById(i)}
function each(a,f){for(var i=0;i<a.length;i++)f(a[i])}
/* Переключение вкладок без перезагрузки страницы: все вкладки уже
   отрисованы в DOM. Прежний вариант (location.href) заставлял роутер
   на каждый клик заново читать все списки обхода, считать записи и
   формировать 30 КБ HTML. Теперь запрос к роутеру не уходит вовсе,
   а адрес правится через history — ссылка остаётся рабочей. */
function go(id){
  var i,el,tabs=document.querySelectorAll('.tab-content'),
  btns=document.querySelectorAll('.tab-btn');
  for(i=0;i<tabs.length;i++)
    tabs[i].classList.remove('active');
  for(i=0;i<btns.length;i++)
    btns[i].classList.remove('active');
  el=g('tab-'+id);
  if(!el){location.href='/?tab='+id;return}
  el.classList.add('active');
  el=g('btn-'+id);
  if(el)el.classList.add('active');
  if(window.history&&history.replaceState)
    history.replaceState(null,'','/?tab='+id);
  window.scrollTo(0,0);
  if(id==='cfg')loadCfg(false);
  if(id==='upd')fetchVer();
  var pb=g('btn-'+id),pt=g('page-title');
  if(pb&&pt)pt.textContent=pb.textContent.trim()}
function jget(u,cb){fetch(u,{credentials:'same-origin',cache:'no-store'}).then(function(r){
  if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}).then(cb).catch(function(){})}
/* Экранирование перед вставкой в innerHTML: значения приходят из
   /api/lookup и содержат пользовательский ввод (домен из поля поиска).
   Без этого строка вида "<img src=x onerror=...>.com" выполнялась
   как HTML — подтверждённый XSS. */
function esc(v){
  return String(v==null?'':v)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;')
    .replace(/'/g,'&#39;')}
function setCell(el,cls,txt){
  if(!el)return;el.className='dns-port '+cls;
  el.textContent=txt}

each(['ss','tr','vl','to','hy','bt'],function(id){
  var ta=g('ta-'+id),cnt=g('cnt-'+id);
  if(!ta||!cnt)return;
  function u(){cnt.textContent='Стр: '+
    ta.value.split('\n').length}
  ta.addEventListener('input',u);u()});

function btnLock(f){
  var b=f.querySelector('.btn');
  if(!b||b.classList.contains('loading'))
    return false;
  b.classList.add('loading');
  b.disabled=true;return true}

var _poll=null,_ld=0;
function pollUpdate(){
  jget('/api/update-status',function(d){
    var bar=g('update-bar'),
    now=Math.floor(Date.now()/1000);
    function stop(){if(_poll){
      clearInterval(_poll);_poll=null}}
    if(d.status==='running'){
      var e=now-(d.ts||now);if(e<0)e=0;
      bar.className='running';
      bar.textContent='\u23F3 Обновление… '+e+'с';
      bar.style.display='block';
      if(!_poll)_poll=setInterval(pollUpdate,2000);
    }else if(d.status==='done'){
      if(d.ts>_ld){_ld=d.ts;
        // F7 (аудит rev5 #1): done с сообщением (RULES MISSING, optional
        // VPN failed) — не зелёный успех: жёлтая плашка с текстом
        // предупреждения, чтобы утечка мимо правил не маскировалась.
        // F8 (аудит-6 L-1): replace убирал только «ok; » — голое «ok»
        // (типовой ответ успеха подshell-конфигуратора) само становилось
        // ложным жёлтым предупреждением. Сравниваем явно до замены.
        var _wm=(d.message||'');
        if(_wm==='ok')_wm='';
        else _wm=_wm.replace(/^ok;\s*/,'');
        if(_wm){bar.className='warn';
          bar.textContent='\u26A0\uFE0F Готово, с предупреждением: '+_wm;
        }else{bar.className='done';
          bar.textContent='\u2705 Готово';}
        bar.style.display='block';
        setTimeout(function(){
          bar.style.display='none'},10000)}
      stop();
    }else if(d.status==='error'&&d.ts&&
        (now-d.ts)<120){
      bar.className='error';
      bar.textContent='\u274C '+(d.message||'');
      bar.style.display='block';stop();
    }else{stop()}})}
pollUpdate();

/* Доступность серверов обхода: плашка показывается, пока проблема не
   устранена. Проверка выполняется в unblock_dnsmasq.sh (крон, подъём
   WAN, смена ключа), панель лишь отображает её результат. */
function pollPin(){
  jget('/api/pin-status',function(d){
    var b=g('pin-bar');
    if(!b||!d)return;
    if(d.kind==='warn'&&d.message){
      b.className='warn';
      b.textContent=d.message;
    }else if(d.kind==='ok'&&d.message){
      b.className='ok';
      b.textContent=d.message;
      setTimeout(function(){
        b.className='';b.style.display='none'},15000);
    }else{
      b.className='';b.style.display='none';
    }
  })}
var _pinPoll=null;
function startPinPoll(){
  if(_pinPoll||document.hidden)return;
  _pinPoll=setInterval(function(){if(!document.hidden)pollPin()},120000)
}
pollPin();startPinPoll();
document.addEventListener('visibilitychange',function(){
  if(document.hidden){clearInterval(_pinPoll);_pinPoll=null}
  else{pollPin();startPinPoll()}
});

var DNS_PORTS={{ dns_ports|tojson }};
var _dO=false;
function toggleDns(){
  var el=g('dns-grid');_dO=!_dO;
  el.className=_dO?'dns-grid open':'dns-grid';
  if(_dO)fetchDns()}
function fetchDns(){
  each(DNS_PORTS,function(p){
    setCell(g('dp-'+p),'checking',p+'…')});
  jget('/api/dns-status',function(d){
    each(['dot','doh'],function(t){
      if(!d[t])return;
      each(Object.keys(d[t]),function(p){
        var info=d[t][p],
            ok=typeof info==='boolean'?info:!!info.ok,
            secure=typeof info==='object'&&!!info.secure,
            state=typeof info==='object'?(info.state||''):'',
            cls=secure?'ok':(ok?'insecure':'fail');
        setCell(g('dp-'+p),cls,
          p+(secure?' \u2713 DNSSEC':
            (ok?' \u2248 DNS':' \u2717 DNS')));
        if(g('dp-'+p)&&typeof info==='object')
          g('dp-'+p).title=state+'; '+
            (info.detail||'')})});
    /* Пин показывается, только если адрес сервера задан доменом:
       при заданном IP закреплять нечего и блок остаётся скрытым. */
    var pb=g('pin-box'),pl=g('pin-label'),
        pin=d.pinned||[];
    if(pb&&pl){
      if(pin.length){
        var t='';
        each(pin,function(x){
          t+=esc(x.host)+' \u2192 '+esc(x.ip)+'\n'});
        pb.textContent=t.replace(/\n$/,'');
        pb.className='pin-box on';
        pl.className='dns-label';
        pl.style.display='';
      }else{
        pb.className='pin-box';
        pl.style.display='none';
        pl.className='dns-label is-hidden';
      }}})}

var VER_NAMES=['xray','hysteria','shadowsocks',
  'trojan','tor','dnsmasq'];
var _vO=false;
/* ── Обновление протоколов ───────────────────────────────────────
   Скрипт работает минутами, поэтому запрос лишь стартует его,
   а прогресс подтягивается опросом /api/proto-update-status. */
var _updTimer=null;
/* Показ/скрытие кнопки обновления конкретного протокола. */
function updBtnShow(name,on){
  var b=g('ub-'+name);
  if(b)b.className='btn upd-btn'+(on?' on':'')}
/* Блокировка всех кнопок на время работы обновления. */
function updBtns(off){
  each(VER_NAMES.concat(['all']),
    function(a){var b=g('ub-'+a);
      if(b)b.disabled=off})}
function updShow(txt){
  var o=g('upd-out');if(!o)return;
  o.className='upd-out on';
  /* Вывод скрипта попадает в DOM — экранируем. */
  o.textContent=txt}
function updPoll(){
  fetch('/api/proto-update-status',
    {credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(d){
    var log=d.log||'';
    var head=d.status==='running'
      ? 'Выполняется…'
      : (d.status==='done'
         ? 'Готово' : 'Ошибка: '+(d.message||''));
    updShow(head+(log?'\n\n'+log:''));
    if(d.status==='running')return;
    clearInterval(_updTimer);_updTimer=null;
    updBtns(false);
    /* Версии могли измениться — перечитываем. */
    fetchVer()})
  .catch(function(){})}
function runUpd(action,label){
  if(_updTimer)return;
  if(!confirm('Запустить обновление: '
    +(label||action)
    +'?\nСервисы будут перезапущены.'))return;
  updBtns(true);
  updShow('Запуск…');
  var b=new FormData();
  b.append('action',action);
  b.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  fetch('/update/run',
    {method:'POST',body:b,
     credentials:'same-origin'})
  .then(function(r){return r.json()
    .then(function(j){return {ok:r.ok,j:j}})})
  .then(function(res){
    if(!res.ok||!res.j.ok){
      updShow('Ошибка: '
        +(res.j.error||'неизвестная'));
      updBtns(false);return}
    _updTimer=setInterval(updPoll,2000);
    updPoll()})
  .catch(function(e){
    updShow('Ошибка сети: '+e);
    updBtns(false)})}
function toggleVer(){
  var el=g('ver-grid');_vO=!_vO;
  el.className=_vO?'ver-grid open':'ver-grid';
  if(_vO)fetchVer()}
function fetchVer(){
  each(VER_NAMES,function(n){
    setCell(g('ver-'+n),'checking',n+'…')});
  jget('/api/protocol-versions',function(d){
    var _ua=g('upd-arch');
    if(_ua&&d.arch)_ua.textContent=d.arch;
    if(d.ts){
      var _tt=g('upd-check-result');
      if(_tt&&!_tt.textContent)
        _tt.textContent='последняя проверка: '+fmtTs(d.ts)}
    if(!d.versions)return;
    var u={},src={},gh=d.github_only||{},any=false;
    if(d.updates)each(d.updates,function(x){
      u[x.name]=x.available;src[x.name]=x.source});
    each(Object.keys(d.versions),function(n){
      /* github_only — справочная версия для протоколов, которые
         обновляются только через opkg. Заполняется, лишь если на
         GitHub появилась сборка под архитектуру роутера. */
      var v=d.versions[n],nv=u[n],
      /* Источник показывается рядом с версией: пользователь видит,
         откуда придёт обновление — с GitHub или из репозитория
         Entware. Для xray и hysteria выбирается более свежая. */
      s=src[n]?' ('+src[n]+')':'';
      if(nv){
        setCell(g('ver-'+n),'fail',n+': '+v+' \u2192 '+nv+s);
        /* Кнопка появляется только у того протокола, для которого
           обновление действительно найдено. */
        updBtnShow(n,true);any=true;
      }else if(gh[n]&&gh[n]!==v){
        /* Обновление доступно на GitHub, но ставится только из opkg. */
        setCell(g('ver-'+n),'ok',
          n+': '+v+' (GitHub: '+gh[n]+')');
        updBtnShow(n,false);
      }else{
        setCell(g('ver-'+n),'ok',n+': '+v);
        updBtnShow(n,false);
      }});
    /* «Обновить всё» имеет смысл лишь когда есть что обновлять. */
    var ar=g('upd-all-row');
    if(ar)ar.className=any?'upd-all-row on':'upd-all-row'})}

/* ── PHASE2: вкладка «Обновления» ────────────────────────────
   Ручной запуск проверки версий (check_updates.sh) через общий
   фон-раннер; вкладка «DNS» — такой же запуск dns_spoof_check.sh. */
function goVer(){go('upd');fetchVer()}
var _chkT=null;
function chkPoll(kind,onDone){
  jget('/api/check-status?kind='+kind,function(d){
    var out=g(kind==='updates'
      ?'upd-check-out':'spoof-log');
    var msg=g(kind==='updates'
      ?'upd-check-result':'spoof-api-status');
    if(!d||!d.status)return;
    if(out){out.className='upd-out on';
      out.textContent=(d.log||'').slice(-3000)}
    if(msg)msg.textContent=
      d.status==='running'?'выполняется…':
      (d.status==='done'?'готово':
       d.status==='error'
        ?'ошибка: '+(d.message||''):'');
    if(d.status==='running')return;
    clearInterval(_chkT);_chkT=null;
    var btn=g(kind==='updates'
      ?'upd-check-btn':'spoof-check-btn');
    if(btn)btn.disabled=false;
    if(onDone)onDone()})}
function chkRun(kind){
  if(_chkT)return;
  var btn=g(kind==='updates'
    ?'upd-check-btn':'spoof-check-btn');
  if(btn)btn.disabled=true;
  var fd=new FormData();fd.append('kind',kind);
  fd.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  fetch('/check/run',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(j){
    if(!j.ok){
      var msg=g(kind==='updates'
        ?'upd-check-result':'spoof-api-status');
      if(msg)msg.textContent=j.error||'ошибка';
      if(btn)btn.disabled=false;return}
    _chkT=setInterval(function(){
      chkPoll(kind,kind==='updates'
        ?fetchVer:fetchSpoof)},3000);
    chkPoll(kind,null)})
  .catch(function(){if(btn)btn.disabled=false})}
function updCheck(){chkRun('updates')}
function spoofCheck(){chkRun('dns-spoof')}

/* ── PHASE2: вкладка «DNS-безопасность» ──────────────────────
   Читает /api/dns-spoof (json dns_spoof_check.sh). */
var _SP_TEXT={
  'LOCAL_DNSSEC':'OK: доверенный DoH/DoT',
  'LOCAL_INSECURE':'внимание: обычный DNS без DNSSEC',
  'TUNNEL_DNS':'резолвинг через туннель',
  'BOOTSTRAP_PUBLIC':'аварийный режим: Google/Yandex DNS',
  'DNS_DEAD':'DNS недоступен',
  'unknown':'ещё не проверялось'};
function fmtTs(t){
  if(!t)return '—';
  try{return new Date(t*1000).toLocaleString()}
    catch(e){return '—'}}
function fetchSpoof(){
  jget('/api/dns-spoof',function(d){
    var v=g('spoof-verdict');if(!v)return;
    var cls='ok';
    if(d.verdict==='LOCAL_INSECURE'
       ||d.verdict==='TUNNEL_DNS')cls='warn';
    else if(d.verdict==='BOOTSTRAP_PUBLIC'
       ||d.verdict==='DNS_DEAD')cls='bad';
    v.className='spoof-verdict '+cls;
    v.textContent=_SP_TEXT[d.verdict]
      ||d.verdict||'нет данных';
    var _hd=g('hd-verdict');
    if(_hd){_hd.className='hd-pill '+cls;
      _hd.textContent=_SP_TEXT[d.verdict]||d.verdict||'нет данных';}
    var m=g('spoof-meta');
    if(m){
      var bits=[];
      bits.push('проверено: '+fmtTs(d.ts));
      if(d.fastest)bits.push('самый быстрый доверенный: '+d.fastest);
      if(d.tunnel_proto)bits.push('туннель: '+d.tunnel_proto);
      if(d.suspected_spoof&&d.suspected_spoof.length)
        bits.push('\u26A0\uFE0F подмена на портах: '
          +d.suspected_spoof.join(', '));
      if(d.bootstrap_servers&&d.bootstrap_servers.length)
        bits.push('fallback: '+d.bootstrap_servers.join(', '));
      m.textContent=bits.join(' | ')}
    var grid=g('spoof-ports');
    if(grid&&d.ports){
      var h='';
      each(Object.keys(d.ports).sort(),function(k){
        var p=d.ports[k],pc='bad',label='недоступен';
        if(p.rc===0){pc='ok';
          label='доверен, '+p.rtt+'мс'}
        else if(p.rc===2){pc='warn';
          label='без DNSSEC, '+p.rtt+'мс'}
        if(p.reason==='authoritative'){
          pc='bad';
          label='\u26A0\uFE0F ПОДМЕНА (aa)'}
        h+='<div class="spoof-port"><span>'+esc(k)
          +'</span><span class="'+pc+'">'+label
          +'</span></div>'});
      grid.innerHTML=h}
    fetchResolver()})}
var _RS_MODE={
  'LOCAL_DNSSEC':['ok','локальный шифрованный DNS (DNSSEC)'],
  'DNS_OK_NO_DNSSEC':['warn','обычный DNS без DNSSEC'],
  'LOCAL_INSECURE':['warn','обычный DNS без DNSSEC'],
  'TUNNEL_DNS':['warn','DNS через туннель'],
  'DNS_UNAVAILABLE':['bad','DNS недоступен'],
  'DNS_UNAVAILABLE_FALLBACK':['bad',
    'DNS недоступен (аварийный 40500)'],
  'BOOTSTRAP_PUBLIC':['bad',
    'аварийный режим: публичный DNS'],
  'DNS_DEAD':['bad','DNS мёртв']};
/* R6 «Активный резолвер»: читает /api/dns-resolver (решение
   последнего DNS-цикла + имена upstream'ов из show dns-proxy).
   Новых DNS-прогонов не добавляет — только чтение state-файлов. */
function fetchResolver(){
  jget('/api/dns-resolver',function(d){
    var m=g('rs-mode');if(!m||!d)return;
    if(!d.ok){
      m.className='rs-mode';
      m.textContent='нет данных — DNS-цикл ещё не выполнялся';
      return}
    var mm=_RS_MODE[d.mode]||['',d.mode||'неизвестно'];
    m.className='rs-mode '+mm[0];
    m.textContent=mm[1]+(d.tunnel?(' · '+d.tunnel):'');
    var _hm=g('hd-mode');
    if(_hm){_hm.className='hd-pill '+(mm[0]||'ghost');
      _hm.textContent=d.mode||'нет данных';}
    var _ht=g('hd-time');
    if(_ht)_ht.textContent='цикл DNS: '+(d.ts_state?fmtTs(d.ts_state):'—');
    var pr=g('rs-primary'),pinfo=null,ix;
    if(d.ports)for(ix=0;ix<d.ports.length;ix++)
      if(d.ports[ix].port===d.primary)pinfo=d.ports[ix];
    if(pr){
      var prtext=d.primary
        ?('активный: '+d.primary
          +(pinfo&&pinfo.name?(' ('+pinfo.name+')'):'')
          +(pinfo&&pinfo.kind?(', '+pinfo.kind):'')
          +(d.primary_rtt?(' · '+d.primary_rtt+' мс'):''))
        :'активный резолвер не выбран';
      pr.textContent=prtext}
    var og=g('rs-order');
    var _fresh=!!(d.ts_spoof&&d.ts_state
      &&d.ts_spoof>d.ts_state);
    if(og){
      var h='';
      if(d.ports)for(ix=0;ix<d.ports.length;ix++){
        var p=d.ports[ix],
          sc=p.state==='secure'?'ok'
            :(p.state==='insecure'?'warn':'bad'),
          lb=(ix===0&&p.port===d.primary)
            ?'основной':('резерв '+ix),
          rt=p.rtt?(p.rtt+'мс'):'—';
        h+='<div class="spoof-port"><span>'+esc(p.port)
          +(p.kind?(' '+esc(p.kind)):'')
          +' · '+(p.name?esc(p.name)
            :'<span class="mut">без имени</span>')
          +'</span><span class="'+sc
            +(_fresh?' rs-ver':'')+'" title="'+esc(
            _fresh?'проверка свежее цикла: '+fmtTs(d.ts_spoof):'')+'">'
          +lb+' · '+rt+(_fresh?' ✓':'')+'</span></div>'}
      og.innerHTML=h
        ||'<div class="spoof-meta">порядок пуст</div>'}
    var mt=g('rs-meta');
    if(mt){
      var bits=[];
      bits.push('резерв по циклу: '+(d.ts_state?fmtTs(d.ts_state):'—'));
      bits.push('проверка портов: '+(d.ts_spoof?fmtTs(d.ts_spoof):'—'));
      if(_fresh)bits.push('\u26A0\uFE0F проверка свежее цикла —'
        +' порядок резервов пересчитается при ближайшем цикле');
      bits.push(d.names_from_ndm
        ?'имена: ndmc show dns-proxy'
        :'имена резолверов не определены (ndmc)');
      if(d.suspected&&d.suspected.length)
        bits.push('\u26A0\uFE0F подмена: '
          +d.suspected.join(', '));
      mt.textContent=bits.join(' | ')}
  })}
function lkSet(v){g('lk-query').value=v;doLookup()}
function doLookup(){
  var q=g('lk-query').value.trim();
  if(!q)return;
  var sp=g('lk-spin');
  sp.style.display='inline-block';
  var fd=new FormData();fd.append('query',q);
  fd.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  fetch('/api/lookup',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(d){
    sp.style.display='none';
    g('lk-results').style.display='block';
    var dn=d.domains||[],ips=d.ips||[],
    cid=d.cidrs||[],inl=d.in_lists||{},
    miss=d.missing||[],fnd=d.found||[],
    cov=d.covered||{};
    g('lk-info').textContent='Сайты: '+dn.length+
      ' | IP: '+ips.length+
      ' | CIDR: '+cid.length;
    /* RDAP/RIPEstat-обогащение (задача 5):
       CIDR владельца, ASN, организация. */
    var ipi=d.ipinfo||{},_ik=Object.keys(ipi);
    if(_ik.length){
      var rh='<div style="margin:.4rem 0">';
      each(_ik,function(ip){
        var o=ipi[ip],parts=[];
        if(o.prefix)parts.push('префикс '+o.prefix);
        else if(o.rdap_cidr)
          parts.push('CIDR '+o.rdap_cidr);
        if(o.asn)parts.push(o.asn);
        if(o.as_holder)parts.push(o.as_holder);
        else if(o.org)parts.push(o.org);
        rh+='<div style="font-size:.75rem;'
          +'color:var(--muted)">'
          +esc(ip)+' &rarr; '
          +esc(parts.join(' | ')||'—')
          +'</div>'});
      rh+='</div>';
      g('lk-info').insertAdjacentHTML(
        'afterend',rh)}
    var h='<div style="font-size:.8rem">';
    if(fnd.length){
      h+='<div style="color:var(--green);'+
        'margin-bottom:.3rem">\u2705 В списках: '+
        fnd.length+'</div>';
      each(Object.keys(inl),function(k){
        h+='<span style="color:var(--green);'+
          'font-size:.72rem">  '+esc(k)+'.txt: '+
          esc(inl[k].join(', '))+'</span><br>'});
      var ck=Object.keys(cov);
      if(ck.length){
        h+='<div style="color:var(--accent);'+
          'font-size:.72rem;margin-top:.2rem">'+
          '\u2139\uFE0F Покрыты:</div>';
        each(ck,function(k){
          h+='<span style="color:var(--accent);'+
            'font-size:.72rem">  '+esc(k)+' \u2192 '+
            esc(cov[k])+'</span><br>'})}}
    if(miss.length)
      h+='<div style="color:var(--orange);'+
        'margin-top:.3rem">\u26A0\uFE0F Нет в '+
        'списках: '+miss.length+'</div>';
    if(!fnd.length&&!miss.length)
      h+='<span style="color:var(--muted)">'+
        'Нет данных</span>';
    g('lk-status').innerHTML=h+'</div>';
    function sortItems(a){
      var ok=[],no=[];
      each(a,function(v){
        (miss.indexOf(v)>=0?no:ok).push(v)});
      return ok.concat(no)}
    function mark(v){
      if(cov[v])return v+' #\u2705 '+cov[v];
      return v+(miss.indexOf(v)>=0?
        ' #\u26A0\uFE0F':' #\u2705')}
    var lines=[];
    function push(arr,title){
      if(!arr.length)return;
      if(lines.length)lines.push('');
      lines.push('#'+title);
      each(arr,function(v){lines.push(mark(v))})}
    var d1=sortItems(dn);
    if(d1.length){lines.push('#'+q);
      each(d1,function(v){lines.push(mark(v))})}
    push(sortItems(ips),q+' IP');
    push(sortItems(cid),q+' CIDR');
    g('lk-output').value=lines.join('\n');
    /* Форма «добавить в список»: сырые значения без пометок,
       сначала то, чего нет в списках. */
    var raw=[],_seen={};
    function _push(v){
      if(v&&!_seen[v]){_seen[v]=1;raw.push(v)}}
    each(sortItems(dn),_push);
    each(sortItems(ips),_push);
    each(sortItems(cid),_push);
    g('lk-add-entries').value=raw.join('\n');
    g('lk-add').style.display=
      raw.length?'block':'none';
    g('lk-add-result').textContent='';
  }).catch(function(e){
    sp.style.display='none';
    alert('\u274C '+e)})}

function addToList(){
  var t=g('lk-add-entries').value.trim();
  if(!t)return;
  var fd=new FormData();
  fd.append('list',g('lk-add-list').value);
  fd.append('entries',t);
  fd.append('csrf_token',
    document.querySelector(
      'input[name=csrf_token]').value);
  fetch('/api/lookup-add',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(j){
    var m=g('lk-add-result');
    if(j.ok){m.textContent='\u2705 '+(j.message||'добавлено')}
    else{m.textContent='\u274C '+(j.error||'ошибка')}})
  .catch(function(e){
    g('lk-add-result').textContent='\u274C '+e})}

function copyLookup(ev){
  var ta=g('lk-output');
  ta.select();
  ta.setSelectionRange(0,ta.value.length);
  try{
    document.execCommand('copy');
    var b=(ev||window.event).target,
    old=b.textContent;
    b.textContent='\u2705 Скопировано';
    setTimeout(function(){
      b.textContent=old},2000)
  }catch(e){}}

/* ── TAB-CFG: вкладка «Конфиги» ────────────────────────────
   Чтение/запись боевых конфигов служб через /api/cfg. Содержимое
   текстовых полей перетирается ответом сервера только при явном
   «Перечитать файлы» или после успешной записи — иначе несохранённые
   правки пользователя затирались бы фоновой перезагрузкой. */
var _CFGKIND={ss:'json',tr:'json',vl:'json',
  hy:'json',to:'bridges'};
var _CFGLOADED=false;
function loadCfg(force){
  if(_CFGLOADED&&!force)return;
  var st=g('cfg-status');
  if(st)st.textContent='чтение…';
  jget('/api/cfg',function(d){
    _CFGLOADED=true;
    if(st)st.textContent='';
    if(!d||!d.items){if(st)
      st.textContent='нет данных';return}
    for(var k in d.items){var it=d.items[k],
      ta=g('cfg-ta-'+k),me=g('cfg-meta-'+k),
      pa=g('cfg-path-'+k);
      if(pa)pa.textContent=it.path||'';
      if(ta&&(!ta.value||force))
        ta.value=it.content||'';
      if(me)me.textContent=it.exists
        ?fmtTs(it.mtime)
        :(it.error||'файла нет')}})}
function cfgCheck(k){
  var out=g('cfg-out-'+k),ta=g('cfg-ta-'+k);
  if(!out||!ta)return;
  out.className='upd-out on';
  if(_CFGKIND[k]!=='json'){
    out.textContent='мосты проверяются при записи';return}
  try{JSON.parse(ta.value);
    out.textContent='✔ JSON корректен'}
  catch(e){out.textContent='✘ JSON: '+e.message}}
function cfgSave(k){
  var ta=g('cfg-ta-'+k),out=g('cfg-out-'+k),
    btn=g('cfg-save-'+k);
  if(!ta||!out)return;
  out.className='upd-out on';
  if(_CFGKIND[k]==='json'){
    try{JSON.parse(ta.value)}
    catch(e){
      out.textContent='✘ JSON: '+e.message;return}}
  if(!window.confirm('Перезаписать конфигурацию '
     +'и перезапустить службу?'))return;
  if(btn)btn.disabled=true;
  out.textContent='запись…';
  var fd=new FormData();
  fd.append('content',ta.value);
  fd.append('csrf_token',document.querySelector(
    'input[name=csrf_token]').value);
  fetch('/api/cfg/'+k,{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()})
  .then(function(j){
    out.textContent=j.ok
      ?('✔ сохранено; '+(j.restart_ok
          ?'служба перезапущена'
          :'✘ перезапуск: '+(j.error||'?'))
        +(j.warnings&&j.warnings.length
          ?'\n⚠ '+j.warnings.join('; '):'')
        +(j.bak?'\nрезервная копия: '+j.bak:''))
      :('✘ '+(j.error||'ошибка записи'));
    if(j.ok){_CFGLOADED=false;loadCfg(true)}})
  .catch(function(){
    out.textContent='✘ ошибка связи с панелью'})
  .then(function(){if(btn)btn.disabled=false})}

/* Переключатель протокола для unblockrouter (вкладка «Бот»).
   Выбор хранится в /opt/etc/unblock/router_proto; бэкенд после записи
   сам перестраивает правила хуком — здесь только подсветка и статус. */
function paintRp(d){
  if(!d)return;
  each(['vl','tr','hy'],function(k){
    var b=g('rp-'+k);if(!b)return;
    b.className='btn rp-btn'+(d.proto===k?' active':'');
    if(d.installed&&!d.installed[k]){
      b.disabled=true;b.title='пакет не установлен'}
    else{
      b.disabled=false;
      b.title=d.ready&&d.ready[k]===false
        ?'локальный proxy-порт не готов по свежему snapshot':''}});
  var s=g('rp-status'),st=d.state||'unknown',
    eff=d.effective||d.proto||'vl',txt='выбран: '+(d.proto||'vl');
  if(st==='ready')txt+=' · local listener готов';
  else if(st==='fallback')txt+=' · tunnel failover: '+eff;
  else if(st==='blocked')txt+=' · нет готового туннеля, fail-closed';
  else txt+=d.status_stale
    ?' · статус hook устарел/отсутствует, состояние неизвестно'
    :' · состояние ещё не определено hook-ом';
  if(d.status_age!==null&&d.status_age!==undefined)
    txt+=' · возраст '+d.status_age+'с';
  if(s)s.textContent=txt}
function loadRouterProto(){jget('/api/router-proto',paintRp)}
function setRouterProto(p){
  if(!confirm('Переключить трафик роутера (unblockrouter) на '
    +p.toUpperCase()
    +'?\nПравила будут перестроены.'))return;
  var s=g('rp-status');
  if(s)s.textContent='переключаю…';
  var fd=new FormData();
  fd.append('proto',p);
  fd.append('csrf_token',document.querySelector(
    'input[name=csrf_token]').value);
  fetch('/api/router-proto',{method:'POST',body:fd,
    credentials:'same-origin'})
  .then(function(r){return r.json()
    .then(function(j){return {ok:r.ok,j:j}})})
  .then(function(res){
    if(res.j&&res.j.ok){loadRouterProto();
      if(s)s.textContent='переключено на '+p
        +' · правила применены';}
    else if(s)s.textContent='\u2718 '
      +((res.j&&res.j.error)||'ошибка')})
  .catch(function(){if(s)s.textContent=
    '\u2718 ошибка связи с панелью'})}

/* Первичное наполнение новых вкладок */
fetchSpoof();
if(g('tab-bt')&&g('tab-bt').className.indexOf('active')>=0)
  loadRouterProto();
if(g('tab-cfg')&&g('tab-cfg').className
   .indexOf('active')>=0)loadCfg(false);
g('lk-query').addEventListener('keydown',
  function(e){if(e.key==='Enter')doLookup()});
</script></body></html>'''


def _render(active='ss'):
    contents, lc = {}, {}
    ld, ipsets = {}, {}
    km = {
        'ss': 'shadowsocks',
        'tr': 'trojan',
        'vl': 'vless',
        'to': 'tor',
        'hy': 'hysteria'}
    for k in ('ss', 'tr', 'vl',
              'to', 'hy'):
        fk = km[k]
        t = read_file_text(
            BYPASS_FILES[fk])
        contents[k] = t
        d, ip, cidr = _count_entries(t)
        lc[k] = d + ip + cidr
        ld[k] = _format_details(
            d, ip, cidr)
        ipsets[k] = BYPASS_IPSETS[fk]
    bt = read_file_text(BOT_BYPASS_FILE)
    contents['bt'] = bt
    d, ip, cidr = _count_entries(bt)
    lc['bt'] = d + ip + cidr
    ld['bt'] = _format_details(
        d, ip, cidr)
    ipsets['bt'] = BYPASS_IPSETS['bot']
    return render_template_string(
        PAGE_TEMPLATE,
        active=active,
        contents=contents,
        list_counts=lc,
        list_details=ld,
        ipsets=ipsets,
        dns_dot_ports=DNS_PORTS_DOT,
        dns_doh_ports=DNS_PORTS_DOH,
        dns_ports=DNS_PORTS_DOT + DNS_PORTS_DOH,
        svc_enabled=get_services_enabled(),
        csrf_token=generate_csrf())


def _read_proto_update():
    """Статус фонового обновления протоколов."""
    try:
        with open(PROTO_UPD_STATUS, 'r') as f:
            d = json.load(f)
    except Exception:
        return {'status': 'idle', 'ts': 0,
                'message': '', 'log': ''}
    # Процесс мог быть убит, не успев записать финальный статус.
    if d.get('status') == 'running':
        age = time.time() - d.get('ts', 0)
        if age > PROTO_UPD_TIMEOUT:
            d['status'] = 'error'
            d['message'] = 'Таймаут'
    d['log'] = _tail_file(PROTO_UPD_LOG)
    return d


def _tail_file(path, limit=4000):
    try:
        with open(path, 'r') as f:
            return f.read()[-limit:]
    except Exception:
        return ''


def start_proto_update(action):
    """Запускает update_protocols.sh в фоне.

    Скрипт работает минутами, поэтому HTTP-запрос его не ждёт:
    панель опрашивает /api/proto-update-status.
    """
    if action not in ('xray', 'hysteria',
                      'opkg', 'all'):
        raise ValueError('action')

    st = _read_proto_update()
    if st.get('status') == 'running':
        age = int(time.time()
                  - st.get('ts', 0))
        raise RuntimeError(
            f'Обновление уже идёт ({age}с)')

    sc = config.paths.get(
        'update_protocols',
        '/opt/bin/update_protocols.sh')
    if not os.path.exists(sc):
        raise FileNotFoundError(sc)

    try:
        with open(PROTO_UPD_STATUS, 'w') as f:
            json.dump({
                'status': 'running',
                'ts': int(time.time()),
                'action': action,
                'message': 'Запуск...'}, f)
    except OSError as e:
        web_log(f"protocol update status write: {e}")

    # Обёртка пишет финальный статус по коду возврата скрипта,
    # а не по наличию значков в выводе.
    lines = [
        '#!/bin/sh',
        'SC=' + shlex.quote(sc),
        'ACT=' + shlex.quote(action),
        'LOG=' + shlex.quote(PROTO_UPD_LOG),
        'ST=' + shlex.quote(PROTO_UPD_STATUS),
        ': > "$LOG"',
        '"$SC" "$ACT" >> "$LOG" 2>&1',
        'RC=$?',
        'TS=$(date +%s)',
        'if [ "$RC" -eq 0 ]; then',
        '    S=done; M="Готово"',
        'else',
        '    S=error; M="Код возврата $RC"',
        'fi',
        'TMP="$ST.tmp"',
        'printf \'{"status":"%s","ts":%s,'
        '"action":"%s","message":"%s"}\\n\' '
        '"$S" "$TS" "$ACT" "$M" > "$TMP"',
        'mv -f "$TMP" "$ST"',
        'exit "$RC"',
    ]
    with open(PROTO_UPD_WRAPPER, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    os.chmod(PROTO_UPD_WRAPPER, 0o755)

    subprocess.Popen(
        ['/bin/sh', PROTO_UPD_WRAPPER],
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL)


@app.route('/api/proto-update-status')
def api_proto_update_status():
    return jsonify(_read_proto_update())


@app.route('/update/run', methods=['POST'])
def route_update_run():
    # Изменяющее состояние действие: CSRF обязателен, доступ уже
    # ограничен LAN и Basic-авторизацией.
    _check_csrf()
    action = (request.form.get('action')
              or '').strip()
    try:
        start_proto_update(action)
    except ValueError:
        return jsonify({
            'ok': False,
            'error': 'Неизвестное действие'}), 400
    except FileNotFoundError:
        return jsonify({
            'ok': False,
            'error': 'Скрипт обновления не найден'}), 500
    except RuntimeError as e:
        return jsonify({
            'ok': False, 'error': str(e)}), 409
    except Exception as e:
        logging.error('proto update: %s', e)
        return jsonify({
            'ok': False,
            'error': 'Не удалось запустить'}), 500
    return jsonify({'ok': True})


@app.route('/api/update-status')
def api_update_status():
    return jsonify(_read_update_status())


# ── Фоновые проверки (задачи 3 и 4 этапа 2) ─────────────────────────
# Унифицированный запуск «долгих» проверок по образцу
# start_proto_update: HTTP-запрос возвращается сразу, обёртка пишет
# JSON-статус по коду возврата, панель опрашивает.
BG_CHECKS = {
    'updates': config.paths.get(
        'check_updates',
        '/opt/bin/check_updates.sh'),
    'dns-spoof': '/opt/bin/dns_spoof_check.sh',
}
BG_CHECK_TIMEOUT = 900
DNS_SPOOF_JSON = '/tmp/keenzoo_dns_spoof.json'
DNS_SPOOF_LOCKDIR = '/tmp/keenzoo_dns_spoof.lockdir'


def _bg_check_paths(kind):
    return (
        f'/tmp/keenzoo_bg_{kind}.json',
        f'/tmp/keenzoo_bg_{kind}.log',
        f'/tmp/keenzoo_bg_{kind}.sh')


def _read_bg_check(kind):
    st, log, _ = _bg_check_paths(kind)
    try:
        with open(st, 'r') as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {'status': 'idle', 'ts': 0,
             'message': ''}
    if d.get('status') == 'running':
        age = time.time() - d.get('ts', 0)
        if age > BG_CHECK_TIMEOUT:
            d['status'] = 'error'
            d['message'] = 'Таймаут'
    d['log'] = _tail_file(log)
    return d


def start_bg_check(kind):
    script = BG_CHECKS.get(kind)
    if not script:
        raise ValueError('kind')
    st = _read_bg_check(kind)
    if st.get('status') == 'running':
        raise RuntimeError('Уже выполняется')
    if not os.path.exists(script):
        raise FileNotFoundError(script)
    stj, log, wrapper = _bg_check_paths(kind)
    try:
        with open(stj, 'w') as f:
            json.dump({
                'status': 'running',
                'ts': int(time.time()),
                'action': kind,
                'message': 'Запуск...'}, f)
    except OSError:
        # Каталог /tmp недоступен для записи — обёртка всё равно
        # отработает и запишет финальный статус по коду возврата.
        pass
    arg = ' manual' if kind == 'dns-spoof' else ''
    lines = [
        '#!/bin/sh',
        'SC=' + shlex.quote(script),
        'LOG=' + shlex.quote(log),
        'ST=' + shlex.quote(stj),
        ': > "$LOG"',
        f'"$SC"{arg} >> "$LOG" 2>&1',
        'RC=$?',
        'TS=$(date +%s)',
        'if [ "$RC" -eq 0 ]; then',
        '    S=done; M="Готово"',
        'else',
        '    S=error; M="Код возврата $RC"',
        'fi',
        'TMP="$ST.tmp"',
        'printf \'{"status":"%s","ts":%s,'
        '"action":"%s","message":"%s"}\\n\' '
        f'"$S" "$TS" "{kind}" "$M" > "$TMP"',
        'mv -f "$TMP" "$ST"',
        'exit "$RC"',
    ]
    with open(wrapper, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    os.chmod(wrapper, 0o755)
    subprocess.Popen(
        ['/bin/sh', wrapper],
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL)


@app.route('/check/run', methods=['POST'])
def route_check_run():
    _check_csrf()
    kind = (request.form.get('kind')
            or '').strip()
    try:
        start_bg_check(kind)
    except ValueError:
        return jsonify({
            'ok': False,
            'error': 'Неизвестная проверка'}), 400
    except FileNotFoundError:
        return jsonify({
            'ok': False,
            'error': 'Скрипт не найден'}), 500
    except RuntimeError as e:
        return jsonify({
            'ok': False, 'error': str(e)}), 409
    except Exception as e:
        logging.error('bg check: %s', e)
        return jsonify({
            'ok': False,
            'error': 'Не удалось запустить'}), 500
    return jsonify({'ok': True})


@app.route('/api/check-status')
def api_check_status():
    kind = request.args.get('kind', '')
    if kind not in BG_CHECKS:
        return jsonify({'error': 'unknown kind'}), 400
    return jsonify(_read_bg_check(kind))


@app.route('/api/dns-spoof')
def api_dns_spoof():
    """Статус проверки подмены DNS + флаг активного прогона."""
    try:
        with open(DNS_SPOOF_JSON, 'r') as f:
            d = json.load(f)
        if not isinstance(d, dict):
            raise ValueError('bad json')
    except Exception:
        d = {'ts': 0, 'verdict': 'unknown',
             'ports': {}, 'trusted': [],
             'suspected_spoof': []}
    running = False
    try:
        if os.path.isdir(DNS_SPOOF_LOCKDIR):
            pidf = os.path.join(
                DNS_SPOOF_LOCKDIR, 'pid')
            ts_file = os.path.join(
                DNS_SPOOF_LOCKDIR, 'ts')
            alive = False
            try:
                with open(pidf) as f:
                    pid = int(f.read().strip())
                os.kill(pid, 0)
                alive = True
            except (OSError, ValueError):
                # pid-файл отсутствует/битый/процесс мёртв:
                # определяем живость по времени замка.
                try:
                    with open(ts_file) as f:
                        ts_ = int(
                            f.read().strip())
                    alive = (time.time() - ts_
                             < 300)
                except (OSError, ValueError):
                    alive = False
            running = alive
    except Exception:
        running = False
    d['running'] = running
    return jsonify(d)


# ── R6 «Активный резолвер» (слит с R3: имена upstream'ов) ────────────
# Виджет вкладки «DNS-безопасность». Источники — только state-файлы
# последнего DNS-цикла (/tmp/keenzoo_dns_state от unblock_dnsmasq.sh
# и /tmp/keenzoo_dns_spoof.json от dns_spoof_check.sh) плюс один
# локальный вызов ndmc (не DNS-прогон): новых dig-запросов эндпоинт
# не добавляет (стоящее ограничение «минимум DNS-прогонов»).
DNS_STATE_FILE = '/tmp/keenzoo_dns_state'


def _read_dns_state():
    """Решение последнего цикла unblock_dnsmasq.sh (key=value)."""
    out = {}
    try:
        with open(DNS_STATE_FILE, 'r') as f:
            for line in f:
                line = line.strip()
                if '=' in line:
                    k, v = line.split('=', 1)
                    out[k] = v
    except OSError:
        pass
    return out


def _ndm_resolver_names():
    """Привязка «порт ↔ upstream» из `ndmc -c 'show dns-proxy'` (R3).

    Формат вывода зависит от прошивки, поэтому разбор защитный:
    ищем строки с портами 4050x/4051x и в ближайшем окне строк —
    адрес upstream'а (URL/хост/IP) и тип DoT/DoH. При недоступном
    ndmc или нестандартном формате возвращаем пустой словарь —
    виджет тогда показывает порты без имён.
    """
    mapping = {}
    try:
        r = subprocess.run(
            ['ndmc', '-c', 'show dns-proxy'],
            capture_output=True, text=True, timeout=5)
        out = r.stdout or ''
    except (OSError, subprocess.SubprocessError):
        return mapping
    lines = out.splitlines()
    _bad_name_re = re.compile(
        r'(^[A-Za-z]\.[A-Za-z]|\.(?:stat|conf|kv|db|cache)$)')
    port_re = re.compile(r'\b(4050[0-9]|4051[01])\b')
    name_re = re.compile(
        r'(https?://[^\s,;"\']+'
        r'|tls://[^\s,;"\']+'
        r'|\b(?:\d{1,3}\.){3}\d{1,3}\b'
        r'|\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b)')
    for i, line in enumerate(lines):
        pm = port_re.search(line)
        if not pm:
            continue
        port = pm.group(1)
        name = ''
        kind = ''
        lo = max(0, i - 4)
        hi = min(len(lines), i + 3)
        for j in range(lo, hi):
            lw = lines[j]
            if not kind:
                if re.search(
                        r'\bDoH\b|dns-query|https://', lw):
                    kind = 'DoH'
                elif re.search(r'\bDoT\b|tls://', lw):
                    kind = 'DoT'
            if not name:
                nm = name_re.search(lw)
                if nm:
                    cand = nm.group(1)
                    # loopback, сам порт, счётчики статистики
                    # (R.Sent/Q.Sent/R.Recvd) и имена файлов
                    # профилей (*.stat/*.conf/...) именем не считаются
                    if port not in cand \
                            and not cand.startswith('127.') \
                            and not _bad_name_re.search(cand):
                        name = cand
            if name and kind:
                break
        entry = mapping.get(port) or {}
        if name and not entry.get('name'):
            entry['name'] = name
        if kind and not entry.get('kind'):
            entry['kind'] = kind
        mapping[port] = entry
    return mapping


@app.route('/api/dns-resolver')
def api_dns_resolver():
    """Решение DNS-цикла + привязка портов к именам upstream'ов."""
    state = _read_dns_state()
    try:
        with open(DNS_SPOOF_JSON, 'r') as f:
            spoof = json.load(f)
        if not isinstance(spoof, dict):
            spoof = {}
    except Exception:
        spoof = {}
    spoof_ports = spoof.get('ports') or {}
    def _toi(v):
        try:
            return int(v or 0)
        except (TypeError, ValueError):
            return 0
    ts_state = _toi(state.get('ts'))
    ts_spoof = _toi(spoof.get('ts'))
    ts = max(ts_state, ts_spoof)
    names = _ndm_resolver_names()
    # Порядок: рабочий порядок последнего цикла (strict-order),
    # хвосты из spoof-проверки, в конце аварийный 40500 — как в
    # update_dnsmasq_upstreams.
    order = []
    for src in (state.get('working', ''),
                ' '.join(spoof.get('trusted') or []),
                ' '.join(spoof.get('insecure') or []),
                '40500'):
        for p in str(src).split():
            # в spoof-списках элементы хранятся как «порт:rtt»
            p = p.split(':', 1)[0]
            if p and p not in order:
                order.append(p)
    rtt = {}
    for pair in str(state.get('ranking', '')).split(','):
        if ':' in pair:
            k, v = pair.split(':', 1)
            rtt[k] = v
    primary = state.get('primary') or spoof.get('fastest') or ''
    prtt = rtt.get(primary, '')
    if not prtt and primary:
        prtt = (spoof_ports.get(primary) or {}).get('rtt')
    trusted = [x.split(':', 1)[0]
               for x in (spoof.get('trusted') or [])]
    insecure = [x.split(':', 1)[0]
                for x in (spoof.get('insecure') or [])]
    ports_out = []
    for p in order:
        sp = spoof_ports.get(p) or {}
        entry = names.get(p) or {}
        ports_out.append({
            'port': p,
            'rtt': rtt.get(p) or sp.get('rtt'),
            'state': ('secure' if p in trusted
                      else 'insecure' if p in insecure
                      else 'unknown'),
            'reason': sp.get('reason') or '',
            'egress': sp.get('egress') or '',
            'name': entry.get('name') or
                    ('системный профиль NDMS'
                     if p == '40500' else ''),
            'kind': entry.get('kind') or
                    ('DoT' if p in (
                        '40500', '40501', '40502', '40503')
                     else 'DoH'),
        })
    mode = state.get('mode') or spoof.get('verdict') or ''
    return jsonify({
        'ok': bool(state or spoof),
        'ts': ts,
        'ts_state': ts_state,
        'ts_spoof': ts_spoof,
        'mode': mode,
        'verdict': spoof.get('verdict') or '',
        'primary': primary,
        'primary_rtt': prtt,
        'tunnel': state.get('tunnel')
                  or spoof.get('tunnel_proto') or '',
        'ports': ports_out,
        'names_from_ndm': bool(names),
        'suspected': spoof.get('suspected_spoof') or [],
    })


# ── Вкладка «Конфиги»: прямое редактирование *.json служб и мостов Tor ──
# Возможность добавлена отдельной вкладкой (уточнение 2026-10-05): окно
# ввода полного config.json для Shadowsocks/Trojan/VLESS/Hysteria и
# мостов Tor (obfs4, webtunnel). Разбор JSON — apply_direct_config из
# utils.py (валидирует и «переводит» данные в боевой файл; для VLESS
# inbound-ы пересобираются под redirect+TPROXY). Перед записью прежний
# файл сохраняется как <path>.bak, после записи служба перезапускается.
# kind: 'json' — полный конфиг; 'bridges' — строки мостов Tor.
CFG_ITEMS = {
    'ss': ('Shadowsocks',
           'shadowsocks_config',
           'shadowsocks', 'shadowsocks', 'json'),
    'tr': ('Trojan', 'trojan_config',
           'trojan', 'trojan', 'json'),
    'vl': ('VLESS (Xray)', 'vless_config',
           'vless', 'vless', 'json'),
    'hy': ('Hysteria', 'hysteria_config',
           'hysteria', 'hysteria', 'json'),
    'to': ('Tor', 'tor_config',
           'tor', None, 'bridges'),
}

# Обязательные поля каждого формата проверяются «префлайтом» внутри
# apply_direct_config (utils.py): неполный конфиг не доходит до боевого
# файла, а причина возвращается ошибкой — см. except в api_cfg_apply.


def _tor_current_bridges(path):
    """Текущие мосты из torrc (строки вида «Bridge ...»)."""
    out = []
    try:
        with open(path, 'r', encoding='utf-8',
                  errors='replace') as f:
            for ln in f:
                ln = ln.strip()
                if ln.lower().startswith('bridge '):
                    out.append(ln)
    except OSError:
        pass
    return '\n'.join(out)


@app.route('/api/cfg')
def api_cfg_read():
    """Текущее содержимое файлов конфигурации для вкладки «Конфиги»."""
    items = {}
    for key, (title, pathkey, svc, _proto,
              kind) in CFG_ITEMS.items():
        path = config.paths.get(pathkey, '')
        info = {
            'title': title, 'path': path,
            'service': svc, 'kind': kind,
            'exists': False, 'mtime': 0,
            'content': ''}
        try:
            if path and os.path.exists(path):
                st = os.stat(path)
                info['exists'] = True
                info['mtime'] = int(st.st_mtime)
                if kind == 'bridges':
                    info['content'] = \
                        _tor_current_bridges(path)
                else:
                    info['content'] = \
                        read_file_text(path)
        except OSError as e:
            info['error'] = str(e)
        items[key] = info
    return jsonify({'ok': True, 'items': items})


@app.route('/api/cfg/<which>', methods=['POST'])
def api_cfg_apply(which):
    """Записать конфигурацию (JSON или мосты Tor) и перезапустить службу."""
    _check_csrf()
    if which not in CFG_ITEMS:
        return jsonify({
            'ok': False,
            'error': 'Неизвестная цель'}), 404
    (title, pathkey, svc, proto,
     kind) = CFG_ITEMS[which]
    data = request.form.get('content') or ''
    path = config.paths.get(pathkey, '')
    if not path:
        return jsonify({
            'ok': False,
            'error': 'Путь не задан в bot_config'}), 500
    try:
        # Резервная копия прежней конфигурации (<файл>.bak, имя
        # фиксированное — перезаписывается при каждом сохранении и не
        # накапливается) создаётся централизованно в
        # ConfigWriter.write_config — только при успешной записи,
        # поэтому на провалившейся валидации .bak остаётся от прошлой
        # удачи (последний рабочий конфиг).
        if kind == 'json':
            if not data.strip():
                raise ValueError('Пустой конфиг')
            apply_direct_config(proto, data)
        else:
            # Строки мостов (obfs4/webtunnel по одному; пусто = снять
            # все мосты). tor_config пишет torrc по шаблону.
            tor_config(data)
        bak = (path + '.bak'
               if os.path.exists(path + '.bak') else '')
        err = None
        try:
            restart_service(svc)
        except Exception as e:
            log_error(f'[cfg]{which} restart: {e}')
            err = str(e)
        web_log(f'cfg {which} applied, restart '
                f'{"ok" if err is None else "FAIL"}')
        return jsonify({
            'ok': True, 'applied': True,
            'restart_ok': err is None,
            'error': err,
            'bak': bak, 'title': title})
    except Exception as e:
        log_error(f'[cfg]{which}: {e}')
        return jsonify({
            'ok': False,
            'error': str(e)}), 400


@app.route('/api/lookup-add', methods=['POST'])
def api_lookup_add():
    """Добавляет выбранные записи в список обхода протокола.

    Форма: list = shadowsocks|trojan|vless|tor|hysteria|bot,
    entries = многострочный текст. Каждая запись валидируется
    (_validate_entry), дедуплицируется по точному совпадению,
    запись атомарна (_atomic_write_text). Комментарии (#...)
    пропускаются.
    """
    _check_csrf()
    target = (request.form.get('list')
              or '').strip()
    raw = request.form.get('entries') or ''
    files = dict(config.list_files)
    if target not in files:
        return jsonify({
            'ok': False,
            'error': 'Неизвестный список'}), 400
    fp = files[target]
    added, dup, bad = [], [], []
    for line in raw.split('\n'):
        entry = (line.split('#', 1)[0]
                 .strip().lower())
        if not entry:
            continue
        if _validate_entry(entry) is None:
            bad.append(line.strip())
            continue
        if entry in dup or entry in added:
            continue
        dedup_key = entry
        existing = read_file_text(fp).lower()
        exist_entries = {
            (ln.split('#', 1)[0].strip())
            for ln in existing.split('\n')
            if ln.strip()}
        if dedup_key in exist_entries:
            dup.append(entry)
            continue
        added.append(entry)
    if bad:
        return jsonify({
            'ok': False,
            'error': 'Невалидные записи: '
                     + ', '.join(bad[:5]),
            'invalid': bad}), 400
    if not added:
        return jsonify({
            'ok': True, 'added': [],
            'duplicates': dup,
            'message': 'Всё уже есть в списке'})
    current = read_file_text(fp)
    text = current
    if text and not text.endswith('\n'):
        text += '\n'
    text += '\n'.join(added) + '\n'
    _atomic_write_text(fp, text)
    return jsonify({
        'ok': True, 'added': added,
        'duplicates': dup,
        'list': target,
        'message': (
            f'Добавлено: {len(added)}; '
            f'уже были: {len(dup)}. '
            'Применится при ближайшем '
            'обновлении списков '
            '(unblock_update).')})


@app.route('/api/dns-status')
def api_dns_status():
    return jsonify(check_dns_ports())


# Состояние доступности серверов обхода. Пишется unblock_dnsmasq.sh при
# проверке закреплённых адресов. Telegram с роутера часто заблокирован,
# поэтому панель — основной канал уведомления.
PIN_STATUS_FILE = _GS.get(
    'pin_status_file', '/tmp/keenzoo_pin_status.json')


@app.route('/api/pin-status')
def api_pin_status():
    try:
        if not os.path.exists(PIN_STATUS_FILE):
            return jsonify({'kind': 'none', 'ts': 0, 'message': ''})
        with open(PIN_STATUS_FILE, 'r') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return jsonify({'kind': 'none', 'ts': 0, 'message': ''})
        return jsonify(data)
    except (json.JSONDecodeError, IOError, ValueError):
        return jsonify({'kind': 'none', 'ts': 0, 'message': ''})


@app.route('/api/protocol-versions')
def api_protocol_versions():
    sf = config.paths.get(
        'updates_status',
        '/tmp/updates_status.json')
    if not os.path.exists(sf):
        cs = config.paths.get(
            'check_updates',
            '/opt/bin/check_updates.sh')
        if os.path.exists(cs):
            try:
                subprocess.run(
                    [cs], timeout=60, check=False)
            except (OSError, subprocess.TimeoutExpired) as e:
                web_log(f"protocol versions check: {e}")
    if os.path.exists(sf):
        try:
            with open(sf, 'r') as f:
                _d = json.load(f)
            if isinstance(_d, dict) and 'arch' not in _d:
                try:
                    _d['arch'] = os.uname().machine
                except AttributeError:
                    _d['arch'] = 'unknown'
            return jsonify(_d)
        except (OSError, ValueError, json.JSONDecodeError) as e:
            web_log(f"protocol versions status: {e}")
    return jsonify({
        'ts': 0, 'has_updates': False,
        'versions': {}, 'updates': [],
        'arch': os.uname().machine
        if hasattr(os, 'uname') else 'unknown'})


# ── Выбор протокола для трафика роутера (unblockrouter) ─────────────────
# Файл — источник выбора для 100-redirect.sh. GET отдаёт состояние и
# доступность пакетов; POST пишет файл через временный и перестраивает
# правила тем же вызовом, что и деплой (type=iptable table=nat|mangle).
ROUTER_PROTO_FILE = config.paths.get(
    'router_proto', '/opt/etc/unblock/router_proto')
ROUTER_PROTO_STATUS_FILE = '/tmp/keenzoo_router_status'
ROUTER_STATUS_MAX_AGE = 300
ROUTER_PROTOS = {
    'vl': ('S24xray', 'VLESS'),
    'tr': ('S22trojan', 'Trojan'),
    'hy': ('S57hysteria', 'Hysteria'),
}


def _router_proto_installed():
    out = {}
    for k, (initd, _lbl) in ROUTER_PROTOS.items():
        p = '/opt/etc/init.d/' + initd
        out[k] = os.path.isfile(p) and os.access(p, os.X_OK)
    return out


def _read_router_proto():
    try:
        with open(ROUTER_PROTO_FILE, 'r') as f:
            v = f.read().strip()
        if v in ROUTER_PROTOS:
            return v
    except OSError as e:
        web_log(f"router proto read: {e}")
    return 'vl'


def _router_proto_status(selected):
    """Read diagnostic-only status written atomically by netfilter hook."""
    result = {
        'effective': selected,
        'state': 'unknown',
        # None означает unknown/missing/stale. False допустим только для
        # свежего snapshot и не должен изображаться как подтверждённый down.
        'ready': {'vl': None, 'tr': None, 'hy': None},
        'status_age': None,
        'status_stale': True,
    }
    raw = {}
    try:
        with open(ROUTER_PROTO_STATUS_FILE, 'r') as f:
            for line in f:
                key, sep, value = line.strip().partition('=')
                if sep and key in {
                        'selected', 'effective', 'state',
                        'ready_vl', 'ready_tr', 'ready_hy',
                        'timestamp'}:
                    raw[key] = value
    except OSError:
        return result

    # Старый status после ручной смены файла не должен изображать новое
    # состояние: источник выбора — ROUTER_PROTO_FILE, status лишь снимок.
    if raw.get('selected') != selected:
        return result
    effective = raw.get('effective')
    state = raw.get('state')
    if effective in ROUTER_PROTOS:
        result['effective'] = effective
    if state in {'ready', 'fallback', 'blocked'}:
        result['state'] = state
    for key in ROUTER_PROTOS:
        result['ready'][key] = raw.get('ready_' + key) == '1'
    try:
        timestamp = int(raw.get('timestamp', '0'))
        if timestamp > 0:
            result['status_age'] = max(0, int(time.time()) - timestamp)
    except (TypeError, ValueError):
        pass
    age = result['status_age']
    if age is not None and age <= ROUTER_STATUS_MAX_AGE:
        result['status_stale'] = False
    else:
        result['effective'] = selected
        result['state'] = 'unknown'
        result['ready'] = {key: None for key in ROUTER_PROTOS}
    return result


def _write_router_proto(v):
    tmp = ROUTER_PROTO_FILE + '.tmp'
    with open(tmp, 'w') as f:
        f.write(v + '\n')
    os.chmod(tmp, 0o600)
    os.replace(tmp, ROUTER_PROTO_FILE)


class RedirectRebuildError(RuntimeError):
    def __init__(self, results):
        self.results = results
        summary = ', '.join(
            f"{name}=rc{item['rc']}" for name, item in results.items())
        super().__init__('netfilter hook: ' + summary)


def _hook_table_run(tbl):
    env = dict(os.environ)
    env.update({'type': 'iptable', 'table': tbl})
    process = subprocess.Popen(
        ['sh', '/opt/etc/ndm/netfilter.d/100-redirect.sh'],
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        start_new_session=True)
    timed_out = False
    try:
        out, _ = process.communicate(timeout=90)
    except subprocess.TimeoutExpired:
        timed_out = True
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            pass
        # Parent мог завершиться, оставив потомка в своей process group.
        group_alive = False
        try:
            os.killpg(process.pid, 0)
            group_alive = True
        except ProcessLookupError:
            pass
        except OSError as e:
            logging.error('netfilter hook process-group probe: %s', e)
        if group_alive:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            except OSError as e:
                logging.error('netfilter hook process-group KILL: %s', e)
        try:
            out, _ = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            out = ''
    rc = process.returncode
    if timed_out:
        rc = 124
    if rc is None:
        rc = 125
    return {
        'rc': rc,
        'timed_out': timed_out,
        'log': (out or '')[-1000:],
    }


def _rebuild_redirect():
    # Обе таблицы запускаются даже при ошибке первой: mangle может успеть
    # поставить fail-closed fallback для отказавшего nat REDIRECT.
    results = {
        tbl: _hook_table_run(tbl) for tbl in ('nat', 'mangle')
    }
    if any(item['rc'] != 0 for item in results.values()):
        raise RedirectRebuildError(results)
    return results


@app.route('/api/router-proto')
def api_router_proto():
    selected = _read_router_proto()
    status = _router_proto_status(selected)
    return jsonify({
        'proto': selected,
        'effective': status['effective'],
        'state': status['state'],
        'ready': status['ready'],
        'status_age': status['status_age'],
        'status_stale': status['status_stale'],
        'readiness_kind': 'local-listener-snapshot',
        'installed': _router_proto_installed()})


@app.route('/api/router-proto', methods=['POST'])
def api_router_proto_set():
    _check_csrf()
    v = (request.form.get('proto') or '').strip()
    if v not in ROUTER_PROTOS:
        return jsonify({
            'ok': False, 'error': 'Неизвестный протокол'}), 400
    if not _router_proto_installed().get(v):
        return jsonify({
            'ok': False,
            'error': 'Пакет ' + ROUTER_PROTOS[v][1]
                     + ' не установлен'}), 409
    try:
        _write_router_proto(v)
    except Exception as e:
        logging.error('router-proto write: %s', e)
        return jsonify({
            'ok': False, 'error': 'Не удалось записать файл'}), 500
    try:
        applied = _rebuild_redirect()
    except RedirectRebuildError as e:
        logging.error('router-proto rebuild: %s', e)
        return jsonify({
            'ok': False,
            'saved': True,
            'applied': e.results,
            'error': 'Выбор сохранён, но применение правил не '
                     'подтверждено. Проверьте hook status и выполните '
                     'nat/mangle rebuild вручную.'}), 500
    except Exception as e:
        logging.error('router-proto rebuild: %s', e)
        return jsonify({
            'ok': False,
            'saved': True,
            'error': 'Выбор сохранён, но перестройка правил '
                     'не удалась. Примените вручную: '
                     'type=iptable table=nat '
                     '/opt/etc/ndm/netfilter.d/100-redirect.sh'}), 500
    return jsonify({
        'ok': True, 'proto': v, 'saved': True, 'applied': applied})


@app.route('/api/lookup', methods=['POST'])
def api_lookup():
    # Единое CSRF-покрытие всех POST-маршрутов (ревью 2026-10-12):
    # раньше этот единственный endpoint был без проверки.
    _check_csrf()
    query = (request.form.get('query')
             or '').strip()
    if not query:
        return jsonify({
            'error': 'Пустой запрос'})
    return jsonify(
        _lookup_resource(query))


@app.route('/')
def index():
    active = request.args.get(
        'tab', 'ss')
    if active not in (
            'ss', 'tr', 'vl',
            'to', 'hy', 'bt', 'lk',
            'upd', 'dns', 'cfg'):
        active = 'ss'
    return _render(active)


@app.route('/key/ss', methods=['POST'])
def key_ss():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ SS', 'err')
        return redirect(
            url_for('index') + '?tab=ss')
    try:
        shadowsocks_config(key)
        restart_service('shadowsocks')
        flash('\u2705 SS: ключ', 'ok')
    except Exception as e:
        log_error(f'[w]ss: {e}')
        flash(f'\u274c SS — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=ss')


@app.route('/key/tr', methods=['POST'])
def key_tr():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ TR', 'err')
        return redirect(
            url_for('index') + '?tab=tr')
    try:
        trojan_config(key)
        restart_service('trojan')
        flash('\u2705 Trojan: ключ', 'ok')
    except Exception as e:
        log_error(f'[w]tr: {e}')
        flash(f'\u274c TR — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=tr')


@app.route('/key/vl', methods=['POST'])
def key_vl():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ VL', 'err')
        return redirect(
            url_for('index') + '?tab=vl')
    try:
        vless_config(key)
        restart_service('vless')
        flash('\u2705 VLESS: ключ', 'ok')
    except Exception as e:
        log_error(f'[w]vl: {e}')
        flash(f'\u274c VL — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=vl')


@app.route('/key/to', methods=['POST'])
def key_to():
    _check_csrf()
    o = (request.form.get(
        'obfs4_bridges') or '').strip()
    w = (request.form.get(
        'webtunnel_bridges') or '').strip()
    if not o and not w:
        flash('\u274c Мост', 'err')
        return redirect(
            url_for('index') + '?tab=to')
    parts = [p for p in [o, w] if p]
    try:
        tor_config('\n'.join(parts))
        restart_service('tor')
        flash('\u2705 Tor: мосты', 'ok')
    except Exception as e:
        log_error(f'[w]to: {e}')
        flash(f'\u274c Tor — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=to')


@app.route('/key/hy', methods=['POST'])
def key_hy():
    _check_csrf()
    key = (request.form.get('key')
           or '').strip()
    if not key:
        flash('\u274c Ключ HY', 'err')
        return redirect(
            url_for('index') + '?tab=hy')
    try:
        hysteria_config(key)
        restart_service('hysteria')
        flash('\u2705 Hysteria: ключ',
              'ok')
    except Exception as e:
        log_error(f'[w]hy: {e}')
        flash(f'\u274c HY — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=hy')


@app.route('/config/ss', methods=['POST'])
def config_ss():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('index') + '?tab=ss')
    try:
        apply_direct_config(
            'shadowsocks', data)
        restart_service('shadowsocks')
        flash('\u2705 SS: конфиг', 'ok')
    except Exception as e:
        log_error(f'[w]ss cfg: {e}')
        flash(f'\u274c SS — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=ss')


@app.route('/config/tr', methods=['POST'])
def config_tr():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('index') + '?tab=tr')
    try:
        apply_direct_config(
            'trojan', data)
        restart_service('trojan')
        flash('\u2705 Trojan: конфиг',
              'ok')
    except Exception as e:
        log_error(f'[w]tr cfg: {e}')
        flash(f'\u274c TR — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=tr')


@app.route('/config/vl', methods=['POST'])
def config_vl():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('index') + '?tab=vl')
    try:
        apply_direct_config(
            'vless', data)
        restart_service('vless')
        flash('\u2705 VLESS: конфиг',
              'ok')
    except Exception as e:
        log_error(f'[w]vl cfg: {e}')
        flash(f'\u274c VL — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=vl')


@app.route('/config/hy', methods=['POST'])
def config_hy():
    _check_csrf()
    data = (request.form.get(
        'config_data') or '').strip()
    if not data:
        flash('\u274c Конфиг', 'err')
        return redirect(
            url_for('index') + '?tab=hy')
    try:
        apply_direct_config(
            'hysteria', data)
        restart_service('hysteria')
        flash('\u2705 Hysteria: конфиг',
              'ok')
    except Exception as e:
        log_error(f'[w]hy cfg: {e}')
        flash(f'\u274c HY — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + '?tab=hy')


def _save_list_route(
        lk, tab, filepath=None,
        skip_global_dedup=False):
    _check_csrf()
    content = (request.form.get(
        'content') or '').strip()
    if filepath is None:
        filepath = BYPASS_FILES[lk]
    try:
        result = parse_and_save(
            filepath, content,
            skip_global_dedup=(
                skip_global_dedup))
        # Обновляем ТОЛЬКО затронутый набор: полный цикл резолвит
        # сотни доменов всех протоколов и занимает десятки секунд,
        # хотя изменился один список.
        apply_unblock_async(
            config.ipset_names.get(lk, ''))
        s = _format_details(
            result['domains'],
            result['ips'],
            result['cidr'])
        msg = f'\u2705 {lk}.txt: {s}'
        if result.get('cidr_report'):
            msg += '\n' + '\n'.join(
                result['cidr_report'])
        if result['duplicates']:
            msg += '\n' + '\n'.join(
                result['duplicates'])
        if result['errors']:
            msg += '\n' + '\n'.join(
                result['errors'])
        flash(msg, 'ok')
    except Exception as e:
        log_error(f'[w]{lk}: {e}')
        flash(f'\u274c {lk} — '
              f'{html.escape(str(e))}',
              'err')
    return redirect(
        url_for('index') + f'?tab={tab}')


@app.route('/toggle/<tab>', methods=['POST'])
def toggle_service(tab):
    _check_csrf()
    sn = TAB_TO_SERVICE.get(tab)
    if not sn:
        flash('\u274c Неизвестный протокол', 'err')
        return redirect(url_for('index'))

    want = request.form.get('enabled') == '1'
    try:
        set_service_enabled(sn, want)
        flash(
            ('\u2705 ' + sn + ' включён'
             if want else
             '\u26a0\ufe0f ' + sn + ' отключён'),
            'ok')
    except Exception as e:
        log_error(f'[w]toggle {sn}: {e}')
        flash(f'\u274c {sn} — {html.escape(str(e))}', 'err')
    return redirect(
        url_for('index') + '?tab=' + tab)


@app.route('/list/ss', methods=['POST'])
def list_ss():
    return _save_list_route(
        'shadowsocks', 'ss')


@app.route('/list/tr', methods=['POST'])
def list_tr():
    return _save_list_route(
        'trojan', 'tr')


@app.route('/list/vl', methods=['POST'])
def list_vl():
    return _save_list_route(
        'vless', 'vl')


@app.route('/list/to', methods=['POST'])
def list_to():
    return _save_list_route(
        'tor', 'to')


@app.route('/list/hy', methods=['POST'])
def list_hy():
    return _save_list_route(
        'hysteria', 'hy')


@app.route('/list/bt', methods=['POST'])
def list_bt():
    return _save_list_route(
        'bot', 'bt',
        filepath=BOT_BYPASS_FILE,
        skip_global_dedup=True)


if __name__ == '__main__':
    app.config['MAX_CONTENT_LENGTH'] = (
        MAX_CONTENT_LENGTH)
    rotate_log()
    setup_firewall(LISTEN_PORT)

    # Слушаем на всех интерфейсах: у роутера несколько внутренних адресов
    # (основная сеть, гостевая, отдельный бридж для 5 ГГц, VPN-сервер
    # прошивки). При host=LAN_IP панель отвечала только по 192.168.1.1,
    # и Wi-Fi-клиенты из другой подсети получали отказ соединения.
    # Доступ извне при этом закрыт двумя рубежами: правило DROP в INPUT
    # (setup_firewall) и проверка подсети в security_checks().
    print(
        f"\n  http://{LAN_IP}"
        f":{LISTEN_PORT}\n")
    app.run(
        host='0.0.0.0',
        port=LISTEN_PORT,
        debug=False,
        threaded=True,
        use_reloader=False)
