#!/bin/sh
# /opt/etc/ndm/fs.d/100-ipset.sh — создание наборов ipset при монтировании
# накопителя Entware, до старта сервисов и правил netfilter.
set -eu

PATH="/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

[ "${1:-}" != "start" ] && exit 0

for s in unblocksh unblocktor unblockvless unblocktroj unblockhysteria unblockrouter; do
    ipset create "$s" hash:net family inet hashsize 1024 maxelem 65536 -exist 2>/dev/null || true
done

# Копия common.sh:vpn_set_name_from_file (F1, аудит rev3) — текст
# обязан совпадать с common.sh; NDM-хук держит локальную копию,
# чтобы работать автономно, без sourcing общей библиотеки.
vpn_set_name_from_file() {
    _vsn="${1##*/}"
    _vsn="${_vsn%.txt}"
    _vsn="unblock${_vsn}"
    if [ "${#_vsn}" -gt 27 ]; then
        _vsn="$(printf '%s' "$_vsn" | cut -c1-27)"
    fi
    printf '%s\n' "$_vsn"
}

for vpn_file_names in /opt/etc/unblock/vpn-*.txt; do
    [ -f "$vpn_file_names" ] || continue
    unblockvpn="$(vpn_set_name_from_file "$vpn_file_names")"
    ipset create "$unblockvpn" hash:net family inet hashsize 1024 maxelem 65536 -exist 2>/dev/null || true
done

exit 0
