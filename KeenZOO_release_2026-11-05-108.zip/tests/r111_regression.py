#!/usr/bin/env python3
"""
r111_regression.py — регрессионный тестовый стенд для циклов r111..r115.
Проверяет:
  1. Читатель kz_enabled_scan (common.sh, 100-redirect.sh, 100-unblock-vpn.sh) по классам:
     - CRLF, exit, return, &, $1, !, "$V", [ -z "$V" ], 2>&1, ENABLED=yes true, fail-closed '?'.
     - Распространение неопределённости переменных (r185 P1-1) и last-wins восстановление (r185 P2-1).
     - Полные штатные init-скрипты S57hysteria, S35tor, S90nfqws2, S24xray, S22trojan, S56dnsmasq, S65shadowsocks.
  2. Парсер watchdog _wd_on (100-unblock-vpn.sh) по F3/P2-1 (CRLF, heredoc, last-assign, ветвления).
  3. Точный glob-парсер символьных классов (_compile_single_class) в lists_core.py по P2-2/P2-3:
     - [a-b-c], [a-c-e], [z-aZ-A], [z-a0-9], [z--a], [a--0], [z--], [a--], [z-a], [--a], [-a-c], [a-c-], POSIX-классы.
     - O(1) расход памяти на широких/Unicode диапазонах [a-\\U0010ffff].
  4. Побайтовый паритет трёх копий kz_enabled_scan.
"""

import os
import re
import subprocess
import sys
import tempfile
import unittest


def find_repo_root():
    candidates = []
    if len(sys.argv) > 1 and os.path.isdir(sys.argv[1]):
        candidates.append(sys.argv.pop(1))
    if "KEENZOO_ROOT" in os.environ:
        candidates.append(os.environ["KEENZOO_ROOT"])
    if "REPO_ROOT" in os.environ:
        candidates.append(os.environ["REPO_ROOT"])
    script_dir = os.path.dirname(os.path.abspath(__file__))
    candidates.append(os.path.dirname(script_dir))
    candidates.append(os.path.join(os.path.dirname(script_dir), "KeenZOO"))
    candidates.append(script_dir)
    candidates.append("/home/user/KeenZOO")
    candidates.append("/home/user")

    for c in candidates:
        if os.path.isfile(os.path.join(c, "opt", "bin", "common.sh")):
            return os.path.abspath(c)
        if os.path.isfile(os.path.join(c, "KeenZOO", "opt", "bin", "common.sh")):
            return os.path.abspath(os.path.join(c, "KeenZOO"))
    return os.path.abspath(os.path.dirname(script_dir))


REPO_ROOT = find_repo_root()
COMMON_SH = os.path.join(REPO_ROOT, 'opt', 'bin', 'common.sh')
REDIRECT_SH = os.path.join(REPO_ROOT, 'opt', 'etc', 'ndm', 'netfilter.d', '100-redirect.sh')
UNBLOCK_VPN_SH = os.path.join(REPO_ROOT, 'opt', 'etc', 'ndm', 'ifstatechanged.d', '100-unblock-vpn.sh')
INIT_DIR = os.path.join(REPO_ROOT, 'opt', 'etc', 'init.d')

sys.path.insert(0, os.path.join(REPO_ROOT, 'opt', 'etc', 'bot'))
import lists_core


def extract_function(filepath, func_name):
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    start_str = func_name + "() {"
    start_pos = content.find(start_str)
    assert start_pos != -1, f"Function {func_name} start not found in {filepath}"
    end_str = "' \"$1\"\n}"
    end_pos = content.find(end_str, start_pos)
    if end_pos != -1:
        end_pos += len(end_str)
        return content[start_pos:end_pos]
    # Fallback to brace matching
    m = re.search(r'\n' + re.escape(func_name) + r'\(\)\s*\{.*?\n\}', content[start_pos:], re.DOTALL)
    assert m, f"Function {func_name} not found in {filepath}"
    return m.group(0)


COMMON_SCAN_FUNC = extract_function(COMMON_SH, 'kz_enabled_scan')
REDIRECT_SCAN_FUNC = extract_function(REDIRECT_SH, 'kz_enabled_scan')
VPN_SCAN_FUNC = extract_function(UNBLOCK_VPN_SH, 'kz_enabled_scan')


def extract_wd_on(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    m = re.search(r'(_wd_on\(\)\s*\{.*?\n\})', content, re.DOTALL)
    assert m, f"_wd_on not found in {filepath}"
    return m.group(1)


WD_ON_FUNC = extract_wd_on(UNBLOCK_VPN_SH)


def run_kz_scan(func_def, script_content):
    with tempfile.NamedTemporaryFile('wb', delete=False) as tf:
        tf.write(script_content if isinstance(script_content, bytes) else script_content.encode('utf-8'))
        tname = tf.name
    try:
        sh_script = f"""{func_def}
kz_enabled_scan "{tname}"
"""
        res = subprocess.run(sh_script, shell=True, executable='/bin/sh', capture_output=True)
        out = res.stdout.decode('latin1', errors='ignore')
        if out.endswith('\n'):
            out = out[:-1]
        return out
    finally:
        if os.path.exists(tname):
            os.unlink(tname)


def run_wd_on(script_content):
    with tempfile.NamedTemporaryFile('wb', delete=False) as tf:
        tf.write(script_content if isinstance(script_content, bytes) else script_content.encode('utf-8'))
        tname = tf.name
    try:
        sh_script = f"""{VPN_SCAN_FUNC}
{WD_ON_FUNC}
_wd_on "{tname}"
echo "rc=$?"
"""
        res = subprocess.run(sh_script, shell=True, executable='/bin/sh', capture_output=True, text=True)
        return "rc=0" in res.stdout
    finally:
        if os.path.exists(tname):
            os.unlink(tname)


class TestScannerParityP4(unittest.TestCase):
    def test_scanner_copies_byte_identical(self):
        f1 = extract_function(COMMON_SH, 'kz_enabled_scan').strip()
        f2 = extract_function(REDIRECT_SH, 'kz_enabled_scan').strip()
        f3 = extract_function(UNBLOCK_VPN_SH, 'kz_enabled_scan').strip()
        self.assertEqual(f1, f2, "kz_enabled_scan in common.sh and 100-redirect.sh must be identical")
        self.assertEqual(f1, f3, "kz_enabled_scan in common.sh and 100-unblock-vpn.sh must be identical")


class TestReaderF1F2(unittest.TestCase):
    def check_all(self, content, expected):
        out_common = run_kz_scan(COMMON_SCAN_FUNC, content)
        out_redir = run_kz_scan(REDIRECT_SCAN_FUNC, content)
        out_vpn = run_kz_scan(VPN_SCAN_FUNC, content)
        self.assertEqual(out_common, expected, f"common.sh mismatch on:\n{repr(content)}\ngot={repr(out_common)}, exp={repr(expected)}")
        self.assertEqual(out_redir, expected, f"100-redirect.sh mismatch on:\n{repr(content)}\ngot={repr(out_redir)}, exp={repr(expected)}")
        self.assertEqual(out_vpn, expected, f"100-unblock-vpn.sh mismatch on:\n{repr(content)}\ngot={repr(out_vpn)}, exp={repr(expected)}")

    def test_crlf_value_not_matching(self):
        # Shell evaluates "yes\r" != "yes"
        self.check_all(b"ENABLED=yes\r\n", "yes\r")

    def test_exit_at_top_before_assign(self):
        # exit before ENABLED assignment leaves ENABLED as default no
        self.check_all("exit 0\nENABLED=yes\n", "no")

    def test_exit_after_assign_retains_enabled(self):
        # ENABLED=yes followed by exit retains yes
        self.check_all("ENABLED=yes\nexit 0\n", "yes")

    def test_return_toplevel_and_function(self):
        self.check_all("return 0\nENABLED=yes\n", "no")
        self.check_all("f() { return 1; }\nif f; then ENABLED=yes; else ENABLED=no; fi\n", "no")
        self.check_all("f() { return 0; }\nif f; then ENABLED=yes; else ENABLED=no; fi\n", "yes")

    def test_background_command_subshell(self):
        self.check_all("ENABLED=yes\nENABLED=no &\n", "yes")

    def test_positional_param_start(self):
        self.check_all('case "$1" in start) ENABLED=yes;; *) ENABLED=no;; esac\n', "yes")
        self.check_all('case "${1}" in start|restart) ENABLED=yes;; *) ENABLED=no;; esac\n', "yes")
        self.check_all('if [ "$1" = "start" ]; then ENABLED=yes; fi\n', "yes")
        self.check_all('if [ -z "$2" ]; then ENABLED=yes; fi\n', "yes")

    def test_negation_operator(self):
        self.check_all("if ! false; then ENABLED=yes; fi\n", "yes")
        self.check_all("if ! true; then ENABLED=yes; else ENABLED=no; fi\n", "no")

    def test_variable_unquoting(self):
        self.check_all('V=start\nif [ "$V" = start ]; then ENABLED=yes; fi\n', "yes")
        self.check_all('if [ -z "$NOPE" ]; then ENABLED=yes; fi\n', "yes")
        self.check_all('X=yes\nif [ -n "$X" ]; then ENABLED="$X"; fi\n', "yes")

    def test_redirection_2_gt_and_1(self):
        self.check_all("ENABLED=no\nENABLED=yes 2>&1\n", "yes")
        self.check_all("ENABLED=no\nENABLED=yes >&2\n", "yes")

    def test_temporary_prefix_assignment(self):
        self.check_all("ENABLED=no\nENABLED=yes true\n", "no")
        self.check_all("ENABLED=no\nENABLED=yes false\n", "no")
        self.check_all("ENABLED=no\nexport ENABLED=yes\n", "yes")

    def test_fail_closed_unknown_command_affecting_enabled(self):
        # unknown command in condition where ENABLED is assigned inside makes verdict '?'
        self.check_all("if pidof unknown_daemon; then ENABLED=yes; else ENABLED=no; fi\n", "?")
        self.check_all("ENABLED=no\nunknown_cmd || ENABLED=yes\n", "?")
        # unknown command that does NOT assign ENABLED does not spoil verdict
        self.check_all("ENABLED=yes\nunknown_cmd >/dev/null 2>&1 || true\n", "yes")

    def test_variable_uncertainty_propagation_p1_1(self):
        # r185 / r186 P1-1: Variable assigned inside unknown condition becomes uncertain
        self.check_all("X=no\nif /bin/false; then X=yes; fi\nENABLED=$X\n", "?")
        self.check_all("X=no\nif /bin/false; then X=yes; fi\nENABLED=no\nif [ \"$X\" = yes ]; then ENABLED=yes; fi\n", "?")
        self.check_all("ENABLED=no\nif ! /bin/true; then ENABLED=yes; fi\n", "?")
        self.check_all("ENABLED=no\nif /bin/false && true; then ENABLED=yes; fi\n", "?")
        self.check_all("if /bin/false; then :; fi\ncase \"$1\" in start) ENABLED=yes;; esac\n", "yes")
        self.check_all("pidof x && true\nENABLED=yes\n", "yes")
        # Known conditions propagate known values
        self.check_all("X=no\nif [ 1 = 1 ]; then X=yes; fi\nENABLED=$X\n", "yes")
        self.check_all("X=yes\nif [ 1 = 2 ]; then X=no; fi\nENABLED=$X\n", "yes")


    def test_taint_and_eval_test_p1_3(self):
        # r187 P1-3: Command substitutions, backticks, modifiers, unsupported test ops
        self.check_all("ENABLED=no\nENABLED=$(echo yes)\n", "?")
        self.check_all("ENABLED=no\nENABLED=`echo yes`\n", "?")
        self.check_all("ENABLED=no\nENABLED=${SOME_VAR#prefix}\n", "?")
        self.check_all("ENABLED=no\n[ \"$A\" = \"$B\" -a 1 = 1 ] && ENABLED=yes\n", "?")
        self.check_all("ENABLED=no\n[ -x /bin/sh -a 1 = 1 ] && ENABLED=yes\n", "?")
        self.check_all("ENABLED=no\n[ ! -r /bin/sh ] && ENABLED=yes\n", "?")
        self.check_all("X=no\nif /bin/false; then X=yes; fi\nENABLED=no\ncase \"$X\" in yes) ENABLED=yes;; esac\n", "?")

    def test_eval_command_list_semicolon_reset_p1_2(self):
        # r187 P1-2: Semicolon / newline boundary resets ctrl_unknown
        self.check_all("f() { /bin/false; ENABLED=yes; }; ENABLED=no; f\n", "yes")
        self.check_all("if /bin/false; then :; fi; case \"$1\" in start) ENABLED=yes;; esac\n", "yes")


    def test_svc_configured_and_svc_config_enabled_fail_closed_p1_1(self):
        # r187 P1-1: Both svc_configured and svc_config_enabled return 1 on '?'
        script_q = "if /bin/false; then ENABLED=yes; else ENABLED=no; fi\n"
        with tempfile.NamedTemporaryFile('w', delete=False) as tf:
            tf.write(script_q)
            tname = tf.name
        try:
            sh_test = f"""
{COMMON_SCAN_FUNC}
svc_configured() {{
    _init="$1"
    [ -f "$_init" ] || return 1
    [ -x "$_init" ] || return 1
    _sc_v="$(kz_enabled_scan "$_init" 2>/dev/null || true)"
    [ "$_sc_v" = "yes" ]
}}
svc_configured "{tname}"
echo "common_rc=$?"

{REDIRECT_SCAN_FUNC}
svc_config_enabled() {{
    _init="$1"
    [ -f "$_init" ] || return 1
    [ -x "$_init" ] || return 1
    _sce_v="$(kz_enabled_scan "$_init" 2>/dev/null || true)"
    [ "$_sce_v" = "yes" ]
}}
svc_config_enabled "{tname}"
echo "redir_rc=$?"
"""
            res = subprocess.run(sh_test, shell=True, executable='/bin/sh', capture_output=True, text=True)
            self.assertIn("common_rc=1", res.stdout)
            self.assertIn("redir_rc=1", res.stdout)
        finally:
            if os.path.exists(tname):
                os.unlink(tname)

    def test_last_assignment_wins_over_unknown_p2_1(self):
        # r185 P2-1: Unconditional top-level assignment after unknown condition clears uncertainty
        self.check_all("ENABLED=no\nif /bin/false; then ENABLED=no; fi\nENABLED=yes\n", "yes")
        self.check_all("X=no\nif /bin/false; then X=yes; fi\nENABLED=yes\n", "yes")
        self.check_all("ENABLED=yes\nif /bin/false; then ENABLED=yes; fi\nENABLED=no\n", "no")


class TestRealFullInitScripts(unittest.TestCase):
    def test_all_real_init_files_yes_and_no(self):
        inits = ["S22trojan", "S24xray", "S35tor", "S56dnsmasq", "S57hysteria", "S65shadowsocks", "S90nfqws2"]
        for init_name in inits:
            init_path = os.path.join(INIT_DIR, init_name)
            with open(init_path, 'r', encoding='utf-8') as f:
                content = f.read()

            for target_val in ["yes", "no"]:
                c_mod = re.sub(r'ENABLED=(yes|no)', f'ENABLED={target_val}', content)
                v_common = run_kz_scan(COMMON_SCAN_FUNC, c_mod)
                v_redir = run_kz_scan(REDIRECT_SCAN_FUNC, c_mod)
                v_vpn = run_kz_scan(VPN_SCAN_FUNC, c_mod)

                self.assertEqual(v_common, target_val, f"{init_name} common.sh got {v_common}, expected {target_val}")
                self.assertEqual(v_redir, target_val, f"{init_name} 100-redirect.sh got {v_redir}, expected {target_val}")
                self.assertEqual(v_vpn, target_val, f"{init_name} 100-unblock-vpn.sh got {v_vpn}, expected {target_val}")

                # Watchdog _wd_on check
                is_on = run_wd_on(c_mod)
                self.assertEqual(is_on, (target_val == "yes"), f"{init_name} _wd_on got {is_on}, expected {target_val == 'yes'}")


class TestWatchdogGateF3(unittest.TestCase):
    def test_wd_heredoc_ignored(self):
        content = """#!/bin/sh
cat <<EOF
ENABLED=yes
EOF
ENABLED=no
"""
        self.assertFalse(run_wd_on(content))

    def test_wd_crlf_value_not_stripped(self):
        self.assertFalse(run_wd_on(b"ENABLED=yes\r\n"))

    def test_wd_last_assignment_preserved(self):
        content = """#!/bin/sh
ENABLED=yes
ENABLED=no
"""
        self.assertFalse(run_wd_on(content))

    def test_wd_if_false_not_enabled(self):
        content = """#!/bin/sh
ENABLED=no
if false; then
    ENABLED=yes
fi
"""
        self.assertFalse(run_wd_on(content))

    def test_wd_valid_enabled_yes(self):
        content = """#!/bin/sh
# Config
ENABLED=yes
"""
        self.assertTrue(run_wd_on(content))


class TestGlobRangeParserP3(unittest.TestCase):
    def test_chained_ranges(self):
        pat = "[a-b-c]"
        self.assertTrue(lists_core._posix_glob_match("a", pat))
        self.assertTrue(lists_core._posix_glob_match("b", pat))
        self.assertTrue(lists_core._posix_glob_match("c", pat))
        self.assertFalse(lists_core._posix_glob_match("-", pat))
        self.assertFalse(lists_core._posix_glob_match("d", pat))

        pat2 = "[a-c-e]"
        for c in "abcde":
            self.assertTrue(lists_core._posix_glob_match(c, pat2))
        self.assertFalse(lists_core._posix_glob_match("-", pat2))
        self.assertFalse(lists_core._posix_glob_match("f", pat2))

    def test_reversed_and_mixed_ranges(self):
        # [z-aZ-A] in ash matches 'z', 'a', 'Z', 'A'
        pat = "[z-aZ-A]"
        self.assertTrue(lists_core._posix_glob_match("z", pat))
        self.assertTrue(lists_core._posix_glob_match("a", pat))
        self.assertTrue(lists_core._posix_glob_match("Z", pat))
        self.assertTrue(lists_core._posix_glob_match("A", pat))
        self.assertFalse(lists_core._posix_glob_match("c", pat))

        # [z-a0-9] in ash matches 'z', 'a', and '0'..'9'
        pat2 = "[z-a0-9]"
        self.assertTrue(lists_core._posix_glob_match("z", pat2))
        self.assertTrue(lists_core._posix_glob_match("a", pat2))
        self.assertTrue(lists_core._posix_glob_match("5", pat2))
        self.assertFalse(lists_core._posix_glob_match("c", pat2))

        # [a--z], [0--z], [b--z] match full range in BusyBox ash
        self.assertTrue(lists_core._posix_glob_match("b", "[a--z]"))
        self.assertTrue(lists_core._posix_glob_match("m", "[a--z]"))
        self.assertTrue(lists_core._posix_glob_match("z", "[a--z]"))
        self.assertFalse(lists_core._posix_glob_match("-", "[a--z]"))

        # [z--a] matches 'z', 'a', NOT '-'
        pat3 = "[z--a]"
        self.assertTrue(lists_core._posix_glob_match("z", pat3))
        self.assertTrue(lists_core._posix_glob_match("a", pat3))
        self.assertFalse(lists_core._posix_glob_match("-", pat3))
        self.assertFalse(lists_core._posix_glob_match("c", pat3))

        # [a--0] and [z--0] match endpoints only, not '-'
        self.assertTrue(lists_core._posix_glob_match("a", "[a--0]"))
        self.assertTrue(lists_core._posix_glob_match("0", "[a--0]"))
        self.assertFalse(lists_core._posix_glob_match("-", "[a--0]"))

        # [z--] and [a--] at end of class match endpoints including '-'
        self.assertTrue(lists_core._posix_glob_match("z", "[z--]"))
        self.assertTrue(lists_core._posix_glob_match("-", "[z--]"))
        self.assertTrue(lists_core._posix_glob_match("a", "[a--]"))
        self.assertTrue(lists_core._posix_glob_match("-", "[a--]"))

        # Leading / trailing hyphens: [-a-c], [a-c-]
        self.assertTrue(lists_core._posix_glob_match("-", "[-a-c]"))
        self.assertTrue(lists_core._posix_glob_match("b", "[-a-c]"))
        self.assertTrue(lists_core._posix_glob_match("-", "[a-c-]"))
        self.assertTrue(lists_core._posix_glob_match("b", "[a-c-]"))

    def test_posix_classes(self):
        self.assertTrue(lists_core._posix_glob_match("5", "[[:digit:]]"))
        self.assertFalse(lists_core._posix_glob_match("a", "[[:digit:]]"))
        self.assertTrue(lists_core._posix_glob_match("b", "[!0-9]"))
        self.assertFalse(lists_core._posix_glob_match("3", "[!0-9]"))

    def test_wide_unicode_range_memory_safety(self):
        # Ensure wide unicode ranges compile instantly without MemoryError
        rx = lists_core._compile_single_class(False, "a-\U0010ffff")
        self.assertIsNotNone(rx)
        self.assertTrue(rx.match("b"))
        self.assertTrue(rx.match("z"))
        self.assertFalse(rx.match("\x00"))


if __name__ == '__main__':
    unittest.main()
