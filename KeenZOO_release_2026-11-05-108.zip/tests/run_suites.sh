#!/bin/bash
# run_suites.sh — штатный прогон наборов поставки (не входит в архив: только tests/).
# Запуск из корня распакованного релиза: bash tests/run_suites.sh
# $1 (необязательно) — корень дерева; по умолчанию — каталог уровнем выше tests/.
set -u
cd "$(dirname "$0")/.." || exit 1
K="${1:-$PWD}"
[ -f "$K/opt/bin/common.sh" ] || { echo "run_suites: нет $K/opt/bin/common.sh"; exit 2; }
# Запрещаем создание байткода в процессах, унаследовавших окружение.
# Для независимой проверки чистоты файлов поставки используйте копию.
export PYTHONDONTWRITEBYTECODE=1
p=0; f=0; n=0
line() { echo "$1" | grep -oE 'PASS=[0-9]+ FAIL=[0-9]+' | head -n 1 ; }
echo "=== корень: $K"
for t in lastwins_test.py reader_heredoc_regression.py; do
    n=$((n+1)); out="$(PYTHONPATH="$K/opt/etc/bot" python3 "$K/tests/$t" 2>&1)"; rc=$?
    s="$(line "$out")"
    if [ -z "$s" ]; then
        s="rc=$rc (без счётчика)"
    fi
    echo "==== $t: $s"; echo "$out" | grep -E 'ИТОГ|Ran |^OK|FAILED' | tail -2
    a=$(echo "$s" | sed -n 's/.*PASS=\([0-9]*\).*/\1/p'); b=$(echo "$s" | sed -n 's/.*FAIL=\([0-9]*\).*/\1/p')
    p=$((p+${a:-0})); f=$((f+${b:-0}))
    [ "$rc" -eq 0 ] || f=$((f+1))
done
for t in verify42.sh f42_check.sh f43_keep.sh f44_audit.sh f45_audit.sh f46_audit.sh f49_lint.sh; do
    n=$((n+1)); out="$(bash "$K/tests/$t" "$K" 2>&1)"; rc=$?
    s="$(line "$out")"
    if [ -z "$s" ]; then
        s="rc=$rc (без счётчика)"
    fi
    echo "==== $t: $s"; echo "$out" | grep -E 'ИТОГ|FAIL' | tail -2
    a=$(echo "$s" | sed -n 's/.*PASS=\([0-9]*\).*/\1/p'); b=$(echo "$s" | sed -n 's/.*FAIL=\([0-9]*\).*/\1/p')
    p=$((p+${a:-0})); f=$((f+${b:-0}))
    [ "$rc" -eq 0 ] || f=$((f+1))
done
n=$((n+1)); out="$(python3 "$K/tests/r111_regression.py" "$K" 2>&1)"; rc=$?
echo "==== r111_regression.py: $(echo "$out" | grep -E '^Ran |^OK|^FAILED' | tr '\n' ' ')"
[ "$rc" -eq 0 ] || f=$((f+1))
n=$((n+1)); out="$(sh "$K/tests/f48_anchor.sh" "$K" 2>&1)"; rc=$?
s="$(line "$out")"
if [ -z "$s" ]; then
    s="rc=$rc (без счётчика)"
fi
echo "==== f48_anchor.sh: $s"
a=$(echo "$s" | sed -n 's/.*PASS=\([0-9]*\).*/\1/p'); b=$(echo "$s" | sed -n 's/.*FAIL=\([0-9]*\).*/\1/p')
p=$((p+${a:-0})); f=$((f+${b:-0}))
[ "$rc" -eq 0 ] || f=$((f+1))
# Не удаляем чужие __pycache__ и .pyc: они могли существовать до прогона.
# Некоторые подпроцессы заменяют окружение и могут создать байткод заново.
if find "$K/opt" \( -type d -name __pycache__ -o -type f -name '*.pyc' \) -print -quit 2>/dev/null | grep -q .; then
    echo "[WARN] В opt обнаружены __pycache__ или .pyc (возможно, были ранее); файлы не удалялись. Для чистой приёмки используйте копию."
fi
echo "SUITES_DONE: наборов=$n PASS=$p FAIL=$f"
[ "$f" -eq 0 ]
