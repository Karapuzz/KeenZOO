#!/usr/bin/env python3
"""Проверка fail-closed ENABLED и повторного чтения opkg без записи в /opt."""
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
DEPLOY = ROOT / 'opt/bin/deploy_bypass.sh'
UPDATE = ROOT / 'opt/bin/update_protocols.sh'

def extract(path, name):
    text = path.read_text(encoding='utf-8')
    start = text.index('\n' + name + '() {') + 1
    end = text.index('\n}\n', start) + 3
    return text[start:end]

def shells():
    result = [['sh']]
    if shutil.which('dash'):
        result.append(['dash'])
    if shutil.which('busybox'):
        result.append(['busybox', 'ash'])
    return result

class Safety(unittest.TestCase):
    def run_shell(self, shell, script, env):
        return subprocess.run(shell + ['-c', script], env=env,
                              text=True, capture_output=True)

    def test_save_rejects_unknown_before_apply(self):
        funcs = extract(DEPLOY, 'kz_enabled_save') + extract(DEPLOY, '_kz_svc_enabled_verdict')
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            init = root / 'S22trojan'
            marker = root / 'applied'
            env = dict(os.environ, KZ_INIT_ROOT=td, _SAFE_EXTRACT_DIR=td + '/missing',
                       KEENZOO_DEPLOY_COMMON=td + '/missing', MARKER=str(marker))
            script = (funcs + '\nwarn(){ :; }; _KZ_ENABLED_SERVICES=S22trojan; '
                      'if kz_enabled_save; then : > "$MARKER"; exit 0; else exit $?; fi\n')
            for body, expected in [('#!/bin/sh\nENABLED=yes\n', 0),
                                   ('#!/bin/sh\nENABLED=no\nif false; then\nENABLED=yes\nfi\n', 2),
                                   ('#!/bin/sh\ncat <<EOF\nENABLED=yes\nEOF\n', 2),
                                   ('#!/bin/sh\nENABLED=yes\nif true; then\n', 2)]:
                init.write_text(body)
                for shell in shells():
                    marker.unlink(missing_ok=True)
                    p = self.run_shell(shell, script, env)
                    with self.subTest(shell=shell, body=body):
                        self.assertEqual(p.returncode, expected, p.stderr)
                        self.assertEqual(marker.exists(), expected == 0)

    def test_nfqws2_unknown_aborts_before_remote_probe(self):
        fn = extract(UPDATE, 'nfw2_is_on').replace('"/opt/etc/init.d/S90nfqws2"', '"$INIT"')
        fn += extract(UPDATE, 'update_nfqws2')
        with tempfile.TemporaryDirectory() as td:
            init = Path(td) / 'S90nfqws2'
            init.write_text('#!/bin/sh\nENABLED=no\nif false; then\nENABLED=yes\nfi\n')
            init.chmod(0o755)
            marker = Path(td) / 'network'
            env = dict(os.environ, INIT=str(init), MARKER=str(marker), NFW2_PKG='mock', NFW2_REPO='mock')
            script = (fn + '\nnfw2_intelliqos_warn(){ :; }; opkg_repo_version(){ echo 1; }; '
                      'gh_latest(){ : > "$MARKER"; echo 2; }; version_gt(){ return 1; }; '
                      'nfw2_feed_configured(){ return 1; }; update_nfqws2\n')
            for shell in shells():
                p = self.run_shell(shell, script, env)
                with self.subTest(shell=shell):
                    self.assertNotEqual(p.returncode, 0, p.stdout + p.stderr)
                    self.assertFalse(marker.exists())

    def test_opkg_refreshes_after_each_upgrade_and_fails_on_second_list(self):
        fn = extract(UPDATE, 'update_opkg')
        with tempfile.TemporaryDirectory() as td:
            log = Path(td) / 'log'
            env = dict(os.environ, LOG=str(log))
            script = fn + r'''
opkg() {
  case "$1" in
    update) : ;;
    list-upgradable)
      echo list >> "$LOG"
      n=$(grep -c '^list$' "$LOG")
      if [ "$n" = 1 ]; then printf '%s\n' 'trojan - 1 - 2' 'tor - 1 - 2';
      elif [ "${FAIL_SECOND:-0}" = 1 ]; then return 1;
      else :; fi ;;
    upgrade) echo "upgrade $2" >> "$LOG" ;;
  esac
}
_upd_http_install_gate() { return 0; }
clean_duplicate_inits() { :; }
update_opkg trojan tor
'''
            for shell in shells():
                for fail in ('0', '1'):
                    log.write_text('')
                    p = self.run_shell(shell, script, dict(env, FAIL_SECOND=fail))
                    lines = log.read_text().splitlines()
                    with self.subTest(shell=shell, fail=fail):
                        self.assertEqual(p.returncode, int(fail), p.stdout + p.stderr)
                        self.assertEqual(lines, ['list', 'upgrade trojan', 'list'])

if __name__ == '__main__':
    unittest.main()
