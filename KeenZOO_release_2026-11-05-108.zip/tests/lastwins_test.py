#!/usr/bin/env python3
"""
Стенд проверки многострочного и расширенного синтаксиса ENABLED
(семантика 'last-wins', пустые присваивания, составные строки, экранирование кавычек,
отсечение комментариев и строк-команд, короткое замыкание ||).
"""
import os
import sys
import tarfile
import tempfile
import atexit
import shutil

# Динамическое определение пути к lists_core
_self_dir = os.path.dirname(os.path.abspath(__file__))
_candidates = [
    os.path.join(os.path.dirname(_self_dir), 'opt', 'etc', 'bot'),
    os.path.join(_self_dir, '..', 'opt', 'etc', 'bot'),
    '/home/user/KeenZOO/opt/etc/bot',
    '/opt/etc/bot',
]

_bot_dir = None
for p in _candidates:
    if os.path.isdir(p) and os.path.exists(os.path.join(p, 'lists_core.py')):
        _bot_dir = os.path.abspath(p)
        break

if not _bot_dir:
    _tar_candidates = [
        os.path.join(os.path.dirname(_self_dir), 'KeenZOO_full_2026-11-05-108.tar.gz'),
        '/home/user/KeenZOO_full_2026-11-05-108.tar.gz',
    ]
    for tp in _tar_candidates:
        if os.path.isfile(tp):
            _tmp = tempfile.mkdtemp(prefix='lastwins_test_')
            atexit.register(shutil.rmtree, _tmp, ignore_errors=True)
            with tarfile.open(tp, 'r:gz') as tf:
                for member in tf.getmembers():
                    if member.name.startswith('opt/etc/bot'):
                        tf.extract(member, path=_tmp)
            cand = os.path.join(_tmp, 'opt', 'etc', 'bot')
            if os.path.exists(os.path.join(cand, 'lists_core.py')):
                _bot_dir = cand
                break

if not _bot_dir:
    print("❌ Не удалось найти модуль lists_core")
    sys.exit(1)

sys.path.insert(0, _bot_dir)
from lists_core import parse_enabled_value, enabled_from_lines, _split_commands

test_cases = [
    (['ENABLED=yes'], True),
    (['ENABLED=YES'], False),
    (['ENABLED=Yes'], False),
    (['ENABLED="YES"'], False),
    (['ENABLED="yes" # включено'], True),
    (["ENABLED='yes' # включено"], True),
    (['ENABLED="yes";'], True),
    (['ENABLED=yes;'], True),
    (['ENABLED=yes#x'], False),
    (['ENABLED="yes"'], True),
    (['ENABLED='], False),
    (['  ENABLED=yes  '], True),
    (['  ENABLED="yes" # comment '], True),
    (['  ENABLED=\'yes\' ; trailing '], True),
    (['ENABLED = yes'], False),
    (['ENABLED= yes'], False),
    (['ENABLED=" yes "'], False),
    (['ENABLED=yes', 'ENABLED=no'], False),
    (['ENABLED=no', 'ENABLED=yes'], True),
    (['ENABLED=yes', 'ENABLED='], False),
    (['ENABLED=yes; ENABLED=no'], False),
    (['ENABLED=no; ENABLED=yes'], True),
    (['ENABLED="yes" "no"'], False),
    (['ENABLED="yes" && echo 1'], True),
    (['ENABLED="yes" || echo 1'], True),
    (['ENABLED="yes"foo'], False),
    (['ENABLED="yes;no"'], False),
    (['ENABLED=no || ENABLED=yes'], False),
    (['ENABLED=yes || ENABLED=no'], True),
    (['ENABLED=yes && ENABLED=no'], False),
    (['ENABLED=no && ENABLED=yes'], True),
    (['ENABLED=no # comment ; ENABLED=yes'], False),
    (['ENABLED="no; ENABLED=yes"'], False),
]

passed = 0
failed = 0

for i, (lines, expected) in enumerate(test_cases, 1):
    res = enabled_from_lines(lines)
    if res == expected:
        passed += 1
    else:
        failed += 1
        print(f"[FAIL] Case {i}: {lines} -> expected {expected}, got {res}")

print(f"═══ LASTWINS_TEST ИТОГ: PASS={passed} FAIL={failed} ═══")
if failed > 0:
    sys.exit(1)
sys.exit(0)
