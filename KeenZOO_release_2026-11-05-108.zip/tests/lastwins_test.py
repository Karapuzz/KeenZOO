#!/usr/bin/env python3
"""
Стенд проверки многострочного и расширенного синтаксиса ENABLED
(семантика 'last-wins', пустые присваивания, составные строки, отсечение строк-команд).
"""
import os
import sys
import tempfile

# Добавляем путь к боту
bot_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'opt', 'etc', 'bot')
sys.path.insert(0, bot_dir)

from lists_core import parse_enabled_value, enabled_from_lines

test_cases = [
    (['ENABLED=yes'], True),
    (['ENABLED=YES'], False),
    (['ENABLED=Yes'], False),
    (['ENABLED="YES"'], False),
    (['ENABLED="yes" # включено'], True),
    (["ENABLED='yes' # включено"], True),
    (['ENABLED="yes";'], True),
    (['ENABLED=yes;'], True),
    (['ENABLED=yes#x'], False),
    (['ENABLED="yes"'], True),
    (['ENABLED='], False),
    (['  ENABLED=yes  '], True),
    (['  ENABLED="yes" # comment '], True),
    (['  ENABLED=\'yes\' ; trailing '], True),
    (['ENABLED = yes'], False),
    (['ENABLED= yes'], False),
    (['ENABLED=" yes "'], False),
    (['ENABLED=yes', 'ENABLED=no'], False),
    (['ENABLED=no', 'ENABLED=yes'], True),
    (['ENABLED=yes', 'ENABLED='], False),
    (['ENABLED=yes; ENABLED=no'], False),
    (['ENABLED=no; ENABLED=yes'], True),
    (['ENABLED="yes" "no"'], False),
    (['ENABLED="yes" && echo 1'], True),
    (['ENABLED="yes" || echo 1'], True),
    (['ENABLED="yes"foo'], False),
]

passed = 0
failed = 0

for i, (lines, expected) in enumerate(test_cases, 1):
    res = enabled_from_lines(lines)
    if res == expected:
        passed += 1
    else:
        failed += 1
        print(f"[FAIL] Case {i}: {lines} -> expected {expected}, got {res}")

print(f"═══ LASTWINS_TEST ИТОГ: PASS={passed} FAIL={failed} ═══")
if failed > 0:
    sys.exit(1)
sys.exit(0)
