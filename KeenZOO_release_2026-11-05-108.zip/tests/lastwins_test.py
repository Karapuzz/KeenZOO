#!/usr/bin/env python3
"""
Стенд проверки многострочного и расширенного синтаксиса ENABLED
(семантика 'last-wins', пустые присваивания, составные строки, экранирование кавычек,
отсечение комментариев и строк-команд, короткое замыкание ||, writer roundtrip).
"""
import os
import sys
import hashlib
import tarfile
import tempfile
import atexit
import shutil
import subprocess

_self_dir = os.path.dirname(os.path.abspath(__file__))
ROOT = sys.argv[1] if len(sys.argv) > 1 else None

_candidates = []
if ROOT:
    _candidates.append(os.path.join(ROOT, 'opt', 'etc', 'bot'))
_candidates.extend([
    os.path.join(os.path.dirname(_self_dir), 'opt', 'etc', 'bot'),
    os.path.join(_self_dir, '..', 'opt', 'etc', 'bot'),
    '/opt/etc/bot',
])

_bot_dir = None
for p in _candidates:
    if os.path.isdir(p) and os.path.exists(os.path.join(p, 'lists_core.py')):
        _bot_dir = os.path.abspath(p)
        break

if not _bot_dir:
    _tar_candidates = [
        os.path.join(os.path.dirname(_self_dir), 'KeenZOO_full_2026-11-05-108.tar.gz'),
        '/home/user/KeenZOO_full_2026-11-05-108.tar.gz',
    ]
    if ROOT:
        _tar_candidates.insert(0, os.path.join(ROOT, 'KeenZOO_full_2026-11-05-108.tar.gz'))
    for tp in _tar_candidates:
        if os.path.isfile(tp):
            _tmp = tempfile.mkdtemp(prefix='lastwins_test_')
            atexit.register(shutil.rmtree, _tmp, ignore_errors=True)
            with tarfile.open(tp, 'r:gz') as tf:
                for member in tf.getmembers():
                    if member.name.startswith('opt/etc/bot'):
                        try:
                            tf.extract(member, path=_tmp, filter='data')
                        except TypeError:
                            tf.extract(member, path=_tmp)
            cand = os.path.join(_tmp, 'opt', 'etc', 'bot')
            if os.path.exists(os.path.join(cand, 'lists_core.py')):
                _bot_dir = cand
                break

if not _bot_dir:
    print("❌ Не удалось найти модуль lists_core")
    sys.exit(1)

sys.path.insert(0, _bot_dir)
from lists_core import enabled_from_lines, rewrite_enabled_lines

mod_path = os.path.join(_bot_dir, 'lists_core.py')
with open(mod_path, 'rb') as f:
    mod_sha = hashlib.sha256(f.read()).hexdigest()[:12]
print(f"[INIT] lists_core loaded from {_bot_dir} (sha: {mod_sha})")

parser_cases = [
    (['ENABLED=yes'], True),
    (['ENABLED=YES'], False),
    (['ENABLED=Yes'], False),
    (['ENABLED="YES"'], False),
    (['ENABLED="yes" # включено'], True),
    (["ENABLED='yes' # включено"], True),
    (['ENABLED="yes";'], True),
    (['ENABLED=yes;'], True),
    (['ENABLED=yes#x'], False),
    (['ENABLED="yes"'], True),
    (['ENABLED='], False),
    (['  ENABLED=yes  '], True),
    (['  ENABLED="yes" # comment '], True),
    (['  ENABLED=\'yes\' ; trailing '], True),
    (['ENABLED = yes'], False),
    (['ENABLED= yes'], False),
    (['ENABLED=" yes "'], False),
    (['ENABLED=yes', 'ENABLED=no'], False),
    (['ENABLED=no', 'ENABLED=yes'], True),
    (['ENABLED=yes', 'ENABLED='], False),
    (['ENABLED=yes; ENABLED=no'], False),
    (['ENABLED=no; ENABLED=yes'], True),
    (['ENABLED="yes" "no"'], False),
    (['ENABLED="yes" && echo 1'], True),
    (['ENABLED="yes" || echo 1'], True),
    (['ENABLED="yes"foo'], False),
    (['ENABLED="yes;no"'], False),
    (['ENABLED=no || ENABLED=yes'], False),
    (['ENABLED=yes || ENABLED=no'], True),
    (['ENABLED=yes && ENABLED=no'], False),
    (['ENABLED=no && ENABLED=yes'], True),
    (['ENABLED=no # comment ; ENABLED=yes'], False),
    (['ENABLED="no; ENABLED=yes"'], False),
    (['ENABLED=yes || :; ENABLED=no'], False),
    (['ENABLED=no || :; ENABLED=yes'], True),
    (['ENABLED=no; true || ENABLED=yes'], False),
    (['ENABLED=no; false && ENABLED=yes'], False),
    (['true || ENABLED=yes'], False),
    (['false && ENABLED=yes'], False),
    (['export ENABLED=yes'], True),
    (['export ENABLED=no'], False),
    (['true x || ENABLED=yes'], False),
    (['/bin/true || ENABLED=yes'], False),
    (['false x && ENABLED=yes'], False),
    (['/bin/false && ENABLED=yes'], False),
    (['[ 1 = 1 ] || ENABLED=yes'], False),
]

passed = 0
failed = 0

for i, (lines, expected) in enumerate(parser_cases, 1):
    res = enabled_from_lines(lines)
    if res == expected:
        passed += 1
    else:
        failed += 1
        print(f"[FAIL] Parser case {i}: {lines} -> expected {expected}, got {res}")

# Проверка roundtrip записи и синтаксиса ash
writer_cases = [
    (['#!/bin/sh\n', 'ENABLED="yes;no"\n'], True),
    (['#!/bin/sh\n', 'ENABLED="no; value"\n'], True),
    (['#!/bin/sh\n', 'ENABLED=yes; ENABLED=no\n'], True),
    (['#!/bin/sh\n', 'ENABLED=no; ENABLED=yes\n'], False),
    (['#!/bin/sh\n', 'ENABLED=no; PROCS=xray\n'], True),
    (['#!/bin/sh\n', 'ENABLED=no\n', 'ENABLED=yes\n'], False),
    (['#!/bin/sh\n', 'ENABLED=yes || :; ENABLED=no\n'], False),
    (['#!/bin/sh\n', 'ENABLED = no\n'], True),
    (['#!/bin/sh\n', 'ENABLED= yes\n'], False),
    (['#!/bin/sh\n', 'ENABLED=yes "no"\n'], True),
    (['#!/bin/sh\n', 'false && ENABLED=no; PROCS=xray\n'], True),
    (['#!/bin/sh\n', 'true || ENABLED=yes\n'], False),
    (['#!/bin/sh\n', 'ENABLED=no\n', 'pidof xray || ENABLED=yes\n'], True),
    (['#!/bin/sh\n', 'ENABLED=yes\n', 'pidof xray || ENABLED=no\n'], False),
    (['#!/bin/sh\n', 'ENABLED=yes && ENABLED=no\n'], True),
    (['#!/bin/sh\n', 'ENABLED=no && echo x\n'], True),
    (['#!/bin/sh\n', 'export ENABLED=no\n'], True),
    (['#!/bin/sh\n', 'ENABLED=no\n', 'ENABLED=no || ENABLED=yes\n'], True),
    (['#!/bin/sh\n', 'pidof xray || ENABLED=yes\n'], False),
]

for j, (in_lines, target_val) in enumerate(writer_cases, 1):
    out_lines, _ = rewrite_enabled_lines(in_lines, target_val)
    read_back = enabled_from_lines(out_lines)
    
    # Проверка синтаксиса через sh / ash если доступен
    script_text = ''.join(out_lines)
    syntax_ok = True
    for sh_bin in ('dash', 'busybox', 'sh'):
        if shutil.which(sh_bin):
            cmd = [sh_bin, 'ash', '-n'] if sh_bin == 'busybox' else [sh_bin, '-n']
            r = subprocess.run(cmd, input=script_text, text=True, capture_output=True)
            if r.returncode != 0:
                syntax_ok = False
                print(f"[FAIL] Writer case {j} syntax error ({sh_bin}): {r.stderr.strip()}")
            break
            
    if read_back == target_val and syntax_ok:
        passed += 1
    else:
        failed += 1
        print(f"[FAIL] Writer case {j}: in={in_lines} -> out={out_lines} (read_back={read_back}, expected={target_val})")

print(f"═══ LASTWINS_TEST ИТОГ: PASS={passed} FAIL={failed} ═══")
if failed > 0:
    sys.exit(1)
sys.exit(0)
