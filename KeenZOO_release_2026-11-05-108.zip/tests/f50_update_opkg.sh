#!/bin/bash
# tests/f50_update_opkg.sh — тесты изолированного обновления протоколов (r211/r215)
# Запуск: bash tests/f50_update_opkg.sh [корень]
set -eu

K="${1:-$PWD}"
[ -f "$K/opt/bin/update_protocols.sh" ] || { echo "f50: нет $K/opt/bin/update_protocols.sh"; exit 2; }
[ -f "$K/opt/bin/check_updates.sh" ] || { echo "f50: нет $K/opt/bin/check_updates.sh"; exit 2; }

PASS=0
FAIL=0

ok() { PASS=$((PASS+1)); echo "[OK]   $1"; }
bad() { FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

TMPDIR="$(mktemp -d /tmp/f50_test.XXXXXX)"
trap 'rm -rf "$TMPDIR"' EXIT
F50_LOG="$TMPDIR/upgraded.log"
export F50_LOG

# ── Тест 1: opkg_available парсит последнее поле ($NF) ──
cat > "$TMPDIR/test_opkg_avail.sh" << 'EOF'
#!/bin/sh
OPKG_LIST_RC=0
OPKG_UPGRADABLE_CACHE="tor - 0.4.8.22-1 - 0.4.9.14-1
shadowsocks-libev-ss-redir - 3.3.5-1 - 3.3.5-2
dnsmasq-full - 2.90-1 - 2.90-2"
EOF
sed -n '/^opkg_available() {/,/^}/p' "$K/opt/bin/check_updates.sh" >> "$TMPDIR/test_opkg_avail.sh"
grep -q '^opkg_available() {' "$TMPDIR/test_opkg_avail.sh" || { echo "[FAIL] opkg_available не извлечён"; exit 1; }
cat >> "$TMPDIR/test_opkg_avail.sh" << 'EOF'
echo "tor:$(opkg_available tor)"
echo "ss:$(opkg_available shadowsocks-libev-ss-redir)"
echo "dnsmasq:$(opkg_available dnsmasq-full)"
echo "none:$(opkg_available trojan)"
EOF
chmod +x "$TMPDIR/test_opkg_avail.sh"
OUT="$("$TMPDIR/test_opkg_avail.sh")"

if echo "$OUT" | grep -q "tor:0.4.9.14-1" \
   && echo "$OUT" | grep -q "ss:3.3.5-2" \
   && echo "$OUT" | grep -q "dnsmasq:2.90-2" \
   && echo "$OUT" | grep -q "none:$"; then
    ok "1: opkg_available корректно извлекает доступную версию (\$NF) для всех пакетов"
else
    bad "1: opkg_available неверно извлекает версию ($OUT)"
fi

# ── Тест 2: update_opkg обновляет только запрошенный пакет (изоляция) ──
mkdir -p "$TMPDIR/bin"
cat > "$TMPDIR/bin/opkg" << 'EOF'
#!/bin/sh
case "$1" in
    update) exit 0 ;;
    list-upgradable)
        echo "shadowsocks-libev-ss-redir - 3.3.5-1 - 3.3.5-2"
        echo "trojan - 1.16.0-1 - 1.16.0-2"
        echo "tor - 0.4.8.22-1 - 0.4.9.14-1"
        echo "tor-geoip - 0.4.8.22-1 - 0.4.9.14-1"
        echo "dnsmasq-full - 2.90-1 - 2.90-2"
        ;;
    upgrade)
        echo "UPGRADED: $2" >> "$F50_LOG"
        exit 0
        ;;
esac
EOF
chmod +x "$TMPDIR/bin/opkg"

# Извлекаем update_opkg из update_protocols.sh
cat > "$TMPDIR/test_isolated.sh" << EOF
#!/bin/sh
PATH="$TMPDIR/bin:/bin:/usr/bin"
_upd_http_install_gate() { return 0; }
clean_duplicate_inits() { :; }
rm -f "$F50_LOG"
EOF
sed -n '/^update_opkg() {/,/^}/p' "$K/opt/bin/update_protocols.sh" >> "$TMPDIR/test_isolated.sh"
echo 'update_opkg trojan' >> "$TMPDIR/test_isolated.sh"
chmod +x "$TMPDIR/test_isolated.sh"

ISOLATED_RC=0
sh "$TMPDIR/test_isolated.sh" >/dev/null 2>&1 || ISOLATED_RC=$?
UP_LOG="$(cat "$F50_LOG" 2>/dev/null || echo "")"
rm -f "$F50_LOG"

if [ "$ISOLATED_RC" -eq 0 ] && [ "$UP_LOG" = "UPGRADED: trojan" ]; then
    ok "2: update_opkg trojan обновляет строго 1 пакет (trojan)"
else
    bad "2: update_opkg trojan обновил неверные пакеты ($UP_LOG)"
fi

# ── Тест 3: update_opkg tor tor-geoip обновляет оба пакета ──
cat > "$TMPDIR/test_tor.sh" << EOF
#!/bin/sh
PATH="$TMPDIR/bin:/bin:/usr/bin"
_upd_http_install_gate() { return 0; }
clean_duplicate_inits() { :; }
rm -f "$F50_LOG"
EOF
sed -n '/^update_opkg() {/,/^}/p' "$K/opt/bin/update_protocols.sh" >> "$TMPDIR/test_tor.sh"
echo 'update_opkg tor tor-geoip' >> "$TMPDIR/test_tor.sh"
chmod +x "$TMPDIR/test_tor.sh"

TOR_RC=0
sh "$TMPDIR/test_tor.sh" >/dev/null 2>&1 || TOR_RC=$?
UP_LOG="$(cat "$F50_LOG" 2>/dev/null || echo "")"
rm -f "$F50_LOG"

if [ "$TOR_RC" -eq 0 ] && [ "$UP_LOG" = "$(printf 'UPGRADED: tor\nUPGRADED: tor-geoip')" ]; then
    ok "3: update_opkg tor tor-geoip обновляет и tor, и tor-geoip"
else
    bad "3: update_opkg tor tor-geoip обновил не все пакеты ($UP_LOG)"
fi

# ── Тест 4: отказ opkg list-upgradable возвращает rc=1 с диагностикой (R211-1) ──
cat > "$TMPDIR/bin/opkg_fail" << 'EOF'
#!/bin/sh
case "$1" in
    update) exit 0 ;;
    list-upgradable) exit 2 ;;
esac
EOF
chmod +x "$TMPDIR/bin/opkg_fail"

cat > "$TMPDIR/test_fail.sh" << EOF
#!/bin/sh
PATH="$TMPDIR/bin:/bin:/usr/bin"
opkg() { "$TMPDIR/bin/opkg_fail" "\$@"; }
_upd_http_install_gate() { return 0; }
clean_duplicate_inits() { :; }
EOF
sed -n '/^update_opkg() {/,/^}/p' "$K/opt/bin/update_protocols.sh" >> "$TMPDIR/test_fail.sh"
echo 'update_opkg' >> "$TMPDIR/test_fail.sh"
chmod +x "$TMPDIR/test_fail.sh"

set +e
FAIL_OUT="$(sh "$TMPDIR/test_fail.sh" 2>&1)"
FAIL_RC=$?
set -e

if [ "$FAIL_RC" -ne 0 ] && echo "$FAIL_OUT" | grep -q "не удалось получить список обновлений"; then
    ok "4: отказ list-upgradable даёт rc != 0 и явное сообщение об ошибке (P1)"
else
    bad "4: отказ list-upgradable замаскирован (rc=$FAIL_RC, out=$FAIL_OUT)"
fi

# ── Тест 5: при отсутствии обновлений выводится честное уведомление ──
cat > "$TMPDIR/bin/opkg_empty" << 'EOF'
#!/bin/sh
case "$1" in
    update) exit 0 ;;
    list-upgradable) exit 0 ;;
esac
EOF
chmod +x "$TMPDIR/bin/opkg_empty"

cat > "$TMPDIR/test_empty.sh" << EOF
#!/bin/sh
PATH="$TMPDIR/bin:/bin:/usr/bin"
opkg() { "$TMPDIR/bin/opkg_empty" "\$@"; }
_upd_http_install_gate() { return 0; }
clean_duplicate_inits() { :; }
EOF
sed -n '/^update_opkg() {/,/^}/p' "$K/opt/bin/update_protocols.sh" >> "$TMPDIR/test_empty.sh"
echo 'update_opkg' >> "$TMPDIR/test_empty.sh"
chmod +x "$TMPDIR/test_empty.sh"

EMPTY_OUT="$(sh "$TMPDIR/test_empty.sh" 2>&1)"

if echo "$EMPTY_OUT" | grep -q "обновлений для запрошенных пакетов не найдено"; then
    ok "5: при пустом списке выводится «обновлений не найдено»"
else
    bad "5: неверный вывод при отсутствии обновлений ($EMPTY_OUT)"
fi

# ── Тест 6: проверка dispatch в update_protocols.sh ──
DISP="$(grep -A 60 'case "$ACTION" in' "$K/opt/bin/update_protocols.sh")"
if echo "$DISP" | grep -q 'shadowsocks|ss)' \
   && echo "$DISP" | grep -q 'trojan)' \
   && echo "$DISP" | grep -q 'tor)' \
   && echo "$DISP" | grep -q 'dnsmasq)' \
   && echo "$DISP" | grep -q 'nfqws2)' \
   && echo "$DISP" | grep -q 'xray)' \
   && echo "$DISP" | grep -q 'hysteria)'; then
    ok "6: dispatch update_protocols.sh содержит все индивидуальные протоколы"
else
    bad "6: dispatch update_protocols.sh не содержит всех протоколов"
fi

echo "f50_update_opkg ИТОГ: PASS=$PASS FAIL=$FAIL"
[ "$FAIL" -eq 0 ]
