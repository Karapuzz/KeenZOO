#!/bin/sh
# audit9_fixture.sh — приёмочные тесты правок R38-1..R38-6 (аудит-9).
# Внешний harness (не часть проекта): извлекает РЕАЛЬНЫЕ фрагменты кода
# release-candidate и исполняет их с моками ip/ipset/iptables/логгера.
set -uo pipefail

W="$(mktemp -d /tmp/a9fix.XXXXXX 2>/dev/null)" || exit 1
MOCKDIR="$W/mock"; mkdir -p "$MOCKDIR"
VPN_HOOK=/home/user/KeenZOO/opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh
DNS_SH=/home/user/KeenZOO/opt/bin/unblock_dnsmasq.sh
RED_SH=/home/user/KeenZOO/opt/etc/ndm/netfilter.d/100-redirect.sh
DEP_SH=/home/user/KeenZOO/opt/bin/deploy_bypass.sh

PASS=0; FAIL=0
ok()  { PASS=$((PASS + 1)); echo "  ✅ $1"; }
bad() { FAIL=$((FAIL + 1)); echo "  ❌ $1 ${2:-}"; }
has()  { printf '%s' "$2" | grep -q -- "$3" && ok "$1" || bad "$1" "«$3» не найден"; }
hasnt(){ printf '%s' "$2" | grep -q -- "$3" && bad "$1" "«$3» найден" || ok "$1"; }
chk() { [ "$2" = "$3" ] && ok "$1" || bad "$1" "$2 ≠ $3"; }
n_of(){ printf '%s' "$1" | tr ';' '\n' | grep -c -- "$2" || true; }

# ═════════════════════════════════════════════════════════════════════
echo "B1. R38-1: канонический полный матчер (unit)"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_rule_exact_present()/,/^}/p' "$VPN_HOOK" > "$W/m.sh"
grep -q '_rule_exact_present()' "$W/m.sh" \
    || { echo "❌ B1: функция не извлечена"; exit 1; }
cat > "$MOCKDIR/ip" <<'EOF'
#!/bin/sh
case "$1 $2 $3" in
    "-4 rule show") [ -n "${IPOPT_RULE_SHOW:-}" ] && printf '%s\n' "$IPOPT_RULE_SHOW"; exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ip"
mx() { # $1 = вывод ip rule show → rc матчера (0 точное/1 нет/2 конфликт)
    ( export PATH="$MOCKDIR:$PATH"
      IPOPT_RULE_SHOW="$1" sh -c '. "$0"; _rule_exact_present 0xd1001 1001 wgtest >/dev/null 2>&1; echo $?' "$W/m.sh" )
}
EXACT="1778: from all fwmark 0xd1001 lookup 1001"
chk "B1.1 каноническое правило (число) → rc=0"            "$(mx "$EXACT")" 0
chk "B1.2 каноническое правило (имя таблицы) → rc=0"      "$(mx "1778: from all fwmark 0xd1001 lookup wgtest")" 0
chk "B1.3 наша метка + чужая таблица → rc=2 (конфликт)"  "$(mx "1778: from all fwmark 0xd1001 lookup other")" 2
chk "B1.3b полностью чужое правило на 1778 → rc=2 (r39)"  "$(mx "1778: from all fwmark 0x999 lookup 99")" 2
chk "B1.4 from-подсеть (не from all) → rc=2"              "$(mx "1778: from 192.0.2.0/24 fwmark 0xd1001 lookup 1001")" 2
chk "B1.5 not fwmark (инверсия) → rc=2"                   "$(mx "1778: from all not fwmark 0xd1001 lookup 1001")" 2
chk "B1.6 лишний селектор iif → rc=2"                     "$(mx "1778: from all fwmark 0xd1001 lookup 1001 iif eth0")" 2
chk "B1.7 маска fwmark 0xd1001/0xffffff → rc=2"          "$(mx "1778: from all fwmark 0xd1001/0xffffff lookup 1001")" 2
chk "B1.8 префикс-яд 0xd10010/10010 → rc=2 (r39: чужое на 1778)" "$(mx "1778: from all fwmark 0xd10010 lookup 10010")" 2
chk "B1.9 чужой priority 2778 → rc=1"                     "$(mx "2778: from all fwmark 0xd1001 lookup 1001")" 1
chk "B1.10 изменённый порядок полей → rc=2"               "$(mx "1778: from all lookup 1001 fwmark 0xd1001")" 2
chk "B1.11 восьмой токен → rc=2"                          "$(mx "1778: from all fwmark 0xd1001 lookup 1001 tos 0x10")" 2
chk "B1.12 пустой вывод → rc=1"                           "$(mx "")" 1
chk "B1.13 конфликтное + каноническое → rc=2 (r39: тень)"  "$(mx "1778: from all not fwmark 0xd1001 lookup 1001
$EXACT")" 2
chk "B1.14 дубликат канона → rc=0 (дубли безвредны)"       "$(mx "$EXACT
$EXACT")" 0

# ═════════════════════════════════════════════════════════════════════
echo "B2. R38-1/R38-3: транзакция — конфликт-диагностика и неразрушающий откат"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_rule_exact_present()/,/^}/p' "$VPN_HOOK" > "$W/rt.sh"
sed -n '/^_rule_tx_claim()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_lock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_unlock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
awk '/^    if _rule_tx_lock "\$vpn_table_id"; then$/{f=1} f{print} /^    ip -4 route flush cache/{if(f)exit}' "$VPN_HOOK" >> "$W/rt.sh"
grep -q '_rule_exact_present' "$W/rt.sh" && grep -q '_rule_rb_rc' "$W/rt.sh" \
    || { echo "❌ B2: блок не извлечён"; exit 1; }
cat > "$MOCKDIR/ip" <<'EOF'
#!/bin/sh
echo "$*" >> "$IP_LOG"
case "$1 $2" in
    "-4 route")
        case "$3" in
            replace) [ "${IPOPT_ROUTE_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            show)
                [ "${IPOPT_ROUTE_EMPTY:-0}" = 1 ] && exit 0
                case "$*" in
                    *" table main"*) echo "10.0.0.0/24 dev br0"; exit 0;;
                    *) echo "default via 10.0.0.1 dev wg0"; exit 0;;
                esac;;
        esac
        exit 0;;
    "-4 rule")
        case "$3" in
            add) [ "${IPOPT_RULE_ADD_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            del) exit 0;;
            show)
                # IPOPT_RULE_SHOW — до вызова №(IPOPT_SHOW_SWITCH-1),
                # далее IPOPT_RULE_SHOW_LATE (эмуляция конкурентной смены)
                _n="$(cat "$W/showcnt" 2>/dev/null || echo 0)"
                _n=$((_n + 1)); echo "$_n" > "$W/showcnt"
                if [ -n "${IPOPT_SHOW_SWITCH:-}" ] && [ "$_n" -ge "$IPOPT_SHOW_SWITCH" ]; then
                    [ -n "${IPOPT_RULE_SHOW_LATE:-}" ] && printf '%s\n' "$IPOPT_RULE_SHOW_LATE"
                else
                    [ -n "${IPOPT_RULE_SHOW:-}" ] && printf '%s\n' "$IPOPT_RULE_SHOW"
                fi
                exit 0;;
        esac
        exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ip"
t_rt() {
    ( export PATH="$MOCKDIR:$PATH"
      export IP_LOG="$W/ip.log" W="$W"; : > "$IP_LOG"; echo 0 > "$W/showcnt"
      TAG=t; logger() { echo "$*" >> "$W/rtlog"; }; : > "$W/rtlog"
      vpn=Wireguard0; vpn_table_id=1001; vpn_table=wgtest
      vpn_ip=10.23.4.5; vpn_dev=Wireguard0
      get_fwmark_id=0xd1001; vpn_name=wgtest
      eval "export $*"
      for _t in 1; do . "$W/rt.sh"; done
      rc=$?
      [ "$rc" = 0 ] && r=ok || r=fail
      echo "$r|$(tr '\n' ';' < "$IP_LOG")|$(tr '\n' ';' < "$W/rtlog")" )
}
# B2.1 (r39/R38-02): конфликтное правило (from-подсеть) — полная
# ОСТАНОВКА настройки: ни route, ни add, ни del; диагностика.
R="$(t_rt "IPOPT_RULE_SHOW='1778: from 192.0.2.0/24 fwmark 0xd1001 lookup 1001' IPOPT_RULE_ADD_FAIL=1")"
has  "B2.1 конфликт диагностирован" "$R" "постороннее/конфликтное правило"
chk "B2.1 route replace не выполнялся" "$(n_of "$R" 'route replace')" 0
chk "B2.1 add не выполнялся" "$(n_of "$R" 'rule add')" 0
chk "B2.1 del=0" "$(n_of "$R" 'rule del')" 0
has  "B2.1 НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
# B2.2: конкурентная смена между verify и откатом: правило «вернулось» —
# del не выполняется (F37-03), честный лог.
R="$(t_rt "IPOPT_RULE_SHOW='' IPOPT_RULE_SHOW_LATE='1778: from all fwmark 0xd1001 lookup 1001' IPOPT_SHOW_SWITCH=3")"
has  "B2.2 конкурентная смена: откат не выполнен" "$R" "конкурентная смена состояния"
chk "B2.2 del=0 (правило снова присутствует)" "$(n_of "$R" 'rule del')" 0
has  "B2.2 НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
# B2.3: verify-fail, правило действительно отсутствует → del выполняется.
R="$(t_rt "IPOPT_RULE_SHOW=''")"
chk "B2.3 del=1 (свой добавленный откатывается)" "$(n_of "$R" 'rule del')" 1
# B2.4 (r39/R38-02): not fwmark-конфликт — ОСТАНОВКА до route replace:
# чужое правило на 1778 не сосуществует с нашим, VPN ON не сообщается.
NOTFW='1778: from all not fwmark 0xd1001 lookup 1001'
R="$(t_rt "IPOPT_RULE_SHOW='$NOTFW' IPOPT_SHOW_SWITCH=2 IPOPT_RULE_SHOW_LATE='$NOTFW
1778: from all fwmark 0xd1001 lookup 1001'")"
has  "B2.4 not-fwmark: конфликт диагностирован" "$R" "постороннее/конфликтное правило"
chk "B2.4 route replace не выполнялся" "$(n_of "$R" 'route replace')" 0
chk "B2.4 add не выполнялся" "$(n_of "$R" 'rule add')" 0
has  "B2.4 НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"

# ═════════════════════════════════════════════════════════════════════
echo "B3. R38-3: mkdir-lock транзакции (unit)"
# ───────────────────────────────────────────────────────────────────────
{ sed -n '/^_rule_tx_claim()/,/^}/p' "$VPN_HOOK"
  sed -n '/^_rule_tx_lock()/,/^}/p' "$VPN_HOOK"
  sed -n '/^_rule_tx_unlock()/,/^}/p' "$VPN_HOOK"; } > "$W/lk.sh"
grep -q '_rule_tx_claim' "$W/lk.sh" \
    || { echo "❌ B3: функции не извлечены"; exit 1; }
LK="/tmp/keenzoo_rule_1001.lockdir"
rm -rf "$LK"
# B3.1: свой захват
R="$( ( TAG=t; logger() { echo "$*"; }; . "$W/lk.sh"; _rule_tx_lock 1001 && echo GOT) )"
has  "B3.1 замок захвачен" "$R" "GOT"
[ -d "$LK" ] && ok "B3.1 lockdir существует" || bad "B3.1 lockdir нет"
# B3.2: живой владелец ($$ тест-скрипта жив) → таймаут rc=1
R="$( ( TAG=t; logger() { echo "$*" >&2; }; . "$W/lk.sh"; _rule_tx_lock 1001 && echo GOT || echo TIMEOUT) 2>/dev/null )"
has  "B3.2 живой владелец → таймаут (не украден)" "$R" "TIMEOUT"
hasnt "B3.2 замок не украден" "$R" "GOT"
[ -d "$LK" ] && ok "B3.2 lockdir цел" || bad "B3.2 lockdir исчез"
# B3.3: чужой unlock (pid≠наш) не снимает
( _ul_pid="$(cat "$LK/pid")"; [ "$_ul_pid" = "999999" ] && rm -rf "$LK" || true )
[ -d "$LK" ] && ok "B3.3 чужой unlock не снял замок" || bad "B3.3 замок потерян"
# B3.4: свой unlock снимает
( _ul_pid="$(cat "$LK/pid" 2>/dev/null || true)"
  [ "$_ul_pid" = "$$" ] && rm -rf "$LK" 2>/dev/null || true )
[ -d "$LK" ] && bad "B3.4 свой unlock не снял" || ok "B3.4 свой unlock снял"
# B3.5: stale-замок (мёртвый pid) перехватывается сразу
mkdir -p "$LK"; echo 999999 > "$LK/pid"
R="$( ( TAG=t; logger() { echo "$*" >&2; }; . "$W/lk.sh"; _rule_tx_lock 1001 && echo GOT) 2>/dev/null )"
has  "B3.5 stale-замок перехвачен" "$R" "GOT"
rm -rf "$LK"

# ═════════════════════════════════════════════════════════════════════
echo "B4. R38-2: userinfo/порт в URL штатного фида"
# ───────────────────────────────────────────────────────────────────────
awk '/^echo "   Каналы пакетов для opkg update/{f=1} f{print} /KEENZOO_DEPLOY_NO_HTTP.*обнаружены/{seen=1} seen&&/^fi$/{exit}' "$DEP_SH" > "$W/feeds.sh"
grep -q '_opf_exempt' "$W/feeds.sh" \
    || { echo "❌ B4: блок не извлечён"; exit 1; }
t_feed() { # $1=строка src; $2=strict; вывод "OUT|RC"
    ( printf '%s\n' "$1" > "$W/opkg.conf"
      export KZ_DEPLOY_OPKG_CONF="$W/opkg.conf" KEENZOO_DEPLOY_NO_HTTP="${2:-0}"
      die() { echo "DIE:$*"; exit 77; }
      out="$(. "$W/feeds.sh")"; rc=$?
      echo "${out}|$rc" )
}
O="$(t_feed 'src/gz hostile http://bin.entware.net:80@evil.example/feed' 1)"
case "$O" in *DIE:*) ok "B4.1 userinfo-обход (@) → заблокирован";; *) bad "B4.1 обход через @";; esac
O="$(t_feed 'src/gz hostile http://bin.entware.net:443@evil.example/x' 1)"
case "$O" in *DIE:*) ok "B4.2 userinfo с портом → заблокирован";; *) bad "B4.2 обход через @:443";; esac
O="$(t_feed 'src/gz evil http://user:pass@evil.example/feed' 1)"
case "$O" in *DIE:*) ok "B4.3 user:pass@evil → заблокирован";; *) bad "B4.3 обход через user:pass@";; esac
O="$(t_feed 'src/gz evil http://bin.entware.net:abc/feed' 1)"
case "$O" in *DIE:*) ok "B4.4 нечисловой порт → заблокирован";; *) bad "B4.4 обход через порт :abc";; esac
O="$(t_feed 'src/gz entware http://bin.entware.net:80/targets/packages' 1)"
case "$O" in *DIE:*) bad "B4.5 числовой порт штатного заблокирован";; *) ok "B4.5 штатной с портом → не блокируется";; esac
has  "B4.5 пометка HTTP-канал" "$O" "HTTP-канал"
O="$(t_feed 'src/gz entware http://bin.entware.net/targets/x86-64/packages' 1)"
case "$O" in *DIE:*) bad "B4.6 точный хост заблокирован";; *) ok "B4.6 точный хост → не блокируется";; esac
O="$(t_feed 'src/gz entware HTTP://BIN.ENTWARE.NET/targets/packages' 1)"
case "$O" in *DIE:*) bad "B4.7 uppercase штатного заблокирован";; *) ok "B4.7 uppercase → не блокируется";; esac
O="$(t_feed 'src/gz evil http://bin.entware.net.evil.example/p' 1)"
case "$O" in *DIE:*) ok "B4.8 суффикс-хост → заблокирован";; *) bad "B4.8 обход через суффикс";; esac
O="$(t_feed 'src/gz evil http://@bin.entware.net/p' 1)"
case "$O" in *DIE:*) ok "B4.9 пустой userinfo @ → заблокирован (fail-closed)";; *) bad "B4.9 обход через пустой @";; esac

# ═════════════════════════════════════════════════════════════════════
echo "B5. R38-5 (K2): recovery по подтверждённому исправлению"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^check_pinned_reachable()/,/^}/p' "$DNS_SH" > "$W/cpr.sh"
grep -q '_cpr_all_fixed' "$W/cpr.sh" \
    || { echo "❌ B5: функция не извлечена"; exit 1; }
PIN_STATE=/tmp/keenzoo_pin_unreach
BADLINE='VLESS: TCP endpoint unavailable — 1.2.3.4:443 (h1.example)'
run_cpr() { # PROBE_H1=ok|unk|bad, PROBE_H2=..., PROBE_HY=...
    ( set -u
      logger() { echo "$*" >> "$W/pinlog"; }
      pin_notify() { echo "$1" >> "$W/notify"; }
      protocol_for_host() { case "$1" in hy1.example) echo Hysteria;; *) echo VLESS;; esac; }
      proto_port_for_host() { echo 443; }
      tcp_probe() {
          case "$1" in
              1.2.3.4) _pr="${PROBE_H1:-2}" ;;
              5.6.7.8) _pr="${PROBE_H2:-2}" ;;
              *) _pr=2 ;;
          esac
          return "$_pr"
      }
      mktemp() { echo "$W/cprf.$$"; }
      . "$W/cpr.sh"
      check_pinned_reachable "$(printf '1.2.3.4\th1.example\n5.6.7.8\th2.example\n9.9.9.9\thy1.example')"
      echo "rc=$?" )
}
prep() { rm -f "$PIN_STATE" "$W"/cprf.* 2>/dev/null; : > "$W/notify"; : > "$W/pinlog"; }

# B5.1: бывший недоступным endpoint подтверждённо O → recovery
prep; printf '%s\n' "$BADLINE" > "$PIN_STATE"
PROBE_H1=0 PROBE_H2=0 PROBE_HY=0 run_cpr >/dev/null 2>&1
has  "B5.1 recovery-уведомление отправлено" "$(cat "$W/notify")" "снова доступны"
[ -f "$PIN_STATE" ] && bad "B5.1 состояние не снято" || ok "B5.1 состояние снято"
# B5.2: бывший bad теперь unknown → recovery НЕ подтверждён
prep; printf '%s\n' "$BADLINE" > "$PIN_STATE"
PROBE_H1=2 PROBE_H2=0 PROBE_HY=0 run_cpr >/dev/null 2>&1
hasnt "B5.2 recovery нет (endpoint не подтверждён)" "$(cat "$W/notify")" "снова доступны"
has  "B5.2 журнал: восстановление не подтверждено" "$(cat "$W/pinlog")" "восстановление не подтверждено"
[ -s "$PIN_STATE" ] && ok "B5.2 прежний статус сохранён" || bad "B5.2 статус потерян"
# B5.3: Hysteria-тупик закрыт: бывший bad → O, Hysteria → U → recovery
prep; printf '%s\n' "$BADLINE" > "$PIN_STATE"
PROBE_H1=0 PROBE_H2=0 PROBE_HY=2 run_cpr >/dev/null 2>&1
has  "B5.3 Hysteria-U не блокирует recovery" "$(cat "$W/notify")" "снова доступны"
has  "B5.3 transparentность: исход 1 проб неизвестен" "$(cat "$W/notify")" "исход 1 проб неизвестен"
# B5.4: endpoint исчез из проверяемых (конфиг изменён) → не блокирует
prep; printf '%s\n' "$BADLINE" > "$PIN_STATE"
printf 'VLESS: TCP endpoint unavailable — 9.8.7.6:443 (gone.example)\n' >> "$PIN_STATE"
PROBE_H1=0 PROBE_H2=0 PROBE_HY=0 run_cpr >/dev/null 2>&1
has  "B5.4 удалённый из конфига endpoint не блокирует" "$(cat "$W/notify")" "снова доступны"
# B5.5: повреждённая строка состояния → fail-closed, recovery нет
prep; printf 'MUSOR\n' > "$PIN_STATE"
PROBE_H1=0 PROBE_H2=0 PROBE_HY=0 run_cpr >/dev/null 2>&1
hasnt "B5.5 повреждённое состояние: recovery нет" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "B5.5 состояние сохранено" || bad "B5.5 статус потерян"
# B5.6: bad по-прежнему → outage с прозрачностью unknown (не изменилось)
prep; rm -f "$PIN_STATE"
PROBE_H1=1 PROBE_H2=0 PROBE_HY=0 run_cpr >/dev/null 2>&1
has  "B5.6 bad+unknown: outage" "$(cat "$W/notify")" "TCP endpoint unavailable"
has  "B5.6 прозрачность unknown" "$(cat "$W/notify")" "исход 1 проб неизвестен"
# B5.7: только unknown (ok=0) → прежний статус, без уведомления
prep; printf '%s\n' "$BADLINE" > "$PIN_STATE"
PROBE_H1=2 PROBE_H2=2 PROBE_HY=2 run_cpr >/dev/null 2>&1
hasnt "B5.7 unknown-only: нет recovery" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "B5.7 прежний статус сохранён" || bad "B5.7 статус потерян"
# B5.8: состояния нет, все ok → уведомления нет
prep; rm -f "$PIN_STATE"
PROBE_H1=0 PROBE_H2=0 PROBE_HY=0 run_cpr >/dev/null 2>&1
hasnt "B5.8 без outage-состояния уведомления нет" "$(cat "$W/notify")" "снова доступны"
rm -f "$PIN_STATE"

# ═════════════════════════════════════════════════════════════════════
echo "B6. R38-6: опциональный fail-closed при отсутствии таблицы"
# ───────────────────────────────────────────────────────────────────────
awk '/^    \[ -n "\$vpn_table_id" \] \|\| \{$/{f=1} f{print} f&&/^    \}$/{exit}' "$RED_SH" > "$W/gate_body.sh"
grep -q '_fc_flag' "$W/gate_body.sh" \
    && grep -qF '/opt/etc/unblock/.fail-closed-no-table' "$W/gate_body.sh" \
    || { echo "❌ B6: блок/маркер не извлечён"; exit 1; }
# Host-fixture: сохраняем проверку production-пути выше, но исполняем
# извлечённый код только с приватным маркером под $W.
KZ_A9_FC_MARK="$W/fcroot/opt/etc/unblock/.fail-closed-no-table"
sed "s#/opt/etc/unblock/.fail-closed-no-table#$KZ_A9_FC_MARK#g" \
    "$W/gate_body.sh" > "$W/gate_body.sandbox.sh"
mv "$W/gate_body.sandbox.sh" "$W/gate_body.sh"
cat > "$W/gate.sh" <<'EOF'
for _t in 1; do
EOF
cat "$W/gate_body.sh" >> "$W/gate.sh"
cat >> "$W/gate.sh" <<'EOF'
done
EOF
cat > "$MOCKDIR/ipset" <<'EOF'
#!/bin/sh
echo "ipset $*" >> "$IPSET_LOG"
_ST="$W/ipset_state"; mkdir -p "$_ST"
case "$1" in
    create) echo 0 > "$_ST/$2.cnt" 2>/dev/null
            [ "${IPSET_CREATE_FAIL:-0}" = 1 ] && exit 1; exit 0;;
    destroy) rm -f "$_ST/$2.cnt" 2>/dev/null; exit 0;;
    flush)   echo 0 > "$_ST/$2.cnt" 2>/dev/null; exit 0;;
    add)     _c="$(cat "$_ST/$2.cnt" 2>/dev/null || echo 0)"
             echo $((_c + 1)) > "$_ST/$2.cnt"; exit 0;;
    restore)
            [ "${IPSET_RESTORE_FAIL:-0}" = 1 ] && exit 1
            _set=""; _n=0
            while read -r _l; do
                case "$_l" in add\ *) _set="${_l#add }"; _set="${_set%% *}"; _n=$((_n + 1));; esac
            done
            [ -n "$_set" ] || exit 1
            _c="$(cat "$_ST/$_set.cnt" 2>/dev/null || echo 0)"
            echo $((_c + _n)) > "$_ST/$_set.cnt"
            exit 0;;
    list)
            if [ -n "${IPSET_FORCE_ENTRIES:-}" ]; then
                echo "Number of entries: $IPSET_FORCE_ENTRIES"; exit 0
            fi
            echo "Number of entries: $(cat "$_ST/$2.cnt" 2>/dev/null || echo 0)"
            exit 0;;
    swap)
            [ "${IPSET_SWAP_FAIL:-0}" = 1 ] && exit 1
            _a="$(cat "$_ST/$2.cnt" 2>/dev/null || echo 0)"
            _b="$(cat "$_ST/$3.cnt" 2>/dev/null || echo 0)"
            echo "$_b" > "$_ST/$2.cnt"; echo "$_a" > "$_ST/$3.cnt"
            exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ipset"
t_gate() { # $1=содержимое списка; $2..: env; вывод: ERR|DEG|FADD|FDEL|адды
    ( export PATH="$MOCKDIR:$PATH"
      printf '%s' "$1" > "$W/vpnlist.txt"
      export vpn_file_name="$W/vpnlist.txt" unblockvpn=unblockvpn-X vpn_type_lower=wgtest
      export vpn_table_id=""
      export IPSET_LOG="$W/ipset.log" W="$W"; : > "$W/ipset.log"
      : > "$W/gerr"; : > "$W/gdeg"; : > "$W/fadd"; : > "$W/fdel"; : > "$W/eset"
      hook_error()   { echo "$*" >> "$W/gerr"; }
      hook_degraded(){ echo "$*" >> "$W/gdeg"; }
      vpn_fallback_add() { echo "$*" >> "$W/fadd"; [ "${FADD_FAIL:-0}" = 1 ] && return 1; return 0; }
      vpn_fallback_del() { echo "$*" >> "$W/fdel"; return 0; }
      ensure_set() { echo "$*" >> "$W/eset"; return 0; }
      eval "export $2"
      . "$W/gate.sh"
      echo "E:$(cat "$W/gerr")|D:$(cat "$W/gdeg")|A:$(cat "$W/fadd")|Xd:$(cat "$W/fdel")|S:$(cat "$W/eset")|$(tr '\n' ';' < "$W/ipset.log")" )
}
LIST3='1.2.3.4
5.6.7.0/24
# комментарий

9.9.9.9 # inline
'
# B6.1: флаг выключен → политика A: error МИМО VPN, DROP снят, не установлен
R="$(t_gate "$LIST3" "KEENZOO_FAIL_CLOSED_NO_TABLE=0")"
has  "B6.1 политика A: честный error" "$R" "E:VPN-набор unblockvpn-X"
has  "B6.1 «МИМО VPN»" "$R" "МИМО VPN"
has  "B6.1 fallback DROP снят (детерминизм)" "$R" "Xd:unblockvpn-X"
hasnt "B6.1 DROP не устанавливался" "$R" "A:unblockvpn-X"
# B6.2: флаг включен (env) → набор заполнен и закрыт DROP
rm -rf "$W/ipset_state"
R="$(t_gate "$LIST3" "KEENZOO_FAIL_CLOSED_NO_TABLE=1")"
has  "B6.2 error: закрыт fail-closed DROP" "$R" "закрыт fail-closed DROP"
has  "B6.2 (3 записи)" "$R" "3 записей"
has  "B6.2 fallback_add вызван" "$R" "A:unblockvpn-X"
has  "B6.2 пакетный restore" "$R" "ipset restore"
has  "B6.2 атомарный swap" "$R" "ipset swap"
hasnt "B6.2 ЖИВОЙ набор не flush'ится (r39)" "$R" "flush unblockvpn-X"
hasnt "B6.2 degraded нет" "$R" "D:VPN"
# B6.3: постоянный маркер-файл (путь NDM-запусков; env прошивкой не
# передаётся). В извлечённой fixture production-путь подменён на $W:
# тест не требует root и не трогает живой /opt.
rm -rf "$W/ipset_state"
mkdir -p "${KZ_A9_FC_MARK%/*}"
: > "$KZ_A9_FC_MARK"
R="$(t_gate "$LIST3" "KEENZOO_FAIL_CLOSED_NO_TABLE=0")"
rm -f "$KZ_A9_FC_MARK"
has  "B6.3 маркер-файл включает fail-closed" "$R" "закрыт fail-closed DROP"
# B6.4: записи не применимы (ipset add отказ) → DROP не считается блокировкой
rm -rf "$W/ipset_state"
R="$(t_gate "$LIST3" "KEENZOO_FAIL_CLOSED_NO_TABLE=1 IPSET_RESTORE_FAIL=1")"
has  "B6.4 restore-отказ: набор не подготовлен" "$R" "не подготовлен"
has  "B6.4 прежняя блокировка сохранена" "$R" "прежняя блокировка сохранена"
hasnt "B6.4 swap не выполнялся" "$R" "ipset swap"
# B6.5: fallback_add отказал → небезопасно
rm -rf "$W/ipset_state"
R="$(t_gate "$LIST3" "KEENZOO_FAIL_CLOSED_NO_TABLE=1 FADD_FAIL=1")"
has  "B6.5 DROP не установлен → небезопасно" "$R" "fail-closed DROP не установлен"
# B6.6: активных записей нет → degraded, DROP снят
rm -rf "$W/ipset_state"
R="$(t_gate "# только комментарии

" "KEENZOO_FAIL_CLOSED_NO_TABLE=1")"
has  "B6.6 пустой список → degraded" "$R" "D:VPN-набор unblockvpn-X"
has  "B6.6 stale DROP снят" "$R" "Xd:unblockvpn-X"
hasnt "B6.6 DROP не ставился" "$R" "A:unblockvpn-X"

echo "════════════════════════════════════════════════════════"
echo "ИТОГ audit9_fixture (shell): PASS=$PASS FAIL=$FAIL"
[ "$FAIL" = 0 ] || exit 1
exit 0
