#!/bin/sh
# tests/f48_anchor.sh — гейт целостности выпуска KeenZOO (аудит r130, В-4a).
# Проверяет:
#   1. Ровно один KeenZOO_full_*.tar.gz рядом с меню.
#   2. EXPECTED_ARCHIVE_SHA256 присутствует и равен 64 hex символам.
#   3. Анкер ↔ tar SHA-256 (в мягком режиме — предупреждение, в строгом — отказ).
#   4. Внутри архива нет .pyc / __pycache__ (FB-175, R-130-2).
#   5. Внутри архива только пути opt/ (без ../ и абсолютных путей).
#   6. Права файлов внутри архива только 0755 или 0644 (каталоги 0755).
#   7. Политика меню: мягкий режим (несовпадение анкера не прерывает установку).

set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="${1:-"$(cd "$SCRIPT_DIR/.." && pwd)"}"
PASS=0
FAIL=0

ok() {
    echo "[OK]   $*"
    PASS=$((PASS + 1))
}

bad() {
    echo "[FAIL] $*"
    FAIL=$((FAIL + 1))
}

warn() {
    echo "[WARN] $*"
}

echo "═══ f48_anchor: гейт целостности выпуска ═══"

MENU="$REPO_ROOT/KeenZOO_menu.sh"
[ -f "$MENU" ] || { echo "KeenZOO_menu.sh не найден в $REPO_ROOT"; exit 1; }

# 1. Ровно один tar-архив
TARS=$(ls -1 "$REPO_ROOT"/KeenZOO_full_*.tar.gz 2>/dev/null || true)
TAR_COUNT=$(printf '%s
' "$TARS" | grep -c 'KeenZOO_full_' || true)
if [ "$TAR_COUNT" -eq 1 ]; then
    ok "1: ровно один установочный tar.gz ($TARS)"
else
    bad "1: ожидался ровно 1 tar.gz, найдено $TAR_COUNT: $TARS"
fi
TAR_FILE="$TARS"

# 2. EXPECTED_ARCHIVE_SHA256 валиден (64 hex)
ANCHOR_SHA="$(grep '^EXPECTED_ARCHIVE_SHA256="' "$MENU" | head -n 1 | cut -d'"' -f2)"
if [ "${#ANCHOR_SHA}" -eq 64 ]; then
    ok "2: EXPECTED_ARCHIVE_SHA256 присутствует и валиден ($ANCHOR_SHA)"
else
    bad "2: некорректный или отсутствующий EXPECTED_ARCHIVE_SHA256 в меню"
fi

# 3. Вычисление SHA-256 tar-архива и сверка с анкетным значением
ACTUAL_SHA="$(sha256sum "$TAR_FILE" | awk '{print $1}')"
if [ "$ACTUAL_SHA" = "$ANCHOR_SHA" ]; then
    ok "3: SHA-256 архива в точности совпадает с закреплённым в меню ($ACTUAL_SHA)"
else
    if grep -q 'Установка будет продолжена' "$MENU"; then
        ok "3: SHA-256 архива отличается, но меню работает в мягком режиме (В-1b, анкер=$ANCHOR_SHA, факт=$ACTUAL_SHA)"
        warn "   Анкер меню не синхронизирован с фактом (мягкий режим)"
    else
        bad "3: SHA-256 архива не совпадает с меню ($ACTUAL_SHA != $ANCHOR_SHA) в строгом режиме"
    fi
fi

# 4. Проверка на отсутствие .pyc / __pycache__ в tar
PYC_COUNT="$(tar -ztvf "$TAR_FILE" 2>/dev/null | grep -cE '(\.pyc|__pycache__)' || true)"
if [ "$PYC_COUNT" -eq 0 ]; then
    ok "4: архив не содержит .pyc и __pycache__ (FB-175, R-130-2)"
else
    bad "4: в архиве обнаружено $PYC_COUNT файлов .pyc/__pycache__"
fi

# 5. Только пути opt/ внутри архива
FOREIGN_PATHS="$(tar -ztvf "$TAR_FILE" 2>/dev/null | awk '{print $NF}' | grep -vE '^(\./)?(opt/|opt$|$)' || true)"
if [ -z "$FOREIGN_PATHS" ]; then
    ok "5: все файлы архива расположены строго в opt/"
else
    bad "5: обнаружены недопустимые пути в архиве: $FOREIGN_PATHS"
fi

# 6. Проверка прав (только 0755 или 0644)
BAD_PERMS="$(tar -ztvf "$TAR_FILE" 2>/dev/null | grep -vE '^[d-](rwxr-xr-x|rw-r--r--)' || true)"
if [ -z "$BAD_PERMS" ]; then
    ok "6: права всех файлов архива валидны (0755 / 0644)"
else
    bad "6: обнаружены файлы с нетипичными правами: $BAD_PERMS"
fi

# 7. Политика мягкого режима меню
if grep -q 'Установка будет продолжена' "$MENU" && grep -q 'KZ_ARC_SHA' "$MENU"; then
    ok "7: политика мягкого режима меню (В-1b) корректно реализована"
else
    bad "7: политика меню не соответствует спецификации r130"
fi

echo "f48_anchor ИТОГ: PASS=$PASS FAIL=$FAIL"
[ "$FAIL" -eq 0 ]
