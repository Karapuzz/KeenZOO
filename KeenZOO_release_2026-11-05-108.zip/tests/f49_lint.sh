#!/bin/sh
# tests/f49_lint.sh — гейт статического разбора shell-скриптов (shellcheck).
# Мягкий режим: нет shellcheck → SKIP (стенд работает офлайн).
#   $1 — корень проекта (по умолчанию — родитель каталога tests/).
#
# r211 (аудит r206): проверка файлов целиком без искусственного разбиения
# с флагом --extended-analysis=false (исключает OOM killer на крупных файлах
# и гарантирует 100% корректность синтаксического анализа heredoc).
set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="${1:-$(cd "$SCRIPT_DIR/.." && pwd)}"
PASS=0
FAIL=0
SKIP=0

ok()   { echo "[OK]   $*"; PASS=$((PASS + 1)); }
bad()  { echo "[FAIL] $*"; FAIL=$((FAIL + 1)); }
skip() { echo "[SKIP] $*"; SKIP=$((SKIP + 1)); }

echo "═══ f49_lint: линтинг shell-скриптов (shellcheck -S error) ═══"

# Список файлов: opt/bin, opt/etc/init.d, opt/etc/ndm + меню.
SCRIPTS=""
for d in "$REPO_ROOT/opt/bin" "$REPO_ROOT/opt/etc/init.d" "$REPO_ROOT/opt/etc/ndm"; do
    [ -d "$d" ] || continue
    for f in $(find "$d" -type f \( -name '*.sh' -o -name 'S[0-9]*' \) 2>/dev/null | sort); do
        SCRIPTS="$SCRIPTS $f"
    done
done
[ -f "$REPO_ROOT/KeenZOO_menu.sh" ] && SCRIPTS="$SCRIPTS $REPO_ROOT/KeenZOO_menu.sh"

COUNT=$(printf '%s\n' $SCRIPTS | grep -c . || true)
[ "${COUNT:-0}" -gt 0 ] && ok "1: файлов к разбору — $COUNT" \
    || bad "1: не найдено ни одного файла (неверный корень: $REPO_ROOT)"

if ! command -v shellcheck >/dev/null 2>&1; then
    skip "shellcheck не установлен — статический разбор пропущен (опциональный гейт)"
    echo "f49_lint ИТОГ: PASS=$PASS FAIL=$FAIL SKIP=$SKIP"
    [ "$FAIL" -eq 0 ]
    exit $?
fi

# lint_one <файл> — 0 = чисто; 1 = находки или сбой анализатора (отчёт в stdout)
lint_one() {
    _lo_rc=0
    _lo_out="$(shellcheck --extended-analysis=false -S error -e SC1090,SC1091 "$1" 2>&1)" || _lo_rc=$?
    [ "$_lo_rc" -eq 0 ] && return 0
    case "$_lo_out" in
        *"SC"[0-9][0-9][0-9][0-9]" (error)"*)
            printf '%s\n' "$_lo_out"
            return 1 ;;
        *)
            [ -n "$_lo_out" ] && printf '%s\n' "$_lo_out" | head -5
            echo "shellcheck не смог разобрать файл (rc=$_lo_rc, без отчёта SCxxxx)"
            return 1 ;;
    esac
}

failed_count=0
for s in $SCRIPTS; do
    rel="${s#$REPO_ROOT/}"
    if ! body="$(lint_one "$s")"; then
        echo "FAIL $rel:"
        printf '%s\n' "$body"
        failed_count=$((failed_count + 1))
    fi
done

if [ "$failed_count" -eq 0 ]; then
    ok "2: shellcheck -S error — ошибок нет ни в одном файле поставки"
else
    bad "2: скриптов с ошибками shellcheck — $failed_count"
fi

echo "f49_lint ИТОГ: PASS=$PASS FAIL=$FAIL SKIP=$SKIP"
[ "$FAIL" -eq 0 ]
