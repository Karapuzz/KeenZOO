#!/bin/sh
# tests/f49_lint.sh — гейт статического разбора shell-скриптов (shellcheck).
# Мягкий режим: нет shellcheck → SKIP (стенд работает офлайн).
#   $1 — корень проекта (по умолчанию — родитель каталога tests/).
#
# r210 (аудит r205/r134):
#  1) Отказ от произвольного разбиения по пустым строкам (ломало heredoc).
#  2) Крупные файлы разбиваются только по границам функций ('^}'),
#     а валидатор _parse_ok проверяет целостность синтаксиса и heredoc.
#  3) Ошибки самого shellcheck (rc != 0) строго фиксируются как FAIL.
set -u

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="${1:-$(cd "$SCRIPT_DIR/.." && pwd)}"
PASS=0
FAIL=0
SKIP=0

ok()   { echo "[OK]   $*"; PASS=$((PASS + 1)); }
bad()  { echo "[FAIL] $*"; FAIL=$((FAIL + 1)); }
skip() { echo "[SKIP] $*"; SKIP=$((SKIP + 1)); }

echo "═══ f49_lint: линтинг shell-скриптов (shellcheck -S error) ═══"

# Список файлов: opt/bin, opt/etc/init.d, opt/etc/ndm + меню.
SCRIPTS=""
for d in "$REPO_ROOT/opt/bin" "$REPO_ROOT/opt/etc/init.d" "$REPO_ROOT/opt/etc/ndm"; do
    [ -d "$d" ] || continue
    for f in $(find "$d" -type f \( -name '*.sh' -o -name 'S[0-9]*' \) 2>/dev/null | sort); do
        SCRIPTS="$SCRIPTS $f"
    done
done
[ -f "$REPO_ROOT/KeenZOO_menu.sh" ] && SCRIPTS="$SCRIPTS $REPO_ROOT/KeenZOO_menu.sh"

COUNT=$(printf '%s\n' $SCRIPTS | grep -c . || true)
[ "${COUNT:-0}" -gt 0 ] && ok "1: файлов к разбору — $COUNT" \
    || bad "1: не найдено ни одного файла (неверный корень: $REPO_ROOT)"

if ! command -v shellcheck >/dev/null 2>&1; then
    skip "shellcheck не установлен — статический разбор пропущен (опциональный гейт)"
    echo "f49_lint ИТОГ: PASS=$PASS FAIL=$FAIL SKIP=$SKIP"
    [ "$FAIL" -eq 0 ]
    exit $?
fi

TMPD="${TMPDIR:-/tmp}/f49_chunks.$$"
mkdir -p "$TMPD" 2>/dev/null || TMPD=""
trap 'rm -rf "$TMPD" 2>/dev/null || true' EXIT INT TERM
CHUNK_LINES=900

# lint_one <файл> — 0 = чисто; 1 = находки или сбой анализатора (отчёт в stdout)
lint_one() {
    _lo_rc=0
    _lo_out="$(shellcheck -S error -e SC1090,SC1091 "$1" 2>&1)" || _lo_rc=$?
    [ "$_lo_rc" -eq 0 ] && return 0
    case "$_lo_out" in
        *"SC"[0-9][0-9][0-9][0-9]" (error)"*)
            printf '%s\n' "$_lo_out"
            return 1 ;;
        *)
            [ -n "$_lo_out" ] && printf '%s\n' "$_lo_out" | head -5
            echo "shellcheck не смог разобрать файл (rc=$_lo_rc, без отчёта SCxxxx)"
            return 1 ;;
    esac
}

# _parse_ok <файл> — 0, если файл разбирается целиком и нет оборванных heredoc
_parse_ok() {
    _po_out=""
    if command -v bash >/dev/null 2>&1; then
        _po_out="$(bash -n "$1" 2>&1)" || return 1
        case "$_po_out" in
            *"here-document"*"delimited by end-of-file"*) return 1 ;;
        esac
    fi
    if command -v busybox >/dev/null 2>&1; then
        busybox ash -n "$1" >/dev/null 2>&1 || return 1
    fi
    sh -n "$1" >/dev/null 2>&1
}

# _make_part <файл> <с_строки> <по_строку> <куда> — вырезает часть
_make_part() {
    { echo '#!/bin/sh'; sed -n "${2},${3}p" "$1"; } > "$4" 2>/dev/null
}

# chunk_ok <файл> — разбирает крупный файл частями; печатает отчёт о
# проблемных частях, rc 0 = чисто. Части пишутся в $TMPD.
chunk_ok() {
    _ck_file="$1"
    _ck_total=$(awk 'END { print NR }' "$_ck_file" 2>/dev/null || echo 0)
    # кандидаты границ: только строки с закрывающей фигурной скобкой '^}' (конец функций)
    _ck_cands=$(awk '/^}/ { print NR }' "$_ck_file" 2>/dev/null)
    _ck_start=1
    _ck_i=0
    _ck_rc=0
    while [ "$_ck_start" -le "$_ck_total" ]; do
        _ck_i=$((_ck_i + 1))
        _ck_part="$TMPD/p$_ck_i.sh"
        _ck_end=0
        for _ck_c in $_ck_cands; do
            [ "$_ck_c" -le "$_ck_start" ] && continue
            [ $((_ck_c - _ck_start + 1)) -lt "$CHUNK_LINES" ] && continue
            _make_part "$_ck_file" "$_ck_start" "$_ck_c" "$_ck_part"
            if _parse_ok "$_ck_part"; then
                _ck_end=$_ck_c
                break
            fi
            # слишком далеко ушли — пробуем следующую
            [ $((_ck_c - _ck_start)) -gt $((CHUNK_LINES * 4)) ] && break
        done
        if [ "$_ck_end" -eq 0 ]; then
            # подходящей границы нет — берём остаток файла целиком
            _ck_end=$_ck_total
            _make_part "$_ck_file" "$_ck_start" "$_ck_end" "$_ck_part"
        fi
        if ! _ck_body="$(lint_one "$_ck_part")"; then
            _ck_rc=1
            echo "  часть $_ck_i (строки $_ck_start-$_ck_end):"
            printf '%s\n' "$_ck_body" | sed 's/^/  /'
        fi
        rm -f "$_ck_part"
        _ck_start=$((_ck_end + 1))
    done
    echo "  [i] частей: $_ck_i (границы проверены ash -n/bash -n)"
    return "$_ck_rc"
}

failed_count=0
for s in $SCRIPTS; do
    rel="${s#$REPO_ROOT/}"
    lines=$(awk 'END { print NR }' "$s" 2>/dev/null || echo 0)
    if [ -n "$TMPD" ] && [ "${lines:-0}" -gt $((CHUNK_LINES * 2)) ]; then
        echo "  … $rel: крупный файл, разбор по частям по $CHUNK_LINES строк"
        if ! chunk_ok "$s"; then
            bad "2: $rel — shellcheck нашёл ошибки (см. выше)"
            failed_count=$((failed_count + 1))
        fi
        continue
    fi
    if ! body="$(lint_one "$s")"; then
        echo "FAIL $rel:"
        printf '%s\n' "$body"
        failed_count=$((failed_count + 1))
    fi
done

if [ "$failed_count" -eq 0 ]; then
    ok "2: shellcheck -S error — ошибок нет ни в одном файле поставки"
else
    bad "2: скриптов с ошибками shellcheck — $failed_count"
fi

echo "f49_lint ИТОГ: PASS=$PASS FAIL=$FAIL SKIP=$SKIP"
[ "$FAIL" -eq 0 ]
