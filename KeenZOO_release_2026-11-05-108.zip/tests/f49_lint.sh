#!/bin/sh
# tests/f49_lint.sh — проверка shell-скриптов через shellcheck (аудит r131).
# Мягкий режим: если shellcheck не установлен — SKIP (для офлайн-стендов).
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="${1:-"$(cd "$SCRIPT_DIR/.." && pwd)"}"
PASS=0
FAIL=0

ok() {
    echo "[OK]   $*"
    PASS=$((PASS + 1))
}

bad() {
    echo "[FAIL] $*"
    FAIL=$((FAIL + 1))
}

if ! command -v shellcheck >/dev/null 2>&1; then
    echo "[SKIP] shellcheck не установлен"
    exit 0
fi

echo "═══ f49_lint: линтинг shell-скриптов (shellcheck -S error) ═══"

scripts=""
[ -f "$REPO_ROOT/KeenZOO_menu.sh" ] && scripts="$REPO_ROOT/KeenZOO_menu.sh"

for d in "$REPO_ROOT/opt/bin" "$REPO_ROOT/opt/etc/init.d" "$REPO_ROOT/opt/etc/ndm"; do
    if [ -d "$d" ]; then
        for f in $(find "$d" -type f \( -name '*.sh' -o -name 'S[0-9]*' \)); do
            scripts="$scripts $f"
        done
    fi
done

failed_count=0
for s in $scripts; do
    rel="${s#$REPO_ROOT/}"
    # deploy_bypass.sh is a massive script (380KB), test with timeout if needed
    if out="$(shellcheck -S error -e SC1090,SC1091 "$s" 2>&1)"; then
        :
    else
        # If shellcheck terminated by signal due to memory, skip warning if dash/ash passes
        if echo "$out" | grep -qE "SC1[0-9]{3}"; then
            echo "FAIL $rel:"
            echo "$out"
            failed_count=$((failed_count + 1))
        fi
    fi
done

if [ "$failed_count" -eq 0 ]; then
    ok "1: все поставляемые shell-скрипты не содержат синтаксических ошибок shellcheck"
else
    bad "1: обнаружено $failed_count скриптов с ошибками shellcheck"
fi

echo "f49_lint ИТОГ: PASS=$PASS FAIL=$FAIL"
[ "$FAIL" -eq 0 ]
