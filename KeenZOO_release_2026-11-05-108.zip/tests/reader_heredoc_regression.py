#!/usr/bin/env python3
"""
Регрессионный набор reader_heredoc_regression.py (FB-228 / FB-229 / FB-230 / FB-231).
Проверяет паритет чтения и переписывания ENABLED= между lists_core и BusyBox ash
на сложных heredoc-конструкциях в шапке init-скрипта (включая quoted/unquoted, continuations,
пустые делимитеры, символы # в делимитере, command substitutions и строковые литералы).
"""

import glob
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest

# Динамическое определение корня проекта строго относительно этого файла
TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.normpath(os.path.join(TESTS_DIR, ".."))
BOT_DIR = os.path.join(PROJECT_ROOT, "opt", "etc", "bot")

# Если runtime не распакован (запуск из распакованного ZIP без дерева opt/),
# извлекаем opt/etc/bot из релизного tar.gz во временный каталог.
_EXTRACTED_TMP = None
if not os.path.isdir(BOT_DIR):
    tars = sorted(glob.glob(os.path.join(PROJECT_ROOT, "KeenZOO_full_*.tar.gz")))
    if tars:
        _EXTRACTED_TMP = tempfile.mkdtemp(prefix="kz_runtime_")
        with tarfile.open(tars[-1], "r:*") as tf:
            for member in tf.getmembers():
                if member.name.startswith("opt/etc/bot"):
                    tf.extract(member, _EXTRACTED_TMP)
        candidate = os.path.join(_EXTRACTED_TMP, "opt", "etc", "bot")
        if os.path.isdir(candidate):
            BOT_DIR = candidate

if os.path.isdir(BOT_DIR):
    if BOT_DIR in sys.path:
        sys.path.remove(BOT_DIR)
    sys.path.insert(0, BOT_DIR)

import lists_core


def ash_eval_enabled(script_content):
    """Выполняет скрипт через busybox ash и возвращает значение ENABLED (True/False)."""
    ash_bin = shutil.which("ash") or shutil.which("busybox")
    if not ash_bin:
        return None
    with tempfile.NamedTemporaryFile("w", suffix=".sh", delete=False) as f:
        f.write(script_content)
        f.write("\nprintf '\\n___KZ_END_RESULT:%s___\\n' \"$ENABLED\"\n")
        f_path = f.name
    try:
        if ash_bin.endswith("busybox"):
            cmd = [ash_bin, "ash", f_path]
        else:
            cmd = [ash_bin, f_path]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if res.returncode != 0:
            raise AssertionError(f"BusyBox ash failed with rc={res.returncode}: {res.stderr}")
        m = re.findall(r'___KZ_END_RESULT:(\S+)___', res.stdout or "")
        if m:
            return (m[-1] == "yes")
        raise AssertionError(f"BusyBox ash output did not contain result marker: {res.stdout}")
    finally:
        try:
            os.remove(f_path)
        except OSError:
            pass


class TestReaderHeredocRegression(unittest.TestCase):
    @classmethod
    def tearDownClass(cls):
        global _EXTRACTED_TMP
        if _EXTRACTED_TMP and os.path.isdir(_EXTRACTED_TMP):
            try:
                shutil.rmtree(_EXTRACTED_TMP)
            except OSError:
                pass
            _EXTRACTED_TMP = None

    def _check_case(self, script_text, expected_val, name=""):
        lines = script_text.splitlines(True)
        py_val = lists_core.enabled_from_lines(lines)
        self.assertEqual(py_val, expected_val, f"lists_core mismatch for {name}: got {py_val}, expected {expected_val}")
        
        ash_val = ash_eval_enabled(script_text)
        if ash_val is None:
            raise unittest.SkipTest(f"BusyBox ash not found on host for {name}")
        self.assertEqual(ash_val, expected_val, f"ash mismatch for {name}: got {ash_val}, expected {expected_val}")

    def test_01_single_heredoc_then_no(self):
        s = """ENABLED=yes; : <<A
x
A
ENABLED=no
"""
        self._check_case(s, False, "01_single_heredoc_then_no")

    def test_02_single_heredoc_then_yes(self):
        s = """ENABLED=no; : <<EOF
some text
EOF
ENABLED=yes
"""
        self._check_case(s, True, "02_single_heredoc_then_yes")

    def test_03_tab_stripped_heredoc(self):
        s = """ENABLED=yes; cat <<- 'TAG'
\tline inside heredoc
\tTAG
ENABLED=no
"""
        self._check_case(s, False, "03_tab_stripped_heredoc")

    def test_04_two_heredocs_one_line(self):
        s = """ENABLED=yes; cat <<A <<B
line A
A
line B
B
ENABLED=no
"""
        self._check_case(s, False, "04_two_heredocs_one_line")

    def test_05_heredoc_in_assignment(self):
        s = """ENABLED=yes; X=cat <<EOF
sub line
EOF
ENABLED=no
"""
        self._check_case(s, False, "05_heredoc_in_assignment")

    def test_06_enabled_inside_heredoc_body_ignored(self):
        s = """ENABLED=no; : <<EOF
ENABLED=yes
EOF
"""
        self._check_case(s, False, "06_enabled_inside_heredoc_body_ignored")

    def test_07_heredoc_with_quoted_delimiter(self):
        s = """ENABLED=yes; : <<"END_OF_DOC"
ENABLED=yes
$VAR
END_OF_DOC
ENABLED=no
"""
        self._check_case(s, False, "07_heredoc_with_quoted_delimiter")

    def test_08_heredoc_with_spaces_in_body(self):
        s = """ENABLED=yes; : <<A
  leading spaces A
  A
A
ENABLED=no
"""
        self._check_case(s, False, "08_heredoc_with_spaces_in_body")

    def test_09_three_heredocs_multiline(self):
        s = """ENABLED=yes; cat <<A <<B <<C
bodyA
A
bodyB
B
bodyC
C
ENABLED=no
"""
        self._check_case(s, False, "09_three_heredocs_multiline")

    def test_10_heredoc_in_middle_assignment_kept(self):
        s = """ENABLED=yes
X=1
: <<EOF
comment
EOF
Y=2
"""
        self._check_case(s, True, "10_heredoc_in_middle_assignment_kept")

    def test_11_quoted_heredoc_backslash_continuation(self):
        # B-17: Quoted heredoc does not join backslash-newline; next line EOF is delimiter
        s = """ENABLED=yes; X=cat <<'EOF'
body\\
EOF
ENABLED=no
"""
        self._check_case(s, False, "11_quoted_heredoc_backslash_continuation")

    def test_12_unquoted_heredoc_backslash_continuation(self):
        # B-17: Unquoted heredoc joins backslash-newline; next line is body, second EOF is delimiter
        s = """ENABLED=no; cat <<EOF
foo\\
EOF
ENABLED=preserve
EOF
ENABLED=yes
"""
        self._check_case(s, True, "12_unquoted_heredoc_backslash_continuation")

    def test_13_empty_quoted_delimiter(self):
        # B-20: Empty quoted delimiter <<'' or <<"" terminated by blank line
        s = """ENABLED=no; cat <<''
ENABLED=preserve

ENABLED=yes
"""
        self._check_case(s, True, "13_empty_quoted_delimiter")

    def test_14_hash_in_delimiter(self):
        # B-20: Delimiter containing # (<<END#x) is treated as full delimiter name
        s = """ENABLED=no; cat <<END#x
END
ENABLED=preserve
END#x
ENABLED=yes
"""
        self._check_case(s, True, "14_hash_in_delimiter")

    def test_15_rewrite_preserves_unquoted_heredoc_body(self):
        # B-17: rewrite_enabled_lines must not delete lines from unquoted heredoc body
        orig = """ENABLED=no
cat <<EOF
foo\\
EOF
ENABLED=preserve
EOF
"""
        out, changed = lists_core._rewrite_enabled_pass(orig.splitlines(True), False)
        out_text = "".join(out)
        self.assertIn("ENABLED=preserve", out_text, "Heredoc body line ENABLED=preserve must not be deleted!")

    def test_16_rewrite_preserves_empty_delimiter_and_hash_delimiter(self):
        # B-20: rewrite_enabled_lines must preserve bodies of <<'' and <<END#x
        s1 = """ENABLED=no
cat <<''
ENABLED=preserve

"""
        out1, _ = lists_core._rewrite_enabled_pass(s1.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out1))

        s2 = """ENABLED=no
cat <<END#x
END
ENABLED=preserve
END#x
"""
        out2, _ = lists_core._rewrite_enabled_pass(s2.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out2))

    def test_17_heredoc_inside_command_substitution(self):
        # B-21: Heredoc inside "$(cat <<'EOF'...)" command substitution
        s = """ENABLED=no
X="$(cat <<'EOF'
ENABLED=preserve
EOF
)"
ENABLED=yes
"""
        self._check_case(s, True, "17_heredoc_inside_command_substitution")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out))

    def test_18_heredoc_inside_backticks(self):
        # B-21: Heredoc inside `cat <<'EOF'...` backticks
        s = """ENABLED=no
X=`cat <<'EOF'
ENABLED=preserve
EOF
`
ENABLED=yes
"""
        self._check_case(s, True, "18_heredoc_inside_backticks")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out))

    def test_19_continuation_preserves_trailing_commands(self):
        # r157 P1: ENABLED=\\nyes; PROCS=xray does not leave orphaned yes
        s = """ENABLED=\\
yes; PROCS=xray
"""
        out_false, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_text = "".join(out_false)
        self.assertIn("ENABLED=no; PROCS=xray", out_text)
        self.assertNotIn("\nyes;\n", out_text)
        self.assertFalse(lists_core.enabled_from_lines(out_false))

    def test_20_literal_string_in_command_preserved(self):
        # r157 P1: if true; then printf '%s\n' ' ENABLED=no'; fi does not corrupt quotes
        s = """#!/bin/sh
if true; then printf '%s\\n' ' ENABLED=no'; fi
"""
        out_true, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        out_text = "".join(out_true)
        self.assertIn("if true; then printf '%s\\n' ' ENABLED=no'; fi", out_text)
        self.assertTrue(lists_core.enabled_from_lines(out_true))

    def test_21_comment_with_trailing_backslash_not_continued(self):
        # B-22: Comments ending with \ do not consume subsequent command line
        s = """ENABLED=no
printf "A\\n" # ENABLED is metadata \\
printf "IMPORTANT\\n"
printf "STATE:%s\\n" "$ENABLED"
"""
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_text = "".join(out)
        self.assertIn("printf \"IMPORTANT\\n\"", out_text)
        self.assertFalse(lists_core.enabled_from_lines(out))

    def test_22_heredoc_after_continuation_line(self):
        # B-22 / r158 P1: Heredoc opened on continuation line is preserved
        s = """ENABLED=no; cat \\
<<'EOF'
ENABLED=data\\
EOF
printf "AFTER\\n"
"""
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_text = "".join(out)
        self.assertIn("ENABLED=data\\", out_text)
        self.assertIn("printf \"AFTER\\n\"", out_text)
        self.assertEqual(out_text.count("ENABLED=no"), 1)
        self.assertFalse(lists_core.enabled_from_lines(out))

    def test_23_multiline_string_literal_data_preserved(self):
        # B-23: Multiline string literals with ENABLED= are not mistaken for service state
        s = """ENABLED=no
X='text
ENABLED=yes
end'
printf "DATA:%s STATE:%s" "$X" "$ENABLED"
"""
        self._check_case(s, False, "23_multiline_string_literal")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_text = "".join(out)
        self.assertIn("ENABLED=yes", out_text)
        self.assertFalse(lists_core.enabled_from_lines(out))

    def test_24_long_continuation_chain_preserves_commands(self):
        # r158 P1: Long continuation chains do not orphan commands as bare 'yes'
        s = """ENABLED=\\
\\
\\
\\
\\
\\
\\
\\
\\
yes; PROCS=xray
"""
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_text = "".join(out)
        self.assertIn("ENABLED=no; PROCS=xray", out_text)
        self.assertNotIn("\nyes;\n", out_text)
        self.assertFalse(lists_core.enabled_from_lines(out))

    def test_25_heredoc_opener_with_duplicate_enabled_not_dropped(self):
        # r159 P1: Duplicate ENABLED= followed by heredoc opener (: <<'EOF') must NOT drop the opener line
        s = """ENABLED=no
ENABLED=no; : <<'EOF'
printf 'executed' > '/tmp/kz_test_sentinel'
EOF
exit 0
"""
        out_no, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_yes, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        self.assertIn(": <<'EOF'", "".join(out_no))
        self.assertIn(": <<'EOF'", "".join(out_yes))
        self.assertFalse(lists_core.enabled_from_lines(out_no))
        self.assertTrue(lists_core.enabled_from_lines(out_yes))

    def test_26_continuation_heredoc_prefix_assignment(self):
        # r108bi P2 / r159 P1: Continuation with heredoc opener and prefix assignment preserves cat command and body
        s = """ENABLED=no
ENABLED=no cat \\
<<'EOF'
ENABLED=keep\\
tail
EOF
printf '\\nSTATE:%s' "$ENABLED"
"""
        out_no, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_yes, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        text_no = "".join(out_no)
        text_yes = "".join(out_yes)
        self.assertIn("ENABLED=keep\\", text_no)
        self.assertIn("tail", text_no)
        self.assertIn("ENABLED=keep\\", text_yes)
        self.assertIn("tail", text_yes)
        self.assertFalse(lists_core.enabled_from_lines(out_no))
        self.assertTrue(lists_core.enabled_from_lines(out_yes))

    def test_27_multiline_string_fastpath_protection(self):
        # r108bi P2: Standalone ENABLED= inside multiline literal without outer ENABLED= is not corrupted by fastpath
        s = """X='text
ENABLED=yes
end'
printf 'DATA:%s' "$X"
"""
        out_no, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        text_no = "".join(out_no)
        self.assertIn("ENABLED=yes", text_no)
        self.assertIn("ENABLED=no\n", text_no)
        self.assertFalse(lists_core.enabled_from_lines(out_no))

    def test_28_multiline_closing_line_with_commands(self):
        # r159 P1/P2: Commands following multiline string closure on the same physical line are parsed correctly
        s_true = """ENABLED=no
X='hello
world'; ENABLED=yes
"""
        s_false = """ENABLED=yes
X='hello
world'; ENABLED=no
"""
        self._check_case(s_true, True, "28_multiline_closing_true")
        self._check_case(s_false, False, "28_multiline_closing_false")

    def test_29_multiline_closing_line_with_multiple_quotes_and_commands(self):
        # r108bj B-26 / r160: Closing line of multiline string containing subsequent quotes & commands is parsed & rewritten correctly
        s = """ENABLED=no
X='alpha
beta'; ENABLED=yes; Y='later'
printf 'STATE:%s DATA:%s Y:%s' "$ENABLED" "$X" "$Y"
"""
        self.assertTrue(lists_core.enabled_from_lines(s.splitlines(True)))
        out_no, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_yes, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        self.assertFalse(lists_core.enabled_from_lines(out_no))
        self.assertTrue(lists_core.enabled_from_lines(out_yes))
        self._check_case("".join(out_no), False, "29_multiline_multiple_quotes_no")
        self._check_case("".join(out_yes), True, "29_multiline_multiple_quotes_yes")

    def test_30_prefix_command_preserved_when_rewritten(self):
        # r108bj B-27 / r160: Prefix assignment with command preserves the command
        s = """ENABLED=no
ENABLED=no printf 'IMPORTANT\\n'
printf 'STATE:%s' "$ENABLED"
"""
        out_no, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_yes, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        self.assertIn("printf 'IMPORTANT\\n'", "".join(out_no))
        self.assertIn("printf 'IMPORTANT\\n'", "".join(out_yes))
        self.assertFalse(lists_core.enabled_from_lines(out_no))
        self.assertTrue(lists_core.enabled_from_lines(out_yes))

    def test_31_prefix_command_with_multiple_assignments_preserved(self):
        # r108bj B-27: Multiple prefix assignments before a command are preserved
        s = """ENABLED=no
ENABLED=no FOO=bar printf 'IMPORTANT\\n'
printf 'STATE:%s' "$ENABLED"
"""
        out_no, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_yes, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        self.assertIn("FOO=bar", "".join(out_no))
        self.assertIn("FOO=bar", "".join(out_yes))
        self.assertIn("printf 'IMPORTANT\\n'", "".join(out_no))
        self.assertIn("printf 'IMPORTANT\\n'", "".join(out_yes))
        self.assertFalse(lists_core.enabled_from_lines(out_no))
        self.assertTrue(lists_core.enabled_from_lines(out_yes))

    def test_32_standalone_multiple_assignments_preserved(self):
        # r108bj B-27: Standalone multiple assignments on one line preserve adjacent variables
        s = """ENABLED=no
ENABLED=no FOO=bar
printf 'STATE:%s FOO:%s' "$ENABLED" "$FOO"
"""
        out_no, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_yes, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        self.assertIn("FOO=bar", "".join(out_no))
        self.assertIn("FOO=bar", "".join(out_yes))
        self.assertFalse(lists_core.enabled_from_lines(out_no))
        self.assertTrue(lists_core.enabled_from_lines(out_yes))



    def test_33_adjacent_multiline_transition_b26(self):
        # B-26: ENABLED= between adjacent closing and opening multiline quotes
        s = """ENABLED=no
X='alpha
beta'; ENABLED=yes; Y='gamma
delta'
printf 'STATE:%s X:%s Y:%s' "$ENABLED" "$X" "$Y"
"""
        self._check_case(s, True, "33_adjacent_multiline_transition_b26")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_s = "".join(out)
        self.assertIn("beta'; ENABLED=no; Y='gamma", out_s)
        self._check_case(out_s, False, "33_adjacent_multiline_transition_b26_rewritten")

    def test_34_subshell_command_substitution_b28(self):
        # B-28: ENABLED= inside $() command substitution tail
        s = """ENABLED=no
X='alpha
beta'; Y=$( ENABLED=no busybox ash -c 'printf %s "$ENABLED"' )
printf 'STATE:%s Y:%s' "$ENABLED" "$Y"
"""
        self._check_case(s, False, "34_subshell_command_substitution_b28")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        out_s = "".join(out)
        self.assertIn("ENABLED=no busybox ash", out_s)
        self._check_case(out_s, True, "34_subshell_command_substitution_b28_rewritten")

    def test_35_nested_subshell_tail_b28(self):
        # B-28: ENABLED= inside (...) subshell tail
        s = """ENABLED=no
X='alpha
beta'; ( ENABLED=no; printf 'INNER:%s' "$ENABLED" )
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s, False, "35_nested_subshell_tail_b28")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        out_s = "".join(out)
        self.assertIn("( ENABLED=no;", out_s)
        self._check_case(out_s, True, "35_nested_subshell_tail_b28_rewritten")


    def test_36_dynamic_env_condition(self):
        # r163 / B-28+B-26: Dynamic variable in test condition [ -n "$FOO" ] || ENABLED=yes
        s1 = """FOO=present
ENABLED=no
[ -n "$FOO" ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s1, False, "36_dynamic_env_condition_present")

        s2 = """FOO=""
ENABLED=no
[ -n "$FOO" ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s2, True, "36_dynamic_env_condition_empty")


    def test_37_posix_quoting_and_sameline_env_b32(self):
        # B-32: Single-quoted string literal should not expand variable
        s_single = """FOO=present
ENABLED=no
[ '$FOO' = present ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_single, True, "37_single_quoted_literal")

        # B-32: Same-line command sequence with sequential env assignment
        s_sameline = """FOO=present; ENABLED=no; [ -n "$FOO" ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_sameline, False, "37_sameline_seq")

        # B-32: Suffix and prefix interpolation in quotes
        s_suffix = """FOO=present
ENABLED=no
[ "${FOO}!" = present! ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_suffix, False, "37_suffix_interpolation")

        s_prefix = """FOO=present
ENABLED=no
[ "x${FOO}" = xpresent ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_prefix, False, "37_prefix_interpolation")

        # B-32: Multiple assignments in a single statement
        s_multi = """FOO=present BAR=val
ENABLED=no
[ -n "$BAR" ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_multi, False, "37_multi_assign")

        # B-32: Variable-to-variable assignment
        s_var2var = """FOO=$BAR
ENABLED=no
[ -z "$FOO" ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_var2var, True, "37_var_to_var")


    def test_38_unicode_escape_nested_default_b35_b37(self):
        # B-35: Unicode character after $ should not crash and be preserved as literal
        s_unicode = """ENABLED=no
[ "$é" = '$é' ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_unicode, True, "38_unicode_dollar")

        # B-37: Escaped space in assignment
        s_space = """FOO=hello\\ world
ENABLED=no
[ "$FOO" = 'hello world' ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_space, True, "38_escaped_space")

        # B-37: Nested default variable expansion
        s_nested = """BAR=present
ENABLED=no
[ "${FOO:-$BAR}" = present ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_nested, True, "38_nested_default")


    def test_39_escaped_dollar_backslash_and_dquote_defaults_b41(self):
        # B-41: Escaped dollar should be preserved literally and not expanded as variable
        s_esc_dollar = r"""FOO=present
BAR=\$FOO
ENABLED=no
[ "$BAR" = '$FOO' ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_esc_dollar, True, "39_escaped_dollar")

        # B-41: Escaped backslash in assignment
        s_esc_bs = r"""FOO=a\\b
ENABLED=no
[ "$FOO" = 'a\b' ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_esc_bs, True, "39_escaped_backslash")

        # B-41: Single quotes inside double-quoted default expansion
        s_dquote_sq = """ENABLED=no
[ "${FOO:-'abc'}" = "'abc'" ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_dquote_sq, True, "39_dquote_single_quotes")


    def test_40_escaped_semicolons_dynamic_conditions_unset_b42(self):
        # B-42: Escaped semicolon in adjacent assignment should not be split
        s_esc_semi = r"""ENABLED=no
X=alpha\;ENABLED=yes
:
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_esc_semi, False, "40_escaped_semicolon")

        # B-42: Escaped double quote with semicolon inside
        s_esc_dquote = r"""ENABLED=no
X="alpha\"; ENABLED=yes; : \"beta"
:
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_esc_dquote, False, "40_escaped_dquote")

        # Dynamic / unknown conditions should not trigger false positive ENABLED state
        s_dynamic_or = """FOO=''
FOO=$(printf present)
ENABLED=no
[ -n "$FOO" ] || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_dynamic_or, False, "40_dynamic_or")

        # unset variable evaluated properly in test condition
        s_unset = """FOO=present
unset FOO
ENABLED=no
[ -z "$FOO" ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_unset, True, "40_unset")

        # Left-associative short-circuit (false && ENABLED=no || ENABLED=yes)
        s_short_circuit = """ENABLED=no
false && ENABLED=no || ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_short_circuit, True, "40_short_circuit")

    def test_41_line_continuation_group_b45(self):
        # B-45: Line continuation across multiple lines with ENABLED in non-first line
        s_cont1 = r"""ENABLED=no
X=alpha\
; ENABLED=yes
:
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_cont1, True, "41_cont_non_first_duplicate")

        s_cont2 = r"""X=alpha\
; ENABLED=yes
:
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_cont2, True, "41_cont_non_first_single")

        s_cont3 = r"""ENABLED=\
yes\
; X=beta
:
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_cont3, True, "41_cont_multi_step")

        # B-45 (r108bs/r169): Escaped semicolon in continuation and multiline quote followed by continuation
        s_cont4 = r"""ENABLED=no
X=pre\
\; ; ENABLED=yes
:
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_cont4, True, "41_cont_escaped_semi")

        s_cont5 = r"""X="foo\
bar"; ENABLED=yes
Y=other\
; ENABLED=yes
printf "STATE:%s" "$ENABLED"
"""
        self._check_case(s_cont5, True, "41_cont_dquote_then_cont")

        # B-50 / r170: EOF continuation without ENABLED (test rewrite without IndexError)
        s_cont6 = """#!/bin/sh
ENABLED=yes
X=abc\\"""
        lines6 = s_cont6.splitlines(keepends=True)
        rewritten6, ok6 = lists_core.rewrite_enabled_lines(lines6, False)
        self.assertTrue(ok6)
        self.assertFalse(lists_core.enabled_from_lines(rewritten6))

        # B-50 / r108bt: Escaped space/tab before semicolon
        s_cont7 = r"""ENABLED=no
X=pre\  ; ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_cont7, True, "41_cont_escaped_space_before_semi")

        s_cont8 = "ENABLED=no\nX=pre\\\t ; ENABLED=yes\nprintf 'STATE:%s' \"$ENABLED\"\n"
        self._check_case(s_cont8, True, "41_cont_escaped_tab_before_semi")

    def test_42_nested_brace_expansions_b46(self):
        # B-46: Nested ${FOO:-${BAR:-...}} parameter expansion
        s_nested1 = r"""BAR=present
ENABLED=no
[ "${FOO:-${BAR:-absent}}" = present ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_nested1, True, "42_nested_brace_fallback")

        s_nested2 = r"""FOO=direct
BAR=present
ENABLED=no
[ "${FOO:-${BAR:-absent}}" = direct ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_nested2, True, "42_nested_brace_direct")

        s_nested3 = r"""ENABLED=no
[ "${FOO:-${BAR:-absent}}" = absent ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_nested3, True, "42_nested_brace_absent")

        s_nested4 = r"""ENABLED=no
[ "${FOO:-${BAR:-${BAZ:-deep}}}" = deep ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_nested4, True, "42_nested_brace_deep")

        # B-48: Single quotes inside default parameter expansion in double quotes context
        s_nested5 = r"""ENABLED=no
[ "${FOO:-x'y}" = "x'y" ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_nested5, True, "42_nested_brace_single_quote_in_dquote")

        s_nested6 = r"""ENABLED=no
[ "${FOO:-'a}b'}" = "'ab'}" ] && ENABLED=yes
printf 'STATE:%s' "$ENABLED"
"""
        self._check_case(s_nested6, True, "42_nested_brace_closing_in_sq")

    def test_43_rewrite_init_enabled_enosps_b44(self):
        # B-44 / B-49: _rewrite_init_enabled handles OSError / ENOSPC / EACCES gracefully
        import errno, unittest.mock as mock, utils
        with tempfile.TemporaryDirectory() as td:
            init_f = os.path.join(td, "S99test")
            with open(init_f, "w") as f:
                f.write("#!/bin/sh\nENABLED=yes\n")

            # Deterministic injection of ENOSPC (passes under both root and non-root):
            with mock.patch("tempfile.mkstemp", side_effect=OSError(errno.ENOSPC, "No space left on device")):
                ret = utils._rewrite_init_enabled(init_f, False)
                self.assertFalse(ret, "Expected False on mkstemp ENOSPC")

            # Deterministic injection of EMFILE:
            with mock.patch("tempfile.mkstemp", side_effect=OSError(errno.EMFILE, "Too many open files")):
                ret = utils._rewrite_init_enabled(init_f, False)
                self.assertFalse(ret, "Expected False on mkstemp EMFILE")

            # Non-root permission test (mode 0555):
            if os.geteuid() != 0:
                os.chmod(td, 0o555)
                try:
                    ret = utils._rewrite_init_enabled(init_f, False)
                    self.assertFalse(ret, "Expected False on unwritable directory")
                finally:
                    os.chmod(td, 0o755)

    def test_44_backup_rollback_setuid_mode_b47(self):
        # B-47: Backup and rollback preserve special mode bits (04755 setuid / 02755 setgid)
        import stat
        with tempfile.TemporaryDirectory() as td:
            sc = os.path.join(td, "S99service")
            with open(sc, "w") as f:
                f.write("#!/bin/sh\nENABLED=no\n")
            os.chmod(sc, 0o4755)
            st = os.stat(sc)
            orig_mode = stat.S_IMODE(st.st_mode)

            # Backup creation sequence with chown + copystat + chmod
            fd, _bak = tempfile.mkstemp(dir=td, prefix=".S99service.kz_orig_")
            with open(sc, 'rb') as f_src:
                with os.fdopen(fd, 'wb') as f_dst:
                    shutil.copyfileobj(f_src, f_dst)
            try:
                os.chown(_bak, st.st_uid, st.st_gid)
            except (OSError, AttributeError):
                pass
            shutil.copystat(sc, _bak)
            try:
                os.chmod(_bak, orig_mode)
            except (OSError, AttributeError):
                pass

            self.assertEqual(stat.S_IMODE(os.stat(_bak).st_mode), 0o4755)
            os.replace(_bak, sc)
            self.assertEqual(stat.S_IMODE(os.stat(sc).st_mode), 0o4755)

    def test_45_param_expansion_forms_b53(self):
        # B-53 / B-54 / B-55: Test parameter expansion & quoting parity with BusyBox ash
        tests = [
            ('[ "${FOO:-x\'y}" = "x\'y" ]', {}, True),
            ('[ "${FOO:-"a b"}" = "a b" ]', {}, True),
            ('[ "${FOO:-\\}}" = "}" ]', {}, True),
            ('[ "${FOO#x}" = "" ]', {'FOO': 'x'}, True),
            ('[ "${FOO%y}" = "" ]', {'FOO': 'y'}, True),
            ('[ "${#FOO}" = 0 ]', {'FOO': ''}, True),
            ('[ "${#FOO}" = 5 ]', {'FOO': 'hello'}, True),
            ('[ "${FOO:+yes}" = "yes" ]', {'FOO': 'val'}, True),
            ('[ "${FOO:+yes}" = "" ]', {'FOO': ''}, True),
            ('[ "${FOO:-${BAR:-x}}" = "x" ]', {'FOO': '', 'BAR': ''}, True),
            ('[ "${FOO:-{a}}" = "{a}" ]', {'FOO': ''}, True),
            ('[ "${FOO:-$BAR}" = "hello" ]', {'FOO': '', 'BAR': 'hello'}, True),
            # B-54: Glob pattern matching for #, ##, %, %%
            ('[ "${FOO#*/}" = "b" ]', {'FOO': 'a/b'}, True),
            ('[ "${FOO##*/}" = "b" ]', {'FOO': 'a/b'}, True),
            ('[ "${FOO%/*}" = "a" ]', {'FOO': 'a/b'}, True),
            ('[ "${FOO%%/*}" = "a" ]', {'FOO': 'a/b'}, True),
            ('[ "${FOO#?}" = "bc" ]', {'FOO': 'abc'}, True),
            ('[ "${FOO#*b}" = "c" ]', {'FOO': 'abc'}, True),
            ('[ "${FOO%%.*}" = "x" ]', {'FOO': 'x.y.z'}, True),
            ('[ "${FOO%.*}" = "x.y" ]', {'FOO': 'x.y.z'}, True),
            ('[ "${FOO##*}" = "" ]', {'FOO': 'abc'}, True),
            ('[ "${FOO%%*}" = "" ]', {'FOO': 'abc'}, True),
            # B-55: Escaped closing brace \} inside double quotes vs inside ${...}
            ('[ "$X" = "a\\}" ]', {'X': 'a\\}'}, True),
            ('[ "${FOO}" = "a}b" ]', {'FOO': 'a}b'}, True),
        ]
        for cmd, env, expected in tests:
            inner = cmd[1:-1].strip()
            tokens = lists_core._split_shell_tokens(inner)
            l = lists_core._literal_operand(tokens[0], env)
            r = lists_core._literal_operand(tokens[2], env)
            self.assertEqual(l == r, expected, f"Failed on {cmd} (l={l}, r={r})")

    def test_46_mode_preservation_on_write_b52(self):
        # B-52: _rewrite_init_enabled and _write_enabled preserve custom file mode (e.g. 04750, 0700)
        import stat, unittest.mock as mock, utils
        if 'flask' not in sys.modules:
            sys.modules['flask'] = mock.MagicMock()
        import generator
        with tempfile.TemporaryDirectory() as td:
            init_f = os.path.join(td, "S99service")
            with open(init_f, "w") as f:
                f.write("#!/bin/sh\nENABLED=no\n")
            os.chmod(init_f, 0o4750)
            
            # 1. Test utils._rewrite_init_enabled
            self.assertTrue(utils._rewrite_init_enabled(init_f, True))
            st = os.stat(init_f)
            self.assertEqual(stat.S_IMODE(st.st_mode), 0o4750, "utils._rewrite_init_enabled must preserve 04750")

            # 2. Test generator._write_enabled
            generator.SERVICE_SCRIPTS['test_sn'] = init_f
            try:
                generator._write_enabled('test_sn', False)
                st = os.stat(init_f)
                self.assertEqual(stat.S_IMODE(st.st_mode), 0o4750, "generator._write_enabled must preserve 04750")
            finally:
                generator.SERVICE_SCRIPTS.pop('test_sn', None)

    def test_47_whitespace_rstrip_performance(self):
        # r172 / P3: verify O(N) performance and correctness of _rstrip_unescaped_ws
        import time
        self.assertEqual(lists_core._rstrip_unescaped_ws("foo    "), "foo")
        self.assertEqual(lists_core._rstrip_unescaped_ws("foo\\ "), "foo\\ ")
        self.assertEqual(lists_core._rstrip_unescaped_ws("foo\\\\ "), "foo\\\\")
        self.assertEqual(lists_core._rstrip_unescaped_ws("foo\\ \t"), "foo\\ ")
        self.assertEqual(lists_core._rstrip_unescaped_ws("foo\\\t"), "foo\\\t")
        self.assertEqual(lists_core._rstrip_unescaped_ws("foo\\  "), "foo\\ ")
        
        # Benchmark large whitespace
        huge_str = "ENABLED=yes; printf x" + (" " * 80000)
        t0 = time.time()
        res = lists_core._rstrip_unescaped_ws(huge_str)
        t1 = time.time()
        self.assertEqual(res, "ENABLED=yes; printf x")
        self.assertLess(t1 - t0, 0.2, "Whitespace stripping must complete in < 200ms")

    def test_48_escaped_glob_pattern_expansion(self):
        # r108bx / F-2 / r175: escaped glob patterns in prefix/suffix expansion
        self.assertTrue(lists_core.enabled_from_lines([
            "FOO='*yes'\n",
            "ENABLED=${FOO##\\*}\n"
        ]))
        self.assertTrue(lists_core.enabled_from_lines([
            "FOO='?yes'\n",
            "ENABLED=${FOO#\\?}\n"
        ]))
        self.assertTrue(lists_core.enabled_from_lines([
            "FOO='[x]yes'\n",
            "ENABLED=${FOO#\\[x\\]}\n"
        ]))
        self.assertFalse(lists_core.enabled_from_lines([
            "FOO='xyes'\n",
            "ENABLED=${FOO##\\*}\n"
        ]))

    def test_49_crlf_and_bom_reader_semantics(self):
        # r108bx / F-1: CRLF line endings and BOM positioning
        # CRLF must return False (rc.func sees "yes\r" != "yes")
        self.assertFalse(lists_core.enabled_from_lines([
            "ENABLED=yes\r\n"
        ]))
        # BOM before command breaks execution
        self.assertFalse(lists_core.enabled_from_lines([
            "\ufeffENABLED=yes\n"
        ]))
        # BOM before shebang is valid comment
        self.assertTrue(lists_core.enabled_from_lines([
            "\ufeff#!/bin/sh\n",
            "ENABLED=yes\n"
        ]))

    def test_50_crlf_writer_normalization(self):
        # r108bx / F-3: writer normalizes modified ENABLED line to LF
        rewritten, ok = lists_core._rewrite_enabled_pass(["ENABLED=yes\r\n"], False)
        self.assertTrue(ok)
        self.assertEqual(rewritten, ["ENABLED=no\n"])

        rewritten2, ok2 = lists_core._rewrite_enabled_pass([
            "#!/bin/sh\r\n",
            "ENABLED=yes\r\n",
            "echo 1\r\n"
        ], False)
        self.assertTrue(ok2)
        self.assertEqual(rewritten2, [
            "#!/bin/sh\r\n",
            "ENABLED=no\n",
            "echo 1\r\n"
        ])

    def test_51_early_exit_reader_semantics(self):
        # r108bx / F-1: early exit or return prior to assignment
        self.assertFalse(lists_core.enabled_from_lines([
            "exit 0\n",
            "ENABLED=yes\n"
        ]))
        self.assertFalse(lists_core.enabled_from_lines([
            "return 0\n",
            "ENABLED=yes\n"
        ]))

    def test_52_glob_posix_classes(self):
        # r108by / r176: POSIX character classes inside glob pattern
        self.assertEqual(lists_core._match_pattern("abc", "#", "[[:alpha:]]"), "bc")
        self.assertEqual(lists_core._match_pattern("123", "#", "[[:digit:]]"), "23")
        self.assertEqual(lists_core._match_pattern("a12", "#", "[[:alnum:]]"), "12")
        self.assertTrue(lists_core.enabled_from_lines([
            "FOO=a\n",
            "ENABLED=no\n",
            "BAR=${FOO#[[:alpha:]]}\n",
            "ENABLED=yes\n"
        ]))

    def test_53_glob_bad_range_safe_fallback(self):
        # r108by / r176 / r180: invalid character range [z-a] matches literals 'z','-','a' as in POSIX/BusyBox ash
        res = lists_core._match_pattern("z", "#", "[z-a]")
        self.assertEqual(res, "")

    def test_54_all_12_posix_classes_matrix(self):
        # r108bz / N-1: verify all 12 POSIX classes in lists_core glob expansion
        classes_data = {
            'alnum': ('a', '1', '-'),
            'alpha': ('a', 'Z', '0'),
            'blank': (' ', '\t', 'a'),
            'cntrl': ('\x01', '\x1f', 'a'),
            'digit': ('0', '9', 'a'),
            'graph': ('a', '!', ' '),
            'lower': ('a', 'z', 'A'),
            'print': ('a', ' ', '\x01'),
            'punct': ('!', '?', 'a'),
            'space': (' ', '\t', 'a'),
            'upper': ('A', 'Z', 'a'),
            'xdigit': ('a', 'F', 'g'),
        }
        for cls, (m1, m2, non_m) in classes_data.items():
            pat = f"[[:{cls}:]]"
            self.assertEqual(lists_core._match_pattern(f"{m1}rest", "#", pat), "rest", f"Failed {cls} with {m1}")
            self.assertEqual(lists_core._match_pattern(f"{m2}rest", "#", pat), "rest", f"Failed {cls} with {m2}")
            self.assertEqual(lists_core._match_pattern(f"{non_m}rest", "#", pat), f"{non_m}rest", f"Failed {cls} non-match with {non_m}")

    def test_55_quote_aware_command_splitting_in_init(self):
        # r108bz / r177: semicolons inside quotes must not create false ENABLED assignments
        self.assertFalse(lists_core.enabled_from_lines([
            "ENABLED=no\n",
            'X="foo; ENABLED=yes"\n'
        ]))
        self.assertFalse(lists_core.enabled_from_lines([
            "ENABLED=no\n",
            "X='foo; ENABLED=yes'\n"
        ]))

    def test_56_awk_unquoted_delimiters_and_or(self):
        # r108ca / R-1, R-2: || and && operators and unquoted word boundaries
        self.assertTrue(lists_core.enabled_from_lines([
            "ENABLED=yes || ENABLED=no\n"
        ]))
        self.assertTrue(lists_core.enabled_from_lines([
            "ENABLED=yes && X=1\n"
        ]))
        self.assertTrue(lists_core.enabled_from_lines([
            "ENABLED=yes # comment\r\n"
        ]))

    def test_57_multi_assignment_and_crlf_quoted_hash(self):
        # r108cb / r179 / C-1, P1, P2
        self.assertTrue(lists_core.enabled_from_lines([
            "ENABLED=no\n",
            "X=foo\\; ENABLED=yes\n"
        ]))
        self.assertFalse(lists_core.enabled_from_lines([
            "X='#'; ENABLED=yes\r\n"
        ]))
        self.assertTrue(lists_core.enabled_from_lines([
            "X='#'; ENABLED=yes # valid comment\r\n"
        ]))

    def test_58_keywords_and_quoted_marker_comment(self):
        # r108cc / r180 / P1, P3
        self.assertTrue(lists_core.enabled_from_lines([
            "if true; then ENABLED=yes; fi\n"
        ]))
        self.assertTrue(lists_core.enabled_from_lines([
            "for i in a; do ENABLED=yes; done\n"
        ]))
        self.assertFalse(lists_core.enabled_from_lines([
            "X='ENABLED= #'; ENABLED=yes\r\n"
        ]))
        self.assertTrue(lists_core.enabled_from_lines([
            "X='ENABLED= #'; ENABLED=yes # real comment\r\n"
        ]))

    def test_59_r181_glob_dash_and_conditions(self):
        # r181: [z-a] on '-' does not match; [a\-z] on 'b' matches
        self.assertEqual(lists_core._match_pattern("-", "#", "[z-a]"), "-")
        self.assertEqual(lists_core._match_pattern("z", "#", "[z-a]"), "")
        self.assertEqual(lists_core._match_pattern("b", "#", r"[a\-z]"), "")
        # Adversarial non-backtracking
        pat = "*a" * 15 + "c"
        val = "a" * 30 + "b"
        self.assertEqual(lists_core._match_pattern(val, "#", pat), val)


if __name__ == "__main__":
    unittest.main()
