#!/usr/bin/env python3
"""
Регрессионный набор reader_heredoc_regression.py (FB-228 / FB-229 / FB-230 / FB-231).
Проверяет паритет чтения и переписывания ENABLED= между lists_core и BusyBox ash
на сложных heredoc-конструкциях в шапке init-скрипта (включая quoted/unquoted, continuations,
пустые делимитеры, символы # в делимитере, command substitutions и строковые литералы).
"""

import glob
import os
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile
import unittest

# Динамическое определение корня проекта строго относительно этого файла
TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.normpath(os.path.join(TESTS_DIR, ".."))
BOT_DIR = os.path.join(PROJECT_ROOT, "opt", "etc", "bot")

# Если runtime не распакован (запуск из распакованного ZIP без дерева opt/),
# извлекаем opt/etc/bot из релизного tar.gz во временный каталог.
_EXTRACTED_TMP = None
if not os.path.isdir(BOT_DIR):
    tars = sorted(glob.glob(os.path.join(PROJECT_ROOT, "KeenZOO_full_*.tar.gz")))
    if tars:
        _EXTRACTED_TMP = tempfile.mkdtemp(prefix="kz_runtime_")
        with tarfile.open(tars[-1], "r:*") as tf:
            for member in tf.getmembers():
                if member.name.startswith("opt/etc/bot"):
                    tf.extract(member, _EXTRACTED_TMP)
        candidate = os.path.join(_EXTRACTED_TMP, "opt", "etc", "bot")
        if os.path.isdir(candidate):
            BOT_DIR = candidate

if os.path.isdir(BOT_DIR):
    if BOT_DIR in sys.path:
        sys.path.remove(BOT_DIR)
    sys.path.insert(0, BOT_DIR)

import lists_core


def ash_eval_enabled(script_content):
    """Выполняет скрипт через busybox ash и возвращает значение ENABLED (True/False)."""
    ash_bin = shutil.which("ash") or shutil.which("busybox")
    if not ash_bin:
        return None
    with tempfile.NamedTemporaryFile("w", suffix=".sh", delete=False) as f:
        f.write(script_content)
        f.write("\nprintf '\\n___KZ_END_RESULT:%s___\\n' \"$ENABLED\"\n")
        f_path = f.name
    try:
        if ash_bin.endswith("busybox"):
            cmd = [ash_bin, "ash", f_path]
        else:
            cmd = [ash_bin, f_path]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        if res.returncode != 0:
            raise AssertionError(f"BusyBox ash failed with rc={res.returncode}: {res.stderr}")
        m = re.findall(r'___KZ_END_RESULT:(\S+)___', res.stdout or "")
        if m:
            return (m[-1] == "yes")
        raise AssertionError(f"BusyBox ash output did not contain result marker: {res.stdout}")
    finally:
        try:
            os.remove(f_path)
        except OSError:
            pass


class TestReaderHeredocRegression(unittest.TestCase):
    @classmethod
    def tearDownClass(cls):
        global _EXTRACTED_TMP
        if _EXTRACTED_TMP and os.path.isdir(_EXTRACTED_TMP):
            try:
                shutil.rmtree(_EXTRACTED_TMP)
            except OSError:
                pass
            _EXTRACTED_TMP = None

    def _check_case(self, script_text, expected_val, name=""):
        lines = script_text.splitlines(True)
        py_val = lists_core.enabled_from_lines(lines)
        self.assertEqual(py_val, expected_val, f"lists_core mismatch for {name}: got {py_val}, expected {expected_val}")
        
        ash_val = ash_eval_enabled(script_text)
        if ash_val is None:
            raise unittest.SkipTest(f"BusyBox ash not found on host for {name}")
        self.assertEqual(ash_val, expected_val, f"ash mismatch for {name}: got {ash_val}, expected {expected_val}")

    def test_01_single_heredoc_then_no(self):
        s = """ENABLED=yes; : <<A
x
A
ENABLED=no
"""
        self._check_case(s, False, "01_single_heredoc_then_no")

    def test_02_single_heredoc_then_yes(self):
        s = """ENABLED=no; : <<EOF
some text
EOF
ENABLED=yes
"""
        self._check_case(s, True, "02_single_heredoc_then_yes")

    def test_03_tab_stripped_heredoc(self):
        s = """ENABLED=yes; cat <<- 'TAG'
\tline inside heredoc
\tTAG
ENABLED=no
"""
        self._check_case(s, False, "03_tab_stripped_heredoc")

    def test_04_two_heredocs_one_line(self):
        s = """ENABLED=yes; cat <<A <<B
line A
A
line B
B
ENABLED=no
"""
        self._check_case(s, False, "04_two_heredocs_one_line")

    def test_05_heredoc_in_assignment(self):
        s = """ENABLED=yes; X=cat <<EOF
sub line
EOF
ENABLED=no
"""
        self._check_case(s, False, "05_heredoc_in_assignment")

    def test_06_enabled_inside_heredoc_body_ignored(self):
        s = """ENABLED=no; : <<EOF
ENABLED=yes
EOF
"""
        self._check_case(s, False, "06_enabled_inside_heredoc_body_ignored")

    def test_07_heredoc_with_quoted_delimiter(self):
        s = """ENABLED=yes; : <<"END_OF_DOC"
ENABLED=yes
$VAR
END_OF_DOC
ENABLED=no
"""
        self._check_case(s, False, "07_heredoc_with_quoted_delimiter")

    def test_08_heredoc_with_spaces_in_body(self):
        s = """ENABLED=yes; : <<A
  leading spaces A
  A
A
ENABLED=no
"""
        self._check_case(s, False, "08_heredoc_with_spaces_in_body")

    def test_09_three_heredocs_multiline(self):
        s = """ENABLED=yes; cat <<A <<B <<C
bodyA
A
bodyB
B
bodyC
C
ENABLED=no
"""
        self._check_case(s, False, "09_three_heredocs_multiline")

    def test_10_heredoc_in_middle_assignment_kept(self):
        s = """ENABLED=yes
X=1
: <<EOF
comment
EOF
Y=2
"""
        self._check_case(s, True, "10_heredoc_in_middle_assignment_kept")

    def test_11_quoted_heredoc_backslash_continuation(self):
        # B-17: Quoted heredoc does not join backslash-newline; next line EOF is delimiter
        s = """ENABLED=yes; X=cat <<'EOF'
body\\
EOF
ENABLED=no
"""
        self._check_case(s, False, "11_quoted_heredoc_backslash_continuation")

    def test_12_unquoted_heredoc_backslash_continuation(self):
        # B-17: Unquoted heredoc joins backslash-newline; next line is body, second EOF is delimiter
        s = """ENABLED=no; cat <<EOF
foo\\
EOF
ENABLED=preserve
EOF
ENABLED=yes
"""
        self._check_case(s, True, "12_unquoted_heredoc_backslash_continuation")

    def test_13_empty_quoted_delimiter(self):
        # B-20: Empty quoted delimiter <<'' or <<"" terminated by blank line
        s = """ENABLED=no; cat <<''
ENABLED=preserve

ENABLED=yes
"""
        self._check_case(s, True, "13_empty_quoted_delimiter")

    def test_14_hash_in_delimiter(self):
        # B-20: Delimiter containing # (<<END#x) is treated as full delimiter name
        s = """ENABLED=no; cat <<END#x
END
ENABLED=preserve
END#x
ENABLED=yes
"""
        self._check_case(s, True, "14_hash_in_delimiter")

    def test_15_rewrite_preserves_unquoted_heredoc_body(self):
        # B-17: rewrite_enabled_lines must not delete lines from unquoted heredoc body
        orig = """ENABLED=no
cat <<EOF
foo\\
EOF
ENABLED=preserve
EOF
"""
        out, changed = lists_core._rewrite_enabled_pass(orig.splitlines(True), False)
        out_text = "".join(out)
        self.assertIn("ENABLED=preserve", out_text, "Heredoc body line ENABLED=preserve must not be deleted!")

    def test_16_rewrite_preserves_empty_delimiter_and_hash_delimiter(self):
        # B-20: rewrite_enabled_lines must preserve bodies of <<'' and <<END#x
        s1 = """ENABLED=no
cat <<''
ENABLED=preserve

"""
        out1, _ = lists_core._rewrite_enabled_pass(s1.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out1))

        s2 = """ENABLED=no
cat <<END#x
END
ENABLED=preserve
END#x
"""
        out2, _ = lists_core._rewrite_enabled_pass(s2.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out2))

    def test_17_heredoc_inside_command_substitution(self):
        # B-21: Heredoc inside "$(cat <<'EOF'...)" command substitution
        s = """ENABLED=no
X="$(cat <<'EOF'
ENABLED=preserve
EOF
)"
ENABLED=yes
"""
        self._check_case(s, True, "17_heredoc_inside_command_substitution")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out))

    def test_18_heredoc_inside_backticks(self):
        # B-21: Heredoc inside `cat <<'EOF'...` backticks
        s = """ENABLED=no
X=`cat <<'EOF'
ENABLED=preserve
EOF
`
ENABLED=yes
"""
        self._check_case(s, True, "18_heredoc_inside_backticks")
        out, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        self.assertIn("ENABLED=preserve", "".join(out))

    def test_19_continuation_preserves_trailing_commands(self):
        # r157 P1: ENABLED=\\nyes; PROCS=xray does not leave orphaned yes
        s = """ENABLED=\\
yes; PROCS=xray
"""
        out_false, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), False)
        out_text = "".join(out_false)
        self.assertIn("ENABLED=no; PROCS=xray", out_text)
        self.assertNotIn("\nyes;\n", out_text)
        self.assertFalse(lists_core.enabled_from_lines(out_false))

    def test_20_literal_string_in_command_preserved(self):
        # r157 P1: if true; then printf '%s\n' ' ENABLED=no'; fi does not corrupt quotes
        s = """#!/bin/sh
if true; then printf '%s\\n' ' ENABLED=no'; fi
"""
        out_true, _ = lists_core.rewrite_enabled_lines(s.splitlines(True), True)
        out_text = "".join(out_true)
        self.assertIn("if true; then printf '%s\\n' ' ENABLED=no'; fi", out_text)
        self.assertTrue(lists_core.enabled_from_lines(out_true))


if __name__ == "__main__":
    unittest.main()
