#!/usr/bin/env python3
"""
Регрессионный набор reader_heredoc_regression.py (FB-228 / B-15).
Проверяет паритет чтения ENABLED= между lists_core.enabled_from_lines и BusyBox ash
на сложных heredoc-конструкциях в шапке init-скрипта.
"""

import os
import sys
import shutil
import subprocess
import tempfile
import unittest

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BOT_DIR = os.path.join(BASE_DIR, "opt", "etc", "bot")
if BOT_DIR not in sys.path:
    sys.path.insert(0, BOT_DIR)

import lists_core


def ash_eval_enabled(script_content):
    """Выполняет скрипт через busybox ash и возвращает значение ENABLED."""
    ash_bin = shutil.which("ash") or shutil.which("busybox")
    if not ash_bin:
        return None
    with tempfile.NamedTemporaryFile("w", suffix=".sh", delete=False) as f:
        f.write(script_content)
        f.write("\nprintf '%s' \"$ENABLED\"\n")
        f_path = f.name
    try:
        if ash_bin.endswith("busybox"):
            cmd = [ash_bin, "ash", f_path]
        else:
            cmd = [ash_bin, f_path]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        out = (res.stdout or "").strip()
        return (out == "yes")
    except Exception:
        return None
    finally:
        try:
            os.remove(f_path)
        except OSError:
            pass


class TestReaderHeredocRegression(unittest.TestCase):
    def _check_case(self, script_text, expected_val, name=""):
        lines = script_text.splitlines(True)
        py_val = lists_core.enabled_from_lines(lines)
        self.assertEqual(py_val, expected_val, f"lists_core mismatch for {name}: got {py_val}, expected {expected_val}")
        
        ash_val = ash_eval_enabled(script_text)
        if ash_val is not None:
            self.assertEqual(ash_val, expected_val, f"ash mismatch for {name}: got {ash_val}, expected {expected_val}")

    def test_01_single_heredoc_then_no(self):
        s = """ENABLED=yes; : <<A
x
A
ENABLED=no
"""
        self._check_case(s, False, "01_single_heredoc_then_no")

    def test_02_single_heredoc_then_yes(self):
        s = """ENABLED=no; : <<EOF
some text
EOF
ENABLED=yes
"""
        self._check_case(s, True, "02_single_heredoc_then_yes")

    def test_03_tab_stripped_heredoc(self):
        s = """ENABLED=yes; cat <<- 'TAG'
\tline inside heredoc
\tTAG
ENABLED=no
"""
        self._check_case(s, False, "03_tab_stripped_heredoc")

    def test_04_two_heredocs_one_line(self):
        s = """ENABLED=yes; cat <<A <<B
line A
A
line B
B
ENABLED=no
"""
        self._check_case(s, False, "04_two_heredocs_one_line")

    def test_05_heredoc_in_assignment(self):
        s = """ENABLED=yes; X=cat <<EOF
sub line
EOF
ENABLED=no
"""
        self._check_case(s, False, "05_heredoc_in_assignment")

    def test_06_enabled_inside_heredoc_body_ignored(self):
        s = """ENABLED=no; : <<EOF
ENABLED=yes
EOF
"""
        self._check_case(s, False, "06_enabled_inside_heredoc_body_ignored")

    def test_07_heredoc_with_quoted_delimiter(self):
        s = """ENABLED=yes; : <<"END_OF_DOC"
ENABLED=yes
$VAR
END_OF_DOC
ENABLED=no
"""
        self._check_case(s, False, "07_heredoc_with_quoted_delimiter")

    def test_08_heredoc_with_spaces_in_body(self):
        s = """ENABLED=yes; : <<A
  leading spaces A
  A
A
ENABLED=no
"""
        self._check_case(s, False, "08_heredoc_with_spaces_in_body")

    def test_09_three_heredocs_multiline(self):
        s = """ENABLED=yes; cat <<A <<B <<C
bodyA
A
bodyB
B
bodyC
C
ENABLED=no
"""
        self._check_case(s, False, "09_three_heredocs_multiline")

    def test_10_heredoc_in_middle_assignment_kept(self):
        s = """ENABLED=yes
X=1
: <<EOF
comment
EOF
Y=2
"""
        self._check_case(s, True, "10_heredoc_in_middle_assignment_kept")


if __name__ == "__main__":
    unittest.main()
