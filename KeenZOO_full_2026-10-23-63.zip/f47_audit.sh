#!/bin/bash
# f47_audit.sh v21 — приёмочный стенд правок аудитов 18/19/20/22/23/24/25/26/27/28/29/30/31/32/33/34/35/36/37 (r45→…→r62→кандидат r63):
#  W. Аудит-34 (перестройка деплоя по распоряжению): авто-бутстрап HTTPS
#     (FB-78) — 4 пакета с текущего фида, фолбэк на зеркала (bin → bfsu
#     → cqupt → nju → diversion, https + http-вариант), флип entware|
#     keendev на https с контрольным opkg update и байт-точным откатом;
#     вопрос согласия упразднён (pty и не-tty выполняются полностью);
#     DNS Override (FB-79) — явное согласие y/N со стартом S56dnsmasq и
#     проверкой живости; перезагрузка — отдельный запрос последним
#     шагом; FB-80 — тихий режим (загрузчик/WebTunnel/crond/ipset/
#     сервисы молчат, предупреждения остаются); FB-81 — пробы фидов
#     печатаются только при ошибке; Q4: 14 установок deploy (2 —
#     авто-бутстрап без гейта, прямое распоряжение); V1/P5/N5 —
#     формулировки факта
#  Y. Аудит-33 (внешние отчёты по r58): атомарный compare-and-write
#     списков (rev = SHA-256 содержимого, проверка+запись под общим
#     guard, strict no-rev), resolv.conf только при DNS_OVERRIDE_OK=1
#     (проба 127.0.0.1 до записи, бэкап+откат), консент бутстрапа не
#     переносится на остаточные сторонние HTTP-фиды, per-source статусы
#     check_updates (частичный провал = check_failed, na для BE-MIPS),
#     паритет example.com до конца (порт/регистр/конечная точка/
#     нестроковый server; sni-исключение), procfs-fallback
#     _kz_dns_live, явный KEENZOO_DLTMP (абсолютный/mkdir/writable),
#     INSTALL: menu-SHA/подписи редакции сверяются с фактом
#  R. Аудит-26 (внешние отчёты по r51): S57-гейт заглушки с портом
#     (K51-1), PID-личность при останове (K51-3), HTTP-гейт — обе
#     копии, 6 форм opkg.conf + fail-closed на нечитаемом (R51-02),
#     мемоизация opkg list-installed (K51-2), порог Range (R51-07),
#     SKIPPED_HTTP со всех точек (R51-05), SNI-исключение needs_key
#     (R51-06), CFG_STATE web_username + баннер (R50-UX-1), LAN-lock
#     (N51-2), _auth_cmp (FB-33), cross-list warning (N51-1),
#     benchmark-диапазон (R50-FW-1), wget-warn (FB-34), маркеры
#  X. Аудит-32 (внешний отчёт по r55): полный lock writers списков
#     (flock панель+бот, revision редактора против stale-вкладки),
#     401 без sleep для отсутствующих кредов, mkstemp+lock
#     router-proto, паритет валидаторов hysteria 15/15 (тип auth,
#     server=CHANGE_ME), уборка сиротливых tmp, warnings в /api/cfg,
#     check_failed потребителю бота
#  W. Аудит-31: одноразовый https-бутстрап фида (4 пакета по HTTP
#     под единым согласием → флип entware|keendev в opkg.conf с копией
#     → контрольный opkg update; провал = откат байт-в-байт) и DNS
#     Override только при живом dnsmasq (мёртвый = пропуск + подсказка
#     + вопрос; заклинивший override предлагается отключить; 127.0.0.1
#     в resolv.conf только при живом dnsmasq)
#  V. Аудит-30 (разбор живой установки r55): tty-согласие на
#     установки из штатного HTTP-фида (вопрос один раз за прогон,
#     не-tty — прежний fail-closed); честная укомплектованность
#     вместо статического «Пакеты уже стоят»; дедуп сводки пропусков;
#     вердикты сервисов по бинарнику (ss-redir/trojan как xray) и
#     ps-матчер без самосопоставления grep ([p]-трюк)
#  U. Аудит-29 (внешний отчёт по r54): гонка записи списков (общий
#     pid-tmp + несериализованный read-modify-write: 20 параллельных
#     POST давали 13×500 и 1 запись из 20) — mkstemp + _LISTS_WRITE_LOCK;
#     _write_enabled — тот же pid-tmp; счётчик неудачных входов считает
#     только предъявленные неверные креды (без Authorization — 401 без
#     счётчика); паритет 4 валидаторов на «auth отсутствует» (needs_key
#     с флагом hysteria, placeholders с require_auth)
#  T. Аудит-28 (внешний отчёт по r53): регресс JS addToList (лишняя })
#     ловится рендером + node --check; HTTP-гейт — 11 форм opkg.conf ×
#     обе копии (кавычки вокруг типа, dist/dist/gz, каталог); порядок
#     «модули → проба» и вердикт пробы в решении deploy (|0 не «✅»);
#     паритет 4 валидаторов hysteria; lookup-add: 1 чтение + лимит;
#     check_updates «проверка не удалась»; PID-личность по /proc/exe;
#     баннер «панель не настроена»; _kz_pkg_installed литерально; Range
#     по коду 206; маркеры FB-43..FB-51
#  S. Аудит-27 (внешний отчёт по r52): проба iptables вставкой правила
#     (K52-7), минифицированный JSON в детекторах заглушек (K52-1),
#     честный вердикт dnsmasq при отсутствии (K52-4), JS warning (K52-3),
#     снимок списков cross-check (K52-6), opkg list-installed ×1 (K52-5),
#     tty-вывод check_updates (N52-8), маркеры FB-35..41
#  Q. Аудит-25 (внешние отчёты по r50): декоратор before_request на
#     security_checks (P0), семантика _auth_fails (K50-2/A9-5), гейт
#     заглушки hysteria в S57 (K50-3), покрытие HTTP-гейта всеми
#     opkg install/upgrade (A9-2), Origin my.keenetic.net/loopback
#     (K50-4/A9-4), канонический путь hysteria (K50-5), форма src
#     фида (A9-3), честность заметки Range (A9-6), учёт гейт-пропусков
#     в сводке (A9-7), фильтр токена-заглушки (K50-7), shlex (K50-8),
#     кэш LAN-адресов (K50-9)
#  P. Аудит-24 (повторный сбой установки, rc=3): HTTP-политика перенесена
#     в точку риска — гейт перед сетевой opkg install (установленное
#     пропускается без сети; отсутствующее при http-фиде без ALLOW —
#     warn+пропуск); rc=3 → warn+продолжение; одиночный OFFLINE-флаг
#     самодостаточен; http-проба с ensure_dns и повтором (FB-8)
#  N. Аудит-23 (сбой установки на устройстве): проверка фидов Entware —
#     https без curl = «не проверено» (не бракуется), Range-проба 256Б,
#     недоступность фидов не убивает установку (авторитет — opkg update;
#     политический rc=3 для http-фида — с явным обходом ALLOW-флагом)
#  M. Аудит-22: O-1 (Origin: SSH-туннель 127.0.0.1:любой-порт при
#     loopback-клиенте, альтернативные LAN-IP, allowed_origin_hosts;
#     request.host не возвращён), TS-1 (tmp-статус не переживает
#     прогон: trap в body, очистка при отказе Popen), AF-1 (жёсткий
#     кап _auth_fails 256), SN-1 (нормализация fallback-подсетей,
#     логирование отказов ACCEPT) — поведенчески, экстракцией helpers
#  L. Аудит-21: FW-1b (зачистка legacy-blanket в setup_firewall,
#     без fallback на ALLOWED_SUBNETS), PF-1 (preflight панели —
#     только flask+markupsafe; текст deploy раздельный), RM-1
#     (uninstall_netfilter предупреждает об остатке чужих ACCEPT
#     на :8080 — поведенчески, на моках секции A)
#  K. Аудит-20: FW-1 (нет blanket-RFC1918 в setup_firewall, подсети
#     LAN как в блоке B7 хука), TW-1 (нет root-обёрток-файлов в /tmp:
#     sh -c + O_NOFOLLOW + mkstemp; фолбэк-статус обёртки), RL-1
#     (ротация: триггер по размеру, KEEP — цель), TG-1 (общая
#     tg_send_message: urlencode + токен вне cmdline), CS-1
#     (Origin: hostname-whitelist, чистка _auth_fails), BC-1 (ранний
#     chmod 0600 bot_config.py после apply)
#  A. R47-1+R48-2: uninstall_netfilter на моках iptables/ip/ipset —
#     проектные правила сняты (negated-DROP с -i и исключениями, DNS
#     RETURN udp/53, ACCEPT 8080 по фактическим подсетям), ЧУЖИЕ правила
#     на 8080 (голый ACCEPT / udp / публичный -s) целы, прочие чужие целы,
#     регрессия прежних форм снятия, идемпотентность
#  B. N-5+R48-3: start() из S99generator ЦЕЛИКОМ (не «до первого fi»):
#     preflight до is_running-выхода; при ненастроенном конфиге и живом
#     процессе — останов; already-running при настроенном; сломанный
#     python-конфиг не отсекается (grep не исполняет код)
#  C. R45-4+R48-1: советы про секреты — реальное поле token, исключение
#     заглушки ТОКЕН_БОТА, раздельные советы (токен / пароль панели)
#  D. R48-6: сводка deploy считает ACCEPT 8080 двухступенчатым grep'ом
#     (форма хука с -s между --dport и -j видна)
#  E. R48-8: сводка различает «панель не настроена» и «не запустилась»
#  F. R48-9: test_udp_tunnels — процесс не запущен => warn, а не FAIL
#  G. R48-5: просмотр списка в боте ≡ рендеру сохранения (R46-2)
#  H. R48-7: wsSettings.host вместо headers.Host (шаблон + конвертер)
#  J. аудит-19: R49-1 (без двойного запуска unblock_update в deploy,
#     boot-путь S99unblock цел), R49-2 (версия hysteria из баннера)
#  I. маркеры правок, синтаксис, отсутствие bot_token, JSON шаблона,
#     хук 100-redirect.sh не тронут; A6-4: pidof-фолбэк через /proc
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f47chk
rm -rf "$F"; mkdir -p "$F/bin"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. R47-1+R48-2: uninstall_netfilter на моках ═══"

# мок iptables: состояние в файле, формат table|chain|-A chain spec
cat > "$F/bin/iptables" <<'EOF'
#!/bin/bash
R=${IPT_MOCK_STATE:?}
T=filter
args=("$@")
i=0
while [ $i -lt ${#args[@]} ]; do
    case "${args[$i]}" in
        -t) T=${args[$((i+1))]}; i=$((i+2)); continue ;;
        -w) i=$((i+1)); continue ;;
    esac
    break
done
act=${args[$i]}
chain=${args[$((i+1))]}
spec=""
j=$((i+2))
while [ $j -lt ${#args[@]} ]; do
    spec="$spec ${args[$j]}"
    j=$((j+1))
done
spec=${spec# }
case "$act" in
    -S)
        awk -F'|' -v t="$T" -v c="$chain" \
            '$1==t && $2==c {sub(/^[^|]*\|[^|]*\|-A [^ ]* /,""); print "-A " c " " $0}' "$R"
        ;;
    -D)
        key="${T}|${chain}|-A ${chain} ${spec}"
        if grep -qxF "$key" "$R"; then
            grep -vx "$key" "$R" > "$R.tmp" && mv "$R.tmp" "$R"
            exit 0
        fi
        exit 1
        ;;
    -C)
        grep -qxF "${T}|${chain}|-A ${chain} ${spec}" "$R" && exit 0
        exit 1
        ;;
esac
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ip6tables"
cat > "$F/bin/ip" <<'EOF'
#!/bin/sh
[ "$1" = "link" ] && [ "$2" = "show" ] && {
    case "$3" in br0|nwg0) exit 0 ;; *) exit 1 ;; esac
}
if [ "$1" = "-4" ] && [ "$2" = "addr" ]; then
    if [ "$4" = "br0" ]; then
        printf '2: br0: <BROADCAST,MULTICAST,UP> mtu 1500\n    inet 192.168.1.1/24 brd 192.168.1.255 scope global br0\n'
    fi
    exit 0
fi
[ "$1" = "rule" ] && exit 1
[ "$1" = "route" ] && exit 0
exit 0
EOF
cat > "$F/bin/ipset" <<'EOF'
#!/bin/sh
if [ "$1" = "list" ] && [ "$2" = "-n" ]; then
    printf 'unblockdns\nunblockhysteria\nunblockrouter\nunblocksh\nunblocktor\nunblocktroj\nunblockvless\n'
fi
exit 0
EOF
# моки для секции E: netstat управляется маркером, ss всегда молчит
cat > "$F/bin/netstat" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/net8080 ] || exit 1
printf 'tcp 0 0 0.0.0.0:8080 0.0.0.0:* LISTEN\n'
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ss"
# мок pidof для секции F: маркер pidup => rc 0
cat > "$F/bin/pidof" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/pidup ] && exit 0
exit 1
EOF
chmod +x "$F/bin/"*

# фикстура правил: проектные (все формы) + чужие (должны уцелеть),
# в т.ч. ТРИ чужих на 8080 (R48-2)
cat > "$F/rules.txt" <<'EOF'
nat|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -j REDIRECT --to-port 9141
nat|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockvless dst -j REDIRECT --to-port 10810
nat|PREROUTING|-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1
nat|PREROUTING|-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP
mangle|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp --dport 53 -j RETURN
mangle|PREROUTING|-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblockrouter dst -j MARK --set-mark 0xd1001/0xd1001
mangle|PREROUTING|-A PREROUTING -m conntrack --ctstate NEW -m set --match-set unblocktor dst -j CONNMARK --set-mark 0xd1001
mangle|PREROUTING|-A PREROUTING -j CONNMARK --restore-mark
mangle|PREROUTING|-A PREROUTING -p tcp --dport 5000 -j DROP
filter|INPUT|-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 192.168.0.0/16 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p udp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j DROP
filter|INPUT|-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT
filter|INPUT|-A INPUT -i br0 -p tcp --dport 9141 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 22 -j ACCEPT
nat|OUTPUT|-A OUTPUT -o lo -j RETURN
nat|OUTPUT|-A OUTPUT -d 192.168.0.0/16 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x2000000 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x9999999 -j RETURN
EOF
cp "$F/rules.txt" "$F/state.txt"

awk '/^uninstall_netfilter\(\) \{/,/^\}/' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/un.s"
UN_LINES=$(wc -l < "$F/un.s")
[ "$UN_LINES" -gt 150 ] \
    && ok "A0: экстракт uninstall_netfilter (${UN_LINES} строк)" \
    || bad "A0: экстракт подозрительно мал (${UN_LINES} строк)"

cat > "$F/runA.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runA.sh"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA.log" 2>&1
rcA=$?
LEFT=$(cat "$F/state.txt")
chk_gone(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 1 || return 0; }
chk_here(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 0 || return 1; }

[ "$rcA" = 0 ] && [ "$(grep -c '^RC=0$' "$F/runA.log")" = 1 ] \
    && ok "A1: uninstall_netfilter отработала rc=0" \
    || bad "A1: rc=$rcA ($(tail -2 "$F/runA.log"))"
chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP' \
    && chk_gone '-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP' \
    && ok "A2: negated-DROP UDP-guard снят (обе формы)" \
    || bad "A2: guard-DROP остался: $(printf '%s\n' "$LEFT" | grep 'unblocktor dst\|unblocktroj dst' | grep DROP)"
chk_gone '-A PREROUTING -p udp --dport 53 -j RETURN' \
    && ok "A3: DNS RETURN (mangle, udp/53) снят" \
    || bad "A3: DNS RETURN остался"
NACC=$(printf '%s\n' "$LEFT" | grep -c -- '--dport 8080 -j ACCEPT' || true)
[ "$NACC" = 3 ] \
    && ok "A4: проектные ACCEPT 8080 (5 приватных -s, включая 169.254) сняты, осталось ровно 3 чужих" \
    || bad "A4: осталось ACCEPT 8080: $NACC (ожидалось 3 чужих)"
chk_gone '-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4c: link-local ACCEPT (169.254.10.0/24) снят (A6-1)" \
    || bad "A4c: link-local ACCEPT пережил удаление"
chk_here '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -p udp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4b: чужие 8080 целы: голый tcp / udp / публичный -s (R48-2)" \
    || bad "A4b: чужое 8080-правило удалено: $(printf '%s\n' "$LEFT" | grep -- '--dport 8080')"
chk_gone '-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP' \
    && chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -j CONNMARK --restore-mark' \
    && chk_gone '-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1' \
    && chk_gone '-A OUTPUT -m mark --mark 0x2000000 -j RETURN' \
    && chk_gone '-A INPUT -p tcp --dport 8080 -j DROP' \
    && chk_gone '-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT' \
    && ok "A5: регрессия прежних форм: REDIRECT/TPROXY/простой DROP/CONNMARK/socket/DNAT/OUTPUT/8080-DROP сняты" \
    || bad "A5: что-то из прежних форм осталось"
chk_here '-A PREROUTING -p tcp --dport 5000 -j DROP' \
    && chk_here '-A INPUT -p tcp --dport 22 -j ACCEPT' \
    && chk_here '-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4' \
    && chk_here '-A OUTPUT -m mark --mark 0x9999999 -j RETURN' \
    && ok "A6: прочие чужие правила целы (DROP 5000 / ACCEPT 22 / DNAT 9999 / RETURN 0x9999999)" \
    || bad "A6: чужое правило удалено"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA2.log" 2>&1
rcA2=$?
LEFT2=$(cat "$F/state.txt")
if [ "$rcA2" = 0 ] && [ "$LEFT2" = "$LEFT" ]; then
    ok "A7: идемпотентность — повторный прогон rc=0, состояние не изменилось"
else
    bad "A7: rc=$rcA2, дельта: $(diff <(printf '%s\n' "$LEFT") <(printf '%s\n' "$LEFT2") | head -5)"
fi

echo "═══ B. N-5+R48-3: start() целиком (S99generator) ═══"
awk '/^start\(\) \{/,/^\}/' "$K/opt/etc/init.d/S99generator" > "$F/start.fn"
grep -q 'R48-3 (аудит-18)' "$F/start.fn" && grep -q 'SKIPPED' "$F/start.fn" \
    && ok "B0: экстракт start() ($(wc -l < "$F/start.fn") строк), preflight внутри" \
    || bad "B0: экстракт неполон"
runB(){
    CFG="$1"; ISRUN="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/start.fn" > "$F/start.case"
    {
        echo 'NAME=generator'
        echo "PIDFILE=$F/pid"
        echo "LOGFILE=$F/gen.log"
        echo "WORKDIR=$F/wd"
        echo "APP=$F/app"
        echo "is_running(){ [ -f '$F/isrun' ]; }"
        echo "kill_app(){ echo kill >> '$F/kills'; }"
        echo 'find_python(){ printf "/bin/echo\n"; }'
        echo ". '$F/start.case'"
        echo 'start'
        echo 'echo "RC=$?"'
    } > "$F/runB.sh"
    rm -f "$F/kills" "$F/pid" "$F/isrun" "$F/gen.log"
    [ "$ISRUN" = 1 ] && { : > "$F/isrun"; echo 12345 > "$F/pid"; }
    mkdir -p "$F/wd"; : > "$F/app"
    ( bash "$F/runB.sh" ) 2>/dev/null
}
mkdir -p "$F/cfg"
printf "web_username = 'admin'\nweb_password = ''\n" > "$F/cfg/empty_pass.py"
printf "web_username = ''\nweb_password = 'x'\n" > "$F/cfg/empty_user.py"
printf "web_username = 'admin'\nweb_password = 'secret'\n" > "$F/cfg/ok.py"
printf "web_username = 'admin'\nweb_password = 'x'\nэтот файл не python !!!\n" > "$F/cfg/broken.py"
O1=$(runB "$F/cfg/empty_pass.py" 0)
printf '%s' "$O1" | grep -q 'SKIPPED' && [ -z "$(printf '%s' "$O1" | grep 'Stopping')" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B1: пустой пароль, процесса нет → SKIPPED, никто не тронут" \
    || bad "B1: $O1 kills=$(cat "$F/kills" 2>/dev/null)"
O2=$(runB "$F/cfg/empty_pass.py" 1)
printf '%s' "$O2" | grep -q 'Stopping' && printf '%s' "$O2" | grep -q 'SKIPPED' \
    && [ -f "$F/kills" ] && [ ! -f "$F/pid" ] \
    && ok "B2: пустой пароль, панель жива → останов (kill_app, pidfile снят) + SKIPPED (R48-3)" \
    || bad "B2: $O2 kills=$(cat "$F/kills" 2>/dev/null) pid=$(cat "$F/pid" 2>/dev/null)"
O3=$(runB "$F/cfg/ok.py" 1)
printf '%s' "$O3" | grep -q 'already running' && [ -z "$(printf '%s' "$O3" | grep SKIPPED)" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B3: настроено, панель жива → already running, без SKIPPED/kill" \
    || bad "B3: $O3"
O4=$(runB "$F/cfg/ok.py" 0)
[ -z "$(printf '%s' "$O4" | grep SKIPPED)" ] && printf '%s' "$O4" | grep -q 'Starting' \
    && ok "B4: настроено, процесса нет → preflight пройден, старт (Starting…)" \
    || bad "B4: $O4"
O5=$(runB "$F/cfg/broken.py" 0)
[ -z "$(printf '%s' "$O5" | grep SKIPPED)" ] && printf '%s' "$O5" | grep -q 'Starting' \
    && ok "B5: сломанный python-конфиг НЕ отсекается (grep не исполняет код)" \
    || bad "B5: $O5"
L1=$(grep -n 'web_username' "$F/start.fn" | head -1 | cut -d: -f1)
L2=$(grep -n 'if is_running; then' "$F/start.fn" | head -1 | cut -d: -f1)
[ -n "$L1" ] && [ -n "$L2" ] && [ "$L1" -lt "$L2" ] \
    && ok "B6: preflight стоит ДО is_running-выхода (строки $L1 < $L2)" \
    || bad "B6: порядок нарушен ($L1 vs $L2)"

echo "═══ C. R45-4+R48-1: советы про секреты ═══"
awk '/# R45-4 \(аудит-17\)/{f=1} f{print} f && /^fi$/{n++; if (n==2) exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/sec.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/sec.body" | grep -c '__CFG__')
[ "$SUBS" = 3 ] \
    && ok "C0: экстракт блока секретов, 3 grep-условия ведут на bot_config.py" \
    || bad "C0: замен путей = $SUBS (ожидалось 3)"
runC(){
    CFG="$1"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/sec.body" > "$F/sec.run"
    ( . "$F/sec.run" )
}
printf "token = '123456:REAL-KEY'\nweb_password = ''\n" > "$F/cfg/tok.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = 'p'\n" > "$F/cfg/ph.py"
printf "token = '123456:REAL-KEY'\nweb_password = 'p'\n" > "$F/cfg/both.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = ''\n" > "$F/cfg/none.py"
printf "token='ТОКЕН_БОТА'\n" > "$F/cfg/ph2.py"
C1=$(runC "$F/cfg/tok.py")
printf '%s' "$C1" | grep -q 'перевыпустите токен' && [ -z "$(printf '%s' "$C1" | grep 'смените пароль')" ] \
    && ok "C1: токен заполнен, пароль пуст → совет про токен, без совета про пароль" \
    || bad "C1: $C1"
C2=$(runC "$F/cfg/ph.py")
printf '%s' "$C2" | grep -q 'смените пароль' && [ -z "$(printf '%s' "$C2" | grep 'перевыпустите токен')" ] \
    && ok "C2: заглушка токена, пароль заполнен → совет про пароль, без токена" \
    || bad "C2: $C2"
C3=$(runC "$F/cfg/both.py")
printf '%s' "$C3" | grep -q 'перевыпустите токен' && printf '%s' "$C3" | grep -q 'смените пароль' \
    && ok "C3: оба заполнены → оба совета" \
    || bad "C3: $C3"
C4=$(runC "$F/cfg/none.py"); C5=$(runC "$F/cfg/missing.py"); C6=$(runC "$F/cfg/ph2.py")
[ -z "$C4" ] && [ -z "$C5" ] && [ -z "$C6" ] \
    && ok "C4: заглушка+пустой пароль / нет файла / заглушка без пробелов → тишина" \
    || bad "C4: напечатано: C4=[$C4] C5=[$C5] C6=[$C6]"
NB=$(grep 'bot_token' "$K/opt/bin/deploy_bypass.sh" | grep -vc '^[[:space:]]*#' || true)
[ "${NB:-0}" = 0 ] \
    && ok "C5: несуществующего поля bot_token больше нет вне комментариев" \
    || bad "C5: bot_token вне комментариев: $NB"

echo "═══ D. R48-6: подсчёт ACCEPT 8080 в сводке ═══"
awk '/# R48-6 \(аудит-18\)/{f=1} f{ if ($0 ~ /^if \[/) exit; print }' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.block"
grep -c 'WEB_ACC=' "$F/webacc.block" | grep -q '^2$' \
    && ok "D0: экстракт присваивания WEB_ACC (обе строки)" \
    || bad "D0: экстракт неполон"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
{ echo 'IPT_BIN=/tmp/f47chk/bin/ipt_web'; cat "$F/webacc.block"; echo 'echo "WEB_ACC=$WEB_ACC"'; } > "$F/runD.sh"
D1=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=' )
[ "$D1" = "WEB_ACC=4" ] \
    && ok "D1: форма хука с -s считается (4 ACCEPT из 5 правил; старая склейка дала бы 1)" \
    || bad "D1: $D1"
printf '#!/bin/sh\nexit 0\n' > "$F/bin/ipt_web"
D2=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=')
[ "$D2" = "WEB_ACC=0" ] \
    && ok "D2: пустой вывод → WEB_ACC=0 (без unbound variable/ошибок)" \
    || bad "D2: $D2"

# A6-2: счётчик остаётся фактом, но вердикт «Доступ из LAN» не выдаётся
awk '/# R48-6 \(аудит-18\)/{f=1} f{print} f && /^fi$/{exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.full"
runD3(){
    MOCK="$1"
    {
        echo "IPT_BIN=$MOCK"
        echo 'warn(){ echo "WARN: $*"; }'
        cat "$F/webacc.full"
    } > "$F/runD3.sh"
    bash "$F/runD3.sh" 2>/dev/null
}
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
D3=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D3" | grep -q 'Найдены ACCEPT-правила на :8080 (2)' \
    && [ -z "$(printf '%s' "$D3" | grep 'Доступ из LAN')" ] \
    && ok "D3: WEB_ACC>0 → ℹ️ «Найдены ACCEPT-правила…», без вердикта «Доступ из LAN» (A6-2)" \
    || bad "D3: $D3"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT'
exit 0
EOF
D4=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D4" | grep -q 'Найдены ACCEPT-правила на :8080 (1)' \
    && [ -z "$(printf '%s' "$D4" | grep 'Доступ из LAN')" ] \
    && ok "D4: только loopback-ACCEPT → ℹ️ (не «доступ из LAN разрешён»)" \
    || bad "D4: $D4"

echo "═══ E. R48-8: сводка про порт 8080 ═══"
awk '/# Панель обязана СЛУШАТЬ/,/^fi$/' "$K/opt/bin/deploy_bypass.sh" > "$F/lstn.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/lstn.body" | grep -c '__CFG__')
[ "$SUBS" = 2 ] \
    && ok "E0: экстракт блока слушателя, оба условия (A6-3) ведут на bot_config.py" \
    || bad "E0: замен путей = $SUBS (ожидалось 2)"
runE(){
    CFG="$1"; NET="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/lstn.body" > "$F/lstn.run"
    rm -f "$F/net8080"
    [ "$NET" = 1 ] && : > "$F/net8080"
    (
        PATH="$F/bin:/usr/bin:/bin"
        warn(){ echo "WARN: $*"; }
        . "$F/lstn.run"
    )
}
E1=$(runE "$F/cfg/ok.py" 1)
printf '%s' "$E1" | grep -q '8080 слушается' \
    && ok "E1: порт слушается → ✅ (пароль не важен)" \
    || bad "E1: $E1"
E2=$(runE "$F/cfg/ok.py" 0)
printf '%s' "$E2" | grep -q 'НЕ слушается' && [ -z "$(printf '%s' "$E2" | grep 'не настроена')" ] \
    && ok "E2: пароль задан, порт молчит → предупреждение с логом" \
    || bad "E2: $E2"
E3=$(runE "$F/cfg/empty_pass.py" 0)
printf '%s' "$E3" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E3" | grep 'НЕ слушается')" ] \
    && ok "E3: пароль пуст, порт молчит → ℹ️ «не настроена», без поиска ошибки в логе (R48-8)" \
    || bad "E3: $E3"
E4=$(runE "$F/cfg/missing.py" 0)
printf '%s' "$E4" | grep -q 'не настроена' \
    && ok "E4: конфига нет → ℹ️ «не настроена»" \
    || bad "E4: $E4"
E5=$(runE "$F/cfg/empty_user.py" 0)
printf '%s' "$E5" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E5" | grep 'НЕ слушается')" ] \
    && ok "E5: пустой web_username + пароль → «не настроена», не «НЕ слушается» (A6-3)" \
    || bad "E5: $E5"

echo "═══ F. R48-9: градация test_udp_tunnels ═══"
awk '/# R48-9 \(аудит-18\)/{f=1} f{print} f && /^    fi$/{n++; if (n==4) exit}' \
    "$K/opt/bin/test_udp_tunnels.sh" > "$F/udp.block"
grep -q '_proc_up' "$F/udp.block" && grep -q 'A6-4 (аудит-19)' "$F/udp.block" \
    && [ "$(grep -c 'не проверяем' "$F/udp.block")" = 2 ] \
    && ok "F0: экстракт сокетных проверок с градацией и /proc-фолбэком" \
    || bad "F0: экстракт неполон"
runF(){
    LU="$1"; LT="$2"; PUP="$3"
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    [ "$PUP" = 1 ] && : > "$F/pidup"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"$LU\"; _lt=\"$LT\""
        echo ". '$F/udp.block'"
    } > "$F/runF.sh"
    ( PATH="$F/bin:/usr/bin:/bin" bash "$F/runF.sh" ) 2>/dev/null
}
runF "10.0.0.1:10810" "10.0.0.1:10810" 1
[ "$(wc -l < "$F/f.ok")" = 3 ] && [ ! -f "$F/f.bad" ] \
    && ok "F1: процесс жив, сокеты слушают → 3×OK" \
    || bad "F1: ok=$(cat "$F/f.ok" 2>/dev/null | wc -l) bad=$(cat "$F/f.bad" 2>/dev/null | wc -l)"
runF "" "10.0.0.1:10810" 1
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" \
    && ok "F2: процесс жив, udp-сокета нет → FAIL сохранён (реальный дефект)" \
    || bad "F2: bad=$(cat "$F/f.bad" 2>/dev/null)"
runF "" "" 0
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F3: процесс не запущен → warn, сокеты не проверяем, FAIL нет (R48-9)" \
    || bad "F3: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

# A6-4: PATH без pidof вовсе — живость через /proc-скан (имитатор xray)
_BASH4="$(command -v bash)"
mkdir -p "$F/bin2"
ln -sf "$(command -v tr)" "$F/bin2/tr"
ln -sf "$(command -v head)" "$F/bin2/head"
cp /bin/sleep "$F/bin2/xray" && chmod +x "$F/bin2/xray"
"$F/bin2/xray" 30 & _IMPID=$!
runFP(){
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"\"; _lt=\"\""
        echo ". '$F/udp.block'"
    } > "$F/runFP.sh"
    # bash по абсолютному пути: VAR=x cmd резолвит cmd уже в новом PATH
    ( PATH="$F/bin2" "$_BASH4" "$F/runFP.sh" ) 2>/dev/null
}
runFP
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" && grep -q 'запущен' "$F/f.ok" \
    && ok "F4: без pidof живой процесс найден через /proc → udp-FAIL сохранён (A6-4)" \
    || bad "F4: ok=$(cat "$F/f.ok" 2>/dev/null) bad=$(cat "$F/f.bad" 2>/dev/null)"
kill "$_IMPID" 2>/dev/null; wait "$_IMPID" 2>/dev/null
runFP
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F5: без pidof процесс отсутствует → warn, FAIL нет" \
    || bad "F5: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

echo "═══ J. Аудит-19: R49-1 (дубль unblock_update), R49-2 (hysteria) ═══"
NB1=$(grep 'safe_start_service "S99unblock"' "$K/opt/bin/deploy_bypass.sh" \
    | grep -vc '^[[:space:]]*#' || true)
[ "${NB1:-0}" = 0 ] && grep -q 'R49-1 (аудит-19)' "$K/opt/bin/deploy_bypass.sh" \
    && ok "J1: deploy не запускает S99unblock в фоне (дубль исключён, контракт-комментарий на месте)" \
    || bad "J1: живых вызовов S99unblock: $NB1"
grep -q '/opt/bin/unblock_update.sh >/dev/null 2>&1 &' \
    "$K/opt/etc/init.d/S99unblock" \
    && ok "J2: boot-путь S99unblock не тронут (фоновый запуск при загрузке)" \
    || bad "J2: S99unblock изменился"
# NB: head -1|awk для XRAY корректен (первая строка без баннера) —
# инвариант только про hysteria-строку
HYLINE=$(grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1)
printf '%s' "$HYLINE" | grep -qF "head -1 | awk" \
    && bad "J3: hysteria-строка всё ещё парсится по первому полю баннера" \
    || ok "J3: парсинг версии hysteria — grep -oE (xray-строки не тронуты)"
mkdir -p "$F/bin3"
cat > "$F/bin3/hysteria" <<'HYS'
#!/bin/sh
printf 'Hysteria2 \xe2\x9c\x93\n'
printf 'Version:        app/v2.13.0\n'
printf 'Platform:       linux/amd64\n'
exit 0
HYS
chmod +x "$F/bin3/hysteria"
grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1 > "$F/hy.echo"
( PATH="$F/bin3:/usr/bin:/bin" sh -c "_hy_bin='$F/bin3/hysteria'; . '$F/hy.echo'" ) > "$F/hy.out" 2>/dev/null
grep -q 'уже установлена (2.13.0), скачивание пропущено' "$F/hy.out" \
    && ok "J4: hysteria 2.x (баннер первой строкой) → «уже установлена (2.13.0)» (R49-2)" \
    || bad "J4: вывод: $(cat "$F/hy.out" 2>/dev/null)"
ND=$(grep -c 'аудит-19' "$K/opt/bin/deploy_bypass.sh" || true)
NT=$(grep -c 'аудит-19' "$K/opt/bin/test_udp_tunnels.sh" || true)
[ "$ND" -ge 5 ] && [ "$NT" -ge 1 ] \
    && ok "J5: маркеры аудита-19: deploy=$ND, test_udp_tunnels=$NT" \
    || bad "J5: deploy=$ND test_udp=$NT"

echo "═══ K. Аудит-20: firewall панели, /tmp-обёртки, ротация, TG, CSRF ═══"
GEN="$K/opt/etc/bot/generator.py"

# K1 (FW-1): в setup_firewall нет blanket-цикла по ALLOWED_SUBNETS;
# подсети берутся из LAN-интерфейсов (паритет с B7 хука).
K1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'for net in \[str(n) for n in ALLOWED_SUBNETS\]' || true)
K1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "proto kernel\|'inet'" || true)
grep -q 'веб-панель доступна только с 127.0.0.1' "$GEN" && K1C=1 || K1C=0
[ "$K1A" = 0 ] && [ "$K1B" -ge 2 ] && [ "$K1C" = 1 ] \
    && ok "K1: setup_firewall — подсети LAN-интерфейсов (B7-паритет), без blanket" \
    || bad "K1: blanket=$K1A lan_list=$K1B degr=$K1C"

# K2 (TW-1): нет файлов-обёрток в /tmp; sh -c + O_NOFOLLOW + mkstemp.
K2A=$(grep -c 'WRAPPER' "$GEN" || true)
K2B=$(grep -c "'-c', body," "$GEN" || true)
K2C=$(grep -c 'O_NOFOLLOW' "$GEN" || true)
K2D=$(grep -c 'mkstemp' "$GEN" || true)
if [ "$K2A" = 0 ] && [ "$K2B" = 2 ] && [ "$K2C" -ge 2 ] && [ "$K2D" -ge 3 ]; then
    # поведенческий прогон точного body обёртки unblock
    KF2="$(mktemp -d)"
    sed -n "/^    body = '\{3\}/,/^'\{3\}$/p" "$GEN" \
        | sed "1s/^    body = '\{3\}//; \$d" > "$KF2/body.sh"
    dash -n "$KF2/body.sh" 2>/dev/null
    printf '#!/bin/sh\necho out; echo err >&2; exit 7\n' > "$KF2/s.sh"
    chmod +x "$KF2/s.sh"
    sh "$KF2/body.sh" "$KF2/st.json" "$KF2/tm" "$KF2/s.sh" "" \
        > "$KF2/run.log" 2>&1
    K2RC=$?
    if [ "$K2RC" = 7 ] \
        && grep -q 'out' "$KF2/run.log" \
        && grep -q '"status":"error"' "$KF2/st.json" \
        && grep -q 'exit code 7' "$KF2/st.json"; then
        ok "K2: обёртки — sh -c + O_NOFOLLOW; body: rc/log/фолбэк-статус верны"
    else
        bad "K2: body-прогон rc=$K2RC: $(cat "$KF2/st.json" 2>/dev/null)"
    fi
    rm -rf "$KF2"
else
    bad "K2: WRAPPER=$K2A sh-c=$K2B nofollow=$K2C mkstemp=$K2D"
fi

# K3 (RL-1): триггер ротации — только размер; KEEP — цель обрезки.
K3T=$(grep -c 'if \[ "$_sz" -gt "$MAX" \]' "$K/opt/bin/rotate_logs.sh" || true)
K3L=$(grep -c -- '-gt "$KEEP"' "$K/opt/bin/rotate_logs.sh" || true)
KF3="$(mktemp -d)"
sed 's|^rotate /opt/etc/bot/error.log$|rotate "$TGT"|; s|^rotate /opt/root/KeenSnap/backup.log$|:|; s|^rotate /opt/var/log/100-redirect.log$|:|; s|^rotate /tmp/unblock_update.log$|:|; s|^MAX=.* rotate |: # |; s|^find /tmp -maxdepth 1|: find /nonexistent|' \
    "$K/opt/bin/rotate_logs.sh" > "$KF3/rot.sh"
sed -i "s|^umask 022|umask 022\nTGT=\"$KF3/error.log\"|" "$KF3/rot.sh"
dash -n "$KF3/rot.sh" 2>/dev/null
awk 'BEGIN{for(i=1;i<=150;i++)print "line"i}' > "$KF3/error.log"
MAX=524288 KEEP=100 sh "$KF3/rot.sh"
K3A=$(wc -l < "$KF3/error.log")
awk 'BEGIN{for(i=1;i<=1000;i++)print "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}' \
    > "$KF3/error.log"
MAX=50000 KEEP=100 sh "$KF3/rot.sh"
K3B=$(wc -l < "$KF3/error.log")
if [ "$K3T" = 1 ] && [ "$K3L" = 0 ] && [ "$K3A" = 150 ] && [ "$K3B" = 100 ]; then
    ok "K3: ротация по размеру: 150 строк<MAX не тронуты, >MAX → KEEP=100"
else
    bad "K3: триггер=$K3T keep-триггер=$K3L A=$K3A B=$K3B"
fi
rm -rf "$KF3"

# K4 (TG-1): общая tg_send_message; urlencode; токен вне cmdline.
K4A=$(grep -c 'tg_send_message()' "$K/opt/bin/common.sh" || true)
K4B=$(grep -c -- '--data-urlencode' "$K/opt/bin/common.sh" || true)
K4C=$(grep -c -- '-K -' "$K/opt/bin/common.sh" || true)
K4D=$(( $(grep -c 'text=\${' "$K/opt/bin/check_updates.sh" || true) \
    + $(grep -c 'text=\${' "$K/opt/bin/unblock_dnsmasq.sh" || true) ))
KF4="$(mktemp -d)"; mkdir -p "$KF4/bin" "$KF4/run"
sed "s|/opt/etc/bot/bot_config.py|$KF4/bot_config.py|g; s|/opt/var/run/|$KF4/run/|g" \
    "$K/opt/bin/common.sh" > "$KF4/common_m.sh"
printf 'token = "ABC123TOKEN"\n' > "$KF4/bot_config.py"
echo "-100200300" > "$KF4/run/bot_chat_id_notify.txt"
printf '#!/bin/sh\necho "ARGV:$@" >> "$MOCKLOG"\ncat > "$MOCKCFG"\nexit 0\n' \
    > "$KF4/bin/curl"
chmod +x "$KF4/bin/curl"
export MOCKLOG="$KF4/argv.log" MOCKCFG="$KF4/cfg.txt"
K4E=$(PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_urlencode 'a&b%c+d<e>'")
PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_send_message 'обновление & готово 100%' HTML"
K4G=0; grep -q 'ABC123TOKEN' "$KF4/argv.log" 2>/dev/null || K4G=1
K4H=0; grep -q 'url = "https://api.telegram.org/botABC123TOKEN/sendMessage"' \
    "$KF4/cfg.txt" 2>/dev/null && K4H=1
if [ "$K4A" = 1 ] && [ "$K4B" -ge 1 ] && [ "$K4C" -ge 1 ] && [ "$K4D" = 0 ] \
    && [ "$K4E" = 'a%26b%25c%2Bd%3Ce%3E' ] && [ "$K4G" = 1 ] && [ "$K4H" = 1 ]; then
    ok "K4: tg_send_message: -K -, --data-urlencode, urlencode, токен вне argv"
else
    bad "K4: fn=$K4A ue=$K4B K=$K4C oldtext=$K4D enc=$K4E tok=$K4G url=$K4H"
fi
rm -rf "$KF4"

# K5 (CS-1+O-1/AF-1): request.host не источник доверия; политика в
# helpers; sweep вызывается из security_checks.
K5A=$(grep -c 'str(request.host)' "$GEN" || true)
K5B=$(grep -c 'def _csrf_origin_allowed' "$GEN" || true)
K5C=$(grep -c 'def _auth_fails_sweep' "$GEN" || true)
K5D=$(grep -c '_auth_fails_sweep(' "$GEN" || true)
[ "$K5A" = 0 ] && [ "$K5B" = 1 ] && [ "$K5C" = 1 ] && [ "$K5D" -ge 2 ] \
    && ok "K5: Origin/_auth_fails — политика в helpers, вызов на месте (L-1+O-1/AF-1)" \
    || bad "K5: reqhost=$K5A origin_h=$K5B sweep_h=$K5C calls=$K5D"

# K6 (BC-1): ранний chmod 0600 bot_config.py сразу после apply.
K6A=$(grep -c 'chmod 0600 /opt/etc/bot/bot_config.py' "$K/opt/bin/deploy_bypass.sh" || true)
K6B=$(sed -n "$(grep -n 'if busybox cp -a' "$K/opt/bin/deploy_bypass.sh" | head -1 | cut -d: -f1),+22p" \
    "$K/opt/bin/deploy_bypass.sh" | grep -c 'BC-1' || true)
[ "$K6A" -ge 4 ] && [ "$K6B" -ge 2 ] \
    && ok "K6: chmod 0600 bot_config.py после apply (BC-1, до аварийных выходов)" \
    || bad "K6: chmod-строк=$K6A маркеров-возле-apply=$K6B"

echo "═══ L. Аудит-21: legacy-blanket, preflight, предупреждение -remove ═══"

# L1 (FW-1b): зачистка legacy-blanket в setup_firewall; fallback нет.
L1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "legacy_net in ('192.168.0.0/16', '10.0.0.0/8'," || true)
L1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'ALLOWED_SUBNETS' || true)
[ "$L1A" = 1 ] && [ "$L1B" = 0 ] \
    && ok "L1: legacy-blanket снимается панелью; fallback на ALLOWED_SUBNETS нет" \
    || bad "L1: legacy=$L1A fallback=$L1B"

# L2 (PF-1): preflight — только flask+markupsafe; текст deploy раздельный.
L2A=$(grep -c 'import flask, markupsafe' "$K/opt/etc/init.d/S99generator" || true)
L2B=$(grep -c 'import flask, requests' "$K/opt/etc/init.d/S99generator" || true)
L2C=$(grep -c 'Панели нужен flask (+markupsafe); боту — telebot и requests' \
    "$K/opt/bin/deploy_bypass.sh" || true)
L2D=$(grep -c 'Веб-панель и бот без этих модулей не запустятся' \
    "$K/opt/bin/deploy_bypass.sh" || true)
[ "$L2A" = 1 ] && [ "$L2B" = 0 ] && [ "$L2C" = 1 ] && [ "$L2D" = 0 ] \
    && ok "L2: preflight flask+markupsafe (без requests); текст deploy раздельный" \
    || bad "L2: preflight=$L2A/$L2B текст=$L2C/$L2D"

# L3 (RM-1): uninstall_netfilter предупреждает об остатке чужих ACCEPT.
# Поведенчески: тот же экстракт/мок, что в секции A.
cat > "$F/runL.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/l3state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runL.sh"
cp "$F/rules.txt" "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3a.log" 2>&1
L3A=$(grep -c 'вне формы проекта: 3' "$F/l3a.log" || true)
grep -v -- '--dport 8080 -j ACCEPT' "$F/rules.txt" > "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3b.log" 2>&1
L3B=$(grep -c 'вне формы проекта' "$F/l3b.log" || true)
L3RC=$(grep -c '^RC=0$' "$F/l3a.log" || true)
if [ "$L3A" = 1 ] && [ "$L3B" = 0 ] && [ "$L3RC" = 1 ]; then
    ok "L3: -remove предупреждает о 3 чужих ACCEPT; без чужих — молчит; rc=0"
else
    bad "L3: с-чужими=$L3A без-чужих=$L3B rc=$L3RC"
fi

echo "═══ M. Аудит-22: Origin-туннель, tmp-статус, кап, нормализация ═══"

# M1 (O-1): поведенческая матрица _csrf_origin_allowed (экстракция).
python3 - "$GEN" > "$F/m1.out" 2>&1 <<'PYM1'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _csrf_origin_allowed\(.*?(?=^(?:@app\.before_request\n)?def )', src, re.M | re.S)
assert m, 'no _csrf_origin_allowed'
import ipaddress
from urllib.parse import urlparse
g = {
    'ipaddress': ipaddress, 'urlparse': urlparse,
    'LAN_IP': '192.168.1.1', 'LISTEN_PORT': 8080,
    '_lan_host_addresses': lambda: {'192.168.2.1'},
    '_ORIGIN_EXTRA_HOSTS': ['my.keenetic.net'],
}
exec(m.group(0), g)
f = g['_csrf_origin_allowed']
cases = [
    ('http://192.168.1.1:8080', '192.168.1.5', True),
    ('http://127.0.0.1:18080', '127.0.0.1', True),
    ('http://localhost:19000', '127.0.0.1', True),
    ('http://127.0.0.1:18080', '192.168.1.5', False),
    ('http://127.0.0.1:8080', '192.168.1.5', False),
    ('http://localhost:8080', '192.168.1.5', False),
    ('http://192.168.2.1:8080', '192.168.1.5', True),
    ('http://my.keenetic.net:8080', '192.168.1.5', True),
    ('http://evil.example:8080', '192.168.1.5', False),
    ('http://192.168.1.1', '192.168.1.5', False),
    ('ftp://192.168.1.1:8080', '192.168.1.5', False),
]
bad = [i for i, (o, c, want) in enumerate(cases) if f(o, c) != want]
if bad:
    print('BAD=%s' % ','.join(map(str, bad)))
else:
    print('MATRIX_OK(%d)' % len(cases))
PYM1
grep -q 'MATRIX_OK(11)' "$F/m1.out" \
    && ok "M1: Origin: туннель ✓ (loopback-клиент), удалённый loopback ✗ на любом порту (A9-4), альт-LAN-IP ✓, конфиг-имя ✓, чужие ✗" \
    || bad "M1: $(cat "$F/m1.out")"

# M2 (TS-1): tmp-статус не переживает прогон (успех и fallback).
KF6="$(mktemp -d)"
python3 - "$GEN" > "$KF6/body.sh" <<'PYM2'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search('body = ' + Q + '(.*?)' + Q, src, re.S)
assert m, 'no body'
sys.stdout.write(m.group(1))
PYM2
dash -n "$KF6/body.sh" 2>/dev/null
printf '{"status":"done","ts":1,"message":"by script"}\n' > "$KF6/st1.json"
printf '#!/bin/sh\nexit 0\n' > "$KF6/s0.sh"; chmod +x "$KF6/s0.sh"
sh "$KF6/body.sh" "$KF6/st1.json" "$KF6/tmp1" "$KF6/s0.sh" "" \
    > "$KF6/a.log" 2>&1
printf '#!/bin/sh\nexit 7\n' > "$KF6/s7.sh"; chmod +x "$KF6/s7.sh"
sh "$KF6/body.sh" "$KF6/st2.json" "$KF6/tmp2" "$KF6/s7.sh" "" \
    > "$KF6/b.log" 2>&1
if [ ! -e "$KF6/tmp1" ] && [ ! -e "$KF6/tmp2" ] \
    && grep -q 'by script' "$KF6/st1.json" \
    && grep -q '"status":"error"' "$KF6/st2.json" \
    && grep -q 'exit code 7' "$KF6/st2.json"; then
    ok "M2: tmp-статус удалён и при успехе (trap), и при fallback (mv); статусы верны"
else
    bad "M2: tmp1=$([ -e "$KF6/tmp1" ] && echo есть || echo нет) tmp2=$([ -e "$KF6/tmp2" ] && echo есть || echo нет)"
fi
rm -rf "$KF6"
K2TRAP=$(grep -c "trap 'rm -f" "$GEN" || true)
K2EXC=$(grep -c 'os.unlink(tmp_status)' "$GEN" || true)
[ "$K2TRAP" = 2 ] && [ "$K2EXC" = 2 ] \
    && ok "M2b: trap в обоих body + очистка при отказе Popen (TS-1)" \
    || bad "M2b: trap=$K2TRAP unlink=$K2EXC"

# M3 (AF-1 + FB-11): кап 256; истёкшие блокировки чистятся; активный
# счётчик НЕ сбрасывается (K50-2); 429 достижим; предел после вставки.
python3 - "$GEN" > "$F/m3.out" 2>&1 <<'PYM3'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
mc = re.search(r'^_AUTH_FAILS_MAX = (\d+)$', src, re.M)
mt = re.search(r'^def _auth_fails_trim\(.*?(?=^def )', src, re.M | re.S)
mf = re.search(r'^def _auth_fails_sweep\(.*?(?=^def )', src, re.M | re.S)
assert mc and mt and mf, 'no const/funcs'
g = {'_AUTH_FAILS_MAX': int(mc.group(1))}
exec(mt.group(0), g)
exec(mf.group(0), g)
trim, sweep = g['_auth_fails_trim'], g['_auth_fails_sweep']
d = {('10.%d.0.1' % i): (5, 2e9) for i in range(300)}
sweep(d, '10.0.0.1', 1e9)
cap_ok = len(d) == 256
d2 = {'a': (0, 100.0), 'b': (5, 2e9)}
r = sweep(d2, 'a', 1e9)
exp_ok = 'a' not in d2 and 'b' in d2 and r == (0, 0.0)
d3 = {'c': (3, 0.0)}
r3 = sweep(d3, 'c', 1e9)
keep_ok = r3 == (3, 0.0) and 'c' in d3
fm = {}
hist = []
for i in range(6):
    f, b = sweep(fm, 'c', 1000.0 + i)
    if b > 1000.0 + i:
        hist.append('429')
        continue
    f += 1
    if f >= 5:
        fm['c'] = (0, 1000.0 + i + 300)
        hist.append('B')
    else:
        fm['c'] = (f, 0.0)
        hist.append(str(f))
    trim(fm)
sim_ok = hist == ['1', '2', '3', '4', 'B', '429']
fm2 = {('c%d' % i): (1, 0.0) for i in range(256)}
sweep(fm2, 'new', 1e9)
fm2['new'] = (1, 0.0)
trim(fm2)
ins_ok = len(fm2) == 256
res = (cap_ok, exp_ok, keep_ok, sim_ok, ins_ok)
print('OK' if all(res) else
      'BAD cap=%s exp=%s keep=%s sim=%s(%s) ins=%s(%d)' % (
          cap_ok, exp_ok, keep_ok, sim_ok, hist, ins_ok, len(fm2)))
PYM3
grep -q '^OK$' "$F/m3.out" \
    && ok "M3: кап 256; истёкшая снята; активный счётчик жив; 6 неудачных → блок+429; предел после вставки (AF-1+FB-11)" \
    || bad "M3: $(cat "$F/m3.out")"

# M4 (SN-1): fallback-нормализация host-bits; невалидные пропущены.
python3 - "$GEN" > "$F/m4.out" 2>&1 <<'PYM4'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _lan_subnet_list\(.*?(?=^def )', src, re.M | re.S)
assert m, 'no func'
import ipaddress, threading
class _R:
    def __init__(self, out): self.stdout = out
class _SP:
    def run(self, args, **kw):
        if args[:4] == ['ip', '-4', 'route', 'show']:
            return _R('')
        if args[:4] == ['ip', '-4', 'addr', 'show']:
            return _R(
                '2: br9: <BROADCAST,MULTICAST,UP>\n'
                '    inet 192.168.2.1/24 brd 192.168.2.255 br9\n'
                '    inet 10.0.0.99/8 brd 10.255.255.255 br9\n'
                '    inet frog/24 br9\n')
        return _R('')
class _C:
    lan_ifaces = ['br9']
g = {'subprocess': _SP(), 'ipaddress': ipaddress, 'config': _C(),
     'threading': threading}
exec(m.group(0), g)
nets, found = g['_lan_subnet_list']()
ok1 = '192.168.2.1/24' not in nets and '192.168.2.0/24' in nets
ok2 = '10.0.0.0/8' in nets
ok3 = not any('frog' in n for n in nets)
ok4 = nets and nets[0] == '127.0.0.0/8' and found is True
print('OK' if ok1 and ok2 and ok3 and ok4 else
      'BAD %r' % (nets,))
PYM4
grep -q '^OK$' "$F/m4.out" \
    && ok "M4: fallback: 192.168.2.1/24 → 192.168.2.0/24; 10.0.0.99/8 → 10.0.0.0/8; frog пропущен (SN-1)" \
    || bad "M4: $(cat "$F/m4.out")"
grep -q 'ACCEPT не создан' "$GEN" \
    && ok "M4b: отказ создания ACCEPT логируется (SN-1)" \
    || bad "M4b: нет логирования отказа ACCEPT"

echo "═══ N. Аудит-23: проверка фидов Entware (сбой установки r48) ═══"
NB="$F/nb"; mkdir -p "$NB/bin" "$NB/dl"
DEP="$K/opt/bin/deploy_bypass.sh"
# экстракция функций блока зеркал
for _nfn in _entware_stock_feeds _entware_feed_base _entware_probe_feed_url \
            _entware_feeds_reachable _entware_prepare_candidate pick_entware_base; do
    awk "/^${_nfn}\(\) \{/,/^\}/" "$DEP" >> "$NB/fns.sh"
    echo >> "$NB/fns.sh"
done
grep -q '^pick_entware_base()' "$NB/fns.sh" || bad "N0: экстракция блока зеркал не удалась"

# N1 (FB-2): https-проба без curl → «не проверено» (rc 2), не «нет».
printf '#!/bin/sh\nexit 1\n' > "$NB/bin/wget"; chmod +x "$NB/bin/wget"
cat > "$NB/run1.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD=""
export KEENZOO_DLTMP DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run1.sh"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run1.sh" 2>/dev/null | tail -1)
[ "$NBRC" = "PROBE_RC=2" ] \
    && ok "N1: https без curl → «не проверено» (rc 2), зеркало не бракуется (FB-2)" \
    || bad "N1: $NBRC (ожидался PROBE_RC=2)"

# N2 (FB-3): curl-проба лёгкая (Range 256Б), а не полная загрузка.
printf '#!/bin/sh\necho "ARGV:$@" >> /tmp/f47chk/nb/curl.log\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c 256 /dev/zero > "$2"; shift; done\nexit 0\n' \
    > "$NB/bin/curl"; chmod +x "$NB/bin/curl"
cat > "$NB/run2.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD="curl"
export KEENZOO_DLTMP DL_CMD
have_cmd() { command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run2.sh"
rm -f "$NB/curl.log"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run2.sh" 2>/dev/null | tail -1)
if [ "$NBRC" = "PROBE_RC=0" ] && grep -q -- '-r 0-255' "$NB/curl.log" 2>/dev/null; then
    ok "N2: curl-проба — Range 256Б (не полная загрузка Packages.gz) (FB-3)"
else
    bad "N2: rc=$NBRC; curl-лог: $(cat "$NB/curl.log" 2>/dev/null | head -1)"
fi
rm -f "$NB/bin/curl"

# N3/N4/N5: поведенческие сценарии pick_entware_base (как на устройстве).
cat > "$NB/pick.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl
KZ_DEPLOY_OPKG_CONF="$1"
ENTWARE_ARCH=aarch64-k3.10; DL_CMD=""
export KEENZOO_DLTMP KZ_DEPLOY_OPKG_CONF ENTWARE_ARCH DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { echo "WARN: $*"; }
die()   { echo "DIE: $*"; exit 42; }
ENTWARE_MIRRORS="https://bin.entware.net https://entware.diversion.ch"
_ENTWARE_BASE_REQUESTED=""
ENTWARE_BASE=""; ENTWARE_MIRROR_SWITCH_NEEDED=0; ENTWARE_MIRROR_CHANGED=0
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
pick_entware_base >/dev/null 2>&1
echo "PICK_RC=$?"
EOF
chmod +x "$NB/pick.sh"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc/gz keendev http://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\nsrc/gz keendev https://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/https.conf"
RC_A=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/http.conf" 2>/dev/null | tail -1)
RC_B=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/https.conf" 2>/dev/null | tail -1)
[ "$RC_A" = "PICK_RC=0" ] \
    && ok "N3: сценарий устройства (http-фиды, curl нет) → rc 0, установка не гибнет (FB-6 аудита-24)" \
    || bad "N3: $RC_A (ожидался PICK_RC=0)"
[ "$RC_B" = "PICK_RC=0" ] \
    && ok "N4: https-фиды без curl → rc 0: установка НЕ гибнет, решает opkg update (FB-1/FB-2)" \
    || bad "N4: $RC_B (ожидался PICK_RC=0)"

# N5 (FB-1/FB-5): инварианты текстов и семантики в самом deploy.
N5A=$(grep -c 'ни один HTTPS-кандидат не прошёл' "$DEP" || true)
N5B=$(grep -c 'Разрешить осознанно: KEENZOO_ALLOW_HTTP_FEED=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5C=$(grep -c 'KEENZOO_OPKG_OFFLINE=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5D=$(grep -c 'Автоматический бутстрап HTTPS ниже попробует зеркала' "$DEP" || true)
[ "$N5A" = 0 ] && [ "$N5B" = 1 ] && [ "$N5C" -ge 1 ] && [ "$N5D" = 1 ] \
    && ok "N5: старые немые die убраны; подсказки-обходы на месте; недоступность фида → авто-бутстрап зеркал (FB-1/FB-5/FB-6/FB-78)" \
    || bad "N5: старый-die=$N5A allow-hint=$N5B offline-hint=$N5C fb78-hint=$N5D"

echo "═══ P. Аудит-24: HTTP-гейт в точке риска, retry пробы ═══"
PB="$F/pb"; mkdir -p "$PB/bin" "$PB/dl"
# экстракция гейт-хелперов
for _pfn in _kz_pkg_installed _kz_http_feed_active _kz_http_install_gate; do
    awk "/^${_pfn}\(\) \{/,/^\}/" "$DEP" >> "$PB/gate.sh"
    echo >> "$PB/gate.sh"
done
grep -q '^_kz_http_install_gate()' "$PB/gate.sh" || bad "P0: экстракция гейтов не удалась"

# фейковый opkg: list-installed знает только tor; /var/opkg/status недоступен
printf '#!/bin/sh\n[ "$1" = list-installed ] && { echo "tor - 1.0"; exit 0; }\nexit 0\n' \
    > "$PB/bin/opkg"; chmod +x "$PB/bin/opkg"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\n' > "$PB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$PB/https.conf"

cat > "$PB/g.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/pb/bin:/bin"; export PATH
warn() { echo "WARN: $*"; }
. /tmp/f47chk/pb/gate.sh >/dev/null 2>&1
case "$1" in
    installed) _kz_pkg_installed "$2"; echo "RC=$?";;
    gate)      KZ_DEPLOY_OPKG_CONF="$2" KEENZOO_ALLOW_HTTP_FEED="${3:-0}" \
                   _kz_http_install_gate testpkg; echo "RC=$?";;
esac
EOF
chmod +x "$PB/g.sh"
GR1=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed tor 2>/dev/null | tail -1)
GR2=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed xray 2>/dev/null | tail -1)
GR3=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 0 2>/dev/null | tail -1)
GR4=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 1 2>/dev/null | tail -1)
GR5=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/https.conf 0 2>/dev/null | tail -1)
if [ "$GR1" = "RC=0" ] && [ "$GR2" = "RC=1" ] && [ "$GR3" = "RC=1" ] \
    && [ "$GR4" = "RC=0" ] && [ "$GR5" = "RC=0" ]; then
    ok "P1: гейт: установлен→пропуск; http без ALLOW→warn+пропуск; http+ALLOW/https→можно (FB-6)"
else
    bad "P1: inst=$GR1/$GR2 http0=$GR3 http1=$GR4 https=$GR5"
fi
GATE_WARNS=$(PATH=/usr/bin:/bin KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/pb/http.conf bash -c \
    'warn(){ echo "WARN:$*"; }; PATH="/tmp/f47chk/pb/bin:/bin"; . /tmp/f47chk/pb/gate.sh >/dev/null 2>&1; _kz_http_install_gate testpkg' 2>/dev/null)
printf '%s' "$GATE_WARNS" | grep -q 'KEENZOO_ALLOW_HTTP_FEED=1' \
    && ok "P2: warn гейта несёт обход KEENZOO_ALLOW_HTTP_FEED=1 (FB-7)" \
    || bad "P2: warn гейта без подсказки: $GATE_WARNS"

# P3: гейт вызван во всех сетевых opkg install шага пакетов.
P3A=$(grep -c '_kz_http_install_gate' "$DEP" || true)
P3B=$(grep -c '_kz_pkg_installed "\$pkg" && continue' "$DEP" || true)
[ "$P3A" -ge 10 ] && [ "$P3B" = 1 ] \
    && ok "P3: гейт на всех местах установок ($P3A); цикл пакетов: skip-if-installed" \
    || bad "P3: gate=$P3A skip=$P3B"

# P4 (FB-8): http-проба — ensure_dns + повтор.
# FB-51 (аудит-28) добавил внутрь http-ветки case с собственными ;;,
# поэтому прежний awk-диапазон до первого ;; обрезался — считаем по
# всей функции пробы.
awk 'index($0, "_entware_probe_feed_url() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$F/p4fn.sh"
P4A=$(grep -c 'ensure_dns' "$F/p4fn.sh" || true)
P4B=$(grep -c '_epf_try' "$F/p4fn.sh" || true)
P4C=$(grep -c 'while \[ "\$_epf_try" -le 2 \]' "$F/p4fn.sh" || true)
[ "$P4A" -ge 1 ] && [ "$P4B" -ge 3 ] && [ "$P4C" -ge 1 ] \
    && ok "P4: http-проба: ensure_dns + 2 попытки (FB-8; диапазон уточнён под case FB-51)" \
    || bad "P4: dns=$P4A retry=$P4B loops=$P4C"

# P5: формулировки.
P5A=$(grep -c 'Пакеты бутстрапа HTTPS установлены' "$DEP" || true)
P5B=$(grep -c 'Пакеты бутстрапа HTTPS не установлены' "$DEP" || true)
[ "$P5A" -ge 2 ] && [ "$P5B" -ge 1 ] \
    && ok "P5: формулировки факта авто-бутстрапа: установка (текущий фид/зеркало) и провал — честные вердикты (FB-9/FB-78/FB-81)" \
    || bad "P5: установлены=$P5A провал=$P5B"

echo "═══ Q. Аудит-25: панель, HTTP-политика, Origin, гейты ═══"

# Q0 (FB-10): единственный @app.before_request стоит на security_checks().
python3 - "$GEN" > "$F/q0.out" 2>&1 <<'PYQ0'
import sys
lines = open(sys.argv[1], encoding='utf-8').read().split('\n')
dec = [i for i, l in enumerate(lines) if l.strip() == '@app.before_request']
ok = (len(dec) == 1 and dec[0] + 1 < len(lines)
      and lines[dec[0] + 1].startswith('def security_checks():'))
print('OK' if ok else 'BAD dec=%r' % [lines[i] for i in dec])
PYQ0
grep -q '^OK$' "$F/q0.out" \
    && ok "Q0: @app.before_request — единственный и на security_checks() (K50-1)" \
    || bad "Q0: $(cat "$F/q0.out")"

# Q1 (FB-11): lock вокруг sweep+вставки; предел после вставки.
Q1A=$(grep -c '^_AUTH_FAILS_LOCK = threading.Lock()' "$GEN" || true)
Q1B=$(grep -c 'with _AUTH_FAILS_LOCK:' "$GEN" || true)
Q1C=$(grep -c '_auth_fails_trim(_auth_fails)' "$GEN" || true)
[ "$Q1A" = 1 ] && [ "$Q1B" = 1 ] && [ "$Q1C" = 1 ] \
    && ok "Q1: sweep+вставка под _AUTH_FAILS_LOCK; trim после вставки (K50-2/A9-5)" \
    || bad "Q1: lock=$Q1A with=$Q1B trim=$Q1C"

# Q2 (FB-14): базовое имя, ключ конфига, нет портового фолбэка loopback.
Q2A=$(grep -c "_ORIGIN_EXTRA_HOSTS = \['my.keenetic.net'\] + \[" "$GEN" || true)
Q2B=$(grep -c "'allowed_origin_hosts'" "$K/opt/etc/bot/bot_config.py" || true)
Q2C=$(grep -c 'return port == str(LISTEN_PORT)' "$GEN" || true)
[ "$Q2A" = 1 ] && [ "$Q2B" -ge 1 ] && [ "$Q2C" = 0 ] \
    && ok "Q2: my.keenetic.net в базовом наборе; ключ в bot_config; loopback — только loopback-клиент (K50-4/A9-4)" \
    || bad "Q2: base=$Q2A cfg=$Q2B fallback=$Q2C"

# Q3 (FB-12): гейт заглушки в S57hysteria — статика и поведение.
S57="$K/opt/etc/init.d/S57hysteria"
Q3A=$(grep -c 'SKIPPED: hysteria не настроена' "$S57" || true)
Q3B=$(grep -c 'CHANGE_ME' "$S57" || true)
Q3C=$(grep -n 'case "${1:-}" in' "$S57" | head -1 | cut -d: -f1)
Q3D=$(grep -n '^\. /opt/etc/init.d/rc\.func' "$S57" | head -1 | cut -d: -f1)
QB="$F/qb"; mkdir -p "$QB"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$QB/gate.sh"
printf '{\n  "server": "example.com:443",\n  "auth": "CHANGE_ME"\n}\n' > "$QB/ph.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k"\n}\n' > "$QB/ok.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k",\n  "tls": {"sni": "example.com"}\n}\n' > "$QB/sni.json"
printf '{\n  "server": "",\n  "auth": "k"\n}\n' > "$QB/empty.json"
cat > "$QB/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/qb/gate.sh
echo "GATE_RC=PASS"
EOF
chmod +x "$QB/run.sh"
Q3R1=$(KEENZOO_HYSTERIA_CONFIG="$QB/ph.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R2=$(KEENZOO_HYSTERIA_CONFIG="$QB/ok.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R3=$(KEENZOO_HYSTERIA_CONFIG="$QB/sni.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R4=$(KEENZOO_HYSTERIA_CONFIG="$QB/empty.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R5=$(KEENZOO_HYSTERIA_CONFIG="$QB/ph.json" sh "$QB/run.sh" stop 2>&1; echo "rc=$?")
if [ "$Q3A" -ge 1 ] && [ "$Q3B" -ge 1 ] && [ -n "$Q3C" ] && [ -n "$Q3D" ] \
    && [ "$Q3C" -lt "$Q3D" ] \
    && printf '%s' "$Q3R1" | grep -q 'SKIPPED: hysteria не настроена' \
    && printf '%s' "$Q3R1" | grep -q 'rc=0' \
    && printf '%s' "$Q3R2" | grep -q 'GATE_RC=PASS' \
    && printf '%s' "$Q3R3" | grep -q 'GATE_RC=PASS' \
    && printf '%s' "$Q3R4" | grep -q 'SKIPPED' \
    && printf '%s' "$Q3R5" | grep -q 'GATE_RC=PASS'; then
    ok "Q3: S57-гейт: заглушка/пустой server → SKIPPED (rc0); валидный и SNI-маскировка → старт; stop не задет (K50-3)"
else
    bad "Q3: A=$Q3A B=$Q3B case=$Q3C rcfunc=$Q3D r1=$(echo "$Q3R1" | tail -1) r2=$(echo "$Q3R2" | tail -1) r3=$(echo "$Q3R3" | tail -1) r4=$(echo "$Q3R4" | tail -1) r5=$(echo "$Q3R5" | tail -1)"
fi

# Q4 (FB-13): перечислитель ВСЕХ opkg install/upgrade — гейт обязателен.
python3 - "$K" > "$F/q4.out" 2>&1 <<'PYQ4'
import re, sys
PAT = re.compile(r'opkg\s+(?:-f\s+\S+\s+)?(?:install|upgrade)\b')
def check(path, want):
    lines = open(path, encoding='utf-8').read().split('\n')
    sites, ungated = [], []
    for n, line in enumerate(lines):
        t = line.strip()
        if not t or t.startswith('#') or t.startswith(('echo', 'warn', 'printf')):
            continue
        if PAT.search(t):
            sites.append(n + 1)
            ctx = '\n'.join(lines[max(0, n - 10):n])
            if not ('_kz_http_install_gate' in ctx
                    or '_upd_http_install_gate' in ctx
                    or 'FB-78-авто' in ctx):
                ungated.append(n + 1)
    return sites, ungated, want
root = sys.argv[1]
ds, du, dw = check(root + '/opt/bin/deploy_bypass.sh', 13)
us, uu, uw = check(root + '/opt/bin/update_protocols.sh', 4)
ok = (not du and not uu and len(ds) == dw and len(us) == uw)
print('OK deploy=%d updater=%d' % (len(ds), len(us)) if ok else
      'BAD deploy=%d(%s) updater=%d(%s) ungated=%r/%r' % (
          len(ds), dw, len(us), uw, du, uu))
PYQ4
grep -q '^OK deploy=13 updater=4' "$F/q4.out" \
    && ok "Q4: все 17 opkg install/upgrade (13 deploy: 12 под HTTP-гейтом + 1 изолированный авто-сайт бутстрапа FB-78-авто, обслуживающий текущий фид и зеркала — K60-01; + 4 updater) (A9-2/FB-78)" \
    || bad "Q4: $(cat "$F/q4.out")"

# Q5 (FB-17): форма src распознаётся гейтом.
Q5="$F/q5"; mkdir -p "$Q5/bin"
for _pfn in _kz_http_feed_active _kz_http_install_gate; do
    awk "/^${_pfn}\(\) \{/,/^\}/" "$DEP" >> "$Q5/gate.sh"
    echo >> "$Q5/gate.sh"
done
printf '#!/bin/sh\nexit 0\n' > "$Q5/bin/opkg"; chmod +x "$Q5/bin/opkg"
printf 'src custom http://bin.entware.net/aarch64-k3.10\n' > "$Q5/src-http.conf"
printf 'src custom https://bin.entware.net/aarch64-k3.10\n' > "$Q5/src-https.conf"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc custom https://mirror.example/x\n' > "$Q5/mixed.conf"
cat > "$Q5/g.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/q5/bin:/bin"; export PATH
warn() { echo "WARN: $*"; }
. /tmp/f47chk/q5/gate.sh >/dev/null 2>&1
KZ_DEPLOY_OPKG_CONF="$1" KEENZOO_ALLOW_HTTP_FEED="${2:-0}" _kz_http_install_gate testpkg
echo "RC=$?"
EOF
chmod +x "$Q5/g.sh"
Q5R1=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/src-http.conf 0 2>/dev/null | tail -1)
Q5R2=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/src-https.conf 0 2>/dev/null | tail -1)
Q5R3=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/mixed.conf 0 2>/dev/null | tail -1)
[ "$Q5R1" = "RC=1" ] && [ "$Q5R2" = "RC=0" ] && [ "$Q5R3" = "RC=1" ] \
    && ok "Q5: src-форма фида: http → skip, https → ок, mixed → skip (A9-3)" \
    || bad "Q5: http=$Q5R1 https=$Q5R2 mixed=$Q5R3"

# Q6 (FB-18): сервер без Range — честная заметка, rc 0.
Q6="$F/q6"; mkdir -p "$Q6/bin" "$Q6/dl"
printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c 100000 /dev/zero > "$2"; shift; done\nexit 0\n' \
    > "$Q6/bin/curl"; chmod +x "$Q6/bin/curl"
cat > "$Q6/run.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/q6/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/q6/dl; DL_CMD="curl"
export KEENZOO_DLTMP DL_CMD
have_cmd() { command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
echo "NOTE=$_EPF_NOTE"
EOF
chmod +x "$Q6/run.sh"
Q6OUT=$(PATH=/usr/bin:/bin bash "$Q6/run.sh" 2>/dev/null | tail -2)
if printf '%s' "$Q6OUT" | grep -q 'PROBE_RC=0' \
    && printf '%s' "$Q6OUT" | grep -q 'полная загрузка (сервер без Range)'; then
    ok "Q6: сервер игнорирует Range → rc0 + честная «полная загрузка» (не «range 256Б») (A9-6)"
else
    bad "Q6: $Q6OUT"
fi

# Q7 (FB-19): гейт-пропуски видны в сводке.
Q7A=$(grep -c '^SKIPPED_HTTP=""' "$DEP" || true)
Q7B=$(grep -c '_kz_skip_note "\$pkg"' "$DEP" || true)
Q7E=$(grep -c '_kz_skip_note() {' "$DEP" || true)
Q7C=$(grep -c 'Пакеты не установлены из-за HTTP-политики' "$DEP" || true)
Q7D=$(grep -c '\[ -z "$SKIPPED_HTTP" \]' "$DEP" || true)
[ "$Q7A" = 1 ] && [ "$Q7B" = 1 ] && [ "$Q7C" = 1 ] && [ "$Q7D" = 1 ] \
    && [ "$Q7E" = 1 ] \
    && ok "Q7: SKIPPED_HTTP копится (_kz_skip_note, FB-57 дедуп), ⚠️-строка есть, «✅ Пакеты» подавлен (A9-7)" \
    || bad "Q7: init=$Q7A acc=$Q7B warn=$Q7C guard=$Q7D helper=$Q7E"

# Q8 (FB-20): заглушки токена не покидают tg_bot_token.
Q8="$F/q8"; mkdir -p "$Q8"
awk '/^tg_bot_token\(\) \{/,/^\}/' "$K/opt/bin/common.sh" > "$Q8/tok.sh"
sed -i "s#/opt/etc/bot/bot_config.py#$Q8/cfg.py#" "$Q8/tok.sh"
printf 'tg_bot_token\n' >> "$Q8/tok.sh"
printf "token = 'ТОКЕН_БОТА'\n" > "$Q8/cfg.py"; Q8R1=$(sh "$Q8/tok.sh" | wc -c)
printf "token = 'CHANGE_ME'\n" > "$Q8/cfg.py"; Q8R2=$(sh "$Q8/tok.sh" | wc -c)
printf "token = '12345:ABC-DEF'\n" > "$Q8/cfg.py"; Q8R3=$(sh "$Q8/tok.sh")
[ "$Q8R1" = 0 ] && [ "$Q8R2" = 0 ] && [ "$Q8R3" = "12345:ABC-DEF" ] \
    && ok "Q8: ТОКЕН_БОТА/CHANGE_ME → пусто; реальный токен проходит (K50-7)" \
    || bad "Q8: r1=$Q8R1 r2=$Q8R2 r3=[$Q8R3]"

# Q9 (FB-21/FB-22): shlex убран; кэш адресов LAN (включая пустой результат).
python3 - "$GEN" > "$F/q9.out" 2>&1 <<'PYQ9'
import sys, re, types, ipaddress, threading
src = open(sys.argv[1], encoding='utf-8').read()
shlex_n = len([l for l in src.split('\n') if 'shlex' in l])
mfunc = re.search(r'^def _lan_host_addresses\(.*?(?=^def )', src, re.M | re.S)
mcache1 = re.search(r'^_LAN_HOSTS_CACHE = \{.*$', src, re.M)
mcache2 = re.search(r'^_LAN_HOSTS_CACHE_TTL = [\d.]+$', src, re.M)
# FB-30 (аудит-26): функция берёт модульный _LAN_HOSTS_LOCK —
# экстракция Q9 обязана дать его неймспейсу.
mlock = re.search(r'^_LAN_HOSTS_LOCK = threading\.Lock\(\)$', src, re.M)
assert mfunc and mcache1 and mcache2 and mlock, 'no cache/lock/func'
import time as _time
def make_env(stdout):
    calls = {'n': 0}
    class _R:
        def __init__(self, out):
            self.stdout = out
    class _SP:
        TimeoutExpired = Exception
        def run(self, args, **kw):
            calls['n'] += 1
            return _R(stdout)
    class _C:
        lan_ifaces = ['br0', 'br1', 'nwg0']
    g = {'time': _time, 'subprocess': _SP(), 'config': _C(),
         'ipaddress': ipaddress, 'threading': threading}
    exec(mcache1.group(0), g)
    exec(mcache2.group(0), g)
    exec(mlock.group(0), g)
    exec(mfunc.group(0), g)
    return g['_lan_host_addresses'], calls
f, calls = make_env('    inet 192.168.1.1/24 brd x br0\n')
a = f()
same = all(f() == a for _ in range(19))
fe, ce = make_env('')
fe()
fe(); fe(); fe()
print('OK shlex=%d forks=%d stable=%s empty_forks=%d' % (
    shlex_n, calls['n'], same, ce['n']) if (
    shlex_n == 0 and calls['n'] == 3 and same and ce['n'] == 3) else
    'BAD shlex=%d forks=%d stable=%s empty_forks=%d' % (
        shlex_n, calls['n'], same, ce['n']))
PYQ9
grep -q '^OK ' "$F/q9.out" \
    && ok "Q9: import shlex убран; кэш LAN: 3 форка на 20 вызовов, пустой результат кэшируется (K50-8/K50-9)" \
    || bad "Q9: $(cat "$F/q9.out")"

# Q10 (FB-15): канонический путь hysteria.
Q10A=$(grep -c -- '-x /opt/sbin/hysteria' "$DEP" || true)
Q10B=$(grep -c '_hy_canon_ok' "$DEP" || true)
Q10C=$(grep -c '/opt/sbin/hysteria version' "$DEP" || true)
Q10D=$(grep -c 'DEPLOY_MODE" = "restore"' "$DEP" || true)
[ "$Q10A" -ge 2 ] && [ "$Q10B" -ge 2 ] && [ "$Q10C" -ge 4 ] && [ "$Q10D" -ge 1 ] \
    && ok "Q10: гейты/версии hysteria — по /opt/sbin; послабление только restore (K50-5)" \
    || bad "Q10: canon=$Q10A flag=$Q10B ver=$Q10C restore=$Q10D"

# Q11 (FB-16): сводка называет оба поля.
Q11A=$(grep -c 'задайте web_username и web_password' "$DEP" || true)
[ "$Q11A" = 1 ] \
    && ok "Q11: сводка: «задайте web_username и web_password» (K50-6)" \
    || bad "Q11: $Q11A"

# Q12 (FB-13): гейт в update_protocols + граница политики задокументирована.
Q12A=$(grep -c '_upd_http_install_gate' "$K/opt/bin/update_protocols.sh" || true)
Q12B=$(grep -c 'opkg update (загрузка индекса) НЕ гейтится' "$K/opt/bin/update_protocols.sh" || true)
[ "$Q12A" = 5 ] && [ "$Q12B" = 1 ] \
    && ok "Q12: updater: гейт-хелпер + 4 вызова; граница политики описана (A9-2)" \
    || bad "Q12: gate=$Q12A boundary=$Q12B"

# Q13 (FB-10, опционально): реальный Flask-смоук, если flask доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/q13.out" 2>&1 <<'PYQ13'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g
reg = g.app.before_request_funcs.get(None) or list(
    g.app.before_request_funcs.values())[0]
names = [f.__name__ for f in reg]
c = g.app.test_client()
r1 = c.get('/')
r2 = c.get('/api/cfg')
ok = (names == ['security_checks'] and r1.status_code != 500
      and r2.status_code != 500)
print('OK registry=%s /=%s cfg=%s' % (names, r1.status_code, r2.status_code)
      if ok else 'BAD registry=%s /=%s cfg=%s' % (
          names, r1.status_code, r2.status_code))
PYQ13
    grep -q '^OK ' "$F/q13.out" \
        && ok "Q13: Flask: before_request=[security_checks], GET без 5xx (K50-1)" \
        || bad "Q13: $(cat "$F/q13.out")"
else
    echo "[SKIP] Q13: Flask-смоук — flask не установлен на хосте (инвариант Q0 покрывает класс)"
fi

echo "═══ G. R48-5: просмотр списка ≡ сохранению ═══"
python3 - "$K" "$F" <<'PYB'
import ast, io, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import lists_core as lc

src = io.open(os.path.join(K, 'opt/etc/bot/handlers.py'), encoding='utf-8').read()
names = {'load_bypass_blocks', 'sections_to_text', 'format_blocks_for_display'}
segs = [ast.get_source_segment(src, n) for n in ast.parse(src).body
        if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(segs) == 3, 'не все функции извлечены'
ns = {'lists_core': lc, 'os': os}
exec('import os\n', ns)
exec('\n\n'.join(segs), ns)

tf = os.path.join(F, 'disp.txt')
io.open(tf, 'w', encoding='utf-8').write(
    '9.example.com\n1.example.com\n# Группа 1\n8.8.8.8\n1.1.1.1\n'
    '# Пометка без записей\n7.7.7.7\n')
secs = ns['load_bypass_blocks'](tf)
disp = ns['format_blocks_for_display'](secs)
expect = ('1.example.com\n9.example.com\n\n# Группа 1\n1.1.1.1\n8.8.8.8\n\n'
          '# Пометка без записей\n7.7.7.7')
if disp == expect:
    ok('G1: просмотр = порядок файла + сортировка в секции + comment-only видны')
else:
    bad(f'G1: {disp!r} != {expect!r}')
if disp.startswith('1.example.com\n9.example.com'):
    ok('G2: безымянные записи не «всплыли» в конец')
else:
    bad('G2: порядок безымянных нарушен')
if '# Пометка без записей' in disp:
    ok('G3: comment-only секция показывается (N-3 паритет)')
else:
    bad('G3: comment-only скрыт')
if ns['format_blocks_for_display']( []) == 'Список пуст':
    ok('G4: пустой список — «Список пуст»')
else:
    bad('G4: пустой список не обработан')
# Настоящий контракт R48-5: то, что пользователь ВИДИТ, равно тому,
# что оказалось бы в файле после сохранения (round-trip через
# parse_and_save — рендер сохранения сортирует записи так же).
d2 = os.path.join(F, 'lists'); os.makedirs(d2)
lc.UNBLOCK_DIR = d2
tf2 = os.path.join(d2, 'vless.txt')
lc.parse_and_save(tf2, ns['sections_to_text'](secs))
saved = io.open(tf2, encoding='utf-8').read()
if disp == saved.rstrip('\n'):
    ok('G5: просмотр ≡ файлу после сохранения (round-trip parse_and_save)')
else:
    bad(f'G5: {disp!r} != {saved!r}')
io.open(os.path.join(F, 'g.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
GP=0; GF=1
[ -s "$F/g.counts" ] && read GP GF < "$F/g.counts"
PASS=$((PASS+GP)); FAIL=$((FAIL+GF))

echo "═══ H. R48-7: wsSettings.host ═══"
TPL="$K/opt/etc/bot/templates/vless_template.json"
grep -q '"host":"{{ws_host}}"' "$TPL" \
    && ok "H1: шаблон: wsSettings.host (новая форма)" \
    || bad "H1: шаблон не содержит host"
NOLD=$(grep -c '"headers"\|"Host"' "$TPL" || true)
[ "$NOLD" = 0 ] \
    && ok "H2: шаблон: headers/Host отсутствуют" \
    || bad "H2: устаревшая форма в шаблоне ($NOLD)"
python3 - "$K" "$F" <<'PYB'
import ast, io, json, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

grep_tpl = io.open(os.path.join(
    K, 'opt/etc/bot/templates/vless_template.json'),
    encoding='utf-8').read()
if '"path":"{{ws_path}}"' in grep_tpl and '{{ws_host}}' in grep_tpl:
    ok('H3: ws-блок шаблона структурно цел (path+host; рендер — f41)')
else:
    bad('H3: ws-блок шаблона повреждён')

src = io.open(os.path.join(K, 'opt/etc/bot/utils.py'), encoding='utf-8').read()
seg = [ast.get_source_segment(src, n) for n in ast.parse(src).body
       if isinstance(n, ast.FunctionDef) and n.name == '_convert_singbox_vless'][0]
ns = {}
exec(seg, ns)
fn = ns['_convert_singbox_vless']

sb_old = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/ws',
                        'headers': {'Host': 'cdn.example.org'}}}
ws = fn(sb_old)['outbounds'][0]['streamSettings']['wsSettings']
if ws == {'path': '/ws', 'host': 'cdn.example.org'}:
    ok('H4: sing-box headers.Host → wsSettings.host (фолбэк старой формы)')
else:
    bad(f'H4: {ws!r}')

sb_new = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/w', 'host': 'h.example'}}
ws2 = fn(sb_new)['outbounds'][0]['streamSettings']['wsSettings']
if ws2 == {'path': '/w', 'host': 'h.example'}:
    ok('H5: sing-box host → wsSettings.host (приоритет новой формы)')
else:
    bad(f'H5: {ws2!r}')
io.open(os.path.join(F, 'h.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
HP=0; HF=1
[ -s "$F/h.counts" ] && read HP HF < "$F/h.counts"
PASS=$((PASS+HP)); FAIL=$((FAIL+HF))

echo "═══ I. Маркеры, синтаксис, контракты ═══"
MD=$(grep -c 'R48-[1268] (аудит-18)' "$K/opt/bin/deploy_bypass.sh" || true)
[ "$MD" = 4 ] \
    && ok "I1: маркеры R48-1/2/6/8 в deploy (4)" \
    || bad "I1: маркеров в deploy = $MD (ожидалось 4)"
grep -q 'R48-3 (аудит-18)' "$K/opt/etc/init.d/S99generator" \
    && grep -q 'R48-9 (аудит-18)' "$K/opt/bin/test_udp_tunnels.sh" \
    && grep -q 'R48-5 (аудит-18)' "$K/opt/etc/bot/handlers.py" \
    && grep -q 'R48-7 (аудит-18)' "$K/opt/etc/bot/utils.py" \
    && ok "I2: маркеры R48-3/9/5/7 на местах" \
    || bad "I2: какой-то маркер отсутствует"
dash -n "$K/opt/bin/deploy_bypass.sh" && dash -n "$K/opt/etc/init.d/S99generator" \
    && dash -n "$K/opt/bin/test_udp_tunnels.sh" \
    && ok "I3: синтаксис правленых shell-файлов (dash -n)" \
    || bad "I3: dash -n упал"
python3 -m py_compile "$K/opt/etc/bot/handlers.py" "$K/opt/etc/bot/utils.py" \
    && ok "I4: py_compile handlers.py + utils.py" \
    || bad "I4: py_compile упал"
grep -q 'web INPUT DROP add/verify failed' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    && ok "I5: хук 100-redirect.sh на месте (правки аудита-18 его не касались)" \
    || bad "I5: хук неожиданно изменён"
# FB-43 (аудит-28): единственная правка хука в r54 — гейт кэша (_IPT_CAPABLE);
# всё прочее содержимое обязано совпадать с HEAD.
if git -C "$K" rev-parse --git-dir >/dev/null 2>&1; then
    I6D=$(git -C "$K" diff HEAD -- opt/etc/ndm/netfilter.d/100-redirect.sh \
        | grep -E '^[+-]' | grep -vE '^(\+\+\+|---)')
    I6N=$(printf '%s\n' "$I6D" | grep -c '^-')
    I6M=$(printf '%s\n' "$I6D" | grep -c '^+if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]')
    I6C=$(printf '%s\n' "$I6D" | grep -c '^+#')
    I6T=$(printf '%s\n' "$I6D" | grep -vcE '^(\+#|\+if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]|-if \[ -n "\$_KZ_HOOK_TMPDIR" \]; then$)')
    if [ -z "$I6D" ]; then
        ok "I6: хук не отличается от Git HEAD"
    elif [ "$I6N" = 1 ] && [ "$I6M" = 1 ] && [ "$I6T" = 0 ] && [ "$I6C" -ge 1 ]; then
        ok "I6: диф хука = только гейт кэша FB-43 (1 строка ужесточена, прочее = HEAD)"
    else
        bad "I6: неожиданный диф хука (n=$I6N m=$I6M c=$I6C t=$I6T)"
    fi
else
    ok "I6: [SKIP] git-раскладка — сверка с HEAD не требуется"
fi
grep -q 'safe_start_service "S99generator"' "$K/opt/bin/deploy_bypass.sh" \
    && grep -A3 'safe_start_service() {' "$K/opt/bin/deploy_bypass.sh" | grep -q '|| true' \
    && ok "I7: deploy не падает от SKIPPED (safe_start_service глотает rc)" \
    || bad "I7: контракт safe_start_service изменён"

echo "═══ R. Аудит-26: S57-гейт с портом, PID-личность, гейты/кэш/панель ═══"

# R0 (FB-23/K51-1/R51-01): заглушка сервера с ПОРТОМ и валидным auth
# тоже отсекается гейтом S57 (ранее example.com:443 проходил на старт).
RB="$F/rb"; mkdir -p "$RB"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$RB/gate.sh"
cat > "$RB/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/rb/gate.sh
echo "GATE_RC=PASS"
EOF
chmod +x "$RB/run.sh"
printf '{\n  "server": "example.com:443",\n  "auth": "realkey"\n}\n' > "$RB/p1.json"
printf '{\n  "server": "example.com:8443",\n  "auth": "realkey"\n}\n' > "$RB/p2.json"
printf '{\n  "server": "example.com",\n  "auth": "realkey"\n}\n' > "$RB/p3.json"
printf '{\n  "server": "",\n  "auth": "realkey"\n}\n' > "$RB/p4.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "realkey",\n  "tls": {"sni": "example.com"}\n}\n' > "$RB/p5.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "realkey"\n}\n' > "$RB/p6.json"
R0A=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" sh "$RB/run.sh" start 2>&1)
R0B=$(KEENZOO_HYSTERIA_CONFIG="$RB/p2.json" sh "$RB/run.sh" start 2>&1)
R0C=$(KEENZOO_HYSTERIA_CONFIG="$RB/p3.json" sh "$RB/run.sh" start 2>&1)
R0D=$(KEENZOO_HYSTERIA_CONFIG="$RB/p4.json" sh "$RB/run.sh" start 2>&1)
R0E=$(KEENZOO_HYSTERIA_CONFIG="$RB/p5.json" sh "$RB/run.sh" start 2>&1)
R0F=$(KEENZOO_HYSTERIA_CONFIG="$RB/p6.json" sh "$RB/run.sh" start 2>&1)
if printf '%s\n%s' "$R0A" "$R0B" | grep -q 'SKIPPED: hysteria не настроена' \
    && printf '%s\n%s' "$R0C" "$R0D" | grep -q 'SKIPPED: hysteria не настроена' \
    && ! printf '%s\n%s\n%s\n%s' "$R0A" "$R0B" "$R0C" "$R0D" | grep -q GATE_RC \
    && printf '%s' "$R0E" | grep -q GATE_RC=PASS \
    && printf '%s' "$R0F" | grep -q GATE_RC=PASS; then
    ok "R0: S57: example.com:443/:8443/без-порта/пустой + валидный auth → SKIPPED; SNI-маскировка и реальный → старт (K51-1/R51-01)"
else
    bad "R0: a=$(echo "$R0A" | tail -1) b=$(echo "$R0B" | tail -1) c=$(echo "$R0C" | tail -1) d=$(echo "$R0D" | tail -1) e=$(echo "$R0E" | tail -1) f=$(echo "$R0F" | tail -1)"
fi

# R1 (FB-25/K51-3/R51-03): pid-файл — только подсказка: сигнал только
# процессу, чей /proc/PID/cmdline относится к hysteria; сам pid-файл
# снимается при любом исходе; PID 0/мусор безопасны; stop не задет.
R1STATE(){ [ -r "/proc/$1/stat" ] && awk '{print $3}' "/proc/$1/stat" 2>/dev/null || echo X; }
RP="$F/rp"; mkdir -p "$RP"
# FB-48 (аудит-28, R53-05): личность процесса — по /proc/PID/exe, поэтому
# «свой» фейкуется РЕАЛЬНЫМ исполняемым файлом с именем hysteria (прежний
# скрипт-фейк имел exe=/bin/sh и по exe-признаку «своим» не является).
cp /bin/sleep "$RP/hysteria" 2>/dev/null \
    || cp /usr/bin/sleep "$RP/hysteria" 2>/dev/null \
    || cp "$(command -v sleep)" "$RP/hysteria"
chmod +x "$RP/hysteria"
# a) чужой живой процесс — не тронут, pid снят
sleep 60 & R1P1=$!
printf '%s\n' "$R1P1" > "$RP/pid"
R1A=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
R1A1=$(R1STATE "$R1P1"); [ -e "$RP/pid" ] && R1A2=present || R1A2=removed
kill "$R1P1" 2>/dev/null; wait "$R1P1" 2>/dev/null
# b) свой процесс (exe = .../hysteria) — снят с «Stopping»
"$RP/hysteria" 600 & R1P2=$!
sleep 1
printf '%s\n' "$R1P2" > "$RP/pid"
R1B=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
sleep 1
R1B1=$(R1STATE "$R1P2"); [ -e "$RP/pid" ] && R1B2=present || R1B2=removed
wait "$R1P2" 2>/dev/null
# b2) чужой процесс с подстрокой hysteria в argv, но чужим exe —
#     НЕ убит (FB-48: прежний матч *hysteria* по cmdline убивал бы его)
bash -c 'exec -a hysteria-marker sleep 60' & R1P3=$!
sleep 1
printf '%s\n' "$R1P3" > "$RP/pid"
R1F=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
R1F1=$(R1STATE "$R1P3")
kill "$R1P3" 2>/dev/null; wait "$R1P3" 2>/dev/null
# c) PID 0 (kill 0 = process-group) и d) мусорный PID — никто не тронут
printf '0\n' > "$RP/pid"
R1C=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1); R1C1=$?
[ -e "$RP/pid" ] && R1C2=present || R1C2=removed
printf '999999999\n' > "$RP/pid"
R1D=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1); R1D1=$?
[ -e "$RP/pid" ] && R1D2=present || R1D2=removed
# e) stop не задет гейтом
R1E=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" sh "$RB/run.sh" stop 2>&1)
if [ "$R1A1" != Z ] && [ "$R1A1" != X ] && [ "$R1A2" = removed ] \
    && { [ "$R1B1" = Z ] || [ "$R1B1" = X ]; } && [ "$R1B2" = removed ] \
    && printf '%s' "$R1B" | grep -q 'Stopping hysteria' \
    && [ "$R1F1" != Z ] && [ "$R1F1" != X ] \
    && [ "$R1C1" = 0 ] && [ "$R1C2" = removed ] \
    && [ "$R1D1" = 0 ] && [ "$R1D2" = removed ] \
    && printf '%s' "$R1E" | grep -q GATE_RC=PASS; then
    ok "R1: S57 PID: чужой жив+pid снят; свой (exe) снят с «Stopping»; argv-подстрока чужого не убита; 0/мусор безопасны; stop цел (K51-3/R51-03+FB-48)"
else
    bad "R1: a1=$R1A1/$R1A2 b1=$R1B1/$R1B2 f1=$R1F1 c=$R1C1/$R1C2 d=$R1D1/$R1D2 e=$(echo "$R1E" | tail -1)"
fi

# R2 (FB-24/R51-02): HTTP-гейт — обе копии, 6 форм opkg.conf.
RG="$F/rg"; mkdir -p "$RG"
awk '/^_kz_http_feed_active\(\) \{/,/^\}$/' "$DEP" > "$RG/dep.sh"
awk '/^_kz_http_install_gate\(\) \{/,/^\}$/' "$DEP" >> "$RG/dep.sh"
awk '/^_upd_http_feed_active\(\) \{/,/^\}$/' "$K/opt/bin/update_protocols.sh" > "$RG/upd.sh"
awk '/^_upd_http_install_gate\(\) \{/,/^\}$/' "$K/opt/bin/update_protocols.sh" >> "$RG/upd.sh"
printf 'src/gz entware http://bin.entware.net/x\n' > "$RG/plain"
printf '   src/gz entware http://bin.entware.net/x\n' > "$RG/lead"
printf 'src/gz "entware" "http://bin.entware.net/x"\n' > "$RG/quoted"
printf '\t src "entware" http://bin.entware.net/x\n' > "$RG/mixed"
printf 'src/gz entware https://bin.entware.net/x\n' > "$RG/https"
cat > "$RG/depdrv.sh" <<'EOF'
#!/bin/sh
warn(){ echo "WARN: $*"; }
. /tmp/f47chk/rg/dep.sh
KZ_DEPLOY_OPKG_CONF="$1"; export KZ_DEPLOY_OPKG_CONF
_kz_http_install_gate testpkg; echo "rc=$?"
EOF
cat > "$RG/upddrv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/rg/upd.sh
KZ_DEPLOY_OPKG_CONF="$1"; export KZ_DEPLOY_OPKG_CONF
_upd_http_install_gate testpkg; echo "rc=$?"
EOF
chmod +x "$RG/depdrv.sh" "$RG/upddrv.sh"
R2RES=""
for cfg in plain lead quoted mixed https missing; do
    [ "$cfg" = missing ] && conf="$F/rg/no-such-file" || conf="$RG/$cfg"
    unset KEENZOO_ALLOW_HTTP_FEED
    D=$(sh "$RG/depdrv.sh" "$conf" 2>&1 | tail -1)
    U=$(sh "$RG/upddrv.sh" "$conf" 2>&1 | tail -1)
    case "$cfg" in
        https) EXP="rc=0|rc=0" ;;
        *) EXP="rc=1|rc=1" ;;
    esac
    R2RES="$R2RES $cfg=${D#rc=}/${U#rc=}"
    [ "$D|$U" = "$EXP" ] || R2BAD="$R2BAD $cfg"
done
unset KEENZOO_ALLOW_HTTP_FEED
R2M=$(sh "$RG/depdrv.sh" "$F/rg/no-such-file" 2>&1; sh "$RG/upddrv.sh" "$F/rg/no-such-file" 2>&1)
if [ -z "${R2BAD:-}" ] && printf '%s' "$R2M" | grep -q 'не читается'; then
    ok "R2: HTTP-гейт (deploy+updater): plain/lead/quoted/mixed → блок, https → rc0, missing → fail-closed warn (R51-02)"
else
    bad "R2:$R2RES bad=[$R2BAD] missing_warn=$(printf '%s' "$R2M" | grep -c 'не читается')"
fi

# R3 (FB-26/K51-2): мемоизация opkg list-installed.
RM="$F/rm"; mkdir -p "$RM/bin"
awk '/^_kz_pkg_installed\(\) \{/,/^\}$/' "$DEP" > "$RM/fns.sh"
awk '/^_kz_pkg_cache_note\(\) \{/,/^\}$/' "$DEP" >> "$RM/fns.sh"
cat > "$RM/bin/opkg" <<'EOF'
#!/bin/sh
echo "opkg-call $*" >> /tmp/f47chk/rm/opkg.log
printf 'tor - 0.1\nxray - 1.0\n'
exit 0
EOF
chmod +x "$RM/bin/opkg"
cat > "$RM/drv.sh" <<'EOF'
#!/bin/sh
PATH="/tmp/f47chk/rm/bin:$PATH"; export PATH
. /tmp/f47chk/rm/fns.sh
_kz_pkg_installed tor; echo "tor=$?"
_kz_pkg_installed xray; echo "xray=$?"
_kz_pkg_installed tor; echo "tor2=$?"
_kz_pkg_installed dnsmasq-full; echo "dns=$?"
_kz_pkg_cache_note dnsmasq-full
_kz_pkg_installed dnsmasq-full; echo "dns2=$?"
EOF
R3OUT=$(sh "$RM/drv.sh" 2>&1)
R3N=$(wc -l < "$RM/opkg.log" 2>/dev/null || echo 0)
if printf '%s' "$R3OUT" | grep -q 'tor=0' && printf '%s' "$R3OUT" | grep -q 'xray=0' \
    && printf '%s' "$R3OUT" | grep -q 'tor2=0' && printf '%s' "$R3OUT" | grep -q 'dns=1' \
    && printf '%s' "$R3OUT" | grep -q 'dns2=0' && [ "$R3N" = 1 ]; then
    ok "R3: мемоизация: 6 проверок → 1 вызов opkg list-installed; cache_note виден (K51-2)"
else
    bad "R3: out=$(echo "$R3OUT" | tr '\n' ' ') calls=$R3N"
fi

# R4 (FB-28/R51-07): порог тела для вердикта Range — ≤256 Б.
RR="$F/rr"; mkdir -p "$RR/bin" "$RR/dl"
awk '/^_entware_probe_feed_url\(\) \{/,/^\}$/' "$DEP" > "$RR/fn.sh"
cat > "$RR/drv.sh" <<'EOF'
#!/bin/sh
PATH="/tmp/f47chk/rr/bin:/bin:/usr/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/rr/dl; export KEENZOO_DLTMP
DL_CMD=curl; export DL_CMD
have_cmd(){ command -v "$1" >/dev/null 2>&1; }
warn(){ :; }
ensure_dns(){ :; }
. /tmp/f47chk/rr/fn.sh
_entware_probe_feed_url "https://bin.entware.net/armv7sf-k3.2/Packages.gz"
echo "rc=$? note=${_EPF_NOTE}"
EOF
R4R=""; R4BAD=""
for sz in 256 1000; do
    printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c %s /dev/zero > "$2"; shift; done\nexit 0\n' "$sz" > "$RR/bin/curl"
    chmod +x "$RR/bin/curl"
    OUT=$(sh "$RR/drv.sh" 2>&1)
    R4R="$R4R [$sz] $(echo "$OUT" | tail -1)"
    if [ "$sz" = 256 ]; then
        echo "$OUT" | grep -q 'range' || R4BAD="$R4BAD $sz"
    else
        echo "$OUT" | grep -q 'полная загрузка' || R4BAD="$R4BAD $sz"
    fi
done
if [ -z "$R4BAD" ]; then
    ok "R4: Range-проба: 256Б → range-вердикт, 1000Б → полная загрузка (R51-07)"
else
    bad "R4:$R4R bad=[$R4BAD]"
fi

# R5 (FB-29/R51-05): SKIPPED_HTTP — сбор со всех гейтов шага, сводка в конце.
R5A=$(grep -c '^SKIPPED_HTTP=""$' "$DEP")
R5B=$(grep -cE '_kz_skip_note (ca-bundle|curl|"\$pkg"|webtunnel-client|python3-requests|dnsmasq-full)' "$DEP")
R5I=$(grep -n '^SKIPPED_HTTP=""$' "$DEP" | head -1 | cut -d: -f1)
R5L=$(grep -nE '_kz_skip_note (ca-bundle|curl|"\$pkg"|webtunnel-client|python3-requests|dnsmasq-full)' "$DEP" | tail -1 | cut -d: -f1)
R5S=$(grep -n 'Пакеты не установлены из-за HTTP-политики' "$DEP" | head -1 | cut -d: -f1)
if [ "$R5A" = 1 ] && [ "$R5B" = 6 ] && [ -n "$R5I" ] && [ -n "$R5L" ] && [ -n "$R5S" ] \
    && [ "$R5I" -lt "$R5L" ] && [ "$R5L" -lt "$R5S" ]; then
    ok "R5: SKIPPED_HTTP: 6 точек сбора (_kz_skip_note, дедуп FB-57), сводка после последней (dnsmasq-full) (R51-05)"
else
    bad "R5: init=$R5A points=$R5B i=$R5I last=$R5L summary=$R5S"
fi

# R6 (FB-31/R51-06): example.com в sni/serverName/peer_name — не заглушка.
RN="$F/rn"; mkdir -p "$RN"
awk '/^needs_key\(\) \{/,/^\}$/' "$DEP" > "$RN/nk.sh"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k",\n  "tls": {"sni": "example.com"}\n}\n' > "$RN/sni.json"
printf '{\n  "server": "example.com:443",\n  "auth": "k"\n}\n' > "$RN/stub.json"
cat > "$RN/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/rn/nk.sh
needs_key /tmp/f47chk/rn/sni.json; echo "sni=$?"
needs_key /tmp/f47chk/rn/stub.json; echo "stub=$?"
EOF
R6OUT=$(sh "$RN/drv.sh" 2>&1)
R6GREP=$(grep -c '_SNI_VALUE_RE' "$K/opt/etc/bot/utils.py" || true)
if printf '%s' "$R6OUT" | grep -q 'sni=1' && printf '%s' "$R6OUT" | grep -q 'stub=0' \
    && [ "$R6GREP" -ge 1 ]; then
    ok "R6: needs_key: SNI-маскировка не «заглушка», server-stub — заглушка; _SNI_VALUE_RE в utils (R51-06+FB-36)"
else
    bad "R6: out=$(echo "$R6OUT" | tr '\n' ' ') utils_re=$R6GREP"
fi

# R7 (FB-32/R50-UX-1): CFG_STATE несёт web_username; баннер — фактическое имя.
RQ="$F/rq"; mkdir -p "$RQ"
sed -n "/^CFG_STATE=\"\$(python3 -/,/^PYEOF$/p" "$DEP" | sed '1d;$d' | sed "s|'/opt/etc/bot'|'$RQ'|" > "$RQ/cfgstate.py"
printf 'token = "X"\nallowed_user_ids = [1]\nweb_password = "Y"\n' > "$RQ/bot_config.py"
R7A=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
printf 'web_username = "ivan"\n' >> "$RQ/bot_config.py"
R7B=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
# FB-49 (аудит-28, R53-10): баннер — ветка if/else (пустое имя = «панель
# не настроена», семантика S99/CFG_STATE), а не молчаливый «admin».
sed -n "/^_panel_user=\"\$(grep/,/^fi$/p" "$DEP" | sed "s|/opt/etc/bot/bot_config.py|$RQ/bot_config.py|" > "$RQ/banner.sh"
R7C=$(sh "$RQ/banner.sh" 2>/dev/null)
sed -i 's/^web_username.*/web_username = ""/' "$RQ/bot_config.py"
R7D=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
R7E=$(grep -c '\[ "\${4:-empty}" = "ok" \] || NEED_CONFIG=1' "$DEP" || true)
R7F=$(sh "$RQ/banner.sh" 2>/dev/null)
if [ "$R7A" = "ok ok ok empty" ] && [ "$R7B" = "ok ok ok ok" ] && [ "$R7D" = "ok ok ok empty" ] \
    && printf '%s' "$R7C" | grep -q '(ivan,' \
    && printf '%s' "$R7F" | grep -q 'панель не настроена: web_username пуст' \
    && [ "$R7E" = 1 ]; then
    ok "R7: CFG_STATE 4-й токен web_username; баннер: имя или «панель не настроена» (R50-UX-1+FB-49)"
else
    bad "R7: a=[$R7A] b=[$R7B] d=[$R7D] ivan=[$R7C] empty=[$R7F] tok4=$R7E"
fi

# R8+R9+R10 (FB-30/FB-33/N51-1): панель — если flask доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/r8.out" 2>&1 <<'PYR8'
import sys, time, threading
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g

# R8 (FB-30/N51-2): lock + повторная проверка; конкурентный шторм → 3 форка.
lock_ok = ('_LAN_HOSTS_LOCK = threading.Lock()' in open(
    sys.argv[1] + '/opt/etc/bot/generator.py', encoding='utf-8').read())
calls = {'n': 0}
class _R:
    def __init__(self, out): self.stdout = out
class _SP:
    TimeoutExpired = Exception
    def run(self, args, **kw):
        calls['n'] += 1; time.sleep(0.05)
        return _R('    inet 192.168.1.1/24 brd x br0\n')
g.subprocess = _SP()
g._LAN_HOSTS_CACHE['ts'] = 0.0
for _ in range(8):
    threading.Thread(target=lambda: g._lan_host_addresses()).start()
while threading.active_count() > 1:
    time.sleep(0.02)
print('R8 %s forks=%d' % ('OK' if lock_ok and calls['n'] == 3 else 'BAD',
                          calls['n']))

# R9 (FB-33): _auth_cmp — модульное сравнение, не-ASCII не роняет.
try:
    r9 = (g._auth_cmp('a', 'a') is True and g._auth_cmp('a', 'b') is False
          and g._auth_cmp('пароль', 'пароль') is True)
    print('R9 %s' % ('OK' if r9 else 'BAD'))
except Exception as e:
    print('R9 BAD %s' % e)

# R10 (N51-1): cross-list warning; маршрут на api_lookup_add; декораторы целы.
lines = open(sys.argv[1] + '/opt/etc/bot/generator.py',
             encoding='utf-8').read().split('\n')
bad_dec = []
for i, l in enumerate(lines):
    if l.strip().startswith('@app.route'):
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines) or not lines[j].startswith('def '):
            bad_dec.append(i + 1)
g.config.web_username = 'admin'; g.config.web_password = 'testpass'
g.config.list_files = {'vless': '/tmp/f47chk/rl_vless.txt',
                       'hysteria': '/tmp/f47chk/rl_hy.txt',
                       'bot': '/tmp/f47chk/rl_bot.txt'}
open('/tmp/f47chk/rl_vless.txt', 'w').write('crossdup.example\n')
open('/tmp/f47chk/rl_hy.txt', 'w').write('')
c = g.app.test_client()
TOK = 'a' * 64
with c.session_transaction() as s:
    s['csrf_token'] = TOK
r = c.post('/api/lookup-add', headers={'Origin': 'http://127.0.0.1'},
           auth=('admin', 'testpass'),
           data={'list': 'hysteria', 'entries': 'crossdup.example',
                 'csrf_token': TOK})
b = r.get_json() or {}
r3 = c.post('/api/lookup-add', headers={'Origin': 'http://127.0.0.1'},
            auth=('admin', 'testpass'),
            data={'list': 'hysteria', 'entries': 'fresh.example',
                  'csrf_token': TOK})
b3 = r3.get_json() or {}
r2 = c.post('/api/lookup-add', headers={'Origin': 'http://evil.example'},
            auth=('admin', 'testpass'),
            data={'list': 'hysteria', 'entries': 'x.example',
                  'csrf_token': TOK})
ok10 = (not bad_dec and r.status_code == 200 and b.get('added') == ['crossdup.example']
        and 'vless' in (b.get('warning') or '')
        and r3.status_code == 200 and 'warning' not in b3
        and r2.status_code == 403)
print('R10 %s status=%s warn=%s fresh=%s evil=%s dec=%s' % (
    'OK' if ok10 else 'BAD', r.status_code,
    'vless' in (b.get('warning') or ''), 'warning' not in b3,
    r2.status_code, bad_dec))
PYR8
    grep -q '^R8 OK' "$F/r8.out" \
        && ok "R8: LAN-кэш под lock; 8 потоков → 3 форка (N51-2)" \
        || bad "R8: $(grep '^R8' "$F/r8.out")"
    grep -q '^R9 OK' "$F/r8.out" \
        && ok "R9: _auth_cmp модульная, ASCII/не-ASCII (FB-33)" \
        || bad "R9: $(grep '^R9' "$F/r8.out")"
    grep -q '^R10 OK' "$F/r8.out" \
        && ok "R10: N51-1: cross-list warning в ответе; свежие — без warning; чужой Origin 403; все @app.route ведут на def (маршрут lookup-add цел)" \
        || bad "R10: $(grep '^R10' "$F/r8.out")"
else
    echo "[SKIP] R8/R9/R10: Flask-смоук — flask не установлен на хосте"
fi

# R11 (FB-27/R50-FW-1): benchmark-диапазон в matcher снятия ACCEPT.
R11A=$(grep -c '198\.1\[89\]\.\*' "$DEP" || true)
[ "$R11A" -ge 1 ] \
    && ok "R11: 198.18.0.0/15 в matcher проектных ACCEPT (R50-FW-1)" \
    || bad "R11: matcher=[$R11A]"

# R12 (FB-34/N51-2): wget-ветка tg_send_message предупреждает про argv.
R12A=$(grep -c 'токен кратко виден в argv' "$K/opt/bin/common.sh" || true)
[ "$R12A" -ge 1 ] \
    && ok "R12: warn в wget-ветке tg_send_message (FB-34)" \
    || bad "R12: warn=[$R12A]"

# R13: маркеры правок аудита-26 на местах (карта «маркер → файл»).
R13B=""
for m in FB-24 FB-26 FB-27 FB-28 FB-29 FB-31 FB-32; do
    grep -q "$m (аудит-26" "$DEP" || R13B="$R13B $m(dep)"
done
grep -q 'FB-24 (аудит-26' "$K/opt/bin/update_protocols.sh" || R13B="$R13B FB-24(upd)"
grep -q 'FB-23 (аудит-26' "$S57" || R13B="$R13B FB-23(S57)"
grep -q 'FB-25 (аудит-26' "$S57" || R13B="$R13B FB-25(S57)"
grep -q 'FB-30 (аудит-26' "$GEN" || R13B="$R13B FB-30(gen)"
grep -q 'FB-33 (аудит-26' "$GEN" || R13B="$R13B FB-33(gen)"
grep -q 'N51-1 (аудит-26' "$GEN" || R13B="$R13B N51-1(gen)"
grep -q 'FB-31 (аудит-26' "$K/opt/etc/bot/utils.py" || R13B="$R13B FB-31(utils)"
grep -q 'FB-34 (аудит-26' "$K/opt/bin/common.sh" || R13B="$R13B FB-34(common)"
if [ -z "$R13B" ]; then
    ok "R13: маркеры FB-23..FB-34 + N51-1 во всех правленых файлах"
else
    bad "R13: отсутствуют:[$R13B]"
fi

echo "═══ S. Аудит-27: проба iptables, детекторы заглушек, честные вердикты ═══"

# S0 (FB-35/K52-7): справка --help не доказывает вставку — проба правилом.
SB="$F/sb"; mkdir -p "$SB/bin"
for fn in ipt_has_target ipt_has_match ipt_is_capable _ipt_probe_ok _ipt_candidate_ok; do
    awk -v f="$fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$SB/fns.sh"
    echo >> "$SB/fns.sh"
done
dash -n "$SB/fns.sh" || { bad "S0: экстракция проб-функций невалидна"; }
cat > "$SB/bin/ipset" <<EOF
#!/bin/sh
echo "ipset \$*" >> "$SB/ipset.log"
exit 0
EOF
cat > "$SB/bin/iptables.good" <<EOF
#!/bin/sh
echo "ipt \$*" >> "$SB/ipt.log"
case "\$1 \$2" in
  "-j TPROXY") echo "TPROXY target options:"; echo "  --on-port port"; exit 0;;
  "-m set") echo "set match options:"; exit 0;;
esac
exit 0
EOF
cat > "$SB/bin/iptables.nft" <<'EOF'
#!/bin/sh
# «nft-подобный»: справку печатает (юзерспейс-плагин), вставку — нет
case "$1 $2" in
  "-j TPROXY") echo "TPROXY target options:"; echo "  --on-port port"; exit 0;;
  "-m set") echo "set match options:"; exit 0;;
esac
case " $* " in
  *" -I "*) echo "Warning: Extension TPROXY revision 0 not supported, missing kernel module?" >&2
            echo "iptables v1.8.11 (nf_tables): RULE_APPEND failed" >&2; exit 4;;
esac
exit 0
EOF
chmod +x "$SB/bin/"*
# a) нет ipset → rc 2 (доверяем справке — холодная установка не ломается)
S0A=$(env -i PATH=/usr/bin:/bin sh -c ". '$SB/fns.sh'; _ipt_probe_ok '$SB/bin/iptables.good'; echo \$?" 2>/dev/null)
# b) рабочий бинарник → кандидат rc 0; вставка/удаление и create/destroy парны
: > "$SB/ipt.log"; : > "$SB/ipset.log"
S0B=$(PATH="$SB/bin:/usr/bin:/bin" sh -c ". '$SB/fns.sh'; _ipt_candidate_ok '$SB/bin/iptables.good'; echo \$?" 2>/dev/null)
S0BI=$(grep -c ' -I ' "$SB/ipt.log" || true)
S0BD=$(grep -c ' -D ' "$SB/ipt.log" || true)
S0BC=$(grep -c ' create ' "$SB/ipset.log" || true)
S0BX=$(grep -c ' destroy ' "$SB/ipset.log" || true)
# c) nft-подобный (справка проходит!) → кандидат rc 1 — отвергнут пробой
S0C=$(PATH="$SB/bin:/usr/bin:/bin" sh -c ". '$SB/fns.sh'; _ipt_candidate_ok '$SB/bin/iptables.nft'; echo \$?" 2>/dev/null)
# d) гейт кандидата стоит на всех точках выбора (deploy 5, хук 4) и в хуке есть проба
S0D=$(grep -c '_ipt_candidate_ok "$_c"' "$DEP" || true)
S0E=$(grep -c '_ipt_candidate_ok "$_c"' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || true)
S0F=$(grep -c '^_ipt_probe_ok() {' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || true)
if [ "$S0A" = 2 ] && [ "$S0B" = 0 ] && [ "$S0C" = 1 ] \
    && [ "$S0BI" = "$S0BD" ] && [ "$S0BI" -ge 1 ] && [ "$S0BC" = "$S0BX" ] \
    && [ "$S0D" = 5 ] && [ "$S0E" = 4 ] && [ "$S0F" = 1 ]; then
    ok "S0: проба iptables: без ipset rc2; рабочий rc0 (вставка/удаление парны); nft-подобный rc1; гейт на 5+4 точках, проба в хуке (K52-7)"
else
    bad "S0: a=$S0A b=$S0B c=$S0C i/d=$S0BI/$S0BD c/x=$S0BC/$S0BX sites=$S0D/$S0E hookprobe=$S0F"
fi

# S1 (FB-36/K52-1): минифицированный JSON — значение поля, а не строка.
SC="$F/sc"; mkdir -p "$SC"
# FB-95 (аудит-36): needs_key зовёт _nk_root_val (lazy-хелпер)
awk 'index($0, "_nk_root_val() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$SC/nk.sh"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$SC/nk.sh"
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$SC/nk.sh"
cat > "$SC/mk.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/sc/nk.sh
i=0; fail=0
t(){ i=$((i+1)); printf '%s' "$2" > /tmp/f47chk/sc/c$i.json
     needs_key /tmp/f47chk/sc/c$i.json; r=$?
     [ "$r" = "$3" ] || { echo "case$i($1):rc=$r,want=$3"; fail=1; } }
t 'mini-stub+mask'  '{"server":"example.com:443","auth":"s3cret","tls":{"sni":"vpn.example.org"}}' 0
t 'mini-stub'       '{"server":"example.com","auth":"s3cret"}' 0
t 'mini-empty-srv'  '{"server":"","auth":"s3cret"}' 0
t 'mini-empty-addr' '{"address":"","password":"x"}' 0
t 'multi-stub'      '{
 "server": "example.com:443",
 "auth": "s3cret",
 "tls": {"sni": "vpn.example.org"}
}' 0
t 'multi-stub2'     '{
 "server": "example.com",
 "auth": "k"
}' 0
t 'mini-real+mask'  '{"server":"real.example.org:443","auth":"k","tls":{"sni":"example.com"}}' 1
t 'multi-real+mask' '{
 "server": "real.example.org:443",
 "auth": "k",
 "tls": {"sni": "example.com"}
}' 1
t 'mini-serverName' '{"server":"real.example.org:443","auth":"k","transport":{"tls":{"serverName":"example.com"}}}' 1
t 'mini-sni-clean'  '{"server":"real.example.org:443","auth":"k","tls":{"sni":"ex-ample.com"}}' 1
# FB-89: маркеры — только в полях-ключах address|server|remote_addr|auth;
t 'mini-CHANGE_ME'  '{"password":"CHANGE_ME"}' 1
t 'mini-zero-uuid'  '{"server":"real.example.org:443","uuid":"00000000-0000-0000-0000-000000000000"}' 1
echo "fail=$fail"
EOF
chmod +x "$SC/mk.sh"
S1S=$(sh "$SC/mk.sh" 2>/dev/null | tail -1)
python3 - "$K" > "$F/s1py.out" 2>&1 <<'PYS1'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import importlib.util
spec = importlib.util.spec_from_file_location('u27', sys.argv[1] + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
# FB-89: кейсы 11/12 — заглушки вне полей-ключей более не
# блокируют конфиг (точечный матч значений полей) — паритет с
# needs_key/S57/preflight, которые password/uuid не смотрят
cases = [(1, True), (2, True), (3, True), (4, True), (5, True), (6, True),
         (7, False), (8, False), (9, False), (10, False), (11, False), (12, False)]
bad = []
for i, want in cases:
    got = u.config_has_placeholders(f'/tmp/f47chk/sc/c{i}.json')
    if got != want:
        bad.append(i)
print('OK' if not bad else 'BAD %r' % bad)
PYS1
if [ "$S1S" = "fail=0" ] && grep -q '^OK$' "$F/s1py.out"; then
    ok "S1: needs_key+utils: 12 кейсов мини/мульти — заглушка в server видна, sni/serverName/peer_name-маскировка чиста; password/uuid-маркеры вне полей-ключей не блокируют (K52-1+FB-89)"
else
    bad "S1: shell=[$S1S] py=$(cat "$F/s1py.out")"
fi

# S2 (FB-37/K52-4): dnsmasq — честный вердикт при отсутствии бинарника.
SD="$F/sd"; mkdir -p "$SD/bin"
awk '/^DNSMASQ_IPSET_OK=0$/{f=1} f{print} /dnsmasq с поддержкой ipset/{if(f)exit}' "$DEP" > "$SD/blk.sh"
{ echo 'warn(){ echo "WARN: $*"; }'
  echo 'have_cmd(){ command -v "$1" >/dev/null 2>&1; }'
  echo '_kz_http_install_gate(){ return 1; }'
  echo '_kz_pkg_cache_note(){ :; }'
  echo 'SKIPPED_HTTP=""'
  cat "$SD/blk.sh"; } > "$SD/run.sh"
printf '#!/bin/sh\necho "dnsmasq 2.90"\n' > "$SD/bin/dnsmasq.ok"; chmod +x "$SD/bin/dnsmasq.ok"
printf '#!/bin/sh\necho "dnsmasq 2.90 (no-ipset)"\n' > "$SD/bin/dnsmasq.noip"; chmod +x "$SD/bin/dnsmasq.noip"
ln -sf "$SD/bin/dnsmasq.ok" "$SD/bin/dnsmasq"
S2A=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
ln -sf "$SD/bin/dnsmasq.noip" "$SD/bin/dnsmasq"
S2B=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
rm -f "$SD/bin/dnsmasq"
S2C=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
if printf '%s' "$S2A" | grep -q '✅ dnsmasq с поддержкой ipset' \
    && ! printf '%s' "$S2B" | grep -q '✅' \
    && printf '%s' "$S2B" | grep -q 'БЕЗ ipset' \
    && ! printf '%s' "$S2C" | grep -q '✅' \
    && printf '%s' "$S2C" | grep -q 'не найден в PATH'; then
    ok "S2: dnsmasq: есть+ipset → ✅; no-ipset → warn без ✅; отсутствует → warn без ✅ (K52-4)"
else
    bad "S2: a=$(echo "$S2A" | head -1) b=$(echo "$S2B" | grep -c WARN) c=$(echo "$S2C" | head -1)"
fi

# S3 (FB-38/K52-3): JS addToList показывает warning из ответа.
S3A=$(grep -c "j.warning?' \\\\u26A0 '+j.warning:''" "$GEN" || true)
[ "$S3A" = 1 ] \
    && ok "S3: addToList: warning отображается (JS-ветка на месте) (K52-3)" \
    || bad "S3: js_branch=$S3A"

# S4 (FB-40/K52-5): единственный opkg list-installed — внутри мемоизации.
# только код: комментарий FB-40 тоже упоминает opkg list-installed
S4A=$(grep -v '^[[:space:]]*#' "$DEP" | grep -c 'opkg list-installed' || true)
[ "$S4A" = 1 ] \
    && ok "S4: opkg list-installed ×1 (мемоизация; ветки iptables закрыты) (K52-5)" \
    || bad "S4: calls=$S4A"

# S5 (FB-41/N52-8): check_updates — tty печатает, не-tty молчит.
SE="$F/se"; mkdir -p "$SE"
awk '/# ── Уведомление ──/{f=1} f{print}' "$K/opt/bin/check_updates.sh" > "$SE/tail.sh"
{ echo 'HAS_UPDATES=true'
  echo 'ARCH=x64'
  echo 'MSG="🆕 <b>Обновления (x64):</b>"'
  echo 'send_telegram(){ echo "TG" >> "'"$SE"'/tg.log"; }'
  cat "$SE/tail.sh"; } > "$SE/drv.sh"
dash -n "$SE/drv.sh" || bad "S5: драйвер невалиден"
rm -f "$SE/tg.log"; sh "$SE/drv.sh" > "$SE/notty.out" 2>/dev/null
S5A=$(wc -c < "$SE/notty.out" | tr -d ' ')
S5B=$([ -f "$SE/tg.log" ] && echo tg || echo notg)
if command -v script >/dev/null 2>&1; then
    S5C=$(script -qec "sh '$SE/drv.sh'" /dev/null 2>/dev/null | tr -d '\r' | grep -c 'Обновления (x64)')
else
    S5C=1  # pty-утилита недоступна — проверяем только не-tty ветку
fi
if [ "$S5A" = 0 ] && [ "$S5B" = tg ] && [ "$S5C" = 1 ]; then
    ok "S5: check_updates: не-tty молчит (Telegram вызван); tty печатает без HTML-тегов (N52-8)"
else
    bad "S5: notty_bytes=$S5A tg=$S5B tty=$S5C"
fi

# S6 (FB-39/K52-6): снимок списков — по Flask, если доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/s6.out" 2>&1 <<'PYS6'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g
g.config.list_files = {n: f'/tmp/f47chk/sf_{n}.txt' for n in
                       ('shadowsocks', 'vless', 'trojan', 'hysteria', 'tor', 'bot')}
for n in g.config.list_files:
    open(g.config.list_files[n], 'w').write(
        '\n'.join(f'd{i}.example' for i in range(500)) + '\n')
calls = {'n': 0}
orig = g.read_file_text
def counting(p):
    calls['n'] += 1
    return orig(p)
g.read_file_text = counting
_cls = g._cross_list_sources('hysteria')
snap_reads = calls['n']
cross = [e for e in (f'd{i}.example' for i in range(100))
         for name, entries in _cls.items() if e in entries]
calls['n'] = 0
wrap = g._cross_list_hint('d0.example', 'hysteria')
ok6 = (snap_reads == 4 and calls['n'] == 4 and len(cross) == 400
       and wrap == ['shadowsocks', 'vless', 'trojan', 'tor'])
print('OK snap=%d wrap_reads=%d cross=%d' % (snap_reads, calls['n'], len(cross))
      if ok6 else 'BAD snap=%d wrap_reads=%d cross=%d wrap=%s' % (
          snap_reads, calls['n'], len(cross), wrap))
PYS6
    grep -q '^OK ' "$F/s6.out" \
        && ok "S6: cross-list: 100 записей → 4 чтения (снимок), предупреждения те же; обёртка жива (K52-6)" \
        || bad "S6: $(cat "$F/s6.out")"
else
    echo "[SKIP] S6: Flask-смоук — flask не установлен на хосте"
fi

# S7: маркеры правок аудита-27 на местах.
S7B=""
for m in FB-35 FB-36 FB-37 FB-40; do
    grep -q "$m (аудит-27" "$DEP" || S7B="$S7B $m(dep)"
done
grep -q 'FB-35 (аудит-27' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || S7B="$S7B FB-35(hook)"
grep -q 'FB-36 (аудит-27' "$K/opt/etc/bot/utils.py" || S7B="$S7B FB-36(utils)"
grep -q 'FB-38' "$GEN" || S7B="$S7B FB-38(gen)"
grep -q 'FB-39' "$GEN" || S7B="$S7B FB-39(gen)"
grep -q 'FB-41 (аудит-27' "$K/opt/bin/check_updates.sh" || S7B="$S7B FB-41(cu)"
if [ -z "$S7B" ]; then
    ok "S7: маркеры FB-35..FB-41 во всех правленых файлах (deploy, хук, utils, generator, check_updates)"
else
    bad "S7: отсутствуют:[$S7B]"
fi

# ═══ T. Аудит-28: регресс JS, HTTP-гейт, вердикт пробы, паритет валидаторов ═══
echo "═══ T. Аудит-28 (r53): JS, гейт 11 форм, |0-вердикт, валидаторы, лимиты ═══"

# T0 (FB-42/R53-01): регресс JS — рендер + node --check каждого блока.
if python3 -c 'import flask' >/dev/null 2>&1 \
    && command -v node >/dev/null 2>&1; then
    python3 - "$K" > "$F/t0.out" 2>&1 <<'PYT0'
import sys, re, subprocess, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
html = c.get('/', auth=('a', 'b')).data.decode()
blocks = re.findall(r'<script[^>]*>(.*?)</script>', html, re.S)
assert blocks, 'нет script-блоков'
for i, b in enumerate(blocks, 1):
    p = f'/tmp/f47chk/t0js{i}.js'
    open(p, 'w').write(b)
    r = subprocess.run(['node', '--check', p], capture_output=True)
    assert r.returncode == 0, 'блок %d: %s' % (
        i, r.stderr.decode()[-140:])
print('OK blocks=%d' % len(blocks))
PYT0
    if grep -q '^OK' "$F/t0.out"; then
        ok "T0: все inline <script> панели валидны (node --check) — регресс FB-38 пойман и закрыт (R53-01)"
    else
        bad "T0: $(tail -1 "$F/t0.out")"
    fi
else
    if ! grep -Fq ":'')}}" "$GEN" && grep -Fq ":'')}" "$GEN"; then
        ok "T0: [частично, без flask/node] исходник addToList без лишней } (R53-01)"
    else
        bad "T0: паттерн регресса JS на месте (R53-01)"
    fi
fi

# T1 (FB-43/R53-03): модули ДО пробы; вердикт пробы — в решении deploy/хука.
T1B=""
_s2=$(grep -n '⏳ \[2/11\]' "$DEP" | head -1 | cut -d: -f1)
_lk=$(grep -n '^load_kmod() {' "$DEP" | head -1 | cut -d: -f1)
_pk=$(awk -v s="$_s2" 'NR>s && /_IPT_PICK="\$\(pick_iptables\)"/{print NR; exit}' "$DEP")
[ -n "$_lk" ] && [ "$_lk" -lt "$_pk" ] || T1B="$T1B load_kmod<pick"
awk -v s="$_s2" -v p="$_pk" 'NR>=s&&NR<p&&/for _dep in nf_defrag_ipv4/{f=1} END{exit !f}' "$DEP" \
    || T1B="$T1B mods-before-pick"
[ "$(grep -c 'if \[ "\$_IPT_CAPABLE" != 1 \]; then' "$DEP")" = 2 ] \
    || T1B="$T1B flag-accept"
grep -q '\[ "\${_ipt_re#\*|}" = 1 \]' "$DEP" || T1B="$T1B repick-flag"
grep -q 'пригодность не подтверждена (гейт справка+проба)' "$DEP" \
    || T1B="$T1B honest-verdict"
grep -q 'if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    || T1B="$T1B hook-cache-gate"
TB1="$F/t1"; mkdir -p "$TB1/bin"
cat > "$TB1/bin/iptables" <<'EOF'
#!/bin/sh
case "$*" in
    *--help*) echo "TPROXY target options:"; echo "set match options:"; exit 0 ;;
    *PREROUTING*) exit 4 ;;
esac
exit 0
EOF
cat > "$TB1/bin/ipset" <<'EOF'
#!/bin/sh
exit 0
EOF
chmod +x "$TB1/bin/iptables" "$TB1/bin/ipset"
for _fn in ipt_has_target ipt_has_match ipt_is_capable _ipt_probe_ok _ipt_candidate_ok pick_iptables; do
    awk -v f="$_fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$TB1/h.sh"
done
T1R=$(PATH="$TB1/bin:/usr/bin:/bin" sh -c ". '$TB1/h.sh'; pick_iptables" 2>/dev/null)
case "$T1R" in
    *'|0') : ;;
    *) T1B="$T1B nft-only[$T1R]" ;;
esac
if [ -z "$T1B" ]; then
    ok "T1: модули до пробы; решение по флагу (|0 ≠ ✅); кэш хука только для |1; nft-only pick → |0 (R53-03)"
else
    bad "T1:$T1B"
fi

# T2 (FB-44/R53-02): HTTP-гейт — 11 форм opkg.conf × обе копии.
T2D=""
extract_fn() { awk -v f="$1" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$2"; }
{ extract_fn _kz_http_feed_active "$DEP"; extract_fn _kz_http_install_gate "$DEP"; } > "$F/t2dep.sh"
{ extract_fn _upd_http_feed_active "$K/opt/bin/update_protocols.sh"; extract_fn _upd_http_install_gate "$K/opt/bin/update_protocols.sh"; } > "$F/t2upd.sh"
warn() { :; }
. "$F/t2dep.sh"
. "$F/t2upd.sh"
T2N=0
t2_case() { # $1=tag $2=content|@DIR|@MISS $3=ожидаемый rc гейта $4=dep|upd
    case "$2" in
        @DIR) rm -rf "$F/t2conf"; mkdir -p "$F/t2conf" ;;
        @MISS) rm -rf "$F/t2conf" ;;
        *) rm -rf "$F/t2conf"; printf '%s\n' "$2" > "$F/t2conf" ;;
    esac
    T2N=$((T2N+1))
    if [ "$4" = dep ]; then
        KZ_DEPLOY_OPKG_CONF="$F/t2conf" _kz_http_install_gate pkg
    else
        KZ_DEPLOY_OPKG_CONF="$F/t2conf" _upd_http_install_gate pkg
    fi
    [ $? = "$3" ] || T2D="$T2D $1-$4"
}
for _cp in dep upd; do
    t2_case srcgz_http 'src/gz entware http://foo/bar' 1 "$_cp"
    t2_case quoted_type '"src/gz" entware http://foo/bar' 1 "$_cp"
    t2_case quoted_all '"src/gz" "entware" "http://foo/bar"' 1 "$_cp"
    t2_case src_plain 'src entware http://foo/bar' 1 "$_cp"
    t2_case indent_q '   src/gz "entware" "http://foo/bar"' 1 "$_cp"
    t2_case dist_gz 'dist/gz feed http://foo/bar' 1 "$_cp"
    t2_case dist 'dist feed http://foo/bar' 1 "$_cp"
    t2_case directory @DIR 1 "$_cp"
    t2_case missing @MISS 1 "$_cp"
    t2_case https 'src/gz entware https://foo/bar' 0 "$_cp"
    t2_case commented '# src/gz entware http://foo/bar' 0 "$_cp"
done
if [ -z "$T2D" ]; then
    ok "T2: HTTP-гейт: 11 форм × deploy+update — 4 fail-open формы закрыты, https/комментарий свободны (R53-02)"
else
    bad "T2:$T2D (из $T2N)"
fi

# T3 (FB-45/R53-04): паритет 4 валидаторов hysteria на 8 конфигах.
T3="$F/t3"; mkdir -p "$T3/cfg"
T3BASE='"tcpRedirect": {"listen": "0.0.0.0:10830"}, "udpTProxy": {"listen": "0.0.0.0:10830"}'
printf '{ "server": "real.example.org:443", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c1.json"
printf '{ "server": "example.com:443", "auth": "realkey", "tls": {"sni": "example.com"}, %s }\n' "$T3BASE" > "$T3/cfg/c2.json"
printf '{ "server": "", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c3.json"
printf '{ "server": "real.example.org:443", "auth": "00000000-0000-0000-0000-000000000000", %s }\n' "$T3BASE" > "$T3/cfg/c4.json"
printf '{ "server": "real.example.org:443", "auth": "", %s }\n' "$T3BASE" > "$T3/cfg/c5.json"
printf '{ "server": "real.example.org:443", %s }\n' "$T3BASE" > "$T3/cfg/c6.json"
printf '{ "server": "real.example.org:443", "auth": "CHANGE_ME", %s }\n' "$T3BASE" > "$T3/cfg/c7.json"
printf '{ "server": "{{server}}:{{port}}", "auth": "{{auth}}", %s }\n' "$T3BASE" > "$T3/cfg/c8.json"
# FB-74 (аудит-33, K58-2/R58-05): c9 — sni-исключение (real server +
# sni=example.com → старт); c10 — нестроковый server; c11 — регистр;
# c12/c13 — конечная точка FQDN-формы (без порта и с портом).
printf '{ "server": "real.example.org:443", "auth": "realkey", "tls": {"sni": "example.com"}, %s }\n' "$T3BASE" > "$T3/cfg/c9.json"
printf '{ "server": 123, "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c10.json"
printf '{ "server": "EXAMPLE.com:443", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c11.json"
printf '{ "server": "example.com.", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c12.json"
printf '{ "server": "example.com.:443", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c13.json"
# FB-96/97/98 (аудит-36): c14 — auth-секрет с портом (валиден);
# c15 — дубликат корневого auth (fail-closed у всех); c16 — маркер
# через \u-эскейп (декодируется до точного совпадения).
printf '%s\n' '{ "server": "real.example.org:443", "auth": "change_me:443", '"$T3BASE"' }' > "$T3/cfg/c14.json"
printf '%s\n' '{ "server": "real.example.org:443", "auth": "a", "auth": "realkey", '"$T3BASE"' }' > "$T3/cfg/c15.json"
printf '%s\n' '{ "server": "real.example.org:443", "auth": "change\u005fme", '"$T3BASE"' }' > "$T3/cfg/c16.json"
T3S57="$T3/rb"; mkdir -p "$T3S57"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$T3S57/gate.sh"
cat > "$T3S57/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/t3/rb/gate.sh
echo "GATE_RC=PASS"
EOF
T3B=""
for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16; do
    awk 'index($0, "_nk_root_val() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$F/t3nk.sh"
    awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$F/t3nk.sh"
    awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$F/t3nk.sh"
    . "$F/t3nk.sh"
    # FB-54 (аудит-29, N54-2): флаг hysteria включает проверку
    # отсутствующего auth (без флага — xray/ss/trojan без поля auth
    # не считаются заглушками).
    needs_key "$T3/cfg/c$i.json" hysteria
    nk=$?
    s57out=$(KEENZOO_HYSTERIA_COMMON="$K/opt/bin/common.sh" KEENZOO_HYSTERIA_CONFIG="$T3/cfg/c$i.json" sh "$T3S57/run.sh" start 2>&1)
    if printf '%s' "$s57out" | grep -q SKIPPED; then s57=SKIP; else s57=START; fi
    case "$i:$nk:$s57" in
        1:1:START|2:0:SKIP|3:0:SKIP|4:0:SKIP|5:0:SKIP|6:0:SKIP|7:0:SKIP|8:0:SKIP|9:1:START|10:0:SKIP|11:0:SKIP|12:0:SKIP|13:0:SKIP|14:1:START|15:0:SKIP|16:0:SKIP) : ;;
        *) T3B="$T3B c$i(nk=$nk,s57=$s57)" ;;
    esac
done
python3 - "$K" > "$F/t3py.out" 2>&1 <<'PYT3'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('u', K + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
exp_ph = {1: False, 2: True, 3: True, 4: True, 5: True,
          6: True, 7: True, 8: True, 9: False, 10: True,
          11: True, 12: True, 13: True,
          14: False, 15: True, 16: True}
# FB-74 (аудит-33, K58-2): c2 (example.com:443 + реальный auth) —
# прежде preflight пропускал (закреплённый дефект), теперь rej;
# c9 — sni-исключение сохранено → ok.
exp_pf = {1: 'ok', 2: 'rej', 3: 'rej', 4: 'rej', 5: 'rej',
          6: 'rej', 7: 'rej', 8: 'rej', 9: 'ok', 10: 'rej',
          11: 'rej', 12: 'rej', 13: 'rej',
          14: 'ok', 15: 'rej', 16: 'rej'}
for i in range(1, 17):
    fp = f'/tmp/f47chk/t3/cfg/c{i}.json'
    ph = u.config_has_placeholders(fp, require_auth=True)
    try:
        u._preflight_hysteria(fp)
        pf = 'ok'
    except ValueError:
        pf = 'rej'
    assert ph == exp_ph[i], f'c{i} placeholders={ph}'
    assert pf == exp_pf[i], f'c{i} preflight={pf}'
print('OK')
PYT3
grep -q '^OK' "$F/t3py.out" || T3B="$T3B py:$(tail -1 "$F/t3py.out")"
if [ -z "$T3B" ]; then
    ok "T3: 4 валидатора hysteria сходятся на 16 конфигах: отсутствующий auth, example.com (порт/регистр/точка/не-строка) — rej всеми, sni-исключение — старт, auth-секрет:443 — старт, дубликаты/эскейпы — rej (FB-54+FB-74, FB-96/97/98 аудит-36)"
else
    bad "T3:$T3B"
fi

# T4 (FB-46+T-2/R53-06-07): lookup-add — 1 чтение target, лимит, bot, точка.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/t4.out" 2>&1 <<'PYT4'
import sys, os, re, importlib.util, tempfile
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzt4_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('')
calls = {'n': 0}
_orig = g.read_file_text
def _cr(fp):
    calls['n'] += 1
    return _orig(fp)
g.read_file_text = _cr
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/', auth=('a', 'b')).data.decode()
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
H = {'Origin': 'http://localhost'}
tf = g.config.list_files['trojan']
calls['n'] = 0
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'trojan',
         'entries': '\n'.join('d%d.example' % i for i in range(100))},
         headers=H, auth=('a', 'b'))
assert r.status_code == 200 and calls['n'] == 5, (r.status_code, calls['n'])
g.MAX_LIST_LINES = 5
open(tf, 'w').write('a.example\nb.example\n')
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'trojan',
         'entries': 'x1.example\nx2.example\nx3.example\nx4.example'},
         headers=H, auth=('a', 'b'))
assert r.status_code == 400 and len(open(tf).read().splitlines()) == 2
open(g.config.list_files['vless'], 'w').write('shared.example\n')
calls['n'] = 0
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'bot',
         'entries': 'shared.example'}, headers=H, auth=('a', 'b'))
assert r.status_code == 200 and 'warning' not in r.get_json() and calls['n'] == 1
open(g.config.list_files['tor'], 'w').write('dot.example\n')
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'tor',
         'entries': 'dot.example.'}, headers=H, auth=('a', 'b'))
j = r.get_json()
assert j.get('added') == [] and j.get('duplicates') == ['dot.example']
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'tor',
         'entries': 'weird.example.'}, headers=H, auth=('a', 'b'))
assert r.get_json().get('added') == ['weird.example']
assert 'weird.example.' not in open(g.config.list_files['tor']).read()
print('OK')
PYT4
    if grep -q '^OK' "$F/t4.out"; then
        ok "T4: lookup-add: 100 записей → 5 чтений; лимит 400 без записи; bot без cross; точка нормализована (R53-06/07)"
    else
        bad "T4: $(tail -1 "$F/t4.out")"
    fi
else
    grep -q 'FB-46 (аудит-28, R53-06)' "$GEN" \
        && ok "T4: [частично, без flask] маркеры FB-46/T-2 на месте" \
        || bad "T4: маркеры FB-46/T-2 отсутствуют"
fi

# T5 (FB-47/R53-08): check_updates — «проверка не удалась» ≠ «Обновлений нет».
T5="$F/t5"; mkdir -p "$T5"
awk '/# ── Уведомление ──/{f=1} f{print}' "$K/opt/bin/check_updates.sh" > "$T5/tail.sh"
{ echo 'HAS_UPDATES=false'; echo 'ARCH=x64'
  echo 'CHECK_FAILED=1'
  echo 'send_telegram(){ :; }'
  cat "$T5/tail.sh"; } > "$T5/drv_fail.sh"
{ echo 'HAS_UPDATES=false'; echo 'ARCH=x64'
  echo 'CHECK_FAILED=0'
  echo 'send_telegram(){ :; }'
  cat "$T5/tail.sh"; } > "$T5/drv_ok.sh"
T5B=""
sh "$T5/drv_fail.sh" > "$T5/notty" 2>/dev/null
[ "$(wc -c < "$T5/notty" | tr -d ' ')" = 0 ] || T5B="$T5B fail-notty-не-молчит"
if command -v script >/dev/null 2>&1; then
    script -qec "sh '$T5/drv_fail.sh'" /dev/null 2>/dev/null | tr -d '\r' > "$T5/tty_fail"
    script -qec "sh '$T5/drv_ok.sh'" /dev/null 2>/dev/null | tr -d '\r' > "$T5/tty_ok"
    grep -q 'Проверка обновлений не удалась' "$T5/tty_fail" || T5B="$T5B fail-нет-честного-сбоя"
    grep -q 'Обновлений нет' "$T5/tty_fail" && T5B="$T5B fail-ложное-«нет»"
    grep -q 'Обновлений нет' "$T5/tty_ok" || T5B="$T5B ok-нет-«нет»"
else
    grep -q 'Проверка обновлений не удалась' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-текста-сбоя"
fi
grep -q 'OPKG_UPD_RC=0' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-захвата-rc"
grep -q '\\"check_failed\\":' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-check_failed-в-JSON"
if [ -z "$T5B" ]; then
    ok "T5: check_updates: сбой источников → «Проверка не удалась» (tty+JSON check_failed), успех → «Обновлений нет» (R53-08)"
else
    bad "T5:$T5B"
fi

# T6 (FB-48/R53-05): PID-личность по /proc/exe.
T6="$F/t6"; mkdir -p "$T6/rp"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$T6/rp/gate.sh"
cat > "$T6/rp/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
export KEENZOO_HYSTERIA_PIDFILE
. /tmp/f47chk/t6/rb/gate.sh
echo "GATE_RC=PASS"
EOF
sed -i "s|/tmp/f47chk/t6/rb/|/tmp/f47chk/t6/rp/|" "$T6/rp/run.sh"
printf '{ "server": "real.example.org:443", "auth": "00000000-0000-0000-0000-000000000000" }\n' > "$T6/stub.json"
cp /bin/sleep "$T6/rp/hysteria" 2>/dev/null || cp "$(command -v sleep)" "$T6/rp/hysteria"
chmod +x "$T6/rp/hysteria"
T6B=""
"$T6/rp/hysteria" 300 & T6P1=$!
sleep 1
printf '%s\n' "$T6P1" > "$T6/rp/pid"
T6A=$(KEENZOO_HYSTERIA_CONFIG="$T6/stub.json" KEENZOO_HYSTERIA_PIDFILE="$T6/rp/pid" sh "$T6/rp/run.sh" start 2>&1)
sleep 1
kill -0 "$T6P1" 2>/dev/null && T6B="$T6B свой-не-снят"
printf '%s' "$T6A" | grep -q 'Stopping hysteria' || T6B="$T6B нет-Stopping"
wait "$T6P1" 2>/dev/null
bash -c 'exec -a hysteria-marker sleep 60' & T6P2=$!
sleep 1
printf '%s\n' "$T6P2" > "$T6/rp/pid"
KEENZOO_HYSTERIA_CONFIG="$T6/stub.json" KEENZOO_HYSTERIA_PIDFILE="$T6/rp/pid" sh "$T6/rp/run.sh" start >/dev/null 2>&1
kill -0 "$T6P2" 2>/dev/null || T6B="$T6B argv-чужой-убит"
kill "$T6P2" 2>/dev/null; wait "$T6P2" 2>/dev/null
[ -e "$T6/rp/pid" ] && T6B="$T6B pid-не-снят"
if [ -z "$T6B" ]; then
    ok "T6: S57 PID: свой (exe=hysteria) снят; argv-подстрока чужого не убита; pid снят (R53-05)"
else
    bad "T6:$T6B"
fi

# T7 (FB-49/R53-10): баннер — имя или «панель не настроена».
T7="$F/t7"; mkdir -p "$T7"
sed -n "/^_panel_user=\"\$(grep/,/^fi$/p" "$DEP" | sed "s|/opt/etc/bot/bot_config.py|$T7/bot_config.py|" > "$T7/banner.sh"
printf 'web_username = "ivan"\n' > "$T7/bot_config.py"
T7A=$(sh "$T7/banner.sh" 2>/dev/null)
printf 'web_username = ""\n' > "$T7/bot_config.py"
T7B=$(sh "$T7/banner.sh" 2>/dev/null)
if printf '%s' "$T7A" | grep -q '(ivan,' \
    && printf '%s' "$T7B" | grep -q 'панель не настроена: web_username пуст'; then
    ok "T7: сводка deploy: пустой web_username → «панель не настроена», а не «admin» (R53-10)"
else
    bad "T7: ivan=[$T7A] empty=[$T7B]"
fi

# T8 (FB-50/R53-11): _kz_pkg_installed — литерально + пустой список не залипает.
T8="$F/t8"; mkdir -p "$T8/bin"
awk 'index($0, "_kz_pkg_installed() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$T8/pki.sh"
printf '#!/bin/sh\nexit 1\n' > "$T8/bin/opkg"; chmod +x "$T8/bin/opkg"
T8B=""
(
    PATH="$T8/bin:/usr/bin:/bin"
    . "$T8/pki.sh"
    _KZ_PKG_LIST=""; unset _KZ_PKG_LIST_READY _KZ_PKG_NEW
    _kz_pkg_installed foo
    [ -z "${_KZ_PKG_LIST_READY:-}" ] || exit 3
    exit 0
) || T8B="$T8B пустой-список-залип"
printf '#!/bin/sh\necho "libstdc++ - 1.0"\necho "iptables - 1.8"\n' > "$T8/bin/opkg"; chmod +x "$T8/bin/opkg"
(
    PATH="$T8/bin:/usr/bin:/bin"
    . "$T8/pki.sh"
    _KZ_PKG_LIST=""; unset _KZ_PKG_LIST_READY _KZ_PKG_NEW
    _kz_pkg_installed 'libstdc++' || exit 4
    _kz_pkg_installed 'libstdc' && exit 5
    exit 0
) || T8B="$T8B rc=$?-литерал"
if [ -z "$T8B" ]; then
    ok "T8: _kz_pkg_installed: пустой сбойный список не кэшируется; libstdc++ найден, libstdc — нет (R53-11)"
else
    bad "T8:$T8B"
fi

# T9 (FB-51/R53-09): Range-заметка по коду ответа, а не по размеру.
T9="$F/t9"; mkdir -p "$T9/bin" "$T9/dl"
cat > "$T9/bin/curl" <<'EOF'
#!/bin/sh
out=""; code=""; body=""
for a in "$@"; do
    case "$a" in
        http*://*206*) code=206; body=bbbb ;;
        http*://*200s*) code=200; body=bb ;;
        http*://*nc*) code=""; body=bbbb ;;
        http*://*200b*) code=200; body=bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb ;;
    esac
done
prev=""
for a in "$@"; do
    [ "$prev" = "-o" ] && printf '%s' "$body" > "$a"
    prev="$a"
done
[ -n "$code" ] && printf '%s' "$code"
exit 0
EOF
chmod +x "$T9/bin/curl"
cat > "$T9/drv.sh" <<'EOF'
#!/bin/sh
DL_CMD=curl
KEENZOO_DLTMP=/tmp/f47chk/t9/dl
dl_file() { return 1; }
warn() { :; }
. /tmp/f47chk/t9/pf.sh
_entware_probe_feed_url "$1"
echo "rc=$? NOTE=[$_EPF_NOTE]"
EOF
for _fn in _entware_probe_feed_url; do
    awk -v f="$_fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$T9/pf.sh"
done
T9B=""
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f206.example/o)" = "rc=0 NOTE=[curl, range 256Б]" ] || T9B="$T9B 206"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f200s.example/o)" = "rc=0 NOTE=[curl, полная загрузка (сервер без Range)]" ] || T9B="$T9B 200-короткое"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://fnc.example/o)" = "rc=0 NOTE=[curl, range 256Б]" ] || T9B="$T9B фолбэк-без-кода"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f200b.example/o)" = "rc=0 NOTE=[curl, полная загрузка (сервер без Range)]" ] || T9B="$T9B 200-большое"
if [ -z "$T9B" ]; then
    ok "T9: Range-заметка: 206 → range; 200+короткое тело → «полная загрузка» (прежде ложный range); без кода — размер (R53-09)"
else
    bad "T9:$T9B"
fi

# T10: маркеры правок аудита-28 на местах.
T10B=""
grep -q 'FB-43 (аудит-28' "$DEP" || T10B="$T10B FB-43(dep)"
grep -q 'FB-43 (аудит-28' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || T10B="$T10B FB-43(hook)"
grep -q 'FB-44 (аудит-28' "$DEP" || T10B="$T10B FB-44(dep)"
grep -q 'FB-44 (аудит-28' "$K/opt/bin/update_protocols.sh" || T10B="$T10B FB-44(upd)"
grep -q 'FB-45 (аудит-28' "$DEP" || T10B="$T10B FB-45(dep)"
grep -q 'FB-45 (аудит-28' "$S57" || T10B="$T10B FB-45(S57)"
grep -q 'FB-45 (аудит-28' "$K/opt/etc/bot/utils.py" || T10B="$T10B FB-45(utils)"
grep -q 'FB-46 (аудит-28' "$GEN" || T10B="$T10B FB-46(gen)"
grep -q 'T-2 (аудит-28' "$GEN" || T10B="$T10B T-2(gen)"
grep -q 'FB-47 (аудит-28' "$K/opt/bin/check_updates.sh" || T10B="$T10B FB-47(cu)"
grep -q 'FB-48 (аудит-28' "$S57" || T10B="$T10B FB-48(S57)"
grep -q 'FB-49 (аудит-28' "$DEP" || T10B="$T10B FB-49(dep)"
grep -q 'FB-50 (аудит-28' "$DEP" || T10B="$T10B FB-50(dep)"
grep -q 'FB-51 (аудит-28' "$DEP" || T10B="$T10B FB-51(dep)"
if [ -z "$T10B" ]; then
    ok "T10: маркеры FB-43..FB-51 + T-2 во всех правленых файлах (FB-42 — JS-паттерн, см. T0)"
else
    bad "T10: отсутствуют:$T10B"
fi

# ═══ U. Аудит-29: гонка записи, счётчик входа, паритет auth ═══
echo "═══ U. Аудит-29 (r54): запись списков, счётчик входа, паритет auth ═══"

# U0 (FB-52/K54-2): 20 параллельных POST — 20×200 и 20/20 записей.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/u0.out" 2>&1 <<'PYU0'
import sys, os, re, importlib.util, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzu0_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('')
N = 20
results = [None] * N
barrier = threading.Barrier(N)
def worker(i):
    c = g.app.test_client()
    with c.session_transaction() as sess:
        sess['auth'] = True
    html = c.get('/', auth=('a', 'b')).data.decode()
    token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"',
                      html).group(1)
    barrier.wait()
    r = c.post('/api/lookup-add',
               data={'csrf_token': token, 'list': 'trojan',
                     'entries': 'p%d.example' % i},
               headers={'Origin': 'http://localhost'},
               auth=('a', 'b'))
    results[i] = r.status_code
ts = [threading.Thread(target=worker, args=(i,)) for i in range(N)]
for t in ts: t.start()
for t in ts: t.join()
ok = sum(1 for c in results if c == 200)
e500 = sum(1 for c in results if c == 500)
content = set(open(g.config.list_files['trojan']).read().splitlines())
landed = sum(1 for i in range(N) if ('p%d.example' % i) in content)
assert ok == N and e500 == 0 and landed == N, (ok, e500, landed)
print('OK')
PYU0
    if grep -q '^OK' "$F/u0.out"; then
        ok "U0: 20 параллельных POST /api/lookup-add: 20×200, 20/20 записей (r54: 13×500, 1/20) (K54-2)"
    else
        bad "U0: $(tail -1 "$F/u0.out")"
    fi
else
    grep -q 'mkstemp' "$K/opt/etc/bot/lists_core.py" \
        && ok "U0: [частично, без flask] mkstemp в _atomic_write_text (K54-2)" \
        || bad "U0: нет mkstemp в lists_core (K54-2)"
fi

# U1 (FB-52): прямой стресс _atomic_write_text — 24 потока, без исключений.
python3 - "$K" > "$F/u1.out" 2>&1 <<'PYU1'
import sys, importlib.util, os, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location(
    'lc', K + '/opt/etc/bot/lists_core.py')
lcm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lcm)
d = tempfile.mkdtemp(prefix='kzu1_')
fp = os.path.join(d, 'stress.txt')
open(fp, 'w').write('')
errs = []
def hammer(k):
    try:
        for j in range(30):
            lcm._atomic_write_text(fp, 't%d.%d ' % (k, j) + 'x' * 200)
    except Exception as e:
        errs.append(repr(e))
ts = [threading.Thread(target=hammer, args=(k,)) for k in range(24)]
for t in ts: t.start()
for t in ts: t.join()
left = [f for f in os.listdir(d) if '.tmp' in f]
assert not errs and not left and len(open(fp).read()) > 100, (errs[:2], left)
print('OK')
PYU1
if grep -q '^OK' "$F/u1.out"; then
    ok "U1: _atomic_write_text: 24 потока × 30 записей — 0 исключений, tmp не залипают (K54-2)"
else
    bad "U1: $(tail -1 "$F/u1.out")"
fi

# U2 (FB-52/N54-3): _write_enabled — параллельные переключения, права 0755.
python3 - "$K" > "$F/u2.out" 2>&1 <<'PYU2'
import sys, os, importlib.util, tempfile, threading, stat
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
d = tempfile.mkdtemp(prefix='kzu2_')
scripts = {}
for i in range(4):
    sp = os.path.join(d, 'S99svc%d' % i)
    open(sp, 'w').write('#!/bin/sh\nENABLED=yes\nPROCS=svc%d\n' % i)
    os.chmod(sp, 0o755)
    scripts['svc%d' % i] = sp
g.SERVICE_SCRIPTS = scripts
def toggle(i):
    for j in range(15):
        g._write_enabled('svc%d' % i, (j % 2 == 0))
ts = [threading.Thread(target=toggle, args=(i,)) for i in range(4)]
for t in ts: t.start()
for t in ts: t.join()
modes = {oct(stat.S_IMODE(os.stat(sp).st_mode)) for sp in scripts.values()}
heads = {open(sp).read().splitlines()[1].split('=')[0] for sp in scripts.values()}
left = [f for f in os.listdir(d) if '.tmp' in f]
assert modes == {'0o755'} and heads == {'ENABLED'} and not left, (modes, heads, left)
print('OK')
PYU2
if grep -q '^OK' "$F/u2.out"; then
    ok "U2: _write_enabled: 4×15 параллельных переключений — права 0755, без tmp-остатков (N54-3)"
else
    bad "U2: $(tail -1 "$F/u2.out")"
fi

# U3 (FB-53/N54-4): без кредов — 401 без счётчика; неверные креды — 429.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/u3.out" 2>&1 <<'PYU3'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
noauth = [c.get('/').status_code for _ in range(7)]
wrong = [c.get('/', auth=('a', 'nope')).status_code for _ in range(7)]
good = c.get('/', auth=('a', 'b')).status_code
assert noauth == [401] * 7, noauth
assert wrong[:5] == [401] * 5 and 429 in wrong[5:], wrong
assert good == 200, good
print('OK')
PYU3
    if grep -q '^OK' "$F/u3.out"; then
        ok "U3: вход: 7 без Authorization — все 401; неверные креды — 429; верный пароль — 200 (N54-4)"
    else
        bad "U3: $(tail -1 "$F/u3.out")"
    fi
else
    grep -q 'elif auth is None:' "$GEN" \
        && ok "U3: [частично, без flask] ветка «без кредов» на месте (N54-4)" \
        || bad "U3: нет ветки FB-53 (N54-4)"
fi

# U4 (FB-54/N54-2): флаг hysteria в needs_key и require_auth в placeholders.
U4="$F/u4"; mkdir -p "$U4"
printf '{ "server": "real.example.org:443", "tcpRedirect": {}, "udpTProxy": {} }\n' > "$U4/c6.json"
printf '{ "outbounds": [{ "protocol": "vless", "settings": { "vnext": [{ "address": "real.example.org", "users": [{ "id": "11111111-2222-3333-4444-555555555555" }] }] } }] }\n' > "$U4/vless.json"
awk 'index($0, "_nk_root_val() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$U4/nk.sh"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$U4/nk.sh"
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$U4/nk.sh"
U4B=""
(
    . "$U4/nk.sh"
    needs_key "$U4/c6.json" hysteria || exit 1
    needs_key "$U4/c6.json" && exit 2
    needs_key "$U4/vless.json" && exit 3
    exit 0
) || U4B="$U4B needs_key(rc=$?)"
python3 - "$K" > "$F/u4py.out" 2>&1 <<'PYU4'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('u', K + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
assert u.config_has_placeholders('/tmp/f47chk/u4/c6.json',
                                 require_auth=True) is True
assert u.config_has_placeholders('/tmp/f47chk/u4/c6.json') is False
assert u.config_has_placeholders('/tmp/f47chk/u4/vless.json') is False
print('OK')
PYU4
grep -q '^OK' "$F/u4py.out" || U4B="$U4B py:$(tail -1 "$F/u4py.out")"
if [ -z "$U4B" ]; then
    ok "U4: needs_key c флагом hysteria и placeholders(require_auth): auth отсутствует = «ключ не задан»; xray/vless не задет (N54-2)"
else
    bad "U4:$U4B"
fi

# U5: маркеры правок аудита-29 на местах.
U5B=""
grep -q 'FB-52 (аудит-29' "$K/opt/etc/bot/lists_core.py" || U5B="$U5B FB-52(lists_core)"
grep -q 'FB-52 (аудит-29' "$GEN" || U5B="$U5B FB-52(gen)"
grep -q 'N54-3' "$GEN" || U5B="$U5B FB-52(_write_enabled)"
grep -q 'FB-53 (аудит-29' "$GEN" || U5B="$U5B FB-53(gen)"
grep -q 'FB-54 (аудит-29' "$DEP" || U5B="$U5B FB-54(dep)"
grep -q 'FB-54 (аудит-29' "$K/opt/etc/bot/utils.py" || U5B="$U5B FB-54(utils)"
if [ -z "$U5B" ]; then
    ok "U5: маркеры FB-52/FB-53/FB-54 во всех правленых файлах (lists_core, generator, deploy, utils)"
else
    bad "U5: отсутствуют:$U5B"
fi

# ═══ V. Аудит-30: согласие HTTP-фида, честная сводка, дедуп, вердикты ═══
echo "═══ V. Аудит-30 (живая установка r55): согласие, честность, дедуп ═══"

# V0 (FB-55): tty-согласие в гейте — не-tty fail-closed, pty y/n/EOF.
V0="$F/v0"; mkdir -p "$V0"
extract_fn _kz_http_feed_active "$DEP" > "$V0/gate.sh"
extract_fn _kz_http_install_gate "$DEP" >> "$V0/gate.sh"
awk 'index($0, "warn() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$V0/gate.sh"
cat > "$V0/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/v0/gate.sh
_KZ_HTTP_FEED_ASKED=0
_KZ_HTTP_FEED_CONSENT=0
export KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/v0/conf
_kz_http_install_gate pkg-one; echo "RC1=$?"
_kz_http_install_gate pkg-two; echo "RC2=$?"
EOF
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\n' > "$V0/conf"
V0B=""
_o=$(sh "$V0/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'RC1=1' && printf '%s' "$_o" | grep -q 'RC2=1' \
    || V0B="$V0B notty-rc"
printf '%s' "$_o" | grep -q 'Ответ' && V0B="$V0B notty-вопрос"
if command -v script >/dev/null 2>&1; then
    _o=$(printf 'y\n' | script -qec "sh $V0/drv.sh" /dev/null 2>&1 | tr -d '\r')
    printf '%s' "$_o" | grep -q 'RC1=0' && printf '%s' "$_o" | grep -q 'RC2=0' \
        || V0B="$V0B yes-rc"
    [ "$(printf '%s' "$_o" | grep -c 'Ответ \[y/N\]')" = 1 ] || V0B="$V0B yes-вопросов-не-1"
    _o=$(printf 'n\n' | script -qec "sh $V0/drv.sh" /dev/null 2>&1 | tr -d '\r')
    printf '%s' "$_o" | grep -q 'RC1=1' && printf '%s' "$_o" | grep -q 'RC2=1' \
        || V0B="$V0B no-rc"
    [ "$(printf '%s' "$_o" | grep -c 'Ответ \[y/N\]')" = 1 ] || V0B="$V0B no-вопросов-не-1"
    _o=$(script -qec "sh $V0/drv.sh" /dev/null </dev/null 2>&1 | tr -d '\r')
    printf '%s' "$_o" | grep -q 'RC1=1' || V0B="$V0B eof-rc"
else
    grep -q '_KZ_HTTP_FEED_ASKED' "$DEP" || V0B="$V0B нет-ветки-согласия"
fi
if [ -z "$V0B" ]; then
    ok "V0: HTTP-гейт: не-tty rc1 без вопроса; pty «y»→0 «n»/EOF→1; вопрос один раз за прогон (FB-55)"
else
    bad "V0:$V0B"
fi

# V1 (FB-56): _kz_required_missing — факт вместо «Пакеты уже стоят».
V1="$F/v1"; mkdir -p "$V1/bin"
extract_fn _kz_pkg_installed "$DEP" > "$V1/rm.sh"
extract_fn _kz_required_missing "$DEP" >> "$V1/rm.sh"
grep '^KZ_PKG_REQUIRED=' "$DEP" > "$V1/req.sh"
cat > "$V1/bin/opkg" <<'EOF'
#!/bin/sh
case "$1" in list-installed) cat /tmp/f47chk/v1/installed.txt;; esac
exit 0
EOF
chmod +x "$V1/bin/opkg"
V1B=""
printf 'curl - 1\ntor - 1\nca-bundle - 1\n' > "$V1/installed.txt"
_m=$(PATH="$V1/bin:/usr/bin:/bin" sh -c ". '$V1/req.sh'; . '$V1/rm.sh'; _kz_required_missing")
[ -n "$_m" ] || V1B="$V1B пустой-список-при-частичной"
: > "$V1/installed.txt"
_m=$(PATH="$V1/bin:/usr/bin:/bin" sh -c ". '$V1/req.sh'; . '$V1/rm.sh'; _kz_required_missing")
[ "$(printf '%s' "$_m" | wc -w)" = 23 ] || V1B="$V1B полный=$(printf '%s' "$_m" | wc -w)"
printf 'tor - 1\ncurl - 1\nca-bundle - 1\nca-certificates - 1\nwget-ssl - 1\ntor-geoip - 1\nbind-dig - 1\ncron - 1\ndnsmasq-full - 1\nipset - 1\niptables - 1\nobfs4 - 1\nshadowsocks-libev-ss-redir - 1\nshadowsocks-libev-config - 1\nxray - 1\ntrojan - 1\ncoreutils-split - 1\nunzip - 1\npython3-pip - 1\npython3-requests - 1\npython3-markupsafe - 1\npython3-setuptools - 1\npython3-openssl - 1\n' > "$V1/installed.txt"
_m=$(PATH="$V1/bin:/usr/bin:/bin" sh -c ". '$V1/req.sh'; . '$V1/rm.sh'; _kz_required_missing")
[ -z "$_m" ] || V1B="$V1B непусто-при-полной:[$_m]"
grep -q 'установлены НЕ все' "$DEP" || V1B="$V1B нет-списка-недостающих"
grep -q 'Пакеты бутстрапа HTTPS не установлены' "$DEP" || V1B="$V1B нет-честного-вердикта-провала"
if [ -z "$V1B" ]; then
    ok "V1: _kz_required_missing: полная/частичная/пустая укомплектованность (23 позиции с wget-ssl); сводка честная; провал бутстрапа — вердикт факта (FB-56+FB-78)"
else
    bad "V1:$V1B"
fi

# V2 (FB-57): дедуп сводки пропусков.
V2="$F/v2"; mkdir -p "$V2"
extract_fn _kz_skip_note "$DEP" > "$V2/sn.sh"
_o=$(PATH=/usr/bin:/bin sh -c ". '$V2/sn.sh'; SKIPPED_HTTP=''; _kz_skip_note dnsmasq-full; _kz_skip_note curl; _kz_skip_note dnsmasq-full; _kz_skip_note xray; printf '%s' \"\$SKIPPED_HTTP\"")
if [ "$_o" = " dnsmasq-full curl xray" ]; then
    ok "V2: _kz_skip_note: dnsmasq-full дважды → одна запись в сводке (FB-57)"
else
    bad "V2: [$_o]"
fi

# V3 (FB-58): вердикты по бинарнику; ps-матчер без самосопоставления.
V3B=""
grep -A5 'ss-redir)' "$DEP" | grep -q 'have_cmd ss-redir' || V3B="$V3B ss-redir"
grep -A5 'trojan)' "$DEP" | grep -q 'have_cmd trojan' || V3B="$V3B trojan"
grep -q 'ставится с GitHub — шаг \[7/11\]' "$DEP" || V3B="$V3B hysteria-формулировка"
grep -q 'ps | grep -q "\[p\]ython3.\*\[m\]ain.py"' "$DEP" || V3B="$V3B ps-main"
grep -q 'ps | grep -q "\[p\]ython3.\*\[g\]enerator.py"' "$DEP" || V3B="$V3B ps-generator"
if ps | grep -q '[p]ython3.*[m]ain.py'; then
    V3B="$V3B ps-паттерн-ложный-позитив (в стенде нет python3-бота)"
fi
if [ -z "$V3B" ]; then
    ok "V3: вердикты ss-redir/trojan по have_cmd; hysteria — «GitHub [7/11]»; ps-матчер [p]-трюк без самосопоставления (FB-58)"
else
    bad "V3:$V3B"
fi

# V4: маркеры аудита-30 на местах.
V4B=""
grep -q 'FB-55 (аудит-30' "$DEP" || V4B="$V4B FB-55"
grep -q 'FB-56 (аудит-30' "$DEP" || V4B="$V4B FB-56"
grep -q 'FB-57 (аудит-30' "$DEP" || V4B="$V4B FB-57"
grep -q 'FB-58 (аудит-30' "$DEP" || V4B="$V4B FB-58"
if [ -z "$V4B" ]; then
    ok "V4: маркеры FB-55..FB-58 в deploy_bypass.sh"
else
    bad "V4: отсутствуют:$V4B"
fi

# ═══ W. Аудит-34: авто-бутстрап HTTPS (FB-78) и DNS Override (FB-79) ═══
echo "═══ W. Аудит-34: авто-бутстрап HTTPS фида + dns-override по согласию ═══"

W0="$F/w0"; mkdir -p "$W0/bin"
for _wfn in warn have_cmd _entware_stock_feeds _entware_feed_base \
    _entware_probe_feed_url _entware_prepare_candidate \
    _kz_pkg_installed _kz_pkg_cache_note _kz_http_feed_active \
    _kz_bootstrap_missing _kz_iso_conf_write \
    _kz_iso_opkg_update_install _kz_bootstrap_rollback \
    _kz_https_bootstrap_try _kz_https_bootstrap \
    _kz_http_install_gate; do
    extract_fn "$_wfn" "$DEP" >> "$W0/bs.sh"
    echo >> "$W0/bs.sh"
done
grep -q '^_kz_https_bootstrap() {' "$W0/bs.sh" || bad "W0: экстракция блока бутстрапа не удалась"
grep '^KZ_PKG_REQUIRED=' "$DEP" > "$W0/req.sh"
# K60-01 (аудит-35): вызовы opkg идут с -f <изолированный conf> —
# мок различает основной и изолированный конфиги (journal пишет
# полный вызов; update-решение — по conf кандидата)
cat > "$W0/bin/opkg" <<'EOF'
#!/bin/sh
echo "opkg $*" >> /tmp/f47chk/w0/journal
CONF="${KZ_DEPLOY_OPKG_CONF:-/tmp/f47chk/w0/opkg.conf}"
while [ $# -gt 0 ]; do
  case "$1" in
    -f) CONF="$2"; shift 2 ;;
    update|install|list-installed) break ;;
    *) shift ;;
  esac
done
case "${1:-}" in
  update)
    [ -f /tmp/f47chk/w0/update_fails ] && exit 1
    if grep -q 'https://' "$CONF" 2>/dev/null \
        && { [ -f /tmp/f47chk/w0/update_https_fails ] \
             || ! grep -q '^wget-ssl' /tmp/f47chk/w0/installed.txt 2>/dev/null; }; then
        exit 1
    fi
    exit 0 ;;
  install)
    printf 'curl - 1\nca-bundle - 1\nca-certificates - 1\nwget-ssl - 1\n' >> /tmp/f47chk/w0/installed.txt
    exit 0 ;;
  list-installed) cat /tmp/f47chk/w0/installed.txt 2>/dev/null; exit 0 ;;
esac
exit 0
EOF
chmod +x "$W0/bin/opkg"
cat > "$W0/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/w0/req.sh
. /tmp/f47chk/w0/bs.sh
KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/w0/opkg.conf
DL_CMD=""
ENTWARE_MIRRORS="https://bin.entware.net https://mirrors.bfsu.edu.cn/entware"
_ENTWARE_BASE_REQUESTED=""
export KZ_DEPLOY_OPKG_CONF DL_CMD ENTWARE_MIRRORS _ENTWARE_BASE_REQUESTED
ENTWARE_BASE=""
PATH="/tmp/f47chk/w0/bin:/usr/bin:/bin"; export PATH
_kz_https_bootstrap
_kz_http_install_gate probe-pkg && echo "GATE=PASS" || echo "GATE=SKIP"
echo "CONSENT=${_KZ_HTTP_FEED_CONSENT:-0}"
EOF
chmod +x "$W0/drv.sh"
w0reset() {
    rm -f "$W0/journal" "$W0/update_fails" "$W0/update_https_fails" "$W0/opkg.conf.bak-keenzoo"
    : > "$W0/installed.txt"
    printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc/gz keendev http://bin.entware.net/aarch64-k3.10/keenetic\nsrc custom http://third.party/feed\n' > "$W0/opkg.conf"
    cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
}

# W0 (FB-78): pty — авто-бутстрап БЕЗ вопроса: 4 пакета → флип → контроль.
# Ввод: пустая строка — бутстрап не спрашивает ничего, а гейт FB-55 про
# остаточный сторонний http-фид спрашивает отдельно и получает отказ.
w0reset
_o=$(printf '\n' | script -qec "sh $W0/drv.sh" /dev/null 2>&1 | tr -d '\r')
W0B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W0B="$W0B появился-вопрос"
printf '%s' "$_o" | grep -q 'Разрешить сетевые установки из HTTP-фида' || W0B="$W0B гейт-не-спросил-про-остаточные"
printf '%s' "$_o" | grep -q 'Пакеты бутстрапа HTTPS установлены (текущий фид)' || W0B="$W0B нет-установки-4"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W0B="$W0B нет-флипа"
# FB-72 (аудит-33): остаточный сторонний http-фид не подпадает под
# авто-бутстрап — гейт для него закрыт, предупреждение напечатано.
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W0B="$W0B гейт-открыт-для-остаточных"
printf '%s' "$_o" | grep -q 'CONSENT=0' || W0B="$W0B согласие-появилось"
printf '%s' "$_o" | grep -q 'остаются сторонние HTTP-фиды' || W0B="$W0B нет-предупреждения-об-остаточных"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W0B="$W0B install-не-4-изолированно"
# K60-01: индекс (1) и контроль флипа (3) — оба изолированным conf
[ "$(grep -cE '^opkg -f [^ ]+ update$' "$W0/journal")" = 2 ] || W0B="$W0B iso-update-не-2 (индекс+контроль)"
grep -q '^opkg update$' "$W0/journal" && W0B="$W0B основной-update-при-iso"
grep -q '^src/gz entware https://bin.entware.net/aarch64-k3.10$' "$W0/opkg.conf" || W0B="$W0B entware-не-флип"
grep -q '^src/gz keendev https://bin.entware.net/aarch64-k3.10/keenetic$' "$W0/opkg.conf" || W0B="$W0B keendev-subpath-потерян"
grep -q '^src custom http://third.party/feed$' "$W0/opkg.conf" || W0B="$W0B custom-тронут"
[ -f "$W0/opkg.conf.bak-keenzoo" ] || W0B="$W0B нет-бэкапа"
if [ -z "$W0B" ]; then
    ok "W0: авто-бутстрап pty: БЕЗ вопроса — 4 пакета → флип entware|keendev (subpath/custom целы) → контрольные iso-update ×2; основной opkg update остаётся шагу [1/11]; остаточный сторонний http-фид — гейт закрыт + предупреждение (FB-78+FB-72+K60-01)"
else
    bad "W0:$W0B"
fi

# W1 (FB-78): не-tty — бутстрап выполняется полностью (авто-режим).
w0reset
_o=$(sh "$W0/drv.sh" </dev/null 2>&1)
W1B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W1B="$W1B появился-вопрос"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W1B="$W1B нет-флипа"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W1B="$W1B нет-установки"
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W1B="$W1B гейт-пропустил-остаточные"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" && W1B="$W1B conf-не-флипнут"
if [ -z "$W1B" ]; then
    ok "W1: авто-бутстрап не-tty: полный переход без вопросов и согласий (FB-78; прежде не-tty — fail-closed по каждому пакету)"
else
    bad "W1:$W1B"
fi

# W2 (FB-78): pty с «n» — вопроса нет, ввод не влияет.
w0reset
_o=$(printf 'n\n' | script -qec "sh $W0/drv.sh" /dev/null 2>&1 | tr -d '\r')
W2B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W2B="$W2B появился-вопрос"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W2B="$W2B нет-флипа"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W2B="$W2B нет-установки"
if [ -z "$W2B" ]; then
    ok "W2: авто-бутстрап pty «n»: вопрос не задаётся — ответ не влияет (FB-78)"
else
    bad "W2:$W2B"
fi

# W3 (FB-78): env=1 не-tty — бутстрап тот же; env открывает гейт остаточным.
w0reset
_o=$(KEENZOO_ALLOW_HTTP_FEED=1 sh "$W0/drv.sh" </dev/null 2>&1)
W3B=""
printf '%s' "$_o" | grep -q 'Выполнить' && W3B="$W3B появился-вопрос"
printf '%s' "$_o" | grep -q 'переведены на https://bin.entware.net' || W3B="$W3B нет-флипа"
printf '%s' "$_o" | grep -q 'GATE=PASS' || W3B="$W3B гейт-не-открыт-env"
grep -qE '^opkg -f [^ ]+ update$' "$W0/journal" || W3B="$W3B нет-изолированного-update"
if [ -z "$W3B" ]; then
    ok "W3: env=1 не-tty: бутстрап тот же автоматический; env открывает гейт для остаточных http-установок (FB-78)"
else
    bad "W3:$W3B"
fi

# W4 (FB-84, аудит-35/R60-02): https-фид — равноправен: (a) без
# транспорта (мок https-update требует wget-ssl) пакеты не ставятся,
# но фид остаётся https, conf/bak не трогаются, основной update
# шага [1/11] сам разберётся; (b) с укомплектованным транспортом —
# тихо: ничего не флипает, журнал без установок. Пробы зеркал
# замокаены rc 2 (нет curl — «не проверено») для детерминизма.
cat > "$W0/drv4.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/w0/req.sh
. /tmp/f47chk/w0/bs.sh
KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/w0/opkg.conf
DL_CMD=""
ENTWARE_MIRRORS="https://bin.entware.net https://mirrors.bfsu.edu.cn/entware"
_ENTWARE_BASE_REQUESTED=""
export KZ_DEPLOY_OPKG_CONF DL_CMD ENTWARE_MIRRORS _ENTWARE_BASE_REQUESTED
ENTWARE_BASE=""
PATH="/tmp/f47chk/w0/bin:/usr/bin:/bin"; export PATH
_entware_probe_feed_url() { return 2; }
_kz_https_bootstrap
echo "ENTWARE_BASE=$ENTWARE_BASE"
EOF
chmod +x "$W0/drv4.sh"
w0reset
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$W0/opkg.conf"
cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
_o=$(sh "$W0/drv4.sh" </dev/null 2>&1)
W4B=""
printf '%s' "$_o" | grep -q 'не установлены' || W4B="$W4B нет-вердикта-без-транспорта"
grep -qE '^opkg -f [^ ]+ install ' "$W0/journal" && W4B="$W4B установка-без-транспорта"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W4B="$W4B conf-тронут"
[ -f "$W0/opkg.conf.bak-keenzoo" ] && W4B="$W4B лишний-бэкап"
w0reset
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$W0/opkg.conf"
cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
printf 'curl - 1\nca-bundle - 1\nca-certificates - 1\nwget-ssl - 1\n' > "$W0/installed.txt"
_o=$(sh "$W0/drv4.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'не установлены' && W4B="$W4B ложный-вердикт-при-укомплектованном"
grep -qE '^opkg -f [^ ]+ (install|update)' "$W0/journal" && W4B="$W4B лишние-вызовы-при-укомплектованном"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W4B="$W4B conf-тронут-при-укомплектованном"
[ -f "$W0/opkg.conf.bak-keenzoo" ] && W4B="$W4B лишний-бэкап-при-укомплектованном"
printf '%s' "$_o" | grep -q 'ENTWARE_BASE=https://bin.entware.net$' || W4B="$W4B base-не-зафиксирован-при-укомплектованном"
if [ -z "$W4B" ]; then
    ok "W4: https-фид (FB-84/R60-02): без транспорта — честный вердикт «не установлены», conf/bak не тронуты; укомплектованный — тихо, без флипа/бэкапа; прежде ранний return не ставил пакеты вовсе"
else
    bad "W4:$W4B"
fi

# W5 (FB-78): OFFLINE — бутстрап пропущен даже с env-разрешением.
w0reset
_o=$(KEENZOO_ALLOW_HTTP_FEED=1 KEENZOO_OPKG_OFFLINE=1 sh "$W0/drv.sh" </dev/null 2>&1)
if ! printf '%s' "$_o" | grep -q 'переведены' && [ ! -f "$W0/journal" ] \
    && cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig"; then
    ok "W5: KEENZOO_OPKG_OFFLINE=1: бутстрап пропущен целиком (FB-78)"
else
    bad "W5: offline-не-учтён"
fi

# W6 (FB-78): провалы — мёртвый фид (все update) и контрольный update
# флипа (https падает при состоявшейся установке): байт-точные откаты.
w0reset
: > "$W0/update_fails"
_o=$(sh "$W0/drv.sh" </dev/null 2>&1)
W6B=""
printf '%s' "$_o" | grep -q 'Пакеты бутстрапа HTTPS не установлены' || W6B="$W6B нет-вердикта-провала"
grep -q '^opkg install' "$W0/journal" && W6B="$W6B установка-при-мёртвом-фиде"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W6B="$W6B conf-тронут-при-провале"
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W6B="$W6B гейт-открыт-при-провале"
w0reset
: > "$W0/update_https_fails"
_o=$(sh "$W0/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'Контрольный opkg update по HTTPS не прошёл' || W6B="$W6B нет-текста-отката-флипа"
grep -qE '^opkg -f [^ ]+ install curl ca-bundle ca-certificates wget-ssl$' "$W0/journal" || W6B="$W6B установка-не-выполнена"
cmp -s "$W0/opkg.conf" "$W0/opkg.conf.orig" || W6B="$W6B флип-не-откачен-байт-в-байт"
printf '%s' "$_o" | grep -q 'GATE=SKIP' || W6B="$W6B гейт-открыт-после-отката-флипа"
if [ -z "$W6B" ]; then
    ok "W6: провалы авто-бутстрапа: мёртвый фид → вердикт + ноль установок, conf цел; провал контрольного https-update → установка состоялась, флип откачен байт-в-байт; гейт всюду закрыт (FB-78)"
else
    bad "W6:$W6B"
fi

# W7 (FB-79): dns-override не-tty — без вопросов и без действий.
W7="$F/w7"; mkdir -p "$W7/bin"
for _wfn in warn have_cmd _kz_pkg_installed _kz_required_missing \
    _kz_dns_live _kz_dns_override_on _kz_dns_override_enable \
    _kz_dns_override_disable _kz_dns_self_revert \
    _kz_dns_override_step _kz_resolver_finalize; do
    extract_fn "$_wfn" "$DEP" >> "$W7/dns.sh"
    echo >> "$W7/dns.sh"
done
grep '^KZ_PKG_REQUIRED=' "$DEP" > "$W7/req.sh"
cat > "$W7/bin/ndmc" <<'EOF'
#!/bin/sh
echo "ndmc $*" >> /tmp/f47chk/w7/journal
case "$*" in
  *'show running-config'*)
    [ "$(cat /tmp/f47chk/w7/state 2>/dev/null)" = on ] && echo 'opkg dns-override'
    ;;
  *'no opkg dns-override'*) echo off > /tmp/f47chk/w7/state ;;
  *'opkg dns-override'*) echo on > /tmp/f47chk/w7/state ;;
esac
exit 0
EOF
cat > "$W7/bin/pidof" <<'EOF'
#!/bin/sh
[ "$(cat /tmp/f47chk/w7/pidof_mode 2>/dev/null)" = alive ] && echo 4242
exit 0
EOF
cat > "$W7/bin/opkg" <<'EOF'
#!/bin/sh
case "${1:-}" in list-installed) cat /tmp/f47chk/w7/installed.txt 2>/dev/null;; esac
exit 0
EOF
chmod +x "$W7/bin/"*
cat > "$W7/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/w7/req.sh
. /tmp/f47chk/w7/dns.sh
PATH="/tmp/f47chk/w7/bin:/usr/bin:/bin"; export PATH
W_ENSURE=0
ensure_local_resolver() { W_ENSURE=$((W_ENSURE + 1)); }
dns_ok() { return 0; }
# FB-71: проба 127.0.0.1 тестируется отдельно (Y4); здесь —
# штатное «резолвер жив», чтобы W7 остался про dns-override-шаг.
_kz_dns_probe_local() { return 0; }
DNS_OVERRIDE_OK=7
_kz_dns_override_step
echo "STEP_OK=${DNS_OVERRIDE_OK}"
_kz_resolver_finalize
echo "ENSURE=$W_ENSURE"
EOF
chmod +x "$W7/drv.sh"
w7run() {
    rm -f "$W7/journal"
    echo "$1" > "$W7/state"
    echo "$2" > "$W7/pidof_mode"
    : > "$W7/installed.txt"
}
w7run on alive
_o=$(sh "$W7/drv.sh" </dev/null 2>&1)
W7B=""
printf '%s' "$_o" | grep -q 'DNS Override уже включён' || W7B="$W7B жив+вкл-не-распознан"
printf '%s' "$_o" | grep -q 'STEP_OK=1' || W7B="$W7B жив+вкл-не-подтверждён"
printf '%s' "$_o" | grep -q 'ENSURE=1' || W7B="$W7B жив-resolv-не-подключён"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W7B="$W7B лишний-enable"
w7run off alive
_o=$(sh "$W7/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'DNS Override не включён' || W7B="$W7B выкл+жив-подсказок-нет"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W7B="$W7B включение-без-согласия"
printf '%s' "$_o" | grep -q 'STEP_OK=0' || W7B="$W7B выкл+жив-OK-не-0"
printf '%s' "$_o" | grep -q 'ENSURE=0' || W7B="$W7B выкл+жив-resolv-тронут"
w7run off dead
_o=$(sh "$W7/drv.sh" </dev/null 2>&1)
printf '%s' "$_o" | grep -q 'DNS Override не включён' || W7B="$W7B выкл+мёртв-подсказок-нет"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W7B="$W7B мёртв-enable-вызван"
printf '%s' "$_o" | grep -q 'ENSURE=0' || W7B="$W7B мёртв-resolv-тронут"
if [ -z "$W7B" ]; then
    ok "W7: dns-override не-tty: вкл+жив→✅+resolv; выкл (жив/мёртв)→подсказки, ни ndmc, ни resolv.conf (FB-79)"
else
    bad "W7:$W7B"
fi

# W8 (FB-79): pty — согласие «y» (+S56-старт при мёртвом), отказ, откат заклинившего.
w7run off dead
_o=$(printf 'y\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
W8B=""
printf '%s' "$_o" | grep -q 'Включить DNS Override сейчас?' || W8B="$W8B нет-вопроса"
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" || W8B="$W8B нет-enable"
# FB-82 (аудит-35, R60-01): dnsmasq не поднялся после включённого
# нами override — откат на системный DNS + подсказки (прежний текст
# «resolv.conf НЕ переключён» заменён откатом самого override)
printf '%s' "$_o" | grep -q 'DNS Override отключён: системный DNS Keenetic снова' || W8B="$W8B нет-отката-override"
grep -q 'ndmc -c no opkg dns-override$' "$W7/journal" || W8B="$W8B нет-no-override-в-откате"
printf '%s' "$_o" | grep -q 'STEP_OK=0' || W8B="$W8B OK-при-мёртвом-dnsmasq"
printf '%s' "$_o" | grep -q 'ENSURE=0' || W8B="$W8B resolv-всё-же-тронут"
w7run off alive
_o=$(printf 'y\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
printf '%s' "$_o" | grep -q 'dnsmasq работает на порту 53' || W8B="$W8B жив-не-подтверждён"
printf '%s' "$_o" | grep -q 'STEP_OK=1' || W8B="$W8B жив-OK-не-1"
printf '%s' "$_o" | grep -q 'ENSURE=1' || W8B="$W8B жив-resolv-не-подключён"
w7run off dead
_o=$(printf 'n\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
grep -q 'ndmc -c opkg dns-override$' "$W7/journal" && W8B="$W8B enable-после-отказа"
printf '%s' "$_o" | grep -q 'DNS Override не включён' || W8B="$W8B отказ-без-подсказок"
w7run on dead
_o=$(printf 'y\n' | script -qec "sh $W7/drv.sh" /dev/null 2>&1 | tr -d '\r')
printf '%s' "$_o" | grep -q 'резолвинг на роутере сейчас сломан' || W8B="$W8B нет-диагноза"
printf '%s' "$_o" | grep -q 'отключён: системный DNS Keenetic снова' || W8B="$W8B нет-отката"
[ "$(cat "$W7/state")" = off ] || W8B="$W8B state-не-off"
grep -q 'ndmc -c no opkg dns-override$' "$W7/journal" || W8B="$W8B нет-no-вызова"
if [ -z "$W8B" ]; then
    ok "W8: dns-override pty: «y»+мёртв→enable+попытка S56 (без /opt — честный OK=0, откат override через общий хелпер FB-92); «y»+жив→OK=1+resolv; «n»→подсказки; заклинивший+«y»→откат (FB-79/FB-92)"
else
    bad "W8:$W8B"
fi

# W9 (FB-78/FB-79/FB-80/FB-81): структурные маркеры аудита-34.
W9B=""
grep -q 'wget-ssl' "$DEP" || W9B="$W9B нет-wget-ssl"
[ "$(grep -c '_kz_https_bootstrap() {' "$DEP")" = 1 ] || W9B="$W9B нет-функции-бутстрапа"
[ "$(grep -c '_kz_https_bootstrap_try() {' "$DEP")" = 1 ] || W9B="$W9B нет-хелпера-try"
[ "$(grep -c '_kz_bootstrap_missing() {' "$DEP")" = 1 ] || W9B="$W9B нет-хелпера-missing"
[ "$(grep -c '_kz_dns_override_step() {' "$DEP")" = 1 ] || W9B="$W9B нет-шага-dns"
[ "$(grep -c '_kz_resolver_finalize() {' "$DEP")" = 1 ] || W9B="$W9B нет-финализатора"
grep -q 'FB-59 (аудит-31' "$DEP" || W9B="$W9B нет-маркера-FB-59"
grep -q 'FB-62 (аудит-31' "$DEP" || W9B="$W9B нет-маркера-FB-62"
for _w9m in 'FB-78 (аудит-34' 'FB-79 (аудит-34' 'FB-80 (аудит-34' 'FB-81 (аудит-34'; do
    grep -q "$_w9m" "$DEP" || W9B="$W9B нет-маркера-$_w9m"
done
grep -q 'KEENZOO_OPKG_OFFLINE:-0.*= 1.*&& return 0' "$DEP" || W9B="$W9B нет-offline-гейта-бутстрапа"
grep -q 'Для завершения установки перезагрузить роутер сейчас' "$DEP" || W9B="$W9B нет-reboot-запроса"
grep -q '/opt/etc/init.d/S56dnsmasq start' "$DEP" || W9B="$W9B нет-старта-S56-в-шаге-dns"
if [ -z "$W9B" ]; then
    ok "W9: маркеры FB-78/79/80/81 + FB-59/62, хелперы бутстрапа, S56-старт в шаге DNS, reboot-запрос, offline-гейт (структура)"
else
    bad "W9:$W9B"
fi

# ═══ X. Аудит-32: writers списков, панель, валидаторы, сироты ═══
echo "═══ X. Аудит-32 (отчёт r55): lock writers, 401-timing, паритет 15/15 ═══"

# X0 (FB-63): межпроцессный flock — 2 субпроцесса × 30 RMW-записей.
X0="$F/x0"; mkdir -p "$X0"
cat > "$X0/child.py" <<'EOF'
import sys
sys.path.insert(0, sys.argv[3])
import lists_core as lc
fp, tag = sys.argv[1], sys.argv[2]
for i in range(30):
    with lc._list_write_guard(fp):
        t = open(fp).read()
        lc._atomic_write_text(fp, t + '%s-%d.example\n' % (tag, i))
EOF
printf 'base.example\n' > "$X0/tr.txt"
python3 "$X0/child.py" "$X0/tr.txt" A "$K/opt/etc/bot" >/dev/null 2>&1 & X0P1=$!
python3 "$X0/child.py" "$X0/tr.txt" B "$K/opt/etc/bot" >/dev/null 2>&1 & X0P2=$!
wait "$X0P1"; X0R1=$?; wait "$X0P2"; X0R2=$?
X0A=$(grep -c '^A-' "$X0/tr.txt" || true)
X0B=$(grep -c '^B-' "$X0/tr.txt" || true)
grep -q '^base.example$' "$X0/tr.txt"; X0C=$?
if [ "$X0R1" = 0 ] && [ "$X0R2" = 0 ] && [ "$X0A" = 30 ] && [ "$X0B" = 30 ] \
    && [ "$X0C" = 0 ]; then
    ok "X0: _list_write_guard: 2 процесса × 30 RMW — 60/60 записей + база (flock сериализует; R55-01)"
else
    bad "X0: rc=$X0R1/$X0R2 A=$X0A/30 B=$X0B/30 base=$X0C"
fi

# X1 (FB-63): revision редактора — stale-вкладка получает конфликт.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x1.out" 2>&1 <<'PYX1'
import sys, os, re, importlib.util, tempfile, time
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzx1_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
g.BYPASS_FILES = {n: p for n, p in g.config.list_files.items() if n != 'bot'}
g.BOT_BYPASS_FILE = g.config.list_files['bot']
import lists_core
lists_core.UNBLOCK_DIR = tmp
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('base.example\n')
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/?tab=tr', auth=('a', 'b')).data.decode()
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
rev = re.search(r'name="rev"[^>]*value="([^"]+)"', html).group(1)
# FB-70 (аудит-33, K58-1): rev = SHA-256 байтов содержимого файла
import hashlib
assert rev == hashlib.sha256(
    open(g.config.list_files['trojan'], 'rb').read()).hexdigest(), rev
# «другой писатель» меняет файл после загрузки вкладки
with open(g.config.list_files['trojan'], 'a') as f:
    f.write('other-writer.example\n')
time.sleep(0.01)
r = c.post('/list/tr',
           data={'csrf_token': token, 'rev': rev,
                 'content': 'stale-tab.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302, r.status_code
text = open(g.config.list_files['trojan']).read()
assert 'stale-tab.example' not in text, 'stale-вкладка перезаписала чужую правку!'
assert 'other-writer.example' in text
# свежий rev — сохранение проходит
fresh = hashlib.sha256(
    open(g.config.list_files['trojan'], 'rb').read()).hexdigest()
r = c.post('/list/tr',
           data={'csrf_token': token, 'rev': fresh,
                 'content': 'base.example\nother-writer.example\nfresh-tab.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302
text = open(g.config.list_files['trojan']).read()
assert 'fresh-tab.example' in text and 'other-writer.example' in text
# FB-70 strict (аудит-33, K58-1): форма без rev при существующем
# непустом файле — КОНФЛИКТ (прежде «совместимость со старой
# вкладкой» молча затирала чужие правки)
r = c.post('/list/tr',
           data={'csrf_token': token,
                 'content': 'base.example\ncompat-tab.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302
assert 'compat-tab.example' not in open(
    g.config.list_files['trojan']).read(), 'no-rev сохранился — strict нарушен!'
print('X1 OK')
PYX1
    grep -q '^X1 OK' "$F/x1.out" \
        && ok "X1: редактор: rev=SHA-256; stale-rev → конфликт (чужая правка цела); свежий rev → сохранение; БЕЗ rev → конфликт strict (FB-63+FB-70/R55-01, K58-1)" \
        || bad "X1: $(tail -3 "$F/x1.out" | tr '\n' ' ')"
else
    ok "X1: [SKIP] flask не установлен — ревизия проверяется структурно в X8"
fi

# X2 (FB-64): 401 без задержки для отсутствующих кредов; неверные — с ней.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x2.out" 2>&1 <<'PYX2'
import sys, time, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
t0 = time.time()
r1 = c.get('/api/update-status')
dt1 = time.time() - t0
assert r1.status_code == 401, r1.status_code
t0 = time.time()
r2 = c.get('/api/update-status', auth=('a', 'WRONG'))
dt2 = time.time() - t0
assert r2.status_code == 401, r2.status_code
assert dt1 < 0.35, dt1
assert dt2 >= 0.45, dt2
print('X2 OK %.2f/%.2f' % (dt1, dt2))
PYX2
    grep -q '^X2 OK' "$F/x2.out" \
        && ok "X2: auth=None → 401 без sleep; неверные креды → с задержкой (FB-64/R55-02)" \
        || bad "X2: $(tail -3 "$F/x2.out" | tr '\n' ' ')"
else
    ok "X2: [SKIP] flask не установлен — гейт проверяется структурно в X8"
fi

# X3 (FB-65): 160 конкурентных _write_router_proto — 0 исключений.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x3.out" 2>&1 <<'PYX3'
import sys, os, importlib.util, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
tmp = tempfile.mkdtemp(prefix='kzx3_')
g.ROUTER_PROTO_FILE = os.path.join(tmp, 'router_proto')
errs = []
def w(i):
    try:
        g._write_router_proto('xray' if i % 2 else 'trojan')
    except Exception as e:
        errs.append(repr(e))
ts = [threading.Thread(target=w, args=(i,)) for i in range(160)]
for t in ts: t.start()
for t in ts: t.join()
val = open(g.ROUTER_PROTO_FILE).read().strip()
left = [f for f in os.listdir(tmp) if f.startswith('.router_proto.')]
assert not errs and val in ('xray', 'trojan') and not left, (len(errs), val, left)
print('X3 OK')
PYX3
    grep -q '^X3 OK' "$F/x3.out" \
        && ok "X3: _write_router_proto: 160 конкурентных — 0 ошибок, 0 tmp-остатков (было 25–46 FileNotFoundError; FB-65/R55-03)" \
        || bad "X3: $(tail -3 "$F/x3.out" | tr '\n' ' ')"
else
    ok "X3: [SKIP] flask не установлен — mkstemp проверяется структурно в X8"
fi

# X4 (FB-66): паритет 4 валидаторов hysteria — 15/15 (типы и маркеры).
X4="$F/x4"; mkdir -p "$X4"
awk '/^_nk_root_val\(\) \{/,/^\}$/' "$DEP" > "$X4/nk.sh"
# FB-89/FB-95: needs_key зовёт kz_json_root_str через _nk_root_val
awk '/^needs_key\(\) \{/,/^\}$/' "$DEP" >> "$X4/nk.sh"
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$X4/nk.sh"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$X4/s57gate.sh"
# FB-89: гейт зовёт kz_json_root_str (common.sh)
awk '/^kz_json_root_str\(\) \{/,/^\}$/' "$K/opt/bin/common.sh" >> "$X4/s57gate.sh"
python3 - "$K" "$X4" > "$F/x4.out" 2>&1 <<'PYX4'
import sys, os, json, tempfile, subprocess
K, X4 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import utils as u
def mk(cfg):
    fd, p = tempfile.mkstemp(suffix='.json'); os.close(fd)
    open(p, 'w').write(json.dumps(cfg)); return p
def nk(p):
    return subprocess.run(['sh', '-c', '. "$X4/nk.sh"; needs_key "$1" hysteria'.replace('$X4', X4),
                           'sh', p]).returncode
def pf(p):
    try:
        u._preflight_hysteria(p); return 'accept'
    except ValueError:
        return 'reject'
def s57(p):
    env = dict(os.environ, KEENZOO_HYSTERIA_CONFIG=p,
               KEENZOO_HYSTERIA_COMMON=K + '/opt/bin/common.sh',
               KEENZOO_HYSTERIA_PIDFILE=os.path.join(X4, 's57.pid'))
    r = subprocess.run(['sh', '-c', '. "' + X4 + '/s57gate.sh" 2>&1 | grep -q SKIPPED',
                        'sh', 'start'], env=env).returncode
    return r == 0
def cph(p):
    return 'reject' if u.config_has_placeholders(p, require_auth=True) else 'accept'
base = {"server": "real.example.org:443", "auth": "realkey",
        "tcpRedirect": {}, "udpTProxy": {}}
cases = []
c = mk({**base, "auth": 12345})
cases.append(('auth-число', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": "CHANGE_ME"})
cases.append(('server-CHANGE_ME', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk(base)
cases.append(('валидный', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "auth": "   "})
cases.append(('auth-пробелы: все принимают согласованно',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
# FB-96 (аудит-36, K61-03): auth — секрет, точный матч без
# host-нормализации: «change_me:443» — валидное значение
c = mk({**base, "auth": "change_me:443"})
cases.append(('auth-change_me:443 (валидный секрет)',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
# FB-97 (K61-04): дубликат корневого ключа — fail-closed у всех
# (json.dumps дубликаты не создаёт — файлы пишем вручную)
fdup, fdupn = tempfile.mkstemp(suffix='.json'); os.close(fdup)
open(fdupn, 'w').write('{ "server": "real.example.org:443", "auth": "a", "auth": "realkey" }')
cases.append(('дубликат auth — fail-closed', nk(fdupn) == 0, pf(fdupn) == 'reject',
              s57(fdupn), cph(fdupn) == 'reject'))
fdup2, fdup2n = tempfile.mkstemp(suffix='.json'); os.close(fdup2)
open(fdup2n, 'w').write('{ "server": "a.com", "server": "real.example.org:443", "auth": "realkey" }')
cases.append(('дубликат server — fail-closed', nk(fdup2n) == 0, pf(fdup2n) == 'reject',
              s57(fdup2n), cph(fdup2n) == 'reject'))
# FB-98 (K61-04b): маркер через \u-эскейп декодируется и ловится
fesc, fescn = tempfile.mkstemp(suffix='.json'); os.close(fesc)
open(fescn, 'w').write('{ "server": "real.example.org:443", "auth": "change\\u005fme" }')
cases.append(('auth через u-эскейп — заглушка', nk(fescn) == 0, pf(fescn) == 'reject',
              s57(fescn), cph(fescn) == 'reject'))
# вложенный tls.auth — корневым auth не является
c = mk({**base, "tls": {"auth": "change_me"}})
cases.append(('вложенный tls.auth не отменяет валидный root auth',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "server": "   "})
cases.append(('server-пробелы: все принимают согласованно',
              nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "auth": "CHANGE_ME"})
cases.append(('auth-CHANGE_ME', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
# FB-74 (аудит-33, K58-2/R58-05): server-заглушка example.com —
# прежде preflight пропускал; нормализация: порт/регистр/конечная
# точка/нестроковое значение. sni-исключение (FB-31) — сохранено.
c = mk({**base, "server": "example.com:443"})
cases.append(('server-example.com:443', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": "EXAMPLE.com:443"})
cases.append(('server-EXAMPLE.com (регистр)', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": "example.com."})
cases.append(('server-example.com. (FQDN-точка)', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "server": 123})
cases.append(('server-число', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "tls": {"sni": "example.com"}})
cases.append(('sni-example.com: легальная маскировка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
# FB-89 (аудит-35, R59-04/K60-04): точечный матч (не substring) и
# регистронезависимые auth-маркеры; вложенный tls.server — маскировка
c = mk({**base, "server": "fooexample.com"})
cases.append(('server-fooexample.com: не заглушка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "server": "sub.example.com"})
cases.append(('server-sub.example.com: не заглушка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
c = mk({**base, "auth": "change_me"})
cases.append(('auth-change_me (регистр)', nk(c) == 0, pf(c) == 'reject', s57(c), cph(c) == 'reject'))
c = mk({**base, "tls": {"server": "example.com"}})
cases.append(('вложенный tls.server=example.com: маскировка', nk(c) == 1, pf(c) == 'accept', not s57(c), cph(c) == 'accept'))
for name, a, b, cc, d in cases:
    assert a and b and cc and d, (name, a, b, cc, d)
print('X4 OK %d кейсов' % len(cases))
PYX4
grep -q '^X4 OK' "$F/x4.out" \
    && ok "X4: hysteria-валидаторы: auth-число/CHANGE_ME/change_me/пробелы, server-CHANGE_ME/example.com (порт, регистр, точка, число) — rej; fooexample/sub.example/sni/tls.server-маскировка — accept; единый вердикт у всех 4 (FB-66+FB-74+FB-89)" \
    || bad "X4: $(tail -3 "$F/x4.out" | tr '\n' ' ')"

# X5 (FB-67): возрастная уборка сирот lists_core.
X5="$F/x5"; mkdir -p "$X5"
python3 - "$K" "$X5" > "$F/x5.out" 2>&1 <<'PYX5'
import sys, os, time, tempfile
K, X5 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import lists_core as lc
fp = os.path.join(X5, 'tr.txt')
open(fp, 'w').write('base.example\n')
old = os.path.join(X5, '.tr.txt.orphan.tmp')
open(old, 'w').write('x')
os.utime(old, (time.time() - 7200, time.time() - 7200))
fresh = os.path.join(X5, '.tr.txt.fresh.tmp')
open(fresh, 'w').write('y')
lc._atomic_write_text(fp, open(fp).read() + 'more.example\n')
assert not os.path.exists(old), 'сирота не убран'
assert os.path.exists(fresh), 'свежий tmp тронут!'
assert 'more.example' in open(fp).read()
print('X5 OK')
PYX5
grep -q '^X5 OK' "$F/x5.out" \
    && ok "X5: _atomic_write_text: сирота >1ч убран, свежий tmp активного writer'а цел (FB-67/R55-06)" \
    || bad "X5: $(tail -3 "$F/x5.out" | tr '\n' ' ')"

# X6 (FB-68): /api/cfg/<which> возвращает warnings (реюз keys_bridges_warnings).
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/x6.out" 2>&1 <<'PYX6'
import sys, os, re, json, importlib.util, tempfile
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzx6_')
hy_path = os.path.join(tmp, 'hysteria.json')
g.config.paths['hysteria_config'] = hy_path
g.config.paths['hysteria_dir'] = tmp
g.config.paths['init_hysteria'] = os.path.join(tmp, 'no-init-script')
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/?tab=hy', auth=('a', 'b')).data.decode()
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
cfg = {"server": "real.example.org:443", "auth": "realkey",
       "tcpRedirect": {}, "udpTProxy": {}}
r = c.post('/api/cfg/hy',
           data={'csrf_token': token, 'content': json.dumps(cfg)},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 200, (r.status_code, r.data[:200])
j = r.get_json()
assert 'warnings' in j and isinstance(j['warnings'], list), j
print('X6 OK warnings=%r' % j['warnings'])
PYX6
    grep -q '^X6 OK' "$F/x6.out" \
        && ok "X6: /api/cfg: успешный ответ содержит warnings (JS-ветка j.warnings достижима; FB-68/R55-08)" \
        || bad "X6: $(tail -3 "$F/x6.out" | tr '\n' ' ')"
else
    ok "X6: [SKIP] flask не установлен — warnings проверяются структурно в X8"
fi

# X7 (FB-69): check_failed читается ботом (структурно + producer).
X7B=""
grep -q "check_failed" "$K/opt/etc/bot/handlers.py" || X7B="$X7B handlers-не-читает"
grep -q 'Проверка обновлений не завершена' "$K/opt/etc/bot/handlers.py" \
    || X7B="$X7B нет-честного-текста"
grep -q 'check_failed' "$K/opt/bin/check_updates.sh" || X7B="$X7B producer-без-поля"
if [ -z "$X7B" ]; then
    ok "X7: бот: check_failed из статуса → «⚠️ Проверка не завершена» вместо «✅ Всё актуально» (FB-69/R54-04)"
else
    bad "X7:$X7B"
fi

# X8: структурные маркеры FB-63..FB-69.
X8B=""
grep -q '_list_write_guard' "$K/opt/etc/bot/lists_core.py" || X8B="$X8B нет-guard"
grep -q '_list_write_guard' "$K/opt/etc/bot/generator.py" || X8B="$X8B guard-не-в-generator"
grep -q 'name="rev"' "$GEN" || X8B="$X8B нет-rev-поля"
grep -q 'if auth is not None:' "$GEN" || X8B="$X8B нет-гейта-sleep"
grep -q '_ROUTER_PROTO_LOCK' "$GEN" || X8B="$X8B нет-lock-router-proto"
grep -q "change_me|)" "$S57" || X8B="$X8B S57-без-change_me"
grep -q 'keys_bridges_warnings' "$GEN" || X8B="$X8B warnings-не-подключены"
grep -q 'FB-63 (аудит-32' "$K/opt/etc/bot/lists_core.py" || X8B="$X8B FB-63"
grep -q 'FB-64 (аудит-32' "$GEN" || X8B="$X8B FB-64"
grep -q 'FB-65 (аудит-32' "$GEN" || X8B="$X8B FB-65"
grep -q 'FB-66 (аудит-32' "$K/opt/etc/bot/utils.py" || X8B="$X8B FB-66(utils)"
grep -q 'FB-66 (аудит-32' "$S57" || X8B="$X8B FB-66(S57)"
grep -q 'FB-67 (аудит-32' "$K/opt/etc/bot/lists_core.py" || X8B="$X8B FB-67"
grep -q 'FB-68 (аудит-32' "$GEN" || X8B="$X8B FB-68"
grep -q 'FB-69 (аудит-32' "$K/opt/etc/bot/handlers.py" || X8B="$X8B FB-69"
if [ -z "$X8B" ]; then
    ok "X8: маркеры FB-63..FB-69, rev-поле, guard, lock, S57-change_me — на местах"
else
    bad "X8:$X8B"
fi

# ═══ Y. Аудит-33: атомарный rev, DNS-гейт, консент-фиды, статусы ═══
echo "═══ Y. Аудит-33 (отчёты r58): rev-атомарность, DNS-гейт, консент, частичный статус ═══"
CU="$K/opt/bin/check_updates.sh"
UPD="$K/opt/bin/update_protocols.sh"
UDNS="$K/opt/bin/unblock_dnsmasq.sh"

# Y0: структурные маркеры FB-70..FB-77 + гейты.
Y0B=""
grep -q 'FB-70 (аудит-33' "$K/opt/etc/bot/lists_core.py" || Y0B="$Y0B FB-70(lc)"
grep -q 'FB-70 (аудит-33' "$GEN" || Y0B="$Y0B FB-70(gen)"
grep -q 'ListRevisionConflict' "$GEN" || Y0B="$Y0B конфликт-класс-не-в-маршруте"
grep -q 'parse_and_save_if_revision' "$GEN" || Y0B="$Y0B маршрут-не-использует-caw"
grep -q 'FB-71 (аудит-33' "$DEP" || Y0B="$Y0B FB-71"
grep -q 'FB-72 (аудит-33' "$DEP" || Y0B="$Y0B FB-72"
grep -q 'FB-73 (аудит-33' "$CU" || Y0B="$Y0B FB-73"
grep -q 'd.check_failed' "$GEN" || Y0B="$Y0B панель-не-читает-check_failed"
grep -q 'Проверка неполная' "$CU" || Y0B="$Y0B TG-без-предупреждения"
grep -q 'FB-74 (аудит-33' "$K/opt/etc/bot/utils.py" || Y0B="$Y0B FB-74(utils)"
grep -q 'FB-74 (аудит-33' "$DEP" || Y0B="$Y0B FB-74(dep)"
grep -q 'FB-74 (аудит-33' "$S57" || Y0B="$Y0B FB-74(S57)"
grep -q 'FB-75 (аудит-33' "$DEP" || Y0B="$Y0B FB-75"
grep -q 'FB-76 (аудит-33' "$DEP" || Y0B="$Y0B FB-76"
grep -q 'DNS_OVERRIDE_OK' "$DEP" || Y0B="$Y0B нет-DNS-гейта-в-тексте"
grep -q 'KEENZOO_DLTMP должен быть абсолютным' "$DEP" || Y0B="$Y0B нет-DLTMP-отказа"
if [ -z "$Y0B" ]; then
    ok "Y0: маркеры FB-70..FB-76, конфликт-класс в маршруте, DNS-гейт, DLTMP-отказ — на местах"
else
    bad "Y0:$Y0B"
fi

# Y1 (FB-70): compare-and-write — семантика ревизий (unit).
Y1="$F/y1"; mkdir -p "$Y1"
python3 - "$K" "$Y1" > "$F/y1.out" 2>&1 <<'PYY1'
import sys, os, importlib.util
K, Y1 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import bot_config as config
for k in config.list_files:
    config.list_files[k] = os.path.join(Y1, os.path.basename(config.list_files[k]))
config.paths['hysteria_dir'] = Y1
config.paths['hysteria_config'] = os.path.join(Y1, 'hy.json')
spec = importlib.util.spec_from_file_location('lc', K + '/opt/etc/bot/lists_core.py')
lc = importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)
lc.UNBLOCK_DIR = Y1 + '/'
fp = os.path.join(Y1, 'list.txt')
# отсутствующий файл + rev='' (bootstrap) — запись проходит
r = lc.parse_and_save_if_revision(fp, 'a.example.org\nb.example.org', expected_rev='')
assert r['domains'] == 2, r
# rev содержимого — повторная запись проходит
rev = lc._list_content_rev(fp)
lc.parse_and_save_if_revision(fp, 'c.example.org', expected_rev=rev)
# идемпотентность rev: no-op перезапись НЕ меняет ревизию (прежде
# mtime_ns менялся от каждого касания — ложные конфликты рендера)
rev2 = lc._list_content_rev(fp)
lc.parse_and_save_if_revision(fp, 'c.example.org', expected_rev=rev2)
assert lc._list_content_rev(fp) == rev2, 'rev нестабилен при no-op записи'
# устаревший rev — конфликт, файл не тронут
try:
    lc.parse_and_save_if_revision(fp, 'STALE.example', expected_rev=rev)
    raise AssertionError('stale-rev прошёл!')
except lc.ListRevisionConflict:
    pass
assert 'STALE' not in open(fp).read()
# strict: пустой rev при существующем файле — конфликт
try:
    lc.parse_and_save_if_revision(fp, 'NOREV.example', expected_rev='')
    raise AssertionError('пустой rev прошёл!')
except lc.ListRevisionConflict:
    pass
assert 'NOREV' not in open(fp).read()
# различие отсутствующего и пустого файла: пустой имеет sha256('')
open(fp, 'w').close()
assert len(lc._list_content_rev(fp)) == 64 and lc._list_content_rev(fp) != ''
os.remove(fp)
assert lc._list_content_rev(fp) == ''
print('Y1 OK')
PYY1
grep -q '^Y1 OK' "$F/y1.out" \
    && ok "Y1: compare-and-write: bootstrap-запись, no-op ревизия стабильна, stale/пустой rev → конфликт, отсутствующий ≠ пустой (FB-70/K58-1)" \
    || bad "Y1: $(tail -3 "$F/y1.out" | tr '\n' ' ')"

# Y2 (FB-70): rev-проверка ВНУТРИ guard (check/lock-интерливинг закрыт).
python3 - "$K" "$Y1" > "$F/y2.out" 2>&1 <<'PYY2'
import sys, os, importlib.util
from contextlib import contextmanager
K, Y1 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('lc', K + '/opt/etc/bot/lists_core.py')
lc = importlib.util.module_from_spec(spec); spec.loader.exec_module(lc)
lc.UNBLOCK_DIR = Y1 + '/'
fp = os.path.join(Y1, 'race.txt')
open(fp, 'w').write('x.example\n')
state = {'depth': 0, 'checked_under_guard': None}
_orig_guard, _orig_rev = lc._list_write_guard, lc._list_content_rev
@contextmanager
def probe_guard(filepath):
    state['depth'] += 1
    try:
        with _orig_guard(filepath):
            yield
    finally:
        state['depth'] -= 1
def probe_rev(p):
    if p == fp and state['checked_under_guard'] is None:
        state['checked_under_guard'] = state['depth'] > 0
    return _orig_rev(p)
lc._list_write_guard = probe_guard
lc._list_content_rev = probe_rev
lc.parse_and_save_if_revision(fp, 'y.example\n', expected_rev=_orig_rev(fp))
assert state['checked_under_guard'] is True, \
    'rev-проверка вне guard — TOCTOU-окно (check/lock-интерливинг) открыто!'
print('Y2 OK')
PYY2
grep -q '^Y2 OK' "$F/y2.out" \
    && ok "Y2: _list_content_rev вызывается под guard — сравнение и запись в одной критической секции, TOCTOU-окно закрыто (FB-70/K58-1)" \
    || bad "Y2: $(tail -3 "$F/y2.out" | tr '\n' ' ')"

# Y3 (FB-70): маршрут — bootstrap-форма без rev на ОТСУТСТВУЮЩЕМ файле.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/y3.out" 2>&1 <<'PYY3'
import sys, os, importlib.util, tempfile
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzy3_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
g.BYPASS_FILES = {n: p for n, p in g.config.list_files.items() if n != 'bot'}
g.BOT_BYPASS_FILE = g.config.list_files['bot']
import lists_core
lists_core.UNBLOCK_DIR = tmp
# файл trojan.txt НЕ создаём: bootstrap-форма (без rev) обязана
# создать список с нуля — пустой expected_rev совпадает с ''
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/?tab=tr', auth=('a', 'b')).data.decode()
import re
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
assert not os.path.exists(g.config.list_files['trojan'])
r = c.post('/list/tr',
           data={'csrf_token': token, 'content': 'bootstrap.example\n'},
           headers={'Origin': 'http://localhost'}, auth=('a', 'b'))
assert r.status_code == 302, r.status_code
text = open(g.config.list_files['trojan']).read()
assert 'bootstrap.example' in text, 'bootstrap-форма без rev не сохранилась!'
print('Y3 OK')
PYY3
    grep -q '^Y3 OK' "$F/y3.out" \
        && ok "Y3: маршрут: отсутствующий файл + форма без rev → создание списка (bootstrap-путь strict не ломает) (FB-70)" \
        || bad "Y3: $(tail -3 "$F/y3.out" | tr '\n' ' ')"
else
    ok "Y3: [SKIP] flask не установлен — bootstrap-путь проверяется в Y1"
fi

# Y4 (FB-71): resolv.conf — гейт DNS_OVERRIDE_OK / проба до / откат после.
Y4="$F/y4"; mkdir -p "$Y4"
{ extract_fn _kz_dns_live "$DEP"; echo; extract_fn _kz_dns_probe_local "$DEP"; echo; extract_fn _kz_resolver_finalize "$DEP"; } > "$Y4/fn.sh"
cat > "$Y4/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/y4/fn.sh
warn() { printf '%s\n' "W|$*"; }
G_OK=$1; G_LIVE=$2; G_PROBE=$3; G_ENS=$4; G_POST=$5
DNS_OVERRIDE_OK=$G_OK; export DNS_OVERRIDE_OK
_kz_dns_live() { [ "$G_LIVE" = 1 ]; }
_kz_dns_probe_local() { return "$G_PROBE"; }
_kz_dns_probe_via_resolv() { return "$G_POST"; }
ensure_local_resolver() { [ "$G_ENS" = 1 ]; }
_kz_resolver_finalize
EOF
y4case() { # $1..$5 = ok/live/probe/ensure/post, $6 = ожидание, $7 = НЕДОПУСТИМОЕ, $8 = тег
    _o=$(sh "$Y4/run.sh" "$1" "$2" "$3" "$4" "$5" 2>&1)
    Y4R="$Y4R $8"
    printf '%s' "$_o" | grep -q "$6" || Y4B="$Y4B $8-нет-ожидалось"
    if [ -n "$7" ]; then
        printf '%s' "$_o" | grep -q "$7" && Y4B="$Y4B $8-лишнее"
    fi
}
Y4B=""; Y4R=""
y4case 0 1 0 1 0 'DNS Override не подтверждён' 'ENSURE' no-gate
y4case 1 0 0 1 0 'dnsmasq не работает' 'ENSURE' dead
y4case 1 1 1 1 0 'не отвечает на' 'ENSURE' probe-fail
y4case 1 1 0 0 0 'Не удалось установить nameserver' '' ensure-fail
y4case 1 1 0 1 1 'резолвинг не работает' '' post-fail
y4case 1 1 0 1 0 'работает через локальный dnsmasq' '' all-ok
# FB-83 (аудит-35, R59-01): «неизвестно» (нет nslookup/dig) —
# fail-closed: не переключаем ДО и откатываем ПОСЛЕ
y4case 1 1 2 1 0 'нет nslookup/dig' 'ENSURE' probe-unknown
y4case 1 1 0 1 2 'не подтверждён' 'работает через локальный' post-unknown
if [ -z "$Y4B" ]; then
    ok "Y4: finalize: без DNS_OVERRIDE_OK / мёртвый dnsmasq / проба fail / проба unknown (нет nslookup+dig) → resolv.conf не тронут; ensure fail → warn+восстановление; пост-чек fail/unknown → откат; всё живо → ✅ (FB-71+FB-83)"
else
    bad "Y4:$Y4B"
fi

# Y5 (FB-75): _kz_dns_live — procfs-fallback при отсутствии pidof.
Y5="$F/y5"; mkdir -p "$Y5/bin"
printf '#!/bin/sh\nexit 127\n' > "$Y5/bin/pidof"
chmod +x "$Y5/bin/pidof"
extract_fn _kz_dns_live "$DEP" > "$Y5/live.sh"
bash -c 'exec -a dnsmasq sleep 4' &
_fpid=$!
sleep 0.3
_o1=$(PATH="$Y5/bin:/usr/bin:/bin" sh -c '. /tmp/f47chk/y5/live.sh; _kz_dns_live; echo rc=$?')
kill "$_fpid" 2>/dev/null || true
wait "$_fpid" 2>/dev/null || true
_o2=$(PATH="$Y5/bin:/usr/bin:/bin" sh -c '. /tmp/f47chk/y5/live.sh; _kz_dns_live; echo rc=$?')
if [ "$_o1" = 'rc=0' ] && [ "$_o2" = 'rc=1' ]; then
    ok "Y5: _kz_dns_live без pidof: /proc/<pid>/cmdline находит dnsmasq (exec -a) и не находит после его смерти (FB-75/K57-3)"
else
    bad "Y5: found=[${_o1#rc=}] gone=[${_o2#rc=}]"
fi

# Y6 (FB-76): явный KEENZOO_DLTMP — абсолютность/mkdir/writable/die.
Y6="$F/y6"; mkdir -p "$Y6"
sed -n '/^KEENZOO_DLTMP=/,/^fi$/p' "$DEP" > "$Y6/block.sh"
cat > "$Y6/run.sh" <<'EOF'
#!/bin/sh
die() { echo "DIE|$*"; exit 1; }
KEENZOO_DLTMP="$1"
. /tmp/f47chk/y6/block.sh
echo "OK|$KEENZOO_DLTMP"
EOF
Y6B=""
_o=$(sh "$Y6/run.sh" "rel/path" 2>&1)
printf '%s' "$_o" | grep -q 'DIE|.*абсолютным' || Y6B="$Y6B relative-прошёл"
_o=$(sh "$Y6/run.sh" "/proc/nope/dl" 2>&1)
printf '%s' "$_o" | grep -q 'DIE|.*создать каталог' || Y6B="$Y6B mkdir-прошёл"
mkdir -p /tmp/f47chk/y6/ro && chmod 555 /tmp/f47chk/y6/ro
# сам каталог существует (mkdir -p ok), но не записываем — [ -w ] false
_o=$(sh "$Y6/run.sh" "/tmp/f47chk/y6/ro" 2>&1)
printf '%s' "$_o" | grep -q 'DIE|.*не доступен для записи' || Y6B="$Y6B writable-прошёл"
_o=$(sh "$Y6/run.sh" "/tmp/f47chk/y6/dl" 2>&1)
printf '%s' "$_o" | grep -q '^OK|/tmp/f47chk/y6/dl$' || Y6B="$Y6B ok-ветка-сломана"
[ -d /tmp/f47chk/y6/dl ] || Y6B="$Y6B каталог-не-создан"
# дефолт-ветка: пустое значение → прежний дефолт без DIE (mkdir в
# /opt/share или /tmp) — регресс FB-76 не ломает подбор по умолчанию
_o=$(KEENZOO_DLTMP= sh "$Y6/run.sh" "" 2>&1 || true)
case "$_o" in
    DIE*) Y6B="$Y6B дефолт-ветка-умерла" ;;
    OK\|*) : ;;
    *) : ;;
esac
if [ -z "$Y6B" ]; then
    ok "Y6: явный KEENZOO_DLTMP: относительный/несоздаваемый/незаписываемый → ранний die с причиной; валидный → mkdir+OK; дефолт-ветка не сломана (FB-76/N58-1)"
else
    bad "Y6:$Y6B"
fi

# Y7 (FB-72/FB-78): флип без сторонних фидов — http-фида больше нет:
# гейт открыт БЕЗ согласия (в авто-режиме согласия не существует вовсе).
w0reset
grep -v '^src custom' "$W0/opkg.conf" > "$W0/opkg.conf.n" && mv "$W0/opkg.conf.n" "$W0/opkg.conf"
cp -p "$W0/opkg.conf" "$W0/opkg.conf.orig"
_o=$(printf '\n' | script -qec "sh $W0/drv.sh" /dev/null 2>&1 | tr -d '\r')
Y7B=""
printf '%s' "$_o" | grep -q 'GATE=PASS' || Y7B="$Y7B гейт-закрыт-без-остаточных"
printf '%s' "$_o" | grep -q 'CONSENT=1' && Y7B="$Y7B согласие-появилось-в-авто-режиме"
printf '%s' "$_o" | grep -q 'НЕ распространяется' && Y7B="$Y7B ложный-сброс"
if [ -z "$Y7B" ]; then
    ok "Y7: флип без сторонних http-фидов: гейт открыт (http-фида больше нет), согласие в авто-режиме не возникает (FB-72/FB-78/K57-1)"
else
    bad "Y7:$Y7B"
fi

# Y8 (FB-73): per-source статусы — частичный провал = check_failed.
Y8="$F/y8"; mkdir -p "$Y8"
sed -n '/^SRC_OPKG=ok/,/^    CHECK_FAILED=1$/p' "$CU" > "$Y8/src.sh"
echo 'fi' >> "$Y8/src.sh"
y8run() { # opkg_rc xgh_ok xgh hy_ok hy expected_cf tag
    _cf=$(OPKG_UPD_RC=$1 XRAY_GH_OK=$2 XRAY_GH=$3 HY_GH_OK=$4 HY_GH=$5 \
        sh -c '. /tmp/f47chk/y8/src.sh; printf %s "$CHECK_FAILED"')
    Y8R="$Y8R $7=$_cf"
    [ "$_cf" = "$6" ] || Y8B="$Y8B $7"
}
Y8B=""; Y8R=""
y8run 0 1 v25 1 v2  0 all-ok
y8run 0 1 ''  1 v2  1 gh-xray-down
y8run 1 1 v25 1 v2  1 opkg-down-gh-up
y8run 1 1 ''  1 ''  1 total-down
y8run 1 0 ''  0 ''  1 be-mips-opkg-down
y8run 0 0 ''  0 ''  0 be-mips-opkg-ok
_src=$(OPKG_UPD_RC=1 XRAY_GH_OK=1 XRAY_GH= HY_GH_OK=0 HY_GH= \
    sh -c '. /tmp/f47chk/y8/src.sh; printf "%s/%s/%s" "$SRC_OPKG" "$SRC_XRAY_GH" "$SRC_HY_GH"')
[ "$_src" = 'fail/fail/na' ] || Y8B="$Y8B sources-матрица[$_src]"
grep -q 'SRC_HY_GH' "$CU" || Y8B="$Y8B нет-SRC_HY_GH-в-JSON-строке"
if [ -z "$Y8B" ]; then
    ok "Y8: check_updates: 6 сценариев per-source (частичный провал=check_failed; BE-MIPS GH=na не ошибка; opkg-down при живом GH теперь честный fail) + sources в JSON (FB-73/R58-03)"
else
    bad "Y8:$Y8B ($Y8R)"
fi

# Y9 (FB-77, релиз): INSTALL r63 — menu-SHA сверен, подписи редакции 63.
INS63=$(ls /home/user/INSTALL_*-63_DETAILED.md 2>/dev/null | head -1)
if [ -n "$INS63" ] && [ -f /home/user/KeenZOO_menu.sh ]; then
    Y9B=""
    _msha=$(sha256sum /home/user/KeenZOO_menu.sh | awk '{print $1}')
    grep -q "$_msha" "$INS63" || Y9B="$Y9B menu-SHA-не-сверён-с-фактом"
    grep -q '3b005e96' "$INS63" && Y9B="$Y9B старый-r62-SHA-остался"
    grep -qE 'редакци(i|я) 62' "$INS63" && Y9B="$Y9B подписи-редакции-62-в-форме-опечатки"
    grep -q 'редакции 63' "$INS63" || Y9B="$Y9B нет-подписей-редакции-63"
    if [ -z "$Y9B" ]; then
        ok "Y9: INSTALL_63: menu-SHA = sha256(KeenZOO_menu.sh), подписи «редакции 63», r62-SHA отсутствует (FB-77/K58-3)"
    else
        bad "Y9:$Y9B"
    fi
else
    ok "Y9: [SKIP] INSTALL_63 ещё не собран — проверка сработает на релизном прогоне (FB-77)"
fi

# ═══ Z. Аудит-35 (внешние отчёты r60): FB-82..FB-90, K60-01, миноры ═══
echo "═══ Z. Аудит-35: транзакционность, fail-closed, изоляция, паритет ═══"

# Z0: структурные маркеры всех правок аудита-35.
Z0B=""
for _z0 in 'FB-82 (аудит-35' 'FB-83 (аудит-35' 'FB-84 (аудит-35' 'FB-85 (аудит-35' 'FB-89 (аудит-35'; do
    grep -q "$_z0" "$DEP" || Z0B="$Z0B нет-$_z0(deploy)"
done
grep -q 'FB-86 (аудит-35' "$GEN" || Z0B="$Z0B нет-FB-86(generator)"
grep -q 'FB-87 (аудит-35' "$GEN" || Z0B="$Z0B нет-FB-87(generator)"
grep -q 'FB-88 (аудит-35' "$CU" || Z0B="$Z0B нет-FB-88(check_updates)"
grep -q 'FB-90 (аудит-35' "$UPD" || Z0B="$Z0B нет-FB-90(update_protocols)"
grep -q 'FB-89 (аудит-35' "$S57" || Z0B="$Z0B нет-FB-89(S57)"
grep -q 'FB-89' "$UDNS" || Z0B="$Z0B нет-FB-89(unblock_dnsmasq)"
grep -q 'FB-89 (аудит-35' "$K/opt/etc/bot/utils.py" || Z0B="$Z0B нет-FB-89(utils)"
grep -q 'kz_json_root_str() {' "$K/opt/bin/common.sh" || Z0B="$Z0B нет-kz_json_root_str"
grep -q 'K60-01' "$DEP" || Z0B="$Z0B нет-K60-01"
grep -q 'K60-05' "$K/opt/etc/bot/main.py" || Z0B="$Z0B нет-K60-05(main)"
grep -q 'K60-05' "$GEN" || Z0B="$Z0B нет-K60-05(generator)"
if [ -z "$Z0B" ]; then
    ok "Z0: маркеры FB-82..FB-90 + K60-01/K60-05 + kz_json_root_str — во всех правленых файлах"
else
    bad "Z0:$Z0B"
fi

# Z1 (FB-90): KEENZOO_DLTMP в update_protocols — семантика deploy (FB-76).
Z1="$F/z1"; mkdir -p "$Z1"
sed -n '/^KEENZOO_DLTMP=/,/^fi$/p' "$UPD" > "$Z1/block.sh"
cat > "$Z1/run.sh" <<'EOF'
#!/bin/sh
KEENZOO_DLTMP="$1"
. /tmp/f47chk/z1/block.sh
echo "OK|$KEENZOO_DLTMP"
EOF
Z1B=""
_o=$(sh "$Z1/run.sh" "rel/path" 2>&1); rc=$?
[ "$rc" = 1 ] || Z1B="$Z1B relative-не-die"
printf '%s' "$_o" | grep -q 'абсолютным' || Z1B="$Z1B relative-без-причины"
printf 'x' > /tmp/f47chk/z1/afile
_o=$(sh "$Z1/run.sh" "/tmp/f47chk/z1/afile" 2>&1); rc=$?
[ "$rc" = 1 ] || Z1B="$Z1B файл-не-die"
printf '%s' "$_o" | grep -q 'файл, а не каталог' || Z1B="$Z1B файл-без-причины"
mkdir -p /tmp/f47chk/z1/ro && chmod 555 /tmp/f47chk/z1/ro
_o=$(sh "$Z1/run.sh" "/tmp/f47chk/z1/ro" 2>&1); rc=$?
[ "$rc" = 1 ] || Z1B="$Z1B ro-не-die"
printf '%s' "$_o" | grep -q 'не доступен для записи' || Z1B="$Z1B ro-без-причины"
_o=$(sh "$Z1/run.sh" "" 2>&1)
case "$_o" in
    OK\|*) : ;;
    *) Z1B="$Z1B дефолт-ветка-сломана" ;;
esac
if [ -z "$Z1B" ]; then
    ok "Z1: update_protocols KEENZOO_DLTMP: относительный/файл/незаписываемый → die с причиной; пустой → авто-выбор (FB-90/R59-05, семантика FB-76)"
else
    bad "Z1:$Z1B"
fi

# Z2 (FB-87): лимит строк → ValueError из lists_core; маршрут ловит и
# отвечает flash+redirect (не HTTP 500).
Z2="$F/z2"; mkdir -p "$Z2"
Z2B=""
python3 - "$K" "$Z2" > "$F/z2.out" 2>&1 <<'PYZ2'
import sys, os
K, Z2 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import lists_core as lc
lc.UNBLOCK_DIR = Z2
fp = os.path.join(Z2, 'big.txt')
big = '\n'.join('d%d.example' % i for i in range(lc.MAX_LIST_LINES + 5)) + '\n'
open(fp, 'w').write('old\n')
try:
    lc._parse_and_save_impl(fp, big)
    print('NO-VALUEERROR')
except ValueError as e:
    print('VE|' + str(e))
PYZ2
grep -q '^VE|Строк:' "$F/z2.out" || Z2B="$Z2B lists_core-не-кидает"
grep -q 'except ValueError' "$GEN" || Z2B="$Z2B маршрут-не-ловит"
grep -q 'слишком большой список' "$GEN" || Z2B="$Z2B нет-flash-текста"
grep -q 'MAX_LIST_LINES' "$GEN" || Z2B="$Z2B лимит-не-упомянут"
if [ -z "$Z2B" ]; then
    ok "Z2: превышение MAX_LIST_LINES → ValueError «Строк: N» (lists_core); маршрут — flash с лимитом + redirect, не 500 (FB-87/K60-03)"
else
    bad "Z2:$Z2B"
fi

# Z3 (FB-88): check_updates — единый kz_resolve_binaries, локальная
# case-матрица и cu_is_mips_le удалены; BE-MIPS Xray=GH согласован.
Z3B=""
grep -q 'kz_resolve_binaries "$ARCH"' "$CU" || Z3B="$Z3B нет-общего-резолвера"
grep -q 'cu_is_mips_le() {' "$CU" && Z3B="$Z3B осталась-локальная-is_mips_le"
grep -q 'XRAY_GH_OK=0' "$CU" || Z3B="$Z3B нет-инициализации-fail-closed"
grep -q 'FB-88 (аудит-35, R59-03' "$CU" || Z3B="$Z3B нет-комментараря-мотивации"
if [ -z "$Z3B" ]; then
    ok "Z3: check_updates: XRAY_GH_OK/HY_GH_OK из kz_resolve_binaries (rc 1 → оба 0, fail-closed; BE-MIPS Xray=GH как в deploy) (FB-88/R59-03)"
else
    bad "Z3:$Z3B"
fi

# Z4 (FB-86): _list_snap — один снимок байтов даёт и текст, и rev.
Z4="$F/z4"; mkdir -p "$Z4"
python3 - "$K" "$Z4" > "$F/z4.out" 2>&1 <<'PYZ4'
import sys, os, hashlib
K, Z4 = sys.argv[1], sys.argv[2]
sys.path.insert(0, K + '/opt/etc/bot')
import generator as g
fp = os.path.join(Z4, 'l.txt')
raw = 'a.example\nb.example\n\n'
open(fp, 'wb').write(raw.encode())
text, rev = g._list_snap(fp)
assert text == 'a.example\nb.example', repr(text)
assert rev == hashlib.sha256(raw.encode()).hexdigest(), 'rev != sha256'
raw2 = 'x.example'  # без завершающего перевода строки
open(fp, 'wb').write(raw2.encode())
text, rev = g._list_snap(fp)
assert text == 'x.example' and rev == hashlib.sha256(raw2.encode()).hexdigest()
text, rev = g._list_snap(os.path.join(Z4, 'missing.txt'))
assert text == '' and rev == hashlib.sha256(b'').hexdigest(), 'нет файла'
print('Z4 OK')
PYZ4
grep -q '^Z4 OK' "$F/z4.out" \
    && ok "Z4: _list_snap: один снимок байтов → текст (rstrip-семантика read_file_text) + rev=sha256; отсутствующий файл → ('', пустой-хэш) (FB-86/R59-02)" \
    || bad "Z4: $(tail -2 "$F/z4.out" | tr '\n' ' ')"

# Z5 (FB-82): _kz_dns_override_enable — save-провал = не подтверждено
# + откат на системный DNS; успешный save → подтверждено.
Z5="$F/z5"; mkdir -p "$Z5/bin"
{ extract_fn _kz_dns_override_on "$DEP"; echo; extract_fn _kz_dns_override_enable "$DEP"; } > "$Z5/fn.sh"
cat > "$Z5/bin/ndmc" <<'EOF'
#!/bin/sh
echo "ndmc $*" >> /tmp/f47chk/z5/journal
case "$*" in
  *'show running-config'*)
    [ "$(cat /tmp/f47chk/z5/state 2>/dev/null)" = on ] && echo 'opkg dns-override'
    exit 0 ;;
  *'system configuration save'*)
    [ -f /tmp/f47chk/z5/save_fails ] && exit 1
    exit 0 ;;
  *'no opkg dns-override'*) echo off > /tmp/f47chk/z5/state ;;
  *'opkg dns-override'*) echo on > /tmp/f47chk/z5/state ;;
esac
exit 0
EOF
chmod +x "$Z5/bin/ndmc"
cat > "$Z5/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/z5/fn.sh
warn() { printf '%s\n' "W|$*"; }
PATH="/tmp/f47chk/z5/bin:/usr/bin:/bin"; export PATH
echo off > /tmp/f47chk/z5/state
_kz_dns_override_enable
echo "rc=$? state=$(cat /tmp/f47chk/z5/state)"
EOF
chmod +x "$Z5/run.sh"
Z5B=""
rm -f "$Z5/save_fails" "$Z5/journal"
_o=$(sh "$Z5/run.sh" 2>&1)
printf '%s' "$_o" | grep -q 'rc=0 state=on' || Z5B="$Z5B успешный-save-не-подтверждён"
rm -f "$Z5/journal"
: > "$Z5/save_fails"
_o=$(sh "$Z5/run.sh" 2>&1)
printf '%s' "$_o" | grep -q 'rc=1 state=off' || Z5B="$Z5B save-провал-без-отката"
printf '%s' "$_o" | grep -q 'не подтверждён' || Z5B="$Z5B нет-текста-неподтверждения"
grep -q 'ndmc -c no opkg dns-override$' "$Z5/journal" || Z5B="$Z5B нет-no-override-при-провале"
if [ -z "$Z5B" ]; then
    ok "Z5: dns-override enable: rc обоих ndmc учтён; save-провал → «не подтверждён» + возврат системного DNS (FB-82/R60-01)"
else
    bad "Z5:$Z5B"
fi

# Z6 (K60-01): изоляция бутстрапа — opkg -f с фильтром entware|keendev,
# отдельный lists_dir, `_kz_BOOTSTRAP_MISSING` без command substitution.
Z6B=""
grep -q 'opkg -f ' "$DEP" || Z6B="$Z6B нет-opkg--f"
grep -q '_kz_iso_conf_write() {' "$DEP" || Z6B="$Z6B нет-фильтра-конфига"
grep -q 'mktemp -d /tmp/.kz_iso_lists' "$DEP" || Z6B="$Z6B нет-отдельного-lists_dir"
grep -q 'KEENZOO_BOOTSTRAP_PROBE_MAX' "$DEP" || Z6B="$Z6B нет-бюджета-проб"
grep -q '_KZ_BOOTSTRAP_MISSING' "$DEP" || Z6B="$Z6B нет-глобального-missing"
printf '%s' "$(grep -c '\$(_kz_bootstrap_missing' "$DEP")" | grep -q '^0$' || Z6B="$Z6B missing-в-command-substitution"
if [ -z "$Z6B" ]; then
    ok "Z6: изолированный бутстрап: opkg -f + фильтр entware|keendev + отдельный lists_dir; список отсутствующих — глобаль (list-installed ×1); бюджет проб с KEENZOO_BOOTSTRAP_PROBE_MAX (K60-01 + миноры §5)"
else
    bad "Z6:$Z6B"
fi

# Z7 (K60-05): минимум Python в точках входа.
Z7B=""
grep -q 'sys.version_info < (3, 8)' "$K/opt/etc/bot/main.py" || Z7B="$Z7B main-без-чека"
grep -q 'sys.version_info < (3, 8)' "$GEN" || Z7B="$Z7B generator-без-чека"
grep -q 'требуется Python 3.8' "$K/opt/etc/bot/main.py" || Z7B="$Z7B main-без-сообщения"
if [ -z "$Z7B" ]; then
    ok "Z7: явный минимум Python 3.8 в main.py/generator.py с сообщением в stderr (K60-05)"
else
    bad "Z7:$Z7B"
fi


# ═══ Z-36. Аудит-36 (внешние отчёты r61): FB-91..FB-99 ═══
echo "═══ Z-36. Аудит-36: пробы ABI, override-откат, resolv-транзакция, tri-state ═══"

# Z36-1 (FB-92, R61-01): финализатор откатывает Override, включённый
# этим запуском, только при ПОДТВЕРЖДЁННОМ провале (rc=1); rc=2
# «не проверено» и чужой Override — не трогаем.
Z8="$F/z8"; mkdir -p "$Z8"
{ extract_fn _kz_dns_override_on "$DEP"; echo; extract_fn _kz_dns_override_disable "$DEP"; echo; extract_fn _kz_dns_self_revert "$DEP"; echo; extract_fn _kz_dns_live "$DEP"; echo; extract_fn _kz_dns_probe_local "$DEP"; echo; extract_fn _kz_resolver_finalize "$DEP"; } > "$Z8/fn.sh"
cat > "$Z8/bin-dir" <<'EOF'
EOF
mkdir -p "$Z8/bin"
cat > "$Z8/bin/ndmc" <<'EOF'
#!/bin/sh
echo "ndmc $*" >> /tmp/f47chk/z8/journal
case "$*" in
  *'show running-config'*) [ "$(cat /tmp/f47chk/z8/state 2>/dev/null)" = on ] && echo 'opkg dns-override' ;;
  *'no opkg dns-override'*) [ -f /tmp/f47chk/z8/fail_no ] && exit 1; echo off > /tmp/f47chk/z8/state ;;
  *'opkg dns-override'*) echo on > /tmp/f47chk/z8/state ;;
esac
exit 0
EOF
chmod +x "$Z8/bin/ndmc"
cat > "$Z8/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/z8/fn.sh
warn() { printf '%s
' "W|$*"; }
G_OK=$1; G_LIVE=$2; G_PROBE=$3; G_ENS=$4; G_POST=$5; G_SELF=$6
DNS_OVERRIDE_OK=$G_OK; DNS_OVERRIDE_SELF=$G_SELF; export DNS_OVERRIDE_OK DNS_OVERRIDE_SELF
_kz_dns_live() { [ "$G_LIVE" = 1 ]; }
_kz_dns_probe_local() { return "$G_PROBE"; }
_kz_dns_probe_via_resolv() { return "$G_POST"; }
ensure_local_resolver() { [ "$G_ENS" = 1 ]; }
_kz_resolver_finalize
EOF
z8case() { # ok live probe ensure post self — ждём-строка, недопустимое, тег
    _o=$(PATH="$Z8/bin:$PATH" sh "$Z8/run.sh" "$1" "$2" "$3" "$4" "$5" "$6" 2>&1)
    printf '%s' "$_o" | grep -q "$7" || Z8B="$Z8B $9-нет-ожидалось"
    if [ -n "$8" ]; then
        printf '%s' "$_o" | grep -q "$8" && Z8B="$Z8B $9-лишнее"
        grep -q 'no opkg dns-override' "$Z8/journal" && [ "$8" = "NOREVERT" ] && Z8B="$Z8B $9-лишний-no-override"
    fi
}
Z8B=""
: > "$Z8/journal"; echo on > "$Z8/state"; rm -f "$Z8/fail_no"
# пост-проба rc=1 (подтверждённый провал), наш override → откат:
# no-override + save + контроль show running-config
z8case 1 1 0 1 1 1 'откат (порт 53 возвращается системному DNS' '' self-post-fail
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B post-fail-нет-no-override"
grep -q 'system configuration save' "$Z8/journal" || Z8B="$Z8B post-fail-нет-save"
grep -q 'show running-config' "$Z8/journal" || Z8B="$Z8B post-fail-нет-контроля"
# пост-проба rc=2 (не проверено) → resolv откат, override НЕ трогаем
: > "$Z8/journal"
z8case 1 1 0 1 2 1 'не подтверждён' '' self-post-unknown
grep -q 'no opkg dns-override' "$Z8/journal" && Z8B="$Z8B post-unknown-лишний-no-override"
# dnsmasq мёртв, наш override → откат
: > "$Z8/journal"
z8case 1 0 0 1 0 1 'dnsmasq не работает' '' self-dead
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B dead-нет-no-override"
# локальная проба rc=1, наш override → откат
: > "$Z8/journal"
z8case 1 1 1 1 0 1 'не отвечает на' '' self-probe-fail
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B probe-fail-нет-no-override"
# чужой override (SELF=0) при провале → НЕ трогаем
: > "$Z8/journal"
z8case 1 1 0 1 1 0 'резолвинг не работает' '' foreign-no-revert
grep -q 'no opkg dns-override' "$Z8/journal" && Z8B="$Z8B foreign-лишний-no-override"
# откат не удался (no-override провалился) → ручные команды + честный
# вердикт; save при этом НЕ вызывается (транзакция прервана)
: > "$Z8/journal"; echo on > "$Z8/state"; : > "$Z8/fail_no"
z8case 1 1 0 1 1 1 'Не удалось отключить DNS Override' '' revert-fail
grep -q 'no opkg dns-override' "$Z8/journal" || Z8B="$Z8B revert-fail-нет-попытки"
grep -q 'system configuration save' "$Z8/journal" && Z8B="$Z8B revert-fail-лишний-save"
if [ -z "$Z8B" ]; then
    ok "Z36-1: финализатор: SELF+пост-fail/dead/probe-fail → no-override+save+контроль; rc=2 и SELF=0 → override не трогаем; отказ ndmc → ручные команды (FB-92/R61-01)"
else
    bad "Z36-1:$Z8B"
fi

# Z36-2 (FB-93/R61-02): resolv.conf — транзакция (бэкап cat+cmp,
# restore с проверкой, идемпотентность) на подменённом пути стенда.
Z9="$F/z9"; mkdir -p "$Z9/bin"
for _z9fn in dns_ok ensure_dns restore_dns; do
    awk -v f="$_z9fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP"
done | sed "s#/etc/resolv.conf#$Z9/resolv.conf#g" > "$Z9/fn.sh"
printf '#!/bin/sh\n[ -s /tmp/f47chk/z9/failmark ] && exit 1\nexit 0\n' > "$Z9/bin/nslookup"
chmod +x "$Z9/bin/nslookup"
cat > "$Z9/bin/cmp" <<'EOF'
#!/bin/sh
N="$(cat /tmp/f47chk/z9/cmpn 2>/dev/null || echo 0)"
N=$((N+1)); echo "$N" > /tmp/f47chk/z9/cmpn
[ "$N" -ge 2 ] && exit 1
exec /usr/bin/cmp "$@"
EOF
chmod +x "$Z9/bin/cmp"
cat > "$Z9/run.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/z9/fn.sh
warn() { printf '%s
' "W|$*" >&2; }
have_cmd() { command -v "$1" >/dev/null 2>&1; }
export PATH="/tmp/f47chk/z9/bin:$PATH"
RESOLV_BACKUP=""; RESOLV_TEMP_ACTIVE=0
case "$1" in
  sub)
    echo fail > /tmp/f47chk/z9/failmark
    printf 'nameserver 192.168.1.1
' > /tmp/f47chk/z9/resolv.conf
    ensure_dns >/dev/null 2>&1
    grep -q 1.1.1.1 /tmp/f47chk/z9/resolv.conf && echo "SUB=ok"
    [ "${RESOLV_TEMP_ACTIVE:-0}" = 1 ] && echo "FLAG=1"
    [ -n "$RESOLV_BACKUP" ] && echo "BAK=1"
    echo 0 > /tmp/f47chk/z9/cmpn
    restore_dns
    grep -q 192.168.1.1 /tmp/f47chk/z9/resolv.conf && echo "REST=ok"
    [ -z "${RESOLV_BACKUP:-}" ] && echo "BAKDEL=1"
    [ "${RESOLV_TEMP_ACTIVE:-1}" = 0 ] && echo "FLAG0=1"
    ;;
  restfail)
    echo fail > /tmp/f47chk/z9/failmark
    printf 'nameserver 192.168.1.1
' > /tmp/f47chk/z9/resolv.conf
    ensure_dns >/dev/null 2>&1
    restore_dns 2>&1 | sed -n '1p'
    [ -n "${RESOLV_BACKUP:-}" ] && [ -f "$RESOLV_BACKUP" ] && echo "BAKKEPT=1"
    ;;
esac
EOF
Z9B=""
: > "$Z9/failmark"; echo 0 > "$Z9/cmpn"
_o=$(sh "$Z9/run.sh" sub 2>&1)
for _z9e in 'SUB=ok' 'FLAG=1' 'BAK=1' 'REST=ok' 'BAKDEL=1' 'FLAG0=1'; do
    printf '%s' "$_o" | grep -q "$_z9e" || Z9B="$Z9B sub-нет-$_z9e"
done
echo 0 > "$Z9/cmpn"
_o=$(sh "$Z9/run.sh" restfail 2>&1)
printf '%s' "$_o" | grep -q 'бэкап СОХРАНЁН' || Z9B="$Z9B restfail-нет-сохранения"
printf '%s' "$_o" | grep -q 'BAKKEPT=1' || Z9B="$Z9B restfail-бэкап-удалён"
if [ -z "$Z9B" ]; then
    ok "Z36-2: resolv.conf: подмена только при сверином бэкапе (cat+cmp), RESOLV_TEMP_ACTIVE, restore подтверждает и удаляет бэкап; провал restore — бэкап сохранён + подсказка (FB-93/R61-02)"
else
    bad "Z36-2:$Z9B"
fi

# Z36-3 (FB-95, R61-05): needs_key в deploy-оболочке — common.sh
# подгружается лениво из _nk_root_val, без засорения основного shell.
Z10="$F/z10"; mkdir -p "$Z10"
awk 'index($0, "_nk_root_val() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$Z10/nk.sh"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$Z10/nk.sh"
printf '%s' '{ "server": "real.example.org:443", "auth": "realkey" }' > "$Z10/valid.json"
Z10B=""
_o=$(KEENZOO_DEPLOY_COMMON="$K/opt/bin/common.sh" sh -c \
    ". '$Z10/nk.sh'; needs_key '$Z10/valid.json' hysteria </dev/null"; echo "rc=$?")
printf '%s' "$_o" | grep -q 'rc=1' || Z10B="$Z10B lazy-не-настроен($_o)"
_o=$(sh -c ". '$Z10/nk.sh'; needs_key '$Z10/valid.json' hysteria </dev/null"; echo "rc=$?")
printf '%s' "$_o" | grep -q 'rc=0' || Z10B="$Z10B без-common-не-fail-closed($_o)"
# на роутере common.sh уже установлен — путь дефолтный /opt/bin/common.sh
grep -q 'KEENZOO_DEPLOY_COMMON:-/opt/bin/common.sh' "$DEP" || Z10B="$Z10B нет-дефолт-пути"
grep -q 'command -v kz_json_root_str' "$DEP" || Z10B="$Z10B нет-прямого-вызова"
if [ -z "$Z10B" ]; then
    ok "Z36-3: needs_key без предзагруженного common: helper через _nk_root_val (lazy-source субшеллом, env-override для стендов), отсутствие helper → rc 0 fail-closed (FB-95/R61-05)"
else
    bad "Z36-3:$Z10B"
fi

# Z36-4 (R61-06): dns_ok — tri-state 0/1/2.
Z11="$F/z11"; mkdir -p "$Z11/bin"
awk 'index($0, "dns_ok() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" \
    | sed "s#/etc/resolv.conf#$Z11/resolv.conf#g" > "$Z11/fn.sh"
printf '#!/bin/sh\nexit %s\n' 0 > "$Z11/bin/nslookup0"
printf '#!/bin/sh\nexit %s\n' 1 > "$Z11/bin/nslookup1"
chmod +x "$Z11/bin/nslookup0" "$Z11/bin/nslookup1"
printf 'nameserver 192.168.1.1
' > "$Z11/resolv.conf"
Z11B=""
mkdir -p "$Z11/binA" "$Z11/binB"
cp "$Z11/bin/nslookup0" "$Z11/binA/nslookup"; cp "$Z11/bin/nslookup1" "$Z11/binB/nslookup"
_dnsok() { # $1=каталог-префикс PATH → rc dns_ok
    PATH="$1:/usr/bin:/bin" sh -c ". '$Z11/fn.sh'; have_cmd() { command -v \"\$1\" >/dev/null 2>&1; }; dns_ok </dev/null"
    return $?
}
_dnsok "$Z11/bin"; [ $? = 2 ] || Z11B="$Z11B нет-nslookup-не-rc2"
_dnsok "$Z11/binA"; [ $? = 0 ] || Z11B="$Z11B ok-не-rc0"
_dnsok "$Z11/binB"; [ $? = 1 ] || Z11B="$Z11B fail-не-rc1"
# без инструментов и без nameserver → rc 1
: > "$Z11/resolv.conf"
_dnsok "$Z11/bin"; [ $? = 1 ] || Z11B="$Z11B пустой-resolv-не-rc1"
if [ -z "$Z11B" ]; then
    ok "Z36-4: dns_ok tri-state: разрешение подтверждено → 0; провал → 1; нет nslookup/dig + nameserver есть → 2 «не проверено» (ранее молчаливый 0) (R61-06)"
else
    bad "Z36-4:$Z11B"
fi

# Z36-5 (FB-91, K61-01): пробы фидов — только <base>/<ABI>/Packages.gz;
# нераспознанный ABI → зеркальный механизм не запускается.
Z12="$F/z12"; mkdir -p "$Z12"
awk 'index($0, "_entware_feed_abi() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$Z12/fn.sh"
Z12B=""
z12abi() { # url → ожидание
    _v=$(sh -c ". '$Z12/fn.sh'; _entware_feed_abi '$1' </dev/null")
    [ "$_v" = "$2" ] || Z12B="$Z12B abi($1)='$_v'"
}
z12abi 'http://bin.entware.net/mipssf-k3.4' 'mipssf-k3.4'
z12abi 'https://bin.entware.net/aarch64-k3.10' 'aarch64-k3.10'
z12abi 'https://mirrors.bfsu.edu.cn/entware/armv7sf-k3.2/' 'armv7sf-k3.2'
z12abi 'http://bin.entware.net/x64-k3.2/keendev/Packages.gz' 'x64-k3.2'
z12abi 'http://bin.entware.net/unknown-branch' ''
z12abi 'not-a-url' ''
# пробы всех трёх мест идут с ABI-сегментом
grep -q '_entware_probe_feed_url "\${_kzb_base%/}/\${_kzb_abi}"' "$DEP" || Z12B="$Z12B нет-пробы-текущего-фida-с-ABI"
grep -q '_entware_probe_feed_url "\${_kzb_cand%/}/\${_kzb_abi}"' "$DEP" || Z12B="$Z12B нет-пробы-зеркала-с-ABI"
grep -q '_entware_probe_feed_url "\${_kzf_cand%/}/\${_kzf_abi}"' "$DEP" || Z12B="$Z12B нет-пробы-флипа-с-ABI"
# ABI не распознан → зеркальный фейловер отключается
grep -q '"\$_kzb_want_mirrors" = 1 \] && \[ -z "\$_kzb_abi"' "$DEP" || Z12B="$Z12B нет-guard-кандидатов"
grep -q 'if \[ -z "\$_kzf_abi" \]; then' "$DEP" || Z12B="$Z12B нет-guard-флипа"
if [ -z "$Z12B" ]; then
    ok "Z36-5: пробы фидов во всех трёх местах идут в <base>/<ABI>/Packages.gz; неизвестный ABI → честный отказ зеркального фейловера; полные URL-пробы — t35_bootstrap K11 (FB-91/K61-01)"
else
    bad "Z36-5:$Z12B"
fi

echo "═══ F47 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
