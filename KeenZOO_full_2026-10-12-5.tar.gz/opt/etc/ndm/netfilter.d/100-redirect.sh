#!/bin/sh
# /opt/etc/ndm/netfilter.d/100-redirect.sh
# Перехват трафика для списков обхода.
#   TCP  -> nat/REDIRECT на локальные порты прокси.
#   UDP  -> mangle/TPROXY (vless, hysteria) либо nat/REDIRECT (shadowsocks).
# Оболочка: BusyBox ash (#!/bin/sh), без bash-измов.

set -eu

PATH="/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

# ─────────────────────────────────────────────────────────────────────
# IPv6: закрыть прокси-порты от внешней сети.
# ─────────────────────────────────────────────────────────────────────
# Перехват трафика (REDIRECT/TPROXY) реализован только для IPv4, но
# xray (Go) на "listen": "0.0.0.0" может создать dual-stack сокет. Если
# IPv6 случайно включили, прокси-порты не должны становиться доступными из
# LAN/WAN IPv6: эти правила закрывают их полностью, кроме loopback.
# Это только защита локальных портов; полноценный IPv4-only режим обязан
# дополнительно отключать IPv6 в KeeneticOS, а deploy проверяет это заранее.
if [ "${type:-}" = "ip6tables" ]; then
    [ "${table:-}" = "filter" ] || exit 0

    IPT6="$(command -v ip6tables 2>/dev/null || true)"
    [ -n "$IPT6" ] || exit 0
    IPT6="$IPT6 -w"

    for p6 in 1082 9141 10810 10829 10830 8080; do
        for pr6 in tcp udp; do
            # Удаляем старые варианты, включая прежние разрешения ULA/
            # link-local, иначе они опередят новое fail-closed правило.
            while $IPT6 -D INPUT -p "$pr6" --dport "$p6" \
                -j DROP >/dev/null 2>&1; do :; done
            while $IPT6 -D INPUT -i lo -p "$pr6" \
                --dport "$p6" -j ACCEPT >/dev/null 2>&1; do :; done
            for n6 in fc00::/7 fe80::/10 ::1/128; do
                while $IPT6 -D INPUT -p "$pr6" --dport "$p6" \
                    -s "$n6" -j ACCEPT >/dev/null 2>&1; do :; done
            done

            # Сначала loopback, затем DROP для любого прочего IPv6.
            $IPT6 -I INPUT 1 -p "$pr6" --dport "$p6" \
                -j DROP >/dev/null 2>&1 || true
            $IPT6 -I INPUT 1 -i lo -p "$pr6" --dport "$p6" \
                -j ACCEPT >/dev/null 2>&1 || true
        done
    done
    exit 0
fi

# filter тоже обрабатывается: в нём живут правила доступа к веб-панели.
case "${table:-}" in
    mangle|nat|filter) ;;
    *) exit 0 ;;
esac

TAG="100-redirect.sh"

# На Keenetic нет logread, а вывод logger в syslog прошивки недоступен
# обычными средствами. Поэтому диагностика дублируется в файл.
REDIRECT_LOG="/opt/var/log/100-redirect.log"
mkdir -p /opt/var/log 2>/dev/null || true

# Хук вызывается при каждом изменении состояния интерфейсов, поэтому лог
# обязан быть самоограниченным: пишем ТОЛЬКО ошибки и держим файл в
# пределах 64 КБ, оставляя последние 100 строк. Иначе накопитель с
# Entware со временем переполнится.
REDIRECT_LOG_MAX=65536
REDIRECT_LOG_KEEP=100

log_msg() {
    logger -t "$TAG" "$*" 2>/dev/null || true

    _lsz="$(wc -c < "$REDIRECT_LOG" 2>/dev/null || echo 0)"
    case "$_lsz" in
        ''|*[!0-9]*) _lsz=0 ;;
    esac
    if [ "$_lsz" -gt "$REDIRECT_LOG_MAX" ]; then
        _ltmp="${REDIRECT_LOG}.tmp.$$"
        if tail -n "$REDIRECT_LOG_KEEP" "$REDIRECT_LOG" \
            > "$_ltmp" 2>/dev/null; then
            mv -f "$_ltmp" "$REDIRECT_LOG" 2>/dev/null || rm -f "$_ltmp"
        else
            rm -f "$_ltmp"
        fi
    fi

    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$*" \
        >> "$REDIRECT_LOG" 2>/dev/null || true
}
# Пакет Entware "iptables" ставит /opt/sbin/iptables, где есть только
# libxt_CT/libxt_conntrack — расширений TPROXY, socket и set в нём НЕТ.
# Так как /opt/sbin в PATH первым, правила молча не создавались
# ("Couldn't load target `TPROXY'"). Прошивочный iptables Keenetic их умеет.
# Проверка расширения по ВЫВОДУ, а не по коду возврата: iptables на
# неизвестную цель печатает общую справку и выходит с 0, поэтому
# "iptables -j TPROXY --help >/dev/null; echo $?" даёт 0 даже там, где
# TPROXY нет. Из-за этого выбирался ущербный /opt/sbin/iptables.
# Определение возможностей iptables.
#
# Заголовок справки — основной признак, но полагаться ТОЛЬКО на него нельзя:
# формат отличается между сборками (двоеточие, регистр, отступ), а часть
# расширений вкомпилирована в libiptext.so и печатает заголовок иначе.
# Проверено на KN-2311: libiptext.so содержит и "TPROXY target options:",
# и "set match options:", то есть пакет Entware способен на TPROXY и
# --match-set, хотя отдельных libxt_set.so/libxt_TPROXY.so в нём нет.
# Прежний детектор с жёстким "^" давал ложный отрицательный вердикт, и
# проект без нужды уходил в деградированный режим.
#
# Поэтому проверка двухуровневая: текст справки, а при неудаче — наличие
# характерных опций расширения в том же выводе.
ipt_has_target() {
    _iht_out="$(LC_ALL=C "$1" -j "$2" --help 2>&1 || true)"
    printf '%s' "$_iht_out" | grep -qi "$2 target options" && return 0
    case "$2" in
        TPROXY)
            printf '%s' "$_iht_out" | grep -q -- '--on-port' && return 0
            ;;
    esac
    return 1
}

ipt_has_match() {
    _ihm_out="$(LC_ALL=C "$1" -m "$2" --help 2>&1 || true)"
    printf '%s' "$_ihm_out" | grep -qi "$2 match options" && return 0
    case "$2" in
        set)
            printf '%s' "$_ihm_out" | grep -q -- '--match-set' && return 0
            ;;
    esac
    return 1
}

ipt_is_capable() {
    ipt_has_target "$1" TPROXY && ipt_has_match "$1" set
}

pick_iptables() {
    # Прошивочный iptables Keenetic содержит libxt_TPROXY/socket/set.
    # Пакет Entware iptables (1.4.21) несёт только CT/conntrack и при этом
    # перекрывает прошивочный в PATH (/opt/sbin идёт первым).
    # На Keenetic /usr/sbin/iptables отсутствует — прошивочный бинарник
    # лежит в других каталогах, поэтому список кандидатов широкий.
    # Прошивочный бинарник на разных моделях лежит по-разному: на KN-2311
    # его нет ни в /usr/sbin, ни в /sbin. Поэтому список расширен, а после
    # абсолютных путей выполняется поиск по всей файловой системе прошивки.
    for _c in /usr/sbin/iptables /sbin/iptables /bin/iptables \
        /usr/bin/iptables /usr/local/sbin/iptables \
        /tmp/sbin/iptables /tmp/usr/sbin/iptables \
        /opt/sbin/iptables /opt/bin/iptables; do
        [ -x "$_c" ] || continue
        if ipt_is_capable "$_c"; then
            printf '%s' "$_c"
            return 0
        fi
    done

    # Прошивочный iptables мог оказаться в нестандартном каталоге —
    # ищем любые экземпляры вне /opt и проверяем каждый.
    # Глоб без ls -d: ls в BusyBox молча выдаёт код 0 и для пустого
    # списка, а разбор его вывода хрупок (имена с пробелами).
    for _c in /usr/sbin/iptables* /sbin/iptables* /bin/iptables* \
        /tmp/sbin/iptables*; do
        [ -e "$_c" ] || continue
        case "$_c" in *-save|*-restore|*multi*) continue ;; esac
        [ -x "$_c" ] || continue
        if ipt_is_capable "$_c"; then
            printf '%s' "$_c"
            return 0
        fi
    done

    # По абсолютным путям не нашли — пробуем то, что даёт PATH.
    _c="$(command -v iptables 2>/dev/null || true)"
    if [ -n "$_c" ] && ipt_is_capable "$_c"; then
        printf '%s' "$_c"
        return 0
    fi

    # Ни один не умеет TPROXY. Берём первый существующий, иначе имя из
    # PATH — путь /usr/sbin/iptables на Keenetic не существует, и
    # возвращать его нельзя (получили бы "not found").
    for _c in /usr/sbin/iptables /sbin/iptables /bin/iptables \
        /usr/bin/iptables /opt/sbin/iptables; do
        [ -x "$_c" ] && { printf '%s' "$_c"; return 0; }
    done
    printf 'iptables'
}

IPT_BIN="$(pick_iptables)"
# Единый источник выбора для панели (M6): generator.py сначала читает
# этот кэш и лишь затем перебирает свой список путей.
printf '%s' "$IPT_BIN" > /tmp/keenzoo_iptables_bin 2>/dev/null || true
IPT="$IPT_BIN -w"

# Одноразовая очистка старого policy-VPN выполняется до обычной генерации
# правил. Это нужно, чтобы сначала снять references на ipset, а затем
# безопасно уничтожить ошибочный набор WAN/Bridge.
purge_vpn_state() {
    _pvs_set="${PURGE_VPN_SET:-}"
    _pvs_mark="${PURGE_VPN_MARK:-}"
    [ -n "$_pvs_set" ] || return 0

    for _pvs_proto in tcp udp; do
        while $IPT -t mangle -D PREROUTING -p "$_pvs_proto" \
            -m set --match-set "$_pvs_set" dst \
            -j MARK --set-mark "$_pvs_mark" >/dev/null 2>&1; do :; done
    done
    while $IPT -t mangle -D PREROUTING \
        -m conntrack --ctstate NEW \
        -m set --match-set "$_pvs_set" dst \
        -j CONNMARK --set-mark "$_pvs_mark" >/dev/null 2>&1; do :; done
    return 0
}

if [ -n "${PURGE_VPN_SET:-}" ]; then
    purge_vpn_state
    exit 0
fi

# ── Порты локальных прокси ───────────────────────────────────────────────
PORT_SS=1082
PORT_TOR=9141
PORT_VLESS=10810
PORT_TROJAN=10829
PORT_HYSTERIA=10830
# Порт веб-панели (generator.py). Держится здесь, чтобы
# правила доступа переустанавливались вместе с остальными.
PORT_WEB=8080

# ── TPROXY: отдельная метка и таблица маршрутизации ──────────────────────
# Маска гарантирует отсутствие пересечения с VPN-метками вида 0xd1001.
# Метка вынесена в старший бит (0x1000000). VPN-марки формируются как
# 0xd<table_id>, где table_id растёт от 1001; начиная с table_id=1100
# значение 0xd1100 задевало бы бит 0x100 и трафик VPN ошибочно уходил
# бы в TPROXY-таблицу. Бит 24 в марки вида 0xdXXXX не попадает никогда.
TPROXY_MARK="0x1000000"
TPROXY_MASK="0x1000000"

# Метка исходящих пакетов самого xray (sockopt.mark в outbound). Служит
# только для RETURN в OUTPUT, чтобы трафик прокси не заворачивался в него
# же. Значение не пересекается ни с TPROXY_MARK, ни с VPN-марками 0xdXXXX.
XRAY_MARK="0x2000000"
TPROXY_TABLE=100
TPROXY_RULE_PRIO=1770

# ── Внутренние (клиентские) интерфейсы ───────────────────────────────────
# Правила обхода обязаны действовать одинаково для LAN, Wi-Fi, гостевой
# сети и для клиентов, подключённых к роутеру по VPN (в т.ч. WireGuard
# сервер прошивки: nwg*, wg*). Список фильтруется по факту существования
# интерфейса, чтобы не плодить мёртвые правила.
LAN_IFACE_PATTERNS="br0 br1 br2 wlan0 wlan1 wlan2 wlan3 nwg0 nwg1 nwg2 wg0 wg1 tun0 tap0 ppp-l2tp0 sstp0"

lan_ifaces() {
    _li_out=""
    for _li_if in $LAN_IFACE_PATTERNS; do
        if ip link show "$_li_if" >/dev/null 2>&1; then
            _li_out="${_li_out}${_li_out:+ }${_li_if}"
        fi
    done

    # Keenetic NDM names its WireGuard interface Wireguard0, while the
    # kernel exposes the same device as nwg0 (confirmed by Test.txt).
    # Discover all currently existing nwg*/wg* devices so a second server
    # interface (nwg1) is covered without hard-coding a stale name.
    for _li_if in $(ip -o link show 2>/dev/null \
        | awk -F': ' '{print $2}' | sed 's/@.*//' \
        | grep -E '^(nwg|wg)[0-9]+$' || true); do
        case " $_li_out " in
            *" $_li_if "*) ;;
            *) _li_out="${_li_out}${_li_out:+ }${_li_if}" ;;
        esac
    done

    [ -n "$_li_out" ] || _li_out="br0"
    printf '%s\n' "$_li_out"
}

LAN_IFACES="$(lan_ifaces)"

# P6 (ревью 2026-10-05): раньше адрес искался только на br0 — на
# конфигурациях без моста правила доступа к панели не создавались.
# br0 идёт первым в LAN_IFACE_PATTERNS, поэтому штатные установки
# получают тот же адрес, что и раньше.
local_ip=""
for _li in $LAN_IFACES; do
    _li_cand=$(
        ip -4 addr show "$_li" 2>/dev/null \
            | awk '/inet /{print $2}' \
            | cut -d/ -f1 \
            | grep -E '^(192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)' \
            | head -n1
    )
    if [ -n "$_li_cand" ]; then
        local_ip="$_li_cand"
        break
    fi
done

# ═════════════════════════════════════════════════════════════════════════
# 8. Доступ к веб-панели: только из локальных сетей
# ═════════════════════════════════════════════════════════════════════════
# Правила ставятся здесь, а не только при старте панели: Keenetic
# пересоздаёт цепочки при смене состояния интерфейсов и вызывает этот хук,
# после чего разрешающие правила панели пропадали и она становилась
# недоступной из LAN до перезапуска S99generator.
# Разрешение выдаётся по ИСХОДНОЙ ПОДСЕТИ, а не по имени интерфейса:
# на Keenetic Wi-Fi-клиенты приходят через разные мосты (гостевая сеть,
# отдельный бридж 5 ГГц, имена вида wl0/ra0), угадать их нельзя.
if [ "${table:-}" = "filter" ]; then
    # Снять прежний DROP, чтобы добавить его последним.
    while $IPT -D INPUT -p tcp --dport "$PORT_WEB" \
        -j DROP >/dev/null 2>&1; do :; done

    # (ревизия 2026-10-12, блок B7): blanket RFC1918-разрешения сняты —
    # они открывали порты в сторону ЛЮБОЙ приватной -s-подсети, включая
    # аплинк, если провайдер выдаёт адрес из 10/8 (CGNAT/L2TP-сети).
    # Поэтому для веб-порта разрешаются только подсети, РЕАЛЬНО
    # существующие на определённых выше LAN-интерфейсах, а для
    # прокси-портов — только -i lo и -i <LAN>. Старые blanket-правила
    # со прежних установок зачищаются здесь же.
    for legacy_net in 192.168.0.0/16 10.0.0.0/8 172.16.0.0/12; do
        while $IPT -D INPUT -p tcp --dport "$PORT_WEB" \
            -s "$legacy_net" -j ACCEPT >/dev/null 2>&1
        do
            :
        done
    done

    _lan_subnets="127.0.0.0/8"
    _lan_found=0
    for proxy_if in $LAN_IFACES; do
        _if_nets=$(ip -4 addr show dev "$proxy_if" 2>/dev/null \
            | awk '/inet /{print $2}')
        for _if_net in $_if_nets; do
            case " $_lan_subnets " in
                *" $_if_net "*) ;;
                *) _lan_subnets="$_lan_subnets $_if_net" ;;
            esac
            _lan_found=1
        done
    done
    # K5 (повторный аудит): деградация доступности обязана оставлять
    # след в логе — иначе панель «просто пропадёт» на нестандартной
    # сборке ip или при сбое парсинга.
    [ "$_lan_found" = "1" ] || log_msg \
        "B7: подсети LAN не определены (ip -4 addr show) — веб-панель $PORT_WEB доступна только с 127.0.0.1"

    for web_net in $_lan_subnets; do
        if ! $IPT -C INPUT -p tcp --dport "$PORT_WEB" \
            -s "$web_net" -j ACCEPT >/dev/null 2>&1
        then
            $IPT -I INPUT -p tcp --dport "$PORT_WEB" \
                -s "$web_net" -j ACCEPT >/dev/null 2>&1 || true
        fi
    done

    $IPT -A INPUT -p tcp --dport "$PORT_WEB" -j DROP >/dev/null 2>&1 || true

    # ─────────────────────────────────────────────────────────────────
    # Прокси-порты: закрыть от WAN (defense-in-depth).
    # ─────────────────────────────────────────────────────────────────
    # ss-redir, tor, xray, trojan и hysteria слушают 0.0.0.0, потому что
    # принимают перехваченный трафик со всех внутренних интерфейсов.
    # Своих правил INPUT у них не было — защищал только межсетевой экран
    # прошивки. При случайном пробросе порта или его отключении роутер
    # превратился бы в открытый прокси-релей.
    #
    # Разрешение выдаётся двумя независимыми способами, чтобы ни один
    # легитимный путь не оказался отрезан:
    #   1) -i lo          — трафик самого роутера после REDIRECT/TPROXY
    #                       (bot.txt -> unblockrouter) приходит через lo;
    #   2) -i <LAN>       — перехваченный трафик клиентов.
    # Бывшая третья ось (-s RFC1918-blanket) удалена (ревизия 2026-10-12,
    # блок B7): она открывала прокси-порты в сторону аплинка при
    # приватной WAN-адресации (CGNAT, L2TP 10/8) — при отключённом
    # межсетевом экране прошивки роутер становился открытым релеем
    # для всех клиентов такой апстрим-подсети. Прежние -s-правила со
    # старых установок зачищаются при первом же проходе хука.
    # DROP ставится безусловно: при пустом LAN_IFACES легитимного пути
    # просто нет, и fail-open против собственного замысла недопустим.
    for proxy_port in "$PORT_SS" "$PORT_TOR" "$PORT_VLESS" \
        "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        for proxy_proto in tcp udp; do
            # Снять прежний DROP, чтобы он снова оказался последним.
            while $IPT -D INPUT -p "$proxy_proto" \
                --dport "$proxy_port" -j DROP >/dev/null 2>&1
            do
                :
            done

            if ! $IPT -C INPUT -i lo -p "$proxy_proto" \
                --dport "$proxy_port" -j ACCEPT >/dev/null 2>&1
            then
                $IPT -I INPUT -i lo -p "$proxy_proto" \
                    --dport "$proxy_port" -j ACCEPT \
                    >/dev/null 2>&1 || true
            fi

            for proxy_if in $LAN_IFACES; do
                if ! $IPT -C INPUT -i "$proxy_if" -p "$proxy_proto" \
                    --dport "$proxy_port" -j ACCEPT >/dev/null 2>&1
                then
                    $IPT -I INPUT -i "$proxy_if" -p "$proxy_proto" \
                        --dport "$proxy_port" -j ACCEPT \
                        >/dev/null 2>&1 || true
                fi
            done

            # Зачистка наследия со старых установок.
            for proxy_net in 127.0.0.0/8 192.168.0.0/16 \
                10.0.0.0/8 172.16.0.0/12; do
                while $IPT -D INPUT -p "$proxy_proto" \
                    --dport "$proxy_port" -s "$proxy_net" \
                    -j ACCEPT >/dev/null 2>&1
                do
                    :
                done
            done

            $IPT -A INPUT -p "$proxy_proto" \
                --dport "$proxy_port" -j DROP \
                >/dev/null 2>&1 \
                || log_msg "INPUT DROP failed: $proxy_proto/$proxy_port"
        done
    done
fi

if [ "${table:-}" = "filter" ]; then
    # В таблице filter больше делать нечего.
    exit 0
fi

if [ -z "$local_ip" ]; then
    log_msg "br0 local_ip not found"
    exit 0
fi

ensure_set() {
    ipset create "$1" hash:net family inet hashsize 1024 maxelem 65536 -exist 2>/dev/null || true
}

# ── Идемпотентные помощники (проверка через -C, без grep по iptables-save)
# Протокол считается выключенным, если в его init-скрипте стоит
# ENABLED=no (ползунок в веб-панели). Для такого протокола правила
# перехвата не создаются, а ранее созданные снимаются — иначе трафик
# уходил бы на порт остановленного сервиса и соединение просто рвалось.
svc_enabled() {
    _init="$1"
    # Нет init-файла или он не исполняемый — протокол не установлен,
    # и правила на его порт создавать нельзя (M8): иначе трафик из
    # набора уходил бы на закрытый порт вместо прямого выхода.
    [ -f "$_init" ] || return 1
    [ -x "$_init" ] || return 1
    if grep -qE '^[[:space:]]*ENABLED[[:space:]]*=[[:space:]]*no' \
        "$_init" 2>/dev/null
    then
        return 1
    fi

    # Мало того, что сервис разрешён — он должен реально работать.
    # Правило на упавший сервис создаёт чёрную дыру: пакеты уходят на
    # порт, который никто не слушает, и клиент получает таймаут вместо
    # обхода (наблюдалось с hysteria: сервис dead, а 6 правил на
    # unblockhysteria стояли). Порт берётся из PROCS init-скрипта.
    _svc_proc="$(sed -n \
        's/^[[:space:]]*PROCS[[:space:]]*=[[:space:]]*\([^[:space:]#]*\).*/\1/p' \
        "$_init" 2>/dev/null | head -1)"
    [ -n "$_svc_proc" ] || return 0

    # Разбор /proc, без pgrep: он есть не во всех сборках BusyBox.
    # Сравнивается ИМЯ БИНАРНИКА (argv[0]), а не вся командная строка:
    # подстрочный поиск принимал за живой сервис любой процесс, где имя
    # встречается в аргументах — например "vi /opt/etc/hysteria/config.json"
    # или "tail -f .../hysteria.log". Тогда правила создавались для
    # мёртвого сервиса, то есть ровно та ошибка, ради которой делалась
    # проверка.
    # Результат кэшируется на время прогона: функция вызывается до 15 раз
    # (5 сервисов × 3 интерфейса), и каждый раз обходить весь /proc
    # слишком дорого — прошивка убивала хук по таймауту
    # ("100-redirect.sh: timed out", Opkg::Manager).
    # Имя процесса нормализуется: в имени переменной допустимы только
    # [A-Za-z0-9_], а PROCS бывает вида "ss-redir".
    _svc_key="$(printf '%s' "$_svc_proc" | tr -c 'A-Za-z0-9_' '_')"
    eval "_svc_cached=\"\${_SVC_ALIVE_${_svc_key}:-}\""
    # shellcheck disable=SC2154
    case "$_svc_cached" in
        1) return 0 ;;
        0) return 1 ;;
    esac

    _svc_found=1
    for _svc_d in /proc/[0-9]*; do
        # Процесс мог завершиться между раскрытием маски и чтением файла.
        # Перенаправление "< файл" выполняет ОБОЛОЧКА, и её сообщение
        # "can't open ...: no such file" не подавляется через 2>/dev/null
        # у самой команды — в журнале роутера это выглядело как ошибка
        # скрипта. Читаем через cat с подавлением его собственного stderr.
        _svc_argv0="$(cat "$_svc_d/cmdline" 2>/dev/null \
            | tr '\0' '\n' | head -1)"
        [ -n "$_svc_argv0" ] || continue
        # argv[0] может быть как "hysteria", так и "/opt/bin/hysteria".
        if [ "${_svc_argv0##*/}" = "$_svc_proc" ]; then
            _svc_found=0
            break
        fi
    done

    # Имя процесса подставляется в имя переменной, поэтому из него
    # убирается всё, кроме [A-Za-z0-9_]: "ss-redir" дал бы недопустимое
    # имя и eval завершился бы ошибкой.
    _svc_key="$(printf '%s' "$_svc_proc" | tr -c 'A-Za-z0-9_' '_')"
    if [ "$_svc_found" = "0" ]; then
        eval "_SVC_ALIVE_${_svc_key}=1"
        return 0
    fi

    eval "_SVC_ALIVE_${_svc_key}=0"
    log_msg "$_svc_proc не запущен — правила перехвата не создаются"
    return 1
}

# Конфигурационный предикат «протокол установлен»: init-скрипт есть и
# исполняемый — без учёта ENABLED и живости процесса. Именно он теперь
# решает создание правил перехвата (требование 2026-10-05, fail-closed):
# недоступный протокол (упал или выключен ползунком) делает домены
# своего списка НЕДОСТУПНЫМИ — RST на мёртвом порту, а не прямой выход.
# Снятие правил по мёртвому сервису было fail-open и дало реальную
# утечку (инцидент: xray/ss-redir dead после деплоя → списки шли
# напрямую). Правила пересоздаются всё теми же хуками, разницы в
# стоимости нет — только в семантике у мира процессов.
svc_installed() {
    [ -f "$1" ] || return 1
    [ -x "$1" ] || return 1
    return 0
}

# Снимает правило REDIRECT с конкретного интерфейса.
nat_del_prerouting() {
    _proto="$1"
    _set="$2"
    _port="$3"
    _if="$4"
    while $IPT -t nat -D PREROUTING -i "$_if" -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    do
        :
    done
}

# Снимает правило TPROXY с конкретного интерфейса.
mangle_del_tproxy() {
    _set="$1"
    _port="$2"
    _if="$3"
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst \
        -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
        --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    do
        :
    done
}

nat_add_prerouting() {
    _proto="$1"
    _set="$2"
    _port="$3"
    _if="$4"
    if ! $IPT -t nat -C PREROUTING -i "$_if" -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    then
        $IPT -t nat -A PREROUTING -i "$_if" -p "$_proto" \
            -m set --match-set "$_set" dst \
            -j REDIRECT --to-port "$_port" >/dev/null 2>&1 || true
    fi
}

nat_del_prerouting_any() {
    # Удаляет старое правило без -i (наследие прежних версий).
    _proto="$1"
    _set="$2"
    _port="$3"
    while $IPT -t nat -D PREROUTING -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    do
        :
    done
}

# Загрузка модуля netfilter при необходимости.
# Хук вызывается при каждой перестройке цепочек, в том числе при
# загрузке роутера, поэтому модули грузятся именно здесь: деплой
# выполняется однократно и после reboot не отработает.
# modprobe на Keenetic бесполезен — в /lib/modules нет modules.dep,
# поэтому используется insmod с полным путём к .ko.
load_kmod() {
    _km="$1"

    if lsmod 2>/dev/null | awk -v m="$_km" '$1==m {f=1} END{exit !f}'
    then
        return 0
    fi

    modprobe "$_km" >/dev/null 2>&1 && return 0

    _kdir="/lib/modules/$(uname -r)"
    [ -d "$_kdir" ] || return 1

    _kfile="$(find "$_kdir" -name "${_km}.ko" -print 2>/dev/null \
        | head -n1)"
    [ -n "$_kfile" ] || return 1

    insmod "$_kfile" >/dev/null 2>&1 || true

    lsmod 2>/dev/null | awk -v m="$_km" '$1==m {f=1} END{exit !f}'
}

# Цель TPROXY доступна только при загруженном xt_TPROXY. Проверяем по
# факту наличия цели в ядре и при отсутствии — догружаем модули.
ensure_tproxy_kmod() {
    if grep -qx 'TPROXY' /proc/net/ip_tables_targets 2>/dev/null; then
        return 0
    fi

    for _d in nf_defrag_ipv4 nf_tproxy_ipv4 nf_tproxy_core \
        nf_socket_ipv4 ip_set; do
        load_kmod "$_d" >/dev/null 2>&1 || true
    done
    for _m in xt_TPROXY xt_socket xt_set; do
        load_kmod "$_m" >/dev/null 2>&1 || true
    done

    if grep -qx 'TPROXY' /proc/net/ip_tables_targets 2>/dev/null; then
        log_msg "xt_TPROXY загружен вручную (insmod)"
        return 0
    fi
    return 1
}

mangle_add_tproxy() {
    _set="$1"
    _port="$2"
    _if="$3"

    # Набор обязан существовать: без него iptables отвергает правило
    # целиком ("Set ... doesn't exist" / "Can't open socket to ipset").
    if ! ipset list -n "$_set" >/dev/null 2>&1; then
        log_msg "TPROXY skip: ipset $_set отсутствует"
        return 0
    fi

    if ! $IPT -t mangle -C PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst \
        -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
        --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    then
        # Ошибка НЕ подавляется: раньше причина терялась в /dev/null и
        # отсутствие правил выглядело беспричинным.
        _err="$($IPT -t mangle -A PREROUTING -i "$_if" -p udp \
            -m set --match-set "$_set" dst \
            -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
            --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" 2>&1)" \
            || {
                log_msg "TPROXY add failed: $_set/$_port/$_if: $_err"
                # Ошибка "No chain/target/match by that name" не говорит,
                # ЧТО именно отвергнуто: цель TPROXY или совпадение set.
                # Разделяем причины одной пробой на каждый прогон, чтобы
                # в журнале была не догадка, а факт.
                if [ "${_tproxy_diag:-0}" = "0" ]; then
                    _tproxy_diag=1
                    if $IPT -t mangle -I PREROUTING -p udp \
                        -d 127.0.0.2 --dport 1 \
                        -j TPROXY --on-ip 127.0.0.1 \
                        --on-port 12345 --tproxy-mark 1/1 \
                        >/dev/null 2>&1
                    then
                        $IPT -t mangle -D PREROUTING -p udp \
                            -d 127.0.0.2 --dport 1 \
                            -j TPROXY --on-ip 127.0.0.1 \
                            --on-port 12345 --tproxy-mark 1/1 \
                            >/dev/null 2>&1 || true
                        log_msg "diag: цель TPROXY работает; отвергается связка с -m set в mangle"
                    else
                        log_msg "diag: ядро НЕ поддерживает цель TPROXY (нет xt_TPROXY). UDP в туннель не пойдёт, TCP не затронут"
                    fi
                fi
            }
    fi
}

# ── H6: ndm вызывает хук отдельно на nat, mangle и filter. Раньше весь
# файл исполнялся трижды (~370 вызовов iptables на событие). Ниже
# разводка работы по таблицам; тела секций не изменены. Системные
# действия (модули, ip rule/route) и ipset-ensure — общие.
# (P10, аудит rev3: строка «[ "$table" = "filter" ] && exit 0» была
# мёртвой — filter-ветка уже вышла из скрипта раньше, на блоке
# «В таблице filter больше делать нечего»; удалена.)
if [ "$table" = "mangle" ]; then _tbl_sys=1; else _tbl_sys=0; fi
if [ "$table" = "nat" ]; then _tbl_nat=1; else _tbl_nat=0; fi

# Пути init-скриптов: по ним читается состояние ползунка ENABLED.
INIT_SS="/opt/etc/init.d/S65shadowsocks"
INIT_TOR="/opt/etc/init.d/S35tor"
INIT_VLESS="/opt/etc/init.d/S24xray"
INIT_TROJ="/opt/etc/init.d/S22trojan"
INIT_HY="/opt/etc/init.d/S57hysteria"

# ── Выбор протокола для трафика роутера (bot.txt -> unblockrouter) ─────
# vl — xray :10810 · tr — trojan :10829 (только TCP: UDP при нём не
# перехватывается) · hy — hysteria :10830. Источник выбора — файл
# /opt/etc/unblock/router_proto (ставит панель, вкладка «Бот»); до его
# появления — vless (историческое поведение). Тест из консоли:
# ROUTER_PROTOCOL=tr type=iptable table=nat <этот хук>.
ROUTER_PROTO_FILE="/opt/etc/unblock/router_proto"
router_proto() {
    _rp=""
    if [ -n "${ROUTER_PROTOCOL:-}" ]; then
        _rp="$ROUTER_PROTOCOL"
    elif [ -r "$ROUTER_PROTO_FILE" ]; then
        _rp="$(tr -d ' \t\r\n' < "$ROUTER_PROTO_FILE" 2>/dev/null)"
    fi
    case "$_rp" in
        vl|tr|hy) printf '%s' "$_rp" ;;
        *) printf '%s' vl ;;
    esac
}
router_proto_init() {
    case "$1" in
        vl) printf '%s' "$INIT_VLESS" ;;
        tr) printf '%s' "$INIT_TROJ" ;;
        hy) printf '%s' "$INIT_HY" ;;
    esac
}

# ═════════════════════════════════════════════════════════════════════════
# 1. DNS клиентов -> локальный dnsmasq (только внутренние интерфейсы)
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ]; then

# Прежняя версия ставила DNAT без -i: правило применялось и к пакетам,
# пришедшим с WAN, то есть роутер становился открытым DNS-релеем.
for protocol in udp tcp; do
    while $IPT -t nat -D PREROUTING -p "$protocol" --dport 53 \
        -j DNAT --to-destination "$local_ip" >/dev/null 2>&1
    do
        :
    done
done

for iface in $LAN_IFACES; do
    for protocol in udp tcp; do
        if ! $IPT -t nat -C PREROUTING -i "$iface" -p "$protocol" --dport 53 \
            -j DNAT --to-destination "$local_ip" >/dev/null 2>&1
        then
            $IPT -t nat -I PREROUTING -i "$iface" -p "$protocol" --dport 53 \
                -j DNAT --to-destination "$local_ip" >/dev/null 2>&1 || true
        fi
    done
done

fi

# ═════════════════════════════════════════════════════════════════════════
# 2. Подготовка ipset
# ═════════════════════════════════════════════════════════════════════════
for s in unblocksh unblocktor unblockvless unblocktroj unblockhysteria unblockrouter unblockdns; do
    ensure_set "$s"
done

# ═════════════════════════════════════════════════════════════════════════
# 3. Чистка устаревших/некорректных правил
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ]; then

# UDP через nat/REDIRECT для Tor/Trojan/Hysteria: это TCP-входы либо
# TPROXY-входы, REDIRECT ломал такой трафик.
nat_del_prerouting_any udp unblocktor "$PORT_TOR"
nat_del_prerouting_any udp unblocktroj "$PORT_TROJAN"
nat_del_prerouting_any udp unblockhysteria "$PORT_HYSTERIA"
nat_del_prerouting_any udp unblockvless "$PORT_VLESS"
# Старые правила без -i.
nat_del_prerouting_any tcp unblocksh "$PORT_SS"
nat_del_prerouting_any udp unblocksh "$PORT_SS"
nat_del_prerouting_any tcp unblocktor "$PORT_TOR"
nat_del_prerouting_any tcp unblockvless "$PORT_VLESS"
nat_del_prerouting_any tcp unblocktroj "$PORT_TROJAN"
nat_del_prerouting_any tcp unblockhysteria "$PORT_HYSTERIA"

fi

# ═════════════════════════════════════════════════════════════════════════
# 4. TCP: nat/REDIRECT на локальные порты (по каждому внутр. интерфейсу)
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ]; then

# Пути init-скриптов перенесены в общий блок выше: mangle-
# секции тоже вызывают svc_enabled со своими INIT_* (см. H6).

for iface in $LAN_IFACES; do
    if svc_installed "$INIT_SS"; then
        nat_add_prerouting tcp unblocksh    "$PORT_SS"    "$iface"
        # ss-redir запущен с -u и обрабатывает UDP через REDIRECT.
        nat_add_prerouting udp unblocksh    "$PORT_SS"    "$iface"
    else
        nat_del_prerouting tcp unblocksh    "$PORT_SS"    "$iface"
        nat_del_prerouting udp unblocksh    "$PORT_SS"    "$iface"
    fi

    if svc_installed "$INIT_TOR"; then
        nat_add_prerouting tcp unblocktor   "$PORT_TOR"   "$iface"
    else
        nat_del_prerouting tcp unblocktor   "$PORT_TOR"   "$iface"
    fi

    if svc_installed "$INIT_VLESS"; then
        nat_add_prerouting tcp unblockvless "$PORT_VLESS" "$iface"
    else
        nat_del_prerouting tcp unblockvless "$PORT_VLESS" "$iface"
    fi

    if svc_installed "$INIT_TROJ"; then
        nat_add_prerouting tcp unblocktroj  "$PORT_TROJAN" "$iface"
    else
        nat_del_prerouting tcp unblocktroj  "$PORT_TROJAN" "$iface"
    fi

    if svc_installed "$INIT_HY"; then
        nat_add_prerouting tcp unblockhysteria "$PORT_HYSTERIA" "$iface"
    else
        nat_del_prerouting tcp unblockhysteria "$PORT_HYSTERIA" "$iface"
    fi
done

fi

# ═════════════════════════════════════════════════════════════════════════
# 5. UDP через TPROXY для VLESS (xray) и Hysteria2
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_sys" = 1 ]; then

# nat/REDIRECT для UDP не сохраняет оригинальный адрес назначения, поэтому
# dokodemo-door/udpTProxy получали пакеты без dst и трафик рвался.
# Корректная схема: mangle/TPROXY + метка + локальная таблица маршрутизации.
if ip rule show 2>/dev/null | grep -q "lookup ${TPROXY_TABLE}$"; then
    :
else
    ip rule add fwmark "${TPROXY_MARK}/${TPROXY_MASK}" \
        lookup "$TPROXY_TABLE" priority "$TPROXY_RULE_PRIO" 2>/dev/null || true
fi

ip route replace local default dev lo table "$TPROXY_TABLE" 2>/dev/null || true

# Модули netfilter должны быть загружены ДО создания правил: на Keenetic
# xt_TPROXY.ko поставляется прошивкой, но автоматически не грузится.
ensure_tproxy_kmod || true

# Пакеты уже установленных TPROXY-сессий должны попадать на локальный сокет
# до правил TPROXY (иначе они уйдут в форвардинг).
# DNS никогда не в TPROXY: mangle идёт раньше nat, и IP публичного
# резолвера, попавший в набор (домен DoH-провайдера разрешился в 8.8.8.8),
# уводил клиентский DNS в туннель вместо локального dnsmasq (M2).
if ! $IPT -t mangle -C PREROUTING -p udp --dport 53 -j RETURN >/dev/null 2>&1; then
    $IPT -t mangle -I PREROUTING 1 -p udp --dport 53 -j RETURN >/dev/null 2>&1 || true
fi

if ! $IPT -t mangle -C PREROUTING -p udp -m socket \
    -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
then
    $IPT -t mangle -I PREROUTING -p udp -m socket \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1 || true
fi

# UDP-guard (fail-closed) для TCP-only входов: у trojan и tor нет
# UDP-перехвата по дизайну. Раньше их UDP в mangle не распознавался:
# если IP домена оказывался в наборе vless/hysteria (общий CDN-адрес),
# пакет подхватывало TPROXY чужого протокола, а без чужого совпадения
# он уходил напрямую провайдеру мимо туннеля (инцидент: whoer.net из
# trojan.txt показывал egress Hysteria — QUIC/443 на Cloudflare-IP из
# unblockhysteria). Явный DROP ставится ДО правил TPROXY (вставка
# на позицию 3, сразу за меткой сокета и DNS-возвратом): REJECT ядром
# этой сборки не принимается в mangle (только filter), DROP согласован
# со всеми таблицами. QUIC такого домена теряет handshake-пакеты,
# Happy Eyeballs уходит на TCP через свой туннель.
# Побочка: на пересечённых IP QUIC умрёт и для доменов vless/hysteria —
# их TCP-интерфейс это не затрагивает.
mangle_add_udpguard() {
    _set="$1"
    _if="$2"
    if ! ipset list -n "$_set" >/dev/null 2>&1; then
        return 0
    fi
    # Освобождение пересечений (ревью 2026-10-12): логические наборы
    # пересекаются по CDN-IP (один IP одновременно в troj и vless
    # наборах — облачные фронты делят их тысячами). DROP ко всему set
    # убивал бы UDP vless-доменов на таких IP, хотя xray 24.x+ несёт
    # их UDP через собственный UoT/XUDP. Для dst из наборов протоколов
    # с UDP-инбаундом (vless, hysteria) guard не действует — пакет
    # пройдёт до TPROXY-позиции и уйдёт в их порт. Чисто troj/tor-IP
    # по-прежнему защищены от утечки (у них UDP-инбаундов нет).
    _gn_excl=""
    for _gn_ex in unblockvless unblockhysteria; do
        if ipset list -n "$_gn_ex" >/dev/null 2>&1; then
            _gn_excl="$_gn_excl -m set ! --match-set $_gn_ex dst"
        fi
    done
    if ! $IPT -t mangle -C PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst $_gn_excl -j DROP >/dev/null 2>&1
    then
        $IPT -t mangle -I PREROUTING 3 -i "$_if" -p udp \
            -m set --match-set "$_set" dst $_gn_excl -j DROP \
            >/dev/null 2>&1 \
            && log_msg "UDP-guard: DROP udp $_set на $_if (кроме vless/hy-пересечений, до TPROXY)"
    fi
}
mangle_del_udpguard() {
    _set="$1"
    _if="$2"
    # Удаляем обе разновидности: со старых установок — без
    # exclusion-цепочки, с новых (ревью 2026-10-12) — с ней.
    _gd_excl=""
    for _gd_ex in unblockvless unblockhysteria; do
        _gd_excl="$_gd_excl -m set ! --match-set $_gd_ex dst"
    done
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst $_gd_excl -j DROP \
        >/dev/null 2>&1
    do
        :
    done
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst -j DROP >/dev/null 2>&1
    do
        :
    done
}

# ── vless: LEGACY-зачистка vision-гарда UDP/443 (2026-10-12) ──────────
# Ранее для ключей с flow=xtls-rprx-vision здесь ставился DROP udp/443 до
# TPROXY: считалось, что Vision не несёт UDP вовсе. Замер на живом ядре
# xray 26.x доказал обратное: UDP/443 клиентское ядро роняет само по
# дизайну Vision (QUIC→TCP), а прочий UDP (звонки, игры, STUN) переносит
# через UoT/XUDP без гардов (живой звонок Telegram через туннель с ростом
# UDP-счётчиков TPROXY). Гард как отдельный слой iptables снят; цикл
# ниже идемпотентно стирает правила прежних прогонов.
mangle_del_vlessquicguard() {
    _set="$1"
    _if="$2"
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp --dport 443 \
        -m set --match-set "$_set" dst -j DROP >/dev/null 2>&1
    do
        :
    done
}

# Гард раньше TPROXY: порядок в кадре определяет победителя правила.
for iface in $LAN_IFACES; do
    if svc_installed "$INIT_TROJ"; then
        mangle_add_udpguard unblocktroj "$iface"
    else
        mangle_del_udpguard unblocktroj "$iface"
    fi
    if svc_installed "$INIT_TOR"; then
        mangle_add_udpguard unblocktor "$iface"
    else
        mangle_del_udpguard unblocktor "$iface"
    fi
done

# Vision-гард снят (см. комментарий к зачистке выше): на ядрах xray >=24
# блок UDP/443 делает само клиентское ядро по дизайну Vision; остатки
# прежних DROP-правил безусловно стираем на каждом прогоне хука.
for iface in $LAN_IFACES; do
    mangle_del_vlessquicguard unblockvless "$iface"
done

for iface in $LAN_IFACES; do
    if svc_installed "$INIT_VLESS"; then
        mangle_add_tproxy unblockvless    "$PORT_VLESS"    "$iface"
    else
        mangle_del_tproxy unblockvless    "$PORT_VLESS"    "$iface"
    fi
    if svc_installed "$INIT_HY"; then
        mangle_add_tproxy unblockhysteria "$PORT_HYSTERIA" "$iface"
    else
        mangle_del_tproxy unblockhysteria "$PORT_HYSTERIA" "$iface"
    fi
done

# UDP, сгенерированный самим роутером (bot.txt -> unblockrouter):
# mangle/OUTPUT лишь маркирует пакет, таблица 100 ведёт его на lo, а
# TPROXY-правила для lo не было — чёрная дыра (H3). Протокол задаётся
# файлом router_proto (панель, вкладка «Бот»): правило создаётся только
# для выбранного сервиса, остальные варианты снимаются. Trojan UDP не
# принимает — при нём здесь правил нет вовсе (см. секцию 6 про TCP).
_rp="$(router_proto)"
for _rpv in vl hy; do
    if [ "$_rpv" = vl ]; then
        _rp_port="$PORT_VLESS"; _rp_init="$INIT_VLESS"
    else
        _rp_port="$PORT_HYSTERIA"; _rp_init="$INIT_HY"
    fi
    if [ "$_rp" = "$_rpv" ] && svc_installed "$_rp_init"; then
        mangle_add_tproxy unblockrouter "$_rp_port" lo
    else
        mangle_del_tproxy unblockrouter "$_rp_port" lo
    fi
done

fi

# ═════════════════════════════════════════════════════════════════════════
# 6. Трафик самого роутера (bot.txt -> unblockrouter)
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ]; then

if ! $IPT -t nat -C OUTPUT -o lo -j RETURN >/dev/null 2>&1; then
    $IPT -t nat -I OUTPUT -o lo -j RETURN >/dev/null 2>&1 || true
fi

for net in 127.0.0.0/8 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16; do
    if ! $IPT -t nat -C OUTPUT -d "$net" -j RETURN >/dev/null 2>&1; then
        $IPT -t nat -A OUTPUT -d "$net" -j RETURN >/dev/null 2>&1 || true
    fi
done

# Защита от петли: пакеты, которые xray сам отправляет наружу, помечены
# XRAY_MARK (sockopt.mark в outbound). Без этого исключения правила ниже
# завернули бы исходящий трафик xray обратно в его же inbound.
if ! $IPT -t nat -C OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; then
    $IPT -t nat -I OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1 || true
fi
fi

if [ "$_tbl_sys" = 1 ]; then
if ! $IPT -t mangle -C OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; then
    $IPT -t mangle -I OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1 || true
fi
fi

if [ "$_tbl_nat" = 1 ]; then

# DNS через активный туннель. В наборе unblockdns находятся адреса
# внешних системных DoH/DoT endpoint-ов, а не IP произвольных сайтов.
# Поэтому клиентский DNS остаётся в dnsmasq/system proxy, а только его
# исходящие TCP/443 и TCP/853 соединения идут через выбранный tunnel.
DNS_TUNNEL_PORT=""
if [ "${DNS_TUNNEL_DISABLE:-0}" != "1" ]; then
    case "${DNS_TUNNEL_PROTOCOL:-}" in
        xray) DNS_TUNNEL_PORT="$PORT_VLESS" ;;
        trojan) DNS_TUNNEL_PORT="$PORT_TROJAN" ;;
        hysteria) DNS_TUNNEL_PORT="$PORT_HYSTERIA" ;;
        *)
            if svc_enabled "$INIT_VLESS"; then
                DNS_TUNNEL_PORT="$PORT_VLESS"
            elif svc_enabled "$INIT_TROJ"; then
                DNS_TUNNEL_PORT="$PORT_TROJAN"
            elif svc_enabled "$INIT_HY"; then
                DNS_TUNNEL_PORT="$PORT_HYSTERIA"
            fi
            ;;
    esac
fi

# Снять старые варианты, включая прежнее правило без --dport.
for _dns_tunnel_port in "$PORT_VLESS" "$PORT_TROJAN" "$PORT_HYSTERIA"; do
    for _dns_remote_port in 443 853; do
        while $IPT -t nat -D OUTPUT -p tcp --dport "$_dns_remote_port" \
            -m set --match-set unblockdns dst \
            -j REDIRECT --to-port "$_dns_tunnel_port" >/dev/null 2>&1; do :; done
    done
    while $IPT -t nat -D OUTPUT -p tcp \
        -m set --match-set unblockdns dst \
        -j REDIRECT --to-port "$_dns_tunnel_port" >/dev/null 2>&1; do :; done
done

if [ -n "$DNS_TUNNEL_PORT" ]; then
    for _dns_remote_port in 443 853; do
        if ! $IPT -t nat -C OUTPUT -p tcp --dport "$_dns_remote_port" \
            -m set --match-set unblockdns dst \
            -j REDIRECT --to-port "$DNS_TUNNEL_PORT" >/dev/null 2>&1; then
            $IPT -t nat -A OUTPUT -p tcp --dport "$_dns_remote_port" \
                -m set --match-set unblockdns dst \
                -j REDIRECT --to-port "$DNS_TUNNEL_PORT" >/dev/null 2>&1 || true
        fi
    done
fi

# TCP роутера (bot.txt) -> протокол из router_proto (по умолчанию
# vless), nat/REDIRECT. Семантика прежняя (инцидент 2026-10-05): правило
# держится, пока выбранный сервис УСТАНОВЛЕН — мёртвый сервис даёт RST
# (недоступно), а не прямую утечку мимо туннеля. Остальные порты
# снимаются циклом перед установкой выбранного.
_rp="$(router_proto)"
for _rpv in vl tr hy; do
    case "$_rpv" in
        vl) _rp_port="$PORT_VLESS" ;;
        tr) _rp_port="$PORT_TROJAN" ;;
        hy) _rp_port="$PORT_HYSTERIA" ;;
    esac
    while $IPT -t nat -D OUTPUT -p tcp \
        -m set --match-set unblockrouter dst \
        -j REDIRECT --to-port "$_rp_port" >/dev/null 2>&1
    do
        :
    done
done
case "$_rp" in
    vl) _rp_port="$PORT_VLESS" ;;
    tr) _rp_port="$PORT_TROJAN" ;;
    hy) _rp_port="$PORT_HYSTERIA" ;;
esac
if svc_installed "$(router_proto_init "$_rp")"; then
    if ! $IPT -t nat -C OUTPUT -p tcp \
        -m set --match-set unblockrouter dst \
        -j REDIRECT --to-port "$_rp_port" >/dev/null 2>&1
    then
        $IPT -t nat -A OUTPUT -p tcp \
            -m set --match-set unblockrouter dst \
            -j REDIRECT --to-port "$_rp_port" >/dev/null 2>&1 || true
    fi
else
    log_msg "router-proto: $_rp не установлен, unblockrouter TCP не заворачивается"
fi

# UDP роутера ранее уходил в ss-redir (PORT_SS) — это противоречило
# требованию "bot.txt только через xray". Снимаем такое правило.
while $IPT -t nat -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst \
    -j REDIRECT --to-port "$PORT_SS" >/dev/null 2>&1
do
    :
done

# nat/REDIRECT для UDP непригоден: xray не восстановит исходный адрес
# назначения. Локальный UDP заворачивается меткой в таблицу 100 (local
# default dev lo), после чего пакет проходит PREROUTING и попадает в
# TPROXY-инбаунд vless-udp-tproxy — тот же путь, что и у UDP из LAN.
while $IPT -t nat -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst \
    -j REDIRECT --to-port "$PORT_VLESS" >/dev/null 2>&1
do
    :
done

fi

if [ "$_tbl_sys" = 1 ]; then
_rp="$(router_proto)"
# Метка только для протоколов с UDP-перехватом (vl/hy): у trojan нет
# UDP-инбаунда, помеченный пакет ушёл бы в чёрную дыру lo без TPROXY.
if [ "$_rp" != "tr" ] && svc_installed "$(router_proto_init "$_rp")"; then
    if ! $IPT -t mangle -C OUTPUT -p udp \
        -m set --match-set unblockrouter dst \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    then
        $IPT -t mangle -A OUTPUT -p udp \
            -m set --match-set unblockrouter dst \
            -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" \
            >/dev/null 2>&1 \
            || log_msg "MARK(OUTPUT udp) add failed"
    fi
else
    while $IPT -t mangle -D OUTPUT -p udp \
        -m set --match-set unblockrouter dst \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    do
        :
    done
fi

fi

# ═════════════════════════════════════════════════════════════════════════
# 7. VPN-интерфейсы прошивки: ipset -> fwmark -> policy routing
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_sys" = 1 ]; then

# При отключении интерфейса нельзя оставлять старые MARK/CONNMARK-правила:
# они отправляют новый трафик в уже неработающую policy table.
vpn_del_mark_rules() {
    _vd_set="$1"
    _vd_mark="$2"

    for _vd_proto in tcp udp; do
        while $IPT -t mangle -D PREROUTING -p "$_vd_proto" \
            -m set --match-set "$_vd_set" dst \
            -j MARK --set-mark "$_vd_mark" >/dev/null 2>&1
        do
            :
        done
    done

    while $IPT -t mangle -D PREROUTING \
        -m conntrack --ctstate NEW \
        -m set --match-set "$_vd_set" dst \
        -j CONNMARK --set-mark "$_vd_mark" >/dev/null 2>&1
    do
        :
    done
}

# Копия common.sh:vpn_set_name_from_file (F1, аудит rev3) — текст
# обязан совпадать с common.sh; NDM-хук держит локальную копию,
# чтобы работать автономно, без sourcing общей библиотеки.
vpn_set_name_from_file() {
    _vsn="${1##*/}"
    _vsn="${_vsn%.txt}"
    _vsn="unblock${_vsn}"
    if [ "${#_vsn}" -gt 27 ]; then
        _vsn="$(printf '%s' "$_vsn" | cut -c1-27)"
    fi
    printf '%s\n' "$_vsn"
}

for vpn_file_name in /opt/etc/unblock/vpn-*.txt; do
    [ -f "$vpn_file_name" ] || continue

    vpn_unblock_name="$(basename "$vpn_file_name" .txt)"
    unblockvpn="$(vpn_set_name_from_file "$vpn_file_name")"
    # M2/F1: ID интерфейса берём из последнего сегмента basename;
    # hash-имена (vpn-<имя>-h<cksum>) его не содержат — читаем sidecar,
    # который vpn-хук записал рядом с файлом списка.
    _sid="/opt/etc/unblock/.${vpn_unblock_name}.iface"
    if [ -f "$_sid" ]; then
        vpn_type="$(sed -n '1p' "$_sid" 2>/dev/null)"
    else
        vpn_type="$(printf '%s\n' "$unblockvpn" | sed 's/-/ /g' | awk '{print $NF}')"
    fi
    [ -n "$vpn_type" ] || continue

    vpn_type_lower="$(printf '%s' "$vpn_type" | tr '[:upper:]' '[:lower:]')"
    vpn_table_id="$(grep -w "$vpn_type_lower" /opt/etc/iproute2/rt_tables 2>/dev/null \
        | awk '{print $1}' | head -n1 || true)"
    [ -n "$vpn_table_id" ] || continue
    vpn_mark_id="0xd${vpn_table_id}"

    vpn_link_up="$(curl -s --max-time 5 \
        "localhost:79/rci/show/interface/${vpn_type}/link" 2>/dev/null \
        | tr -d '"' || true)"

    if [ "$vpn_link_up" != "up" ]; then
        vpn_del_mark_rules "$unblockvpn" "$vpn_mark_id"
        ip -4 rule del from all table "$vpn_table_id" priority 1778 \
            >/dev/null 2>&1 || true
        ip -4 rule del fwmark "$vpn_mark_id" lookup "$vpn_table_id" \
            priority 1778 >/dev/null 2>&1 || true
        ip -4 route flush table "$vpn_table_id" >/dev/null 2>&1 || true
        ipset flush "$unblockvpn" >/dev/null 2>&1 || true
        continue
    fi

    ensure_set "$unblockvpn"

    fastnat="$(curl -s --max-time 5 localhost:79/rci/show/version 2>/dev/null | grep ppe || true)"
    software="$(curl -s --max-time 5 localhost:79/rci/show/rc/ppe 2>/dev/null \
        | grep software -C1 | head -1 | awk '{print $2}' | tr -d ',' || true)"
    hardware="$(curl -s --max-time 5 localhost:79/rci/show/rc/ppe 2>/dev/null \
        | grep hardware -C1 | head -1 | awk '{print $2}' | tr -d ',' || true)"

    if [ -z "$fastnat" ] && [ "$software" = "false" ] && [ "$hardware" = "false" ]; then
        for proto in tcp udp; do
            if ! $IPT -t mangle -C PREROUTING -p "$proto" \
                -m set --match-set "$unblockvpn" dst \
                -j MARK --set-mark "$vpn_mark_id" >/dev/null 2>&1
            then
                $IPT -t mangle -A PREROUTING -p "$proto" \
                    -m set --match-set "$unblockvpn" dst \
                    -j MARK --set-mark "$vpn_mark_id" >/dev/null 2>&1 || true
            fi
        done
    else
        if ! $IPT -t mangle -C PREROUTING \
            -m conntrack --ctstate NEW \
            -m set --match-set "$unblockvpn" dst \
            -j CONNMARK --set-mark "$vpn_mark_id" >/dev/null 2>&1
        then
            $IPT -t mangle -A PREROUTING \
                -m conntrack --ctstate NEW \
                -m set --match-set "$unblockvpn" dst \
                -j CONNMARK --set-mark "$vpn_mark_id" >/dev/null 2>&1 || true
        fi
        if ! $IPT -t mangle -C PREROUTING -j CONNMARK --restore-mark >/dev/null 2>&1; then
            $IPT -t mangle -A PREROUTING -j CONNMARK --restore-mark >/dev/null 2>&1 || true
        fi
    fi

    # Успешная обработка VPN-интерфейса не логируется: хук срабатывает на
    # каждое изменение состояния, и такие записи быстро раздували файл.
    # В лог попадают только ошибки.
done
fi

exit 0
