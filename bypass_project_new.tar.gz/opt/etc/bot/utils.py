# -*- coding: utf-8 -*-
# --- KeenZOO DNS policy v4 (stdlib only; before optional bot imports) ---
import datetime as _v4_datetime
import ast as _v4_ast
import concurrent.futures as _v4_futures
import fcntl as _v4_fcntl
import ipaddress as _v4_ip
import json as _v4_json
import os as _v4_os
from pathlib import Path as _V4Path
import re as _v4_re
import secrets as _v4_secrets
import signal as _v4_signal
import socket as _v4_socket
import socketserver as _v4_server
import struct as _v4_struct
import subprocess as _v4_subprocess
import sys as _v4_sys
import tempfile as _v4_temp
import threading as _v4_thread
import time as _v4_time

V4_PORT = 40512  # Stable loopback facade; never included among candidate ports.
V4_STATE = '/tmp/keenzoo-dns-v4.json'
V4_LOCK = '/tmp/keenzoo-dns-v4.lock'
V4_CONFIG = '/opt/etc/bot/bot_config.py'
V4_PRIORITY = ('hysteria', 'xray', 'trojan')
V4_MARKS = {'hysteria': 0x02000101, 'xray': 0x02000102, 'trojan': 0x02000103}
V4_EMERGENCY_MARK = 0x02000104

# dns4.2.33 (статический аудит, F-01): резолверы специальных зон
# (альтернативные TLD). Запросы к ним идут ЧЕРЕЗ КОНТРОЛЛЕР маркированным
# TCP-сокетом (через туннель), а не напрямую: немаркированный внешний
# DNS на :53 закрыт фильтром. Состав синхронен с dnsmasq.conf, где эти
# зоны направлены на петлевую фасаду контроллера (127.0.0.1#40512).
V4_ZONE_SERVERS = {
    'lib': ('65.21.1.106', '95.216.99.249',
            '94.247.43.254', '195.10.195.195'),
    'emc': ('95.216.99.249',),
    'coin': ('95.216.99.249',),
    'bazar': ('95.216.99.249',),
    'geek': ('95.216.99.249',),
    'libre': ('95.216.99.249',),
    'bbs': ('95.216.99.249',),
    'chan': ('95.216.99.249',),
    'cyb': ('95.216.99.249',),
    'indy': ('95.216.99.249',),
    'neo': ('95.216.99.249',),
    'null': ('95.216.99.249',),
    'pirate': ('95.216.99.249',),
}


def _v4_zone_for(name):
    """Имя зоны (без точки), если запрос к специальной зоне."""
    try:
        text = bytes(name).rstrip(b'.').decode('ascii').lower()
    except (UnicodeDecodeError, AttributeError,
            TypeError):
        return None
    if not text:
        return None
    if text in V4_ZONE_SERVERS:
        return text
    for zone in V4_ZONE_SERVERS:
        if text.endswith('.' + zone):
            return zone
    return None


def v4_config(path=V4_CONFIG):
    allowed = {'dnsovertls_ports', 'dnsoverhttps_ports', 'bootstrap_resolvers',
               'dns_health_domain', 'dns_policy_interval', 'dns_policy_pool_hours',
               'dns_policy_recovery_interval',
               'localporthysteria', 'localportvless', 'localporttrojan'}
    raw = {}
    tree = _v4_ast.parse(_V4Path(path).read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, _v4_ast.Assign):
            for target in node.targets:
                if isinstance(target, _v4_ast.Name) and target.id in allowed:
                    raw[target.id] = _v4_ast.literal_eval(node.value)
    ports = raw.get('dnsovertls_ports', [40500, 40501, 40502, 40503]) + raw.get('dnsoverhttps_ports', [40508, 40509, 40510, 40511])
    if not ports or len(ports) > 16 or any(type(p) is not int or not 1024 <= p <= 65535 or p == V4_PORT for p in ports):
        raise ValueError('invalid DNS candidate ports')
    bootstrap = list(dict.fromkeys(str(_v4_ip.IPv4Address(p)) for p in raw.get('bootstrap_resolvers', ['9.9.9.9', '8.8.8.8', '1.1.1.1'])))
    if not 1 <= len(bootstrap) <= 8 or any(not _v4_ip.IPv4Address(p).is_global for p in bootstrap):
        raise ValueError('bootstrap_resolvers must contain 1..8 public IPv4 addresses')
    domain = raw.get('dns_health_domain', 'example.com').rstrip('.')
    if len(domain) > 253 or not all(_v4_re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', s) for s in domain.split('.')):
        raise ValueError('invalid DNS health domain')
    interval = raw.get('dns_policy_interval', 3600)
    hours = raw.get('dns_policy_pool_hours', [11, 23])
    recovery = raw.get('dns_policy_recovery_interval', 300)
    if type(interval) is not int or not 1800 <= interval <= 3600:
        raise ValueError('DNS idle control interval must be 1800..3600 seconds; migrate legacy settings')
    if hours != [11, 23] or any(type(h) is not int for h in hours):
        raise ValueError('DNS pool hours must be [11, 23] in router local time')
    if type(recovery) is not int or recovery != 300:
        raise ValueError('DNS Primary recovery interval must be 300 seconds')
    # 4.2.72 Л-4: длины пар одинаковы по построению (3 приоритета —
    # 3 порта); «zip(strict=)» сознательно не используется — требует
    # Python 3.10+, а Entware на старых архитектурах бывает ниже.
    targets = dict(zip(V4_PRIORITY, (raw.get('localporthysteria', 10830), raw.get('localportvless', 10810), raw.get('localporttrojan', 10829))))
    if any(type(p) is not int or not 1024 <= p <= 65535 or p == V4_PORT for p in targets.values()):
        raise ValueError('invalid tunnel listener port')
    return {'ports': list(dict.fromkeys(ports)), 'bootstrap': bootstrap, 'domain': domain,
            'interval': interval, 'pool_hours': hours, 'recovery_interval': recovery, 'targets': targets}


def v4_name(data, offset):
    labels, seen, end = [], set(), None
    for _ in range(128):
        if offset >= len(data) or offset in seen:
            raise ValueError('invalid DNS name')
        seen.add(offset)
        n = data[offset]
        if n & 0xc0 == 0xc0:
            if offset + 1 >= len(data):
                raise ValueError('short DNS pointer')
            end = end if end is not None else offset + 2
            offset = ((n & 63) << 8) | data[offset+1]
        elif n == 0:
            return b'.'.join(labels).lower(), end if end is not None else offset + 1
        elif n <= 63 and offset + 1 + n <= len(data):
            labels.append(data[offset+1:offset+1+n])
            offset += n + 1
        else:
            raise ValueError('invalid DNS label')
    raise ValueError('DNS name too complex')


def v4_question(data):
    if len(data) < 12 or _v4_struct.unpack('!H', data[4:6])[0] != 1:
        raise ValueError('exactly one DNS question required')
    name, offset = v4_name(data, 12)
    if offset + 4 > len(data):
        raise ValueError('short question')
    return (name, data[offset:offset+4]), offset + 4


def v4_query(domain):
    name = b''.join(bytes([len(s)]) + s.encode('ascii') for s in domain.split('.')) + b'\0'
    return _v4_struct.pack('!HHHHHH', _v4_secrets.randbits(16), 0x0120, 1, 0, 0, 1) + name + b'\0\x01\0\x01' + b'\0\0\x29\x04\xd0\0\0\x80\0\0\0'


def v4_answer(data, query, health=False, secure=False):
    if len(data) < 12 or data[:2] != query[:2]:
        raise ValueError('DNS transaction mismatch')
    flags = _v4_struct.unpack('!H', data[2:4])[0]
    if not flags & 0x8000 or flags & 0x7800 or v4_question(data)[0] != v4_question(query)[0]:
        raise ValueError('DNS response/question mismatch')
    if health:
        if flags & 0x020f or (secure and not flags & 0x0020):
            raise ValueError('health response lacks validated positive result')
        question, offset = v4_question(data)
        if question[1] != b'\0\x01\0\x01':
            raise ValueError('health requires an IN A question')
        addresses, aliases = set(), {}
        for _ in range(_v4_struct.unpack('!H', data[6:8])[0]):
            owner, offset = v4_name(data, offset)
            if offset + 10 > len(data):
                raise ValueError('short resource record')
            kind, cls, _, size = _v4_struct.unpack('!HHIH', data[offset:offset+10])
            offset += 10
            if offset + size > len(data):
                raise ValueError('short resource data')
            if kind == 1 and cls == 1 and size == 4:
                addresses.add(owner)
            elif kind == 5 and cls == 1:
                alias, end = v4_name(data, offset)
                if end != offset + size:
                    raise ValueError('invalid CNAME data')
                aliases[owner] = alias
            offset += size
        name = question[0]
        for _ in range(32):
            if name in addresses:
                break
            if name not in aliases:
                raise ValueError('health response has no matching IPv4 answer')
            name = aliases[name]
        else:
            raise ValueError('CNAME chain too complex')
    return data


def v4_recv(sock, count, deadline=None):
    chunks = bytearray()
    deadline = deadline or (_v4_time.monotonic() + (sock.gettimeout() or 2))
    while len(chunks) < count:
        remaining = deadline - _v4_time.monotonic()
        if remaining <= 0:
            raise TimeoutError("DNS frame deadline")
        sock.settimeout(remaining)
        data = sock.recv(count - len(chunks))
        if not data:
            raise OSError('short DNS TCP frame')
        chunks.extend(data)
    return bytes(chunks)


def v4_exchange(query, host, port, tcp=False, mark=0, timeout=2):
    # Every exchange uses a fresh socket. Mark is set BEFORE connect; a failed
    # SO_MARK never falls back to unmarked/direct DNS.
    with _v4_socket.socket(_v4_socket.AF_INET, _v4_socket.SOCK_STREAM if tcp else _v4_socket.SOCK_DGRAM) as sock:
        deadline = _v4_time.monotonic() + timeout
        sock.settimeout(timeout)
        if mark:
            sock.setsockopt(_v4_socket.SOL_SOCKET, getattr(_v4_socket, 'SO_MARK', 36), mark)
        sock.connect((host, port))
        if tcp:
            remaining = deadline - _v4_time.monotonic()
            if remaining <= 0:
                raise TimeoutError("DNS connect deadline")
            sock.settimeout(remaining)
            sock.sendall(_v4_struct.pack('!H', len(query)) + query)
            size = _v4_struct.unpack('!H', v4_recv(sock, 2, deadline))[0]
            data = v4_recv(sock, size, deadline)
        else:
            sock.send(query)
            data = sock.recv(65535)
    v4_answer(data, query)
    if not tcp and data[2] & 2:
        return v4_exchange(query, host, port, True, mark, timeout)
    return data


def v4_fail(query):
    try:
        end = v4_question(query)[1]
        return query[:2] + _v4_struct.pack('!HHHHH', 0x8082 | (query[2] & 1) << 8, 1, 0, 0, 0) + query[12:end]
    except (ValueError, IndexError):
        return b''


def v4_identity(pid):
    text = _V4Path('/proc/%d/stat' % pid).read_text()
    fields = text[text.rfind(')')+2:].split()
    if fields[0] == 'Z':
        raise ValueError('worker is a zombie')
    return fields[19]


def v4_read_state(path):
    fd = _v4_os.open(path, _v4_os.O_RDONLY | _v4_os.O_NOFOLLOW)
    with _v4_os.fdopen(fd) as stream:
        stat = _v4_os.fstat(stream.fileno())
        if stat.st_uid != _v4_os.geteuid() or stat.st_mode & 0o022:
            raise ValueError('unsafe DNS state ownership')
        return _v4_json.loads(stream.read(65536))


def v4_status(path=V4_STATE, check_age=True):
    try:
        result = v4_read_state(path)
        if result.get('version') != 4 or v4_identity(int(result['pid'])) != result['start']:
            return {}
        age = _v4_time.time() - result['epoch']
        limit = 180 if result.get('health_mode') == 'hybrid' else max(180, int(result.get('interval', 15))*3 + 120)
        if check_age and (age < -2 or age > limit):
            return {}
        return result
    except (OSError, ValueError, KeyError, IndexError, TypeError):
        return {}


class DNSPolicyV4:
    # The maintenance tick reads local files and publishes a heartbeat ONLY.
    # It is NOT a DNS probe, subprocess, cron job or connection to the WAN.
    HEARTBEAT = 30
    EVENT_COOLDOWN = 30

    def __init__(self, cfg, state_path=V4_STATE, exchange=v4_exchange):
        self.cfg, self.state_path, self.exchange = cfg, state_path, exchange
        self.stop = _v4_thread.Event()
        self.wake = _v4_thread.Event()
        self.rerank = _v4_thread.Event()
        self.network_event = _v4_thread.Event()
        self.guard = _v4_thread.RLock()
        self.active = None
        self.mode = 'DNS_UNAVAILABLE'
        self.preferred = None
        self.metrics = {}
        self.last_pool = 0
        self.last_restart = {}
        self.deploy_owner = self.deployment_owner()
        self.last_log = None
        self.query_count = 0
        self.health_query_count = 0
        self.passive_confirmations = 0
        self.failure_events = 0
        self.generation = 0
        self.last_checked = 0
        self.last_good = 0
        self.last_evidence_epoch = None
        self.last_control_epoch = None
        self.last_primary_probe = 0
        self.last_primary_probe_epoch = None
        self.last_heartbeat = _v4_time.monotonic()
        self.last_maintenance = None
        self.pending_failure = False
        self.pending_network = False
        self.pending_rerank = False
        self.next_event = 0
        self.initialized = False
        self.check_reason = 'starting'
        self.next_pool_epoch = self.next_pool_time(_v4_time.time())
        self.last_calendar_slot = ''
        self.last_wall = _v4_time.time()
        self.config_stamp = None
        self.listener_stamp = None
        try:
            old = v4_read_state(state_path)
            if old.get('candidates') == cfg['ports'] and old.get('preferred') in cfg['ports']:
                self.preferred = old['preferred']
        except (OSError, ValueError):
            pass

    def next_pool_time(self, now):
        local = _v4_datetime.datetime.fromtimestamp(now)
        for day in (0, 1, 2):
            date = local.date() + _v4_datetime.timedelta(days=day)
            for hour in self.cfg.get('pool_hours', [11, 23]):
                slot = _v4_datetime.datetime.combine(date, _v4_datetime.time(hour))
                # timestamp() uses the same local TZ/DST rules as the router.
                if slot.timestamp() > now:
                    return slot.timestamp()
        raise ValueError('cannot schedule DNS pool')

    def health(self, target, secure=False, samples=1):
        rtts = []
        for _ in range(samples):
            if self.stop.is_set():
                return None
            query = v4_query(self.cfg['domain'])
            started = _v4_time.monotonic()
            with self.guard:
                self.health_query_count += 1
            try:
                response = self.exchange(query, *target)
                v4_answer(response, query, health=True, secure=secure)
                rtts.append((_v4_time.monotonic() - started) * 1000)
            except (OSError, ValueError):
                return None
        return sum(rtts) / len(rtts)

    def scan_local(self, ports):
        if not ports:
            return
        def one(port):
            target = ('127.0.0.1', port, False, 0)
            result = self.health(target, True)
            if result is None:  # Confirm an error; steady healthy port costs ONE query.
                result = self.health(target, True)
            return port, result
        with _v4_futures.ThreadPoolExecutor(max_workers=3) as pool:
            for port, rtt in pool.map(one, ports):
                with self.guard:
                    self.metrics[port] = {'rtt': rtt, 'at': _v4_time.time()}
                    if port == self.preferred:
                        self.last_primary_probe = _v4_time.monotonic()
                        self.last_primary_probe_epoch = _v4_time.time()

    @staticmethod
    def deployment_owner():
        try:
            root = _V4Path('/tmp/keenzoo_deploy.lockdir')
            return ((root/'pid').read_text().strip(), (root/'start').read_text().strip())
        except OSError:
            return None

    @staticmethod
    def listener_identity(protocol, port):
        inodes = set()
        try:
            # РАУД 37 (итоговый аудит, P2-03): проект IPv4-only.
            for name in ('tcp',):
                with open('/proc/net/' + name) as table:
                    for row in table:
                        columns = row.split()
                        if len(columns) > 9 and columns[3] == '0A' and int(columns[1].split(':')[-1], 16) == int(port):
                            inodes.add('socket:[' + columns[9] + ']')
            if not inodes:
                return False, False
            for directory in _V4Path('/proc').glob('[0-9]*'):
                try:
                    argv0 = (directory/'cmdline').read_bytes().split(b'\0', 1)[0].decode('utf-8', 'replace')
                    if _v4_os.path.basename(argv0) != protocol:
                        continue
                    for fd in (directory/'fd').iterdir():
                        try:
                            if _v4_os.readlink(fd) in inodes:
                                return True, True
                        except OSError:
                            pass
                except OSError:
                    continue
        except (OSError, ValueError):
            return True, False  # Unverifiable is not permission to start/probe.
        return True, False

    def tunnel_ready(self, protocol):
        # Fail-closed proof of the exact marked path. filter blocks tcp/53
        # if NAT redirection disappears; it is not PID/listener verification.
        mark = hex(V4_MARKS[protocol])
        port = str(self.cfg['targets'][protocol])
        rules = [
            ['-t', 'nat', '-C', 'OUTPUT', '-j', 'KZ_DNS_V4'],
            ['-t', 'nat', '-C', 'KZ_DNS_V4', '-p', 'tcp', '--dport', '53', '-m', 'mark', '--mark', mark, '-j', 'REDIRECT', '--to-ports', port],
            ['-t', 'filter', '-C', 'OUTPUT', '-p', 'tcp', '--dport', '53', '-m', 'mark', '--mark', mark, '-j', 'REJECT'],
        ]
        try:
            if not all(_v4_subprocess.run(['iptables', '-w', '2'] + r, stdout=_v4_subprocess.DEVNULL, stderr=_v4_subprocess.DEVNULL, timeout=4).returncode == 0 for r in rules):
                return False
        except (OSError, _v4_subprocess.TimeoutExpired):
            return False
        listening, owned = self.listener_identity(protocol, int(port))
        if listening:
            return owned
        if _V4Path('/tmp/keenzoo_protocol_update.lockdir').exists():
            return False
        if _V4Path('/tmp/keenzoo_installing.d').exists() \
                or _V4Path('/tmp/keenzoo_installing').exists():
            owner = self.deployment_owner()
            # A new worker is started by deploy only AFTER code/config copy.
            # An old worker must not revive a daemon while binaries are replaced.
            if owner is None or owner != self.deploy_owner:
                return False
        now = _v4_time.monotonic()
        if now - self.last_restart.get(protocol, -1000) < 90:
            return False
        self.last_restart[protocol] = now
        init = {'hysteria': 'S57hysteria', 'xray': 'S24xray', 'trojan': 'S22trojan'}[protocol]
        path = '/opt/etc/init.d/' + init
        try:
            if _v4_re.search(r'^\s*ENABLED\s*=\s*no\b', _V4Path(path).read_text(), _v4_re.M):
                return False
            _v4_subprocess.run([path, 'start'], stdin=_v4_subprocess.DEVNULL, stdout=_v4_subprocess.DEVNULL, stderr=_v4_subprocess.DEVNULL, timeout=8)
            return self.listener_identity(protocol, int(port))[1]  # Then health() must verify the actual DNS exchange.
        except (OSError, _v4_subprocess.TimeoutExpired):
            return False

    def choose(self, full=False, reason='control'):
        """One requested round, NOT a periodic polling loop.

        Only candidates verified in THIS round may be promoted. Saved pool
        metrics are diagnostic, never permission to use a 12-hour-old backup.
        """
        self.check_reason = reason
        active = self.active
        secure_active = bool(active and active[0] == '127.0.0.1')
        recovery = reason == 'primary-recovery' and active is not None
        if full or not self.initialized or (recovery and self.preferred is None):
            ports = list(self.cfg['ports'])
        elif recovery:
            ports = [self.preferred] if self.preferred in self.cfg['ports'] else []
        else:
            ports = [active[1]] if secure_active else []
        tested = set(ports)
        self.scan_local(ports)
        self.initialized = True
        if recovery:
            self.last_primary_probe = _v4_time.monotonic()
            self.last_primary_probe_epoch = _v4_time.time()
        # In event/control mode first confirm the active resolver. The failed
        # preferred resolver has its own five-minute timer, not every event.
        active_ok = secure_active and active[1] in tested and self.metrics[active[1]]['rtt'] is not None
        if not recovery and not active_ok and len(tested) < len(self.cfg['ports']):
            remaining = [p for p in self.cfg['ports'] if p not in tested]
            self.scan_local(remaining)
            tested.update(remaining)
        if len(tested) == len(self.cfg['ports']):
            self.last_pool = _v4_time.time()
            if self.preferred is None:
                self.last_primary_probe = _v4_time.monotonic()
                self.last_primary_probe_epoch = self.last_pool
        with self.guard:
            eligible = sorted((self.metrics[p]['rtt'], p) for p in tested if self.metrics[p]['rtt'] is not None)
        # Keep a working Primary sticky. Keep an already working local backup
        # until Primary recovers, rather than moving between backups for RTT.
        # An explicit rerank is the single exception: it re-evaluates the pure
        # fastest candidate and drops both active and backup stickiness.
        order = [p for _, p in eligible]
        if reason != 'rerank':
            # Insert preferred FIRST so the working active backup wins when
            # both are eligible: the recovery probe/rerank owns the return to
            # Primary; an event/pool scan must not cause a second switch.
            for port in (self.preferred, active[1] if secure_active else None):
                if port in order:
                    order.remove(port)
                    order.insert(0, port)
        for port in order:
            target = ('127.0.0.1', port, False, 0)
            if target != active:
                # First positive was scan_local(); a second is required before
                # entering a different state/target, including initial startup.
                if self.health(target, True) is None:
                    with self.guard:
                        self.metrics[port] = {'rtt': None, 'at': _v4_time.time()}
                    continue
            if self.preferred is None or self.preferred not in self.cfg['ports']:
                self.preferred = port
            if port == self.preferred:
                self.last_primary_probe = _v4_time.monotonic()
                self.last_primary_probe_epoch = _v4_time.time()
            self.commit('LOCAL_DNSSEC', target)
            return
        if recovery:
            # Do NOT ping the working backup or all tunnels every five minutes.
            self.publish()
            return
        for protocol in V4_PRIORITY:
            if self.stop.is_set():
                return
            if not self.tunnel_ready(protocol):
                continue
            for host in self.cfg['bootstrap']:
                target = (host, 53, True, V4_MARKS[protocol])
                if self.target_ready(target, active):
                    self.commit('TUNNEL_DNS', target)
                    return
        for host in self.cfg['bootstrap']:
            for tcp in (False, True):
                target = (host, 53, tcp, V4_EMERGENCY_MARK)
                if self.target_ready(target, active):
                    self.commit('EMERGENCY_DNS', target)
                    return
        self.commit('DNS_UNAVAILABLE', None)

    def target_ready(self, target, active):
        result = self.health(target)
        if result is None:
            result = self.health(target)
        return result is not None and (target == active or self.health(target) is not None)

    def commit(self, mode, target):
        with self.guard:
            if target != self.active or mode != self.mode:
                self.generation += 1
                self.last_good = 0
                self.last_evidence_epoch = None
                self.pending_failure = False
            self.mode, self.active = mode, target
            self.last_checked = self.last_heartbeat = _v4_time.monotonic()
            self.last_control_epoch = _v4_time.time()
            if target:
                self.last_good = self.last_checked
                self.last_evidence_epoch = self.last_control_epoch
            else:
                self.last_primary_probe = self.last_checked
            # dns4.2.37 H-1: длинный гейт (recovery_interval) после провала
            # СОХРАНЁН как антидребезг КЛИЕНТСКИХ ошибок — без него каждый
            # сбой запроса долбил бы пробы каждые 30 с при отсутствующем WAN
            # (регрессия «unavailable retry is bounded»). Исключение из
            # гейта для сетевых событий (--dns-event) и переранжиров сделано
            # в tick(): они обрабатываются сразу, не ожидая 5 минут.
            self.next_event = max(self.next_event, self.last_checked +
                                  (self.EVENT_COOLDOWN if target else self.cfg.get('recovery_interval', 300)))
        self.publish()

    def publish(self):
        with self.guard:
            target, mode = self.active, self.mode
            protocol = next((p for p, mark in V4_MARKS.items() if target and target[3] == mark), None)
            state = {'version': 4, 'pid': _v4_os.getpid(), 'start': v4_identity(_v4_os.getpid()),
                     'epoch': int(_v4_time.time()), 'mode': mode, 'active': list(target) if target else None,
                     'preferred': self.preferred, 'tunnel': protocol, 'listen_port': V4_PORT,
                     'candidates': self.cfg['ports'], 'metrics': self.metrics, 'query_count': self.query_count,
                     'health_mode': 'hybrid', 'interval': self.cfg['interval'],
                     'pool_hours': self.cfg.get('pool_hours', [11, 23]),
                     'recovery_interval': self.cfg.get('recovery_interval', 300),
                     'next_pool_epoch': int(self.next_pool_epoch), 'last_pool_epoch': self.last_pool,
                     'last_evidence_epoch': self.last_evidence_epoch,
                     'last_control_epoch': self.last_control_epoch,
                     'last_primary_probe_epoch': self.last_primary_probe_epoch,
                     'health_query_count': self.health_query_count,
                     'passive_confirmations': self.passive_confirmations,
                     'failure_events': self.failure_events, 'check_reason': self.check_reason}
        path = _V4Path(self.state_path)
        fd, filename = _v4_temp.mkstemp(prefix=path.name+'.', dir=str(path.parent))
        try:
            with _v4_os.fdopen(fd, 'w') as stream:
                stream.write(_v4_json.dumps(state, separators=(',', ':')))
            _v4_os.replace(filename, path)
        finally:
            if _v4_os.path.exists(filename):
                _v4_os.unlink(filename)
        key = (mode, target, self.preferred)
        # Bound the same inode held by stdout, even during repeated flaps.
        if self.state_path == V4_STATE:
            logfile = _V4Path('/opt/var/log/unblock_dns_v4.log')
            try:
                if logfile.stat().st_size > 65536:
                    with logfile.open('rb') as stream:
                        stream.seek(-32768, 2)
                        tail = stream.read()
                    logfile.write_bytes(tail)
            except OSError:
                pass
        if key != self.last_log:
            self.last_log = key
            # stdout goes to a bounded service log (only transitions, no names).
            print('DNSv4 mode=%s preferred=%s active=%s tunnel=%s' % (mode, self.preferred, target, protocol), flush=True)

    def request_check(self, network=False, rerank=False):
        with self.guard:
            was_pending = self.pending_network or self.pending_failure or self.pending_rerank
            if network:
                self.pending_network = True
            elif not rerank:
                self.pending_failure = True
            if rerank:
                self.pending_rerank = True
            if not was_pending:
                self.wake.set()

    def observe(self, query, response, target, generation, rtt):
        """No DNS I/O here. Only the exact current upstream may refresh proof.

        A positive, matching IN A answer with AD and CD=0 is suitable passive
        evidence. Unsigned domains, NXDOMAIN, CD=1 and non-A replies are NOT
        DNSSEC failures, and cannot indefinitely postpone the control timer.
        """
        flags = _v4_struct.unpack('!H', response[2:4])[0]
        qflags = _v4_struct.unpack('!H', query[2:4])[0]
        positive = False
        try:
            v4_answer(response, query, health=True, secure=self.mode == 'LOCAL_DNSSEC')
            positive = not bool(qflags & 0x0010)
        except ValueError:
            pass
        with self.guard:
            if self.active != target or self.generation != generation:
                return
            secure = self.mode == 'LOCAL_DNSSEC'
            if positive:
                self.last_good = _v4_time.monotonic()
                self.last_evidence_epoch = _v4_time.time()
                self.passive_confirmations += 1
                if secure:
                    self.metrics[target[1]] = {'rtt': rtt, 'at': self.last_evidence_epoch}
            # AD absence is meaningful only for the configured signed control
            # name with an explicit AD request and CD=0; never for arbitrary
            # unsigned names. A probe confirms every failure before switching.
            known_signed = (v4_question(query)[0] ==
                            (self.cfg.get('domain', 'example.com').encode('ascii').lower(), b'\0\x01\0\x01'))
            lost_ad = secure and known_signed and qflags & 0x0020 and not qflags & 0x0010 and not flags & 0x0020
            if flags & 15 in (2, 5) or lost_ad:
                self.failure_events += 1
                self.request_check()

    def forward(self, query, tcp=False):
        # Invalid client packets must not trigger health probes (DoS amplifier).
        try:
            question = v4_question(query)
            if query[2] & 0xf8:
                raise ValueError('invalid query opcode')
        except (ValueError, IndexError):
            return v4_fail(query)
        # dns4.2.33/4.2.35 (аудиты, F-01, R-04): специальные зоны
        # резолвит только контроллер; путь к резолверам зон зависит
        # от режима политики (см. forward_zone): туннель — через
        # туннель, режимы без туннеля — разрешённым прямым путём
        # (аварийная метка). Прямой немаркированный DNS закрыт.
        # question = ((имя, тип-класс), смещение)
        _fwd_zone = _v4_zone_for(question[0][0])
        if _fwd_zone:
            return self.forward_zone(query, _fwd_zone)
        with self.guard:
            target, generation = self.active, self.generation
            fresh = _v4_time.monotonic() - self.last_heartbeat <= 180
            self.query_count += 1
        if not target or not fresh:
            self.request_check()
            return v4_fail(query)
        try:
            started = _v4_time.monotonic()
            response = self.exchange(query, *target)
            v4_answer(response, query)
            self.observe(query, response, target, generation, (_v4_time.monotonic()-started)*1000)
            return response
        except (OSError, ValueError, IndexError):
            with self.guard:
                if self.active == target and self.generation == generation:
                    self.failure_events += 1
                    self.request_check()
            return v4_fail(query)

    def forward_zone(self, query, zone):
        # Публичные резолверы альтернативные TLD не знают — зоны
        # ходят только к резолверам зон (V4_ZONE_SERVERS). Выбор пути
        # по режиму политики:
        #   TUNNEL_DNS  — через туннель, метка активного кандидата;
        #   LOCAL_DNSSEC / EMERGENCY_DNS — разрешённым ПРЯМЫМ путём
        #     (аварийная метка: для неё в фильтре есть RETURN), как и
        #     до закрытия немаркированного DNS, но строго к
        #     закреплённым адресам резолверов зон;
        #   нет рабочего резолвера — SERVFAIL, как и весь трафик.
        with self.guard:
            target = self.active
            mode = self.mode
            fresh = (_v4_time.monotonic()
                     - self.last_heartbeat <= 180)
            self.query_count += 1
        if not target or not fresh \
                or mode == 'DNS_UNAVAILABLE':
            self.request_check()
            return v4_fail(query)
        if mode == 'TUNNEL_DNS':
            _fz_mark = target[3]
            if _fz_mark not in V4_MARKS.values():
                return v4_fail(query)
        else:
            _fz_mark = V4_EMERGENCY_MARK
        # dns4.2.35 (ре-аудит): общий бюджет зоны ~4 с, иначе при
        # недоступных резолверах запрос занимает слоты семафора на
        # срок до «число апстримов × 2 с». Остаток бюджета идёт в
        # таймаут каждой попытки.
        _fz_deadline = _v4_time.monotonic() + 4.0
        for host in V4_ZONE_SERVERS[zone]:
            _fz_left = _fz_deadline - _v4_time.monotonic()
            if _fz_left < 0.2:
                break
            try:
                response = self.exchange(
                    query, host, 53, True, _fz_mark,
                    timeout=min(2.0, _fz_left))
                v4_answer(response, query)
                return response
            except (OSError, ValueError, IndexError):
                continue
        return v4_fail(query)

    def listener_fingerprint(self):
        # Socket inode changes expose stubby/DoH restarts without querying DNS
        # or spawning pidof/netstat. Only local IPv4 listener ports are used.
        result = []
        ports = set(self.cfg['ports']) | set(self.cfg.get('targets', {}).values())
        for kind in ('tcp', 'udp'):
            try:
                for row in _V4Path('/proc/net/' + kind).read_text().splitlines()[1:]:
                    cols = row.split()
                    host, port = cols[1].split(':')
                    if host in ('0100007F', '00000000') and int(port, 16) in ports and cols[3] in ('0A', '07'):
                        result.append((kind, port, cols[9]))
            except (OSError, ValueError, IndexError):
                return None  # A failed proc read is not evidence of a restart.
        return tuple(sorted(result))

    def maintenance(self):
        if _V4Path('/opt/etc/unblock/.disabled').exists():
            self.stop.set()
            return
        try:
            stat = _V4Path(V4_CONFIG).stat()
        except OSError:
            # A transiently unreadable config keeps the last validated values;
            # it must not mark a working resolver unavailable every tick.
            stat = None
        stamp = (stat.st_ino, stat.st_mtime_ns, stat.st_size) if stat is not None else self.config_stamp
        if stamp is not None and stamp != self.config_stamp:
            updated = v4_config()
            if updated != self.cfg:
                with self.guard:
                    self.cfg = updated
                    self.metrics = {}
                    self.next_pool_epoch = self.next_pool_time(_v4_time.time())
                self.request_check(network=True)
            self.config_stamp = stamp
        listeners = self.listener_fingerprint()
        if listeners is not None:
            if self.listener_stamp is not None and listeners != self.listener_stamp:
                self.request_check(network=True)
            self.listener_stamp = listeners

    def tick(self):
        """Deterministic scheduling step. Heartbeats never call choose()."""
        now, wall = _v4_time.monotonic(), _v4_time.time()
        self.last_heartbeat = now
        if wall < self.last_wall - 120:
            self.next_pool_epoch = self.next_pool_time(wall)
        self.last_wall = wall
        if self.network_event.is_set():
            self.network_event.clear()
            self.request_check(network=True)
        if self.rerank.is_set():
            self.rerank.clear()
            self.request_check(rerank=True)
        reason, full = None, False
        if not self.initialized:
            reason, full = 'startup', True
        elif wall >= self.next_pool_epoch:
            # A forward clock jump coalesces missed slots to ONE scan. A clock
            # rollback must not scan the same local calendar slot twice.
            slot = _v4_datetime.datetime.fromtimestamp(self.next_pool_epoch).strftime('%Y-%m-%d %H')
            self.next_pool_epoch = self.next_pool_time(wall)
            if slot > self.last_calendar_slot:
                self.last_calendar_slot = slot
                reason, full = 'scheduled-pool', True
        with self.guard:
            # dns4.2.37 H-1: сетевые события (--dns-event от WAN-воркера)
            # и запросы переранжирования проходят БЕЗ ожидания
            # next_event — иначе после DNS_UNAVAILABLE (когда
            # next_event = now + recovery_interval) поднявшийся туннель
            # игнорировался до пяти минут. Клиентские ошибки по-прежнему
            # антидребезжатся гейтом времени.
            if reason is None and (self.pending_network or self.pending_failure or self.pending_rerank) \
                    and (self.pending_network or self.pending_rerank or now >= self.next_event):
                full = self.pending_network or self.pending_rerank
                reason = 'rerank' if self.pending_rerank else ('network-event' if full else 'client-error')
                if self.pending_rerank:
                    self.preferred = None
                self.pending_network = self.pending_failure = self.pending_rerank = False
                self.next_event = now + self.EVENT_COOLDOWN
            active_primary = self.active == ('127.0.0.1', self.preferred, False, 0)
            recovery_due = not active_primary and now - self.last_primary_probe >= self.cfg.get('recovery_interval', 300)
            if reason is None and recovery_due:
                reason = 'primary-recovery'
                full = self.active is None
            if reason is None and self.active and now - max(self.last_good, self.last_checked) >= self.cfg['interval']:
                reason = 'idle-control'
        if reason:
            if full:
                with self.guard:
                    if self.pending_rerank:
                        self.preferred = None
                    self.pending_network = self.pending_failure = self.pending_rerank = False
            self.choose(full=full, reason=reason)
        # Bound status age independently of the hour-long health interval.
        # publish() does local atomic file replacement, no DNS requests.
        self.publish()
        now = _v4_time.monotonic()
        waits = [self.HEARTBEAT, max(.05, self.next_pool_epoch - _v4_time.time())]
        with self.guard:
            if self.pending_network or self.pending_failure or self.pending_rerank:
                waits.append(max(.05, self.next_event - now))
            if self.active != ('127.0.0.1', self.preferred, False, 0):
                waits.append(max(.05, self.last_primary_probe + self.cfg.get('recovery_interval', 300) - now))
            if self.active:
                waits.append(max(.05, max(self.last_good, self.last_checked) + self.cfg['interval'] - now))
        return min(waits)

    def monitor(self):
        while not self.stop.is_set():
            self.wake.clear()
            try:
                now = _v4_time.monotonic()
                if self.last_maintenance is None or now-self.last_maintenance >= self.HEARTBEAT:
                    self.maintenance()
                    self.last_maintenance = now
                if self.stop.is_set():
                    break
                delay = self.tick()
            except Exception as exc:
                self.commit('DNS_UNAVAILABLE', None)
                print('DNSv4 monitor error=%s' % type(exc).__name__, flush=True)
                delay = self.HEARTBEAT
            self.wake.wait(delay)


class _V4Bounded(_v4_server.ThreadingMixIn):
    daemon_threads = True
    allow_reuse_address = True
    def process_request(self, request, address):
        if not self.slots.acquire(False):
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except Exception:
            self.slots.release()
            raise
    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.slots.release()
    def handle_error(self, request, address):
        pass


class V4UDP(_V4Bounded, _v4_server.UDPServer):
    max_packet_size = 65535


class V4TCP(_V4Bounded, _v4_server.TCPServer):
    request_queue_size = 32


class V4UDPHandler(_v4_server.BaseRequestHandler):
    def handle(self):
        data, sock = self.request
        result = self.server.policy.forward(data)
        if result:
            sock.sendto(result, self.client_address)


class V4TCPHandler(_v4_server.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(4)
        size = _v4_struct.unpack('!H', v4_recv(self.request, 2))[0]
        data = v4_recv(self.request, size)
        result = self.server.policy.forward(data, True)
        if result:
            self.request.sendall(_v4_struct.pack('!H', len(result)) + result)


def v4_shell(state):
    mode = state.get('mode', 'DNS_UNAVAILABLE')
    if mode not in ('LOCAL_DNSSEC', 'TUNNEL_DNS', 'EMERGENCY_DNS'):
        mode = 'DNS_UNAVAILABLE'
    tunnel = state.get('tunnel') if mode == 'TUNNEL_DNS' else ''
    if mode == 'TUNNEL_DNS' and tunnel not in V4_PRIORITY:
        mode, tunnel = 'DNS_UNAVAILABLE', ''
    port = str(V4_PORT)  # Keep dnsmasq attached during outage/recovery.
    fields = {'DNS_MODE': mode, 'DNS_PRIMARY_LEVEL': 'DNSSEC_OK' if mode == 'LOCAL_DNSSEC' else mode,
              'DNS_PRIMARY': port, 'DNS_WORKING_PORTS': port, 'DNS_BACKUP_PORTS': '', 'DNS_PRIMARY_RTT_MS': '',
              'DNS_SECURE_PORTS': port if mode == 'LOCAL_DNSSEC' else '',
              'DNS_INSECURE_PORTS': port if mode in ('TUNNEL_DNS', 'EMERGENCY_DNS') else '',
              'DNS_TUNNEL_REQUIRED': int(mode == 'TUNNEL_DNS'), 'DNS_TUNNEL_READY': int(mode == 'TUNNEL_DNS'),
              'DNS_TUNNEL_PROTOCOL': tunnel or '', 'DNS_RANKING': ''}
    return '\n'.join("%s='%s'" % (k, v) for k, v in fields.items())


def v4_main(command):
    _v4_os.umask(0o077)
    if command == '--dns-status':
        print(_v4_json.dumps(v4_status(), indent=2))
        return 0
    if command == '--dns-shell':
        print(v4_shell(v4_status()))
        return 0
    if command in ('--dns-rerank', '--dns-event'):
        state = v4_status()
        if not state:
            return 1
        _v4_os.kill(state['pid'], _v4_signal.SIGUSR1 if command == '--dns-rerank' else _v4_signal.SIGUSR2)
        return 0
    if command == '--dns-stop':
        state = v4_status(check_age=False)
        if state:
            _v4_os.kill(state['pid'], _v4_signal.SIGTERM)
            for _ in range(50):
                if not v4_status(check_age=False):
                    return 0
                _v4_time.sleep(.1)
            return 1
        return 0
    if _V4Path('/opt/etc/unblock/.disabled').exists():
        # dns4.2.23 (аудит A5 #8): отказ был молчаливым — оператор в
        # терминале видел только «did not start» без причины.
        print('DNSv4 disabled: присутствует /opt/etc/unblock/.disabled'
              ' — контроллер не запускается (снимите маркер для '
              'возобновления)', file=_v4_sys.stderr)
        return 1
    if command == '--dns-start':
        if v4_status():
            return 0
        if v4_status(check_age=False) and v4_main('--dns-stop') != 0:
            return 1
        # Validate config before spawning; no imports/credentials executed.
        v4_config()
        log = _V4Path('/opt/var/log/unblock_dns_v4.log')
        log.parent.mkdir(parents=True, exist_ok=True)
        if log.exists() and log.stat().st_size > 65536:
            with log.open('rb') as stream:
                stream.seek(-32768, 2)
                tail = stream.read()
            log.write_bytes(tail)
        with log.open('ab') as out:
            # dns4.2.27 (внешний аудит, U-05): PYTHONDONTWRITEBYTECODE
            # выставляется явно — дочерний демон не должен зависеть от
            # экспорта переменной в родительском стартовом скрипте и
            # писать __pycache__ на флеш.
            _v4_env = {k: v for k, v in _v4_os.environ.items() if k not in ('KEENZOO_UPDATE_LOCK_HELD', 'KEENZOO_LOCK_DIR', 'KEENZOO_DNS_STAGE', 'DNS_HEALTH_LOG')}
            _v4_env['PYTHONDONTWRITEBYTECODE'] = '1'
            _v4_subprocess.Popen([_v4_sys.executable, '-u', __file__, '--dns-run'], start_new_session=True,
                                stdin=_v4_subprocess.DEVNULL, stdout=out, stderr=out,
                                env=_v4_env)
        for _ in range(50):
            if v4_status():
                return 0
            _v4_time.sleep(.1)
        return 1
    if command != '--dns-run':
        return 2
    lock_fd = _v4_os.open(V4_LOCK, _v4_os.O_CREAT | _v4_os.O_RDWR | _v4_os.O_NOFOLLOW, 0o600)
    with _v4_os.fdopen(lock_fd, 'a') as lock:
        if _v4_os.fstat(lock.fileno()).st_uid != _v4_os.geteuid():
            raise ValueError('unsafe DNS lock ownership')
        try:
            _v4_fcntl.flock(lock, _v4_fcntl.LOCK_EX | _v4_fcntl.LOCK_NB)
        except BlockingIOError:
            return 0
        policy = DNSPolicyV4(v4_config())
        # dns4.2.37 П-8: 24 слота хватало, пока за фасадом стоял один
        # апстрим; при пробах/рейтинге нескольких кандидатов и всплесках
        # списка очередь на семафоре становилась узким местом. 64 слота
        # на MIPS-роутере — умеренная цена за отсутствие искусственного
        # ограничения параллелизма клиентских запросов.
        slots = _v4_thread.BoundedSemaphore(64)
        with V4UDP(('127.0.0.1', V4_PORT), V4UDPHandler) as udp, V4TCP(('127.0.0.1', V4_PORT), V4TCPHandler) as tcp:
            for server in (udp, tcp):
                server.policy, server.slots = policy, slots
                _v4_thread.Thread(target=server.serve_forever, daemon=True).start()
            for sig in (_v4_signal.SIGTERM, _v4_signal.SIGINT):
                _v4_signal.signal(sig, lambda *_: (policy.stop.set(), policy.wake.set()))
            _v4_signal.signal(_v4_signal.SIGUSR1, lambda *_: (policy.rerank.set(), policy.wake.set()))
            _v4_signal.signal(_v4_signal.SIGUSR2, lambda *_: (policy.network_event.set(), policy.wake.set()))
            policy.publish()
            worker = _v4_thread.Thread(target=policy.monitor, daemon=True)
            worker.start()
            while not policy.stop.wait(1):
                if not worker.is_alive():
                    raise RuntimeError("DNS monitor stopped")
            for server in (udp, tcp):
                server.shutdown()
        try:
            _V4Path(V4_STATE).unlink()
        except FileNotFoundError:
            pass
        return 0


if __name__ == '__main__' and len(_v4_sys.argv) == 2 and _v4_sys.argv[1].startswith('--dns-'):
    try:
        raise SystemExit(v4_main(_v4_sys.argv[1]))
    except Exception as _v4_error:
        print('DNSv4 error: %s' % type(_v4_error).__name__, file=_v4_sys.stderr)
        raise SystemExit(1) from None
# --- end KeenZOO DNS policy v4 ---

import os
import signal
import time
import subprocess
import json
import re
import socket
import tempfile
import shutil
import html
import copy
import fcntl
from contextlib import contextmanager
from urllib.parse import (
    urlparse, parse_qs, unquote)
import base64
from collections import deque
import bot_config as config


def signal_handler(sig, _frame):
    # dns4.2.37 L-6: frame не используется (сигнал обрабатывается по имени).
    log_error(
        f"Бот остановлен сигналом "
        f"{signal.Signals(sig).name}")
    raise SystemExit


# ---------------------------------------------------------------------------
# Ротация логов. Пороги настраиваются через опциональные атрибуты
# bot_config (LOG_MAX_SIZE_BYTES / LOG_KEEP_LINES) — если их нет,
# используются прежние значения по умолчанию (полная совместимость).
# Без ротации лог-файлы на Entware (часто ограниченный объём флеш/USB)
# могли бы расти неограниченно и занять всё свободное место.
# ---------------------------------------------------------------------------

_LOG_MAX_SIZE_BYTES = getattr(config, 'LOG_MAX_SIZE_BYTES', 524288)
_LOG_KEEP_LINES = getattr(config, 'LOG_KEEP_LINES', 50)


def clean_log(log_file, max_size=None, keep_lines=None):
    """
    Ограничивает размер лог-файла: при превышении max_size байт
    оставляет только последние keep_lines строк.
    """
    max_size = (
        _LOG_MAX_SIZE_BYTES if max_size is None else max_size)
    keep_lines = (
        _LOG_KEEP_LINES if keep_lines is None else keep_lines)

    if not os.path.exists(log_file):
        open(log_file, 'a').close()
        return
    try:
        if os.path.getsize(log_file) > max_size:
            with open(log_file, 'r', encoding='utf-8',
                      errors='replace') as f:
                lines = deque(f, maxlen=keep_lines)
            with open(log_file, 'w', encoding='utf-8') as f:
                f.writelines(lines)
    except OSError:
        pass


def log_error(message):
    log_file = config.paths["error_log"]
    try:
        clean_log(log_file)
        with open(log_file, "a",
                  encoding='utf-8') as fl:
            fl.write(
                f"{time.strftime('%Y-%m-%d %H:%M:%S')}"
                f" - {message}\n")
    except Exception:
        pass


def download_script():
    """
    Ранее функция скачивала script.sh с внешнего URL и делала его
    исполняемым, после чего бот запускал его с правами root без проверки
    подписи. Внешний источник удалён: используются только локальные
    скрипты из /opt/bin, поставляемые вместе с проектом.
    Возвращает путь к локальному установочному скрипту.
    """
    deploy = config.paths.get(
        "deploy_script", "/opt/bin/deploy_bypass.sh")
    if not os.path.exists(deploy):
        raise FileNotFoundError(
            f"Не найден локальный скрипт: {deploy}")
    try:
        os.chmod(deploy, 0o755)
    except OSError as e:
        log_error(f"chmod {deploy}: {e}")
    return deploy


def load_bypass_list(filepath):
    if not os.path.exists(filepath):
        return set()
    result = set()
    with open(filepath, 'r',
              encoding='utf-8') as f:
        for line in f:
            line = line.split('#')[0].strip()
            if line:
                result.add(line)
    return result


def save_bypass_list(filepath, sites):
    try:
        with open(filepath, 'w',
                  encoding='utf-8') as f:
            f.write('\n'.join(sorted(sites)))
    except Exception as e:
        log_error(
            f"Ошибка сохранения: {str(e)}")
        raise


def check_restart(bot):
    chat_id_path = config.paths[
        "chat_id_path"]
    if os.path.exists(chat_id_path):
        try:
            with open(chat_id_path, 'r') as f:
                chat_id = int(f.read().strip())
        except (OSError, ValueError) as e:
            # dns4.2.30 (полный аудит, П1): пустой или битый файл
            # (потеря питания в момент записи) не должен навсегда
            # ломать запуск бота: раньше необработанный ValueError
            # убивал процесс до polling, файл не удалялся — и каждый
            # следующий старт падал снова. Паритет с
            # generator._lock_is_live.
            log_error(
                f"check_restart: повреждён {chat_id_path}: {e}")
            try:
                os.remove(chat_id_path)
            except OSError:
                pass
            return
        try:
            bot.send_message(
                chat_id,
                '✅ Бот перезапущен')
        except Exception as e:
            log_error(
                f"Перезапуск: {str(e)}")
        try:
            os.remove(chat_id_path)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Preflight-проверки бинарниками (best-effort: если бинарник не найден,
# проверка пропускается с записью в лог, а не блокирует запись конфига —
# это важно, чтобы не сломать деплой на роутерах, где xray/tor ещё не
# установлены на момент первой генерации конфига).
# ---------------------------------------------------------------------------

# dns4.2.58 В-3 (аудит 2026-09-29, H-13): межпроцессная сериализация
# жизненного цикла сервисов. Панель и бот берут один и тот же файловый
# замок, поэтому одновременные переключения одного сервиса решаются
# порядком взятия замка, а не случайным переплетением операций.
SERVICE_OP_LOCK_DIR = '/opt/var/run'


@contextmanager
def service_op_lock(service, timeout=60):
    """Файловый flock на время операций с одним сервисом.

    Держатель, умерший без освобождения, не блокирует навсегда:
    ядро снимает flock при выходе процесса, а таймаут защищает от
    ожидания живого, но зависшего держателя.
    """
    os.makedirs(SERVICE_OP_LOCK_DIR, exist_ok=True)
    lock_path = os.path.join(
        SERVICE_OP_LOCK_DIR, f'keenzoo_svc_{service}.lock')
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
    deadline = time.time() + timeout
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except OSError:
            if time.time() >= deadline:
                os.close(fd)
                raise TimeoutError(
                    f'service_op_lock({service}): таймаут {timeout} с') from None
            time.sleep(0.2)
    try:
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)


def _find_binary(binary_name, fallback_paths):
    """Ищет бинарник через PATH, затем по типовым путям Entware."""
    found = shutil.which(binary_name)
    if found:
        return found
    for path in fallback_paths:
        if os.path.exists(path) and os.access(path, os.X_OK):
            return path
    return None


def _lint_xray_transports(tmp_path):
    """
    Линт соответствия «транспорт ↔ блок настроек» после успешного
    'xray -test'.

    Ядро молча принимает конфиг с 'network': 'xhttp' без блока
    xhttpSettings (или с устаревшим splithttpSettings): проверка
    проходит, а в рантайме транспорт получает path '/' и mode 'auto'
    вместо значений из ключа, и сервер рвёт соединение без внятной
    диагностики. Обнаружить это статически возможно только сверкой
    транспорта с настройками — здесь она и выполняется.

    Результат — предупреждение в лог; запись конфига НЕ блокируется,
    чтобы линт не ломал обновление рабочих конфигураций.
    """
    try:
        with open(tmp_path, 'r', encoding='utf-8') as cfg_file:
            parsed = json.load(cfg_file)
    except (OSError, ValueError):
        return
    if not isinstance(parsed, dict):
        return
    outbounds = parsed.get('outbounds')
    if not isinstance(outbounds, list):
        return
    for ob in outbounds:
        if not isinstance(ob, dict):
            continue
        stream = ob.get('streamSettings')
        if not isinstance(stream, dict):
            continue
        if stream.get('network') != 'xhttp':
            continue
        tag = ob.get('tag') or ob.get('protocol') or '?'
        if 'xhttpSettings' not in stream:
            log_error(
                "Xray lint: outbound '%s' — network=xhttp без "
                "xhttpSettings: ядро принимает конфиг молча, но "
                "транспорт уходит в значения по умолчанию "
                "(path=/, mode=auto)" % tag)
        if 'splithttpSettings' in stream:
            log_error(
                "Xray lint: outbound '%s' — устаревший "
                "splithttpSettings при network=xhttp: блок игнорируется "
                "ядром, используйте xhttpSettings" % tag)


def _preflight_xray(tmp_path):
    """
    Проверка конфига через xray -test.

    Формат передаётся ЯВНО через '-format json', а не через
    автоопределение по расширению файла (default 'auto' у Xray
    определяет формат по расширению, а временный файл создаётся
    tempfile.mkstemp со случайным суффиксом и может не совпадать
    с реальным расширением — при опоре на автоопределение это
    давало бы false negative на абсолютно корректных конфигах).
    Поддержаны оба синтаксиса CLI: старый 'xray -test' и новый
    'xray run -test'.
    """
    binary = _find_binary(
        'xray', ['/opt/sbin/xray', '/opt/bin/xray'])
    if not binary:
        log_error(
            "Preflight: xray не найден, проверка конфига пропущена")
        return

    last_err = ''
    for cmd in (
            [binary, 'run', '-test',
             '-format', 'json', '-config', tmp_path],
            [binary, '-test',
             '-format', 'json', '-config', tmp_path]):
        try:
            res = subprocess.run(
                cmd, capture_output=True,
                text=True, timeout=15)
        except subprocess.TimeoutExpired:
            last_err = 'timeout при проверке конфига'
            continue
        if res.returncode == 0:
            # Конфиг ядром принят. Отдельно сверяем транспортные блоки:
            # ядро молча разрешает несовпадение (см. _lint_xray_transports).
            _lint_xray_transports(tmp_path)
            return
        last_err = (res.stderr or res.stdout or '').strip()

    raise ValueError(f"Xray validation failed: {last_err}")


def _preflight_tor(tmp_path):
    """Проверка torrc через 'tor --verify-config -f <файл>'."""
    binary = _find_binary(
        'tor', ['/opt/sbin/tor', '/opt/bin/tor'])
    if not binary:
        log_error(
            "Preflight: tor не найден, проверка конфига пропущена")
        return

    try:
        res = subprocess.run(
            [binary, '--verify-config', '-f', tmp_path],
            capture_output=True, text=True, timeout=15)
    except subprocess.TimeoutExpired:
        raise ValueError("Tor validation timeout") from None

    if res.returncode != 0:
        err = (res.stderr or res.stdout or '').strip()
        raise ValueError(f"Tor validation failed: {err}")


def _preflight_hysteria(tmp_path):
    """Проверка нативного конфига Hysteria2: 'hysteria client -c <файл> --help'
    не валидирует, поэтому используется JSON-схема + обязательные поля."""
    binary = _find_binary(
        'hysteria', ['/opt/sbin/hysteria', '/opt/bin/hysteria'])

    try:
        with open(tmp_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError(f"Hysteria: некорректный JSON: {e}") from e

    if not data.get('server'):
        raise ValueError("Hysteria: не задан server")
    if not data.get('auth'):
        raise ValueError("Hysteria: не задан auth")
    if not isinstance(data.get('tcpRedirect'), dict):
        raise ValueError("Hysteria: отсутствует tcpRedirect")
    if not isinstance(data.get('udpTProxy'), dict):
        raise ValueError("Hysteria: отсутствует udpTProxy (UDP не пойдёт в туннель)")

    # dns4.2.36 (аудит, KZ-09): одних ключей недостаточно — проверяем
    # сами адреса слушателей и совпадение порта с перехватом трафика
    # (правила фаервола ведут на порт из bot_config).
    for _pf_key in ('tcpRedirect', 'udpTProxy'):
        _pf_listen = data[_pf_key].get('listen')
        if not isinstance(_pf_listen, str) \
                or ':' not in _pf_listen:
            raise ValueError(
                "Hysteria: %s.listen должен быть строкой «адрес:порт»"
                % _pf_key)
        _pf_port = _pf_listen.rsplit(':', 1)[-1]
        if not _pf_port.isdigit() \
                or not (1 <= int(_pf_port) <= 65535):
            raise ValueError(
                "Hysteria: %s.listen — некорректный порт: %r"
                % (_pf_key, _pf_listen))
        if int(_pf_port) != int(config.localporthysteria):
            raise ValueError(
                "Hysteria: %s.listen порт %s != %s из bot_config — "
                "перехват трафика на этот порт не настроен"
                % (_pf_key, _pf_port, config.localporthysteria))

    if not binary:
        log_error(
            "Preflight: hysteria не найден, проверка бинарником пропущена")
        return

    # dns4.2.58 М-02 (аудит 2026-09-29): схема находит поля, но не
    # запускает бинарник. Дымовая проба: отдельная копия конфига
    # (lazy, слушатели 127.0.0.1:0) в отдельной группе процессов;
    # немедленный выход с ошибкой парсинга — отказ; зависание —
    # ограниченное ожидание и гарантированное завершение. Это проверка
    # парсера/бинарника, а не сетевой тест.
    _pf_probe = copy.deepcopy(data)
    _pf_probe['lazy'] = True
    _pf_probe['tcpRedirect'] = {'listen': '127.0.0.1:0'}
    _pf_probe['udpTProxy'] = {'listen': '127.0.0.1:0', 'timeout': '1s'}
    # dns4.2.61 Н-10 (аудит раунда 23, v21): из пробы убираются ВСЕ
    # прочие слушатели нативного конфига (socks5/http/tun/форвардинг).
    # Иначе при работающем экземпляре на тех же портах проба падала на
    # bind(), и валидный конфиг отклонялся как невалидный.
    for _pf_extra in ('socks5', 'http', 'tun', 'tcpForwarding',
                      'udpForwarding', 'tcpTProxy'):
        _pf_probe.pop(_pf_extra, None)
    # dns4.2.60 К-1 (аудит 2026-09-29, H-02): Hysteria 2 определяет тип
    # конфига по РАСШИРЕНИЮ ещё до чтения содержимого — суффикс .tmp
    # отвергался («Unsupported Config Type "tmp"») и любой валидный ключ
    # не проходил пробу. Только .json и только системный временный
    # каталог (не /opt/etc/xray: xray -confdir читает ВСЕ *.json).
    _pf_fd, _pf_path = tempfile.mkstemp(
        prefix='.hysteria.probe.', suffix='.json', dir='/tmp')
    _pf_proc = None
    try:
        with os.fdopen(_pf_fd, 'w', encoding='utf-8') as _pf_f:
            json.dump(_pf_probe, _pf_f)
        os.chmod(_pf_path, 0o600)
        _pf_proc = subprocess.Popen(
            [binary, 'client', '-c', _pf_path],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            start_new_session=True)
        try:
            _pf_out, _ = _pf_proc.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            # Не вышел за 2 секунды — парсер принял конфиг и процесс
            # работает; для дымовой проверки достаточно.
            _pf_proc.terminate()
            try:
                _pf_proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                _pf_proc.kill()
                _pf_proc.wait(timeout=2)
            return
        _pf_text = (_pf_out or b'').decode('utf-8', 'replace').strip()
        # dns4.2.63 Н-2 (аудит раунда 25, RU_R23 H-02): вывод пробы
        # приходит с ANSI-кодами цвета — чистим перед разбором, иначе
        # матчер промахивается, а текст ошибки несёт мусорные коды.
        _pf_text = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', _pf_text)
        if _pf_proc.returncode != 0:
            # dns4.2.61 М-03 (аудит раунда 23, RU_CURRENT M-03): проверка
            # ПАРСЕРА отделяется от привилегий рантайма. «IP_TRANSPARENT:
            # operation not permitted» — ядро не дало CAP_NET_ADMIN
            # (песочница/непривилегированный запуск): парсер конфиг
            # принял, отказ среды — не ошибка конфига.
            #
            # dns4.2.63 М-06 (аудит раунда 25, RU_R23 M-06): матчер
            # строго по паре признаков — «нехватка привилегий» на
            # TPROXY-сокет. Раздельные условия были слишком широкими:
            # любая ошибка парсера, содержавшая хотя бы одно из слов,
            # молча считалась пройденной пробой.
            _pf_low = _pf_text.lower()
            if 'ip_transparent' in _pf_low \
                    and 'operation not permitted' in _pf_low:
                log_error(
                    "Preflight: hysteria принял конфиг, но проверка "
                    "рантайма недоступна без CAP_NET_ADMIN — проба "
                    "считается пройденной по парсеру")
                return
            raise ValueError(
                "Hysteria: бинарник отверг конфиг: " + _pf_text[:300])
    finally:
        if _pf_proc is not None and _pf_proc.poll() is None:
            try:
                _pf_proc.kill()
            except OSError:
                pass
        try:
            os.unlink(_pf_path)
        except OSError:
            pass


def _preflight_trojan(tmp_path):
    """Структурная проверка Trojan; init дополнительно выполняет trojan -t."""
    try:
        with open(tmp_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError(f"Trojan: некорректный JSON: {e}") from e

    # Здесь важно именно OR: конфиг непригоден, если отсутствует ХОТЯ БЫ
    # одно из обязательных полей (раньше проверка через AND пропускала
    # конфиги без remote_addr или без пароля).
    if (not data.get('remote_addr')
            or not data.get('remote_port')
            or not data.get('password')):
        raise ValueError(
            "Trojan: нужны remote_addr, remote_port и password")

    ssl = data.get('ssl', {})
    if not isinstance(ssl, dict):
        raise ValueError("Trojan: ssl должен быть объектом")
    if ssl.get('verify', True):
        cert = ssl.get('cert', '')
        if not cert:
            raise ValueError(
                "Trojan: ssl.cert не задан; нужен CA bundle "
                "/opt/etc/ssl/certs/ca-certificates.crt")
        if not os.path.isfile(cert):
            raise ValueError(
                f"Trojan: CA bundle не найден: {cert}")


def _preflight_shadowsocks(tmp_path):
    """Структурная проверка конфига shadowsocks-libev."""
    try:
        with open(tmp_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        raise ValueError(f"Shadowsocks: некорректный JSON: {e}") from e

    if not data.get('server'):
        raise ValueError("Shadowsocks: не задан server")
    if not data.get('server_port'):
        raise ValueError("Shadowsocks: не задан server_port")
    if not data.get('password'):
        raise ValueError("Shadowsocks: не задан password")
    if not data.get('method'):
        raise ValueError("Shadowsocks: не задан method")


def _cleanup_stale_tmp_files(directory, basename, max_age_seconds=3600):
    """
    Удаляет "осиротевшие" временные файлы конфигурации, оставшиеся
    от прерванных (например, из-за отключения питания роутера)
    предыдущих запусков write_config. Без этой очистки такие файлы
    накапливались бы бесконечно и могли занять всё место на
    накопителе Entware. Возраст 1 час гарантированно превышает время
    любой нормальной записи (доли секунды), поэтому риска удалить
    "живой" временный файл конкурентного процесса нет.
    """
    pattern_prefix = f".{basename}.tmp_"
    try:
        now = time.time()
        for name in os.listdir(directory):
            if not name.startswith(pattern_prefix):
                continue
            full = os.path.join(directory, name)
            try:
                # В-2: легаси-шаблон с расширением .json удаляется
                # независимо от возраста: текущий выпуск такие имена не
                # создаёт, а загрузчик конфигов подобрал бы их как боевые.
                if name.endswith('.json') \
                        or now - os.path.getmtime(full) > max_age_seconds:
                    os.remove(full)
            except OSError:
                pass
    except OSError:
        pass


def _refresh_pins_if_needed(file_path):
    """
    Перечитать адреса серверов после изменения конфига протокола.

    Пиннинг хранит IP серверов в /opt/etc/hosts, а туннели ходят именно
    по ним. Пин и canonical DNS обновляются при изменении конфигурации,
    подъёме WAN и штатном обновлении списков, поэтому после ввода нового
    ключа не нужно ждать следующего суточного цикла. Запускается в фоне —
    вызывающий код (панель,
    бот) не должен ждать сетевых запросов.
    """
    watched = (
        config.paths.get("vless_config"),
        config.paths.get("hysteria_config"),
        config.paths.get("trojan_config"),
        config.paths.get("shadowsocks_config"),
    )
    try:
        real = os.path.realpath(file_path)
    except Exception:
        real = file_path
    hit = False
    for w in watched:
        if not w:
            continue
        try:
            if os.path.realpath(w) == real:
                hit = True
                break
        except Exception:
            if w == file_path:
                hit = True
                break
    if not hit:
        return

    script = config.paths.get(
        "unblock_dnsmasq", "/opt/bin/unblock_dnsmasq.sh")
    if not os.path.exists(script):
        return
    try:
        # start_new_session отвязывает процесс: панель может быть
        # перезапущена, а обновление пина обязано завершиться.
        subprocess.Popen(
            [script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True)
    except Exception as e:
        log_error(f"pin refresh ({script}): {e}")


def _mark_tunnel_configured(file_path):
    """Record that this tunnel config was explicitly submitted by a user.

    A syntactically complete JSON file can survive from an older /opt or from
    a sample archive. The init guards must not treat that alone as permission
    to open a tunnel listener. The marker is deliberately a sidecar so it is
    not passed to xray, Trojan, or Hysteria as an unknown JSON field.
    """
    configured_dir = config.get(
        'tunnel_configured_dir', '/opt/etc/unblock/.configured') \
        if isinstance(config, dict) else getattr(
            config, 'tunnel_configured_dir',
            '/opt/etc/unblock/.configured')
    configured_dir = str(configured_dir)
    target = os.path.realpath(file_path)
    mapping = {
        os.path.realpath(config.paths.get('vless_config', '')): 'xray',
        os.path.realpath(config.paths.get('trojan_config', '')): 'trojan',
        os.path.realpath(config.paths.get('hysteria_config', '')): 'hysteria',
        # dns4.2.20: shadowsocks тоже маркируется — иначе guard
        # S65shadowsocks (симметричный S22/S24/S57) заблокировал бы
        # ss-redir навсегда. Правка применяется только вместе с guard.
        os.path.realpath(config.paths.get('shadowsocks_config', '')): 'shadowsocks',
    }
    service = mapping.get(target)
    if not service:
        return
    os.makedirs(configured_dir, exist_ok=True)
    marker = os.path.join(configured_dir, service)
    fd, tmp_path = tempfile.mkstemp(
        prefix=f'.{service}.', suffix='.tmp', dir=configured_dir)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as marker_file:
            marker_file.write('configured=1\n')
            marker_file.flush()
            os.fsync(marker_file.fileno())
        os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, marker)
    except Exception:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


# dns4.2.63 Н-3 (аудит раунда 25, v22 + RU_R23 M-02): контракт хука
# перехвата — ОДИН источник для панели и бота. Прежде
# generator._reapply_netfilter и handlers.setup_handlers независимо
# дублировали контракт «0 — применено, 4 — применено с деградацией,
# 75 — чужой замок (до трёх попыток), остальное — авария», и правка в
# одном месте не доходила до второго.
NETFILTER_HOOK = '/opt/etc/ndm/netfilter.d/100-redirect.sh'
TPROXY_STATE_FILE = '/opt/etc/unblock/.tproxy_state'
NETFILTER_TABLES = ('nat', 'filter')


def tproxy_fail_reason():
    """Причина деградации: последнее поле последней строки «fail» в
    /opt/etc/unblock/.tproxy_state (аудит раунда 23, М-5)."""
    reason = ''
    try:
        with open(TPROXY_STATE_FILE, encoding='utf-8') as _tr_f:
            for _tr_line in _tr_f:
                if _tr_line.startswith('fail'):
                    _tr_parts = _tr_line.split()
                    if _tr_parts:
                        reason = _tr_parts[-1]
    except OSError:
        pass
    return reason or 'см. /opt/var/log/100-redirect.log'


def reapply_netfilter():
    """Переприменяет правила перехвата обеими таблицами.

    Возврат: (применено, деградация). Контракт кодов хука:
    0 — применено, 4 — применено с деградацией (причина в
    .tproxy_state), 75 — чужой замок (преходящее состояние, до трёх
    попыток с паузой 2 с), любой другой код — авария.
    """
    if not _v4_os.path.exists(NETFILTER_HOOK):
        # dns4.2.64 P2-02 (аудит раунда 26): отсутствие хука — это
        # повреждённая установка, а не штатный пропуск. Прежде
        # возвращался «успех», и панель/бот рапортовали о применённых
        # правилах, которых не существует.
        log_error(
            'netfilter: хук перехвата отсутствует '
            f'({NETFILTER_HOOK}) — правила не применены')
        return False, False
    ok = True
    degraded = False
    for table in NETFILTER_TABLES:
        env = dict(_v4_os.environ, type='iptable', table=table)
        rc = None
        for _rn_try in range(3):
            try:
                _rn_proc = _v4_subprocess.run(
                    [NETFILTER_HOOK], env=env, timeout=90,
                    stdout=_v4_subprocess.DEVNULL,
                    stderr=_v4_subprocess.PIPE, text=True)
                rc = _rn_proc.returncode
            except (_v4_subprocess.TimeoutExpired, OSError):
                rc = 1
            if rc != 75:
                break
            _v4_time.sleep(2)
        if rc is None or rc not in (0, 4):
            ok = False
            log_error(
                f'netfilter table={table}: применение не подтверждено '
                f'(код {rc})')
        elif rc == 4:
            degraded = True
    return ok, degraded


def tunnel_marker_path_for(cfg_path):
    """Путь маркера .configured/<сервис> для конфига туннеля, либо
    None для немаркируемых конфигов (tor ведёт своё рантайм-состояние).
    Зеркалит отображение _mark_tunnel_configured."""
    try:
        configured_dir = config.get(
            'tunnel_configured_dir', '/opt/etc/unblock/.configured') \
            if isinstance(config, dict) else getattr(
                config, 'tunnel_configured_dir',
                '/opt/etc/unblock/.configured')
    except Exception:
        configured_dir = '/opt/etc/unblock/.configured'
    mapping = {
        _v4_os.path.realpath(
            config.paths.get('vless_config', '')): 'xray',
        _v4_os.path.realpath(
            config.paths.get('trojan_config', '')): 'trojan',
        _v4_os.path.realpath(
            config.paths.get('hysteria_config', '')): 'hysteria',
        _v4_os.path.realpath(
            config.paths.get('shadowsocks_config', '')): 'shadowsocks',
    }
    service = mapping.get(_v4_os.path.realpath(cfg_path))
    if not service:
        return None
    return _v4_os.path.join(str(configured_dir), service)


def snapshot_service_config(cfg_path):
    """dns4.2.63 Х-08 (аудит раунда 25, RU_R23 H-08): снимок конфига и
    его маркера ДО перезапуска, чтобы при сбое вернуть сервис в
    ПРЕЖНИЙ вид целиком (конфиг, права, маркер).

    Возврат: снимок или None — None означает, что транзакцию нельзя
    ни начать, ни честно откатить.

    dns4.2.64 P1-02 (аудит раунда 26): отсутствием считается ТОЛЬКО
    FileNotFoundError. Прочие ошибки чтения (нет прав, ввод-вывод,
    сетевая ФС) раньше объявлялись «конфига не было», и последующий
    откат удалял существующий конфиг. Байты и режим читаются с одного
    открытого дескриптора (один inode)."""
    existed = False
    data = None
    mode = 0o600
    try:
        with open(cfg_path, 'rb') as _sc_f:
            data = _sc_f.read()
            mode = _v4_os.fstat(_sc_f.fileno()).st_mode & 0o777
        existed = True
    except FileNotFoundError:
        pass
    except OSError as exc:
        log_error(
            f'snapshot конфига не прочитан ({cfg_path}): {exc} — '
            'транзакция прервана')
        return None
    marker = tunnel_marker_path_for(cfg_path)
    return {
        'path': cfg_path,
        'existed': existed,
        'data': data,
        'mode': mode,
        'marker': marker,
        'marker_existed': bool(marker)
        and _v4_os.path.exists(marker),
    }


def config_snapshot_touched(snap):
    """dns4.2.64 К-3 (аудит раунда 26, v23 В-2): содержательный
    признак «что-то изменилось на диске» — откат и перезапуск
    выполняются только при нём. Флаг «конфиг тронут» в аварийных
    путях ненадёжен: исключение может подняться и после записи, и до
    неё. Возврат: True/False; при невозможности проверить — True
    (лучше откатать лишнее, чем оставить битый конфиг)."""
    if snap is None:
        return False
    try:
        now_exists = _v4_os.path.exists(snap['path'])
        if now_exists != snap['existed']:
            return True
        if now_exists:
            with open(snap['path'], 'rb') as _cst_f:
                if _cst_f.read() != snap['data']:
                    return True
        marker = snap.get('marker')
        if marker and (_v4_os.path.exists(marker)
                       != snap.get('marker_existed')):
            return True
    except OSError:
        return True
    return False


def rollback_service_config(snap):
    """Возврат конфига и маркера к снимку (атомарно). Возврат: текст
    ошибки или None. Перезапуск после возврата выполняет вызывающий:
    панель и бот перезапускают сервисы своими командами."""
    if not snap:
        return 'нет снимка конфига'
    try:
        if snap['existed']:
            _rb_dir = _v4_os.path.dirname(snap['path']) or '.'
            _rb_fd, _rb_tmp = tempfile.mkstemp(
                prefix='.kz-rb.', dir=_rb_dir)
            try:
                with _v4_os.fdopen(_rb_fd, 'wb') as _rb_f:
                    _rb_f.write(snap['data'])
                    _rb_f.flush()
                    _v4_os.fsync(_rb_f.fileno())
                _v4_os.chmod(_rb_tmp, snap['mode'])
                _v4_os.replace(_rb_tmp, snap['path'])
            except Exception:
                try:
                    _v4_os.unlink(_rb_tmp)
                except OSError:
                    pass
                raise
        else:
            # Первая настройка: конфиг не должен остаться.
            try:
                _v4_os.unlink(snap['path'])
            except FileNotFoundError:
                pass
        marker = snap.get('marker')
        if marker:
            if snap.get('marker_existed'):
                if not _v4_os.path.exists(marker):
                    _v4_os.makedirs(
                        _v4_os.path.dirname(marker), exist_ok=True)
                    with open(marker, 'w',
                              encoding='utf-8') as _mk_f:
                        _mk_f.write('configured=1\n')
                    _v4_os.chmod(marker, 0o600)
            else:
                try:
                    _v4_os.unlink(marker)
                except FileNotFoundError:
                    pass
    except OSError as exc:
        return str(exc)
    return None


class ConfigWriter:
    @staticmethod
    def write_config(file_path,
                     config_data,
                     format='json'):
        """
        Атомарная запись конфигурации:
        0) удаляются "осиротевшие" временные файлы от прошлых
           прерванных записей (защита от накопления мусора на диске);
        1) содержимое пишется во временный файл в той же директории
           (нужно для атомарности os.replace на той же ФС), причём
           временный файл получает суффикс .tmp, а не расширение
           целевого файла (dns4.2.58 В-2: загрузчик конфигов по маске
           *.json не должен подхватить прерванную запись);
        2) выполняется best-effort preflight-проверка (xray -test для
           vless_config, tor --verify-config для tor_config);
        3) только при успехе временный файл заменяет боевой путь.

        Права временного файла наследуются от уже существующего
        конфига (если есть), иначе ставятся в 0600 — конфиги содержат
        пароли/UUID/reality-ключи и не должны быть читаемы всем.
        Установка прав выполняется ПОСЛЕ передачи fd в os.fdopen()
        (через os.chmod по пути, а не os.fchmod по дескриптору) и
        обёрнута в отдельный try/except: на файловых системах без
        полноценной поддержки POSIX-прав (exFAT/NTFS — частый случай
        для внешних USB-накопителей Entware) chmod может завершиться
        ошибкой — это не должно ни прерывать запись конфига, ни
        приводить к утечке файлового дескриптора.

        Все ошибки (включая невалидный JSON на входе, ошибки создания
        каталога и preflight) логируются через log_error перед
        повторным raise.
        """
        directory = os.path.dirname(file_path) or '.'
        tmp_path = None

        try:
            os.makedirs(directory, exist_ok=True)
            _cleanup_stale_tmp_files(
                directory, os.path.basename(file_path))

            if format == 'json':
                content = json.dumps(
                    json.loads(config_data),
                    ensure_ascii=False, indent=2)
            else:
                content = config_data

            # dns4.2.58 В-2 (аудит 2026-09-29, H-14): временник в
            # каталоге конфигурации не должен иметь расширение боевого
            # файла: Xray с -confdir читает ВСЕ *.json каталога, и
            # прерванная запись могла бы попасть в рабочий конфиг.
            # Формат уже задан аргументом -format json.
            fd, tmp_path = tempfile.mkstemp(
                dir=directory,
                prefix=f".{os.path.basename(file_path)}.tmp_",
                suffix='.tmp')

            # dns4.2.58 Б-2 (аудит 2026-09-29, H-02): секретный конфиг
            # не может остаться читаемым группе/прочим, если ФС соблюдает
            # права. На exFAT/NTFS chmod честно не работает — пропуск
            # остаётся допустимым, как и прежде.
            _kz_secret_names = (
                'config.json', 'bot_config.py', 'torrc',
                'shadowsocks.json', '.secret_key')
            _kz_is_secret = os.path.basename(
                file_path) in _kz_secret_names
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                _kz_chmod_ok = True
                try:
                    # dns4.2.60 М-1 (аудит 2026-09-29, M-04): секретные
                    # цели ВСЕГДА ужесточаются до 0600, а не наследуют
                    # режим существующего файла: унаследованные 0644
                    # прежних версий раньше делали запись невозможной до
                    # ручного chmod (панель не могла сама починиться).
                    if _kz_is_secret:
                        mode = 0o600
                    elif os.path.exists(file_path):
                        mode = os.stat(file_path).st_mode & 0o777
                    else:
                        mode = 0o600
                    os.chmod(tmp_path, mode)
                except OSError as chmod_err:
                    _kz_chmod_ok = False
                    log_error(
                        f"Preflight: chmod пропущен для "
                        f"{tmp_path}: {chmod_err}")
                if _kz_is_secret and _kz_chmod_ok:
                    _kz_st_mode = os.fstat(f.fileno()).st_mode
                    if _kz_st_mode & 0o077:
                        # Ремедиация через дескриптор временника — он ещё
                        # не опубликован, исправление безопасно.
                        try:
                            os.fchmod(f.fileno(), 0o600)
                        except OSError as _kz_fchmod_err:
                            raise PermissionError(
                                f"Секретный конфиг {file_path} не защищён "
                                "от чтения группе/прочим") from _kz_fchmod_err
                        _kz_st_mode = os.fstat(f.fileno()).st_mode
                        if _kz_st_mode & 0o077:
                            raise PermissionError(
                                f"Секретный конфиг {file_path} не защищён "
                                "от чтения группе/прочим")

                f.write(content)
                f.flush()
                os.fsync(f.fileno())

            # Preflight выполняется на ВРЕМЕННОМ файле: боевой конфиг
            # заменяется только после успешной проверки, поэтому неудачная
            # генерация не оставляет сервис с нерабочим конфигом.
            real_path = os.path.realpath(file_path)
            checks = {
                os.path.realpath(config.paths.get('vless_config', '')):
                    _preflight_xray,
                os.path.realpath(config.paths.get('tor_config', '')):
                    _preflight_tor,
                os.path.realpath(config.paths.get('hysteria_config', '')):
                    _preflight_hysteria,
                os.path.realpath(config.paths.get('trojan_config', '')):
                    _preflight_trojan,
                os.path.realpath(config.paths.get('shadowsocks_config', '')):
                    _preflight_shadowsocks,
            }
            checker = checks.get(real_path)
            if checker is not None:
                checker(tmp_path)

            # dns4.2.36 (аудит, KZ-09): для туннельных конфигов держим
            # копию прежнего содержимого: если запись маркера
            # .configured упадёт ПОСЛЕ замены конфига, откатываем —
            # иначе сервис остался бы с новым конфигом, но без права
            # запуска (и без простого способа вернуться назад).
            _kz_tunnel_cfgs = (
                os.path.realpath(config.paths.get('vless_config', '')),
                os.path.realpath(config.paths.get('trojan_config', '')),
                os.path.realpath(config.paths.get('hysteria_config', '')),
                os.path.realpath(
                    config.paths.get('shadowsocks_config', '')))
            _kz_old_backup = None
            if real_path in _kz_tunnel_cfgs \
                    and os.path.exists(file_path):
                try:
                    with open(file_path, 'rb') as _kz_of:
                        _kz_old_backup = _kz_of.read()
                except OSError:
                    _kz_old_backup = None

            os.replace(tmp_path, file_path)
            # Do not let a preserved or hand-copied complete JSON authorize
            # a listener. This marker exists only after the bot/web config
            # submission itself has succeeded.
            try:
                _mark_tunnel_configured(file_path)
            except Exception as _kz_marker_err:
                if _kz_old_backup is not None:
                    try:
                        _kz_fd, _kz_rb = tempfile.mkstemp(
                            dir=directory or '.', suffix='.rollback')
                        with os.fdopen(_kz_fd, 'wb') as _kz_rf:
                            _kz_rf.write(_kz_old_backup)
                            _kz_rf.flush()
                            os.fsync(_kz_rf.fileno())
                        os.replace(_kz_rb, file_path)
                    except OSError:
                        log_error(
                            "KZ-09: не удалось откатить конфиг после "
                            "сбоя маркера: " + file_path)
                else:
                    # dns4.2.64 P1-02 (аудит раунда 26): первая
                    # настройка — прежнего конфига не было. Без этой
                    # ветки опубликованный конфиг оставался на диске
                    # без маркера: полунастроенный сервис вместо
                    # честного «ничего не настроено».
                    try:
                        os.remove(file_path)
                    except OSError:
                        log_error(
                            "KZ-09: не удалось убрать новый конфиг "
                            "после сбоя маркера: " + file_path)
                log_error(
                    "Маркер .configured не записан — конфиг откачен: "
                    "%s" % _kz_marker_err)
                raise

            # Адрес сервера в конфиге только что мог смениться, а в
            # /opt/etc/hosts остался пин от прежнего ключа. Туннель пошёл
            # бы на старый IP, и обход молча не работал бы до 06:00.
            # Обновляем закреплённые адреса сразу после записи конфига
            # любого из протоколов, к которым применяется пиннинг.
            _refresh_pins_if_needed(file_path)

        except Exception as e:
            if tmp_path and os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except Exception:
                    pass
            log_error(
                f"Failed to write config to {file_path}: {e}")
            raise


def notify_on_error():
    def decorator(func):
        def wrapper(key, bot=None,
                    chat_id=None,
                    *args, **kwargs):
            try:
                return func(
                    key, bot, chat_id,
                    *args, **kwargs)
            except Exception as e:
                if bot and chat_id:
                    if func.__name__ == (
                            "tor_config"):
                        bot.send_message(
                            chat_id,
                            f"❌ Tor: "
                            f"{str(e)}")
                    else:
                        protocol = (
                            func.__name__
                            .split('_')[1]
                            .capitalize())
                        bot.send_message(
                            chat_id,
                            f"❌ "
                            f"{protocol}: "
                            f"{str(e)}")
                raise
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# IPv4-only проверка. На роутере Keenetic IPv6 отключён на уровне системы,
# а dnsmasq/ipset в проекте работают только в режиме family inet (IPv4).
# Явный IPv6-адрес сервера в ссылке привёл бы к конфигу, который либо не
# подключится (нет IPv6-стека), либо не попадёт в анблок-списки — поэтому
# такой адрес отклоняется на этапе парсинга с понятной ошибкой.
# ---------------------------------------------------------------------------

def _is_ipv6_literal(host):
    """
    Надёжный маркер IPv6 в этом контексте — наличие ':' в host,
    т.к. ни домены, ни IPv4-адреса символ ':' не содержат (host
    на этом этапе уже отделён от порта вызывающим кодом).
    """
    return bool(host) and ':' in host


def _reject_ipv6_host(host, context="адрес сервера"):
    if _is_ipv6_literal(host):
        raise ValueError(
            f"IPv6 не поддерживается (IPv6 отключён на "
            f"роутере): {context}")


def _endpoint_host(value):
    """Extract a host from a direct-config host or host:port value."""
    if not isinstance(value, str):
        return ''
    value = value.strip()
    if value.startswith('['):
        host, sep, _port = value[1:].partition(']')
        return host if sep else value
    if value.count(':') == 1:
        host, port = value.rsplit(':', 1)
        if port.isdigit():
            return host
    return value


def _reject_endpoint_ipv6(value, context="адрес сервера"):
    _reject_ipv6_host(_endpoint_host(value), context)


def _endpoint_port(value):
    if not isinstance(value, str):
        return None
    value = value.strip()
    if value.startswith('['):
        end = value.find(']')
        if end < 0:
            return None
        value = value[end + 1:]
        if value.startswith(':'):
            return value[1:]
        return None
    if value.count(':') == 1:
        return value.rsplit(':', 1)[1]
    return None


def _validate_port(value, context="порт"):
    try:
        port = int(value)
    except (TypeError, ValueError):
        raise ValueError(f"Некорректный {context}: {value}") from None
    if not 1 <= port <= 65535:
        raise ValueError(f"Некорректный {context}: {value}")
    return port


@notify_on_error()
def parse_vless_key(key, bot=None,
                    chat_id=None):
    if not key.startswith('vless://'):
        raise ValueError("vless://")
    url = key[6:]
    parsed_url = urlparse(url)
    params = parse_qs(parsed_url.query)
    if (not parsed_url.hostname
            or not parsed_url.username):
        raise ValueError("Нет адреса/ID")
    _reject_ipv6_host(parsed_url.hostname)
    port = 443 if parsed_url.port is None else parsed_url.port
    if not (1 <= port <= 65535):
        raise ValueError(f"Порт: {port}")
    transport = params.get(
        'type', ['tcp'])[0]
    raw_path = params.get(
        'path', ['/'])[0]
    raw_host = params.get(
        'host', [''])[0]
    return {
        'address': parsed_url.hostname,
        'port': port,
        'id': parsed_url.username,
        'encryption': params.get(
            'encryption', ['none'])[0],
        'flow': params.get(
            'flow', [''])[0],
        'security': params.get(
            'security', [''])[0],
        'pbk': params.get(
            'pbk', [''])[0],
        'fp': params.get(
            'fp', [''])[0],
        'sni': params.get(
            'sni', [''])[0],
        'sid': params.get(
            'sid', [''])[0],
        'spx': params.get(
            'spx', ['/'])[0],
        # dns4.2.17/4.2.18: allowInsecure=1 и алиас insecure=1 — намерение
        # «самоподписанный сервер»; доставляется в render (generate_config →
        # _normalize_xray_insecure → pinnedPeerCertSha256), т.к. на Xray
        # ≥26 поле allowInsecure отсутствует и до этого молча испарялось.
        'allowInsecure': params.get(
            'allowInsecure',
            params.get('insecure', ['0']))[0],
        # dns4.2.18: хеш сертификата из ссылки (&pin= канонично; &hash= и
        # полное имя — алиасы). Hex64 по DER; base64 ядро не принимает.
        'pinnedPeerCertSha256': params.get(
            'pin',
            params.get(
                'hash',
                params.get('pinnedPeerCertSha256', [''])))[0].lower(),
        'transport': transport,
        'serviceName': params.get(
            'serviceName', [''])[0],
        'ws_path': raw_path,
        'ws_host': raw_host,
        'xhttp_mode': params.get(
            'mode', ['auto'])[0],
        'xhttp_path': raw_path,
        'xhttp_host': raw_host,
    }


@notify_on_error()
def parse_trojan_key(key, bot=None,
                     chat_id=None):
    # Ключи из HTML/Telegram иногда содержат &amp; вместо '&'.
    # Нормализуем только URL-сущности, сохраняя пароль, SNI и path.
    key = key.strip()
    # Поддерживаем как обычный URL из Telegram, так и дважды HTML-
    # экранированный вариант (&amp;amp;), который появляется после
    # последовательного копирования через HTML/Markdown.
    for _ in range(3):
        _decoded_key = html.unescape(key)
        if _decoded_key == key:
            break
        key = _decoded_key
    if not key.startswith('trojan://'):
        raise ValueError("trojan://")
    parsed_url = urlparse(key)
    params = parse_qs(
        parsed_url.query,
        keep_blank_values=True)
    pw = (unquote(parsed_url.username)
          if parsed_url.username else "")
    if not pw:
        raise ValueError("Нет пароля")
    port = parsed_url.port
    if port is None:
        raise ValueError("Нет порта")
    if not (1 <= port <= 65535):
        raise ValueError(f"Порт: {port}")
    netloc = parsed_url.netloc
    if '@' in netloc:
        hp = netloc.rsplit('@', 1)[-1]
    else:
        hp = netloc
    if hp.startswith('['):
        be = hp.find(']')
        if be == -1:
            raise ValueError("IPv6")
        host = hp[1:be]
    else:
        host = hp.rsplit(':', 1)[0]
    if not host:
        raise ValueError("Нет адреса")
    _reject_ipv6_host(host)
    sni_raw = params.get('sni', [''])[0]
    sni = (unquote(sni_raw)
           if sni_raw else '')
    path_raw = params.get(
        'path', ['/'])[0]
    path = (unquote(path_raw)
            if path_raw else '/')
    result = {
        'pw': pw, 'host': host,
        'port': port, 'sni': sni,
        'fp': params.get('fp', [''])[0],
        'alpn': params.get(
            'alpn', [''])[0],
        'type': params.get(
            'type', ['tcp'])[0],
        'security': params.get(
            'security', ['tls'])[0],
        'path': path,
        'host_header': params.get(
            'host', [''])[0],
        # dns4.2.17: insecure=1 — алиас allowInsecure=1 (устоявшийся в
        # vless-share). Дальше маршруты разные: vless (ядро Xray ≥26) —
        # конвертация в verifyPeerCertByName; trojan (своё ядро
        # trojan-go) — verify=false; параметр больше нигде не испаряется.
        'allowInsecure': params.get(
            'allowInsecure',
            params.get('insecure', ['0']))[0],
        'serviceName': params.get(
            'serviceName', [''])[0],
    }
    if not result['sni']:
        result['sni'] = result['host']
    result['ws_enabled'] = (
        'true' if result['type'] == 'ws'
        else 'false')
    # Проверка сертификата отключается ТОЛЬКО при явном allowInsecure=1
    # в ссылке. По умолчанию (в т.ч. при отсутствии параметра) — включена:
    # прежде шаблон трояна жёстко получал verify=false, что снимало защиту
    # от подмены сертификата на всём трафике Trojan.
    result['verify'] = (
        'false'
        if str(result['allowInsecure']).lower() in ('1', 'true', 'yes')
        else 'true')
    return result


@notify_on_error()
def parse_shadowsocks_key(key, bot=None,
                          chat_id=None):
    if not key.startswith('ss://'):
        raise ValueError("ss://")

    def dec_b64(v):
        v = unquote(v.strip())
        v += '=' * ((4 - len(v) % 4) % 4)
        return base64.urlsafe_b64decode(
            v.encode('utf-8')).decode('utf-8')

    raw = key[5:].split('#', 1)[0]

    if '@' in raw:
        userinfo, server_part = raw.rsplit('@', 1)
        decoded = dec_b64(userinfo)
        if ':' not in decoded:
            raise ValueError("method:password")
        method, password = decoded.split(':', 1)
    else:
        decoded = dec_b64(raw)
        if '@' not in decoded:
            raise ValueError("server")
        userinfo, server_part = decoded.rsplit('@', 1)
        if ':' not in userinfo:
            raise ValueError("method:password")
        method, password = userinfo.split(':', 1)

    server_part = server_part.split('?', 1)[0].split('/', 1)[0]
    if server_part.startswith('['):
        end = server_part.find(']')
        if end < 0:
            raise ValueError("IPv6")
        server = server_part[1:end]
        port = server_part[end + 2:]
    else:
        if ':' not in server_part:
            raise ValueError("Порт")
        server, port = server_part.rsplit(':', 1)

    _reject_ipv6_host(server)

    if (not server or not port.isdigit()
            or not method or not password):
        raise ValueError("Некорректный")
    pn = int(port)
    if not (1 <= pn <= 65535):
        raise ValueError(f"Порт: {port}")
    return {
        'server': server, 'port': pn,
        'password': password,
        'method': method,
    }

@notify_on_error()
def parse_hysteria_key(key, bot=None,
                       chat_id=None):
    kc = key.split('#')[0].strip()
    if kc.startswith('hy2://'):
        up = kc[6:]
    elif kc.startswith('hysteria2://'):
        up = kc[12:]
    else:
        raise ValueError("hy2://")
    pu = urlparse('http://' + up)
    params = parse_qs(pu.query)
    # 4.2.73 №1 (технический отчёт): форма «user:password» в userInfo
    # прежде терялась — «urlparse» уносит пароль в «pu.password», и в
    # «auth» попадал только пользователь (сервер отвечал 401). Пара
    # собирается обратно; одиночный токен «пароль@хост» идёт прежним
    # путём; пустой пароль в паре не даёт хвост «:».
    if pu.password:
        auth = f"{unquote(pu.username or '')}:{unquote(pu.password)}"
    else:
        auth = unquote(pu.username) if pu.username else ""
    if not auth:
        raise ValueError("Нет пароля")
    server = pu.hostname
    if not server:
        raise ValueError("Нет адреса")
    _reject_ipv6_host(server)
    port = pu.port
    if not port:
        raise ValueError("Нет порта")
    if not (1 <= port <= 65535):
        raise ValueError(f"Порт: {port}")
    sni = params.get('sni', [''])[0]
    if not sni:
        sni = server
    ins = params.get('insecure', ['0'])[0]
    insecure = (
        'true' if str(ins).lower() in ('1', 'true', 'yes') else 'false')
    alpn_raw = params.get('alpn', [''])[0]
    ap = [p.strip()
          for p in alpn_raw.split(',')
          if p.strip()]
    # Баг 6 фикс: раньше пустой ALPN превращался в `""`, шаблон давал
    # `"alpn": [""]`, и `_cleanup_empty_fields` удаляла ключ целиком —
    # клиент стучался по QUIC вообще без предложения ALPN, а строгие
    # серверы это отклоняют. Стандарт для hy2 — «h3»; он и подставляется,
    # когда пользователь явно не задал свой список.
    if not ap:
        ap = ['h3']
    alpn = ', '.join(
        f'"{p}"' for p in ap)
    ot = params.get('obfs', [''])[0]
    op = params.get('obfs-password', [''])[0]
    return {
        'server': server, 'port': port,
        'auth': auth, 'sni': sni,
        'insecure': insecure, 'alpn': alpn,
        'obfs_type': ot,
        'obfs_password': op,
    }


def _cleanup_empty_fields(obj):
    rif = {'flow'}
    ts = {
        'grpcSettings', 'wsSettings',
        'tcpSettings', 'httpSettings',
        'quicSettings', 'xhttpSettings',
        'httpupgradeSettings',
    }
    ss = {'realitySettings', 'tlsSettings'}
    if isinstance(obj, dict):
        cn = obj.get('network', '')
        cs = obj.get('security', '')
        kr = []
        for k, v in obj.items():
            if k in rif and v == '':
                kr.append(k)
            elif (k in ts
                  and isinstance(v, dict)):
                exp = cn + 'Settings'
                if k != exp:
                    kr.append(k)
                elif not v:
                    kr.append(k)
            elif (k in ss
                  and isinstance(v, dict)):
                exs = cs + 'Settings'
                if k != exs:
                    kr.append(k)
                elif not v:
                    kr.append(k)
            elif isinstance(v, (dict, list)):
                _cleanup_empty_fields(v)
        obfs = obj.get('obfs')
        if (isinstance(obfs, dict)
                and not obfs.get('type')):
            kr.append('obfs')
        alpn = obj.get('alpn')
        if isinstance(alpn, list):
            if (not alpn
                    or (len(alpn) == 1
                        and alpn[0] == '')):
                kr.append('alpn')
        for k in kr:
            if k in obj:
                del obj[k]
    elif isinstance(obj, list):
        for item in obj:
            if isinstance(item, (dict, list)):
                _cleanup_empty_fields(item)



# Ключи, значения которых подставляются в шаблон как «сырой» JSON
# (числа, булевы литералы, готовые списки alpn), а не как строка.
_JSON_RAW_KEYS = {
    'insecure', 'alpn', 'ws_enabled',
    'verify', 'localportvless',
    'localporttrojan', 'localportsh',
    'localporthysteria',
}

# Значения этих ключей формируются кодом, а не пользователем.
_JSON_RAW_ALLOWED = {
    'true', 'false', '',
}


def _tpl_value(key, value):
    """
    Готовит значение к подстановке в JSON-шаблон.

    Строки экранируются через json.dumps (кавычки, обратные слеши,
    переводы строк). Прежняя версия для «сырых» ключей возвращала
    str(value) без проверки, поэтому специально сформированный ключ
    (например, alpn с кавычкой) ломал структуру JSON или позволял
    дописать в конфиг произвольные поля.
    """
    if isinstance(value, bool):
        return 'true' if value else 'false'
    if isinstance(value, (int, float)):
        return str(value)

    if key in _JSON_RAW_KEYS:
        raw = str(value)
        if raw in _JSON_RAW_ALLOWED:
            return raw
        if raw.lstrip('-').isdigit():
            return raw
        if key == 'alpn':
            # alpn собирается из уже проверенных токенов вида "h3", "h2".
            parts = []
            for token in raw.split(','):
                token = token.strip().strip('"')
                if not token:
                    continue
                if not re.match(r'^[A-Za-z0-9.\-/]+$', token):
                    raise ValueError(
                        f"Недопустимое значение alpn: {token}")
                parts.append(json.dumps(token, ensure_ascii=False))
            return ', '.join(parts)
        raise ValueError(
            f"Недопустимое значение поля {key}: {raw}")

    return json.dumps(
        str(value), ensure_ascii=False)[1:-1]


def _ensure_xray_quiet_log(parsed):
    """
    Ограничивает журналирование xray. Без секции "log" xray пишет
    предупреждения и, при access-логе, строку на КАЖДОЕ соединение —
    на накопителе с Entware это быстро съедает место. Оставляем
    только ошибки, access-лог отключаем.
    """
    if not isinstance(parsed, dict):
        return parsed
    log = parsed.get('log')
    if not isinstance(log, dict):
        log = {}
    log['access'] = 'none'
    log['loglevel'] = 'error'
    # Пустая строка означает вывод в stdout; оставляем как есть, если
    # путь задан пользователем осознанно.
    if not log.get('error'):
        log['error'] = ''
    parsed['log'] = log
    return parsed



def _xray_version_known():
    """Return True only when the installed Xray version is observable.

    Removing a user-supplied Xray dns block changes runtime DNS semantics.
    Do not perform that migration when the binary is absent or its CLI
    format is unknown; preserving the block is safer than guessing.
    """
    binary = _find_binary(
        'xray', ['/opt/sbin/xray', '/opt/bin/xray'])
    if not binary:
        return False
    for args in ([binary, 'version'], [binary, '--version']):
        try:
            result = subprocess.run(
                args, capture_output=True, text=True, timeout=5)
        except (OSError, subprocess.SubprocessError):
            continue
        text = (result.stdout or '') + '\n' + (result.stderr or '')
        if result.returncode == 0 and re.search(
                r'\b[0-9]+\.[0-9]+\.[0-9]+\b', text):
            return True
    return False


# Ownership is explicit rather than inferred from nameservers or ports:
# a user may legitimately run a local resolver on the same address. These
# markers are carried by the project-managed Xray dns object and are removed
# before the config is written to Xray, so they never become runtime fields.
_XRAY_PROJECT_DNS_MARKERS = frozenset((
    'keenzoo',
    'keenzoo-dns',
    'keenzoo-managed-dns',
    'KeenZOO managed DNS',
))


def _xray_dns_block_owned(parsed):
    """Return True only for an explicitly project-owned Xray dns block."""
    if not isinstance(parsed, dict):
        return False
    dns = parsed.get('dns')
    if not isinstance(dns, dict):
        return False

    # ``tag`` is the Xray-native identity field. ``owner`` and ``managedBy``
    # are accepted for configs produced by older project revisions; they are
    # not guessed from arbitrary server addresses.
    for key in ('tag', 'owner', 'managedBy'):
        marker = dns.get(key)
        if isinstance(marker, str) and marker.strip() in \
                _XRAY_PROJECT_DNS_MARKERS:
            return True
    # A JSON-side marker is useful for migrations and is deliberately strict:
    # only the literal boolean True grants ownership.
    return dns.get('_keenzoo_managed') is True


def _remove_xray_dns_block(parsed):
    """Remove only project-owned Xray DNS objects after a version check.

    DNS clients are intended to use the system DoH/DoT proxy through
    dnsmasq. A user-provided Xray dns block is preserved, even when Xray's
    version is known, unless its explicit ownership marker is present. This
    prevents a config migration from silently changing user DNS semantics.
    """
    if not isinstance(parsed, dict):
        return parsed
    if 'dns' not in parsed:
        return parsed
    if not _xray_dns_block_owned(parsed):
        log_error(
            "Xray dns block preserved: ownership marker is absent")
        return parsed
    if not _xray_version_known():
        log_error(
            "Xray dns block preserved: version check unavailable")
        return parsed

    # Delete only after both guards pass. The associated inbound tags are
    # project-owned by definition of the same migration and are never
    # touched in a user-owned config.
    parsed.pop('dns', None)
    inbounds = parsed.get('inbounds')
    if isinstance(inbounds, list):
        parsed['inbounds'] = [
            ib for ib in inbounds
            if not (isinstance(ib, dict)
                    and ib.get('tag') in (
                        'dns-tunnel-tcp', 'dns-tunnel-udp'))]
    return parsed


def _ensure_xray_tproxy(parsed):
    """
    Гарантирует наличие двух inbound-ов dokodemo-door на порту
    config.localportvless:
      * TCP — приходит через nat/REDIRECT, sockopt.tproxy = "redirect";
      * UDP — приходит через mangle/TPROXY, sockopt.tproxy = "tproxy".

    Оба слушают один и тот же порт: TCP- и UDP-сокеты не конфликтуют,
    а правило TPROXY в 100-redirect.sh использует тот же номер порта.
    Без UDP-инбаунда весь UDP-трафик ресурсов из vless.txt (QUIC/HTTP3,
    DNS, игровой трафик, звонки) уходил мимо туннеля.

    Функция вызывается и при генерации из шаблона, и при вставке готового
    конфига через бота/веб-панель, поэтому UDP-инбаунд не теряется при
    смене ключа.
    """
    if not isinstance(parsed, dict):
        return parsed

    port = int(config.localportvless)
    inbounds = parsed.setdefault('inbounds', [])
    if not isinstance(inbounds, list):
        inbounds = []
        parsed['inbounds'] = inbounds

    # Убрать ранее добавленные служебные inbound-ы, чтобы не плодить дубли.
    inbounds[:] = [
        ib for ib in inbounds
        if not isinstance(ib, dict)
        or ib.get('tag') not in (
            'vless-udp-tproxy', 'vless-tcp-redirect')
    ]

    base = None
    for ib in inbounds:
        if not isinstance(ib, dict):
            continue
        try:
            ib_port = int(ib.get('port', 0))
        except (TypeError, ValueError):
            continue
        if (ib.get('protocol') == 'dokodemo-door'
                and ib_port == port):
            base = ib
            break

    if base is None:
        base = {
            'port': port,
            # IPv6 на роутере отключён — слушаем только IPv4.
            'listen': '0.0.0.0',
            'protocol': 'dokodemo-door',
            'settings': {},
            'sniffing': {
                'enabled': True,
                'destOverride': ['http', 'tls', 'quic'],
            },
        }
        inbounds.insert(0, base)

    base['tag'] = 'vless-tcp-redirect'
    base['port'] = port
    base['listen'] = '0.0.0.0'
    base['protocol'] = 'dokodemo-door'
    base.setdefault('settings', {})
    base['settings']['network'] = 'tcp'
    base['settings']['followRedirect'] = True
    base.setdefault('sniffing', {})
    base['sniffing']['enabled'] = True
    base['sniffing']['destOverride'] = ['http', 'tls', 'quic']
    base.setdefault('streamSettings', {})
    base['streamSettings'].setdefault('sockopt', {})
    base['streamSettings']['sockopt']['tproxy'] = 'redirect'

    udp = json.loads(json.dumps(base))
    udp['tag'] = 'vless-udp-tproxy'
    udp['settings']['network'] = 'udp'
    udp['settings']['followRedirect'] = True
    # Для UDP важен sniffing по QUIC, иначе маршрутизация по доменам
    # для HTTP/3 работать не будет.
    udp['sniffing'] = {
        'enabled': True,
        'destOverride': ['quic'],
    }
    udp['streamSettings']['sockopt']['tproxy'] = 'tproxy'
    inbounds.append(udp)

    # DNS listener Xray не создаётся: dnsmasq использует системные
    # DoH/DoT upstream-ы, а их внешние TCP/443 и TCP/853 соединения
    # перенаправляет 100-redirect.sh в активный tunnel.  Migration of an
    # existing dns block is performed by the outer config path only after
    # the Xray version check.
    _ensure_xray_udp_routing(parsed)

    # Пакеты, которые xray отправляет наружу, помечаются XRAY_SOCK_MARK.
    # Правило OUTPUT в 100-redirect.sh делает RETURN по этой метке, иначе
    # исходящий трафик самого xray заворачивался бы в его же inbound
    # (bot.txt перехватывается в OUTPUT) и получалась бы петля.
    _ensure_xray_outbound_mark(parsed)

    return parsed


# Должно совпадать с XRAY_MARK в /opt/etc/ndm/netfilter.d/100-redirect.sh
XRAY_SOCK_MARK = 0x2000000


def _ensure_xray_outbound_mark(parsed):
    """
    Проставляет sockopt.mark всем исходящим соединениям xray, кроме
    blackhole (у него нет сетевого выхода).
    """
    for ob in parsed.get('outbounds') or []:
        if not isinstance(ob, dict):
            continue
        # 'type' — вариант ключа в sing-box-конфигах.
        if (ob.get('protocol') or ob.get('type')) == 'blackhole':
            continue
        ss = ob.setdefault('streamSettings', {})
        sockopt = ss.setdefault('sockopt', {})
        sockopt['mark'] = XRAY_SOCK_MARK

    return parsed


# dns4.2.32 (статический аудит, F-02): единая семантика правил
# маршрутизации. Прежние три независимые проверки расходились:
# has_catch_all не смотрела на ip/domain/source-селекторы, has_udp_rule
# принимала любое правило с «udp» в network (даже ограниченное), а
# поиск дефолта не считал «network» условием — из-за этого вставка
# «udp,tcp -> proxy» могла переопределить пользовательское
# «network: tcp -> direct».
_RULE_CONDITION_KEYS = (
    'domain', 'domains', 'ip', 'source', 'sourcePort',
    'protocol', 'network', 'inboundTag', 'attrs', 'user',
    'rule_set', 'geosite', 'geoip',
)


def _rule_port_unconditional(rule):
    # «0-65535» покрывает все порты и приравнивается к отсутствию.
    return rule.get('port') in (None, '', '0-65535')


_ANY_IP = {
    '0.0.0.0/0', '::/0',
    '0.0.0.0-255.255.255.255'}


def _ip_covers_all(ip):
    # «ip: [0.0.0.0/0]» покрывает всё и приравнивается к
    # отсутствию селектора (дефолт вида «всё остальное -> direct»).
    # dns4.2.35 (ре-аудит, R-05): семантика Xray — правило матчится
    # при совпадении ЛЮБОГО элемента списка, поэтому достаточно ОДНОЙ
    # записи, покрывающей весь диапазон:
    #   ip: ["0.0.0.0/0", "192.0.2.0/24"]  →  покрывает всё.
    if not ip:
        return True
    if isinstance(ip, str):
        return ip.strip() in _ANY_IP
    if isinstance(ip, list):
        return any(
            str(x).strip() in _ANY_IP for x in ip)
    return False


def _is_unconditional(rule):
    if not isinstance(rule, dict):
        return False
    for key in _RULE_CONDITION_KEYS:
        if not rule.get(key):
            continue
        if key == 'ip' and _ip_covers_all(rule.get('ip')):
            continue
        return False
    return _rule_port_unconditional(rule)


def _covers_all_udp(rule, proxy_tag=None):
    if not isinstance(rule, dict):
        return False
    if proxy_tag is not None \
            and rule.get('outboundTag') != proxy_tag:
        return False
    network = rule.get('network')
    if isinstance(network, str):
        nets = {n.strip() for n in network.split(',')
                if n.strip()}
    elif isinstance(network, list):
        nets = {str(n).strip() for n in network
                if str(n).strip()}
    else:
        nets = {'tcp', 'udp'}
    if 'udp' not in nets:
        return False
    for key in _RULE_CONDITION_KEYS:
        if key == 'network':
            continue
        if not rule.get(key):
            continue
        if key == 'ip' and _ip_covers_all(rule.get('ip')):
            continue
        return False
    return _rule_port_unconditional(rule)


def _balancer_has_proxy(routing, balancer_tag, outbounds,
                        proxy_kinds, direct_kinds):
    # dns4.2.35 (ре-аудит, R-05): безусловное правило с
    # «balancerTag» — тоже дефолт маршрутизации. Разрешаем
    # балансировщик: его селекторы матчат теги outbound-ов
    # по префиксу; если среди выбранных есть прокси-выход,
    # политика пользователя уже покрывает трафик — своё
    # правило перед ним не ставим (не обходим балансировщик).
    balancers = routing.get('balancers')
    if not isinstance(balancers, list):
        return False
    selectors = None
    for b in balancers:
        if isinstance(b, dict) \
                and b.get('tag') == balancer_tag:
            sel = b.get('selector')
            if isinstance(sel, str):
                sel = [sel]
            selectors = [str(x) for x in (sel or [])]
            break
    if selectors is None:
        return False
    for ob in outbounds:
        if not isinstance(ob, dict):
            continue
        tag = str(ob.get('tag') or '')
        if not any(tag.startswith(x) for x in selectors):
            continue
        kind = ob.get('protocol') or ob.get('type')
        if kind in proxy_kinds:
            return True
        if kind not in direct_kinds:
            return True
    return False


def _ensure_xray_udp_routing(parsed):
    """
    Проверяет, что в routing нет правил, отбрасывающих UDP, и что
    существует общее правило на прокси-outbound. Без него UDP-инбаунд
    работал бы «в никуда» при конфигах, где правила заданы только для TCP.
    """
    outbounds = parsed.get('outbounds') or []
    if not outbounds:
        return parsed

    # Протокол берётся из 'protocol' (xray) либо 'type' (sing-box): при
    # вставке готового блока outbounds sing-box-конфига ключа 'protocol'
    # нет, из-за чего proxy_tag не находился и UDP-правило не добавлялось —
    # UDP из vless.txt приходил в inbound и отбрасывался за отсутствием
    # маршрута.
    proxy_kinds = ('vless', 'vmess', 'trojan', 'shadowsocks')
    direct_kinds = ('freedom', 'direct', 'blackhole', 'dns')

    proxy_tag = None
    for ob in outbounds:
        if not isinstance(ob, dict):
            continue
        kind = ob.get('protocol') or ob.get('type')
        if kind in proxy_kinds:
            proxy_tag = ob.get('tag') or 'proxy'
            ob['tag'] = proxy_tag
            break

    if not proxy_tag:
        # Протокол не распознан (нестандартный или новый) — берём первый
        # outbound, который заведомо не является прямым выходом.
        for ob in outbounds:
            if not isinstance(ob, dict):
                continue
            kind = ob.get('protocol') or ob.get('type')
            if kind in direct_kinds:
                continue
            proxy_tag = ob.get('tag') or 'proxy'
            ob['tag'] = proxy_tag
            break

    if not proxy_tag:
        return parsed

    routing = parsed.get('routing')
    if not isinstance(routing, dict):
        routing = {}
        parsed['routing'] = routing
    routing.setdefault('domainStrategy', 'IPIfNonMatch')
    rules = routing.setdefault('rules', [])
    if not isinstance(rules, list):
        rules = []
        routing['rules'] = rules

    has_catch_all = any(
        _is_unconditional(r)
        and r.get('outboundTag') == proxy_tag
        for r in rules)
    if not has_catch_all:
        has_catch_all = any(
            isinstance(r, dict)
            and _is_unconditional(r)
            and bool(r.get('balancerTag'))
            and _balancer_has_proxy(
                routing, r.get('balancerTag'),
                outbounds, proxy_kinds, direct_kinds)
            for r in rules)

    has_udp_rule = False
    for r in rules:
        if _covers_all_udp(r, proxy_tag):
            has_udp_rule = True
            break
        if isinstance(r, dict) and _covers_all_udp(r) \
                and r.get('balancerTag') \
                and _balancer_has_proxy(
                    routing, r.get('balancerTag'),
                    outbounds, proxy_kinds, direct_kinds):
            has_udp_rule = True
            break

    if not has_catch_all and not has_udp_rule:
        new_rule = {
            'type': 'field',
            'network': 'udp,tcp',
            'outboundTag': proxy_tag,
        }

        # Баг 8 фикс: правила маршрутизации матчатся СВЕРХУ ВНИЗ.
        # Прежний `rules.append` ставил наше правило после чужого
        # завершающего («всё остальное -> direct») в импортированных
        # конфигах, и оно никогда не срабатывало — весь перехваченный
        # трафик шёл мимо прокси. Но и вставка в позицию 0 неверна:
        # она переопределила бы пользовательские предметные правила
        # (домены/диапазоны -> direct). Ставим правило перед ПЕРВЫМ
        # обнаруженным завершающим правилом; если такого нет — в конец.
        # dns4.2.32 (F-02): дефолт ищем по той же семантике;
        # «network: tcp -> direct» теперь НЕ признаётся безусловным
        # и наше правило встаёт ПОСЛЕ него, не ломая политику.
        pos = len(rules)
        for i, r in enumerate(rules):
            if _is_unconditional(r):
                pos = i
                break
        rules.insert(pos, new_rule)

    return parsed


# Проектный mux-блок для vless-outbound-ов с flow=xtls-rprx-vision:
# включает ТОЛЬКО XUDP-канал для UDP/443. concurrency < 0 полностью
# отключает TCP-сторону mux (см. infra/conf/xray.go у Xray-core:
# "Concurrency < 0 completely disables mux"), поэтому TCP остаётся в
# прямом vision-режиме (splice/zero-copy) и не нагружает CPU роутера,
# а QUIC (UDP/443) перестаёт молча отбрасываться ядром
# ("XTLS rejected UDP/443 traffic" / "XUDP rejected UDP/443 traffic" —
# оба на уровне Info, которого в проектных логах нет).
KEENZOO_XRAY_MUX_UDP443 = {
    'enabled': True,
    'concurrency': -1,
    'xudpConcurrency': 8,
    'xudpProxyUDP443': 'allow',
}


def _ensure_xray_mux_udp443(parsed):
    """
    Управляет прохождением QUIC (UDP/443) в туннель по flow-семантике.

    Действие по отношению к mux-блоку у каждого vless-outbound:

    * flow НАЧИНАЕТСЯ с xtls-rprx-vision — впрыснуть/привести к
      проектному блоку KEENZOO_XRAY_MUX_UDP443. Без mux-блока с
      разрешением ядро при vision отбрасывает UDP/443 ещё до отправки,
      не оставляя следов на проектном loglevel=error: клиенты
      скатываются на TCP/HTTPS, и диагноз в логах не находится.
      Проект заворачивает в обход весь UDP с LAN (dokodemo-inbound
      UDP + TPROXY), поэтому политика «весь UDP в туннель» сильнее
      пользовательских значений mux при vision: четыре ключевых поля
      приводятся к проектным, прочие поля пользователя сохраняются.

    * vision-flow НЕТ — проектный mux-блок снимается, если он записан
      точно константой KEENZOO_XRAY_MUX_UDP443 (оставлен от смены ключа
      vision -> не-vision). Для не-vision-путей (WS+TLS, gRPC и пр.,
      где сервер нередко sing-box/не-Xray) mux-блок давал бы регресс:
      весь UDP уходил бы в XUDP-сеанс, который нативно понимает только
      Xray-сервер, тогда как без mux родной VLESS-UDP с не-vision
      работает и на других серверах. Пользовательский mux (значения
      отличаются от проектной константы) не трогается совсем.

    Функция идемпотентна.

    Известное допущение (сознательно не правится): снятие происходит
    только при полном совпадении mux с проектной константой. Если
    пользователь сам правил mux (скажем, xudpConcurrency) при vision-
    ключе, блок уже не совпадает с константой, и при последующей смене
    ключа на не-vision он останется — на сервере не-Xray UDP тогда
    пойдёт по XUDP (для таких серверов это не рабочий транспорт).
    Это осознанный компромисс: автозатирание пользовательских значений
    mux опаснее сохранения его поведения. Рекомендация по эксплуатации —
    в чек-листе маршрутизатора: для не-vision ключа с сервером sing-box
    применить vless:// заново (guard снимет проектный блок корректно).

    4.2.71 №5 (целостный аудит, декларация против рантайма): штатная
    заглушка «opt/etc/xray/config.json» и «vless_template.json»
    декларируют «mux.enabled: true» рядом с vision-потоком. Это
    НАМЕРЕННО; в сами JSON-файлы комментарии не добавляются (пайплайн
    читает их строгим «json.loads»): рантайм Xray сам отключает
    TCP-мультиплексирование для vision-соединения (предупреждение в
    лог — ожидаемо), но именно этот блок с «xudpProxyUDP443: allow»
    оставляет проекту политику «весь UDP в туннель». Выключать
    «mux.enabled» при vision нельзя: без разрешающего блока ядро
    отбрасывает UDP/443 до отправки.
    """
    if not isinstance(parsed, dict):
        return parsed
    outbounds = parsed.get('outbounds')
    if not isinstance(outbounds, list):
        return parsed
    for ob in outbounds:
        if not isinstance(ob, dict):
            continue
        if ob.get('protocol') != 'vless':
            continue
        settings = ob.get('settings')
        if not isinstance(settings, dict):
            continue
        vnext = settings.get('vnext')
        if not isinstance(vnext, list):
            continue
        vision = False
        for server in vnext:
            if not isinstance(server, dict):
                continue
            users = server.get('users')
            if not isinstance(users, list):
                continue
            for user in users:
                if not isinstance(user, dict):
                    continue
                flow = user.get('flow')
                if (isinstance(flow, str)
                        and flow.startswith('xtls-rprx-vision')):
                    vision = True
                    break
            if vision:
                break
        mux = ob.get('mux')
        if vision:
            if not isinstance(mux, dict):
                mux = {}
                ob['mux'] = mux
            mux.update(KEENZOO_XRAY_MUX_UDP443)
            continue
        # Не-vision: снимаем только проектный по значениям mux.
        if (isinstance(mux, dict)
                and len(mux) == len(KEENZOO_XRAY_MUX_UDP443)
                and all(mux.get(k) == v for k, v in
                        KEENZOO_XRAY_MUX_UDP443.items())):
            del ob['mux']
    return parsed


def _ensure_hysteria_tproxy(parsed):
    """
    Приводит нативный конфиг Hysteria2 к режиму прозрачного проксирования:
      * tcpRedirect — приём TCP из nat/REDIRECT;
      * udpTProxy   — приём UDP из mangle/TPROXY.

    Оба слушателя используют один порт config.localporthysteria, тот же,
    что указан в правилах 100-redirect.sh. Раньше udpTProxy мог
    отсутствовать (например, при вставке готового конфига), и весь UDP
    ресурсов из hysteria.txt шёл напрямую, минуя туннель.
    """
    if not isinstance(parsed, dict):
        return parsed

    port = int(config.localporthysteria)
    listen = f'0.0.0.0:{port}'

    tcp = parsed.get('tcpRedirect')
    if not isinstance(tcp, dict):
        tcp = {}
        parsed['tcpRedirect'] = tcp
    udp = parsed.get('udpTProxy')
    if not isinstance(udp, dict):
        udp = {}
        parsed['udpTProxy'] = udp
    tcp['listen'] = listen
    udp['listen'] = listen

    # Таймаут UDP-сессий: значение по умолчанию у hysteria велико для
    # роутера, 60 секунд достаточно для игр и звонков.
    parsed['udpTProxy'].setdefault('timeout', '60s')

    return parsed


def generate_config(key, template_file,
                    config_path,
                    replacements,
                    parse_func,
                    bot=None, chat_id=None):
    params = parse_func(key, bot, chat_id)

    with open(
            os.path.join(
                config.paths["templates_dir"],
                template_file),
            'r', encoding='utf-8') as f:
        template = f.read()

    cd = template

    for rk, rv in replacements.items():
        cd = cd.replace(
            "{{" + rk + "}}",
            _tpl_value(rk, rv))

    for pk, pv in params.items():
        cd = cd.replace(
            "{{" + pk + "}}",
            _tpl_value(pk, pv))

    if template_file.endswith('.json'):
        parsed = json.loads(cd)

        if template_file == 'vless_template.json':
            parsed = _remove_xray_dns_block(parsed)
            parsed = _ensure_xray_quiet_log(parsed)
            parsed = _ensure_xray_tproxy(parsed)
            parsed = _ensure_xray_mux_udp443(parsed)
            # dns4.2.18: &pin=<64-hex> в ссылке — само по себе намерение
            # закрепить сертификат; allowInsecure=1/insecure=1 без хеша —
            # TOFU-зонд. Шаблон несёт allowInsecure:false, без intent-проброса
            # параметр молча испарялся (dns4.2.17 закрыла этот flatten).
            _gci_pin = str(params.get('pinnedPeerCertSha256', '') or '')
            parsed = _normalize_xray_insecure(
                parsed,
                intent_flag=(str(params.get('allowInsecure', '')).lower()
                             in ('1', 'true', 'yes') or bool(_gci_pin)),
                intent_name=params.get('sni') or params.get('address'),
                intent_pin=_gci_pin or None)
        elif template_file == 'hysteria_template.json':
            parsed = _ensure_hysteria_tproxy(parsed)

        _cleanup_empty_fields(parsed)
        cd = json.dumps(
            parsed,
            ensure_ascii=False,
            indent=2)

    ConfigWriter.write_config(
        config_path, cd)

def vless_config(key, bot=None,
                 chat_id=None):
    generate_config(
        key=key,
        template_file="vless_template.json",
        config_path=config.paths[
            "vless_config"],
        replacements={
            "localportvless":
                config.localportvless},
        parse_func=parse_vless_key,
        bot=bot, chat_id=chat_id)


def trojan_config(key, bot=None,
                  chat_id=None):
    generate_config(
        key=key,
        template_file=(
            "trojan_template.json"),
        config_path=config.paths[
            "trojan_config"],
        replacements={
            "localporttrojan":
                config.localporttrojan},
        parse_func=parse_trojan_key,
        bot=bot, chat_id=chat_id)


def shadowsocks_config(key, bot=None,
                       chat_id=None):
    generate_config(
        key=key,
        template_file=(
            "shadowsocks_template.json"),
        config_path=config.paths[
            "shadowsocks_config"],
        replacements={
            "localportsh":
                config.localportsh},
        parse_func=parse_shadowsocks_key,
        bot=bot, chat_id=chat_id)


def hysteria_config(key, bot=None,
                    chat_id=None):
    os.makedirs(
        config.paths.get(
            "hysteria_dir",
            "/opt/etc/hysteria"),
        exist_ok=True)
    generate_config(
        key=key,
        template_file=(
            "hysteria_template.json"),
        config_path=config.paths[
            "hysteria_config"],
        replacements={
            "localporthysteria":
                config.localporthysteria},
        parse_func=parse_hysteria_key,
        bot=bot, chat_id=chat_id)
def _valid_cert_pin(value):
    """hex SHA-256 (64 символа) от DER сертификата; base64 ядро не принимает."""
    return isinstance(value, str) and bool(
        _v4_re.fullmatch(r'[0-9a-fA-F]{64}', value or ''))


def _fetch_server_cert_sha256(host, port, sni):
    """SHA-256 (hex) по DER сертификата сервера; None при недоступности.

    Один прямой TLS-коннект с SSL.CERT_NONE (trust-on-first-use): сертификат
    как раз и неизвестен, поэтому верификация здесь бессмысленна. Изолирован
    в отдельную функцию для моков в регрессии — сеть из тестов не вызывается.
    """
    try:
        import hashlib as _pin_hashlib
        import socket as _pin_socket
        import ssl as _pin_ssl
        ctx = _pin_ssl.SSLContext(_pin_ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = _pin_ssl.CERT_NONE
        with _pin_socket.create_connection(
                (host, int(port)), timeout=6) as sock:
            with ctx.wrap_socket(
                    sock, server_hostname=(sni or None)) as ssock:
                der = ssock.getpeercert(binary_form=True)
        if not der:
            return None
        return _pin_hashlib.sha256(der).hexdigest()
    except Exception:
        return None


def _outbound_endpoint(ob):
    """address/port для TOFU-зонда из settings.vnext[0]."""
    st = ob.get('settings')
    if not isinstance(st, dict):
        return None, None
    vn = st.get('vnext')
    if isinstance(vn, list) and vn and isinstance(vn[0], dict):
        return vn[0].get('address'), vn[0].get('port')
    return None, None


def _pin_helper_cmd(host, port, sni):
    return ("openssl s_client -connect %s:%s -servername %s </dev/null "
            "2>/dev/null | openssl x509 -outform DER | openssl sha256"
            % (host or '<host>', port or 443, sni or '<sni>'))


def _log_pin_conversion(pin, tag, origin, host, port, sni):
    log_error(
        "Xray: allowInsecure → pinnedPeerCertSha256 '%s…' (outbound '%s', "
        "%s): ядро ≥26 убрал allowInsecure; сертификат закреплён по SHA-256 "
        "(trust-on-first-use) — сверьте хеш: %s. После перевыпуска "
        "сертификата примените ключ заново"
        % (pin[:12], tag, origin, _pin_helper_cmd(host, port, sni)))


def _normalize_xray_insecure(parsed, intent_flag=None, intent_name=None,
                             intent_pin=None):
    """allowInsecure/pin-намерение → pinnedPeerCertSha256 (Xray ≥ 26).

    Xray ≥ 25.x убрал поле allowInsecure (hard-fail проверки конфига:
    «migrated to pinnedPeerCertSha256 / verifyPeerCertByName»). Единственный
    рабочий аналог для самоподписанного сервера — pinnedPeerCertSha256
    (hex SHA-256 по DER): verifyPeerCertByName сверяет имя ПОВЕРХ
    CA-проверки и самоподписанный сертификат по-прежнему отклоняет.

    Приоритеты в tlsSettings (только при streamSettings.security == 'tls';
    reality/none не трогаются — там tlsSettings очисткой снимается, и
    конвертация порождала ложные записи в журнале):
      1. Нативный pinnedPeerCertSha256 (пользователь задал явно) — принят,
         недействительный allowInsecure просто снимается.
      2. Явный verifyPeerCertByName пользователя — принят, allowInsecure
         снимается (поле мёртво на новом ядре), в журнал — одна честная
         строка.
      3. Хеш из входа (intent_pin: параметр ссылки &pin=/&hash=/
         &pinnedPeerCertSha256=, sing-box tls.pin_sha256) — hex64 или отказ.
      4. TOFU-зонд к address:port с SNI (см. _fetch_server_cert_sha256);
         недостижим → ValueError с openssl-командой для ручного хеша.
    """
    if not isinstance(parsed, dict):
        return parsed
    outbounds = parsed.get('outbounds')
    if not isinstance(outbounds, list):
        outbounds = []
    if intent_pin and not _valid_cert_pin(intent_pin):
        raise ValueError(
            "Пин сертификата: ожидается 64 hex-символа SHA-256 по DER; "
            "base64 ядром Xray не принимается. Получить: %s"
            % _pin_helper_cmd(None, None, intent_name))
    pin_from_intent = (intent_pin or '').lower() or None
    converted = 0
    tls_seen = 0
    for ob in outbounds:
        if not isinstance(ob, dict):
            continue
        stream = ob.get('streamSettings')
        if not isinstance(stream, dict):
            continue
        if stream.get('security') != 'tls':
            continue
        tls = stream.get('tlsSettings')
        if not isinstance(tls, dict):
            continue
        tls_seen += 1
        tag = ob.get('tag') or ob.get('protocol') or '?'
        host, port = _outbound_endpoint(ob)
        sni = tls.get('serverName') or intent_name
        if _valid_cert_pin(tls.get('pinnedPeerCertSha256')):
            tls['pinnedPeerCertSha256'] = tls[
                'pinnedPeerCertSha256'].lower()
            if tls.pop('allowInsecure', None):
                log_error(
                    "Xray: allowInsecure снят у outbound '%s' — на ядре ≥26 "
                    "поле мертво; действует ваш pinnedPeerCertSha256" % tag)
            continue
        if bool(tls.get('allowInsecure')) and tls.get('verifyPeerCertByName'):
            tls.pop('allowInsecure', None)
            log_error(
                "Xray: allowInsecure снят у outbound '%s' — на ядре ≥26 "
                "поле мертво; действует ваш verifyPeerCertByName '%s'"
                % (tag, tls['verifyPeerCertByName']))
            continue
        want = bool(tls.get('allowInsecure')) or bool(
            intent_flag and not tls.get('pinnedPeerCertSha256'))
        if not want:
            continue
        pin = pin_from_intent
        origin = 'хеш из входа'
        if not pin:
            pin = _fetch_server_cert_sha256(host, port, sni) if host else None
            origin = 'TOFU-зонд'
        if not pin:
            raise ValueError(
                "Xray ≥26 не поддерживает allowInsecure; сертификат сервера "
                "недоступен для автоматического пиннинга (прямое подключение "
                "к %s:%s не удалось). Укажите хеш вручную (&pin= в ссылке "
                "или поле pinnedPeerCertSha256): %s"
                % (host, port, _pin_helper_cmd(host, port, sni)))
        tls.pop('allowInsecure', None)
        tls['pinnedPeerCertSha256'] = pin
        converted += 1
        _log_pin_conversion(pin, tag, origin, host, port, sni)
    if intent_flag and converted == 0 and tls_seen == 0:
        log_error(
            "Xray: запрошен allowInsecure/insecure=1, но TLS-outbound "
            "не найден (security=reality/none): под reality параметр не "
            "имеет смысла и проигнорирован")
    return parsed


def _geo_asset_ref(entry):
    # dns4.2.35 (ре-аудит, R-08): запись ссылается на внешний
    # гео-ассет, если это «geosite:tag», «geoip:tag» (в том числе
    # инвертированные «!…») или «ext:file.dat:tag». Возвращает имя
    # файла ассета либо None.
    if not isinstance(entry, str):
        return None
    e = entry.strip()
    if e.startswith('!'):
        e = e[1:].strip()
    if e.startswith('ext:'):
        parts = e.split(':', 2)
        return parts[1] if len(parts) >= 2 and parts[1] else None
    if e.startswith('geosite:'):
        return 'geosite.dat'
    if e.startswith('geoip:'):
        return 'geoip.dat'
    return None


def _needs_geo_assets(rule):
    """Правилу нужны гео-ассеты (geosite/geoip/ext .dat)."""
    domain = rule.get('domain') or []
    if isinstance(domain, str):
        domain = [domain]
    for entry in domain:
        if _geo_asset_ref(entry):
            return True
    ip = rule.get('ip') or []
    if isinstance(ip, str):
        ip = [ip]
    for entry in ip:
        if _geo_asset_ref(entry):
            return True
    return bool(rule.get('geosite')
                or rule.get('geoip'))


def _convert_singbox_vless(sb):
    """sing-box vless → xray."""
    server = sb.get('server', '')
    port = _validate_port(sb.get('server_port', 443), 'server_port')
    uuid = sb.get('uuid', '')
    flow = sb.get('flow', '')
    if not server:
        raise ValueError("Нет server")
    _reject_endpoint_ipv6(server, "server")
    if not uuid:
        raise ValueError("Нет uuid")
    tls = sb.get('tls', {})
    sni = tls.get('server_name', server)
    reality = tls.get('reality', {})
    utls = tls.get('utls', {})
    security = 'none'
    if reality.get('enabled'):
        security = 'reality'
    elif tls.get('enabled'):
        security = 'tls'
    # Параметры переносятся БЕЗ самодеятельности: сервер сверяет их при
    # рукопожатии, и любая подстановка «разумного» значения приводит к
    # отказу в подключении. Поэтому поля, которых нет во входном конфиге,
    # не выдумываются, а просто не попадают в выход.
    fp = utls.get('fingerprint', tls.get('fingerprint', ''))
    transport = sb.get('transport', {})
    if not isinstance(transport, dict):
        raise ValueError("transport должен быть объектом")
    network = transport.get('type', 'tcp')

    def _singbox_text(value, field):
        """Normalize scalar fields from subscription JSON variants.

        Xray expects WS Host and xhttp/httpupgrade host as strings. Some
        sing-box/Clash converters emit a one-item JSON array instead. Accept
        that harmless variant, but reject multiple values instead of writing
        an invalid Xray config or silently choosing the wrong Host.
        """
        if value is None:
            return ''
        if isinstance(value, str):
            return value
        if isinstance(value, list):
            if not value:
                return ''
            if len(value) == 1 and isinstance(value[0], str):
                return value[0]
        raise ValueError(
            f"{field} должен быть строкой или массивом из одной строки")

    headers = transport.get('headers', {})
    if headers is None:
        headers = {}
    if not isinstance(headers, dict):
        raise ValueError("transport.headers должен быть объектом")
    header_host = _singbox_text(
        headers.get('Host', headers.get('host', '')),
        'transport.headers.Host')
    explicit_host = (_singbox_text(
        transport.get('host'), 'transport.host')
        if 'host' in transport else header_host)

    stream = {
        "network": network,
        "security": security,
    }
    if security == 'reality':
        rs = {
            "publicKey": reality.get('public_key', ''),
            "serverName": sni,
            "shortId": reality.get('short_id', ''),
        }
        # fingerprint подставлять нельзя: 'chrome' вместо заданного 'qq'
        # меняет отпечаток TLS ClientHello, и Reality-сервер отвергает
        # соединение. Ключ добавляется, только если задан пользователем.
        if fp:
            rs["fingerprint"] = fp
        # spiderX ("/") раньше добавлялся всегда. Это параметр Reality,
        # который сервер учитывает; навязывать его нельзя.
        spx = reality.get('spider_x', reality.get('spiderX', ''))
        if spx:
            rs["spiderX"] = spx
        stream["realitySettings"] = rs
    elif security == 'tls':
        ts = {"serverName": sni}
        if fp:
            ts["fingerprint"] = fp
        # insecure из входного конфига раньше игнорировался (жёсткое
        # allowInsecure=False), затем ядро Xray ≥ 25.x убрало поле вовсе
        # (true → hard-fail 'xray -test'). dns4.2.18: рабочий путь —
        # pinnedPeerCertSha256 (verifyPeerCertByName сверяет имя ПОВЕРХ
        # CA-проверки и самоподписанный сертификат отклоняет); хеш — из
        # tls.pin_sha256, иначе один TOFU-зонд к серверу. sni здесь всегда
        # непуст (fallback на server).
        if bool(tls.get('insecure', False)):
            sb_pin = (tls.get('pin_sha256')
                      or tls.get('pinnedPeerCertSha256') or '')
            if sb_pin and not _valid_cert_pin(sb_pin):
                raise ValueError(
                    "tls.pin_sha256: ожидается 64 hex-символа SHA-256 по "
                    "DER; base64 ядром Xray не принимается. Получить: %s"
                    % _pin_helper_cmd(server, port, sni))
            sb_pin = (sb_pin or '').lower()
            if not sb_pin:
                sb_pin = _fetch_server_cert_sha256(server, port, sni) or ''
            if not sb_pin:
                raise ValueError(
                    "Xray ≥26 не поддерживает tls.insecure; сертификат "
                    "%s:%s недоступен для автоматического пиннинга. Укажите "
                    "tls.pin_sha256 вручную: %s"
                    % (server, port, _pin_helper_cmd(server, port, sni)))
            ts["pinnedPeerCertSha256"] = sb_pin
            _log_pin_conversion(
                sb_pin, 'vless-reality',
                'sing-box tls.insecure', server, port, sni)
        alpn = tls.get('alpn')
        if alpn:
            ts["alpn"] = alpn if isinstance(alpn, list) else [alpn]
        stream["tlsSettings"] = ts
    if network == 'grpc':
        stream["grpcSettings"] = {
            "serviceName":
                transport.get(
                    'service_name', ''),
        }
    elif network == 'ws':
        stream["wsSettings"] = {
            "path": transport.get(
                'path', '/'),
            "headers": {
                # Xray's wsSettings.headers.Host is a string. A number of
                # subscription JSONs use ["host"] here; header_host above
                # normalizes that one-item form before serialization.
                "Host": header_host,
            },
        }
    elif network == 'xhttp':
        # Транспорт xhttp (бывший splithttp). Без этого блока xray
        # получал "network": "xhttp" БЕЗ настроек: path и mode терялись,
        # клиент стучался в корень "/" вместо рабочего пути, и сервер
        # рвал соединение. Шаблон vless_template.json xhttpSettings уже
        # умеет — ссылки vless:// работали, а JSON sing-box нет.
        stream["xhttpSettings"] = {
            "mode": transport.get('mode', 'auto'),
            "path": transport.get('path', '/'),
            "host": explicit_host,
        }
    elif network == 'httpupgrade':
        stream["httpupgradeSettings"] = {
            "path": transport.get('path', '/'),
            "host": explicit_host,
        }
    elif network not in ('tcp', ''):
        # Неизвестный транспорт молча пропускать нельзя: xray получит
        # network без соответствующих настроек и будет подключаться
        # неверно. Лучше отказать сразу с понятным текстом.
        raise ValueError(
            f"Транспорт '{network}' не поддерживается. "
            "Поддерживаются: tcp, ws, grpc, xhttp, httpupgrade.")
    user = {
        "id": uuid,
        # encryption обязателен для vless и всегда "none" по спецификации
        # протокола — это не подстановка, а требование формата xray.
        "encryption": "none",
        "level": 0,
    }
    if flow:
        user["flow"] = flow
    xray = {
        "log": {
            "access": "",
            "error": "",
            "loglevel": "none",
        },
        # Inbound-ы (TCP redirect + UDP tproxy) добавит _ensure_xray_tproxy.
        "inbounds": [],
        "outbounds": [
            {
                "tag": "vless-reality",
                "protocol": "vless",
                "settings": {
                    "vnext": [{
                        "address": server,
                        "port": port,
                        "users": [user],
                    }],
                },
                "streamSettings": stream,
            },
            {
                "tag": "direct",
                "protocol": "freedom",
            },
        ],
        "routing": {
            "domainStrategy":
                "IPIfNonMatch",
            "rules": [{
                "type": "field",
                "network": "udp,tcp",
                "port": "0-65535",
                "outboundTag":
                    "vless-reality",
                "enabled": True,
            }],
        },
    }
    return xray


def _convert_xray_hysteria(xc):
    """xray hysteria → нативный hy2."""
    outbounds = xc.get('outbounds', [])
    ho = None
    for ob in outbounds:
        if not isinstance(ob, dict):
            continue
        pr = ob.get('protocol', '')
        if pr in ('hysteria', 'hysteria2'):
            ho = ob
            break
    if not ho:
        raise ValueError("Нет outbound hy")
    settings = ho.get('settings', {})
    stream = ho.get('streamSettings', {})
    tls_s = stream.get('tlsSettings', {})
    hy_s = stream.get(
        'hysteriaSettings', {})
    address = settings.get(
        'address',
        settings.get('server', ''))
    port = settings.get('port', 443)
    if not address:
        vn = settings.get('vnext', [])
        if vn:
            address = vn[0].get(
                'address', '')
            port = vn[0].get('port', 443)
    if not address:
        raise ValueError("Нет адреса")
    port = _validate_port(port, 'server_port')
    _reject_endpoint_ipv6(address, "server")
    auth = hy_s.get(
        'auth',
        hy_s.get(
            'auth_str',
            settings.get('auth', '')))
    if not auth:
        vn = settings.get('vnext', [])
        if vn:
            users = vn[0].get('users', [])
            if users:
                auth = users[0].get(
                    'id',
                    users[0].get(
                        'password', ''))
    if not auth:
        raise ValueError("Нет auth")
    sni = tls_s.get(
        'serverName',
        tls_s.get('sni', address))
    alpn = tls_s.get('alpn', [])
    if isinstance(alpn, str):
        alpn = [alpn]
    insecure = tls_s.get(
        'allowInsecure',
        tls_s.get('insecure', False))
    native = {
        "server": f"{address}:{port}",
        "auth": auth,
        "tls": {
            "sni": sni,
            "insecure": insecure,
        },
        "quic": {
            "initStreamReceiveWindow":
                8388608,
            "maxStreamReceiveWindow":
                8388608,
            "initConnReceiveWindow":
                20971520,
            "maxConnReceiveWindow":
                20971520,
        },
        "tcpRedirect": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}")
        },
        # UDP-приём обязателен, иначе QUIC/игровой трафик пойдёт мимо.
        "udpTProxy": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}"),
            "timeout": "60s",
        }
    }
    if alpn:
        native['tls']['alpn'] = alpn
    fm = stream.get('finalmask', {})
    qp = fm.get('quicParams', {})
    cg = qp.get('congestion', '')
    if cg:
        native['quic']['congestion'] = cg
    return native


def _convert_singbox_hysteria(sb):
    """sing-box hysteria2 → нативный hy2."""
    server = sb.get('server', '')
    port = _validate_port(sb.get('server_port', 443), 'server_port')
    password = sb.get('password', '')
    if not server:
        raise ValueError("Нет server")
    _reject_endpoint_ipv6(server, "server")
    if not password:
        raise ValueError("Нет password")
    tls = sb.get('tls', {})
    sni = tls.get(
        'server_name',
        tls.get('sni', server))
    insecure = tls.get(
        'insecure', False)
    alpn = tls.get('alpn', [])
    if isinstance(alpn, str):
        alpn = [alpn]
    native = {
        "server": f"{server}:{port}",
        "auth": password,
        "tls": {
            "sni": sni,
            "insecure": insecure,
        },
        "quic": {
            "initStreamReceiveWindow":
                8388608,
            "maxStreamReceiveWindow":
                8388608,
            "initConnReceiveWindow":
                20971520,
            "maxConnReceiveWindow":
                20971520,
        },
        "tcpRedirect": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}")
        },
        "udpTProxy": {
            "listen": (
                f"0.0.0.0:"
                f"{config.localporthysteria}"),
            "timeout": "60s",
        }
    }
    if alpn:
        native['tls']['alpn'] = alpn
    # dns4.2.35 (ре-аудит, R-09): лимиты полосы нативный клиент
    # понимает («bandwidth», Мбит/с) — переносим. Порт-хоппинг
    # (список портов сервера и интервал прыжков) нативный клиент
    # не воспроизводит: тихий успех означал бы подключение к
    # единственному порту вместо ожидаемого хоппинга, поэтому
    # такие импорты отклоняем явно.
    if sb.get('server_ports') or sb.get('hop_interval'):
        raise ValueError(
            "hysteria2: port hopping (server_ports/"
            "hop_interval) не поддерживается нативным "
            "клиентом")
    _hy_up = sb.get('up_mbps')
    _hy_down = sb.get('down_mbps')
    if _hy_up or _hy_down:
        _hy_bw = {}
        if _hy_up:
            _hy_bw['up'] = int(_hy_up)
        if _hy_down:
            _hy_bw['down'] = int(_hy_down)
        native['bandwidth'] = _hy_bw
    # dns4.2.32 (статический аудит, F-06): без переноса obfs
    # обфусцированный сервер отвергал бы соединение, хотя импорт
    # выглядел успешным. Неподдерживаемые варианты — явная ошибка,
    # а не тихое игнорирование.
    obfs = sb.get('obfs') or {}
    if obfs:
        obfs_type = obfs.get('type')
        if obfs_type != 'salamander' \
                or not obfs.get('password'):
            raise ValueError(
                "obfs: поддерживается только "
                "salamander с password")
        native['obfs'] = {
            'type': 'salamander',
            'salamander': {
                'password': obfs['password'],
            },
        }
    return native


def _validate_direct_endpoints(protocol, parsed):
    """Reject invalid endpoints in formats used by direct-config flow."""
    if protocol == 'vless':
        valid = False
        for outbound in parsed.get('outbounds') or []:
            if not isinstance(outbound, dict):
                continue
            settings = outbound.get('settings') or {}
            if not isinstance(settings, dict):
                continue
            for vnext in settings.get('vnext') or []:
                if not isinstance(vnext, dict) or not vnext.get('address'):
                    continue
                valid = True
                _reject_endpoint_ipv6(vnext['address'], 'VLESS server')
                if 'port' in vnext:
                    _validate_port(vnext['port'], 'server_port')
        if not valid:
            raise ValueError("Нет VLESS outbound с server address")
    elif protocol == 'shadowsocks':
        servers = parsed.get('server', [])
        if not isinstance(servers, list):
            servers = [servers]
        for server in servers:
            _reject_endpoint_ipv6(server, 'Shadowsocks server')
        _validate_port(parsed.get('server_port'), 'server_port')
    elif protocol == 'trojan':
        _reject_endpoint_ipv6(
            parsed.get('remote_addr', ''), 'Trojan server')
    elif protocol == 'hysteria':
        server = parsed.get('server', '')
        _reject_endpoint_ipv6(server, 'Hysteria server')
        port = _endpoint_port(server)
        if port is None:
            raise ValueError("Hysteria server must be host:port")
        _validate_port(port, 'server_port')


def apply_direct_config(protocol,
                        config_data,
                        bot=None,
                        chat_id=None):
    """
    JSON конфиг напрямую.
    xray, sing-box, нативный.
    """
    cp = {
        'vless': config.paths[
            "vless_config"],
        'shadowsocks': config.paths[
            "shadowsocks_config"],
        'trojan': config.paths[
            "trojan_config"],
        'hysteria': config.paths[
            "hysteria_config"],
    }
    cdir = {
        'vless': config.paths.get(
            "xray_dir", "/opt/etc/xray"),
        'trojan': config.paths.get(
            "trojan_dir",
            "/opt/etc/trojan"),
        'hysteria': config.paths.get(
            "hysteria_dir",
            "/opt/etc/hysteria"),
    }
    if protocol not in cp:
        raise ValueError(
            f"Неизвестный: {protocol}")
    filepath = cp[protocol]
    dp = cdir.get(protocol)
    if dp:
        os.makedirs(dp, exist_ok=True)
    # JSON из файлов/Telegram может начинаться с UTF-8 BOM.
    # Удаляем только BOM в начале, не изменяя токены и значения полей.
    data = config_data.lstrip('\ufeff').strip()
    if not data:
        raise ValueError("Пустой конфиг")
    try:
        parsed = json.loads(data)
    except json.JSONDecodeError as e:
        raise ValueError(f"JSON: {e}") from e
    if not isinstance(parsed, dict):
        raise ValueError("Корневой JSON должен быть объектом")

    if protocol == 'vless':
        if 'outbounds' in parsed:
            # xray формат. Inbound-ы формирует _ensure_xray_tproxy ниже:
            # отдельно TCP (redirect) и UDP (tproxy). Прежняя версия
            # ставила один inbound "tcp,udp" с followRedirect, из-за чего
            # UDP приходил без оригинального адреса назначения.
            parsed['inbounds'] = []
            rt = parsed.get('routing')
            if not isinstance(rt, dict):
                rt = {}
                parsed.pop('routing', None)
            rules = rt.get('rules', [])
            if not isinstance(rules, list):
                rules = []
            # dns4.2.32 (статический аудит, F-05): прежний фильтр
            # без предупреждения выбрасывал ВСЕ правила с ключом
            # «domain», включая пользовательские исключения
            # (например, домен -> direct). Теперь правила
            # сохраняются; отбрасываются только требующие гео-ассетов
            # (geosite:/geoip:) — проект .dat-файлы не поставляет,
            # и старт xray с ними завершился бы ошибкой.
            cr = []
            _geo_dropped = 0
            for r in rules:
                if not isinstance(r, dict):
                    continue
                if _needs_geo_assets(r):
                    _geo_dropped += 1
                    continue
                cr.append(r)
            if _geo_dropped:
                log_error(
                    "Импорт xray: правил с "
                    "geosite:/geoip: отброшено — "
                    "гео-ассеты отсутствуют: "
                    + str(_geo_dropped))
            if cr:
                rt['rules'] = cr
                parsed['routing'] = rt
            elif 'routing' in parsed:
                del parsed['routing']
        elif (parsed.get('type') == 'vless'
              or ('server' in parsed
                  and 'uuid' in parsed)):
            # sing-box формат
            parsed = (
                _convert_singbox_vless(
                    parsed))
        else:
            raise ValueError(
                "Нет outbounds "
                "или server/uuid")

    elif protocol == 'shadowsocks':
        if 'server' not in parsed:
            raise ValueError("Нет server")
        parsed['local_port'] = (
            config.localportsh)

    elif protocol == 'trojan':
        if (not parsed.get('remote_addr')
                or 'remote_port' not in parsed
                or not parsed.get('password')):
            raise ValueError(
                "Нет remote_addr/remote_port/password")
        parsed['remote_port'] = _validate_port(
            parsed['remote_port'], 'remote_port')
        parsed['local_port'] = (
            config.localporttrojan)

    elif protocol == 'hysteria':
        if ('server' in parsed
                and 'auth' in parsed):
            # Нативный формат
            pass
        elif ('server' in parsed
              and 'password' in parsed):
            # sing-box формат
            parsed = (
                _convert_singbox_hysteria(
                    parsed))
        elif 'outbounds' in parsed:
            # xray формат
            parsed = (
                _convert_xray_hysteria(
                    parsed))
        else:
            raise ValueError(
                "Нет server/auth, "
                "server/password "
                "или outbounds")

    _validate_direct_endpoints(protocol, parsed)

    if protocol == 'vless':
        parsed = _remove_xray_dns_block(parsed)
        parsed = _ensure_xray_quiet_log(parsed)
        parsed = _ensure_xray_tproxy(parsed)
        parsed = _ensure_xray_mux_udp443(parsed)
        parsed = _normalize_xray_insecure(parsed)
    elif protocol == 'hysteria':
        parsed = _ensure_hysteria_tproxy(parsed)

    ConfigWriter.write_config(
        filepath,
        json.dumps(parsed, ensure_ascii=False))


@notify_on_error()
def tor_config(bridges, bot=None,
               chat_id=None):
    bl = bridges.strip().split('\n')
    vt = {"obfs4", "webtunnel"}
    # Очищенные строки: в torrc должен попасть нормализованный текст,
    # иначе markdown-разметка из буфера обмена уедет в конфиг и Tor
    # не сможет разобрать мост.
    cleaned = []

    # Адрес моста: только IPv4 (1.2.3.4:443).
    # dns4.2.58 М-10 (аудит 2026-09-29): проект IPv4-only; IPv6-мост
    # ушёл бы вне политики при активном стеке или дал бы неработающий
    # конфиг при отключённом. Октеты и порт проверяются по значению.
    def _valid_endpoint(value):
        if not value:
            return False
        if value.startswith('['):
            return False
        host, sep, port = value.rpartition(':')
        if not sep:
            return False
        if not port.isdigit() or not 1 <= int(port) <= 65535:
            return False
        try:
            socket.inet_pton(socket.AF_INET, host)
        except (OSError, ValueError):
            return False
        return True

    urp = re.compile(
        r"^https?://[^\s/$.?#].\S*$")

    for line in bl:
        line = line.strip()
        if not line:
            continue
        # Строки часто копируют из мессенджера или веб-страницы вместе с
        # markdown-разметкой: ++[https://a/b](https://a/b)++. Tor такой
        # формат не понимает, а пользователь видел невнятную ошибку.
        # Разметка снимается, ссылка берётся из адресной части.
        if '](' in line or '++[' in line:
            line = re.sub(
                r'\+*\[([^\]]+)\]\((?:[^)]*)\)\+*', r'\1', line)
            line = line.replace('++', '').strip()
        cleaned.append(line)
        parts = line.split()
        if parts and parts[0].lower() == "bridge":
            parts = parts[1:]
        if not parts:
            raise ValueError(
                f"Мост: '{line}'")
        tt = (parts[0]
              if parts[0] in vt
              else None)
        if tt:
            if len(parts) < 2:
                raise ValueError(
                    f"IP: '{line}'")
            bd = parts[1]
        else:
            bd = parts[0]
        if tt == "webtunnel":
            if not _valid_endpoint(bd):
                raise ValueError(
                    f"IP:порт: '{line}'")
            # url= может быть пустым
            # в некоторых мостах
            url_match = next(
                (p[4:]
                 for p in parts
                 if p.startswith("url=")),
                None)
            if url_match is None:
                raise ValueError(
                    f"Нет url=: '{line}'")
            # Проверять URL только если
            # он не пустой
            if (url_match
                    and not urp.match(
                        url_match)):
                raise ValueError(
                    f"URL: '{line}'")
        else:
            if not _valid_endpoint(bd):
                raise ValueError(
                    f"IP:порт: '{line}'")

    with open(
            os.path.join(
                config.paths[
                    "templates_dir"],
                "tor_template.torrc"),
            'r', encoding='utf-8') as f:
        cdata = f.read()
        cdata = cdata.replace(
            "{{localporttor}}",
            str(config.localporttor))
        cdata = cdata.replace(
            "{{dnsporttor}}",
            str(config.dnsporttor))
        bo = "\n".join(cleaned) if cleaned else bridges.strip()
        transports = ["obfs4", "webtunnel"]
        found = False
        for t in transports:
            if t in bo:
                bo = "\n".join(
                    line if line.startswith("Bridge ")
                    else (line.replace(
                        t,
                        f"Bridge {t}", 1)
                    if line.startswith(t)
                    else line)
                    for line in
                    bo.splitlines())
                cdata = cdata.replace(
                    f"#ClientTransport"
                    f"Plugin {t}",
                    f"ClientTransport"
                    f"Plugin {t}", 1)
                found = True
        # 4.2.72 М-3 (аудит поведения при деградации): «UseBridges»
        # обязан отражать факт рендера мостов. «UseBridges 1» без
        # единой строки Bridge не даёт тору собрать ни одной цепи;
        # без мостов тор работает обычным клиентом.
        cdata = cdata.replace(
            "{{usebridges}}",
            "1" if (found and bo.strip()) else "0")
        cdata = cdata.replace(
            "{{bridges}}",
            bo if found else "")
    ConfigWriter.write_config(
        config.paths["tor_config"],
        cdata, format='text')



# ── Валидаторы записей списков разблокировки ─────────────────────────
# dns4.2.40 M-7 (аудит-3): перенесены из generator.py. Проверка записей
# в боте/панели больше не требует импорта модуля генератора, который на
# уровне модуля тянет Flask (+7 МБ даже при выключенной панели).
# Сигнатуры и поведение сохранены; в generator.py имена реэкспортируются.
import ipaddress

def _clean_entry(entry):
    return entry.split('#')[0].strip()


def _validate_cidr(entry):
    try:
        ipaddress.IPv4Network(entry, strict=False)
        return '/' in entry
    except ValueError:
        return False


def _validate_ip(entry):
    try:
        ipaddress.IPv4Address(entry)
        return True
    except ValueError:
        return False


# dns4.2.23 (аудит A5 #1), dns4.2.24 (A6 N5): таблица зарезервированных
# сетей. ПРАВИТЬ СИНХРОННО с awk-реализациями: is_public_cidr/
# is_public_range — в unblock_ipset.sh (с dns4.2.40 единственные копии),
# is_public_ipv4 — в unblock_ipset.sh и unblock_dnsmasq.sh.
# Shell остаётся исполнителем последней мили; панель отсекает те же
# записи заранее, чтобы сохранённый список совпадал с фактически
# применённым (раньше приватный адрес сохранялся, но тихо отбрасывался
# при наполнении ipset).
_RESERVED_NETS = (
    ('0.0.0.0', 8), ('10.0.0.0', 8), ('100.64.0.0', 10),
    ('127.0.0.0', 8), ('169.254.0.0', 16), ('172.16.0.0', 12),
    ('192.0.0.0', 24), ('192.0.2.0', 24), ('192.88.99.0', 24),
    ('192.168.0.0', 16), ('192.175.48.0', 24), ('198.18.0.0', 15),
    ('198.51.100.0', 24), ('203.0.113.0', 24),
    # 224.0.0.0/3: shell-таблицы отсекают весь хвост 224—255 (и
    # multicast, и reserved 240/4) одной записью — держим так же.
    ('224.0.0.0', 3),
)


def _is_public_v4(addr):
    """True, только если адрес/сеть пройдёт public-фильтр shell-слоя."""
    net, _, plen = addr.partition('/')
    try:
        octets = [int(x) for x in net.split('.')]
        plen = 32 if not plen else int(plen)
    except ValueError:
        return False
    if len(octets) != 4 or not 0 <= plen <= 32:
        return False
    value = ((octets[0] << 24) | (octets[1] << 16)
             | (octets[2] << 8) | octets[3])
    # dns4.2.24 (аудит A6 N2): сравнивать надо АДРЕС СЕТИ, как это
    # делает awk-слой (first = int(v/block)*block в is_public_cidr):
    # ненормализованный ввод вида 1.163.38.40/7 раньше проходил панель
    # по адресу узла, тогда как shell честно отбрасывал сеть 0.0.0.0/7.
    value &= ~((1 << (32 - plen)) - 1) & 0xFFFFFFFF
    end = value | ((1 << (32 - plen)) - 1)
    for net_ip, pref in _RESERVED_NETS:
        o = [int(x) for x in net_ip.split('.')]
        start = ((o[0] << 24) | (o[1] << 16) | (o[2] << 8) | o[3])
        last = start | ((1 << (32 - pref)) - 1)
        # Пересечение диапазонов: даже частичное попадание в
        # зарезервированную сеть отбрасывается — как в shell.
        if value <= last and start <= end:
            return False
    return True


def _validate_entry(ce):
    if '/' in ce:
        if not _validate_cidr(ce):
            return None
        return ('cidr', ce) if _is_public_v4(ce) else None
    if _validate_ip(ce):
        return ('ip', ce) if _is_public_v4(ce) else None
    if re.fullmatch(r'[0-9.]+', ce):
        return None
    # dns4.2.37 L-7: панель снимает ведущие точки (кроме маски «*.» — она
    # обрабатывается ниже). До dns4.2.41 shell-исполнитель такие записи
    # молча отбрасывал; с раунда 4 (L-9) normalize_domain_target в
    # unblock_ipset.sh снимает ведущие точки так же, как панель и
    # unblock_dnsmasq.sh — все три слоя согласованы.
    # Кириллические IDN по-прежнему отклоняются с обеих сторон:
    # поддерживается только ASCII (punycode не выполняется нигде).
    if ce.startswith('.') and not ce.startswith('*.'):
        ce = ce.lstrip('.')
        if not ce:
            return None
    host = ce[2:] if ce.startswith('*.') else ce
    if not host or len(host) > 253:
        return None
    labels = host.split('.')
    # Фактический исполнитель списка — shell-валидатор (is_domain_core в
    # unblock_ipset.sh:351, такой же в unblock_dnsmasq.sh:891): минимум
    # две метки и TLD не полностью числовой. Однословная запись (youtube)
    # или «домен» с цифровым TLD раньше молча игнорировались при резолве.
    if len(labels) < 2:
        return None
    if labels[-1].isdigit():
        return None
    if all(1 <= len(label) <= 63 and re.fullmatch(
            r'[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?', label)
           for label in labels):
        return ('domain', ce)
    return None


# ─────────────────────────────────────────────────────────────────────
# M-7 остаток (раунд 4): операционные функции панели, которые НЕ
# используют Flask, перенесены из generator.py сюда — импорт генератора
# из handlers больше не тянет Flask-экосистему в процесс телеграм-бота.
# Панель реэкспортирует имена; поведение и файловые локеры не меняются.
# ─────────────────────────────────────────────────────────────────────
import logging
import shlex
import threading
# 4.2.73 №5 (технический отчёт): «contextmanager» повторно не
# импортируется — он уже взят в начале этой секции; прочие точечные
# импорты блока намеренные (см. комментарий выше).
from functools import wraps

_M7_GS = getattr(config, 'generator_settings', {})

UNBLOCK_TIMEOUT = int(_M7_GS.get('unblock_timeout', 300))
UNBLOCK_DIR = config.paths.get(
    'unblock_dir', '/opt/etc/unblock').rstrip('/')
LOCK_DIR = _M7_GS.get(
    'lock_dir', '/tmp/unblock_update.lockdir')
# dns4.2.50 N-24 (аудит раунда 11): наборы отложенных правок списков —
# их подбирает хвост текущей транзакции (см. unblock_update.sh).
PENDING_SETS_FILE = LOCK_DIR + '.pending_sets'
UPDATE_STATUS_FILE = _M7_GS.get(
    'status_file', '/tmp/unblock_update_status.json')
UPDATE_LOG_FILE = _M7_GS.get(
    'update_log', '/tmp/unblock_update.log')
PROTO_UPD_STATUS = (
    '/tmp/proto_update_status.json')
PROTO_UPD_LOG = (
    '/tmp/proto_update.log')
# Обновление всех компонентов может занимать минуты; после этого срока
# зависший запуск считается мёртвым и разрешается новый.
PROTO_UPD_TIMEOUT = 900
UNBLOCK_LAUNCH_LOCK = LOCK_DIR + '.launcher.lockdir'
PROTO_LAUNCH_LOCK = '/tmp/proto_update.launch.lockdir'
UPDATES_CHECK_LOCK = '/tmp/keenzoo_updates_check.lockdir'
BYPASS_FILES = {
    key: path
    for key, path in config.list_files.items()
    if key != 'bot'
}
MAX_LIST_LINES = int(_M7_GS.get('max_list_lines', 5000))
_update_thread_lock = threading.RLock()
_update_depth = threading.local()
VERSIONS_REFRESH_STATUS = '/tmp/keenzoo_versions_refresh.json'


def _run_command(args, timeout=30, env=None, check=False, label='command',
                 expected_rcs=(0,)):
    """Run a bounded command with one error/reporting policy.

    The wrapper deliberately keeps argv execution (no shell=True), truncates
    captured diagnostics for flash-backed logs, and turns timeout/OS errors
    into a normal CompletedProcess-like result unless the caller requests
    ``check``. This keeps BusyBox/Entware failures visible without allowing a
    hung child to hang the web worker forever.

    ``expected_rcs`` lists return codes that are a normal semantic answer,
    not an error (e.g. rc=1 for iptables -D/-C when a rule is absent).
    Such codes are not logged and never raise under ``check``; only codes
    OUTSIDE the list are treated as failures.
    """
    try:
        # Spool stdout/stderr rather than holding arbitrarily large command
        # output in Python RAM. Only bounded diagnostics/data are read back.
        with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
            proc = subprocess.Popen(list(args), stdout=out, stderr=err,
                                    stdin=subprocess.DEVNULL, env=env,
                                    start_new_session=True)
            timed_out = False
            try:
                proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                # Give ash EXIT traps a chance to restore state; then ensure
                # grandchildren cannot continue modifying rules after rollback.
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                proc.wait()
            size = out.tell()
            out.seek(0)
            stdout = out.read(1024 * 1024).decode('utf-8', 'replace') if size <= 1024 * 1024 else ''
            err.seek(max(0, err.tell() - 4000))
            stderr = err.read(4000).decode('utf-8', 'replace')
            rc = proc.returncode
            if timed_out:
                rc, stderr = 124, 'timeout'
            elif size > 1024 * 1024:
                rc, stderr = 125, 'command output exceeds 1 MiB'
            result = subprocess.CompletedProcess(args, rc, stdout, stderr)
    except OSError as err:
        log_error(f'[!] {label}: {err}')
        result = subprocess.CompletedProcess(
            args=args, returncode=127, stdout='', stderr=str(err))

    result.stdout = result.stdout or ''
    if len(result.stdout) > 1024 * 1024:
        result.stdout = ''
        result.stderr = 'command output exceeds 1 MiB'
        result.returncode = 125
    result.stderr = (result.stderr or '')[-4000:]
    if result.returncode not in expected_rcs:
        detail = (result.stderr or result.stdout).strip()[-400:]
        log_error(
            f'[!] {label}: rc={result.returncode}'
            f'{": " + detail if detail else ""}')
        if check:
            raise RuntimeError(
                f'{label}: rc={result.returncode}'
                f'{": " + detail if detail else ""}')
    return result


def _pid_start_time(pid):
    try:
        with open(f'/proc/{int(pid)}/stat', 'r') as f:
            fields = f.read().split()
        return fields[21] if len(fields) > 21 else ''
    except (OSError, ValueError):
        return ''


def _lock_is_live(path):
    try:
        with open(os.path.join(path, 'pid'), 'r') as f:
            pid = int(f.read().strip())
        with open(os.path.join(path, 'start'), 'r') as f:
            saved = f.read().strip()
    except (OSError, ValueError):
        try:
            # os.mkdir is the atomic operation; pid/start are written just
            # after it. Do not let a concurrent caller remove that fresh
            # directory during the small metadata-write window.
            return time.time() - os.stat(path).st_mtime < 10
        except OSError:
            return False
    return bool(saved and _pid_start_time(pid) == saved)


def _acquire_launcher_lock(path):
    """Atomic launcher gate; status JSON alone is not a mutex."""
    for _ in range(2):
        try:
            os.mkdir(path)
        except FileExistsError:
            if _lock_is_live(path):
                return False
            # РАУД 39 (повторный аудит, R38-LOCK-02): двойная сверка
            # маркера перед очисткой устаревшего лока — не удалять,
            # если между проверками появился новый владелец.
            marker1 = _lock_marker(path)
            if _lock_is_live(path):
                return False
            if _lock_marker(path) != marker1:
                continue
            shutil.rmtree(path, ignore_errors=True)
            continue
        except OSError:
            return False
        try:
            with open(os.path.join(path, 'pid'), 'w') as f:
                f.write(str(os.getpid()))
            start = _pid_start_time(os.getpid())
            with open(os.path.join(path, 'start'), 'w') as f:
                f.write(start)
            return True
        except OSError:
            shutil.rmtree(path, ignore_errors=True)
            return False
    return False


def _lock_marker(path):
    """Слепок метаданных владельца лока (для двойной сверки)."""
    parts = []
    for name in ('pid', 'start'):
        try:
            with open(os.path.join(path, name), encoding='utf-8') as f:
                parts.append(f.read().strip())
        except OSError:
            parts.append('')
    return ';'.join(parts)


def _release_launcher_lock(path):
    # РАУД 39 (повторный аудит, R38-LOCK-02): снимать только свой лок —
    # сверка владельца по «pid» перед удалением.
    try:
        with open(os.path.join(path, 'pid'), encoding='utf-8') as f:
            owner = f.read().strip()
    except OSError:
        owner = ''
    if owner == str(os.getpid()):
        shutil.rmtree(path, ignore_errors=True)


@contextmanager
def shared_update_lock():
    if not _update_thread_lock.acquire(blocking=False):
        raise RuntimeError('Изменение уже выполняется; повторите позже')
    owner = False
    try:
        depth = getattr(_update_depth, 'value', 0)
        if not depth:
            if not _acquire_launcher_lock(LOCK_DIR):
                raise RuntimeError('DNS/ipset/netfilter заняты; повторите позже')
            owner = True
        _update_depth.value = depth + 1
        try:
            yield
        finally:
            _update_depth.value = depth
    finally:
        if owner:
            _release_launcher_lock(LOCK_DIR)
        _update_thread_lock.release()


def with_update_lock(func):
    @wraps(func)
    def wrapped(*args, **kwargs):
        with shared_update_lock():
            return func(*args, **kwargs)
    return wrapped


def _write_update_status(
        status, message=''):
    try:
        data = {
            'status': status,
            'ts': int(time.time()),
            'message': message}
        # dns4.2.36 (аудит, KZ-07): непредсказуемое временное имя;
        # переименование атомарно и не следует по чужому симлинку.
        fd, tmp = tempfile.mkstemp(
            prefix='.unblock_update_status.', dir='/tmp')
        with os.fdopen(fd, 'w') as f:
            json.dump(data, f)
        os.rename(tmp, UPDATE_STATUS_FILE)
    except Exception:
        pass


def _read_update_status():
    if not os.path.exists(
            UPDATE_STATUS_FILE):
        return {
            'status': 'idle',
            'ts': 0, 'message': ''}
    try:
        with open(
                UPDATE_STATUS_FILE, 'r') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return {
                'status': 'idle',
                'ts': 0, 'message': ''}
        return data
    except (json.JSONDecodeError,
            IOError, ValueError):
        return {
            'status': 'idle',
            'ts': 0, 'message': ''}


def _build_wrapper(sp, only_sets='', launcher_lock=''):
    # only_sets — частичное обновление: обрабатывается лишь указанный
    # набор ipset. Правка одной записи в списке раньше запускала полный
    # цикл по всем доменам всех протоколов (сотни DNS-запросов).
    lines = [
        '#!/bin/sh',
        'export PATH=/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin',]
    if launcher_lock:
        lines += [
            'LAUNCH_LOCK=' + shlex.quote(launcher_lock),
            "trap 'rm -rf \"$LAUNCH_LOCK\" 2>/dev/null || true' EXIT INT TERM HUP",
            'printf \'%s\\n\' "$$" > "$LAUNCH_LOCK/pid"',
            'awk \'{print $22}\' "/proc/$$/stat" 2>/dev/null > "$LAUNCH_LOCK/start" || true',
        ]
    if only_sets:
        # shlex.quote защищает от подстановки: имя набора приходит из
        # таблицы BYPASS_FILES, но экранирование дешевле доверия.
        lines.append('export ONLY_SETS=' + shlex.quote(only_sets))
        # Частичное обновление запускается только по правке списка
        # (панель/бот): набора ЗАМЕНЯЮТСЯ новым содержимым, без merge
        # со старым, чтобы удалённые записи сразу уходили из ipset.
        # Плановые крон/WAN-прогоны REPLACE_SETS не получают и
        # сохраняют merge-защиту от «плохого» резолва.
        lines.append('export REPLACE_SETS=1')
    lines += [
        'STATUS_FILE="' + UPDATE_STATUS_FILE + '"',
        'TMP_STATUS="' + UPDATE_STATUS_FILE + '.wtmp"',
        'LOG_FILE="' + UPDATE_LOG_FILE + '"',
        # Баг 7 фикс: путь подставляется через shlex.quote — как уже
        # делается для LAUNCH_LOCK/ONLY_SETS выше. Путь пока внутренняя
        # константа, но экранирование дешевле доверия к источнику.
        'SCRIPT=' + shlex.quote(sp),
        '',
        '# Lock и основной статус обслуживает SCRIPT.',
        '"$SCRIPT" >"$LOG_FILE" 2>&1',
        'RC=$?',
        '',
        '# Резервный статус только если SCRIPT не успел',
        '# записать собственный done/error.',
        'NEED_FALLBACK=0',
        '[ -f "$STATUS_FILE" ] || NEED_FALLBACK=1',
        'if [ -f "$STATUS_FILE" ]; then',
        '    grep -Eq '
        '\'"status"[[:space:]]*:[[:space:]]*"running"\' '
        '"$STATUS_FILE" && NEED_FALLBACK=1',
        'fi',
        '',
        'if [ "$NEED_FALLBACK" -eq 1 ]; then',
        '    TS=$(date +%s)',
                '    if [ "$RC" -eq 0 ]; then',
        '        printf '
        '\'{"status":"done","ts":%s,'
        '"message":"ok"}\n\' '
        '"$TS" > "$TMP_STATUS"',
        '    elif [ "$RC" -eq 75 ]; then',
        '        # РАУД 39 (повторный аудит, R38-STATUS-01): 75 — отложено.',
        '        printf '
        '\'{"status":"deferred","ts":%s,'
        '"message":"deferred (exit code 75)"}\n\' '
        '"$TS" > "$TMP_STATUS"',
        '    else',
        '        printf '
        '\'{"status":"error","ts":%s,'
        '"message":"exit code %s"}\n\' '
        '"$TS" "$RC" > "$TMP_STATUS"',
        '    fi',
        '    mv -f "$TMP_STATUS" "$STATUS_FILE"',
        'fi',
        '',
        '# dns4.2.36 (аудит, KZ-07): враппер одноразовый — имя было',
        '# непредсказуемым, файл удаляем за собой.',
        'rm -f "$0"',
        'exit "$RC"',
    ]
    return '\n'.join(lines) + '\n'


def apply_unblock_async(only_sets=''):
    sc = '/opt/bin/unblock_update.sh'
    if not os.path.exists(sc):
        raise FileNotFoundError(sc)
    os.chmod(sc, 0o755)
    st = _read_update_status()
    if st.get('status') == 'running':
        age = time.time() - st.get('ts', 0)
        if age < UNBLOCK_TIMEOUT and _lock_is_live(UNBLOCK_LAUNCH_LOCK):
            raise RuntimeError(
                f"Уже ({int(age)}с).")
        if age < UNBLOCK_TIMEOUT:
            raise RuntimeError('Операция уже запускается')

    if not _acquire_launcher_lock(UNBLOCK_LAUNCH_LOCK):
        raise RuntimeError('Обновление уже запускается')
    try:
        _write_update_status('running', 'starting')
        # dns4.2.36 (аудит, KZ-07): фиксированное имя в /tmp могло быть
        # заранее подменено локальным процессом; создаём эксклюзивно и
        # враппер сам удаляет себя в конце.
        _wr_fd, _wr_path = tempfile.mkstemp(
            prefix='kz_unblock_wrapper.', suffix='.sh', dir='/tmp')
        with os.fdopen(_wr_fd, 'w') as f:
            f.write(_build_wrapper(
                sc, only_sets, UNBLOCK_LAUNCH_LOCK))
        os.chmod(_wr_path, 0o700)
        subprocess.Popen(
            ['/bin/sh', _wr_path],
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL)
    except Exception:
        _release_launcher_lock(UNBLOCK_LAUNCH_LOCK)
        raise


def _rejection_reason(ce):
    # dns4.2.24 (аудит A6 N3): панель с dns4.2.23 отклоняет приватные и
    # зарезервированные адреса ДО записи в файл (иначе счётчик «принято»
    # расходился с фактически применённым), но голое «⚠️» не объясняло
    # причину. Отличаем непубличный, но синтаксически корректный адрес
    # от синтаксической ошибки — только для текста ошибки, логика
    # отбора не меняется.
    if '/' in ce:
        if _validate_cidr(ce) and not _is_public_v4(ce):
            return 'приватная/зарезервированная сеть, в обход не попадает'
    elif _validate_ip(ce) and not _is_public_v4(ce):
        return 'приватный/зарезервированный адрес, в обход не попадает'
    return ''


def _atomic_write_text(filepath, text):
    directory = os.path.dirname(filepath)
    os.makedirs(directory, exist_ok=True)
    mode = 0o644
    try:
        mode = os.stat(filepath).st_mode & 0o777
    except FileNotFoundError:
        pass
    fd, tmp = tempfile.mkstemp(prefix='.' + os.path.basename(filepath) + '.',
                               suffix='.tmp', dir=directory)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            os.fchmod(f.fileno(), mode)
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, filepath)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def _read_blocks(fp):
    if not os.path.exists(fp):
        return []
    secs = []
    cc = None
    ce = []
    with open(fp, 'r',
              encoding='utf-8') as f:
        for raw in f:
            s = (raw.rstrip('\n')
                 .rstrip('\r').strip())
            if not s:
                # См. parse_and_save: именованная секция без записей —
                # пользовательская аннотация, а не мусор.
                if ce or cc:
                    secs.append((cc, ce))
                    cc = None
                    ce = []
                continue
            if s.startswith('#'):
                if ce or cc:
                    secs.append((cc, ce))
                    ce = []
                cc = s[1:].strip()
            else:
                ce.append(s)
    if ce or cc:
        secs.append((cc, ce))
    return secs


def _all_bypass_filepaths():
    fps = list(BYPASS_FILES.values())
    try:
        for n in os.listdir(UNBLOCK_DIR):
            if (n.startswith('vpn-')
                    and n.endswith('.txt')):
                fps.append(os.path.join(
                    UNBLOCK_DIR, n))
    except Exception:
        pass
    return fps


def _build_global_bypass_index(
        exclude_filepath=None):
    gm = {}
    for fp in _all_bypass_filepaths():
        if (exclude_filepath
                and os.path.realpath(fp)
                == os.path.realpath(
                    exclude_filepath)):
            continue
        fl = os.path.splitext(
            os.path.basename(fp))[0]
        for comment, entries in (
                _read_blocks(fp)):
            for entry in entries:
                c = _clean_entry(entry)
                if c:
                    # Регистронезависимость как у seen-ключей
                    # parse_and_save: KEYWORD.example.com в trojan.txt
                    # должен закрывать keyword.example.com в vless.txt.
                    key = c.lower()
                    if key not in gm:
                        gm[key] = {
                            'file': fl,
                            'comment': comment}
    return gm


def _optimize_networks(sections):
    an = []
    nte = {}
    for _c, entries in sections:
        for entry in entries:
            cl = _clean_entry(entry)
            r = _validate_entry(cl)
            if r and r[0] in ('ip', 'cidr'):
                try:
                    net = ipaddress.ip_network(
                        cl if '/' in cl
                        else cl + '/32',
                        strict=False)
                    if net not in nte:
                        an.append(net)
                        nte[net] = entry
                except ValueError:
                    pass
    if len(an) < 2:
        return sections, []
    # dns4.2.21 (аудит A3 M4): collapse_addresses на тысячах CIDR съедает
    # CPU MIPS-роутера в Flask-воркере. При большом списке свёртку
    # пропускаем целиком: ДАННЫЕ НЕ ОБРЕЗАЮТСЯ, секции возвращаются как
    # есть, а панель показывает отметку. Обрезание списка (вариант
    # внешнего отчёта) сознательно отклонено как потеря данных.
    if len(an) > 2000:
        return sections, [
            ('\U0001f4e6 CIDR: %d адресов — свёртка пропущена (>2000) '
             'для экономии CPU, список сохранён полностью') % len(an)]
    oc = len(nte)
    col = set(
        ipaddress.collapse_addresses(an))
    cc = len(col)
    if cc >= oc:
        return sections, []
    os_set = set(nte.keys())
    surv = os_set & col
    nfm = col - os_set
    del an, os_set
    rt = 0
    ns = []
    bi = 0
    bd = 0
    moves = []
    for idx, (comment, entries) in (
            enumerate(sections)):
        ne = []
        sr = 0
        for entry in entries:
            cl = _clean_entry(entry)
            r = _validate_entry(cl)
            if r and r[0] in ('ip', 'cidr'):
                try:
                    net = ipaddress.ip_network(
                        cl if '/' in cl
                        else cl + '/32',
                        strict=False)
                    if net in surv:
                        ne.append(entry)
                    else:
                        sr += 1
                except ValueError:
                    ne.append(entry)
            else:
                ne.append(entry)
        rt += sr
        ns.append((comment, ne))
        if sr > 0:
            moves.append((comment, sr))
        if sr > bd:
            bd = sr
            bi = idx
    del surv, nte
    if nfm:
        merged = []
        for net in sorted(nfm):
            merged.append(
                str(net.network_address)
                if net.prefixlen == 32
                else str(net))
        if bd > 0:
            c, e = ns[bi]
            ns[bi] = (c, e + merged)
        else:
            ns.append((
                'Оптимизированные', merged))
    rep = []
    saved = oc - cc
    if rt > 0:
        rep.append(
            f"\U0001f4e6 CIDR: "
            f"удалено {rt}")
    # Переносы между секциями показываем явно: пользователь должен
    # видеть, откуда адреса ушли в объединённые сети (заголовок секции
    # при этом остаётся в файле — его сохраняет parse_and_save).
    for moved_from, moved_count in moves[:6]:
        rep.append(
            f"\U0001f4e6 {moved_count} адрес. из "
            + (f"«{moved_from}»"
               if moved_from
               else 'блока без названия')
            + ' объединены в общие сети')
    if nfm:
        rep.append(
            f"\U0001f4e6 CIDR: "
            f"создано {len(nfm)}")
    if saved > 0:
        rep.append(
            f"\U0001f4e6 {oc}"
            f"\u2192{cc} "
            f"(\u2248"
            f"{saved*100//oc}%)")
    return ns, rep


def _sort_key(entry):
    cl = _clean_entry(entry)
    try:
        net = ipaddress.ip_network(
            cl, strict=False)
        return (
            1,
            net.network_address.packed,
            net.prefixlen)
    except ValueError:
        pass
    try:
        addr = ipaddress.ip_address(cl)
        return (1, addr.packed, 32)
    except ValueError:
        pass
    return (0, cl.lower().encode(), 0)

def _parse_and_save_core(
        filepath, text,
        skip_global_dedup):
    rb = os.path.realpath(UNBLOCK_DIR)
    rp = os.path.realpath(filepath)
    if not rp.startswith(rb + os.sep):
        raise ValueError("Путь")
    lines = text.split('\n')
    if len(lines) > MAX_LIST_LINES:
        raise ValueError(
            f"Строк: {len(lines)}")
    os.makedirs(UNBLOCK_DIR, exist_ok=True)
    secs = []
    cc = None
    ce = []
    errors = []
    dups = []
    seen = {}
    gs = (
        {} if skip_global_dedup
        else _build_global_bypass_index(
            exclude_filepath=filepath))
    for line in lines:
        s = line.strip()
        if not s:
            # Пустой блок закрываем независимо от числа записей: заголовок
            # «осиротевшей» секции (все её адреса ушла CIDR-оптимизация)
            # обязан пережить пересохранение, иначе теряется аннотация.
            if ce or cc:
                secs.append((cc, ce))
                cc = None
                ce = []
            continue
        if s.startswith('#'):
            if ce or cc:
                secs.append((cc, ce))
                ce = []
            cc = s[1:].strip()
        else:
            cl = _clean_entry(s)
            if not cl:
                continue
            r = _validate_entry(cl)
            if r is None:
                # dns4.2.24 (A6 N3): подпись причины отклонения.
                _why = _rejection_reason(cl)
                errors.append(
                    f"\u26a0\ufe0f {cl}"
                    + (f" — {_why}" if _why else ""))
                continue
            key = cl.lower()
            if key in seen:
                c = seen[key]
                dups.append(
                    f"\u26a0\ufe0f {cl}"
                    + (f" (#{c})"
                       if c else ""))
                continue
            if key in gs:
                info = gs[key]
                dups.append(
                    f"\u26a0\ufe0f {cl}"
                    f" ({info['file']}.txt"
                    + (f", #{info['comment']}"
                       if info['comment']
                       else "")
                    + ")")
                continue
            seen[key] = cc
            if r[0] == 'domain':
                # Регистр доменов значения не имеет, а shell при
                # резолве приводит к нижнему — сохраняем нормализованно,
                # чтобы дедупликация не зависела от регистра ввода.
                core, _, tail = s.partition('#')
                s = core.strip().lower() + (
                    ' # ' + tail.strip() if tail else '')
            ce.append(s)
    if ce or cc:
        secs.append((cc, ce))
    del seen, gs
    secs, cr = _optimize_networks(secs)
    out = []
    # Порядок секций — пользовательский: сохраняем как введён.
    # Раньше именованные секции пересортировывались по алфавиту при
    # каждом сохранении, что ломало группировку и diff'ы. Сортировкой
    # записей внутри секции (_sort_key) порядок секций не затрагивается.
    cd = ci = cc2 = 0
    first_block = True
    for comment, entries in secs:
        if comment is None and not entries:
            continue
        if not first_block:
            out.append('')
        first_block = False
        if comment is not None:
            # Заголовок секции сохраняем, даже если CIDR-оптимизация
            # увела все её адреса: комментарий — пользовательская
            # аннотация («что это за ресурс и почему он тут»).
            out.append(f'#{comment}')
        for entry in sorted(
                entries, key=_sort_key):
            out.append(entry)
            cl = _clean_entry(entry)
            r = _validate_entry(cl)
            if r:
                if r[0] == 'cidr':
                    cc2 += 1
                elif r[0] == 'ip':
                    ci += 1
                else:
                    cd += 1
    _atomic_write_text(
        filepath,
        '\n'.join(out) + '\n'
        if out else '')
    return {
        'total': cd + ci + cc2,
        'domains': cd, 'ips': ci,
        'cidr': cc2, 'errors': errors,
        'duplicates': dups,
        'cidr_report': cr,
    }


def parse_and_save(
        filepath, text,
        skip_global_dedup=False):
    # dns4.2.49 И-26 (отчёт раунда 9): при занятом замке обновлений
    # правка списка раньше отклонялась и терялась. Файл пишется
    # атомарно и сам по себе ничего не применяет (транзакция читает
    # списки сама), поэтому при занятом замке сохраняем без замка и
    # помечаем отложенное применение — правка попадёт в следующее
    # обновление. Фатальные ошибки разбора по-прежнему исключаются.
    try:
        with shared_update_lock():
            return _parse_and_save_core(
                filepath, text, skip_global_dedup)
    except RuntimeError:
        result = _parse_and_save_core(
            filepath, text, skip_global_dedup)
        result['deferred'] = True
        # dns4.2.50 N-24 (аудит раунда 11): текущая транзакция могла
        # уже прочитать список — пометим набор, чтобы хвост транзакции
        # запустил для отложенной правки частичный повтор.
        try:
            _pas_key = os.path.basename(filepath)[:-4]
            _pas_set = config.ipset_names.get(_pas_key, '')
            if _pas_set:
                with open(PENDING_SETS_FILE, 'a',
                          encoding='utf-8') as fh:
                    fh.write(_pas_set + '\n')
        except (OSError, AttributeError):
            pass
        return result


def _read_proto_update():
    """Статус фонового обновления протоколов."""
    try:
        with open(PROTO_UPD_STATUS, 'r') as f:
            d = json.load(f)
    except Exception:
        return {'status': 'idle', 'ts': 0,
                'message': '', 'log': ''}
    # Процесс мог быть убит, не успев записать финальный статус.
    if d.get('status') == 'running':
        age = time.time() - d.get('ts', 0)
        if age > PROTO_UPD_TIMEOUT and not _lock_is_live(PROTO_LAUNCH_LOCK):
            d['status'] = 'error'
            d['message'] = 'Таймаут'
    d['log'] = _tail_file(PROTO_UPD_LOG)
    return d


def _tail_file(path, limit=4000):
    try:
        with open(path, 'rb') as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - limit))
            return f.read(limit).decode('utf-8', 'replace')
    except Exception:
        return ''


def start_proto_update(action):
    """Запускает update_protocols.sh в фоне.

    Скрипт работает минутами, поэтому HTTP-запрос его не ждёт:
    панель опрашивает /api/proto-update-status.
    """
    if action not in ('xray', 'hysteria', 'github',
                      'opkg', 'all'):
        raise ValueError('action')

    st = _read_proto_update()
    if st.get('status') == 'running':
        age = int(time.time()
                  - st.get('ts', 0))
        if age < PROTO_UPD_TIMEOUT and _lock_is_live(PROTO_LAUNCH_LOCK):
            raise RuntimeError(
                f'Обновление уже идёт ({age}с)')
        # Status can be left at running if the worker was killed. A dead
        # owner is recoverable; the atomic lock is the source of truth.

    sc = config.paths.get(
        'update_protocols',
        '/opt/bin/update_protocols.sh')
    if not os.path.exists(sc):
        raise FileNotFoundError(sc)
    if not _acquire_launcher_lock(PROTO_LAUNCH_LOCK):
        raise RuntimeError('Обновление уже запускается')

    try:
        with open(PROTO_UPD_STATUS, 'w') as f:
            json.dump({
                'status': 'running',
                'ts': int(time.time()),
                'action': action,
                'message': 'Запуск...'}, f)
    except Exception:
        pass

    # Обёртка пишет финальный статус по коду возврата скрипта,
    # а не по наличию значков в выводе.
    lines = [
        '#!/bin/sh',
        'SC=' + shlex.quote(sc),
        'ACT=' + shlex.quote(action),
        'LOG=' + shlex.quote(PROTO_UPD_LOG),
        'ST=' + shlex.quote(PROTO_UPD_STATUS),
        'LAUNCH_LOCK=' + shlex.quote(PROTO_LAUNCH_LOCK),
        "trap 'rm -rf \"$LAUNCH_LOCK\" 2>/dev/null || true' EXIT INT TERM HUP",
        'printf \'%s\\n\' "$$" > "$LAUNCH_LOCK/pid"',
        'awk \'{print $22}\' "/proc/$$/stat" 2>/dev/null > "$LAUNCH_LOCK/start" || true',
        ': > "$LOG"',
        '"$SC" "$ACT" >> "$LOG" 2>&1',
                'RC=$?',
        'TS=$(date +%s)',
        '# РАУД 39 (повторный аудит, R38-STATUS-01): код 75 — это',
        '# «отложено» (блокировки заняты), а не авария: отдельный',
        '# статус, причина и владелец глобального лока.',
        'GL="${GLOBAL_LIFECYCLE_LOCK_DIR:-/tmp/unblock_update.lockdir}"',
        'LO="$(cat "$GL/pid" 2>/dev/null || true)"',
        'if [ "$RC" -eq 0 ]; then',
        '    S=done; M="Готово"',
        'elif [ "$RC" -eq 75 ]; then',
        '    S=deferred',
        '    if [ -n "$LO" ]; then',
        '        M="Отложено: блокировки заняты (владелец $LO); повтор будет по расписанию"',
        '    else',
        '        M="Отложено: блокировки заняты; повтор будет по расписанию"',
        '    fi',
        'else',
        '    S=error; M="Код возврата $RC"',
        'fi',
        'TMP="$ST.tmp"',
        'printf \'{"status":"%s","ts":%s,'
        '"action":"%s","rc":%s,"lock_owner":"%s","message":"%s"}\\n\' '
        '"$S" "$TS" "$ACT" "$RC" "$LO" "$M" > "$TMP"',
        'mv -f "$TMP" "$ST"',
        '# dns4.2.36 (аудит, KZ-07): одноразовый враппер.',
        'rm -f "$0"',
        'exit "$RC"',
    ]
    # dns4.2.36 (аудит, KZ-07): эксклюзивное непредсказуемое имя.
    _pw_fd, _pw_path = tempfile.mkstemp(
        prefix='kz_proto_wrapper.', suffix='.sh', dir='/tmp')
    with os.fdopen(_pw_fd, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    os.chmod(_pw_path, 0o700)

    try:
        subprocess.Popen(
            ['/bin/sh', _pw_path],
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL)
    except Exception:
        _release_launcher_lock(PROTO_LAUNCH_LOCK)
        raise


def _start_refresh_job(script, lock, status_file, env=None, timeout=600):
    if not os.path.isfile(script) or not os.access(script, os.X_OK):
        raise FileNotFoundError(script)
    if not _acquire_launcher_lock(lock):
        return False

    def save(status, message='', rc=0):
        _atomic_write_text(status_file, json.dumps({
            'status': status, 'message': message, 'rc': rc,
            'ts': int(time.time())}, ensure_ascii=False))

    def worker():
        try:
            result = _run_command([script], timeout=timeout, env=env,
                                  label='background check')
            messages = {75: 'Другая операция заняла блокировку; повторите позже',
                        124: 'Превышено время проверки; проверьте DNS и WAN'}
            message = messages.get(result.returncode,
                                   'Проверка завершилась ошибкой; см. журнал DNS/обновлений')
            save('done' if result.returncode == 0 else 'error',
                 '' if result.returncode == 0 else message, result.returncode)
        except Exception:
            logging.exception('background check failed')
            try:
                save('error', 'Ошибка фоновой проверки', 1)
            except OSError:
                pass
        finally:
            _release_launcher_lock(lock)

    try:
        save('running')
        threading.Thread(target=worker, daemon=True, name='keenzoo-check').start()
    except Exception:
        _release_launcher_lock(lock)
        raise
    return True


def _start_updates_check_async(script):
    return _start_refresh_job(script, UPDATES_CHECK_LOCK,
                              VERSIONS_REFRESH_STATUS, timeout=240)
