#!/bin/sh
# remove keeps data but disables cron/NDM reactivation until next install.
if [ -f /opt/etc/unblock/.disabled ] && [ "${PURGE_PROJECT:-0}" != 1 ]; then
    exit 0
fi
# /opt/etc/ndm/netfilter.d/100-redirect.sh
# Перехват трафика для списков обхода.
#   TCP  -> nat/REDIRECT на локальные порты прокси.
#   UDP  -> mangle/TPROXY (vless, hysteria) либо nat/REDIRECT (shadowsocks).
# Оболочка: BusyBox ash (#!/bin/sh), без bash-измов.
#
# Контракт кодов возврата (аудит раунда 23, v21 М-5):
#   0  — правила применены полностью;
#   4  — применено С ДЕГРАДАЦИЕЙ: в /opt/etc/unblock/.tproxy_state есть
#        строка «fail» (чужой ресурс, отвергнутое правило, отсутствие
#        маркера владельца). Перехват работает частично; причина — в
#        последнем поле строки «fail». НЕ является полным отказом.
#   75 — общий замок занят другой транзакцией; повтор поставлен;
#   1  — авария, применённое откатывается снапшотом.

set -eu
DNS_POLICY_V4=1

PATH="/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

# dns4.2.23 (аудит A5 #3): единый список локальных/служебных сетей для
# RETURN/ACCEPT-правил этого файла. Раньше список копипастился в пяти
# местах, причём без link-local (169.254/16) и CGNAT (100.64/10 —
# частый адрес мобильного WAN на Keenetic): обращение роутера к таким
# адресам уходило бы в REDIRECT/TPROXY и получало петлю или чёрную дыру.
# Состав согласован с public-фильтрами is_public_* (unblock_ipset.sh,
# unblock_dnsmasq.sh) — править синхронно.
LOCAL_NETS="127.0.0.0/8 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 169.254.0.0/16 100.64.0.0/10"

config_number() {
    # Раунд 7, N-16: в ветке двойных кавычек одинарные кавычки оболочки
    # не гасят обратные слеши — до седа они дошли литералами, группа не
    # образовалась, и значения вида `web_port = "8081"` молча заменялись
    # умолчанием. Ветке двойных кавычек нужны одинарные `\(`/`\)`/`\1`.
    _cn_key="$1"
    _cn_default="$2"
    _cn_value="$(sed -n \
        -e "s/^[[:space:]]*${_cn_key}[[:space:]]*=[[:space:]]*'\\([0-9][0-9]*\\)'.*$/\\1/p" \
        -e 's/^[[:space:]]*'"${_cn_key}"'[[:space:]]*=[[:space:]]*"\([0-9][0-9]*\)".*/\1/p' \
        -e "s/^[[:space:]]*${_cn_key}[[:space:]]*=[[:space:]]*\\([0-9][0-9]*\\).*$/\\1/p" \
        /opt/etc/bot/bot_config.py 2>/dev/null)"
    # Раунд 7, П-19: первая строка — подстановкой (командная подстановка
    # уже сняла хвостовые переводы; обрезка по первому встроенному).
    _cn_value="${_cn_value%%
*}"
    case "$_cn_value" in ''|*[!0-9]*) _cn_value="$_cn_default" ;; esac
    printf '%s\n' "$_cn_value"
}


# dns4.2.20: TUNNEL_PROTOCOL_PRIORITY удалён — выбор транспорта давно
# принадлежит DNS-слою (unblock_dnsmasq/utils), здесь значение не
# читалось (замечание аудита A2, SC2034).

config_string() {
    _cs_key="$1"
    _cs_default="$2"
    _cs_value="$(sed -n \
        -e "s/^[[:space:]]*${_cs_key}[[:space:]]*=[[:space:]]*'\\([^']*\\)'.*$/\\1/p" \
        -e 's/^[[:space:]]*'"${_cs_key}"'[[:space:]]*=[[:space:]]*"\([^"\\]*\)".*/\1/p' \
        /opt/etc/bot/bot_config.py 2>/dev/null)"
    # Раунд 7, П-19: первая строка — подстановкой вместо форка head.
    _cs_value="${_cs_value%%
*}"
    [ -n "$_cs_value" ] || _cs_value="$_cs_default"
    printf '%s\n' "$_cs_value"
}

# ─────────────────────────────────────────────────────────────────────
# IPv6: закрыть прокси-порты от внешней сети.
# ─────────────────────────────────────────────────────────────────────
# Перехват трафика (REDIRECT/TPROXY) реализован только для IPv4, но
# xray (Go) на "listen": "0.0.0.0" может создать dual-stack сокет. Если
# IPv6 случайно включили, прокси-порты не должны становиться доступными из
# LAN/WAN IPv6: эти правила закрывают их полностью, кроме loopback.
# Это только защита локальных портов; полноценный IPv4-only режим обязан
# дополнительно отключать IPv6 в KeeneticOS, а deploy проверяет это заранее.
if [ "${type:-}" = "ip6tables" ]; then
    [ "${table:-}" = "filter" ] || exit 0

    IPT6="$(command -v ip6tables 2>/dev/null || true)"
    [ -n "$IPT6" ] || exit 0
    IPT6="$IPT6 -w"

    # dns4.2.35 (ре-аудит, R-11): проектные правила удаляются ВСЕГДА
    # (старые варианты не должны опережать новые), а при удалении
    # проекта на этом работа заканчивается — ДО установки новых
    # правил. Раньше проверка шла после установки, и -remove
    # оставлял свежие IPv6 DROP-правила на уже несуществующие сервисы.
    # dns4.2.49 L-4 (остаток раундов 1-2): вместо циклов «пробуй -D до
    # отказа» на каждый порт/протокол/вариант — один дамп -S и один
    # проход awk: снимаются только реально присутствующие правила
    # проектных форм, форков на порядок меньше.
    ip6_drop_project_rules() {
        _ip6d_ports=""
        for p6 in "$(config_number localportsh 1082)" "$(config_number localporttor 9141)" \
            "$(config_number localportvless 10810)" "$(config_number localporttrojan 10829)" \
            "$(config_number localporthysteria 10830)" "$(config_number web_port 8080)"; do
            _ip6d_ports="${_ip6d_ports}${_ip6d_ports:+ }$p6"
        done
        $IPT6 -S INPUT 2>/dev/null | awk \
            -v ports="$_ip6d_ports" '
            BEGIN {
                np = split(ports, pp, " ")
                for (i = 1; i <= np; i++) portok[pp[i]] = 1
            }
            $1 == "-A" && $2 == "INPUT" {
                proto = ""; dport = ""; src = ""; ifc = ""; tgt = ""
                for (i = 3; i <= NF; i++) {
                    if ($i == "-p") proto = $(i + 1)
                    else if ($i == "--dport") dport = $(i + 1)
                    else if ($i == "-s") src = $(i + 1)
                    else if ($i == "-i") ifc = $(i + 1)
                    else if ($i == "-j") tgt = $(i + 1)
                }
                if (!(dport in portok)) next
                if (proto != "tcp" && proto != "udp") next
                if (tgt == "DROP" && src == "" && ifc == "")
                    print proto, dport, "drop"
                else if (tgt == "ACCEPT" && ifc == "lo" && src == "")
                    print proto, dport, "lo"
                else if (tgt == "ACCEPT" && ifc == "" \
                    && (src == "fc00::/7" || src == "fe80::/10" \
                        || src == "::1/128"))
                    print proto, dport, "src", src
            }' \
            | while read -r _ip6d_proto _ip6d_port _ip6d_kind _ip6d_src; do
                case "$_ip6d_kind" in
                    drop)
                        while $IPT6 -D INPUT -p "$_ip6d_proto" \
                            --dport "$_ip6d_port" -j DROP \
                            >/dev/null 2>&1; do :; done ;;
                    lo)
                        while $IPT6 -D INPUT -i lo -p "$_ip6d_proto" \
                            --dport "$_ip6d_port" -j ACCEPT \
                            >/dev/null 2>&1; do :; done ;;
                    src)
                        while $IPT6 -D INPUT -p "$_ip6d_proto" \
                            --dport "$_ip6d_port" -s "$_ip6d_src" \
                            -j ACCEPT >/dev/null 2>&1; do :; done ;;
                esac
            done
    }
    ip6_drop_project_rules
    if [ "${PURGE_PROJECT:-0}" = "1" ]; then
        exit 0
    fi

    for p6 in "$(config_number localportsh 1082)" "$(config_number localporttor 9141)" \
        "$(config_number localportvless 10810)" "$(config_number localporttrojan 10829)" \
        "$(config_number localporthysteria 10830)" "$(config_number web_port 8080)"; do
        for pr6 in tcp udp; do
            # Сначала loopback, затем DROP для любого прочего IPv6.
            $IPT6 -I INPUT 1 -p "$pr6" --dport "$p6" \
                -j DROP >/dev/null 2>&1 || { printf "%s\n" "IPv6 proxy DROP failed: $p6/$pr6" >&2; exit 1; }
            $IPT6 -I INPUT 1 -i lo -p "$pr6" --dport "$p6" \
                -j ACCEPT >/dev/null 2>&1 || { printf "%s\n" "IPv6 loopback ACCEPT failed: $p6/$pr6" >&2; exit 1; }
        done
    done
    exit 0
fi

# Idempotent full removal path. It deliberately runs before the normal
# service-state reconciliation and therefore does not depend on a service
# still being enabled or alive. No new daemon/state file is introduced.
purge_project_netfilter() {

    # dns4.2.35 (ре-аудит, R-03): без снятия цепочки закрытия
    # немаркированного DNS после удаления системный резолвер
    # прошивки получал бы REJECT на собственных восходящих запросах.
    for _pps_chain in KZ_DNS_V4_FILTER KZ_DNS_V4_FILTER_NEW; do
        for _pps_p in tcp udp; do
            while $IPT -D OUTPUT -p "$_pps_p" --dport 53 \
                -j "$_pps_chain" >/dev/null 2>&1; do :; done
        done
        $IPT -F "$_pps_chain" >/dev/null 2>&1 || true
        $IPT -X "$_pps_chain" >/dev/null 2>&1 || true
    done
    while $IPT -t nat -D OUTPUT -j KZ_DNS_V4 >/dev/null 2>&1; do :; done
    $IPT -t nat -F KZ_DNS_V4 >/dev/null 2>&1 || true
    $IPT -t nat -X KZ_DNS_V4 >/dev/null 2>&1 || true
    # dns4.2.57 H-11: снять fail-closed backstop UDP.
    while $IPT -t filter -D FORWARD -j KZ_UDP_FAILCLOSED >/dev/null 2>&1; do :; done
    $IPT -t filter -F KZ_UDP_FAILCLOSED >/dev/null 2>&1 || true
    $IPT -t filter -X KZ_UDP_FAILCLOSED >/dev/null 2>&1 || true
    for _v4_mark in 0x2000101 0x2000102 0x2000103; do
        while $IPT -D OUTPUT -p tcp --dport 53 -m mark --mark "$_v4_mark" -j REJECT >/dev/null 2>&1; do :; done
    done
    for _v4_proto in tcp udp; do
        while $IPT -t nat -D OUTPUT -p "$_v4_proto" --dport 53 -m mark --mark 0x2000104 -j RETURN >/dev/null 2>&1; do :; done
    done
    _pps_sets="unblocksh unblocktor unblockvless unblocktroj unblockhysteria unblockrouter unblockdns"
    _pps_ports="$PORT_SS:$PORT_TOR:$PORT_VLESS:$PORT_TROJAN:$PORT_HYSTERIA"

    # DNS DNAT and client redirects, including rules without -i from older
    # releases. Include the historical interface names even when a device is
    # currently down; otherwise a reboot could leave an orphaned rule behind.
    #
    # dns4.2.40 N-9 (аудит-3): установка ставит правила на ВСЕ текущие
    # внутренние интерфейсы (lan_ifaces находит и не входящие в статический
    # шаблон: nwg3+, br3+, guest*, ovpn*/pptp*/l2tp*-серверы, ra*, wl*),
    # а сюда раньше попадал только шаблон — после -remove на таких
    # интерфейсах оставались сиротские DNAT/REDIRECT :53 и TPROXY.
    # Берём имена прямо из живого дампа правил проекта: это покрывает и
    # устройства, которые уже исчезли/переименованы (правила с -i живут
    # в таблице и после удаления интерфейса). Три дополнительных -S-дампа
    # выполняются только в PURGE-проходе.
    _pps_dump_ifaces="$({ $IPT -t nat -S PREROUTING; \
        $IPT -t mangle -S PREROUTING; $IPT -S INPUT; } 2>/dev/null \
        | grep -E -- "--match-set unblock|--to-ports 53|--dport 53 -j DNAT|--dport ($PORT_WEB|$PORT_SS|$PORT_TOR|$PORT_VLESS|$PORT_TROJAN|$PORT_HYSTERIA)( |\$)" \
        | sed -n 's/.* -i \([^ ]*\) .*/\1/p' | sort -u | tr '\n' ' ')"
    _pps_all_ifaces="$(printf '%s\n' \
        "$LAN_IFACES $LAN_IFACE_PATTERNS $_pps_dump_ifaces" \
        | tr ' ' '\n' | awk 'NF && !seen[$0]++' | tr '\n' ' ')"
    for _pps_if in $_pps_all_ifaces; do
        # dns4.2.37 M-2: установка перехватывает клиентский :53 через
        # `REDIRECT --to-ports 53`, а при недоступном xt_REDIRECT —
        # фолбэком `DNAT --to-destination <IP самого интерфейса>` (он
        # может отличаться от $local_ip). Раньше чистился только DNAT на
        # $local_ip, и после -remove на каждом интерфейсе оставались до
        # двух правил перехвата клиентского DNS.
        _pps_if_ip="$(ip -4 addr show "$_pps_if" 2>/dev/null \
            | awk '/inet /{print $2; exit}' | cut -d/ -f1)"
        for _pps_proto in tcp udp; do
            while $IPT -t nat -D PREROUTING -i "$_pps_if" -p "$_pps_proto" \
                --dport 53 -j DNAT --to-destination "$local_ip" >/dev/null 2>&1; do :; done
            while $IPT -t nat -D PREROUTING -i "$_pps_if" -p "$_pps_proto" \
                --dport 53 -j REDIRECT --to-ports 53 >/dev/null 2>&1; do :; done
            if [ -n "$_pps_if_ip" ] && [ "$_pps_if_ip" != "$local_ip" ]; then
                while $IPT -t nat -D PREROUTING -i "$_pps_if" -p "$_pps_proto" \
                    --dport 53 -j DNAT --to-destination "$_pps_if_ip" \
                    >/dev/null 2>&1; do :; done
            fi
        done
        while $IPT -t nat -D PREROUTING -i "$_pps_if" -p tcp \
            -m set --match-set unblockrouter dst -j REDIRECT \
            --to-port "$PORT_VLESS" >/dev/null 2>&1; do :; done
        for _pps_spec in \
            "tcp unblocksh $PORT_SS" "udp unblocksh $PORT_SS" \
            "tcp unblocktor $PORT_TOR" "tcp unblockvless $PORT_VLESS" \
            "tcp unblocktroj $PORT_TROJAN" "tcp unblockhysteria $PORT_HYSTERIA"; do
            set -- $_pps_spec
            while $IPT -t nat -D PREROUTING -i "$_pps_if" -p "$1" \
                -m set --match-set "$2" dst -j REDIRECT --to-port "$3" \
                >/dev/null 2>&1; do :; done
            while $IPT -t mangle -D PREROUTING -i "$_pps_if" -p udp \
                -m set --match-set "$2" dst -j TPROXY --on-ip 127.0.0.1 \
                --on-port "$3" --tproxy-mark "$TPROXY_MARK/$TPROXY_MASK" \
                >/dev/null 2>&1; do :; done
        done
    done

    for _pps_proto in tcp udp; do
        while $IPT -t nat -D PREROUTING -p "$_pps_proto" --dport 53 \
            -j DNAT --to-destination "$local_ip" >/dev/null 2>&1; do :; done
        # dns4.2.37 M-2: и безынтерфейсная форма клиентского перехвата.
        while $IPT -t nat -D PREROUTING -p "$_pps_proto" --dport 53 \
            -j REDIRECT --to-ports 53 >/dev/null 2>&1; do :; done
    done
    for _pps_spec in \
        "udp unblocktor $PORT_TOR" "udp unblocktroj $PORT_TROJAN" \
        "udp unblockhysteria $PORT_HYSTERIA" "udp unblockvless $PORT_VLESS" \
        "tcp unblocksh $PORT_SS" "udp unblocksh $PORT_SS" \
        "tcp unblocktor $PORT_TOR" "tcp unblockvless $PORT_VLESS" \
        "tcp unblocktroj $PORT_TROJAN" "tcp unblockhysteria $PORT_HYSTERIA"; do
        set -- $_pps_spec
        while $IPT -t nat -D PREROUTING -p "$1" \
            -m set --match-set "$2" dst -j REDIRECT --to-port "$3" \
            >/dev/null 2>&1; do :; done
        while $IPT -t mangle -D PREROUTING -p udp \
            -m set --match-set "$2" dst -j TPROXY --on-ip 127.0.0.1 \
            --on-port "$3" --tproxy-mark "$TPROXY_MARK/$TPROXY_MASK" \
            >/dev/null 2>&1; do :; done
    done

    # Dedicated router chain introduced by the protocol selector.
    while $IPT -t nat -D OUTPUT -p tcp -m set --match-set unblockrouter dst \
        -j KZ_ROUTER >/dev/null 2>&1; do :; done
    if $IPT -t nat -S KZ_ROUTER >/dev/null 2>&1; then
        $IPT -t nat -F KZ_ROUTER >/dev/null 2>&1 || return 1
        $IPT -t nat -X KZ_ROUTER >/dev/null 2>&1 || return 1
    fi
    for _pps_botport in "$PORT_VLESS" "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        while $IPT -t nat -D OUTPUT -p tcp -m set --match-set unblockrouter dst \
            -j REDIRECT --to-port "$_pps_botport" >/dev/null 2>&1; do :; done
    done
    # OUTPUT rules for bot.txt and tunnel-DNS, plus loop/mark exceptions.
    while $IPT -t nat -D OUTPUT -o lo -j RETURN >/dev/null 2>&1; do :; done
    for _pps_net in $LOCAL_NETS; do
        while $IPT -t nat -D OUTPUT -d "$_pps_net" -j RETURN \
            >/dev/null 2>&1; do :; done
    done
    while $IPT -t mangle -D OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; do :; done
    while $IPT -t nat -D OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; do :; done
    for _pps_port in "$PORT_VLESS" "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        for _pps_remote in 443 853; do
            while $IPT -t nat -D OUTPUT -p tcp --dport "$_pps_remote" \
                -m set --match-set unblockdns dst -j REDIRECT \
                --to-port "$_pps_port" >/dev/null 2>&1; do :; done
        done
    done
    while $IPT -t nat -D OUTPUT -p tcp -m set --match-set unblockrouter dst \
        -j REDIRECT --to-port "$PORT_VLESS" >/dev/null 2>&1; do :; done
    for _pps_proto in tcp udp; do
        while $IPT -t nat -D OUTPUT -p "$_pps_proto" \
            -m set --match-set unblockrouter dst -j REDIRECT \
            --to-port "$PORT_VLESS" >/dev/null 2>&1; do :; done
        while $IPT -t nat -D OUTPUT -p "$_pps_proto" \
            -m set --match-set unblockrouter dst -j REDIRECT \
            --to-port "$PORT_SS" >/dev/null 2>&1; do :; done
        while $IPT -t mangle -D OUTPUT -p "$_pps_proto" \
            -m set --match-set unblockrouter dst -j MARK \
            --set-mark "$TPROXY_MARK/$TPROXY_MASK" >/dev/null 2>&1; do :; done
    done
    # dns4.2.49 L-3: снимаем оба варианта (с --transparent и без).
    while $IPT -t mangle -D PREROUTING -p udp -m socket \
        -j MARK --set-mark "$TPROXY_MARK/$TPROXY_MASK" >/dev/null 2>&1; do :; done
    while $IPT -t mangle -D PREROUTING -p udp -m socket --transparent \
        -j MARK --set-mark "$TPROXY_MARK/$TPROXY_MASK" >/dev/null 2>&1; do :; done

    # Remove policy routing created by the UDP client plane.
    # dns4.2.63 Х-04 (аудит раунда 25, RU_R23 H-04): PURGE пользуется
    # той же владельческой функцией, что и обычная вычистка: без
    # действующего маркера точные правило/маршрут могут принадлежать
    # другому приложению и удаляться не должны.
    remove_owned_tproxy_policy
    # dns4.2.64 P1-05 (аудит раунда 26): одноразовый маркер миграции —
    # тоже состояние проекта; ПУРЖ снимает его вместе с остальным.
    rm -f /opt/etc/unblock/.kz_owner_migrated 2>/dev/null || true

    # Filter rules protecting the panel and proxy listeners.
    for _pps_raw in tcp udp; do
        while $IPT -D OUTPUT -d 127.0.0.0/8 -p "$_pps_raw" --dport 53 \
            -j RETURN >/dev/null 2>&1; do :; done
        while $IPT -D OUTPUT -p "$_pps_raw" --dport 53 \
            -j DROP >/dev/null 2>&1; do :; done
    done
    while $IPT -D INPUT -p tcp --dport "$PORT_WEB" -j DROP >/dev/null 2>&1; do :; done
    for _pps_net in $LOCAL_NETS; do
        while $IPT -D INPUT -p tcp --dport "$PORT_WEB" -s "$_pps_net" \
            -j ACCEPT >/dev/null 2>&1; do :; done
    done
    while $IPT -D INPUT -i lo -p tcp --dport "$PORT_WEB" \
        -j ACCEPT >/dev/null 2>&1; do :; done
    for _pps_if in $_pps_all_ifaces; do
        while $IPT -D INPUT -i "$_pps_if" -p tcp --dport "$PORT_WEB" \
            -j ACCEPT >/dev/null 2>&1; do :; done
    done
    for _pps_port in "$PORT_SS" "$PORT_TOR" "$PORT_VLESS" \
        "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        for _pps_proto in tcp udp; do
            while $IPT -D INPUT -p "$_pps_proto" --dport "$_pps_port" \
                -j DROP >/dev/null 2>&1; do :; done
            while $IPT -D INPUT -i lo -p "$_pps_proto" \
                --dport "$_pps_port" -j ACCEPT >/dev/null 2>&1; do :; done
            for _pps_if in $_pps_all_ifaces; do
                while $IPT -D INPUT -i "$_pps_if" -p "$_pps_proto" \
                    --dport "$_pps_port" -j ACCEPT >/dev/null 2>&1; do :; done
            done
        done
    done

    # The rules are gone, so sets can safely be destroyed. Both live and
    # staging names are removed to prevent a later swap from resurrecting it.
    for _pps_set in $_pps_sets; do
        ipset flush "$_pps_set" >/dev/null 2>&1 || true
        ipset destroy "${_pps_set}_new" >/dev/null 2>&1 || true
        ipset destroy "$_pps_set" >/dev/null 2>&1 || true
    done
}

# filter тоже обрабатывается: в нём живут правила доступа к веб-панели.
# 4.2.72 П-2: раннер откреплённого повтора идёт без «table» — ему
# нужно дойти до тела (обработка — после определений функций).
case "${table:-}" in
    mangle|nat|filter) ;;
    *)
        [ "${KEENZOO_EMERGENCY_RETRY_RUNNER:-0}" = "1" ] || exit 0
        ;;
esac

TAG="100-redirect.sh"

# NDM может запускать этот hook одновременно с панелью и WAN-hook.
# Используем тот же atomic mkdir-lock, что и unblock_update.sh; при вызове
# из уже открытой update-транзакции nested lock не берём. Это не daemon и не
# новый постоянный файл — lock живёт только во время применения правил.
NETFILTER_LOCK_DIR="${KEENZOO_LOCK_DIR:-/tmp/unblock_update.lockdir}"
NETFILTER_LOCK_ACQUIRED=0

# РАУД 47 (аудит 4.2.84, №2): поле N «/proc/<pid>/stat» (3 —
# состояние, 22 — время старта) с отсечением «(comm)» по последней
# «)»: имя процесса может содержать пробелы и скобки, чтение по
# номерам полей без отсечения сдвигает поля.
_kz_pid_field() {
    # $1 — pid, $2 — номер поля /proc/<pid>/stat (3=state, 22=starttime).
    # Имя процесса «(comm)» отсекается по последней «)» — устойчиво к
    # пробелам и скобкам в имени. РАУД 48 (аудит раунда 47, №8): один
    # форк — awk сам читает файл.
    awk -v n="$2" '{ sub(/.*\) /, ""); print $(n - 2) }' \
        "/proc/$1/stat" 2>/dev/null
}

netfilter_lock_owner_live() {
    if [ ! -f "$NETFILTER_LOCK_DIR/pid" ]; then
        _nfl_mtime="$(stat -c %Y "$NETFILTER_LOCK_DIR" 2>/dev/null || echo 0)"
        _nfl_now="$(date +%s 2>/dev/null || echo 0)"
        case "$_nfl_mtime:$_nfl_now" in
            *[!0-9:]*|0:*) return 1 ;;
        esac
        # РАУД 48 (аудит раунда 47, №12): откат часов не «свежий» лок.
        [ $((_nfl_now - _nfl_mtime)) -ge 0 ] \
            && [ $((_nfl_now - _nfl_mtime)) -lt 10 ] && return 0
        return 1
    fi
    _nfl_pid="$(cat "$NETFILTER_LOCK_DIR/pid" 2>/dev/null || true)"
    _nfl_saved="$(cat "$NETFILTER_LOCK_DIR/start" 2>/dev/null || true)"
    case "$_nfl_pid" in
    *[!0-9]*) return 1 ;;
    '')
        # РАУД 48 (независимый аудит раунда 47, R47-LCK-01):
        # пустой «пид» — окно записи метаданных; владелец жив в это окно.
        _nfl_mtime="$(stat -c %Y "$NETFILTER_LOCK_DIR" 2>/dev/null || echo 0)"
        _nfl_now="$(date +%s 2>/dev/null || echo 0)"
        case "$_nfl_mtime:$_nfl_now" in
            *[!0-9:]*|0:*) return 1 ;;
        esac
        [ $((_nfl_now - _nfl_mtime)) -ge 0 ] \
            && [ $((_nfl_now - _nfl_mtime)) -lt 10 ] && return 0
        return 1
        ;;
    esac
    kill -0 "$_nfl_pid" 2>/dev/null || return 1
    # РАУД 46 (независимый аудит, R45-LCK-02): зомби проходит «kill -0» —
    # живость по состоянию процесса: пустое состояние или «Z» — мёртв.
    _nfl_state="$(_kz_pid_field "$_nfl_pid" 3 || true)"
    case "$_nfl_state" in ''|Z) return 1 ;; esac
    if [ -z "$_nfl_saved" ]; then
        # РАУД 46 (независимый аудит, R45-LCK-02): пустое время старта —
        # неполные метаданные; владелец «жив» только в короткое окно
        # записи после создания каталога, дальше лок устарел.
        _nfl_mtime="$(stat -c %Y "$NETFILTER_LOCK_DIR" 2>/dev/null || echo 0)"
        _nfl_now="$(date +%s 2>/dev/null || echo 0)"
        case "$_nfl_mtime:$_nfl_now" in
            *[!0-9:]*|0:*) return 1 ;;
        esac
        [ $((_nfl_now - _nfl_mtime)) -ge 0 ] \
            && [ $((_nfl_now - _nfl_mtime)) -lt 10 ] && return 0
        return 1
    fi
    # РАУД 47 (аудит 4.2.84, №4): сверка старта безусловна — ветка
    # «стат нечитаем» недостижима после проверки состояния.
    _nfl_now="$(_kz_pid_field "$_nfl_pid" 22 || true)"
    [ -n "$_nfl_now" ] && [ "$_nfl_now" = "$_nfl_saved" ] || return 1
    return 0
}

netfilter_unlock() {
    # dns4.2.55 П-24: черновик состояния не должен оставаться в /tmp.
    [ -z "${TPROXY_STATE_TMP:-}" ] || \
        rm -f "$TPROXY_STATE_TMP" 2>/dev/null || true
    # РАУНД 62 (аудит раунда 61, №4): снапшоты таблиц создаются ДО
    # установки ловушки «netfilter_exit»; сигнал или аварийный выход
    # в этом окне обязан прибраться здесь.
    rm -f "${NETFILTER_SNAPSHOT_NAT:-}" \
        "${NETFILTER_SNAPSHOT_MANGLE:-}" \
        "${NETFILTER_SNAPSHOT_FILTER:-}" 2>/dev/null || true
    if [ "$NETFILTER_LOCK_ACQUIRED" -eq 1 ]; then
        # РАУД 40 (повторный аудит, R39-LOCK-03): снимать только свой
        # лок; пустой/отсутствующий «pid» — частичная инициализация.
        _nfu_pid="$(cat "$NETFILTER_LOCK_DIR/pid" 2>/dev/null || true)"
        case "$_nfu_pid" in
            ''|"$$") rm -rf "$NETFILTER_LOCK_DIR" ;;
        esac
    fi
}

# РАУД 41 (повторный аудит, R40-REDIR-TRAP): одна установка ловушек —
# ДО блока захвата, покрывает и прямой захват, и раннер повтора.
# «netfilter_unlock» снимает только свой лок, а при незавершённом
# захвате — только черновик состояния.
trap netfilter_unlock EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP

# 4.2.72 П-2: раннер повтора общий лок не берёт — его возьмут фазы.
if [ "${KEENZOO_UPDATE_LOCK_HELD:-0}" != "1" ] \
        && [ "${KEENZOO_EMERGENCY_RETRY_RUNNER:-0}" != "1" ]; then
    _nfl_tries=0
    while ! mkdir "$NETFILTER_LOCK_DIR" 2>/dev/null; do
        if ! netfilter_lock_owner_live; then
            # РАУД 40 (повторный аудит, R39-LOCK-03): двойная сверка
            # маркера перед очисткой устаревшего лока — не удалять,
            # если между проверками появился новый владелец.
            _nfl_m1="$(cat "$NETFILTER_LOCK_DIR/pid" 2>/dev/null || true);$(cat "$NETFILTER_LOCK_DIR/start" 2>/dev/null || true)"
            if ! netfilter_lock_owner_live; then
                _nfl_m2="$(cat "$NETFILTER_LOCK_DIR/pid" 2>/dev/null || true);$(cat "$NETFILTER_LOCK_DIR/start" 2>/dev/null || true)"
                if [ "$_nfl_m1" = "$_nfl_m2" ]; then
                    rm -rf "$NETFILTER_LOCK_DIR" 2>/dev/null || true
                fi
            fi
            # РАУД 40 (повторный аудит, R39-LOCK-04): любая итерация
            # без захвата считается ожиданием — в том числе при
            # неустранимой ошибке удаления устаревшего лока.
        fi
        _nfl_tries=$((_nfl_tries + 1))
        # dns4.2.37 M-1: 30 попыток × сон держали хук до 30+ с на
        # каждое событие при занятом локе — на MIPS это риск таймаута
        # NDM. Пяти секунд ожидания достаточно: дальше срабатывает
        # существующий однократный фоновый повтор (маркер ниже),
        # который и доводит правила до конца без блокировки хука.
        if [ "$_nfl_tries" -ge 5 ]; then
            logger -t "$TAG" "netfilter apply deferred: shared lock is busy" 2>/dev/null || true
            # NDM may not retry a hook after exit 75. Queue one bounded,
            # one-shot retry in RAM so a concurrent list update cannot leave
            # NAT/TPROXY in a permanently partial state. This is not a daemon
            # or a persistent script; the marker disappears after the retry.
            if [ "${KEENZOO_NETFILTER_RETRY:-0}" != "1" ]; then
                _nfl_retry_marker="/tmp/keenzoo.netfilter.retry.${table:-all}"
                if mkdir "$_nfl_retry_marker" 2>/dev/null; then
                    (
                        trap 'rm -rf "$_nfl_retry_marker" 2>/dev/null || true' EXIT
                        trap 'exit 130' INT
                        trap 'exit 143' TERM
                        trap 'exit 129' HUP
                        _nfl_wait=0
                        while [ "$_nfl_wait" -lt 120 ]; do
                            if ! netfilter_lock_owner_live; then
                                # dns4.2.65 R27-10/Н-6 (аудит раунда 27):
                                # повтор — явным интерпретатором. Скрипт
                                # исполним только с битом «х»; без него
                                # повтор молча не выполнялся.
                                KEENZOO_NETFILTER_RETRY=1 \
                                    type=iptable table="${table:-nat}" \
                                    /bin/sh "$0" >/dev/null 2>&1 || true
                                exit 0
                            fi
                            sleep 2
                            _nfl_wait=$((_nfl_wait + 1))
                        done
                    ) >/dev/null 2>&1 </dev/null &
                fi
            fi
            exit 75
        fi
        sleep 1
    done
    NETFILTER_LOCK_ACQUIRED=1
    printf '%s\n' "$$" > "$NETFILTER_LOCK_DIR/pid"
    # РАУД 48 (аудит раунда 47, №5): время старта — общим хелпером.
    _kz_pid_field "$$" 22 > "$NETFILTER_LOCK_DIR/start" 2>/dev/null || true
fi

# На Keenetic нет logread, а вывод logger в syslog прошивки недоступен
# обычными средствами. Поэтому диагностика дублируется в файл.
REDIRECT_LOG="/opt/var/log/100-redirect.log"
mkdir -p /opt/var/log 2>/dev/null || true
# Create the file before the first wc/redirection. Some BusyBox builds emit
# "can't open ...: no such file" even when the parent directory exists.
: >> "$REDIRECT_LOG" 2>/dev/null || true

# Хук вызывается при каждом изменении состояния интерфейсов, поэтому лог
# обязан быть самоограниченным: пишем ТОЛЬКО ошибки и держим файл в
# пределах 64 КБ, оставляя последние 100 строк. Иначе накопитель с
# Entware со временем переполнится.
REDIRECT_LOG_MAX=65536
REDIRECT_LOG_KEEP=100

log_msg() {
    logger -t "$TAG" "$*" 2>/dev/null || true

    _lsz="$(wc -c < "$REDIRECT_LOG" 2>/dev/null || echo 0)"
    case "$_lsz" in
        ''|*[!0-9]*) _lsz=0 ;;
    esac
    _llines="$(wc -l < "$REDIRECT_LOG" 2>/dev/null || echo 0)"
    case "$_llines" in ''|*[!0-9]*) _llines=0 ;; esac
    if [ "$_lsz" -gt "$REDIRECT_LOG_MAX" ] || [ "$_llines" -gt "$REDIRECT_LOG_KEEP" ]; then
        _ltmp="${REDIRECT_LOG}.tmp.$$"
        _lbytes="${_ltmp}.bytes"
        if tail -n "$REDIRECT_LOG_KEEP" "$REDIRECT_LOG" > "$_ltmp" 2>/dev/null; then
            _ltmp_sz="$(wc -c < "$_ltmp" 2>/dev/null || echo 0)"
            case "$_ltmp_sz" in
                ''|*[!0-9]*) ;;
                *)
                    if [ "$_ltmp_sz" -gt "$REDIRECT_LOG_MAX" ]; then
                        tail -c "$REDIRECT_LOG_MAX" "$_ltmp" > "$_lbytes" 2>/dev/null \
                            && mv -f "$_lbytes" "$_ltmp"
                    fi
                    # Keep the inode stable for long-lived writers.
                    cat "$_ltmp" > "$REDIRECT_LOG" 2>/dev/null || true
                    ;;
            esac
        fi
        rm -f "$_ltmp" "$_lbytes"
    fi

    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$*" \
        >> "$REDIRECT_LOG" 2>/dev/null || true
    # Bound the just-written record as well; scheduled log rotation is only a
    # storage safeguard and is unrelated to DNS health polling.
    _lsz="$(wc -c < "$REDIRECT_LOG" 2>/dev/null || echo 0)"
    _llines="$(wc -l < "$REDIRECT_LOG" 2>/dev/null || echo 0)"
    if [ "$_lsz" -gt "$REDIRECT_LOG_MAX" ] || [ "$_llines" -gt "$REDIRECT_LOG_KEEP" ]; then
        _ltmp="${REDIRECT_LOG}.tmp.$$"
        tail -n "$REDIRECT_LOG_KEEP" "$REDIRECT_LOG" > "$_ltmp" 2>/dev/null \
            && cat "$_ltmp" > "$REDIRECT_LOG" 2>/dev/null || true
        rm -f "$_ltmp"
    fi
}
# Пакет Entware "iptables" ставит /opt/sbin/iptables, где есть только
# libxt_CT/libxt_conntrack — расширений TPROXY, socket и set в нём НЕТ.
# Так как /opt/sbin в PATH первым, правила молча не создавались
# ("Couldn't load target `TPROXY'"). Прошивочный iptables Keenetic их умеет.
# Проверка расширения по ВЫВОДУ, а не по коду возврата: iptables на
# неизвестную цель печатает общую справку и выходит с 0, поэтому
# "iptables -j TPROXY --help >/dev/null; echo $?" даёт 0 даже там, где
# TPROXY нет. Из-за этого выбирался ущербный /opt/sbin/iptables.
# Определение возможностей iptables.
#
# Заголовок справки — основной признак, но полагаться ТОЛЬКО на него нельзя:
# формат отличается между сборками (двоеточие, регистр, отступ), а часть
# расширений вкомпилирована в libiptext.so и печатает заголовок иначе.
# Проверено на KN-2311: libiptext.so содержит и "TPROXY target options:",
# и "set match options:", то есть пакет Entware способен на TPROXY и
# --match-set, хотя отдельных libxt_set.so/libxt_TPROXY.so в нём нет.
# Прежний детектор с жёстким "^" давал ложный отрицательный вердикт, и
# проект без нужды уходил в деградированный режим.
#
# Поэтому проверка двухуровневая: текст справки, а при неудаче — наличие
# характерных опций расширения в том же выводе.
ipt_has_target() {
    _iht_out="$("$1" -j "$2" --help 2>&1 || true)"
    printf '%s' "$_iht_out" | grep -qi "$2 target options" && return 0
    case "$2" in
        TPROXY)
            printf '%s' "$_iht_out" | grep -q -- '--on-port' && return 0
            ;;
    esac
    return 1
}

ipt_has_match() {
    _ihm_out="$("$1" -m "$2" --help 2>&1 || true)"
    printf '%s' "$_ihm_out" | grep -qi "$2 match options" && return 0
    case "$2" in
        set)
            printf '%s' "$_ihm_out" | grep -q -- '--match-set' && return 0
            ;;
    esac
    return 1
}

ipt_is_capable() {
    ipt_has_target "$1" TPROXY && ipt_has_match "$1" set
}

# dns4.2.49 L-3 (остаток раундов 1-2): --transparent сужает -m socket
# до сокетов прозрачного прокси (иначе помечается любой локальный
# UDP). Поддержка зависит от ядра/сборки — пробуем по справке матча;
# без неё остаётся прежний вариант правила.
ipt_socket_transparent_capable() {
    _istc_out="$("$1" -m socket --help 2>&1 || true)"
    printf '%s' "$_istc_out" | grep -q -- '--transparent' && return 0
    return 1
}

pick_iptables() {
    # Прошивочный iptables Keenetic содержит libxt_TPROXY/socket/set.
    # Пакет Entware iptables (1.4.21) несёт только CT/conntrack и при этом
    # перекрывает прошивочный в PATH (/opt/sbin идёт первым).
    # На Keenetic /usr/sbin/iptables отсутствует — прошивочный бинарник
    # лежит в других каталогах, поэтому список кандидатов широкий.
    # Прошивочный бинарник на разных моделях лежит по-разному: на KN-2311
    # его нет ни в /usr/sbin, ни в /sbin. Поэтому список расширен, а после
    # абсолютных путей выполняется поиск по всей файловой системе прошивки.
    # dns4.2.27 (внешний аудит, R-02): кандидаты из /tmp исключены —
    # /tmp world-writable, бинарь оттуда можно подменить; паритет с
    # фиксом A3 C1 (dns4.2.21), который закрыл их в deploy, но пропустил
    # этот хук.
    for _c in /usr/sbin/iptables /sbin/iptables /bin/iptables \
        /usr/bin/iptables /usr/local/sbin/iptables \
        /opt/sbin/iptables /opt/bin/iptables; do
        [ -x "$_c" ] || continue
        if ipt_is_capable "$_c"; then
            printf '%s' "$_c"
            return 0
        fi
    done

    # Прошивочный iptables мог оказаться в нестандартном каталоге —
    # ищем любые экземпляры вне /opt и проверяем каждый.
    # dns4.2.20: glob-цикл вместо $(ls -d …) — пути с пробелами больше
    # не разбиваются по IFS (замечание аудита A2, SC2045).
    for _c in /usr/sbin/iptables* /sbin/iptables* /bin/iptables*; do
        [ -e "$_c" ] || continue
        case "$_c" in *-save|*-restore|*multi*) continue ;; esac
        [ -x "$_c" ] || continue
        if ipt_is_capable "$_c"; then
            printf '%s' "$_c"
            return 0
        fi
    done

    # По абсолютным путям не нашли — пробуем то, что даёт PATH.
    _c="$(command -v iptables 2>/dev/null || true)"
    if [ -n "$_c" ] && ipt_is_capable "$_c"; then
        printf '%s' "$_c"
        return 0
    fi

    # Ни один не умеет TPROXY. Берём первый существующий, иначе имя из
    # PATH — путь /usr/sbin/iptables на Keenetic не существует, и
    # возвращать его нельзя (получили бы "not found").
    for _c in /usr/sbin/iptables /sbin/iptables /bin/iptables \
        /usr/bin/iptables /opt/sbin/iptables; do
        [ -x "$_c" ] && { printf '%s' "$_c"; return 0; }
    done
    printf 'iptables'
}

IPT_BIN="$(pick_iptables)"
IPT="$IPT_BIN -w"
# РАУД 49 (аудит раунда 48, №2): публикуем сделанный выбор для смежных
# проверок (DNS-слой обязан сверять правила тем же бинарником, которым
# они созданы). Путь /tmp доверенный для чтения: потребитель принимает
# только значение из белого списка.
# РАУНД 50 (аудит раунда 49, №3; повторный аудит, РА-03): запись
# защищена: чужой файл или заранее созданный симлинк убираются,
# содержимое пишется во временный файл и переносится переименованием —
# перезапись произвольного файла через симлинк исключена. При сбое
# защищённой записи публикация пропускается (у потребителя фолбэк).
# РАУНД 52 (аудит раунда 51, №3): принадлежность проверяется без
# нестандартного «test -O» — через «stat -c %u» и «id -u».
_ipt_pub_uid="$(stat -c %u /tmp/keenzoo.ipt.bin 2>/dev/null || echo -1)"
if [ -L /tmp/keenzoo.ipt.bin ] \
    || { [ -e /tmp/keenzoo.ipt.bin ] \
         && [ "$_ipt_pub_uid" != "$(id -u)" ]; }; then
    rm -f /tmp/keenzoo.ipt.bin 2>/dev/null || true
fi
_ipt_pub_tmp="$(mktemp /tmp/keenzoo.ipt.bin.XXXXXX 2>/dev/null || true)"
if [ -n "$_ipt_pub_tmp" ]; then
    if printf '%s\n' "$IPT_BIN" > "$_ipt_pub_tmp" 2>/dev/null; then
        mv -f "$_ipt_pub_tmp" /tmp/keenzoo.ipt.bin 2>/dev/null \
            || rm -f "$_ipt_pub_tmp" 2>/dev/null || true
    else
        rm -f "$_ipt_pub_tmp" 2>/dev/null || true
    fi
fi

# NDM invokes this hook separately for each table. Snapshot that one table
# before mutation and restore it on any mandatory failure. save/restore must
# come from the same xtables installation as the selected capable iptables;
# mixing an Entware helper with a firmware binary makes rollback unreliable.
iptables_aux() {
    _ia_kind="$1"
    _ia_dir="${IPT_BIN%/*}"
    [ "$_ia_dir" != "$IPT_BIN" ] || _ia_dir="."
    for _ia_c in "$_ia_dir/iptables-$_ia_kind" "$_ia_dir/$_ia_kind" \
        /usr/sbin/iptables-"$_ia_kind" /sbin/iptables-"$_ia_kind" \
        /bin/iptables-"$_ia_kind" /usr/bin/iptables-"$_ia_kind" \
        /opt/sbin/iptables-"$_ia_kind" /opt/bin/iptables-"$_ia_kind"; do
        [ -x "$_ia_c" ] && { printf '%s\n' "$_ia_c"; return 0; }
    done
    return 1
}

IPT_SAVE_BIN="${IPT_SAVE_BIN:-$(iptables_aux save 2>/dev/null || true)}"
IPT_RESTORE_BIN="${IPT_RESTORE_BIN:-$(iptables_aux restore 2>/dev/null || true)}"
# РАУНД 61 (реаудит раунда 60): непредсказуемые имена снапшотов.
# Если «mktemp» не дал имени — снимок не удастся и сработает
# существующая ветка «snapshot failed» (fail-closed, как и при
# сбое самого «iptables-save»).
NETFILTER_SNAPSHOT_NAT="$(mktemp /tmp/keenzoo-iptables-nat.XXXXXX 2>/dev/null)" || NETFILTER_SNAPSHOT_NAT=""
NETFILTER_SNAPSHOT_MANGLE="$(mktemp /tmp/keenzoo-iptables-mangle.XXXXXX 2>/dev/null)" || NETFILTER_SNAPSHOT_MANGLE=""
NETFILTER_SNAPSHOT_FILTER="$(mktemp /tmp/keenzoo-iptables-filter.XXXXXX 2>/dev/null)" || NETFILTER_SNAPSHOT_FILTER=""
NETFILTER_SNAPSHOT_NAT_READY=0
NETFILTER_SNAPSHOT_MANGLE_READY=0
NETFILTER_SNAPSHOT_FILTER_READY=0
# dns4.2.61 Х-01: 1 = ненулевой выход является НАМЕРЕННОЙ fail-closed
# фиксацией (код 4), снапшоты не восстанавливаются. См. netfilter_exit.
NETFILTER_PRESERVE_FAILCLOSED=0
TPROXY_RULE_ADDED=0
TPROXY_ROUTE_ADDED=0
if [ -z "$IPT_SAVE_BIN" ] || [ -z "$IPT_RESTORE_BIN" ]; then
    log_msg "matching iptables-save/restore binaries not found for $IPT_BIN"
    exit 1
fi
# 4.2.72 П-2: раннер повтора снапшоты не снимает (пустой «table»).
if [ "${KEENZOO_EMERGENCY_RETRY_RUNNER:-0}" = "1" ]; then
    :
elif [ "${table:-}" = "filter" ]; then
    "$IPT_SAVE_BIN" -t filter > "$NETFILTER_SNAPSHOT_FILTER" 2>/dev/null \
        && NETFILTER_SNAPSHOT_FILTER_READY=1 || {
        log_msg "filter snapshot failed"
        exit 1
    }
else
    "$IPT_SAVE_BIN" -t nat > "$NETFILTER_SNAPSHOT_NAT" 2>/dev/null \
        && NETFILTER_SNAPSHOT_NAT_READY=1 || {
        log_msg "nat snapshot failed"
        exit 1
    }
    if [ "${DNS_ONLY:-0}" != 1 ]; then
    "$IPT_SAVE_BIN" -t mangle > "$NETFILTER_SNAPSHOT_MANGLE" 2>/dev/null \
        && NETFILTER_SNAPSHOT_MANGLE_READY=1 || {
        log_msg "mangle snapshot failed"
        exit 1
    }
    fi
fi

netfilter_exit() {
    _nfe_rc=$?
    # dns4.2.61 Х-01 (аудит раунда 23, RU_CURRENT H-01): различаем два
    # типа ненулевого выхода. Сбой ПРИМЕНЕНИЯ (1 и др.) — откат к
    # last-known-good снапшотам. Намеренная fail-closed вычистка
    # (состояние «fail», код 4) откатываться НЕ должна: иначе трап
    # возвращал только что удалённые старые правила из снапшота, а
    # снятые `ip rule/route` не восстанавливал — состояние становилось
    # рассогласованным. Флаг ставится непосредственно перед `exit 4`.
    if [ "$_nfe_rc" -ne 0 ] \
            && [ "${NETFILTER_PRESERVE_FAILCLOSED:-0}" -ne 1 ]; then
        [ "$TPROXY_RULE_ADDED" -eq 1 ] && \
            ip rule del fwmark "${TPROXY_MARK:-0x1000000}/${TPROXY_MASK:-0x1000000}" \
                lookup "${TPROXY_TABLE:-100}" priority "${TPROXY_RULE_PRIO:-1770}" \
                >/dev/null 2>&1 || true
        [ "$TPROXY_ROUTE_ADDED" -eq 1 ] && \
            ip route del local default dev lo table "${TPROXY_TABLE:-100}" \
                >/dev/null 2>&1 || true
        # 4.2.72 П-3 (аудит поведения при деградации, фиксация):
        # восстановление ЦЕЛЫХ таблиц из снапшота начала этого же
        # прогона. Известное окно: если «ndm» поменял таблицу между
        # снапшотом и откатом (откат = сбой установки, редкое
        # событие), его правка будет перезаписана; «ndm» сам
        # переприменяет свои правила (в т.ч. MASQUERADE) на событиях
        # интерфейсов. Точечное удаление только проектных правил
        # вместо полного отката — кандидат на будущий крупный раунд.
        [ "$NETFILTER_SNAPSHOT_NAT_READY" -eq 1 ] && \
            "$IPT_RESTORE_BIN" < "$NETFILTER_SNAPSHOT_NAT" >/dev/null 2>&1 || \
            true
        [ "$NETFILTER_SNAPSHOT_MANGLE_READY" -eq 1 ] && \
            "$IPT_RESTORE_BIN" < "$NETFILTER_SNAPSHOT_MANGLE" >/dev/null 2>&1 || \
            true
        [ "$NETFILTER_SNAPSHOT_FILTER_READY" -eq 1 ] && \
            "$IPT_RESTORE_BIN" < "$NETFILTER_SNAPSHOT_FILTER" >/dev/null 2>&1 || \
            true
    fi
    rm -f "$NETFILTER_SNAPSHOT_NAT" "$NETFILTER_SNAPSHOT_MANGLE" \
        "$NETFILTER_SNAPSHOT_FILTER" 2>/dev/null || true
    netfilter_unlock
    exit "$_nfe_rc"
}
trap netfilter_exit EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP

# PURGE_PROJECT is handled after the matching iptables binaries and shared
# lock are ready. Seed the same runtime constants under `set -u`; normal
# service discovery below recalculates LAN_IFACES/local_ip for apply mode.
PORT_SS="${PORT_SS:-$(config_number localportsh 1082)}"
PORT_TOR="${PORT_TOR:-$(config_number localporttor 9141)}"
PORT_VLESS="${PORT_VLESS:-$(config_number localportvless 10810)}"
PORT_TROJAN="${PORT_TROJAN:-$(config_number localporttrojan 10829)}"
PORT_HYSTERIA="${PORT_HYSTERIA:-$(config_number localporthysteria 10830)}"
PORT_WEB="${PORT_WEB:-$(config_number web_port 8080)}"
TPROXY_MARK="${TPROXY_MARK:-0x1000000}"
TPROXY_MASK="${TPROXY_MASK:-0x1000000}"
TPROXY_TABLE="${TPROXY_TABLE:-100}"
TPROXY_RULE_PRIO="${TPROXY_RULE_PRIO:-1770}"

# dns4.2.63 Х-04 (аудит раунда 25, RU_R23 H-04): маркер владельца
# политики и единые функции владения. Определены ДО всех исполняемых
# секций: они нужны и раннему проходу демонтажа (включая
# PURGE-режим), и секции 5. Значения ниже продублированы не будут —
# секция 4 перезаписывает сами константы теми же литералами.
KZ_TPROXY_OWNER="/opt/var/run/keenzoo-tproxy-owner"
# Числовая нормализация: настраиваемые метка/маска/таблица/приоритет
# могут задаваться в 16-ричном или десятичном виде; сравнение учитывает
# оба представления (ранее был захардкожен алиас только для 0x1000000).
_kz_dec() {
    case "$1" in
        0x*[!0-9a-fA-F]*|0X*[!0-9a-fA-F]*|''|*[!0-9a-fxA-F]*)
            printf '%s' "$1" ;;
        0x*|0X*)
            printf '%s' "$(($1))" ;;
        *)
            printf '%s' "$1" ;;
    esac
}
KZ_TPROXY_MARKM_RAW="$TPROXY_MARK/$TPROXY_MASK"
KZ_TPROXY_MARKM_DEC="$(_kz_dec "$TPROXY_MARK")/$(_kz_dec "$TPROXY_MASK")"
KZ_TPROXY_TABLE_RAW="$TPROXY_TABLE"
KZ_TPROXY_TABLE_DEC="$(_kz_dec "$TPROXY_TABLE")"
KZ_TPROXY_PRIO_RAW="$TPROXY_RULE_PRIO"
KZ_TPROXY_PRIO_DEC="$(_kz_dec "$TPROXY_RULE_PRIO")"
# dns4.2.63 Х-03/Х-04 (аудит раунда 25, RU_R23 H-03/H-04): маркер
# действителен, если в нём наш кортеж (в любой нотации) и текущий
# boot-id: после перезагрузки правило с тем же кортежем создано уже
# не нами.
kz_tproxy_marker_valid() {
    [ -f "$KZ_TPROXY_OWNER" ] || return 1
    _ktmv_mark=""; _ktmv_table=""; _ktmv_prio=""; _ktmv_boot=""
    read -r _ktmv_mark _ktmv_table _ktmv_prio _ktmv_boot \
        < "$KZ_TPROXY_OWNER" 2>/dev/null || true
    _ktmv_now="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null || printf -- '-')"
    { [ "${_ktmv_mark:-}" = "$KZ_TPROXY_MARKM_RAW" ] \
        || [ "${_ktmv_mark:-}" = "$KZ_TPROXY_MARKM_DEC" ]; } \
        && { [ "${_ktmv_table:-}" = "$KZ_TPROXY_TABLE_RAW" ] \
        || [ "${_ktmv_table:-}" = "$KZ_TPROXY_TABLE_DEC" ]; } \
        && [ "${_ktmv_prio:-}" = "$KZ_TPROXY_PRIO_RAW" ] \
        && [ "${_ktmv_boot:-}" = "$_ktmv_now" ]
}
# Единый владельческий демонтаж политики (вычистка и PURGE). Без
# действительного маркера точные кортежи могут принадлежать другому
# приложению — они НЕ удаляются; удаляются только ресурсы с
# доказанным владением. Правила/цепочки iptables проекта снимает
# вызывающий: к ним владение не применяется.
remove_owned_tproxy_policy() {
    if kz_tproxy_marker_valid; then
        while ip rule del fwmark "$TPROXY_MARK/$TPROXY_MASK" \
            lookup "$TPROXY_TABLE" priority "$TPROXY_RULE_PRIO" \
            >/dev/null 2>&1; do :; done
        # То же в десятичном представлении: правило, добавленное в
        # другой нотации, иначе не снимется.
        if [ "$KZ_TPROXY_MARKM_DEC" != "$KZ_TPROXY_MARKM_RAW" ] \
                || [ "$KZ_TPROXY_TABLE_DEC" != "$KZ_TPROXY_TABLE_RAW" ] \
                || [ "$KZ_TPROXY_PRIO_DEC" != "$KZ_TPROXY_PRIO_RAW" ]; then
            while ip rule del fwmark "$KZ_TPROXY_MARKM_DEC" \
                lookup "$KZ_TPROXY_TABLE_DEC" priority "$KZ_TPROXY_PRIO_DEC" \
                >/dev/null 2>&1; do :; done
        fi
        while ip route del local default dev lo table "$TPROXY_TABLE" \
            >/dev/null 2>&1; do :; done
        rm -f "$KZ_TPROXY_OWNER" 2>/dev/null || true
    else
        # dns4.2.66 R28-06 (аудит раунда 28, v25): ПУРЖ вызывает хук
        # трижды (мангл/нат/фильтр); после первого снятия маркера
        # повторные вызовы прежде писали ложную тревогу. Предупреждение
        # нужно только если кортеж РЕАЛЬНО есть в ядре.
        if ip rule show 2>/dev/null \
                | grep -q "^${KZ_TPROXY_PRIO_DEC}:" \
                || [ -n "$(ip route show table "$TPROXY_TABLE" \
                    2>/dev/null)" ]; then
            log_msg "TPROXY: нет действующего маркера владельца — ip rule/route не удалены (возможен чужой владелец); проверьте: ip rule show priority $TPROXY_RULE_PRIO"
        fi
    fi
}
XRAY_MARK="${XRAY_MARK:-0x2000000}"
# dns4.2.60 В-3 (аудит 2026-09-29): общий бюджет ожидания слушателей на
# ОДИН прогон хука (см. svc_owned_transport). Без ограничения каждое
# событие NDM растягивалось бы кратно числу сервисов.
# dns4.2.61 Н-11 (аудит раунда 23, v21): бюджет объявлен ДО первого
# использования (раньше — после, и в DNS_ONLY-прогоне ожидание было 0).
_KZ_OWN_WAIT_LEFT=8
LAN_IFACE_PATTERNS="${LAN_IFACE_PATTERNS:-br0 br1 br2 wlan0 wlan1 wlan2 wlan3 nwg0 nwg1 nwg2 wg0 wg1 tun0 tap0 ppp-l2tp0 sstp0}"
LAN_IFACES="${LAN_IFACES:-$LAN_IFACE_PATTERNS}"
local_ip="${local_ip:-${CONFIG_ROUTER_IP:-$(config_string routerip 192.168.1.1)}}"
if [ "${PURGE_PROJECT:-0}" = "1" ]; then
    purge_project_netfilter
    exit 0
fi

# Одноразовая очистка старого policy-VPN выполняется до обычной генерации
# правил. Это нужно, чтобы сначала снять references на ipset, а затем
# безопасно уничтожить ошибочный набор WAN/Bridge.
purge_vpn_state() {
    _pvs_set="${PURGE_VPN_SET:-}"
    _pvs_mark="${PURGE_VPN_MARK:-}"
    [ -n "$_pvs_set" ] || return 0

    for _pvs_proto in tcp udp; do
        while $IPT -t mangle -D PREROUTING -p "$_pvs_proto" \
            -m set --match-set "$_pvs_set" dst \
            -j MARK --set-mark "$_pvs_mark" >/dev/null 2>&1; do :; done
    done
    while $IPT -t mangle -D PREROUTING \
        -m conntrack --ctstate NEW \
        -m set --match-set "$_pvs_set" dst \
        -j CONNMARK --set-mark "$_pvs_mark" >/dev/null 2>&1; do :; done
    return 0
}

if [ -n "${PURGE_VPN_SET:-}" ]; then
    purge_vpn_state
    exit 0
fi

# dns4.2.28 (внешний отчёт, P-07): блок PORT_* здесь дублировал сид выше
# (оба вида ${VAR:-…} — повтор был функционально пуст). Оставлены только
# константы, которых в сиде нет.
# The DNS owner publishes its verified tunnel selection in the existing,
# bounded health log. Netfilter consumes that decision; it must never choose
# a tunnel merely because an enabled process happens to be running.
DNS_HEALTH_LOG="${DNS_HEALTH_LOG:-$(config_string dns_health_log /opt/var/log/unblock_dns_health.log)}"
DNS_SNAPSHOT_MAX_AGE="${DNS_SNAPSHOT_MAX_AGE:-$(config_number dns_snapshot_max_age 21600)}"  # was 90000=25h (dns4.2.21)
case "$DNS_SNAPSHOT_MAX_AGE" in
    ''|*[!0-9]*) DNS_SNAPSHOT_MAX_AGE=21600 ;;  # was 90000 (dns4.2.21)
esac

# DNS-only refresh uses the SAME DNS helpers as a normal NDM event, but
# does not rebuild LAN, TPROXY or WireGuard rules (nor their routing tables).
# ВСЕ пути сервисных скриптов объявлены ДО любых гейтов секций: пути
# INIT_SS/INIT_TOR читаются также в мангл-проходе (секция 5), который
# выполняется при _kz_do_nat=0 — объявление только внутри нат-гейта
# роняло хук под set -u на «параметр не задан» (раунд 4, R-1).
INIT_VLESS="/opt/etc/init.d/S24xray"
INIT_TROJ="/opt/etc/init.d/S22trojan"
INIT_HY="/opt/etc/init.d/S57hysteria"
INIT_SS="/opt/etc/init.d/S65shadowsocks"
INIT_TOR="/opt/etc/init.d/S35tor"
# dns4.2.59 Х-09 (аудит 2026-09-29, H-09): готовность = процесс проекта
# ВЛАДЕЕТ слушателем порта. Сопоставляются inode сокетов из
# /proc/<pid>/fd с записями /proc/net/{tcp,udp}: чужой слушатель на
# порту больше не имитирует готовность. Аргументы:
#   $1 имя процесса (по argv[0]), $2 порт, $3 транспорт (tcp|udp),
#   $4 необязательная подстрока командной строки (путь конфига).
owned_listener_ready() {
    _olr_proc="$1"; _olr_port="$2"; _olr_proto="$3"; _olr_hint="${4:-}"
    case "$_olr_port" in ''|*[!0-9]*) return 1 ;; esac
    [ "$_olr_port" -ge 1 ] && [ "$_olr_port" -le 65535 ] || return 1
    # РАУД 37 (итоговый аудит, P2-03): проект IPv4-only.
    case "$_olr_proto" in
        tcp) _olr_files="/proc/net/tcp"; _olr_state="0A" ;;
        udp) _olr_files="/proc/net/udp"; _olr_state="" ;;
        *) return 1 ;;
    esac
    _olr_hex="$(printf '%04X' "$_olr_port")"
    # РАУД 38 (повторный аудит, R37-03): на минимальных сборках
    # BusyBox может не быть «pidof» — фолбэк обходом /proc со
    # сравнением basename argv[0] (зеркало svc_enabled_probe).
    if command -v pidof >/dev/null 2>&1; then
        _olr_pids="$(pidof "$_olr_proc" 2>/dev/null || true)"
    else
        _olr_pids=""
        for _olr_d in /proc/[0-9]*; do
            _olr_argv0="$(cat "$_olr_d/cmdline" 2>/dev/null \
                | tr '\0' '\n' | head -1)"
            [ -n "$_olr_argv0" ] || continue
            [ "${_olr_argv0##*/}" = "$_olr_proc" ] || continue
            _olr_pids="$_olr_pids ${_olr_d#/proc/}"
        done
    fi
    _olr_inodes=" "
    for _olr_pid in $_olr_pids; do
        # РАУД 38 (повторный аудит, R37-04): хинт — ОТДЕЛЬНЫЙ
        # argv-токен, а не подстрока командной строки: «/opt/etc/
        # xray» не должен совпадать с «/opt/etc/xray-backup/…».
        if [ -n "$_olr_hint" ]; then
            _olr_match=0
            while IFS= read -r _olr_arg; do
                [ "$_olr_arg" = "$_olr_hint" ] && { _olr_match=1; break; }
            done <<EOF
$(tr '\0' '\n' < "/proc/$_olr_pid/cmdline" 2>/dev/null)
EOF
            [ "$_olr_match" = 1 ] || continue
        fi
        # dns4.2.60 К-3 (аудит 2026-09-29, C-01): sed печатает по одному
        # inode в строке; без перевода строк в пробелы список содержал
        # \n, и awk-поиск " inode " у процесса с двумя и более
        # сокетами не совпадал никогда (все реальные демоны проекта —
        # TCP+UDP). Формат списка: пробел-разделитель с обеих сторон.
        _olr_s="$(ls -l "/proc/$_olr_pid/fd" 2>/dev/null \
            | sed -n 's/^.*socket:\[\([0-9][0-9]*\)\].*$/\1/p' \
            | tr '\n' ' ')"
        [ -n "$_olr_s" ] && _olr_inodes="$_olr_inodes$_olr_s"
    done
    [ "$_olr_inodes" != " " ] || return 1
    for _olr_f in $_olr_files; do
        [ -r "$_olr_f" ] || continue
        awk -v p=":$_olr_hex" -v il="$_olr_inodes" -v st="$_olr_state" '
            NR > 1 {
                n = split($2, _la, ":")
                if (_la[n] != substr(p, 2)) next
                if (st != "" && $4 != st) next
                if (index(il, " " $10 " ") > 0) { ok = 1; exit }
            }
            END { exit ok ? 0 : 1 }' "$_olr_f" 2>/dev/null && return 0
    done
    return 1
}

# Соответствие сервиса порту/подсказке для гейта владения. Транспорт
# задаёт вызывающий: отказ одного транспорта не гасит другой.
# Результат кэшируется на прогон хука (по сервису и транспорту).
# shellcheck disable=SC2154 # _sot_cached задаётся через eval (динамика, dns4.2.20)
svc_owned_transport() {
    _sot_name="${1##*/}"
    _sot_tr="$2"
    case "$_sot_name" in
        S24xray)         _sot_proc="xray";      _sot_port="$PORT_VLESS";    _sot_hint="/opt/etc/xray" ;;
        S22trojan)       _sot_proc="trojan";    _sot_port="$PORT_TROJAN";   _sot_hint="/opt/etc/trojan/config.json" ;;
        S57hysteria)     _sot_proc="hysteria";  _sot_port="$PORT_HYSTERIA"; _sot_hint="/opt/etc/hysteria/config.json" ;;
        S65shadowsocks)  _sot_proc="ss-redir";  _sot_port="$PORT_SS";       _sot_hint="/opt/etc/shadowsocks.json" ;;
        S35tor)          _sot_proc="tor";       _sot_port="$PORT_TOR";      _sot_hint="/opt/etc/tor/torrc" ;;
        *) return 0 ;;
    esac
    case "$_sot_tr" in
        tcp) ;;
        udp) case "$_sot_name" in S22trojan|S35tor) return 0 ;; esac ;;
        *) return 0 ;;
    esac
    _sot_key="$(printf '%s_%s' "$_sot_name" "$_sot_tr" | tr -c 'A-Za-z0-9_' '_')"
    eval "_sot_cached=\"\${_SVC_OWNED_${_sot_key}:-}\""
    case "$_sot_cached" in
        1) return 0 ;;
        0) return 1 ;;
    esac
    if owned_listener_ready "$_sot_proc" "$_sot_port" "$_sot_tr" "$_sot_hint"; then
        eval "_SVC_OWNED_${_sot_key}=1"
        return 0
    fi
    # dns4.2.60 В-3 (аудит 2026-09-29): гонка «перезапуск сервиса ->
    # немедленный хук»: слушатель ещё не поднят, и строгая проверка
    # владельца снимала правила до следующего события NDM. Ограниченное
    # ожидание с ОБЩИМ бюджетом на прогон хука (а не на каждый сервис —
    # иначе событие растягивалось бы кратно числу сервисов).
    while [ "${_KZ_OWN_WAIT_LEFT:-0}" -gt 0 ]; do
        sleep 1
        _KZ_OWN_WAIT_LEFT=$((_KZ_OWN_WAIT_LEFT - 1))
        if owned_listener_ready "$_sot_proc" "$_sot_port" "$_sot_tr" "$_sot_hint"; then
            eval "_SVC_OWNED_${_sot_key}=1"
            return 0
        fi
    done
    eval "_SVC_OWNED_${_sot_key}=0"
    log_msg "$_sot_proc: слушатель $_sot_port/$_sot_tr не принадлежит проекту — правила $_sot_tr не создаются"
    return 1
}

# Раунд 6, П-16: ответ «сервис включён и жив» в пределах ОДНОГО прогона
# хука не меняется, а вызовов ≈33 на событие (16 точек × проходы по
# таблицам). Прежде на каждый вызов до кэша _SVC_ALIVE_<proc> заново
# исполнялись grep ENABLED, sed PROCS, printf|tr. Мемоизация по имени
# init-скрипта; тело проверки без изменений — в svc_enabled_probe.
# shellcheck disable=SC2154 # _se_state задаётся через eval _SVC_STATE_<key> (динамика, раунд 6)
svc_enabled() {
    _se_base="${1##*/}"
    case "$_se_base" in
        ''|*[!A-Za-z0-9_]*) _se_base="$(printf '%s' "$_se_base" | tr -c 'A-Za-z0-9_' '_')" ;;
    esac
    # dns4.2.59 Х-09: необязательный второй аргумент (tcp|udp) включает
    # гейт владения слушателем; без него — прежняя проверка живости.
    # Кэш раздельный по (сервис, транспорт): отказ одного транспорта
    # не гасит другой.
    _se_tr="${2:-}"
    case "$_se_tr" in
        tcp|udp) _se_key="${_se_base}_${_se_tr}" ;;
        *) _se_tr=""; _se_key="$_se_base" ;;
    esac
    eval "_se_state=\"\${_SVC_STATE_${_se_key}:-}\""
    case "$_se_state" in
        1) return 0 ;;
        0) return 1 ;;
    esac
    if svc_enabled_probe "$1"; then
        if [ -n "$_se_tr" ] && ! svc_owned_transport "$1" "$_se_tr"; then
            eval "_SVC_STATE_${_se_key}=0"
            return 1
        fi
        eval "_SVC_STATE_${_se_key}=1"
        return 0
    fi
    eval "_SVC_STATE_${_se_key}=0"
    return 1
}

# shellcheck disable=SC2154 # _svc_cached задаётся через eval _SVC_ALIVE_<key> (динамика, dns4.2.20)
svc_enabled_probe() {
    _init="$1"
    [ -f "$_init" ] || return 1
    if grep -qE '^[[:space:]]*ENABLED[[:space:]]*=[[:space:]]*no' \
        "$_init" 2>/dev/null
    then
        return 1
    fi

    # Мало того, что сервис разрешён — он должен реально работать.
    # Правило на упавший сервис создаёт чёрную дыру: пакеты уходят на
    # порт, который никто не слушает, и клиент получает таймаут вместо
    # обхода (наблюдалось с hysteria: сервис dead, а 6 правил на
    # unblockhysteria стояли). Порт берётся из PROCS init-скрипта.
    _svc_proc="$(sed -n \
        's/^[[:space:]]*PROCS[[:space:]]*=[[:space:]]*\([^[:space:]#]*\).*/\1/p' \
        "$_init" 2>/dev/null | head -1)"
    [ -n "$_svc_proc" ] || return 1

    # Разбор /proc, без pgrep: он есть не во всех сборках BusyBox.
    # Сравнивается ИМЯ БИНАРНИКА (argv[0]), а не вся командная строка:
    # подстрочный поиск принимал за живой сервис любой процесс, где имя
    # встречается в аргументах — например "vi /opt/etc/hysteria/config.json"
    # или "tail -f .../hysteria.log". Тогда правила создавались для
    # мёртвого сервиса, то есть ровно та ошибка, ради которой делалась
    # проверка.
    # Результат кэшируется на время прогона: функция вызывается до 15 раз
    # (5 сервисов × 3 интерфейса), и каждый раз обходить весь /proc
    # слишком дорого — прошивка убивала хук по таймауту
    # ("100-redirect.sh: timed out", Opkg::Manager).
    # Имя процесса нормализуется: в имени переменной допустимы только
    # [A-Za-z0-9_], а PROCS бывает вида "ss-redir".
    _svc_key="$(printf '%s' "$_svc_proc" | tr -c 'A-Za-z0-9_' '_')"
    eval "_svc_cached=\"\${_SVC_ALIVE_${_svc_key}:-}\""
    case "$_svc_cached" in
        1) return 0 ;;
        0) return 1 ;;
    esac

    # dns4.2.37 H-3 / dns4.2.38 N-2: фастпуть через pidof — ОДИН exec
    # вместо обхода всего /proc с тремя форками на каждый PID (~100 PID
    # на MIPS). pidof сравнивает имя процесса, а не подстроку командной
    # строки, поэтому «vi /opt/etc/hysteria/config.json» живым сервисом
    # не считается — той же строгости, что у обхода ниже. Отрицательный
    # ответ столь же надёжен: оба способа сравнивают одно и то же, и
    # проваливание в обход стоило по ~3 форка на каждый PID системы на
    # КАЖДЫЙ выключенный сервис (2–3 из 5 в типовой установке). Обход
    # /proc остаётся только для сборок, где нет самого pidof.
    if command -v pidof >/dev/null 2>&1; then
        if pidof "$_svc_proc" >/dev/null 2>&1; then
            eval "_SVC_ALIVE_${_svc_key}=1"
            return 0
        fi
        eval "_SVC_ALIVE_${_svc_key}=0"
        log_msg "$_svc_proc не запущен — правила перехвата не создаются"
        return 1
    fi

    _svc_found=1
    for _svc_d in /proc/[0-9]*; do
        # Процесс мог завершиться между раскрытием маски и чтением файла.
        # Перенаправление "< файл" выполняет ОБОЛОЧКА, и её сообщение
        # "can't open ...: no such file" не подавляется через 2>/dev/null
        # у самой команды — в журнале роутера это выглядело как ошибка
        # скрипта. Читаем через cat с подавлением его собственного stderr.
        _svc_argv0="$(cat "$_svc_d/cmdline" 2>/dev/null \
            | tr '\0' '\n' | head -1)"
        [ -n "$_svc_argv0" ] || continue
        # argv[0] может быть как "hysteria", так и "/opt/bin/hysteria".
        if [ "${_svc_argv0##*/}" = "$_svc_proc" ]; then
            _svc_found=0
            break
        fi
    done

    # Имя процесса подставляется в имя переменной, поэтому из него
    # убирается всё, кроме [A-Za-z0-9_]: "ss-redir" дал бы недопустимое
    # имя и eval завершился бы ошибкой.
    _svc_key="$(printf '%s' "$_svc_proc" | tr -c 'A-Za-z0-9_' '_')"
    if [ "$_svc_found" = "0" ]; then
        eval "_SVC_ALIVE_${_svc_key}=1"
        return 0
    fi

    eval "_SVC_ALIVE_${_svc_key}=0"
    log_msg "$_svc_proc не запущен — правила перехвата не создаются"
    return 1
}

# dns4.2.60 Х-07 (аудит 2026-09-29, H-07): «сервис включён политикой» —
# конфигурация разрешает перехват, независимо от живости процесса.
# Отдельно от живости/владения (svc_enabled): если процесс намеренно
# включённого сервиса временно умер, очередной прогон не обязан снимать
# политику безопасности — в частности, обязан оставаться fail-closed
# backstop UDP, иначе неперехваченный уходил бы прямо в WAN (тихий
# обход на время перезапуска).
svc_policy_enabled() {
    _sp_init="$1"
    [ -f "$_sp_init" ] || return 1
    if grep -qE '^[[:space:]]*ENABLED[[:space:]]*=[[:space:]]*no' \
        "$_sp_init" 2>/dev/null
    then
        return 1
    fi
    # dns4.2.61 К-5 (аудит раунда 23, v21): «политика включена» — тот
    # же критерий, по которому init-скрипт вообще поднимает туннель
    # (см. key_config_ready в S24xray/S57hysteria/S65shadowsocks/
    # S22trojan): ключ добавлен => есть маркер .configured/<svc>.
    # ENABLED=yes стоит в каждом init-скрипте с момента установки, и
    # без маркера backstop отвергал UDP к спискам протоколов, которые
    # пользователь ещё не настраивал (свежая установка: 9 REJECT при
    # 0 правил перехвата — QUIC, звонки к доменам из списков).
    # Замысел Х-07 сохраняется: настроенный, но упавший сервис
    # остаётся fail-closed.
    case "${_sp_init##*/}" in
        S24xray)        _sp_mark=xray ;;
        S57hysteria)    _sp_mark=hysteria ;;
        S65shadowsocks) _sp_mark=shadowsocks ;;
        S22trojan)      _sp_mark=trojan ;;
        *)              return 0 ;;
    esac
    [ -f "/opt/etc/unblock/.configured/$_sp_mark" ]
}

dns_snapshot_tunnel() {
    [ -f "$DNS_HEALTH_LOG" ] || return 1
    _dst_line="$(grep 'decision=final ' "$DNS_HEALTH_LOG" 2>/dev/null | tail -1 || true)"
    [ -n "$_dst_line" ] || return 1
    _dst_epoch="$(printf '%s\n' "$_dst_line" | sed -n 's/.* epoch=\([0-9][0-9]*\) .*/\1/p')"
    case "$_dst_epoch" in ''|*[!0-9]*) return 1 ;; esac
    _dst_now="$(date +%s 2>/dev/null || echo 0)"
    [ "$_dst_now" -ge "$_dst_epoch" ] || return 1
    [ $((_dst_now - _dst_epoch)) -le "$DNS_SNAPSHOT_MAX_AGE" ] || return 1
    _dst_mode="$(printf '%s\n' "$_dst_line" | sed -n 's/.* mode=\([^ ]*\).*/\1/p')"
    _dst_level="$(printf '%s\n' "$_dst_line" | sed -n 's/.* level=\([^ ]*\).*/\1/p')"
    _dst_required="$(printf '%s\n' "$_dst_line" | sed -n 's/.* required=\([^ ]*\).*/\1/p')"
    _dst_verified="$(printf '%s\n' "$_dst_line" | sed -n 's/.* verified=\([^ ]*\).*/\1/p')"
    _dst_tunnel="$(printf '%s\n' "$_dst_line" | sed -n 's/.* tunnel=\([^ ]*\).*/\1/p')"
    [ "$_dst_mode" = "TUNNEL_DNS" ] \
        && [ "$_dst_level" = "TUNNEL_DNS" ] \
        && [ "$_dst_required" = "1" ] \
        && [ "$_dst_verified" = "1" ] || return 1
    case "$_dst_tunnel" in
        xray) svc_enabled "$INIT_VLESS" tcp || return 1; printf '%s\n' "$PORT_VLESS" ;;
        trojan) svc_enabled "$INIT_TROJ" tcp || return 1; printf '%s\n' "$PORT_TROJAN" ;;
        hysteria) svc_enabled "$INIT_HY" tcp || return 1; printf '%s\n' "$PORT_HYSTERIA" ;;
        *) return 1 ;;
    esac
}

# v4: only sockets explicitly marked by the DNS controller use tunnel DNS.
# The mandatory filter guard prevents a missing NAT rule from leaking a
# tunnel probe/query as direct TCP53. Normal DoT/DoH listeners are not routed
# through a tunnel merely because a proxy daemon is running.
apply_dns_v4_filter() {
    for _v4_mark in 0x2000101 0x2000102 0x2000103; do
        if ! $IPT -C OUTPUT -p tcp --dport 53 -m mark --mark "$_v4_mark" -j REJECT >/dev/null 2>&1; then
            $IPT -I OUTPUT 1 -p tcp --dport 53 -m mark --mark "$_v4_mark" -j REJECT || return 1
        fi
    done
}

apply_dns_v4_nat() {
    $IPT -t nat -N KZ_DNS_V4 >/dev/null 2>&1 || true
    # Build guards in filter BEFORE installing any marked redirect.
    apply_dns_v4_filter || return 1
    # No flushing of a live chain: replacing a target leaves no direct gap.
    for _v4_spec in "0x2000101:$PORT_HYSTERIA" "0x2000102:$PORT_VLESS" "0x2000103:$PORT_TROJAN"; do
        _v4_mark="${_v4_spec%%:*}"; _v4_port="${_v4_spec#*:}"
        if ! $IPT -t nat -C KZ_DNS_V4 -p tcp --dport 53 -m mark --mark "$_v4_mark" -j REDIRECT --to-ports "$_v4_port" >/dev/null 2>&1; then
            $IPT -t nat -I KZ_DNS_V4 1 -p tcp --dport 53 -m mark --mark "$_v4_mark" -j REDIRECT --to-ports "$_v4_port" || return 1
        fi
    done
    # Emergency sockets explicitly bypass project-wide router TCP redirect.
    for _v4_proto in tcp udp; do
        if ! $IPT -t nat -C OUTPUT -p "$_v4_proto" --dport 53 -m mark --mark 0x2000104 -j RETURN >/dev/null 2>&1; then
            $IPT -t nat -I OUTPUT 1 -p "$_v4_proto" --dport 53 -m mark --mark 0x2000104 -j RETURN || return 1
        fi
    done
    # Put the policy chain before generic mark/loopback/router RETURN rules.
    while $IPT -t nat -D OUTPUT -j KZ_DNS_V4 >/dev/null 2>&1; do :; done
    $IPT -t nat -I OUTPUT 1 -j KZ_DNS_V4 || return 1
}

# dns4.2.35 (ре-аудит, R-02/R-03): содержимое цепочки статично, поэтому
# обычный прогон — быстрая сверка готовности (без единого изменения в
# рабочем пути ядра). Если цепочка отсутствует или повреждена, она
# пересобирается через стейджинг-цепочку: новая заполняется ПОЛНОСТЬЮ,
# прыжок переключается на неё и лишь затем снимается старая — окна
# «пустая цепочка возвращает пакет в OUTPUT» нет. Оба имени равноправны;
# активна та цепочка, на которую сейчас указывает прыжок.
KZ_RAW_GUARD_CHAINS="KZ_DNS_V4_FILTER KZ_DNS_V4_FILTER_NEW"

kzv4_raw_guard_chain_ok() {
    _rgco_chain="$1"
    $IPT -C "$_rgco_chain" -d 127.0.0.0/8 -p tcp --dport 53 \
        -j RETURN >/dev/null 2>&1 || return 1
    $IPT -C "$_rgco_chain" -d 127.0.0.0/8 -p udp --dport 53 \
        -j RETURN >/dev/null 2>&1 || return 1
    $IPT -C "$_rgco_chain" -p tcp --dport 53 -m mark \
        --mark 0x2000104 -j RETURN >/dev/null 2>&1 || return 1
    $IPT -C "$_rgco_chain" -p udp --dport 53 -m mark \
        --mark 0x2000104 -j RETURN >/dev/null 2>&1 || return 1
    $IPT -C "$_rgco_chain" -p tcp --dport 53 \
        -j REJECT >/dev/null 2>&1 || return 1
    $IPT -C "$_rgco_chain" -p udp --dport 53 \
        -j REJECT >/dev/null 2>&1 || return 1
    return 0
}

kzv4_raw_guard_wanted() {
    for _rgw_chain in $KZ_RAW_GUARD_CHAINS; do
        kzv4_raw_guard_chain_ok "$_rgw_chain" || continue
        for _rgw_p in tcp udp; do
            $IPT -C OUTPUT -p "$_rgw_p" --dport 53 \
                -j "$_rgw_chain" >/dev/null 2>&1 || return 1
        done
        return 0
    done
    return 1
}

kzv4_raw_guard_remove() {
    for _rgr_chain in $KZ_RAW_GUARD_CHAINS; do
        for _rgr_p in tcp udp; do
            while $IPT -D OUTPUT -p "$_rgr_p" --dport 53 \
                -j "$_rgr_chain" >/dev/null 2>&1; do :; done
        done
        $IPT -F "$_rgr_chain" >/dev/null 2>&1 || true
        $IPT -X "$_rgr_chain" >/dev/null 2>&1 || true
    done
}

apply_dns_v4_raw_guard() {
    # dns4.2.33 (статический аудит, F-01): в режиме DNSv4 немаркированный
    # внешний TCP/UDP 53 закрывается. Разрешены ТОЛЬКО петля (dnsmasq и
    # контроллер; спец-зоны тоже идут через контроллер) и аварийная метка
    # 0x2000104 (у контроллера все апстрим-сокеты маркированы, поэтому
    # других исключений не нужно). Маркированные кандидаты туннеля, как и
    # прежде, уходят через NAT, а при сбое NAT их отклоняют гарды выше.
    # Во время установки/удаления цепочка снимается: установщик сам может
    # временно ходить на публичные резолверы (окно подмены resolv.conf).
    if [ -d /tmp/keenzoo_installing.d ] \
        || [ -f /tmp/keenzoo_installing ] \
        || [ -f /opt/etc/unblock/.disabled ]; then
        kzv4_raw_guard_remove
        return 0
    fi
    kzv4_raw_guard_wanted && return 0
    # dns4.2.37 M-4: стейджинг ВСЕГДА брал имя _NEW. Если активной была
    # именно _NEW-цепочка (нормальное состояние после первого цикла),
    # пересборка делала `-F` по ЖИВОЙ цепочке (окно без защиты) и
    # вставляла второй джамп поверх первого. Теперь стейджинг — то из
    # двух имён, на которое сейчас НЕТ джампа в OUTPUT: чистится и
    # наполняется только неактивная цепочка, переключение атомарно на
    # уровне джампов. Если по какой-то причине джампы есть на обе —
    # стейджингом берётся базовое имя, а цикл снятия «прежних» ниже
    # удаляет ВСЕ джампы на _NEW, разбирая дубли.
    _rg_output_dump="$($IPT -S OUTPUT 2>/dev/null || true)"
    _rg_staging="KZ_DNS_V4_FILTER_NEW"
    case "$_rg_output_dump" in
        *"-j KZ_DNS_V4_FILTER_NEW"*) _rg_staging="KZ_DNS_V4_FILTER" ;;
    esac
    $IPT -N "$_rg_staging" >/dev/null 2>&1 || true
    $IPT -F "$_rg_staging" || return 1
    for _rg_proto in tcp udp; do
        $IPT -A "$_rg_staging" -d 127.0.0.0/8 \
            -p "$_rg_proto" --dport 53 -j RETURN || return 1
        $IPT -A "$_rg_staging" -p "$_rg_proto" --dport 53 \
            -m mark --mark 0x2000104 -j RETURN || return 1
    done
    $IPT -A "$_rg_staging" -p tcp --dport 53 -j REJECT || return 1
    $IPT -A "$_rg_staging" -p udp --dport 53 -j REJECT || return 1
    for _rg_proto in tcp udp; do
        $IPT -I OUTPUT 1 -p "$_rg_proto" --dport 53 \
            -j "$_rg_staging" || {
                # Откат стейджинга без дыры: старые правила не тронуты.
                for _rg_rb in tcp udp; do
                    while $IPT -D OUTPUT -p "$_rg_rb" --dport 53 \
                        -j "$_rg_staging" >/dev/null 2>&1; do :; done
                done
                $IPT -F "$_rg_staging" >/dev/null 2>&1 || true
                $IPT -X "$_rg_staging" >/dev/null 2>&1 || true
                return 1
            }
    done
    # Джамп уже указывает на готовую цепочку — снимаем прежнюю.
    for _rg_chain in $KZ_RAW_GUARD_CHAINS; do
        [ "$_rg_chain" = "$_rg_staging" ] && continue
        for _rg_proto in tcp udp; do
            while $IPT -D OUTPUT -p "$_rg_proto" --dport 53 \
                -j "$_rg_chain" >/dev/null 2>&1; do :; done
        done
        $IPT -F "$_rg_chain" >/dev/null 2>&1 || true
        $IPT -X "$_rg_chain" >/dev/null 2>&1 || true
    done
    return 0
}

apply_dns_filter() {
    # When tunnel DNS is verified, raw external DNS (including user-owned
    # server=/zone/<public-ip> rules) is fail-closed. System DoH/DoT uses
    # TCP/443 or TCP/853 and is redirected separately through the tunnel.
    for _raw_proto in tcp udp; do
        while $IPT -D OUTPUT -d 127.0.0.0/8 -p "$_raw_proto" --dport 53 \
            -j RETURN >/dev/null 2>&1; do :; done
        while $IPT -D OUTPUT -p "$_raw_proto" --dport 53 \
            -j DROP >/dev/null 2>&1; do :; done
    done
    _raw_block="${DNS_TUNNEL_BLOCK_RAW_DNS:-}"
    if [ -z "$_raw_block" ]; then
        _raw_block=0
        if [ "${DNS_TUNNEL_DISABLE:-0}" != 1 ] && dns_snapshot_tunnel >/dev/null; then
            _raw_block=1
        fi
    fi
    [ "${DNS_POLICY_V4:-0}" != 1 ] || _raw_block=0
    if [ "$_raw_block" = "1" ]; then
        for _raw_proto in tcp udp; do
            $IPT -I OUTPUT -d 127.0.0.0/8 -p "$_raw_proto" --dport 53 \
                -j RETURN >/dev/null 2>&1 || exit 1
            $IPT -A OUTPUT -p "$_raw_proto" --dport 53 \
                -j DROP >/dev/null 2>&1 || exit 1
        done
    fi

    if [ "${DNS_POLICY_V4:-0}" = 1 ]; then apply_dns_v4_filter || return 1; fi
    if [ "${DNS_POLICY_V4:-0}" = 1 ]; then apply_dns_v4_raw_guard || return 1; fi

}

apply_dns_nat() {
    # Required even on a cold start before the full hook has run.
    for _dn_rule in lo mark; do
        case "$_dn_rule" in
            lo) set -- -o lo ;;
            mark) set -- -m mark --mark "$XRAY_MARK" ;;
        esac
        if ! $IPT -t nat -C OUTPUT "$@" -j RETURN >/dev/null 2>&1; then
            $IPT -t nat -I OUTPUT "$@" -j RETURN >/dev/null 2>&1 || return 1
        fi
    done
[ "${DNS_POLICY_V4:-0}" != 1 ] || DNS_TUNNEL_DISABLE=1
DNS_TUNNEL_VERIFIED="${DNS_TUNNEL_VERIFIED:-0}"
DNS_TUNNEL_PORT=""
if [ "${DNS_TUNNEL_DISABLE:-0}" != "1" ]; then
    _dns_snapshot_port="$(dns_snapshot_tunnel || true)"
    case "${DNS_TUNNEL_PROTOCOL:-}" in
        xray)
            if [ "$DNS_TUNNEL_VERIFIED" = "1" ] \
                && svc_enabled "$INIT_VLESS" tcp; then
                DNS_TUNNEL_PORT="$PORT_VLESS"
            fi
            ;;
        trojan)
            if [ "$DNS_TUNNEL_VERIFIED" = "1" ] \
                && svc_enabled "$INIT_TROJ" tcp; then
                DNS_TUNNEL_PORT="$PORT_TROJAN"
            fi
            ;;
        hysteria)
            if [ "$DNS_TUNNEL_VERIFIED" = "1" ] \
                && svc_enabled "$INIT_HY" tcp; then
                DNS_TUNNEL_PORT="$PORT_HYSTERIA"
            fi
            ;;
        '') DNS_TUNNEL_PORT="$_dns_snapshot_port" ;;
        *) log_msg "invalid DNS_TUNNEL_PROTOCOL; DNS redirect disabled" ;;
    esac
fi

# Снять старые варианты, включая прежнее правило без --dport.
# dns4.2.38 N-4а: вычистка только при наличии правил набора в дампе —
# под DNSv4 переменная DNS_TUNNEL_PORT всегда пуста, и 9-12 пробных -D
# на каждом проходе были чистой миграцией, которой давно нечего чистить.
_dn_out_dump="$($IPT -t nat -S OUTPUT 2>/dev/null || true)"
case "$_dn_out_dump" in
    *"--match-set unblockdns dst"*)
        for _dns_tunnel_port in "$PORT_VLESS" "$PORT_TROJAN" "$PORT_HYSTERIA"; do
            for _dns_remote_port in 443 853; do
                while $IPT -t nat -D OUTPUT -p tcp --dport "$_dns_remote_port" \
                    -m set --match-set unblockdns dst \
                    -j REDIRECT --to-port "$_dns_tunnel_port" >/dev/null 2>&1; do :; done
            done
            while $IPT -t nat -D OUTPUT -p tcp \
                -m set --match-set unblockdns dst \
                -j REDIRECT --to-port "$_dns_tunnel_port" >/dev/null 2>&1; do :; done
        done
        ;;
esac

if [ -n "$DNS_TUNNEL_PORT" ]; then
    for _dns_remote_port in 443 853; do
        if ! $IPT -t nat -C OUTPUT -p tcp --dport "$_dns_remote_port" \
            -m set --match-set unblockdns dst \
            -j REDIRECT --to-port "$DNS_TUNNEL_PORT" >/dev/null 2>&1; then
            $IPT -t nat -A OUTPUT -p tcp --dport "$_dns_remote_port" \
                -m set --match-set unblockdns dst \
                -j REDIRECT --to-port "$DNS_TUNNEL_PORT" >/dev/null 2>&1 || exit 1
        fi
    done
fi
    if [ "${DNS_POLICY_V4:-0}" = 1 ]; then apply_dns_v4_nat || return 1; fi
    return 0
}

if [ "${DNS_ONLY:-0}" = 1 ]; then
    case "${table:-}" in
        nat) apply_dns_nat ;;
        filter) apply_dns_filter ;;
        *) log_msg "DNS_ONLY requires nat or filter"; exit 1 ;;
    esac
    exit 0
fi

# ── TPROXY: отдельная метка и таблица маршрутизации ──────────────────────
# Маска гарантирует отсутствие пересечения с VPN-метками вида 0xd1001.
# Метка вынесена в старший бит (0x1000000). VPN-марки формируются как
# 0xd<table_id>, где table_id растёт от 1001; начиная с table_id=1100
# значение 0xd1100 задевало бы бит 0x100 и трафик VPN ошибочно уходил
# бы в TPROXY-таблицу. Бит 24 в марки вида 0xdXXXX не попадает никогда.
TPROXY_MARK="0x1000000"
TPROXY_MASK="0x1000000"

# Метка исходящих пакетов самого xray (sockopt.mark в outbound). Служит
# только для RETURN в OUTPUT, чтобы трафик прокси не заворачивался в него
# же. Значение не пересекается ни с TPROXY_MARK, ни с VPN-марками 0xdXXXX.
XRAY_MARK="0x2000000"
TPROXY_TABLE=100
TPROXY_RULE_PRIO=1770

# ── Внутренние (клиентские) интерфейсы ───────────────────────────────────
# Правила обхода обязаны действовать одинаково для LAN, Wi-Fi, гостевой
# сети и для клиентов, подключённых к роутеру по VPN (в т.ч. WireGuard
# сервер прошивки: nwg*, wg*). Список фильтруется по факту существования
# интерфейса, чтобы не плодить мёртвые правила.
LAN_IFACE_PATTERNS="br0 br1 br2 wlan0 wlan1 wlan2 wlan3 nwg0 nwg1 nwg2 wg0 wg1 tun0 tap0 ppp-l2tp0 sstp0"

lan_ifaces() {
    _li_out=""
    _li_links="$(ip -o link show 2>/dev/null | awk -F': ' '{print $2}' \
        | sed 's/@.*//' | tr '\n' ' ')"
    # Prefer the deploy-time configuration when it exists. The parser is
    # intentionally limited to a simple Python list of interface names.
    # Раунд 6, П-17: принадлежность интерфейса — подстановкой case вместо
    # «printf | tr | grep -Fxq» на каждый образец (3 exec × ~19 имён).
    # Имена интерфейсов без пробелов, список разделён пробелами, поэтому
    # «" имя " внутри " списка "» — та же точная проверка. Идиома уже
    # использовалась ниже для дедупа.
    for _li_if in $(sed -n \
        "s/^[[:space:]]*lan_ifaces[[:space:]]*=[[:space:]]*\\[\\(.*\\)\\]/\\1/p" \
        /opt/etc/bot/bot_config.py 2>/dev/null \
        | tr -d "'\"" | tr ',' ' '); do
        case " $_li_links " in
            *" $_li_if "*) _li_out="${_li_out}${_li_out:+ }${_li_if}" ;;
        esac
    done
    for _li_if in $LAN_IFACE_PATTERNS; do
        case " $_li_links " in
            *" $_li_if "*)
                case " $_li_out " in
                    *" $_li_if "*) ;;
                    *) _li_out="${_li_out}${_li_out:+ }${_li_if}" ;;
                esac ;;
        esac
    done

    # Keenetic NDM names its WireGuard interface Wireguard0, while the
    # kernel exposes the same device as nwg0 (confirmed by Test.txt).
    # Discover all currently existing nwg*/wg* devices so a second server
    # interface (nwg1) is covered without hard-coding a stale name.
    #
    # Баг 3 фикс: добавлены серверные туннельные интерфейсы роутера
    # (OpenVPN ovpn*, SSTP sstp*, PPTP pptp*, L2TP l2tp*) — их клиенты
    # раньше полностью выпадали из перехвата. ГОЛЫЙ префикс `ppp` НЕ
    # добавлен сознательно: на Keenetic ppp0 — это обычно WAN-аплинк
    # самого роутера (PPPoE/PPTP/L2TP-клиент), и его перехват давал бы
    # обработку WAN-трафика как клиентского. Исходящие клиентские
    # туннели по-прежнему вычитываются реестром .vpn_client_devs ниже.
    # Раунд 7, П-20: список устройств уже прочитан в _li_links — вместо
    # второго «ip | awk | sed | grep» перебор с тем же фильтром
    # (префиксы и только символы [A-Za-z0-9_.-]).
    for _li_if in $_li_links; do
        case "$_li_if" in
            br*|nwg*|wg*|wlan*|wl*|ra*|guest*|ovpn*|sstp*|pptp*|l2tp*) ;;
            *) continue ;;
        esac
        case "$_li_if" in
            *[!A-Za-z0-9_.-]*) continue ;;
        esac
        case " $_li_out " in
            *" $_li_if "*) ;;
            *) _li_out="${_li_out}${_li_out:+ }${_li_if}" ;;
        esac
    done

    # dns4.2.19: исключить исходящие клиентские туннели (реестр ведёт
    # 100-unblock-vpn.sh, формат "<dev> <rci-id>"): удалённая сторона
    # такого туннеля — не LAN-клиенты, иначе она получала бы перехват
    # DNS/TCP в наши прокси и ACCEPT веб-порта панели в секции 8.
    # Фильтр строго read-only: мутация реестра — только в путях up/down
    # хука 100-unblock-vpn.sh, не из accessor-а.
    if [ -f /opt/etc/unblock/.vpn_client_devs ]; then
        _li_vpn_devs=" $(awk '{print $1}' \
            /opt/etc/unblock/.vpn_client_devs 2>/dev/null | tr '\n' ' ') "
        if [ "$_li_vpn_devs" != "  " ]; then
            _li_filtered=""
            for _li_cand in $_li_out; do
                case "$_li_vpn_devs" in
                    *" $_li_cand "*) continue ;;
                esac
                _li_filtered="${_li_filtered}${_li_filtered:+ }${_li_cand}"
            done
            _li_out="$_li_filtered"
        fi
    fi

    # No br0 fallback: applying a rule to a guessed interface is worse than
    # temporarily having no client redirect during early boot.
    printf '%s\n' "$_li_out"
}

LAN_IFACES="$(lan_ifaces)"

# Use the configured routerip when it is actually assigned, otherwise
# discover a private address on the detected LAN interfaces. This supports
# non-br0 Keenetic layouts without trusting an arbitrary WAN address.
CONFIG_ROUTER_IP="${ROUTER_IP:-}"
if [ -z "$CONFIG_ROUTER_IP" ] && [ -f /opt/etc/bot/bot_config.py ]; then
    # Раунд 7, П-19: общий помощник (одинарные и двойные кавычки)
    # вместо двух отдельных седов.
    CONFIG_ROUTER_IP="$(config_string routerip '')"
fi
local_ip=""
if printf '%s\n' "$CONFIG_ROUTER_IP" | awk -F. \
    'NF==4 && $1 <= 255 && $2 <= 255 && $3 <= 255 && $4 <= 255 {ok=1} END{exit !ok}' \
    && ip -4 addr show 2>/dev/null | grep -q "[[:space:]]$CONFIG_ROUTER_IP/"; then
    local_ip="$CONFIG_ROUTER_IP"
fi
if [ -z "$local_ip" ]; then
    for _lip_if in $LAN_IFACES; do
        _lip_candidate="$(ip -4 addr show "$_lip_if" 2>/dev/null \
            | awk '/inet /{print $2}' | cut -d/ -f1 \
            | grep -E '^(192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)' \
            | head -n1)"
        if [ -n "$_lip_candidate" ]; then
            local_ip="$_lip_candidate"
            break
        fi
    done
fi

# ═════════════════════════════════════════════════════════════════════════
# 8. Доступ к веб-панели: только из локальных сетей
# ═════════════════════════════════════════════════════════════════════════
# Правила ставятся здесь, а не только при старте панели: Keenetic
# пересоздаёт цепочки при смене состояния интерфейсов и вызывает этот хук,
# после чего разрешающие правила панели пропадали и она становилась
# недоступной из LAN до перезапуска S99generator.
# Разрешение выдаётся по loopback и фактическим внутренним интерфейсам.
# Это закрывает WAN spoofing даже при RFC1918 source address.
if [ "${table:-}" = "filter" ]; then
    apply_dns_filter

    # dns4.2.38 N-3: миграционная вычистка устаревших «-s <сеть>»
    # разрешений (66 пробных -D на каждое событие) запускается только
    # при наличии сигнатуры в дампе. Ложное срабатывание гейта (чужое
    # правило с той же сетью) лишь возвращает прежнее поведение.
    _kz_in_dump="$($IPT -S INPUT 2>/dev/null || true)"
    _kz_legacy_src=0
    for _kz_net in $LOCAL_NETS; do
        case "$_kz_in_dump" in
            *"-s $_kz_net "*) _kz_legacy_src=1; break ;;
        esac
    done

    # Remove legacy source-only accepts. A private source address arriving
    # from WAN is not a trustworthy LAN identity.
    while $IPT -D INPUT -p tcp --dport "$PORT_WEB" -j DROP >/dev/null 2>&1; do :; done
    if [ "$_kz_legacy_src" = 1 ]; then
        for web_net in $LOCAL_NETS; do
            while $IPT -D INPUT -p tcp --dport "$PORT_WEB" -s "$web_net" \
                -j ACCEPT >/dev/null 2>&1; do :; done
        done
    fi
    if ! $IPT -C INPUT -i lo -p tcp --dport "$PORT_WEB" -j ACCEPT >/dev/null 2>&1; then
        $IPT -I INPUT -i lo -p tcp --dport "$PORT_WEB" -j ACCEPT >/dev/null 2>&1 || exit 1
    fi
    for web_if in $LAN_IFACES; do
        if ! $IPT -C INPUT -i "$web_if" -p tcp --dport "$PORT_WEB" -j ACCEPT >/dev/null 2>&1; then
            $IPT -I INPUT -i "$web_if" -p tcp --dport "$PORT_WEB" -j ACCEPT >/dev/null 2>&1 || exit 1
        fi
    done
    $IPT -A INPUT -p tcp --dport "$PORT_WEB" -j DROP >/dev/null 2>&1 || exit 1

    # ─────────────────────────────────────────────────────────────────
    # Прокси-порты: закрыть от WAN (defense-in-depth).
    # ─────────────────────────────────────────────────────────────────
    # ss-redir, tor, xray, trojan и hysteria слушают 0.0.0.0, потому что
    # принимают перехваченный трафик со всех внутренних интерфейсов.
    # Своих правил INPUT у них не было — защищал только межсетевой экран
    # прошивки. При случайном пробросе порта или его отключении роутер
    # превратился бы в открытый прокси-релей.
    #
    # Разрешение выдаётся только через loopback и фактически существующие
    # внутренние интерфейсы; source CIDR alone is deliberately not trusted.
    # DROP всегда добавляется последним, поэтому отсутствие LAN-интерфейса
    # в ранней загрузке оставляет порт закрытым.
    for proxy_port in "$PORT_SS" "$PORT_TOR" "$PORT_VLESS" \
        "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        for proxy_proto in tcp udp; do
            # Снять прежний DROP, чтобы он снова оказался последним.
            while $IPT -D INPUT -p "$proxy_proto" \
                --dport "$proxy_port" -j DROP >/dev/null 2>&1
            do
                :
            done

            if ! $IPT -C INPUT -i lo -p "$proxy_proto" \
                --dport "$proxy_port" -j ACCEPT >/dev/null 2>&1
            then
                $IPT -I INPUT -i lo -p "$proxy_proto" \
                    --dport "$proxy_port" -j ACCEPT \
                    >/dev/null 2>&1 || true
            fi

            for proxy_if in $LAN_IFACES; do
                if ! $IPT -C INPUT -i "$proxy_if" -p "$proxy_proto" \
                    --dport "$proxy_port" -j ACCEPT >/dev/null 2>&1
                then
                    $IPT -I INPUT -i "$proxy_if" -p "$proxy_proto" \
                        --dport "$proxy_port" -j ACCEPT \
                        >/dev/null 2>&1 || true
                fi
            done

            # Remove legacy source-only accepts so a spoofed RFC1918
            # source from WAN cannot reach a local proxy listener.
            if [ "$_kz_legacy_src" = 1 ]; then
                for proxy_net in $LOCAL_NETS; do
                    while $IPT -D INPUT -p "$proxy_proto" \
                        --dport "$proxy_port" -s "$proxy_net" \
                        -j ACCEPT >/dev/null 2>&1; do :; done
                done
            fi

            $IPT -A INPUT -p "$proxy_proto" \
                --dport "$proxy_port" -j DROP \
                >/dev/null 2>&1 \
                || log_msg "INPUT DROP failed: $proxy_proto/$proxy_port"
        done
    done
fi

# dns4.2.65 R27-03 (аудит раунда 27, R26-03): аварийный безмножественный
# подпор — одна проверяемая функция. Гарантируется существование цепочки
# (возврат осиротевшей «_OLD» переименованием или создание), ошибки
# добавления правил НЕ подавляются, план сверяется с фактом, прыжок
# вставляется только при полном плане. Неудача — возврат 1, причина
# «emergency-guard-failed»; сообщение об успехе без верификации
# запрещено.
#
# Н-7 (аудит раунда 27; раунды 29-30): одноразовый фоновый повтор через
# 90 с взводится обёрткой при ЛЮБОМ исходе сборки (кроме «noretry» и
# самого повторного прогона), выполняет нат-прогон, затем фильтровый,
# и перед фазами ждёт освобождения общего лока: событие netfilter может
# не прийти часами, а подпор режет весь форвардный UDP с LAN.
_eug_build() {
    # 4.2.72 П-1 (аудит поведения при деградации): аварийный подпор
    # сужен до udp/443. Прежде правило без множеств и без порта
    # («-i <LAN> -p udp -j REJECT») на прошивке без xt_set/xt_TPROXY
    # резало ВЕСЬ форвардный UDP клиентов — QUIC, VoIP, игры,
    # клиентские VPN, NTP — при живом TCP. Основной канал утечки
    # политики в обход туннеля — QUIC (udp/443); его и отбиваем.
    # Прочий UDP клиентов возвращается; цена — неперехваченный UDP
    # списков на нестандартных портах уйдёт напрямую (зафиксировано).
    # dns4.2.66 R27-01/R28-05 (final-аудит и аудит раунда 28): план
    # считается по числу интерфейсов НЕЗАВИСИМО от исхода «-A».
    # Семантика владельца — жёсткая (С-А): отказ хотя бы одного
    # правила очищает цепочку и прыжок не ставится; частичная цепочка
    # с прыжком оставляла бы один из LAN молча без защиты. Исход
    # всегда честен; повтор взводится обёрткой при ЛЮБОМ исходе.
    if ! $IPT -t filter -L KZ_UDP_FAILCLOSED -n >/dev/null 2>&1; then
        $IPT -t filter -E KZ_UDP_FAILCLOSED_OLD KZ_UDP_FAILCLOSED \
                >/dev/null 2>&1 \
            || $IPT -t filter -N KZ_UDP_FAILCLOSED >/dev/null 2>&1 \
            || return 1
    fi
    $IPT -t filter -F KZ_UDP_FAILCLOSED >/dev/null 2>&1 || return 1
    _eug_want=0
    _eug_ok=1
    for _eug_if in $LAN_IFACES; do
        _eug_want=$((_eug_want + 1))
        if ! $IPT -t filter -A KZ_UDP_FAILCLOSED -i "$_eug_if" -p udp \
                --dport 443 \
                -j REJECT --reject-with icmp-port-unreachable \
                >/dev/null 2>&1; then
            _eug_ok=0
            log_msg "UDP fail-closed: ядро отвергло аварийный REJECT для $_eug_if"
        fi
    done
    if [ "$_eug_want" -eq 0 ] || [ "$_eug_ok" -ne 1 ]; then
        # Неполный план: цепочка очищается, прыжок не ставится.
        $IPT -t filter -F KZ_UDP_FAILCLOSED >/dev/null 2>&1 || true
        log_msg "UDP fail-closed: аварийный подпор неполон — правил 0 из $_eug_want, цепочка очищена"
        return 1
    fi
    _eug_built="$($IPT -t filter -S KZ_UDP_FAILCLOSED 2>/dev/null \
        | grep -c -- '-j REJECT' || true)"
    [ "${_eug_built:-0}" -eq "$_eug_want" ] || return 1
    if ! $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED \
            >/dev/null 2>&1; then
        $IPT -t filter -I FORWARD 1 -j KZ_UDP_FAILCLOSED \
            >/dev/null 2>&1 || return 1
    fi
    return 0
}

_eug_arm_retry() {
    # dns4.2.67 R29-01/R28-P1 (аудиты раунда 29): планировщик повтора
    # вынесен из тела построения — прежде все ранние «return 1»
    # аварийной сборки выходили ДО него, и защита оставалась нулевой
    # без самовосстановления до внешнего события. Взводится при любом
    # исходе построения (кроме «noretry» и самого повторного прогона).
    #
    # Маркер хранится в /tmp, имя — по восстанавливаемой ветке.
    _eug_retry_marker="/tmp/keenzoo.netfilter.emergency.filter"
    # dns4.2.68 R29-P3-02 (аудит раунда 30, final): коллизия пути
    # маркера (обычный файл, битая символическая ссылка) и отказ его
    # создания не должны молча отключать повтор — неуспех взвода
    # сообщается явно (retry-arm-failed).
    if { [ -e "$_eug_retry_marker" ] || [ -L "$_eug_retry_marker" ]; } \
            && [ ! -d "$_eug_retry_marker" ]; then
        log_msg "КРИТИЧНО: повтор подпора не взведён (retry-arm-failed) — путь маркера занят не каталогом"
        return 1
    fi
    # dns4.2.66 R28-07 (аудит раунда 28, v25): устаревший маркер
    # (подоболочка убита извне) снимается по возрасту, иначе повтор
    # молча не взводился бы никогда.
    # dns4.2.70 R30-P3-02 (аудит раунда 32, final): порог 600 с —
    # легитимная жизнь воркера теперь до ~450 с (90 с задержка +
    # до 240 с ожидание лока + хук-ожидания фаз); при 180 с живой
    # воркер принимался за мёртвого и снимался конкурирующим взводом.
    if [ -d "$_eug_retry_marker" ]; then
        _eug_age="$(( $(date +%s 2>/dev/null || echo 0) \
            - $(stat -c %Y "$_eug_retry_marker" 2>/dev/null || echo 0) ))"
        if [ "${_eug_age:-0}" -gt 600 ]; then
            rm -rf "$_eug_retry_marker" 2>/dev/null || true
            log_msg "UDP fail-closed: устаревший маркер повтора снят (возраст ${_eug_age} с)"
        else
            log_msg "UDP fail-closed: повтор уже запланирован"
            return 0
        fi
    fi
    if ! mkdir "$_eug_retry_marker" 2>/dev/null; then
        log_msg "КРИТИЧНО: повтор подпора не взведён (retry-arm-failed) — маркер не создан ($_eug_retry_marker)"
        return 1
    fi
    # dns4.2.70 R30-P3-02 (аудит раунда 32, final): токен владения —
    # трап снимает маркер только если он всё ещё принадлежит этому
    # воркеру; перевзведённый (чужой) маркер не удаляется.
    _eug_token="$(date +%s 2>/dev/null || echo 0).$$"
    printf '%s' "$_eug_token" > "$_eug_retry_marker/.owner" \
        2>/dev/null || true
    # 4.2.72 П-2 (аудит поведения при деградации): запуск повтора.
    # Если доступен setsid, повтор уходит в НОВУЮ СЕССИЮ повторным
    # входом в хук с флагом раннера (обработка — сразу после этого
    # определения): убийство группы процессов хука по таймауту
    # события запланированное восстановление не снимет. Нет setsid
    # (в BusyBox прошивки его обычно нет, как и nohup) — прежний
    # запуск подоболочкой: штатный выход родителя она переживает,
    # риск остаётся только у принудительного убийства группы.
    if command -v setsid >/dev/null 2>&1; then
        KEENZOO_EMERGENCY_RETRY_RUNNER=1 setsid /bin/sh "$0" \
            >/dev/null 2>&1 </dev/null &
    else
        ( _eug_retry_body ) >/dev/null 2>&1 </dev/null &
    fi
    log_msg "UDP fail-closed: через 90 с будет выполнен одноразовый повтор (нат, затем фильтр)"
    return 0
}

_eug_retry_body() {
    # 4.2.72 П-2: тело одноразового аварийного повтора. Вызывается
    # либо подоболочкой взвода (нет setsid), либо откреплённым
    # раннером (повторный вход в хук с KEENZOO_EMERGENCY_RETRY_RUNNER=1;
    # раннер задаёт «_eug_retry_marker» и несовпадающий «_eug_token»,
    # поэтому его трап маркер не снимает — владелец маркера прежний
    # воркер взвода).
    trap '[ "$(cat "$_eug_retry_marker/.owner" 2>/dev/null || true)" = "$_eug_token" ] && rm -rf "$_eug_retry_marker" 2>/dev/null || true' EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM
    trap 'exit 129' HUP
    sleep 90
    # dns4.2.68 R30-01/R29-P2-01 (аудиты раунда 30): фазы шли бы при
    # занятом общем локе с исходом 75. Перед фазами ждём освобождения
    # лока тем же приёмом, что штатный повтор занятого лока
    # (до 120 × 2 с = 240 с); лок обычно держит обновление
    # списков, стартующее вместе с контроллером.
    _eug_w=0
    while [ "$_eug_w" -lt 120 ] && netfilter_lock_owner_live; do
        sleep 2
        _eug_w=$((_eug_w + 1))
    done
    # dns4.2.67 R28-M2 (final-аудит раунда 29, решение
    # владельца): повтор — ограниченный нат-прогон (пересборка
    # и сверка .tproxy_state по факту), затем фильтровый
    # (пересборка backstop и снятие подпора). Итоги обеих фаз
    # логируются; снятие подпора определяет финальный фильтр.
    _eug_nat_rc=0
    _eug_filter_rc=0
    # dns4.2.69 R31-03 (аудит раунда 31, v28): среда взвода не должна
    # приходить в фазы («лок держит родитель, не брать») — повтор
    # берёт лок сам, ожидание (Р30-01) работает для всех источников.
    #
    # dns4.2.70 R30-P2-01 (аудит раунда 32, final): фазы идут
    # под НОВЫМ флагом «аварийный повтор», а не под
    # «KEENZOO_NETFILTER_RETRY». Лок-слой хука гейтит свой
    # ограниченный повтор только по второму, поэтому при 75
    # любой фазы (лок жив после 240 с ожидания или взят в
    # зазоре ТОСТУ) штатный повтор таблицы взводится сам и
    # доводит её после освобождения лока — передача вместо
    # потерянного восстановления.
    # РАУД 36 / повторный аудит раунда 2, F-Н2 (критично): фазы
    # ОБЯЗАНЫ стартовать с нулевым флагом раннера. Иначе флаг
    # «_RUNNER=1», унаследованный от раннера, приводил фазовый
    # подпроцесс в гейт «_RUNNER=1 → тело», и фаза вместо
    # применения правил снова запускала фазы — удвоение процессов
    # каждые 90 с (геометрический рост), нат/фильтр не применялись.
    KEENZOO_EMERGENCY_RETRY_RUNNER=0 KEENZOO_UPDATE_LOCK_HELD=0 KEENZOO_EMERGENCY_RETRY=1 type=iptable table=nat \
        /bin/sh "$0" >/dev/null 2>&1 || _eug_nat_rc=$?
    KEENZOO_EMERGENCY_RETRY_RUNNER=0 KEENZOO_UPDATE_LOCK_HELD=0 KEENZOO_EMERGENCY_RETRY=1 type=iptable table=filter \
        /bin/sh "$0" >/dev/null 2>&1 || _eug_filter_rc=$?
    log_msg "UDP fail-closed: одноразовый повтор выполнен: нат=$_eug_nat_rc фильтр=$_eug_filter_rc"
}

# 4.2.72 П-2: обработка откреплённого раннера повтора — повторный
# вход в хук с флагом, без «type»/«table». Лок раннер не берёт
# (гейт взвода ниже по файлу), снапшоты не снимает (гейт секции
# снапшотов), секции применения пропускаются из-за пустого «table»;
# фазы тела возьмут лок сами. Токен намеренно не совпадает с токеном
# воркера взвода: маркер снимает только владелец.
# РАУД 36 / повторный аудит раунда 2, F-Н2 (критично): вход в тело
# — только при пустом «table». Раннер стартует без «table»; фаза с
# ошибочно живым флагом раннера всё равно уйдёт по табличным
# секциям (санитаризация ниже — второй слой защиты).
if [ "${KEENZOO_EMERGENCY_RETRY_RUNNER:-0}" = "1" ] && [ -z "${table:-}" ]; then
    _eug_retry_marker="/tmp/keenzoo.netfilter.emergency.filter"
    _eug_token="runner.$$"
    # Второй слой: флаг раннера не течёт дальше по дереву — тело и
    # его фазы живут уже с нулевым флагом, даже если префиксы фаз
    # когда-либо изменятся.
    KEENZOO_EMERGENCY_RETRY_RUNNER=0
    export KEENZOO_EMERGENCY_RETRY_RUNNER
    _eug_retry_body
    exit 0
fi

install_emergency_udp_guard() {
    # dns4.2.67 R29-01/R28-P1 (аудиты раунда 29): обёртка. Построение
    # и планировщик разделены: повтор взводится при любом исходе,
    # кроме «noretry» (нет xt_set до перезагрузки) и самого повторного
    # прогона. Код возврата — исход построения.
    _eug_mode="${1:-allow}"
    if _eug_build; then
        _eug_rc=0
    else
        _eug_rc=1
    fi
    if [ "$_eug_mode" != "noretry" ] \
            && [ "${KEENZOO_NETFILTER_RETRY:-0}" != "1" ] \
            && [ "${KEENZOO_EMERGENCY_RETRY:-0}" != "1" ]; then
        _eug_arm_retry
    fi
    return "$_eug_rc"
}

# dns4.2.57 H-11: fail-closed backstop для UDP ресурсов, чей UDP обязан
# идти в туннель. Перехваченные TPROXY пакеты маршрутизируются локально и
# до FORWARD не доходят; сюда попадают ТОЛЬКО неперехваченные. При
# деградации TPROXY (нет расширения ядра, нет набора, правило отвергнуто)
# такой UDP не уходит молча напрямую в WAN, а отвергается с
# icmp-port-unreachable: приложение получает быстрый отказ вместо тихой
# утечки. Гейтинг — по фактически включённым сервисам: для намеренно
# выключенного сервиса прямой UDP разрешён, как и прямой TCP.
if [ "${table:-}" = "filter" ]; then
    if ipt_has_match "$IPT_BIN" set; then
        # dns4.2.61 Х-04 (аудит раунда 23, RU_CURRENT H-04): цепочка
        # больше не перестраивается «на живую». Раньше живая цепочка
        # сначала очищалась, правила добавлялись по одному, и при
        # ошибке защита снималась ПОЛНОСТЬЮ при коде выхода 0.
        # Теперь: план собирается и строится в новой цепочке,
        # проверяется счётчиком правил, и только затем атомарно
        # переносится в живую. Сбой сборки оставляет ПРЕЖНЮЮ цепочку
        # нетронутой и даёт ненулевой код.
        $IPT -t filter -N KZ_UDP_FAILCLOSED >/dev/null 2>&1 || true
        $IPT -t filter -N KZ_UDP_FAILCLOSED_NEW >/dev/null 2>&1 \
            || $IPT -t filter -F KZ_UDP_FAILCLOSED_NEW >/dev/null 2>&1
        _kz_uf_ok=1
        _kz_uf_plan_count=0
        for _kz_uf in "unblocksh:${PORT_SS}:${INIT_SS}" \
                      "unblockvless:${PORT_VLESS}:${INIT_VLESS}" \
                      "unblockhysteria:${PORT_HYSTERIA}:${INIT_HY}"; do
            _kz_uf_set="${_kz_uf%%:*}"
            _kz_uf_rest="${_kz_uf#*:}"
            _kz_uf_port="${_kz_uf_rest%%:*}"
            _kz_uf_init="${_kz_uf_rest#*:}"
            # dns4.2.60 Х-07 (аудит 2026-09-29, H-07): backstop живёт по
            # политике, а не по живости процесса: смерть сервиса не
            # превращает политику в обход.
            # К-5 (4.2.61): настроенность проверяется маркером внутри.
            svc_policy_enabled "$_kz_uf_init" || continue
            if ! ipset list -n "$_kz_uf_set" >/dev/null 2>&1; then
                # dns4.2.63 Х-05 (аудит раунда 25, RU_R23 H-05):
                # отсутствующий НАСТРОЕННЫЙ набор — не «пропускаем и
                # зелёный итог», а сбой сборки: сервис остался бы без
                # UDP fail-closed молча. Причина пишется в файл
                # состояния одной строкой (черновик принадлежит
                # нат/мангл-пути; ближайший нат-прогон пересоберёт файл
                # целиком по фактическим правилам).
                log_msg "UDP fail-closed: набор $_kz_uf_set отсутствует — защита для него не может быть построена"
                _kz_uf_note="fail - - - missing-$_kz_uf_set udp_policy=DEGRADED_443_ONLY"
                if [ "$(tail -n 1 /opt/etc/unblock/.tproxy_state 2>/dev/null)" != "$_kz_uf_note" ]; then
                    printf '%s\n' "$_kz_uf_note" \
                        >> /opt/etc/unblock/.tproxy_state 2>/dev/null || true
                fi
                _kz_uf_ok=0
                _kz_uf_reason="missing-$_kz_uf_set"
                break
            fi
            for _kz_uf_if in $LAN_IFACES; do
                if ! $IPT -t filter -A KZ_UDP_FAILCLOSED_NEW \
                        -i "$_kz_uf_if" -p udp \
                        -m set --match-set "$_kz_uf_set" dst \
                        -j REJECT --reject-with icmp-port-unreachable \
                        >/dev/null 2>&1; then
                    log_msg "UDP fail-closed: правило для $_kz_uf_set/$_kz_uf_if отвергнуто"
                    _kz_uf_ok=0
                    break
                fi
                _kz_uf_plan_count=$((_kz_uf_plan_count + 1))
            done
            [ "$_kz_uf_ok" -eq 1 ] || break
        done
        # Верификация сборки: фактическое число правил в новой цепочке
        # обязано совпасть с планом.
        if [ "$_kz_uf_ok" -eq 1 ]; then
            _kz_uf_built="$($IPT -t filter -S KZ_UDP_FAILCLOSED_NEW 2>/dev/null \
                | grep -c -- '-j REJECT' || true)"
            [ "${_kz_uf_built:-0}" -eq "$_kz_uf_plan_count" ] || _kz_uf_ok=0
        fi
        if [ "$_kz_uf_ok" -eq 1 ] && [ "$_kz_uf_plan_count" -gt 0 ]; then
            # dns4.2.64 К-2 (аудиты раунда 26, P0-02): перенос — атомарное
            # ПЕРЕИМЕНОВАНИЕ: живая цепочка становится старой,
            # проверенная новая — живой. ВАЖНАЯ семантика «-E»: ссылки
            # «-j» следуют за ПЕРЕИМЕНОВАННОЙ цепочкой (подтверждено на
            # реальной iptables) — после первого «-E» прыжок FORWARD
            # указывает на «…_OLD» и держит ПРЕЖНИЕ рабочие правила.
            # Отсюда два следствия: новый прыжок добавляется только
            # вперёд, а старые прыжок/цепочка снимаются ТОЛЬКО после
            # подтверждённого нового прыжка. Прежде «-OLD» удалялась
            # безусловно — при отказе вставки прыжка уничтожалась
            # последняя работающая защита.
            #
            # Восстановление после незавершённого прошлого обмена:
            # если «_OLD» существует, прошлый обмен остановился.
            if $IPT -t filter -L KZ_UDP_FAILCLOSED_OLD -n \
                    >/dev/null 2>&1; then
                if $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED_OLD \
                        >/dev/null 2>&1; then
                    # Прошлый обмен выполнен, но прыжок на новую живую
                    # цепочку не вставлен. Доводим: прыжок вперёд — и
                    # старое снимается.
                    if $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED \
                            >/dev/null 2>&1 \
                            || $IPT -t filter -I FORWARD 1 \
                                -j KZ_UDP_FAILCLOSED >/dev/null 2>&1; then
                        while $IPT -t filter -D FORWARD \
                                -j KZ_UDP_FAILCLOSED_OLD \
                                >/dev/null 2>&1; do :; done
                        $IPT -t filter -F KZ_UDP_FAILCLOSED_OLD \
                            >/dev/null 2>&1 || true
                        $IPT -t filter -X KZ_UDP_FAILCLOSED_OLD \
                            >/dev/null 2>&1 || true
                    else
                        # Прыжок снова не вставился: защита работает
                        # через «_OLD», прогон с деградацией.
                        _kz_uf_ok=0
                        _kz_uf_reason="${_kz_uf_reason:-forward-jump-rejected}"
                        log_msg "UDP fail-closed: прыжок к новой цепочке не вставлен повторно — старая защита в _OLD сохранена"
                    fi
                else
                    # Прыжка на «_OLD» нет — осиротевший хвост прошлого
                    # обмена; снимаем и строим обмен заново.
                    $IPT -t filter -F KZ_UDP_FAILCLOSED_OLD \
                        >/dev/null 2>&1 || true
                    $IPT -t filter -X KZ_UDP_FAILCLOSED_OLD \
                        >/dev/null 2>&1 || true
                fi
            fi
            _kz_uf_swapped=0
            if [ "$_kz_uf_ok" -eq 1 ] \
                    && $IPT -t filter -E KZ_UDP_FAILCLOSED KZ_UDP_FAILCLOSED_OLD \
                        >/dev/null 2>&1; then
                if $IPT -t filter -E KZ_UDP_FAILCLOSED_NEW KZ_UDP_FAILCLOSED \
                        >/dev/null 2>&1; then
                    _kz_uf_swapped=1
                else
                    # Вернуть живую цепочку на место; новая остаётся в
                    # своей и будет вычищена ниже.
                    $IPT -t filter -E KZ_UDP_FAILCLOSED_OLD KZ_UDP_FAILCLOSED \
                        >/dev/null 2>&1 || true
                fi
            fi
            if [ "$_kz_uf_swapped" -eq 1 ]; then
                if ! $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED \
                        >/dev/null 2>&1; then
                    $IPT -t filter -I FORWARD 1 -j KZ_UDP_FAILCLOSED \
                        >/dev/null 2>&1 || _kz_uf_ok=0
                fi
                if [ "$_kz_uf_ok" -eq 1 ]; then
                    # Новый прыжок подтверждён — старые снимаются.
                    while $IPT -t filter -D FORWARD -j KZ_UDP_FAILCLOSED_OLD \
                            >/dev/null 2>&1; do :; done
                    $IPT -t filter -F KZ_UDP_FAILCLOSED_OLD \
                        >/dev/null 2>&1 || _kz_uf_ok=0
                    $IPT -t filter -X KZ_UDP_FAILCLOSED_OLD \
                        >/dev/null 2>&1 || _kz_uf_ok=0
                else
                    # К-2: вставка прыжка отказала. «_OLD» с прыжком
                    # НЕ трогается: защита продолжает работать старыми
                    # правилами, прогон сообщит деградацию (код 4).
                    _kz_uf_reason="${_kz_uf_reason:-forward-jump-rejected}"
                    log_msg "UDP fail-closed: прыжок к новой цепочке не вставлен — прежняя защита сохранена в _OLD"
                fi
            elif [ "$_kz_uf_ok" -eq 1 ]; then
                # dns4.2.64 К-2: переименование недоступно (нет «-E» или
                # живая цепочка отсутствовала). ПРЕЖНЯЯ политика
                # остаётся на месте, прогон с деградацией. Старый
                # фолбэк «очистка живой цепочки + построчный повтор»
                # не был атомарным: обрыв на середине оставлял цепочку
                # полупустой (открытый канал), прежние правила были
                # безвозвратно потеряны.
                _kz_uf_ok=0
                _kz_uf_reason="${_kz_uf_reason:-rename-unavailable}"
                log_msg "UDP fail-closed: переименование цепочки недоступно — прежняя политика сохранена, прогон с деградацией"
            fi
        fi
        $IPT -t filter -F KZ_UDP_FAILCLOSED_NEW >/dev/null 2>&1 || true
        $IPT -t filter -X KZ_UDP_FAILCLOSED_NEW >/dev/null 2>&1 || true
        # dns4.2.64 К-1/К-2 (аудиты раунда 26): три независимые ветки:
        # успешный план — прыжок обязан быть; пустой успешный план —
        # прыжок снимается; любой сбой — прежняя защита не трогается,
        # код 4. Прежде сбой с нулевым счётчиком плана уходил в ветку
        # «пусто штатно» и снимал защиту (В-1), а отказ вставки прыжка
        # давал «exit 1» с потерей уже применённых защит прогона.
        if [ "$_kz_uf_ok" -eq 1 ] && [ "$_kz_uf_plan_count" -gt 0 ]; then
            if ! $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED >/dev/null 2>&1; then
                $IPT -t filter -I FORWARD 1 -j KZ_UDP_FAILCLOSED \
                    >/dev/null 2>&1 || _kz_uf_ok=0
            fi
        fi
        if [ "$_kz_uf_ok" -eq 1 ] && [ "$_kz_uf_plan_count" -eq 0 ]; then
            # dns4.2.64 К-1 (аудиты раунда 26, В-1/P0-01): «правил нет
            # штатно» — ТОЛЬКО при успешной сборке. Прежде условие
            # смотрело один счётчик: сбой до первого правила
            # (отсутствующий набор ПЕРВОГО настроенного сервиса)
            # уходил в эту ветку, живая цепочка очищалась, прыжок
            # снимался, код был 0 — fail-open. Теперь такой сбой
            # падает в ветку ниже: прежняя цепочка цела, код 4.
            # Прямой UDP разрешён, как и прямой TCP. Снимаем возможный
            # прыжок от прошлого события.
            $IPT -t filter -F KZ_UDP_FAILCLOSED >/dev/null 2>&1 || true
            while $IPT -t filter -D FORWARD -j KZ_UDP_FAILCLOSED \
                    >/dev/null 2>&1; do :; done
        fi
        if [ "$_kz_uf_ok" -ne 1 ]; then
            # Сбой сборки/переноса: прежняя цепочка осталась на месте.
            # Защита не снята, но и не обновлена — сообщаем аварийно,
            # вместо прежнего молчаливого «успеха».
            # dns4.2.62 С-2 (аудит раунда 24, v22): деградация
            # ОДНОЙ подсистемы не должна откатывать весь прогон —
            # прежний «exit 1» поднимал трап, и терялись уже
            # применённые в этом прогоне DNS-гард и INPUT-защита.
            # Флаг сохраняет вычистку/снимки, код 4 вызывающие
            # трактуют как «применено с деградацией».
            log_msg "UDP fail-closed: перестройка не завершена — прежняя цепочка сохранена"
            # dns4.2.65 R27-03 (аудит раунда 27, R26-03): если защиты
            # нет ВОВСЕ (ни живой цепочки, ни прыжка) — аварийный
            # подпор ставится проверяемой функцией; успех без
            # верификации не сообщается, неудача меняет причину.
            if ! $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED \
                    >/dev/null 2>&1 \
                    && ! $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED_OLD \
                    >/dev/null 2>&1; then
                if install_emergency_udp_guard; then
                    log_msg "UDP fail-closed: живых правил не было — поставлен и проверен аварийный безмножественный отбой udp/443 с LAN"
                else
                    _kz_uf_reason="emergency-guard-failed"
                    log_msg "КРИТИЧНО: аварийный безмножественный подпор не построен — ручной разбор обязателен"
                fi
            fi
            # Причина деградации — в файл состояния (одна строка;
            # черновик принадлежит нат/мангл-пути, ближайший нат-прогон
            # пересоберёт файл по фактическим правилам). Пишется ПОСЛЕ
            # аварийного подпора: его неудача уточняет причину.
            _kz_uf_note="fail - - - ${_kz_uf_reason:-backstop-build-failed} udp_policy=DEGRADED_443_ONLY"
            if [ "$(tail -n 1 /opt/etc/unblock/.tproxy_state 2>/dev/null)" != "$_kz_uf_note" ]; then
                printf '%s\n' "$_kz_uf_note" \
                    >> /opt/etc/unblock/.tproxy_state 2>/dev/null || true
            fi
            NETFILTER_PRESERVE_FAILCLOSED=1
            exit 4
        fi
    else
        # dns4.2.63 Х-05 (аудит раунда 25, RU_R23 H-05): xt_set
        # недоступен. Если настроенных сервисов нет — защита и не
        # нужна (тихий пропуск). Если есть — это деградация с причиной,
        # а не молчаливый успех: прямой UDP для настроенной политики
        # оставался бы открытым при зелёных итогах у вызывающих.
        _kz_uf_want=0
        for _kz_uf_c in "$INIT_SS" "$INIT_VLESS" "$INIT_HY"; do
            if svc_policy_enabled "$_kz_uf_c"; then
                _kz_uf_want=1
            fi
        done
        if [ "$_kz_uf_want" -eq 1 ]; then
            log_msg "UDP fail-closed: xt_set недоступен — защита для настроенных сервисов не может быть построена"
            _kz_uf_note="fail - - - xt_set-unavailable udp_policy=DEGRADED_443_ONLY"
            if [ "$(tail -n 1 /opt/etc/unblock/.tproxy_state 2>/dev/null)" != "$_kz_uf_note" ]; then
                printf '%s\n' "$_kz_uf_note" \
                    >> /opt/etc/unblock/.tproxy_state 2>/dev/null || true
            fi
            # dns4.2.64 К-2 → dns4.2.65 R27-03: тот же аварийный
            # подпор — если защиты нет вовсе, форвардный UDP с LAN
            # отбивается без множеств. Цепочка здесь могла ещё не
            # создаваться (создание живёт в ветке доступного
            # «xt_set») — функция гарантирует её наличие.
            if ! $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED \
                    >/dev/null 2>&1 \
                    && ! $IPT -t filter -C FORWARD -j KZ_UDP_FAILCLOSED_OLD \
                    >/dev/null 2>&1; then
                # dns4.2.66 R28-07 (аудит раунда 28, v25): «noretry» —
                # xt_set не появится до перезагрузки, повтор бесполезен.
                if install_emergency_udp_guard noretry; then
                    log_msg "UDP fail-closed: xt_set недоступен — поставлен и проверен аварийный безмножественный отбой udp/443 с LAN"
                else
                    log_msg "КРИТИЧНО: аварийный безмножественный подпор не построен — ручной разбор обязателен"
                    _kz_uf_note="fail - - - emergency-guard-failed udp_policy=DEGRADED_443_ONLY"
                    if [ "$(tail -n 1 /opt/etc/unblock/.tproxy_state 2>/dev/null)" != "$_kz_uf_note" ]; then
                        printf '%s\n' "$_kz_uf_note" \
                            >> /opt/etc/unblock/.tproxy_state 2>/dev/null || true
                    fi
                fi
            fi
            NETFILTER_PRESERVE_FAILCLOSED=1
            exit 4
        fi
        log_msg "UDP fail-closed: xt_set недоступен — защита не построена"
    fi

    # В таблице filter больше делать нечего.
    exit 0
fi

# dns4.2.40 N-4в (аудит-3): контракт «table=nat = полное применение»
# сохраняем — на него опираются deploy_bypass.sh, unblock_update.sh и
# 100-unblock-vpn.sh (вызывают хук только с table=nat/filter, ожидая и
# mangle-секции). Поэтому при вызове с table=mangle пропускаются ТОЛЬКО
# nat-секции; при пустом/полном проходе и при table=nat делается всё.
_kz_do_nat=1
_kz_do_mangle=1
case "${table:-}" in
    mangle) _kz_do_nat=0 ;;
esac

if [ "${table:-}" = "nat" ] && [ -z "$local_ip" ]; then
    log_msg "LAN router IP not found; refusing DNS DNAT"
    exit 1
fi

# dns4.2.47 N-21 (раунд 9): клиентский туннель (nwg*/ovpn*) существует
# в ядре с загрузки, и до его регистрации хук ставит на него правила
# «как на LAN». После регистрации устройство исчезает из LAN_IFACES,
# но поставленные правила (перехват DNS/TPROXY, порты прокси и панели)
# оставались — удалённая сторона туннеля получала перехват и открытые
# порты. Снимаем с устройств реестра правила с сигнатурами проекта по
# живому дампу. Без реестра — ни одного обращения к iptables:
# состояние netfilter без клиентского VPN байт-в-байт прежнее.
# dns4.2.64 С-3 (аудит раунда 26, v23): правила «исчезнувших»
# интерфейсов. Устройство может уйти из ядра (перезагрузка модема,
# смена типа подключения); его TPROXY/REDIRECT-правила прежде висели
# до ПУРЖа или перезагрузки и искажали счёт гейта 4 установки.
# Снимаются только проектные правила: в mangle — TPROXY, в nat —
# REDIRECT/DNAT на порты проекта.
purge_dead_iface_rules() {
    # dns4.2.66 R28-01 (аудит раунда 28, v25): список живых интерфейсов
    # склеивается ПРОБЕЛАМИ. Прежде вывод sed оставался разделён
    # переводами строк, сравнение « имя » не срабатывало, и каждый
    # прогон снимал проектные правила со ВСЕХ интерфейсов, включая
    # живые (окно без перехвата до повторной постановки). Идиома та же,
    # что в остальных сборщиках списков этого хука.
    _pdi_live=" $(ip -o link show 2>/dev/null \
        | sed -n 's/^[0-9]*: \([^:@]*\)[@:].*/\1/p' | tr '\n' ' ') "
    # dns4.2.67 R29-06/R28-L1 (аудиты раунда 29): сбой перечисления
    # (нет «ip», сбой нетлинка, пустой вывод) делает список пустым, и
    # ВСЕ интерфейсы выглядели бы исчезнувшими — прогон снял бы
    # правила живых (то самое окно из раунда 28). Петлевой «lo» есть
    # в ядре всегда; его отсутствие — признак сбоя, чистка пропускается.
    case "$_pdi_live" in
        *" lo "*) ;;
        *)
            log_msg "stale-iface purge: список интерфейсов недоступен — чистка пропущена"
            return 0
            ;;
    esac
    # dns4.2.65 R27-01 (аудит раунда 27, R26-01/Н-5): снимаются ТОЛЬКО
    # правила проекта по полной сигнатуре (свой набор + свой порт +
    # своя метка/форма). Чужое правило на исчезнувшем интерфейсе не
    # трогается. Извлечение «-i» — подстановками ash, без форка на
    # правило.
    _pdi_redirect_specs="unblocksh:$PORT_SS unblocktor:$PORT_TOR \
unblockvless:$PORT_VLESS unblocktroj:$PORT_TROJAN \
unblockhysteria:$PORT_HYSTERIA"
    # Контракт N-4в: при вызове с table=… трогаем только свою таблицу.
    if [ "${_kz_do_mangle:-1}" -eq 1 ]; then
    _pdi_dead="$($IPT -t mangle -S PREROUTING 2>/dev/null \
        | sed -n 's/^-A PREROUTING /-D PREROUTING /p' \
        | grep -- '-j TPROXY' || true)"
    while IFS= read -r _pdi_line; do
        [ -n "$_pdi_line" ] || continue
        case "$_pdi_line" in
            *" -i "*) _pdi_if="${_pdi_line#* -i }"
                      _pdi_if="${_pdi_if%% *}" ;;
            *) continue ;;
        esac
        case "$_pdi_live" in
            *" $_pdi_if "*) continue ;;
        esac
        # Проектный TPROXY: udp, --on-ip 127.0.0.1, проектная метка,
        # набор из списка проекта и СООТВЕТСТВУЮЩИЙ набору порт.
        case "$_pdi_line" in
            *" -p udp "*" -j TPROXY "*"--on-ip 127.0.0.1 "*"--tproxy-mark $TPROXY_MARK/$TPROXY_MASK"*) ;;
            *) continue ;;
        esac
        _pdi_ok=0
        for _pdi_spec in $_pdi_redirect_specs; do
            _pdi_set="${_pdi_spec%%:*}"
            _pdi_port="${_pdi_spec#*:}"
            case "$_pdi_line" in
                *"--match-set $_pdi_set dst "*"--on-port $_pdi_port "*)
                    _pdi_ok=1; break ;;
            esac
        done
        [ "$_pdi_ok" -eq 1 ] || continue
        # Намеренное словоразбиение строки правила.
        # shellcheck disable=SC2086
        $IPT -t mangle $_pdi_line >/dev/null 2>&1 || true
    done <<EOF_PDI_M
$_pdi_dead
EOF_PDI_M
    fi
    [ "${_kz_do_nat:-1}" -eq 1 ] || return 0
    _pdi_dead="$($IPT -t nat -S PREROUTING 2>/dev/null \
        | sed -n 's/^-A PREROUTING /-D PREROUTING /p' \
        | grep -e '-j REDIRECT' -e '-j DNAT' || true)"
    while IFS= read -r _pdi_line; do
        [ -n "$_pdi_line" ] || continue
        case "$_pdi_line" in
            *" -i "*) _pdi_if="${_pdi_line#* -i }"
                      _pdi_if="${_pdi_if%% *}" ;;
            *) continue ;;
        esac
        case "$_pdi_live" in
            *" $_pdi_if "*) continue ;;
        esac
        _pdi_ok=0
        # Проектный прокси-перехват: набор проекта + свой порт
        # + REDIRECT. Канонический вывод «-S» — «--to-ports»
        # (множественное число, подтверждено на реальном iptables);
        # «--to-port» принимается для совместимости с разбором
        # аргументов старых версий. Оба шаблона — с якорем конца
        # строки (защита от префиксов портов).
        # dns4.2.66 R28-02 (аудит раунда 28, v25).
        for _pdi_spec in $_pdi_redirect_specs; do
            _pdi_set="${_pdi_spec%%:*}"
            _pdi_port="${_pdi_spec#*:}"
            case "$_pdi_line" in
                *"--match-set $_pdi_set dst "*"-j REDIRECT --to-ports $_pdi_port")
                    _pdi_ok=1; break ;;
                *"--match-set $_pdi_set dst "*"-j REDIRECT --to-port $_pdi_port")
                    _pdi_ok=1; break ;;
            esac
        done
        # Проектный DNS: :53 -> REDIRECT :53 либо легаси-DNAT на общий
        # адрес роутера. (Периферийный DNAT на адрес самого исчезнувшего
        # интерфейса здесь неотличим от чужого и остаётся до ПУРЖа.)
        # dns4.2.66 R27-04 (final-аудит раунда 28): правила с чужим
        # «--comment» не снимаются — проект свои DNS-правила не
        # комментирует, а явная чужая пометка важнее совпавшего кортежа.
        if [ "$_pdi_ok" -eq 0 ]; then
            case "$_pdi_line" in
                *"--comment "*) ;;
                *" --dport 53"*" -j REDIRECT --to-ports 53") _pdi_ok=1 ;;
                *" --dport 53"*" -j DNAT --to-destination $local_ip") _pdi_ok=1 ;;
            esac
        fi
        [ "$_pdi_ok" -eq 1 ] || continue
        # Намеренное словоразбиение строки правила.
        # shellcheck disable=SC2086
        $IPT -t nat $_pdi_line >/dev/null 2>&1 || true
    done <<EOF_PDI_N
$_pdi_dead
EOF_PDI_N
}

purge_client_dev_rules() {
    [ -f /opt/etc/unblock/.vpn_client_devs ] || return 0
    _pcd_devs="$(awk 'NF {print $1}' \
        /opt/etc/unblock/.vpn_client_devs 2>/dev/null | sort -u | tr '\n' ' ')"
    [ -n "${_pcd_devs% }" ] || return 0
    _pcd_re="--match-set unblock|--to-ports 53|--dport 53 -j DNAT|-j TPROXY|--dport ($PORT_WEB|$PORT_SS|$PORT_TOR|$PORT_VLESS|$PORT_TROJAN|$PORT_HYSTERIA) -j ACCEPT"
    for _pcd_tc in nat:PREROUTING mangle:PREROUTING filter:INPUT; do
        _pcd_tbl="${_pcd_tc%%:*}"
        _pcd_chain="${_pcd_tc#*:}"
        [ "$_pcd_tbl" = nat ] && [ "$_kz_do_nat" != 1 ] && continue
        [ "$_pcd_tbl" = mangle ] && [ "$_kz_do_mangle" != 1 ] && continue
        $IPT -t "$_pcd_tbl" -S "$_pcd_chain" 2>/dev/null \
            | grep -E -- "$_pcd_re" \
            | while IFS= read -r _pcd_rule; do
                for _pcd_dev in $_pcd_devs; do
                    case "$_pcd_rule" in
                        "-A $_pcd_chain -i $_pcd_dev "*)
                            $IPT -t "$_pcd_tbl" -D ${_pcd_rule#-A } \
                                >/dev/null 2>&1 || true
                            log_msg "снято правило LAN с клиентского туннеля $_pcd_dev ($_pcd_tbl/$_pcd_chain)" ;;
                    esac
                done
            done
    done
}
purge_client_dev_rules
# dns4.2.64 С-3: сразу за очисткой клиентских VPN-устройств.
purge_dead_iface_rules

remove_dns_tunnel_set_refs() {
    # unblockdns is shared by the DNS owner and this hook. If an older
    # installation created it with another ipset type/geometry, ipset -exist
    # rejects the new create. Remove only the OUTPUT DNS redirects first so
    # the incompatible set can be rebuilt safely.
    for _rds_port in "$PORT_VLESS" "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        for _rds_remote in 443 853; do
            while $IPT -t nat -D OUTPUT -p tcp --dport "$_rds_remote" \
                -m set --match-set unblockdns dst \
                -j REDIRECT --to-port "$_rds_port" >/dev/null 2>&1; do :; done
        done
        while $IPT -t nat -D OUTPUT -p tcp \
            -m set --match-set unblockdns dst \
            -j REDIRECT --to-port "$_rds_port" >/dev/null 2>&1; do :; done
    done
}

rebuild_dns_tunnel_set() {
    remove_dns_tunnel_set_refs
    ipset flush unblockdns >/dev/null 2>&1 || true
    ipset flush unblockdns_new >/dev/null 2>&1 || true
    ipset destroy unblockdns_new >/dev/null 2>&1 || true
    ipset destroy unblockdns >/dev/null 2>&1 || true
    ipset create unblockdns hash:net family inet hashsize 1024 \
        maxelem 65536 -exist 2>/dev/null
}

ensure_set() {
    _es_set="$1"
    if ipset create "$_es_set" hash:net family inet hashsize 1024 \
        maxelem 65536 -exist 2>/dev/null; then
        return 0
    fi
    if [ "$_es_set" = "unblockdns" ]; then
        log_msg "ipset create failed: unblockdns; rebuilding incompatible DNS set"
        if rebuild_dns_tunnel_set; then
            log_msg "ipset unblockdns rebuilt as hash:net/family=inet"
            return 0
        fi
    fi
    log_msg "ipset create failed: $_es_set"
    return 1
}

# ── Идемпотентные помощники (проверка через -C, без grep по iptables-save)
# Протокол считается выключенным, если в его init-скрипте стоит
# ENABLED=no (ползунок в веб-панели). Для такого протокола правила
# перехвата не создаются, а ранее созданные снимаются — иначе трафик
# уходил бы на порт остановленного сервиса и соединение просто рвалось.


# Снимает правило REDIRECT с конкретного интерфейса.
nat_del_prerouting() {
    _proto="$1"
    _set="$2"
    _port="$3"
    _if="$4"
    while $IPT -t nat -D PREROUTING -i "$_if" -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    do
        :
    done
}

# Снимает правило TPROXY с конкретного интерфейса.
mangle_del_tproxy() {
    _set="$1"
    _port="$2"
    _if="$3"
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst \
        -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
        --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    do
        :
    done
}

nat_add_prerouting() {
    _proto="$1"
    _set="$2"
    _port="$3"
    _if="$4"
    if ! $IPT -t nat -C PREROUTING -i "$_if" -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    then
        if ! $IPT -t nat -A PREROUTING -i "$_if" -p "$_proto" \
            -m set --match-set "$_set" dst \
            -j REDIRECT --to-port "$_port" >/dev/null 2>&1; then
            log_msg "REDIRECT add failed: $_set/$_port/$_if/$_proto"
            return 1
        fi
    fi
}

nat_del_prerouting_any() {
    # Удаляет старое правило без -i (наследие прежних версий).
    _proto="$1"
    _set="$2"
    _port="$3"
    while $IPT -t nat -D PREROUTING -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    do
        :
    done
}

# Загрузка модуля netfilter при необходимости.
# Хук вызывается при каждой перестройке цепочек, в том числе при
# загрузке роутера, поэтому модули грузятся именно здесь: деплой
# выполняется однократно и после reboot не отработает.
# modprobe на Keenetic бесполезен — в /lib/modules нет modules.dep,
# поэтому используется insmod с полным путём к .ko.
load_kmod() {
    _km="$1"

    if lsmod 2>/dev/null | awk -v m="$_km" '$1==m {f=1} END{exit !f}'
    then
        return 0
    fi

    modprobe "$_km" >/dev/null 2>&1 && return 0

    _kdir="/lib/modules/$(uname -r)"
    [ -d "$_kdir" ] || return 1

    _kfile="$(find "$_kdir" -name "${_km}.ko" -print 2>/dev/null \
        | head -n1)"
    [ -n "$_kfile" ] || return 1

    insmod "$_kfile" >/dev/null 2>&1 || true

    lsmod 2>/dev/null | awk -v m="$_km" '$1==m {f=1} END{exit !f}'
}

# Цель TPROXY доступна только при загруженном xt_TPROXY. Проверяем по
# факту наличия цели в ядре и при отсутствии — догружаем модули.
ensure_tproxy_kmod() {
    if grep -qx 'TPROXY' /proc/net/ip_tables_targets 2>/dev/null; then
        return 0
    fi

    for _d in nf_defrag_ipv4 nf_tproxy_ipv4 nf_tproxy_core \
        nf_socket_ipv4 ip_set; do
        load_kmod "$_d" >/dev/null 2>&1 || true
    done
    for _m in xt_TPROXY xt_socket xt_set; do
        load_kmod "$_m" >/dev/null 2>&1 || true
    done

    if grep -qx 'TPROXY' /proc/net/ip_tables_targets 2>/dev/null; then
        log_msg "xt_TPROXY загружен вручную (insmod)"
        return 0
    fi
    return 1
}

mangle_add_tproxy() {
    _set="$1"
    _port="$2"
    _if="$3"

    # Набор обязан существовать: без него iptables отвергает правило
    # целиком ("Set ... doesn't exist" / "Can't open socket to ipset").
    if ! ipset list -n "$_set" >/dev/null 2>&1; then
        # dns4.2.57 H-11: отсутствие набора — отказ, а не тихий успех:
        # вызывающий фиксирует деградацию в .tproxy_state, а fail-closed
        # backstop в таблице filter не даёт неперехваченному UDP уйти
        # напрямую.
        log_msg "TPROXY failed: ipset $_set does not exist"
        return 1
    fi

    if ! $IPT -t mangle -C PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst \
        -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
        --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    then
        # Ошибка НЕ подавляется: раньше причина терялась в /dev/null и
        # отсутствие правил выглядело беспричинным.
        _err="$($IPT -t mangle -A PREROUTING -i "$_if" -p udp \
            -m set --match-set "$_set" dst \
            -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
            --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" 2>&1)" \
            || {
                log_msg "TPROXY add failed: $_set/$_port/$_if: $_err"
                # Ошибка "No chain/target/match by that name" не говорит,
                # ЧТО именно отвергнуто: цель TPROXY или совпадение set.
                # Разделяем причины одной пробой на каждый прогон, чтобы
                # в журнале была не догадка, а факт.
                if [ "${_tproxy_diag:-0}" = "0" ]; then
                    _tproxy_diag=1
                    if $IPT -t mangle -I PREROUTING -p udp \
                        -d 127.0.0.2 --dport 1 \
                        -j TPROXY --on-ip 127.0.0.1 \
                        --on-port 12345 --tproxy-mark 1/1 \
                        >/dev/null 2>&1
                    then
                        $IPT -t mangle -D PREROUTING -p udp \
                            -d 127.0.0.2 --dport 1 \
                            -j TPROXY --on-ip 127.0.0.1 \
                            --on-port 12345 --tproxy-mark 1/1 \
                            >/dev/null 2>&1 || true
                        log_msg "diag: цель TPROXY работает; отвергается связка с -m set в mangle"
                    else
                        log_msg "diag: ядро НЕ поддерживает цель TPROXY (нет xt_TPROXY). UDP в туннель не пойдёт, TCP не затронут"
                    fi
                fi
                return 1
            }
    fi
}

# ═════════════════════════════════════════════════════════════════════════
# 1. DNS клиентов -> локальный dnsmasq (только внутренние интерфейсы)
# ═════════════════════════════════════════════════════════════════════════
# Прежняя версия ставила DNAT без -i: правило применялось и к пакетам,
# пришедшим с WAN, то есть роутер становился открытым DNS-релеем.
#
# dns4.2.37 H-3: миграционные циклы «на всякий случай» запускаются
# только при наличии их сигнатуры в дампе таблицы. Один `-S`-дамп
# (переменная ниже используется и в секции 4) вместо десятков пробных
# `-D` на каждом событии, когда вычищать уже нечего.
if [ "$_kz_do_nat" = 1 ]; then
_kz_pre_dump="$($IPT -t nat -S PREROUTING 2>/dev/null || true)"
_kz_legacy_dnat=0
case "$_kz_pre_dump" in
    *"--to-destination $local_ip"*) _kz_legacy_dnat=1 ;;
esac
if [ "$_kz_legacy_dnat" = 1 ]; then
    for protocol in udp tcp; do
        while $IPT -t nat -D PREROUTING -p "$protocol" --dport 53 \
            -j DNAT --to-destination "$local_ip" >/dev/null 2>&1
        do
            :
        done
    done
fi

# dns4.2.19: жёсткий DNAT на единый $local_ip ломал DNS клиентов
# серверного WireGuard (запрос к адресу туннельного интерфейса, напр.
# 172.16.82.1, переписывался на адрес другого сегмента). Канонический
# REDIRECT подставляет primary-адрес ingress-интерфейса; старые per-iface
# DNAT-правила сначала миграционно снимаются. При недоступном xt_REDIRECT
# — fallback на DNAT на адрес самого интерфейса, строго с собственным
# -C-гейтом (иначе каждое NDM-событие плодило бы дубликаты).
for iface in $LAN_IFACES; do
    for protocol in udp tcp; do
        # Миграция: устаревший per-iface DNAT на общий $local_ip
        # (dns4.2.37 H-3: гейт по сигнатуре в дампе).
        if [ "$_kz_legacy_dnat" = 1 ]; then
            while $IPT -t nat -D PREROUTING -i "$iface" -p "$protocol" --dport 53 \
                -j DNAT --to-destination "$local_ip" >/dev/null 2>&1
            do
                :
            done
        fi

        if ! $IPT -t nat -C PREROUTING -i "$iface" -p "$protocol" --dport 53 \
            -j REDIRECT --to-ports 53 >/dev/null 2>&1; then
            if ! $IPT -t nat -I PREROUTING -i "$iface" -p "$protocol" --dport 53 \
                -j REDIRECT --to-ports 53 >/dev/null 2>&1; then
                _di_if_ip="$(ip -4 addr show "$iface" 2>/dev/null \
                    | awk '/inet /{print $2; exit}' | cut -d/ -f1)"
                [ -n "$_di_if_ip" ] || _di_if_ip="$local_ip"
                if ! $IPT -t nat -C PREROUTING -i "$iface" -p "$protocol" --dport 53 \
                    -j DNAT --to-destination "$_di_if_ip" >/dev/null 2>&1; then
                    $IPT -t nat -I PREROUTING -i "$iface" -p "$protocol" --dport 53 \
                        -j DNAT --to-destination "$_di_if_ip" >/dev/null 2>&1 || {
                        log_msg "DNS intercept add failed: $iface/$protocol"
                        exit 1
                    }
                fi
            fi
        fi
    done
done
fi

# ═════════════════════════════════════════════════════════════════════════
# 2. Подготовка ipset
# ═════════════════════════════════════════════════════════════════════════
for s in unblocksh unblocktor unblockvless unblocktroj unblockhysteria unblockrouter unblockdns; do
    ensure_set "$s"
done

# ═════════════════════════════════════════════════════════════════════════
# 3. Чистка устаревших/некорректных правил
# ═════════════════════════════════════════════════════════════════════════
# UDP через nat/REDIRECT для Tor/Trojan/Hysteria: это TCP-входы либо
# TPROXY-входы, REDIRECT ломал такой трафик.
#
# dns4.2.37 H-3: всё, что чистит эта секция, — правила БЕЗ -i. Актуальные
# правила все с -i, поэтому при их отсутствии в дампе чистить нечего и
# десять пробных `-D`-циклов (по два-три exec каждый) пропускаются. Один
# разбор уже снятого дампа вместо ~30 вызовов iptables на событие.
if [ "$_kz_do_nat" = 1 ]; then
_kz_legacy_no_if=0
case "$_kz_pre_dump" in
    *"--match-set unblock"*)
        if printf '%s\n' "$_kz_pre_dump" \
            | grep -- '--match-set unblock' | grep -vq -- '-i '; then
            _kz_legacy_no_if=1
        fi
        ;;
esac
if [ "$_kz_legacy_no_if" = 1 ]; then
    nat_del_prerouting_any udp unblocktor "$PORT_TOR"
    nat_del_prerouting_any udp unblocktroj "$PORT_TROJAN"
    nat_del_prerouting_any udp unblockhysteria "$PORT_HYSTERIA"
    nat_del_prerouting_any udp unblockvless "$PORT_VLESS"
    # Старые правила без -i.
    nat_del_prerouting_any tcp unblocksh "$PORT_SS"
    nat_del_prerouting_any udp unblocksh "$PORT_SS"
    nat_del_prerouting_any tcp unblocktor "$PORT_TOR"
    nat_del_prerouting_any tcp unblockvless "$PORT_VLESS"
    nat_del_prerouting_any tcp unblocktroj "$PORT_TROJAN"
    nat_del_prerouting_any tcp unblockhysteria "$PORT_HYSTERIA"
fi

# ═════════════════════════════════════════════════════════════════════════
# 4. TCP: nat/REDIRECT на локальные порты (по каждому внутр. интерфейсу)
# ═════════════════════════════════════════════════════════════════════════
# Пути init-скриптов: по ним читается состояние ползунка ENABLED.
INIT_SS="/opt/etc/init.d/S65shadowsocks"
INIT_TOR="/opt/etc/init.d/S35tor"
INIT_VLESS="/opt/etc/init.d/S24xray"
INIT_TROJ="/opt/etc/init.d/S22trojan"
INIT_HY="/opt/etc/init.d/S57hysteria"

for iface in $LAN_IFACES; do
    if svc_enabled "$INIT_SS" tcp; then
        nat_add_prerouting tcp unblocksh    "$PORT_SS"    "$iface"
        # dns4.2.37 M-3: UDP для ss-redir идёт через TPROXY в секции 5.
        # После nat/REDIRECT адресом назначения в заголовке становится
        # адрес роутера, а UDP-релей ss-redir получает исходный адрес
        # через IP_RECVORIGDSTADDR, что работает только с TPROXY —
        # старый UDP REDIRECT отправлял трафик «в никуда». Здесь только
        # миграционное снятие устаревшего правила.
        # dns4.2.38 N-4б: миграция запускается только при наличии
        # сигнатуры в дампе, снятом в начале секции 1.
        case "$_kz_pre_dump" in
            *"-p udp -m set --match-set unblocksh dst"*)
                nat_del_prerouting udp unblocksh    "$PORT_SS"    "$iface" ;;
        esac
    else
        nat_del_prerouting tcp unblocksh    "$PORT_SS"    "$iface"
        nat_del_prerouting udp unblocksh    "$PORT_SS"    "$iface"
    fi

    # 4.2.71 №6 (целостный аудит, документация дизайна): списки
    # unblocktor/unblocktroj перехватываются ТОЛЬКО по TCP. UDP этих
    # списков (включая QUIC udp/443) намеренно идёт напрямую:
    # tor TransPort по природе TCP, а UDP REDIRECT у trojan ломал
    # трафик (исторический комментарий секции). Браузеры при
    # недоставке QUIC отступают на TCP, который уже в туннеле —
    # покрытие целей сохраняется. Принудительный отступ (отказ по
    # udp/443) сознательно НЕ включается: он ломал бы клиент,
    # который не умеет отступать. Решение зафиксировано владельцем.
    if svc_enabled "$INIT_TOR" tcp; then
        nat_add_prerouting tcp unblocktor   "$PORT_TOR"   "$iface"
    else
        nat_del_prerouting tcp unblocktor   "$PORT_TOR"   "$iface"
    fi

    if svc_enabled "$INIT_VLESS" tcp; then
        nat_add_prerouting tcp unblockvless "$PORT_VLESS" "$iface"
    else
        nat_del_prerouting tcp unblockvless "$PORT_VLESS" "$iface"
    fi

    if svc_enabled "$INIT_TROJ" tcp; then
        nat_add_prerouting tcp unblocktroj  "$PORT_TROJAN" "$iface"
    else
        nat_del_prerouting tcp unblocktroj  "$PORT_TROJAN" "$iface"
    fi

    if svc_enabled "$INIT_HY" tcp; then
        nat_add_prerouting tcp unblockhysteria "$PORT_HYSTERIA" "$iface"
    else
        nat_del_prerouting tcp unblockhysteria "$PORT_HYSTERIA" "$iface"
    fi
done
fi

# ═════════════════════════════════════════════════════════════════════════
# 5. UDP через TPROXY для VLESS (xray), Hysteria2 и Shadowsocks
# ═════════════════════════════════════════════════════════════════════════
# nat/REDIRECT для UDP не сохраняет оригинальный адрес назначения, поэтому
# dokodemo-door/udpTProxy получали пакеты без dst и трафик рвался.
# Корректная схема: mangle/TPROXY + метка + локальная таблица маршрутизации.
# Для shadowsocks то же ограничение: ss-redir узнаёт исходный адрес
# назначения только из сокета с IP_RECVORIGDSTADDR, т.е. из-под TPROXY
# (dns4.2.37, M-3).

# dns4.2.61 Х-02 (аудит раунда 23, RU_CURRENT H-02): доказуемое
# владение политическими ресурсами. Совпадение кортежа «метка/маска +
# таблица + приоритет» само по себе НЕ доказывает, что правило создал
# проект: другое TPROXY-приложение вправе использовать те же значения.
# Маркер владельца пишется после успешного проектного добавления и
# снимается при проектном демонтаже; при вычистке ресурсы удаляются
# ТОЛЬКО при совпадении маркера (включая boot-id: после перезагрузки
# правило с тем же кортежем создано уже не нами).
# dns4.2.63 Х-04 (аудит раунда 25): константы маркера, _kz_dec и
# нормализованные представления вынесены к началу скрипта (до
# исполняемых секций) — ими пользуется и ранний демонтаж, включая
# PURGE. Здесь определений больше нет.
tproxy_rule_exact() {
    # Матчер полного кортежа по входу `ip rule show` (stdin):
    # приоритет, ключевое слово, метка/маска, таблица — с учётом обоих
    # числовых представлений.
    awk \
        -v praw="$KZ_TPROXY_PRIO_RAW" -v pdec="$KZ_TPROXY_PRIO_DEC" \
        -v mraw="$KZ_TPROXY_MARKM_RAW" -v mdec="$KZ_TPROXY_MARKM_DEC" \
        -v traw="$KZ_TPROXY_TABLE_RAW" -v tdec="$KZ_TPROXY_TABLE_DEC" \
        '($1 == praw ":" || $1 == pdec ":") && $4 == "fwmark" \
         && ($5 == mraw || $5 == mdec) \
         && $6 == "lookup" && ($7 == traw || $7 == tdec) {ok=1} \
         END {exit !ok}'
}
kz_tproxy_rule_present() {
    ip rule show 2>/dev/null | tproxy_rule_exact
}

TPROXY_REQUIRED=0
if [ "$_kz_do_mangle" = 1 ]; then
if svc_enabled "$INIT_VLESS" udp || svc_enabled "$INIT_HY" udp || svc_enabled "$INIT_SS" udp; then
    TPROXY_REQUIRED=1
fi

# dns4.2.35 (ре-аудит, R-06): файл состояния TPROXY — построчные итоги
# применения на КАЖДОМ интерфейсе (вместо «есть хотя бы одно правило»
# в деплое): «ok|fail|degraded <iface> <ipset> <port> <причина>».
# Хук — единственный, кто знает правду о применённых правилах.
TPROXY_STATE="/opt/etc/unblock/.tproxy_state"
# dns4.2.55 П-24: состояние копится в черновике на tmpfs и пишется в
# /opt одной операцией и только при изменении содержимого. Прежний режим
# «усечь и дописать по строке» давал ~10 записей на флеш на каждое событие
# netfilter; при раннем выходе файл оставался усечённым.
# РАУНД 61 (реаудит раунда 60, RA-03): непредсказуемое временное
# имя — «mktemp» создаёт файл сам (режим 0600); при сбое работает
# прежняя ветка деградации (кеш состояния не ведётся, функции ниже
# проверяют «[ -n ]»).
TPROXY_STATE_TMP="$(mktemp /tmp/.tproxy_state.XXXXXX 2>/dev/null)" || TPROXY_STATE_TMP=""
tproxy_state_note() {
    [ -n "$TPROXY_STATE_TMP" ] || return 0
    # dns4.2.64 Н-1 (аудит раунда 26): дедуп — конфликтные пути зовут
    # заметку дважды (гейт владения и демонтаж), строка пишется одна.
    _tsn_line="$1 $2 $3 $4 $5"
    if grep -qxF "$_tsn_line" "$TPROXY_STATE_TMP" 2>/dev/null; then
        return 0
    fi
    printf '%s\n' "$_tsn_line" \
        >> "$TPROXY_STATE_TMP" 2>/dev/null || true
}
tproxy_state_commit() {
    [ -n "$TPROXY_STATE_TMP" ] || return 0
    if [ "$(cat "$TPROXY_STATE_TMP" 2>/dev/null)" != \
         "$(cat "$TPROXY_STATE" 2>/dev/null)" ]; then
        cat "$TPROXY_STATE_TMP" > "$TPROXY_STATE" 2>/dev/null || true
    fi
    rm -f "$TPROXY_STATE_TMP" 2>/dev/null || true
    TPROXY_STATE_TMP=""
}

# Баг 1 фикс: предпроверка возможностей ядра ДО каких-либо изменений.
# Старая версия здесь делала `exit 1`, и снапшот-ловушка откатывала
# УЖЕ применённые в секции 4 TCP-правила: отсутствие модуля ядра
# ломало не только UDP-туннель, но и весь обход. Теперь при отсутствии
# поддержки деградируем в режим «только TCP» без выхода из скрипта:
# тот же итог, что обещает диагностика mangle_add_tproxy («TCP не
# затронут»), но без убийства применённых правил.
if [ "$TPROXY_REQUIRED" -eq 1 ]; then
    if ! ensure_tproxy_kmod; then
        log_msg "TPROXY: цель недоступна в ядре — деградация в режим только TCP (UDP в туннель не пойдёт)"
        TPROXY_REQUIRED=0
        tproxy_state_note degraded - - - kernel-no-tproxy
    elif ! ipt_has_match "$IPT_BIN" socket; then
        log_msg "TPROXY: xt_socket недоступен — деградация в режим только TCP"
        TPROXY_REQUIRED=0
        tproxy_state_note degraded - - - kernel-no-xt_socket
    elif ! ipt_has_match "$IPT_BIN" set; then
        log_msg "TPROXY: xt_set недоступен — деградация в режим только TCP"
        TPROXY_REQUIRED=0
        tproxy_state_note degraded - - - kernel-no-xt_set
    fi
fi

if [ "$TPROXY_REQUIRED" -eq 1 ]; then
    # dns4.2.61 Х-02: tproxy_rule_exact вынесена к нормализованным
    # константам выше (нужна и ветке вычистки, а не только этому блоку).
    tproxy_route_exact() {
        awk -v t="$TPROXY_TABLE" \
            '$1 == "local" && $2 == "default" && $3 == "dev" && $4 == "lo" {ok=1} END {exit !ok}'
    }
    # dns4.2.36 (аудит, KZ-13) → dns4.2.59 Х-10 (аудит 2026-09-29,
    # H-10): фиксированные ресурсы маршрутизации (приоритет/таблица)
    # проверяются на чужого владельца ЯВНО. Прежде конфликт лишь
    # помечался «degraded», после чего проект всё равно добавлял свои
    # правила — результат зависел от порядка. Теперь конфликт =
    # жёсткий отказ: правила перехвата не создаются. Оговорка:
    # правило с НАШЕЙ меткой на этом приоритете считается своим
    # (остаток от прежнего прогона проекта), и чужие маршруты в
    # таблице ищутся относительно канонического «local default dev lo».
    _kz_tp_conflict=0
    # dns4.2.60 Н-03 (аудит 2026-09-29, H-03): сопоставление по полному
    # кортежу «метка/маска + таблица», а не только по метке: правило с
    # НАШЕЙ меткой, но чужой маской или таблицой раньше проходило как
    # своё. Чужая считается любая строка на приоритете, не совпадающая
    # с каноническим кортежем проекта.
    _kz_tp_lines="$(ip rule show 2>/dev/null \
        | awk -v p="$TPROXY_RULE_PRIO:" '$1 == p' || true)"
    if [ -n "$_kz_tp_lines" ]; then
        _kz_tp_total="$(printf '%s\n' "$_kz_tp_lines" | grep -c . || true)"
        # dns4.2.61 Х-02: оба числовых представления кортежа.
        _kz_tp_exact="$(printf '%s\n' "$_kz_tp_lines" | awk \
            -v mraw="$KZ_TPROXY_MARKM_RAW" -v mdec="$KZ_TPROXY_MARKM_DEC" \
            -v traw="$KZ_TPROXY_TABLE_RAW" -v tdec="$KZ_TPROXY_TABLE_DEC" \
            '$4 == "fwmark" && ($5 == mraw || $5 == mdec) \
             && $6 == "lookup" && ($7 == traw || $7 == tdec)' | grep -c . || true)"
        if [ "${_kz_tp_total:-0}" -ne "${_kz_tp_exact:-0}" ]; then
            _kz_tp_conflict=1
            tproxy_state_note fail - - - rule-$TPROXY_RULE_PRIO-foreign
            log_msg "TPROXY: приоритет $TPROXY_RULE_PRIO занят чужим правилом — перехват не включается"
        fi
    fi
    if ip route show table "$TPROXY_TABLE" 2>/dev/null \
        | grep -v '^local default dev lo' | grep -q .; then
        _kz_tp_conflict=1
        tproxy_state_note fail - - - table-$TPROXY_TABLE-foreign
        log_msg "TPROXY: таблица $TPROXY_TABLE содержит чужие маршруты — перехват не включается"
    fi
    if [ "$_kz_tp_conflict" = 1 ]; then
        log_msg "TPROXY: очистите чужие ресурсы (ip rule / ip route flush table $TPROXY_TABLE) и повторите; правила перехвата не создаются"
        TPROXY_REQUIRED=0
    fi

    # dns4.2.63 Х-03/Н-4 (аудит раунда 25, RU_R23 H-03, v22 Н-4):
    # владение определяется ДО добавления ресурсов. Точный кортеж без
    # действующего маркера больше не «усыновляется»: он может
    # принадлежать другому приложению. Исключение — одноразовая
    # миграция: строки «ok» в .tproxy_state пишет только проект, и их
    # наличие доказывает, что ресурсы наши (переход с выпуска без
    # маркера или сбой записи маркера в прошлом).
    _kz_tp_need_marker=0
    _kz_tp_migration=0
    # dns4.2.64 P1-05 (аудит раунда 26): доказательство миграции —
    # ОДНОРАЗОВОЕ. Строки «ok» в .tproxy_state постоянны, переживают
    # перезагрузку и прежде разрешали повторное «усыновление» после
    # любой потери маркера — в т.ч. чужого кортежа.
    #
    # dns4.2.65 R27-02 (аудит раунда 27, R26-02): сайдкар
    # .kz_owner_migrated — маркер «легаси-миграция УЖЕ УПОТРЕБЛЕНА»,
    # а не бессрочное разрешение усыновлять. Первая миграция по
    # «ok»-строкам (когда сайдкара ещё нет) пишет маркер владельца и
    # сайдкар; при действующем сайдкаре и недействительном маркере —
    # конфликт: повторного усыновления нет, восстановление только
    # через ПУРЖ/очистку. Чужим считается точное ПРАВИЛО ИЛИ точный
    # МАРШРУТ без маркера.
    _kz_tp_owned_found=0
    if ip rule show 2>/dev/null | tproxy_rule_exact; then
        _kz_tp_owned_found=1
    fi
    if [ "$_kz_tp_owned_found" -eq 0 ] \
            && ip route show table "$TPROXY_TABLE" 2>/dev/null \
                | tproxy_route_exact; then
        _kz_tp_owned_found=1
    fi
    if [ "$_kz_tp_conflict" != 1 ] && [ "$_kz_tp_owned_found" -eq 1 ]; then
        if kz_tproxy_marker_valid; then
            : # своё, маркер действителен — ничего не трогаем
        elif [ -f /opt/etc/unblock/.kz_owner_migrated ]; then
            _kz_tp_conflict=1
            tproxy_state_note fail - - - rule-owner-unknown
            log_msg "TPROXY: легаси-миграция уже употреблена, маркер владельца недействителен — кортеж не усыновляется (нужен ПУРЖ или очистка кортежа)"
            TPROXY_REQUIRED=0
        elif grep -q '^ok ' /opt/etc/unblock/.tproxy_state 2>/dev/null; then
            log_msg "TPROXY: ПЕРВАЯ одноразовая миграция по строкам ok — после записи маркера будет создан маркер миграции"
            _kz_tp_need_marker=1
            _kz_tp_migration=1
        else
            _kz_tp_conflict=1
            tproxy_state_note fail - - - rule-owner-unknown
            log_msg "TPROXY: точный кортеж (правило/маршрут) уже есть без маркера владельца — чужой ресурс не усыновляется"
            TPROXY_REQUIRED=0
        fi
    fi
    if [ "$_kz_tp_conflict" != 1 ]; then
        if ! ip rule show 2>/dev/null | tproxy_rule_exact; then
            ip rule add fwmark "${TPROXY_MARK}/${TPROXY_MASK}" \
                lookup "$TPROXY_TABLE" priority "$TPROXY_RULE_PRIO" 2>/dev/null || {
                log_msg "TPROXY ip rule add failed"
                exit 1
            }
            TPROXY_RULE_ADDED=1
            _kz_tp_need_marker=1
        fi
    fi
    if [ "$_kz_tp_conflict" != 1 ]; then
        if ! ip route show table "$TPROXY_TABLE" 2>/dev/null | tproxy_route_exact; then
            TPROXY_ROUTE_ADDED=1
        fi
        ip route replace local default dev lo table "$TPROXY_TABLE" 2>/dev/null || {
            log_msg "TPROXY local route add failed"
            exit 1
        }
        if ! ip rule show 2>/dev/null | tproxy_rule_exact \
            || ! ip route show table "$TPROXY_TABLE" 2>/dev/null | tproxy_route_exact; then
            log_msg "TPROXY policy routing verification failed"
            exit 1
        fi
        # dns4.2.61 Х-02 → dns4.2.63 Х-03 (аудит раунда 25): маркер
        # владельца ОБЯЗАТЕЛЕН и пишется атомарно (временный файл +
        # переименование). Сбой записи означает «владение не
        # доказано»: только что добавленные ресурсы откатываются,
        # прогон помечается «fail». Фиксируем кортеж и boot-id: после
        # перезагрузки правило с тем же кортежем создано уже не нами.
        if [ "$_kz_tp_need_marker" -eq 1 ]; then
            _kz_boot_id="$(cat /proc/sys/kernel/random/boot_id 2>/dev/null || printf -- '-')"
            mkdir -p /opt/var/run 2>/dev/null || true
            _kz_owner_tmp="${KZ_TPROXY_OWNER}.$$"
            if printf '%s %s %s %s\n' "$KZ_TPROXY_MARKM_RAW" \
                    "$KZ_TPROXY_TABLE_RAW" "$KZ_TPROXY_PRIO_RAW" \
                    "$_kz_boot_id" > "$_kz_owner_tmp" 2>/dev/null \
                    && mv -f "$_kz_owner_tmp" "$KZ_TPROXY_OWNER" 2>/dev/null; then
                # dns4.2.64 P1-05: одноразовый маркер миграции —
                # только после доказанной записи маркера владельца.
                # Сбой записи сайдкара не отменяет усыновление:
                # маркер уже стоит, следующий прогон допишет сайдкар.
                if [ "${_kz_tp_migration:-0}" -eq 1 ] \
                        && [ ! -f /opt/etc/unblock/.kz_owner_migrated ]; then
                    _kz_mig_tmp="/opt/etc/unblock/.kz_owner_migrated.$$"
                    if printf 'migrated=1\n' > "$_kz_mig_tmp" 2>/dev/null; then
                        mv -f "$_kz_mig_tmp" \
                            /opt/etc/unblock/.kz_owner_migrated \
                            2>/dev/null \
                            || rm -f "$_kz_mig_tmp" 2>/dev/null || true
                    fi
                fi
            else
                rm -f "$_kz_owner_tmp" 2>/dev/null || true
                [ "${TPROXY_RULE_ADDED:-0}" -eq 1 ] && \
                    ip rule del fwmark "${TPROXY_MARK}/${TPROXY_MASK}" \
                        lookup "$TPROXY_TABLE" priority "$TPROXY_RULE_PRIO" \
                        >/dev/null 2>&1 || true
                [ "${TPROXY_ROUTE_ADDED:-0}" -eq 1 ] && \
                    ip route del local default dev lo table "$TPROXY_TABLE" \
                        >/dev/null 2>&1 || true
                tproxy_state_note fail - - - marker-write-failed
                log_msg "TPROXY: маркер владельца не записан — добавленные ресурсы откачены, прогон помечен сбоем"
                TPROXY_REQUIRED=0
            fi
        fi
    fi
fi

# Пакеты уже установленных TPROXY-сессий должны попадать на локальный сокет
# до правил TPROXY (иначе они уйдут в форвардинг).
# dns4.2.49 L-3 (остаток раундов 1-2): с --transparent матч трогает
# только TPROXY-сокеты; без поддержки (проба) — прежний вариант.
# Противоположный вариант снимается: сборка/ядро могли измениться.
if [ "$TPROXY_REQUIRED" -eq 1 ]; then
    if ipt_socket_transparent_capable "$IPT_BIN"; then
        _kz_sock_new="-m socket --transparent"
        _kz_sock_old="-m socket"
    else
        _kz_sock_new="-m socket"
        _kz_sock_old="-m socket --transparent"
    fi
    while $IPT -t mangle -D PREROUTING -p udp $_kz_sock_old \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1; do :; done
    if ! $IPT -t mangle -C PREROUTING -p udp $_kz_sock_new \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    then
        $IPT -t mangle -I PREROUTING -p udp $_kz_sock_new \
            -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1 || {
            log_msg "TPROXY socket mark add failed"
            exit 1
        }
    fi
fi

# Баг 1 фикс (продолжение): при `set -eu` return 1 из mangle_add_tproxy
# убивал скрипт посреди цикла и откатывал применённые правила. Функция
# сама пишет причину отказа в журнал (включая одноразовую диагностику
# «ядро НЕ поддерживает цель TPROXY») — фиксируем деградацию и идём
# дальше: правила для остальных интерфейсов/протоколов продолжают
# применяться, TCP-обход не затрагивается.
#
# Полировка 4.2.26: добавление гейтится флагом. При деградации ядра
# (префлайт обнулил TPROXY_REQUIRED) не делаем по два холостых форка
# iptables и по две строки журнала на каждый интерфейс на каждое сетевое
# событие. ВНИМАНИЕ: ветки вычистки (mangle_del_tproxy) гейтить нельзя —
# ноль в флаге бывает и при ВЫКЛЮЧЕННЫХ сервисах на живом ядре, и тогда
# именно эти вызовы снимают правила, оставшиеся от включённого состояния.
# dns4.2.60 Н-03 (аудит 2026-09-29, H-03): структура веток перестроена —
# добавление только при «сервис включён И ядро готово», иначе ВСЕГДА
# вычистка. Прежняя вложенность оставляла правила прошлого включённого
# состояния, когда сервис включён, а TPROXY_REQUIRED обнулился
# (деградация ядра или чужой конфликт ресурсов).
for iface in $LAN_IFACES; do
    if svc_enabled "$INIT_SS" udp && [ "$TPROXY_REQUIRED" -eq 1 ]; then
        if mangle_add_tproxy unblocksh "$PORT_SS" "$iface"; then
            tproxy_state_note ok "$iface" unblocksh "$PORT_SS" -
        else
            log_msg "TPROXY: правило для $iface отклонено — деградация (интерфейс/протокол пропущен)"
            tproxy_state_note fail "$iface" unblocksh "$PORT_SS" rule-rejected
        fi
    else
        mangle_del_tproxy unblocksh       "$PORT_SS"      "$iface"
    fi
    if svc_enabled "$INIT_VLESS" udp && [ "$TPROXY_REQUIRED" -eq 1 ]; then
        if mangle_add_tproxy unblockvless "$PORT_VLESS" "$iface"; then
            tproxy_state_note ok "$iface" unblockvless "$PORT_VLESS" -
        else
            log_msg "TPROXY: правило для $iface отклонено — деградация (интерфейс/протокол пропущен)"
            tproxy_state_note fail "$iface" unblockvless "$PORT_VLESS" rule-rejected
        fi
    else
        mangle_del_tproxy unblockvless    "$PORT_VLESS"    "$iface"
    fi
    if svc_enabled "$INIT_HY" udp && [ "$TPROXY_REQUIRED" -eq 1 ]; then
        if mangle_add_tproxy unblockhysteria "$PORT_HYSTERIA" "$iface"; then
            tproxy_state_note ok "$iface" unblockhysteria "$PORT_HYSTERIA" -
        else
            log_msg "TPROXY: правило для $iface отклонено — деградация (интерфейс/протокол пропущен)"
            tproxy_state_note fail "$iface" unblockhysteria "$PORT_HYSTERIA" rule-rejected
        fi
    else
        mangle_del_tproxy unblockhysteria "$PORT_HYSTERIA" "$iface"
    fi
done

# dns4.2.60 Н-03 (аудит 2026-09-29, H-03): обобщённое правило пометки
# сокетов снимается не только в PURGE-проходе, но и всякий раз, когда
# перехват не требуется (деградация ядра, конфликт, выключенные
# сервисы) — обе его формы сборки (--transparent и без него).
if [ "$TPROXY_REQUIRED" -ne 1 ]; then
    while $IPT -t mangle -D PREROUTING -p udp -m socket --transparent \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1; do :; done
    while $IPT -t mangle -D PREROUTING -p udp -m socket \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1; do :; done
    # dns4.2.61 Х-02 (аудит раунда 23, RU_CURRENT H-02): политика и
    # маршрут снимаются ТОЛЬКО при доказанном владении (маркер с
    # совпадающим кортежем и текущим boot-id). Точное совпадение
    # кортежа без маркера больше не считается своим: ресурс может
    # принадлежать другому TPROXY-приложению — не удаляем, фиксируем
    # «fail» и сообщаем аварийным кодом.
    # dns4.2.63 Х-04 (аудит раунда 25, RU_R23 H-04): та же единая
    # владельческая функция, что в раннем демонтаже и в PURGE.
    if kz_tproxy_marker_valid; then
        remove_owned_tproxy_policy
    elif kz_tproxy_rule_present; then
        tproxy_state_note fail - - - rule-owner-unknown
        log_msg "TPROXY: найден точный кортеж без маркера владельца — ресурс НЕ удалён (возможен чужой владелец); очистите вручную и повторите"
    fi
fi
# dns4.2.55 П-24: одна запись состояния на событие, и только при изменении.
tproxy_state_commit
fi

# ═════════════════════════════════════════════════════════════════════════
# 6. Трафик самого роутера (bot.txt -> unblockrouter)
# ═════════════════════════════════════════════════════════════════════════
if [ "$_kz_do_nat" = 1 ]; then
if ! $IPT -t nat -C OUTPUT -o lo -j RETURN >/dev/null 2>&1; then
    $IPT -t nat -I OUTPUT -o lo -j RETURN >/dev/null 2>&1 || exit 1
fi

for net in $LOCAL_NETS; do
    if ! $IPT -t nat -C OUTPUT -d "$net" -j RETURN >/dev/null 2>&1; then
        $IPT -t nat -A OUTPUT -d "$net" -j RETURN >/dev/null 2>&1 || exit 1
    fi
done

# Защита от петли: пакеты, которые xray сам отправляет наружу, помечены
# XRAY_MARK (sockopt.mark в outbound). Без этого исключения правила ниже
# завернули бы исходящий трафик xray обратно в его же inbound.
if ! $IPT -t nat -C OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; then
    $IPT -t nat -I OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1 || exit 1
fi
fi
if [ "$_kz_do_mangle" = 1 ]; then
if ! $IPT -t mangle -C OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; then
    $IPT -t mangle -I OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1 || exit 1
fi
fi
if [ "$_kz_do_nat" = 1 ]; then

# DNS через активный туннель. В наборе unblockdns находятся адреса
# внешних системных DoH/DoT endpoint-ов, а не IP произвольных сайтов.
# Поэтому клиентский DNS остаётся в dnsmasq/system proxy, а только его
# исходящие TCP/443 и TCP/853 соединения идут через выбранный tunnel.
#
# ВАЖНО: выбор transport принадлежит unblock_dnsmasq.sh. При обычном
# вызове NDM этот hook только потребляет свежий canonical snapshot из
# существующего bounded health log; поиск «первого живого процесса» здесь
# запрещён, иначе fallback Xray -> Trojan -> Hysteria расходился бы с DNS
# health и мог вернуть stale unblockdns к другому tunnel.


apply_dns_nat

# TCP router path: selection is a single data word, NEVER sourced as shell.
router_protocol() {
    _rp_file=/opt/etc/unblock/.router_protocol
    _rp=xray
    if [ -f "$_rp_file" ]; then
        IFS= read -r _rp < "$_rp_file" || [ -n "$_rp" ] || return 1
    fi
    case "$_rp" in xray|trojan|hysteria) printf '%s\n' "$_rp" ;; *) return 1 ;; esac
}

apply_router_tcp() {
    _rt_proto="$(router_protocol)" || { log_msg "invalid router protocol"; return 1; }
    case "$_rt_proto" in
        xray) _rt_init="$INIT_VLESS"; _rt_port="$PORT_VLESS" ;;
        trojan) _rt_init="$INIT_TROJ"; _rt_port="$PORT_TROJAN" ;;
        hysteria) _rt_init="$INIT_HY"; _rt_port="$PORT_HYSTERIA" ;;
    esac
    # Small dedicated chain: do not flush OUTPUT or any Keenetic/WireGuard chain.
    if ! $IPT -t nat -S KZ_ROUTER >/dev/null 2>&1; then
        $IPT -t nat -N KZ_ROUTER >/dev/null 2>&1 || return 1
    fi
    $IPT -t nat -F KZ_ROUTER >/dev/null 2>&1 || return 1
    # Remove legacy redirects and the old jump; reinstall exactly once.
    while $IPT -t nat -D OUTPUT -p tcp -m set --match-set unblockrouter dst \
        -j KZ_ROUTER >/dev/null 2>&1; do :; done
    for _rt_old in "$PORT_VLESS" "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        while $IPT -t nat -D OUTPUT -p tcp -m set --match-set unblockrouter dst \
            -j REDIRECT --to-port "$_rt_old" >/dev/null 2>&1; do :; done
    done
    # РАУД 37 (итоговый аудит, P2-02): транспортный гейт обязателен —
    # без «tcp» правила роутерного редиректа строились по слабой
    # проверке живости, без владения слушателем.
    svc_enabled "$_rt_init" tcp || return 0

    # Trojan has no Xray sockopt mark. Bypass its upstream to prevent a loop
    # if a broad bot.txt CIDR contains the VPS. Domain endpoints require the
    # existing managed pins; no new DNS requests in a short NDM hook.
    if [ "$_rt_proto" = trojan ]; then
        _rt_host="$(sed -n 's/.*"remote_addr"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' /opt/etc/trojan/config.json | head -n1)"
        _rt_ips="$(printf '%s\n' "$_rt_host" | awk -F. '
            NF==4 {ok=1; for(i=1;i<=4;i++) if($i !~ /^[0-9]+$/ || $i>255) ok=0; if(ok) print}')"
        if [ -z "$_rt_ips" ]; then
            _rt_ips="$(awk -v h="$_rt_host" '
                /^# --- KeenZOO pinned / {inside=1; next}
                /^# --- end KeenZOO pinned/ {inside=0}
                inside && $1 !~ /^#/ {for(i=2;i<=NF;i++) if($i==h) print $1}
            ' /opt/etc/hosts 2>/dev/null || true)"
        fi
        [ -n "$_rt_ips" ] || { log_msg "Trojan router path: missing IPv4 endpoint pin"; return 1; }
        for _rt_ip in $_rt_ips; do
            $IPT -t nat -A KZ_ROUTER -d "$_rt_ip" -j RETURN >/dev/null 2>&1 || return 1
        done
    fi
    $IPT -t nat -A KZ_ROUTER -p tcp -j REDIRECT --to-port "$_rt_port" >/dev/null 2>&1 || return 1
    $IPT -t nat -A OUTPUT -p tcp -m set --match-set unblockrouter dst \
        -j KZ_ROUTER >/dev/null 2>&1 || return 1
}
# dns4.2.20: router-путь ОПЦИОНАЛЕН и некритичен. Его отказ (повреждённый
# .router_protocol, временно отсутствующий trojan-pin в /opt/etc/hosts) не
# должен завершать весь nat-прогон: иначе trap откатывал снапшотом уже
# установленные правила на КАЖДОМ событии NDM. Функция идемпотентна и при
# выключенном сервисе возвращает 0 после снятия legacy-правил; обязательные
# секции по-прежнему завершают прогон с ошибкой.
apply_router_tcp || log_msg "router path skipped (non-critical)"

# Local-origin UDP is deliberately not intercepted. Linux local packets
# traverse OUTPUT -> POSTROUTING, not PREROUTING; marking OUTPUT and hoping
# for a second PREROUTING pass is not a valid transparent-proxy design.
# bot.txt is therefore a TCP-only router path, which is sufficient for the
# Telegram/HTTP bot. Remove rules left by older releases.
while $IPT -t nat -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst \
    -j REDIRECT --to-port "$PORT_SS" >/dev/null 2>&1; do :; done
while $IPT -t nat -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst \
    -j REDIRECT --to-port "$PORT_VLESS" >/dev/null 2>&1; do :; done
fi
if [ "$_kz_do_mangle" = 1 ]; then
    while $IPT -t mangle -D OUTPUT -p udp \
        -m set --match-set unblockrouter dst \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1; do :; done
fi

# ═════════════════════════════════════════════════════════════════════════
# 7. VPN-интерфейсы прошивки: ipset -> fwmark -> policy routing
# ═════════════════════════════════════════════════════════════════════════
# При отключении интерфейса нельзя оставлять старые MARK/CONNMARK-правила:
# они отправляют новый трафик в уже неработающую policy table.
if [ "$_kz_do_mangle" = 1 ]; then
vpn_del_mark_rules() {
    _vd_set="$1"
    _vd_mark="$2"

    for _vd_proto in tcp udp; do
        while $IPT -t mangle -D PREROUTING -p "$_vd_proto" \
            -m set --match-set "$_vd_set" dst \
            -j MARK --set-mark "$_vd_mark" >/dev/null 2>&1
        do
            :
        done
    done

    while $IPT -t mangle -D PREROUTING \
        -m conntrack --ctstate NEW \
        -m set --match-set "$_vd_set" dst \
        -j CONNMARK --set-mark "$_vd_mark" >/dev/null 2>&1
    do
        :
    done
}

for vpn_file_name in /opt/etc/unblock/vpn-*.txt; do
    [ -f "$vpn_file_name" ] || continue

    vpn_unblock_name="$(basename "$vpn_file_name" .txt)"
    unblockvpn="unblock${vpn_unblock_name}"
    vpn_type="$(printf '%s\n' "$unblockvpn" | sed 's/-/ /g' | awk '{print $NF}')"
    [ -n "$vpn_type" ] || continue

    vpn_type_lower="$(printf '%s' "$vpn_type" | tr '[:upper:]' '[:lower:]')"
    vpn_table_id="$(grep -w "$vpn_type_lower" /opt/etc/iproute2/rt_tables 2>/dev/null \
        | awk '{print $1}' | head -n1 || true)"
    [ -n "$vpn_table_id" ] || continue
    vpn_mark_id="0xd${vpn_table_id}"

    # dns4.2.20: различаем «RCI не ответил» (состояние неизвестно —
    # ничего не сносим) и явное не-up. Раньше пустой/ошибочный ответ
    # эквивалентился «не up» и на каждом событии NDM вёл к сносу
    # mark-правил, flush таблицы и flush ipset при живом туннеле.
    # Метрика унифицирована с 100-unblock-vpn.sh: /connected (yes|up) —
    # до правки здесь был /link, и хуки могли разойтись во мнении.
    _vlu_raw="$(curl -s --max-time 5 \
        "localhost:79/rci/show/interface/${vpn_type}/connected" 2>/dev/null || true)"
    vpn_link_up="$(printf '%s' "$_vlu_raw" | tr -d '" \r\t')"

    case "$vpn_link_up" in
        '')
            # Нет ответа: состояние неизвестно. Сохраняем всё как есть.
            continue
            ;;
        # dns4.2.47 N-20 (раунд 9): явное «поднят» — ниже строятся
        # правила пометки трафика по списку. Раньше значения да
        # (yes|up) попадали в «*)» и уходили в continue, поэтому
        # policy routing списков vpn-*.txt не строился никогда.
        yes|up)
            : ;;
        no|down|false)
            : ;;  # явное не-up: демонтаж ниже
        *)
            case "$_vlu_raw" in
                *"not found"*|*"Not Found"*)
                    : ;;  # интерфейса нет в NDM: демонтаж ниже
                *)
                    # Ошибка RCI/error-JSON без «not found»: неизвестно.
                    continue
                    ;;
            esac
            ;;
    esac
    if [ "$vpn_link_up" != "yes" ] && [ "$vpn_link_up" != "up" ]; then
        vpn_del_mark_rules "$unblockvpn" "$vpn_mark_id"
        ip -4 rule del from all table "$vpn_table_id" priority 1778 \
            >/dev/null 2>&1 || true
        ip -4 rule del fwmark "$vpn_mark_id" lookup "$vpn_table_id" \
            priority 1778 >/dev/null 2>&1 || true
        ip -4 route flush table "$vpn_table_id" >/dev/null 2>&1 || true
        ipset flush "$unblockvpn" >/dev/null 2>&1 || true
        continue
    fi

    ensure_set "$unblockvpn"

    fastnat="$(curl -s --max-time 5 localhost:79/rci/show/version 2>/dev/null | grep ppe || true)"
    software="$(curl -s --max-time 5 localhost:79/rci/show/rc/ppe 2>/dev/null \
        | grep software -C1 | head -1 | awk '{print $2}' | tr -d ',' || true)"
    hardware="$(curl -s --max-time 5 localhost:79/rci/show/rc/ppe 2>/dev/null \
        | grep hardware -C1 | head -1 | awk '{print $2}' | tr -d ',' || true)"

    if [ -z "$fastnat" ] && [ "$software" = "false" ] && [ "$hardware" = "false" ]; then
        for proto in tcp udp; do
            if ! $IPT -t mangle -C PREROUTING -p "$proto" \
                -m set --match-set "$unblockvpn" dst \
                -j MARK --set-mark "$vpn_mark_id" >/dev/null 2>&1
            then
                $IPT -t mangle -A PREROUTING -p "$proto" \
                    -m set --match-set "$unblockvpn" dst \
                    -j MARK --set-mark "$vpn_mark_id" >/dev/null 2>&1 || exit 1
            fi
        done
    else
        if ! $IPT -t mangle -C PREROUTING \
            -m conntrack --ctstate NEW \
            -m set --match-set "$unblockvpn" dst \
            -j CONNMARK --set-mark "$vpn_mark_id" >/dev/null 2>&1
        then
            $IPT -t mangle -A PREROUTING \
                -m conntrack --ctstate NEW \
                -m set --match-set "$unblockvpn" dst \
                -j CONNMARK --set-mark "$vpn_mark_id" >/dev/null 2>&1 || exit 1
        fi
        if ! $IPT -t mangle -C PREROUTING -j CONNMARK --restore-mark >/dev/null 2>&1; then
            $IPT -t mangle -A PREROUTING -j CONNMARK --restore-mark >/dev/null 2>&1 || exit 1
        fi
    fi

    # Успешная обработка VPN-интерфейса не логируется: хук срабатывает на
    # каждое изменение состояния, и такие записи быстро раздували файл.
    # В лог попадают только ошибки.
done
fi

# Раунд 4, И-9: финальный выход вынесен за гейт _kz_do_mangle — нат-проход
# завершается здесь же со статусом 0, читаемость без изменения поведения.
#
# dns4.2.60 Н-03 (аудит 2026-09-29, H-03): если в применённом состоянии
# зафиксирован «fail», хук не имеет права рапортовать успех — вызывающие
# поток деплоя/панели должны видеть деградацию. Статус 4 — «применено с
# отказом хотя бы одного ресурса» (отличен от 1/общей аварии).
if [ -n "${TPROXY_STATE:-}" ] && [ -f "${TPROXY_STATE:-}" ] \
        && grep -q '^fail' "$TPROXY_STATE" 2>/dev/null; then
    # dns4.2.61 Х-01: код 4 — НАМЕРЕННАЯ фиксация деградации; снапшоты
    # не восстанавливаются (вычистка не должна откатываться трапом).
    NETFILTER_PRESERVE_FAILCLOSED=1
    exit 4
fi
exit 0
