#!/bin/sh
# remove keeps data but disables cron/NDM reactivation until next install.
if [ -f /opt/etc/unblock/.disabled ] && [ "${PURGE_PROJECT:-0}" != 1 ]; then
    exit 0
fi
# /opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh
# Реакция на изменение состояния интерфейсов прошивки.
#   Клиентский VPN (выход в интернет через туннель) -> таблица маршрутизации,
#   fwmark-правило и список /opt/etc/unblock/vpn-<описание>-<id>.txt.
#   Серверный VPN (WireGuard для удалённого доступа к роутеру) -> НЕ создаёт
#   таблицу и список; его клиенты обслуживаются общими правилами обхода
#   из 100-redirect.sh (интерфейс входит в LAN_IFACE_PATTERNS).
# Оболочка: BusyBox ash.

set -eu

PATH="/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

# deploy_bypass.sh sets this marker while replacing configs. Do not revive
# xray/trojan/hysteria/ss-redir from a concurrent WAN event before the install
# has reached its explicit post-install state.
# dns4.2.58 Б-1: маркер — каталог (старый файл — для совместимости).
{ [ -d /tmp/keenzoo_installing.d ] || [ -f /tmp/keenzoo_installing ]; } && exit 0

TAG="100-unblock-vpn.sh"

# dns4.2.21 (находка B6-5): порядок перебора туннелей — из конфига,
# как в DNS-слое (unblock_dnsmasq.sh:117), а не хардкодом.
config_words() {
    _cw_key="$1"
    _cw_default="$2"
    _cw_value="$(sed -n \
        "s/^[[:space:]]*${_cw_key}[[:space:]]*=[[:space:]]*\\[\\(.*\\)\\].*$/\\1/p" \
        /opt/etc/bot/bot_config.py 2>/dev/null \
        | tr -d "'\"" | tr ',' ' ' | tr -s ' ' | sed 's/^ //;s/ $//')"
    [ -n "$_cw_value" ] || _cw_value="$_cw_default"
    printf '%s\n' "$_cw_value"
}
RT_TABLES="/opt/etc/iproute2/rt_tables"
BOT_CONFIG="/opt/etc/bot/bot_config.py"
RCI="localhost:79/rci"

sleep 1

rci_get() {
    # dns4.2.27 (внешний аудит, V-02): NDM может ответить ошибкой
    # («485 Busy» при флуде событий) или пустотой; один сбой раньше
    # оставлял VPN-хук без данных до следующего события. Три попытки
    # с шагом 1 с; ошибка в теле ответа считается поводом для ретрая.
    _rg_try=0
    _rg_out=""
    while [ "$_rg_try" -lt 3 ]; do
        _rg_out="$(curl -s --max-time 5 "${RCI}/$1" 2>/dev/null || true)"
        case "$_rg_out" in
            ''|*'"error"'*)
                _rg_try=$((_rg_try + 1))
                [ "$_rg_try" -lt 3 ] && sleep 1
                continue ;;
        esac
        printf '%s\n' "$_rg_out"
        return 0
    done
    printf '%s\n' "$_rg_out"
}

check_allow_vpn_in_config="$(
    grep 'vpn_allowed' "$BOT_CONFIG" 2>/dev/null \
        | head -1 | sed 's/=/ /g' | tr -d '"' | awk '{print $2}' || true
)"

if [ -z "$check_allow_vpn_in_config" ]; then
    vpn_services="IKE|SSTP|OpenVPN|Wireguard|L2TP"
else
    vpn_services="$check_allow_vpn_in_config"
fi

# Нельзя искать VPN глобальным grep по show/interface: RCI возвращает
# интерфейсы вложенными блоками, и строка id соседнего блока WAN/Bridge
# ошибочно приклеивалась к найденному типу VPN. Сначала извлекаем id из
# собственных строк id, затем проверяем конфигурацию именно этого id.
rci_interface_ids() {
    rci_get "show/interface" | sed -nE \
        -e 's/.*[" ]id[" ]*[=:][ ]*"?([^",} ]+)"?.*/\1/p' \
        -e 's/^[[:space:]]*id[[:space:]]*[=:][[:space:]]*"?([^",} ]+)"?.*/\1/p' \
        | sed '/^$/d' | sort -u
}

interface_cfg() {
    rci_get "show/rc/interface/$1"
}

# Физические WAN, мосты и системные зоны никогда не являются клиентскими
# VPN policy-интерфейсами. Это явное исключение защищает даже при странном
# или неполном RCI-ответе.
is_forbidden_interface() {
    case "$1" in
        GigabitEthernet*|Ethernet*|Bridge*|ISP|Home|Guest|WifiMaster*|\
        WifiStation*|AccessPoint*|Mobile*|Cellular*|LTE*|Lte*|\
        Usb*|CdcEthernet*|Qmi*|Mbim*|Modem*|Pppoe*) return 0 ;;
    esac
    return 1
}

is_vpn_interface() {
    _ivi_id="$1"
    is_forbidden_interface "$_ivi_id" && return 1

    _ivi_cfg="$(interface_cfg "$_ivi_id")"
    # Дополнительная защита для LTE/USB-модемов, чьи логические имена
    # различаются между моделями Keenetic. Они являются WAN, даже если RCI
    # отдал их рядом с VPN-блоком.
    _ivi_link_kind="$(printf '%s\n' "$_ivi_cfg" \
        | grep -Ei 'type|technology|kind|transport|device' | head -20 || true)"
    printf '%s\n' "$_ivi_link_kind" \
        | grep -Eiq 'ethernet|usb|mobile|cellular|lte|modem|qmi|mbim' \
        && return 1

    # ID Wireguard0 есть в NDM, тогда как kernel-имя его устройства в
    # приложенном выводе — nwg0. Не отбрасываем его из-за несовпадения имён.
    case "$_ivi_id" in
        Wireguard*|OpenVPN*|SSTP*|L2TP*|IKE*) return 0 ;;
    esac

    printf '%s\n' "$_ivi_cfg" \
        | grep -Eiq "${vpn_services}|wireguard|openvpn|sstp|l2tp|ike"
}

# Удаление ошибочно созданного состояния выполняется только после проверки
# policy table и правил. В частности, это чистит старый набор
# unblockvpn-Подключение_Ethernet-GigabitEthernet1, если он пережил старый
# запуск проекта.
remove_rt_table_name() {
    _rrtn_name="$1"
    _rrtn_tmp="${RT_TABLES}.tmp.$$"
    # dns4.2.58 М-07 (аудит 2026-09-29): явные проверки вместо
    # «&& mv || rm», скрывавшего отказ записи.
    if awk -v n="$_rrtn_name" '$2 != n' "$RT_TABLES" > "$_rrtn_tmp" 2>/dev/null; then
        if mv -f "$_rrtn_tmp" "$RT_TABLES" 2>/dev/null; then
            return 0
        fi
    fi
    rm -f "$_rrtn_tmp"
    return 1
}

purge_forbidden_vpn_file() {
    _pf_file="$1"
    _pf_base="$(basename "$_pf_file" .txt)"
    _pf_if="${_pf_base##*-}"
    is_forbidden_interface "$_pf_if" || return 0

    _pf_set="unblock${_pf_base}"
    _pf_table_name="$(printf '%s' "$_pf_if" | tr '[:upper:]' '[:lower:]')"
    _pf_table_id="$(grep -w "$_pf_table_name" "$RT_TABLES" 2>/dev/null \
        | awk '{print $1}' | head -n1 || true)"
    if [ -n "$_pf_table_id" ]; then
        _pf_mark="0xd${_pf_table_id}"
        _pf_routes="$(ip -4 route show table "$_pf_table_id" 2>/dev/null \
            | wc -l | awk '{print $1}')"
        _pf_rules="$(ip -4 rule show 2>/dev/null \
            | grep -cE "table $_pf_table_id|fwmark $_pf_mark" || true)"
        logger -t "$TAG" "prune forbidden VPN $_pf_if: table=$_pf_table_id routes=$_pf_routes rules=$_pf_rules set=$_pf_set"

        # Сначала снимаем iptables references, затем уничтожаем ipset.
        # Иначе ipset destroy может быть отвергнут ядром как busy.
        if [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ]; then
            PURGE_VPN_SET="$_pf_set" PURGE_VPN_MARK="$_pf_mark" \
                type=iptable table=mangle \
                /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
        fi
        while ip -4 rule del from all table "$_pf_table_id" priority 1778 \
                >/dev/null 2>&1; do :; done
        while ip -4 rule del fwmark "$_pf_mark" lookup "$_pf_table_id" priority 1778 \
                >/dev/null 2>&1; do :; done
        ip -4 route flush table "$_pf_table_id" >/dev/null 2>&1 || true
        remove_rt_table_name "$_pf_table_name" || \
            logger -t "$TAG" "warn: запись $_pf_table_name в rt_tables не удалена"
    else
        logger -t "$TAG" "prune forbidden VPN $_pf_if: policy table absent, set=$_pf_set"
    fi

    ipset flush "$_pf_set" >/dev/null 2>&1 || true
    ipset destroy "${_pf_set}_new" >/dev/null 2>&1 || true
    ipset destroy "$_pf_set" >/dev/null 2>&1 || true
    rm -f "$_pf_file"
    logger -t "$TAG" "forbidden VPN state removed: $_pf_if / $_pf_set"
}

# dns4.2.64 P1-04 (аудит раунда 26): режим повторителя определяется
# СРАЗУ, до любого изменения состояния. Прежде повторитель — созданный
# именно из-за занятого замка — успевал пройти верхнеуровневую
# вычистку (меняя маршруты, правила, наборы и вызывая хук перехвата)
# до попытки взять замок. Повторитель занимается только своей
# очисткой под замком.
if [ "${1:-}" = "worker-cleanup" ] && [ -n "${2:-}" ]; then
    _KZ_WORKER_VPN="$2"
else
    _KZ_WORKER_VPN=""
fi

mkdir -p /opt/etc/iproute2
[ -f "$RT_TABLES" ] || : > "$RT_TABLES"
chmod 644 "$RT_TABLES"

# Убираем только заведомо запрещённые WAN/Bridge-файлы. Валидные client VPN
# не трогаются, даже если сейчас disconnected.
if [ -z "$_KZ_WORKER_VPN" ]; then
    for _pf_file in /opt/etc/unblock/vpn-*.txt; do
        [ -f "$_pf_file" ] || continue
        purge_forbidden_vpn_file "$_pf_file"
    done

    # unblock_update.sh вызывает этот скрипт в режиме только очистки перед
    # сборкой списков, чтобы старый WAN-set не успел попасть в dnsmasq/ipset.
    [ "${PRUNE_ONLY:-0}" = "1" ] && exit 0
fi

# dns4.2.63 Х-06 (аудит раунда 25, RU_R23 H-06): фоновый повторитель
# очистки запускается ОТДЕЛЬНЫМ вызовом этого же скрипта со служебным
# аргументом: в сабшелле «( … ) &» переменная «$$» равна PID
# родительского шелла (подтверждено для BusyBox ash), и после выхода
# родителя замок выглядел мёртвым и мог быть украден параллельным
# хуком, пока повторитель жив и держит его. Тело повторителя — ниже,
# после определений функций; здесь фиксируем режим и пропускаем
# тяжёлую для RCI сборку списка интерфейсов.
if [ -z "$_KZ_WORKER_VPN" ]; then
    vpn_check="$(
        for _rci_id in $(rci_interface_ids); do
            is_vpn_interface "$_rci_id" && printf '%s\n' "$_rci_id"
        done
    )"
fi

# ═════════════════════════════════════════════════════════════════════════
# Определение роли интерфейса: клиент (выход в интернет) или сервер (доступ)
# ═════════════════════════════════════════════════════════════════════════
# Роль определяется по конфигурации и маршрутизации. Runtime-endpoint пира
# после handshake НЕ используется: он появляется и у серверных пиров.
# Используется только СТАТИЧЕСКИЙ endpoint из сохранённой конфигурации
# (show/rc/interface) — его наличие характерно для клиентского туннеля,
# в т.ч. split-tunnel без defaultgw. Регулярные выражения допускают
# опциональные кавычки и пробелы вокруг '=' / ':' — формат вывода rc
# (INI или JSON с кавычками) на стенде одинаково покрыт.
is_client_tunnel() {
    _ict_id="$1"
    _ict_cfg="$(interface_cfg "$_ict_id")"

    # KN-1012 не реализует RCI-запрос роли интерфейса: такой вызов
    # давал в журнале сообщение «not found». Роль определяется по
    # конфигурации и маршрутизации, без неподдерживаемого endpoint.

    case "$_ict_id" in
        Wireguard*)
            # 1. Признаки локального сервера имеют безусловный приоритет.
            if printf '%s\n' "$_ict_cfg" \
                | grep -Eiq '^[[:space:]]*"?(listen[-_ ]?port|listen[[:space:]]*[=:]|server[[:space:]]*[=:])'; then
                logger -t "$TAG" "VPN $_ict_id: classified as SERVER (listen-port/server marker)"
                return 1
            fi
            # 2. Статический IPv4-endpoint в конфиге — клиентский туннель
            #    (split-tunnel без defaultgw сюда же). IPv6-литерал [::]
            #    осознанно не считается основанием: проект IPv4-only.
            if printf '%s\n' "$_ict_cfg" \
                | grep -Eqi '^[[:space:]]*"?endpoint[[:space:]]*"?[[:space:]]*[=:][[:space:]]*"?[A-Za-z0-9_.-]+:[0-9]+' \
                && ! printf '%s\n' "$_ict_cfg" \
                    | grep -Eqi '^[[:space:]]*"?endpoint[[:space:]]*"?[[:space:]]*[=:][[:space:]]*"?[\[][0-9a-fA-F:]+[\]]:[0-9]+'; then
                logger -t "$TAG" "VPN $_ict_id: classified as CLIENT (static endpoint in config)"
                return 0
            fi
            ;;
    esac

    _ict_global="$(rci_get "show/interface/${_ict_id}/global" \
        | tr -d '"' | tr -d ' ' | tr '[:upper:]' '[:lower:]')"
    if [ "$_ict_global" = "true" ]; then
        logger -t "$TAG" "VPN $_ict_id: classified as CLIENT (global=true)"
        return 0
    fi

    _ict_defaultgw="$(rci_get "show/interface/${_ict_id}/defaultgw" \
        | tr -d '"' | tr -d ' ' | tr '[:upper:]' '[:lower:]')"
    if [ "$_ict_defaultgw" = "true" ]; then
        logger -t "$TAG" "VPN $_ict_id: classified as CLIENT (defaultgw=true)"
        return 0
    fi

    # Неизвестная роль безопасно считается server/access: policy routing
    # нельзя включать на обычном интерфейсе и нельзя делать WAN-утечку.
    logger -t "$TAG" "VPN $_ict_id: classified as SERVER (unknown role fallback)"
    return 1
}

# Очистка состояния клиентского VPN при disconnected/down. Файл списка
# сохраняется: при следующем подключении он снова может быть заполнен, но
# policy rule, маршруты, mark и старые адреса не должны переживать туннель.
cleanup_client_vpn() {
    _cc_vpn="$1"
    _cc_table_name="$(printf '%s' "$_cc_vpn" | tr '[:upper:]' '[:lower:]')"
    _cc_table_id="$(grep -w "$_cc_table_name" "$RT_TABLES" 2>/dev/null \
        | awk '{print $1}' | head -n1 || true)"
    [ -n "$_cc_table_id" ] || return 0

    _cc_mark="0xd${_cc_table_id}"
    while ip -4 rule del from all table "$_cc_table_id" priority 1778 \
            >/dev/null 2>&1; do :; done
    while ip -4 rule del fwmark "$_cc_mark" lookup "$_cc_table_id" priority 1778 \
            >/dev/null 2>&1; do :; done
    ip -4 route flush table "$_cc_table_id" >/dev/null 2>&1 || true

    # Все списки, созданные для этого интерфейса, имеют суффикс -<id>.
    for _cc_list in /opt/etc/unblock/vpn-*-"$_cc_vpn".txt; do
        [ -f "$_cc_list" ] || continue
        _cc_set="unblock$(basename "$_cc_list" .txt)"
        ipset flush "$_cc_set" >/dev/null 2>&1 || true
    done

    # dns4.2.19: запись из реестра исходящих туннелей снимаем по RCI-id
    # (второе поле) — он известен всегда, в отличие от kernel-имени на
    # уже упавшем интерфейсе, которое RCI может не вернуть.
    if [ -f /opt/etc/unblock/.vpn_client_devs ]; then
        _vcd_tmp="/opt/etc/unblock/.vpn_client_devs.tmp.$$"
        # dns4.2.58 М-07: отказ записи виден в журнале, а не скрыт.
        if awk -v id="$_cc_vpn" '$2 != id {print}' \
                /opt/etc/unblock/.vpn_client_devs > "$_vcd_tmp" 2>/dev/null; then
            if ! mv -f "$_vcd_tmp" /opt/etc/unblock/.vpn_client_devs \
                    2>/dev/null; then
                logger -t "$TAG" "warn: реестр туннелей не обновлён ($_cc_vpn)"
            fi
        else
            logger -t "$TAG" "warn: реестр туннелей не очищен ($_cc_vpn)"
        fi
        rm -f "$_vcd_tmp" 2>/dev/null || true
    fi

    logger -t "$TAG" "VPN $_cc_vpn OFF: policy rules, routes and ipset cleared"
    if [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ]; then
        type=iptable table=nat \
            /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
        type=iptable table=mangle \
            /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 || true
    fi
}

# dns4.2.19: тихий prune реестра исходящих туннелей от устройств, которых
# больше нет в ядре. Вызывается на down-событиях при отсутствии живого
# состояния: без логов и без вызова 100-redirect.sh.
prune_vpn_client_devs() {
    _pd_file="/opt/etc/unblock/.vpn_client_devs"
    [ -f "$_pd_file" ] || return 0
    _pd_links="$(ip -o link show 2>/dev/null \
        | awk -F': ' '{print $2}' | cut -d@ -f1)"
    _pd_tmp="${_pd_file}.prune.$$"
    # dns4.2.58 М-07: явные ветки вместо «&& mv || rm».
    if awk -v live="$_pd_links" '
        BEGIN { n=split(live, a, " "); for (i=1; i<=n; i++) if (a[i] != "") active[a[i]]=1 }
        active[$1] { print }
    ' "$_pd_file" > "$_pd_tmp" 2>/dev/null; then
        if ! mv -f "$_pd_tmp" "$_pd_file" 2>/dev/null; then
            logger -t "$TAG" "warn: реестр устройств не обновлён"
        fi
    else
        logger -t "$TAG" "warn: реестр устройств не очищен"
    fi
    rm -f "$_pd_tmp" 2>/dev/null || true
}

# dns4.2.19: атомарные короткие критические секции для rt_tables и
# реестра `.vpn_client_devs`. Два независимых хука (ifstatechanged.d и на
# KeeneticOS 4.x также iflayerchanged.d) могут сработать по одному
# событию; пары «проверил-дописал» без замка давали бы дубли id таблиц.
# Замок НЕ удерживается через sleep/RCI-запросы — две отдельные секции.
VPN_STATE_LOCK="/tmp/keenzoo_vpn_state.lockdir"
# РАУД 42 (повторный аудит, R41-VPN-RACE): токен активной секции
# владения; пуст — владения нет, и общий трэп ничего не снимает.
VPN_LOCK_TOKEN=''
VPN_LOCK_SEQ=0
vpn_lock_acquire() {
    # РАУД 42 (повторный аудит, R41-VPN-PRETRAP): трэпы ставятся ДО
    # первого захвата — обработчик пустая операция, пока токен
    # владения не задан, поэтому вне активной секции выход ничего не
    # снимает. Окна между «mkdir» и установкой трэпов больше нет.
    trap vpn_lock_release EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM
    trap 'exit 129' HUP
    _vla_tries=10
    while [ "$_vla_tries" -gt 0 ]; do
        # РАУД 43 (повторный аудит, R42-VPN-PRETOKEN): токен готов
        # ДО попытки захвата — при сигнале сразу после «mkdir»
        # обработчик уже способен опознать свой каталог, в том числе
        # при неудачной записи «owner».
        VPN_LOCK_SEQ=$(( VPN_LOCK_SEQ + 1 ))
        VPN_LOCK_TOKEN="$$.$(awk '{print $22}' "/proc/$$/stat" 2>/dev/null).$(date +%s).$VPN_LOCK_SEQ"
        if mkdir "$VPN_STATE_LOCK" 2>/dev/null; then
            # РАУД 43 (§4.2): владелец — первое действие после
            # «mkdir»; отказ записи не остаётся без диагностики.
            printf '%s\n' "$VPN_LOCK_TOKEN" > "$VPN_STATE_LOCK/owner" 2>/dev/null || \
                logger -t "$TAG" "VPN lock: не удалось записать владельца (очистка по пустому «owner»)"
            printf '%s\n' "$$" > "$VPN_STATE_LOCK/pid"
            awk '{print $22}' "/proc/$$/stat" 2>/dev/null \
                > "$VPN_STATE_LOCK/stime" || true
            return 0
        fi
        # РАУД 43: попытка не удалась — владения нет; гасим токен,
        # чтобы трэп при выходе не тронул чужой частичный лок.
        VPN_LOCK_TOKEN=''
        # Мёртвый держатель (pid отсутствует или сменилось starttime,
        # field 22 /proc/<pid>/stat) — сброс немедленно, без TTL.
        _vla_pid="$(cat "$VPN_STATE_LOCK/pid" 2>/dev/null || true)"
        _vla_stime="$(cat "$VPN_STATE_LOCK/stime" 2>/dev/null || true)"
        _vla_dead=0
        case "$_vla_pid" in
            ''|*[!0-9]*) ;;
            *)
                if [ ! -d "/proc/$_vla_pid" ]; then
                    _vla_dead=1
                else
                    _vla_cur="$(awk '{print $22}' \
                        "/proc/$_vla_pid/stat" 2>/dev/null || true)"
                    [ -n "$_vla_stime" ] && [ -n "$_vla_cur" ] \
                        && [ "$_vla_cur" != "$_vla_stime" ] && _vla_dead=1
                fi
                ;;
        esac
        if [ "$_vla_dead" -eq 1 ]; then
            # РАУД 40 (повторный аудит, R39-LOCK-03): двойная сверка
            # маркера перед очисткой устаревшего лока — не удалять,
            # если между проверками появился новый владелец.
            _vla_m2="$(cat "$VPN_STATE_LOCK/pid" 2>/dev/null || true);$(cat "$VPN_STATE_LOCK/stime" 2>/dev/null || true)"
            if [ "$_vla_pid;$_vla_stime" = "$_vla_m2" ]; then
                rm -rf "$VPN_STATE_LOCK" 2>/dev/null || true
            fi
            # РАУД 40 (повторный аудит, R39-LOCK-04): ограниченное
            # ожидание и при неустранимой ошибке удаления.
        fi
        # Метаданные отсутствуют/повреждены либо держатель жив:
        # TTL 30 c по stat -c %Y (busybox date -r не гарантирован), с
        # защитой от отрицательного возраста (скачок часов назад).
        _vla_mtime="$(stat -c %Y "$VPN_STATE_LOCK" 2>/dev/null || echo 0)"
        _vla_age=$(( $(date +%s 2>/dev/null || echo 0) - _vla_mtime ))
        if [ "$_vla_age" -ge 30 ] || [ "$_vla_age" -lt 0 ]; then
            # РАУД 40 (повторный аудит, R39-LOCK-03): двойная сверка
            # маркера перед очисткой устаревшего лока.
            _vla_m2="$(cat "$VPN_STATE_LOCK/pid" 2>/dev/null || true);$(cat "$VPN_STATE_LOCK/stime" 2>/dev/null || true)"
            if [ "$_vla_pid;$_vla_stime" = "$_vla_m2" ]; then
                rm -rf "$VPN_STATE_LOCK" 2>/dev/null || true
            fi
            # РАУД 40 (повторный аудит, R39-LOCK-04): ограниченное
            # ожидание и при неустранимой ошибке удаления.
        fi
        _vla_tries=$(( _vla_tries - 1 ))
        usleep 100000 2>/dev/null || sleep 1
    done
    return 1
}
vpn_lock_release() {
    # РАУД 43 (повторный аудит, R42-VPN-PRETOKEN): снимается только
    # лок АКТИВНОЙ секции владения — по непустому токену. Пустой или
    # отсутствующий «owner» при непустом токене — частичная
    # инициализация СВОЕГО лока (включая отказ записи «owner»);
    # снимается тоже. После ручного снятия токен гасится, и тот же
    # трэп при выходе процесса уже ничего не трогает: чужой новый
    # каталог с пустыми метаданными не удаляется.
    if [ -n "$VPN_LOCK_TOKEN" ]; then
        _vlr_own="$(cat "$VPN_STATE_LOCK/owner" 2>/dev/null || true)"
        case "$_vlr_own" in
            "$VPN_LOCK_TOKEN"|'')
                # РАУД 43 (§7 P2-2): ограниченная повторная попытка;
                # токен гасится только когда каталог действительно
                # исчез, иначе снятие повторит ручной вызов или трэп.
                _vlr_try=0
                while [ "$_vlr_try" -lt 3 ] && [ -d "$VPN_STATE_LOCK" ]; do
                    rm -rf "$VPN_STATE_LOCK" 2>/dev/null || true
                    _vlr_try=$(( _vlr_try + 1 ))
                done
                ;;
        esac
    fi
    [ -d "$VPN_STATE_LOCK" ] || VPN_LOCK_TOKEN=''
}

# dns4.2.60 C-02 (аудит 2026-09-29): никакой изменяющий состояние
# cleanup не выполняется вне общего замка. Если замок занят, демонтаж
# откладывается: параллельный процесс прямо сейчас меняет те же
# policy-ресурсы, и одновременная вычистка уничтожила бы его свежие
# маршрут/правило/реестр.
# dns4.2.61 Х-03.3 (аудит раунда 23, RU_CURRENT H-03): «следующего
# события» может не быть — ограниченный одноразовый фоновый повтор
# (идиома проекта, ср. повтор в 100-redirect.sh). Маркер гарантирует
# один повтор на запрос; это не демон и не постоянный скрипт.
cleanup_client_vpn_locked() {
    if vpn_lock_acquire; then
        cleanup_client_vpn "$1"
        vpn_lock_release
        return 0
    fi
    _cvl_marker="/tmp/keenzoo.vpn.cleanup.retry.$1"
    if mkdir "$_cvl_marker" 2>/dev/null; then
        # dns4.2.63 Х-06 (аудит раунда 25, RU_R23 H-06): повторитель —
        # отдельный запуск этого же скрипта (см. метку режима выше),
        # а не сабшелл: его «$$» и есть настоящий PID воркера, и
        # метаданные владения замком (pid + starttime) корректны.
        #
        # dns4.2.64 С-1 (аудит раунда 26, v23): запуск через явный
        # интерпретатор — «"$0"» исполним только с битом «х» и при
        # прямом вызове. Дерево без прав (копия без «-p») или вызов
        # «sh hook» молча оставляли маркер навсегда. Относительный
        # «$0» доопределяется каноническим путём.
        _cvl_self="$0"
        case "$_cvl_self" in
            /*) ;;
            *) if [ -f /opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh ]; then
                    _cvl_self=/opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh
               fi ;;
        esac
        if [ -r "$_cvl_self" ]; then
            /bin/sh "$_cvl_self" worker-cleanup "$1" \
                >/dev/null 2>&1 </dev/null &
            logger -t "$TAG" "warn: vpn state lock busy ($1): cleanup поставлен в ограниченный фоновый повтор"
        else
            rmdir "$_cvl_marker" 2>/dev/null || true
            logger -t "$TAG" "warn: vpn state lock busy ($1): повторитель не запущен ($_cvl_self недоступен) — очистка при следующем событии"
        fi
    else
        logger -t "$TAG" "warn: vpn state lock busy ($1): повтор cleanup уже поставлен"
    fi
    return 0
}

# dns4.2.63 Х-06 (аудит раунда 25, RU_R23 H-06): тело фонового
# повторителя очистки. Исполняется отдельным процессом (см. выше),
# поэтому «$$» в vpn_lock_acquire — настоящий PID, и живой воркер не
# выглядит мёртвым держателем замка. Один повтор на запрос (маркер),
# бюджет 60 с, это не демон и не постоянный скрипт.
if [ -n "${_KZ_WORKER_VPN:-}" ]; then
    _wc_marker="/tmp/keenzoo.vpn.cleanup.retry.$_KZ_WORKER_VPN"
    trap 'rm -rf "$_wc_marker" 2>/dev/null || true' EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM
    trap 'exit 129' HUP
    _wc_wait=0
    while [ "$_wc_wait" -lt 60 ]; do
        if vpn_lock_acquire; then
            cleanup_client_vpn "$_KZ_WORKER_VPN"
            vpn_lock_release
            exit 0
        fi
        sleep 2
        _wc_wait=$((_wc_wait + 2))
    done
    logger -t "$TAG" "error: vpn cleanup повтор исчерпан ($_KZ_WORKER_VPN): замок занят более 60 с, нужен ручной разбор"
    exit 0
fi

# RCI может на короткое время убрать интерфейс из show/interface раньше,
# чем hook передаст disconnected. Добавляем переданный id в обработку.
if [ "${1:-}" = "hook" ] && [ -n "${id:-}" ]; then
    # RCI иногда сообщает id до того, как он появился в show/interface,
    # но добавлять можно только структурно подтверждённый VPN id.
    if is_vpn_interface "$id"; then
        # dns4.2.47 N-22 (раунд 9): vpn_check собирается построчно
        # ($( ... printf '%s\n' ...)), а проверка дубля ждала пробелы
        # вокруг id — она не срабатывала, и событие обрабатывалось
        # дважды. Нормализуем разделители перед сравнением.
        case " $(printf '%s\n' "$vpn_check" | tr '\n' ' ') " in
            *" $id "*) ;;
            *) vpn_check="$vpn_check $id" ;;
        esac
    fi
fi

for vpn in $vpn_check; do
    [ "${1:-}" = "hook" ] || continue
    [ "${id:-}" = "$vpn" ] || continue

    # dns4.2.19: $change — ИСТОЧНИК события (link|connected|up|config), а
    # не статус; disconnected|down|stopped в нём никогда не бывает, и
    # прежняя ветка демонтажа была мёртвой. Статус — в $connected/$link/$up.
    _is_down=0
    case "${connected:-}" in no|false) _is_down=1 ;; esac
    case "${link:-}"      in down)     _is_down=1 ;; esac
    case "${up:-}"        in no|down)  _is_down=1 ;; esac

    if [ "$_is_down" -eq 1 ]; then
        # Демонтаж и строка «OFF» — только при живом состоянии в ядре:
        # иначе каждое повторное down/config-событие спамило бы syslog и
        # дёргало 100-redirect.sh. Иначе — тихий prune реестра туннелей.
        _down_table="$(printf '%s' "$vpn" | tr '[:upper:]' '[:lower:]')"
        _down_table_id="$(grep -w "$_down_table" "$RT_TABLES" 2>/dev/null \
            | awk '{print $1}' | head -n1 || true)"
        _down_has=0
        if [ -n "$_down_table_id" ]; then
            _down_mark="0xd${_down_table_id}"
            ip -4 rule show 2>/dev/null | grep -q "fwmark $_down_mark" \
                && _down_has=1
            [ "$_down_has" -eq 1 ] || {
                ip -4 route show table "$_down_table_id" 2>/dev/null \
                    | grep -q . && _down_has=1
            }
        fi
        if [ "$_down_has" -eq 1 ]; then
            # dns4.2.60 C-02 (аудит 2026-09-29): демонтаж только под замком.
            cleanup_client_vpn_locked "$vpn"
        else
            # dns4.2.60 C-02 (аудит 2026-09-29): сборка мусора реестра тоже
            # мутирует общее состояние — только под тем же замком.
            if vpn_lock_acquire; then
                prune_vpn_client_devs
                vpn_lock_release
            fi
        fi
        continue
    fi

    # Промежуточные события без активного состояния пропускаем. Если обе
    # переменные пусты (экзотика NDM), идём дальше к RCI-перепроверке —
    # сохраняем прежнее поведение без регресса.
    if [ -n "${connected:-}${link:-}" ] \
        && [ "${connected:-}" != "yes" ] && [ "${link:-}" != "up" ]; then
        continue
    fi

    if ! is_client_tunnel "$vpn"; then
        # Серверный туннель (например, WireGuard для удалённого управления).
        # Никаких таблиц/списков — только сообщение в лог. Клиенты такого
        # туннеля получают обход через общие правила 100-redirect.sh.
        logger -t "$TAG" "VPN $vpn: серверный режим, policy routing пропущен"
        [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ] \
            && type=iptable table=nat /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 \
            || true
        continue
    fi

    vpn_table="$(printf '%s' "$vpn" | tr '[:upper:]' '[:lower:]')"

    # Критическая секция 1/2: append в rt_tables строго под замком —
    # параллельный хук (ifstatechanged/iflayerchanged) не должен получить
    # дубль id. Замок через sleep ниже НЕ удерживается.
    if vpn_lock_acquire; then
        if grep -qw "$vpn_table" "$RT_TABLES" 2>/dev/null; then
            logger -t "$TAG" "VPN $vpn: таблица уже есть"
        else
            # dns4.2.28 (внешний отчёт, P-01): читаются только числовые
            # id 1000–4095 и берётся МАКСИМУМ. Прежний код брал $1
            # ПОСЛЕДНЕЙ строки без разбора: комментарий в хвосте
            # чужого/системного rt_tables ронял арифметику под set -eu
            # («Illegal number», rc=2 — хук умирал на каждом событии),
            # «0 unspec» давал counter_new=1 в обход диапазона, а
            # пустой хвост — дубль id 1001 рядом с существующей
            # таблицей (общий fwmark, трафик шёл не туда).
            # dns4.2.29 (внешний отчёт, N-02): «print _m + 0» — запись с
            # ведущим нулём (строка «01008») печаталась строкой как есть:
            # арифметика $((01008+1)) — окталь, «Illegal number», хук
            # умирал; «01001» тихо давал 514. «+ 0» нормализует в десятичную.
            get_last_fwmark_id="$(awk \
                '$1 ~ /^[0-9]+$/ && $1 >= 1000 && $1 <= 4095 \
                    && $1 + 0 > _m { _m = $1 }
                 END { if (_m) print _m + 0 }' \
                "$RT_TABLES" 2>/dev/null || true)"
            case "$get_last_fwmark_id" in
                ''|*[!0-9]*) counter_new=1001 ;;
                *) counter_new=$((get_last_fwmark_id + 1)) ;;
            esac
            # dns4.2.27 (внешний аудит, R-03): верхний предел номера —
            # метка строится как 0xd<id>, поэтому id обязан оставаться
            # в пределах 0xFFF (старшие биты метки зарезервированы под
            # TPROXY/XRAY-метки). Практически недостижимо, но дёшево.
            if [ "$counter_new" -gt 4095 ]; then
                logger -t "$TAG" \
                    "error: VPN $vpn: исчерпан предел номеров таблиц ($counter_new > 4095)"
                vpn_lock_release
                continue
            fi
            printf '%s %s\n' "$counter_new" "$vpn_table" >> "$RT_TABLES"
            logger -t "$TAG" "VPN $vpn: создана таблица $counter_new"
        fi
        vpn_lock_release
    else
        logger -t "$TAG" "warn: vpn state lock busy ($vpn): rt_tables не обновлён, повтор при следующем событии"
        continue
    fi

    sleep 1
    vpn_table_id="$(grep -w "$vpn_table" "$RT_TABLES" | awk '{print $1}' | head -n1)"
    [ -n "$vpn_table_id" ] || continue
    get_fwmark_id="0xd${vpn_table_id}"

    vpn_link_up="$(rci_get "show/interface/${vpn}/connected" | tr -d '"')"

    case "$vpn_link_up" in
        yes|up) ;;
        *)
            # dns4.2.60 C-02 (аудит 2026-09-29): демонтаж только под замком.
            cleanup_client_vpn_locked "$vpn"
            continue
            ;;
    esac

    sleep 2
    sleep 3
    vpn_ip="$(rci_get "show/interface/${vpn}/address" | tr -d '"')"
    # dns4.2.60 C-02 (аудит 2026-09-29): демонтаж только под замком.
    [ -n "$vpn_ip" ] || { cleanup_client_vpn_locked "$vpn"; continue; }

    vpn_dev="$(rci_get "show/interface/${vpn}/interface-name" | tr -d '"')"
    if [ -z "$vpn_dev" ]; then
        vpn_dev="$(ip -4 addr show 2>/dev/null \
            | awk -v a="$vpn_ip" '/^[0-9]+:/{dev=$2} $1=="inet" && $2 ~ "^"a"/" {gsub(":","",dev); print dev; exit}')"
    fi
    # dns4.2.60 C-02 (аудит 2026-09-29): демонтаж только под замком.
    [ -n "$vpn_dev" ] || { cleanup_client_vpn_locked "$vpn"; continue; }

    # dns4.2.58 М-01 (аудит 2026-09-29): имена строятся из ограниченного
    # slug интерфейсного id; description идёт только в журнал. Раньше
    # RCI-description попадал в имена файлов и ipset: «/», управляющие
    # символы и длина (ограничение имени ipset — 31 байт) ломали путь,
    # а ошибка «ipset create» подавлялась.
    case "$vpn" in
        ''|*[!A-Za-z0-9_]*)
            logger -t "$TAG" "invalid VPN id: $vpn"
            # dns4.2.60 C-02 (аудит 2026-09-29): демонтаж только под замком.
            cleanup_client_vpn_locked "$vpn"
            continue
            ;;
    esac
    if [ "${#vpn}" -gt 18 ]; then
        logger -t "$TAG" "VPN id is too long: $vpn"
        # dns4.2.60 C-02 (аудит 2026-09-29): демонтаж только под замком.
        cleanup_client_vpn_locked "$vpn"
        continue
    fi
    vpn_desc="$(rci_get "show/interface/${vpn}/description" | tr -d '"\r\n' | cut -c1-64)"
    [ -n "$vpn_desc" ] || vpn_desc="vpn"
    unblockvpn="unblockvpn-v-${vpn}"
    vpn_list="/opt/etc/unblock/vpn-v-${vpn}.txt"
    # Одноразовая миграция старых списков выполняется НИЖЕ, под общим
    # замком (аудит раунда 23, Х-03.2): это мутация общего состояния.

    # dns4.2.19: для L3-туннелей (WireGuard nwg*/wg*) шлюза по IP нет, а
    # "via $vpn_ip" задавал nexthop на СОБСТВЕННЫЙ адрес роутера — ядро
    # отклоняло маршрут, таблица оставалась без default, policy routing
    # молча не работал. Для PPP/L2TP — via внешний gateway из RCI, с
    # обязательной валидацией IPv4 (на отсутствующем поле RCI может
    # вернуть error-JSON, а не пустоту).
    vpn_gw="$(rci_get "show/interface/${vpn}/gateway" 2>/dev/null \
        | tr -d '"\r ' | head -n1 || true)"
    case "$vpn_gw" in 0.0.0.0) vpn_gw="" ;; esac
    if [ -n "$vpn_gw" ]; then
        printf '%s\n' "$vpn_gw" | awk -F. \
            'NF==4 && $1<=255 && $2<=255 && $3<=255 && $4<=255 {ok=1} END{exit !ok}' \
            || vpn_gw=""
    fi

    # dns4.2.57 C-01/H-01: весь политический транзакт (маршрут ->
    # правило -> реестр) выполняется под общим замком, а правило
    # публикуется ТОЛЬКО после подтверждённого default-маршрута в таблице.
    # Иначе помеченный трафик уходил по правилу в таблицу без default и
    # молча выходил напрямую в WAN. Дубли экземпляров правила вычищаются
    # циклом. RCI-вызовы и паузы остаются ДО взятия замка (см. выше).
    if ! vpn_lock_acquire; then
        # dns4.2.60 C-02 (аудит 2026-09-29): замок занят — другой процесс
        # прямо сейчас меняет те же policy-ресурсы. Демонтаж БЕЗ замка
        # уничтожил бы его свежие маршрут/правило/реестр. Ничего не
        # удаляем: только журнал, повтор при следующем событии.
        logger -t "$TAG" "warn: vpn state lock busy ($vpn): политика не опубликована, повтор при следующем событии"
        continue
    fi

    # dns4.2.61 Х-03.1 (аудит раунда 23, RU_CURRENT H-03): сверка
    # состояния ПОСЛЕ взятия замка. Иначе устаревшее событие «up»
    # (прочитанное до пауз и до замка) публиковало бы политику по
    # состоянию, которого уже нет — например, после более нового
    # «down», обработанного параллельным хуком. Замок сериализует
    # операции, но не порядок событий; порядок гарантирует только
    # повторная проверка под замком.
    # dns4.2.63 Х-07 (аудит раунда 25, RU_R23 H-07): под замком
    # перечитывается ВЕСЬ кортеж — не только «connected». При
    # reconnect интерфейс может остаться «connected», но сменить
    # устройство/адрес/шлюз; значения, прочитанные до пауз и замка,
    # опубликовали бы политику на устройстве, которого уже нет.
    _vpn_link_now="$(rci_get "show/interface/${vpn}/connected" | tr -d '"')"
    case "$_vpn_link_now" in
        yes|up) ;;
        *)
            logger -t "$TAG" "VPN $vpn: состояние сменилось на ${_vpn_link_now:-unknown} пока ждали замок — политика не публикуется, демонтаж"
            cleanup_client_vpn "$vpn"
            vpn_lock_release
            continue
            ;;
    esac
    _vpn_ip_now="$(rci_get "show/interface/${vpn}/address" | tr -d '"')"
    if [ -z "$_vpn_ip_now" ]; then
        logger -t "$TAG" "VPN $vpn: адрес исчез пока ждали замок — политика не публикуется, демонтаж"
        cleanup_client_vpn "$vpn"
        vpn_lock_release
        continue
    fi
    if [ "$_vpn_ip_now" != "$vpn_ip" ]; then
        logger -t "$TAG" "VPN $vpn: адрес сменился пока ждали замок ($vpn_ip -> $_vpn_ip_now) — берём свежие данные"
        vpn_ip="$_vpn_ip_now"
    fi
    _vpn_dev_now="$(rci_get "show/interface/${vpn}/interface-name" | tr -d '"')"
    if [ -z "$_vpn_dev_now" ]; then
        _vpn_dev_now="$(ip -4 addr show 2>/dev/null \
            | awk -v a="$vpn_ip" '/^[0-9]+:/{dev=$2} $1=="inet" && $2 ~ "^"a"/" {gsub(":","",dev); print dev; exit}')"
    fi
    if [ -z "$_vpn_dev_now" ]; then
        logger -t "$TAG" "VPN $vpn: устройство исчезло пока ждали замок — политика не публикуется, демонтаж"
        cleanup_client_vpn "$vpn"
        vpn_lock_release
        continue
    fi
    if [ "$_vpn_dev_now" != "$vpn_dev" ]; then
        logger -t "$TAG" "VPN $vpn: устройство сменилось пока ждали замок ($vpn_dev -> $_vpn_dev_now) — берём свежие данные"
        vpn_dev="$_vpn_dev_now"
    fi
    # Для не-WireGuard туннелей в маршруте участвует шлюз.
    case "$vpn_dev" in
        nwg*|wg*) ;;
        *)
            _vpn_gw_now="$(rci_get "show/interface/${vpn}/gateway" 2>/dev/null \
                | tr -d '"\r ' | head -n1 || true)"
            case "$_vpn_gw_now" in 0.0.0.0) _vpn_gw_now="" ;; esac
            if [ -n "$_vpn_gw_now" ]; then
                printf '%s\n' "$_vpn_gw_now" | awk -F. \
                    'NF==4 && $1<=255 && $2<=255 && $3<=255 && $4<=255 {ok=1} END{exit !ok}' \
                    || _vpn_gw_now=""
            fi
            if [ "${_vpn_gw_now:-}" != "${vpn_gw:-}" ]; then
                logger -t "$TAG" "VPN $vpn: шлюз сменился пока ждали замок (${vpn_gw:-<нет>} -> ${_vpn_gw_now:-<нет>}) — берём свежие данные"
                vpn_gw="$_vpn_gw_now"
            fi
            ;;
    esac

    # dns4.2.64 P1-03 (аудит раунда 26): роль перепроверяется ПОД
    # замком. Событие «up» читало её до пауз; клиент мог стать
    # сервером (и наоборот) пока ждали замок, публикация клиентской
    # политики для серверного туннеля рвала бы входящие сессии.
    if ! is_vpn_interface "$vpn" || ! is_client_tunnel "$vpn"; then
        logger -t "$TAG" "VPN $vpn: роль сменилась пока ждали замок (клиент -> сервер/не-туннель) — клиентская политика не публикуется, демонтаж"
        cleanup_client_vpn "$vpn"
        vpn_lock_release
        continue
    fi

    # dns4.2.61 Х-03.2 (аудит раунда 23, RU_CURRENT H-03): одноразовая
    # миграция старых списков — ПОД замком (это мутация общего
    # состояния: файл списка и набор пересекаются с параллельным
    # применением других хуков). Содержимое НЕ уничтожается: записи
    # переносятся дедуплицированными (аудит раунда 20, В-2).
    for _mig_file in /opt/etc/unblock/vpn-*-"${vpn}".txt; do
        [ -f "$_mig_file" ] || continue
        [ "$_mig_file" = "$vpn_list" ] && continue
        _mig_set="unblock$(basename "$_mig_file" .txt)"
        [ -f "$vpn_list" ] || : > "$vpn_list"
        cat "$_mig_file" >> "$vpn_list" 2>/dev/null || true
        sort -u "$vpn_list" -o "$vpn_list" 2>/dev/null || true
        ipset destroy "$_mig_set" >/dev/null 2>&1 || true
        rm -f "$_mig_file"
        logger -t "$TAG" "миграция: содержимое $_mig_file перенесено в $vpn_list"
    done

    _kz_policy_ok=0
    # dns4.2.64 P1-03 (аудит раунда 26): отказ «route replace» — сбой
    # транзакции, а не запись в журнал. Прежде публикация шла дальше,
    # и успех доказывался ЛЮБЫМ default в таблице — в том числе
    # устаревшим маршрутом прошлого подключения через старые
    # устройство/шлюз.
    _kz_route_ok=0
    case "$vpn_dev" in
        nwg*|wg*)
            # dns4.2.65 Н-4 (аудит раунда 27): у L3-туннелей шлюза нет.
            # Если RCI всё же вернул непустой валидный шлюз, маршрут
            # строится без «via», а сверка требовала бы «via» — и
            # политика не публиковалась бы никогда. Шлюз обнуляется ДО
            # замены и сверки.
            vpn_gw=""
            if _rerr="$(ip -4 route replace table "$vpn_table_id" \
                default dev "$vpn_dev" 2>&1)"; then
                _kz_route_ok=1
            else
                logger -t "$TAG" "ERROR: не удалось установить default dev $vpn_dev для $vpn (таблица $vpn_table_id): $_rerr"
            fi
            ;;
        *)
            if [ -n "$vpn_gw" ]; then
                if _rerr="$(ip -4 route replace table "$vpn_table_id" \
                    default via "$vpn_gw" dev "$vpn_dev" 2>&1)"; then
                    _kz_route_ok=1
                else
                    logger -t "$TAG" "ERROR: не удалось установить default via $vpn_gw dev $vpn_dev для $vpn (таблица $vpn_table_id): $_rerr"
                fi
            else
                if _rerr="$(ip -4 route replace table "$vpn_table_id" \
                    default dev "$vpn_dev" 2>&1)"; then
                    _kz_route_ok=1
                else
                    logger -t "$TAG" "ERROR: не удалось установить default dev $vpn_dev для $vpn (таблица $vpn_table_id): $_rerr"
                fi
            fi
            ;;
    esac

    # Подтверждается ТОЧНЫЙ кортеж «default [via <шлюз>] dev <устройство>»,
    # а не любое «есть default».
    # dns4.2.65 R27-06 (аудит раунда 27, R26-06): сравнение ПОЛЯМИ, а не
    # подстроками: прежде «nwg10» проходил за «nwg1», а «10.0.0.10» —
    # за «10.0.0.1»; при пустом ожидаемом шлюзе строка с любым «via»
    # тоже проходила. Теперь устройство и шлюз обязаны совпадать
    # токен-в-токен, а отсутствие «via» требуется явно.
    if [ "$_kz_route_ok" -eq 1 ] \
            && ip -4 route show table "$vpn_table_id" 2>/dev/null \
                | awk -v _rt_dev="$vpn_dev" -v _rt_gw="${vpn_gw:-}" '
                    $1 == "default" {
                        _m_dev = ""; _m_via = ""
                        for (i = 2; i <= NF; i++) {
                            if ($i == "dev" && i < NF) _m_dev = $(i+1)
                            else if ($i == "via" && i < NF) _m_via = $(i+1)
                        }
                        if (_m_dev == _rt_dev \
                                && ((_rt_gw == "" && _m_via == "") \
                                    || (_rt_gw != "" && _m_via == _rt_gw))) {
                            found=1
                        }
                    }
                    END { exit !found }'; then
        # Осознанное подавление: массовое некритичное копирование
        # маршрутов из main; ошибка default-маршрута выше логируется
        # всегда.
        ip -4 route show table main | grep -Ev '^default' | while read -r ROUTE; do
            [ -n "$ROUTE" ] || continue
            ip -4 route replace table "$vpn_table_id" $ROUTE 2>/dev/null || true
        done
        # Вычищаем ВСЕ прежние экземпляры правила (защита от накопления
        # дублей), затем добавляем ровно одно.
        while ip -4 rule del fwmark "$get_fwmark_id" lookup "$vpn_table_id" \
                priority 1778 >/dev/null 2>&1; do :; done
        if ip -4 rule add fwmark "$get_fwmark_id" lookup "$vpn_table_id" \
                priority 1778 >/dev/null 2>&1; then
            _kz_policy_ok=1
        fi
    fi

    if [ "$_kz_policy_ok" -ne 1 ]; then
        logger -t "$TAG" "ERROR: VPN $vpn: политика не опубликована (default-маршрут не подтверждён); частичное состояние снято"
        # dns4.2.60 C-02 (аудит 2026-09-29): вычистка частичного состояния
        # выполняется ДО освобождения замка — в пределах той же
        # транзакции, что и попытка публикации.
        cleanup_client_vpn "$vpn"
        vpn_lock_release
        continue
    fi
    ip -4 route flush cache 2>/dev/null || true

    # dns4.2.19: критическая секция 2/2 — реестр исходящих туннелей для
    # исключения dev из LAN_IFACES в 100-redirect.sh (удалённая сторона
    # клиентского туннеля не должна получать DNS-перехват, редирект в
    # прокси и ACCEPT веб-порта). Запись "<dev> <rci-id>".
    # dns4.2.57: реестр записывается под тем же замком, что и политический
    # транзакт.
    _vcd_file="/opt/etc/unblock/.vpn_client_devs"
    [ -d /opt/etc/unblock ] || mkdir -p /opt/etc/unblock 2>/dev/null || true
    sed -i "/[[:space:]]${vpn}$/d" "$_vcd_file" 2>/dev/null || true
    printf '%s %s\n' "$vpn_dev" "$vpn" >> "$_vcd_file"
    vpn_lock_release

    [ -f "$vpn_list" ] || : > "$vpn_list"
    chmod 0644 "$vpn_list"

    ipset create "$unblockvpn" hash:net family inet hashsize 1024 maxelem 65536 -exist 2>/dev/null || true

    logger -t "$TAG" "VPN $vpn ON: $vpn_desc $vpn_ip via $vpn_dev"

    [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ] \
        && type=iptable table=nat /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1 \
        || true
done

# ═════════════════════════════════════════════════════════════════════════
# Восстановление после смены канала (актуально для LTE/USB-модема)
# ═════════════════════════════════════════════════════════════════════════
# Все сервисы проекта, кроме hysteria, при старте лишь открывают локальный
# сокет и идут наружу по первому запросу клиента — разрыв WAN они
# переживают сами. Hysteria (без lazy) устанавливает QUIC-сессию сразу и
# при обрыве может завершиться. Перезапускать её было некому: в этом хуке
# init-скрипты не вызывались, а 100-redirect.sh при мёртвом сервисе лишь
# снимает его правила. Итог — UDP из hysteria.txt шёл напрямую до ручного
# вмешательства.
#
# Поднимаются ТОЛЬКО мёртвые сервисы: безусловный перезапуск рвал бы
# рабочие соединения при каждом изменении состояния интерфейса.

# Событие приходит пачками: в журнале зафиксировано до 8 срабатываний за
# минуту на одно переподключение. Без защиты сервисы перезапускались бы
# каскадом. Каталог-замок атомарен в BusyBox ash (mkdir), stale-замок
# старше 5 минут снимается.
WD_LOCK="/tmp/unblock_ifup.lockdir"
# РАУД 43 (повторный аудит, R42-WD-HANDOFF): пока флаг 0, родитель ещё
# может разобрать созданный им лок; флаг гасится ДО запуска воркера —
# с этого момента разрушающая очистка в компетенции только воркера.
WD_HANDOFF=0
WD_STAMP="/tmp/unblock_ifup.stamp"
# Интервал больше, чем длится фоновая работа. Родитель завершается сразу
# (иначе прошивка убивает хук по таймауту) и снимает замок, поэтому от
# наложения двух фоновых веток защищает именно эта пауза: запуск пяти
# init-скриптов занимает до ~40 с (hysteria одна поднималась 17 с),
# плюс sleep 5 и переустановка правил.
# 300 с: роуминг пира серверного WireGuard (новый source-port -> handshake ->
# link pending/running) рождает события каждые 2-3 минуты, и каждый цикл
# стоил ~10 служебных DNS-опросов + dns-event. Плата за антидребезг: после
# реального падения/подъёма WAN сервисы могут стартовать с задержкой до ~5
# минут (DNS клиентов при этом продолжает работать через фасад).
WD_MIN_INTERVAL=300

if [ -d "$WD_LOCK" ]; then
    _wd_live=0
    _wd_pid="$(cat "$WD_LOCK/pid" 2>/dev/null || true)"
    _wd_start="$(cat "$WD_LOCK/start" 2>/dev/null || true)"
    case "$_wd_pid" in
        ''|*[!0-9]*) ;;
        *)
            if kill -0 "$_wd_pid" 2>/dev/null; then
                _wd_now_start="$(awk '{print $22}' "/proc/$_wd_pid/stat" 2>/dev/null || true)"
                [ -z "$_wd_start" ] || [ "$_wd_now_start" = "$_wd_start" ] && _wd_live=1
            fi
            ;;
    esac
    if [ "$_wd_live" -eq 0 ]; then
        # A metadata-less/fresh lock is preserved conservatively. It may be
        # between mkdir and metadata writes on a slow flash filesystem.
        _wd_t="$(cat "$WD_LOCK/ts" 2>/dev/null || echo 0)"
        _wd_now="$(date +%s 2>/dev/null || echo 0)"
        case "$_wd_t" in ''|*[!0-9]*) _wd_t=0 ;; esac
        if [ "$_wd_t" -gt 0 ] && [ $((_wd_now - _wd_t)) -gt 300 ]; then
            # РАУД 40 (повторный аудит, R39-LOCK-03): двойная сверка
            # маркера перед очисткой устаревшего лока.
            _wd_mk2="$(cat "$WD_LOCK/pid" 2>/dev/null || true);$(cat "$WD_LOCK/start" 2>/dev/null || true);$(cat "$WD_LOCK/ts" 2>/dev/null || true)"
            _wd_mk1="$_wd_pid;$_wd_start;$_wd_t"
            if [ "$_wd_mk1" = "$_wd_mk2" ]; then
                rm -rf "$WD_LOCK" 2>/dev/null || true
            fi
        else
            exit 0
        fi
    else
        exit 0
    fi
fi

# Антидребезг и проверка WAN выполняются до mkdir: после захвата lock
# здесь больше нет раннего exit, который мог бы оставить каталог навсегда.
_wd_now="$(date +%s 2>/dev/null || echo 0)"
if [ -f "$WD_STAMP" ]; then
    _wd_prev="$(cat "$WD_STAMP" 2>/dev/null || echo 0)"
    case "$_wd_prev" in ''|*[!0-9]*) _wd_prev=0 ;; esac
    if [ $((_wd_now - _wd_prev)) -lt "$WD_MIN_INTERVAL" ]; then
        exit 0
    fi
fi

# Есть ли вообще выход в интернет: без маршрута по умолчанию поднимать
# сервисы бессмысленно — событие «интерфейс погас» отсекается до захвата
# фонового lock.
if ! ip -4 route show default 2>/dev/null | grep -q .; then
    exit 0
fi

mkdir "$WD_LOCK" 2>/dev/null || exit 0
# РАУД 42 (повторный аудит, R41-WD-PRETRAP): родительский трэп с
# момента создания лока — отказ, сигнал или завершение до запуска
# воркера не оставляют лок до устаревания. Снятие только по
# родительскому токену; воркер после своего трэпа перезаписывает
# «owner» своим токеном, и этот обработчик перестаёт совпадать.
# РАУД 42 (R41-TOKEN-UNIQ): токен дополнен временем старта процесса.
WD_PARENT_TOKEN="$$-WDP-$(date +%s).$(awk '{print $22}' "/proc/$$/stat" 2>/dev/null)"
# shellcheck disable=SC2154 # _wdp_own присваивается строкой трэпа
trap '[ "${WD_HANDOFF:-0}" = "1" ] || { _wdp_own="$(cat "$WD_LOCK/owner" 2>/dev/null || true)"; case "$_wdp_own" in "$WD_PARENT_TOKEN") rm -rf "$WD_LOCK" 2>/dev/null || true ;; esac; }' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP
printf '%s\n' "$WD_PARENT_TOKEN" > "$WD_LOCK/owner" 2>/dev/null || true
date +%s > "$WD_LOCK/ts" 2>/dev/null || true
printf '%s' "$_wd_now" > "$WD_STAMP" 2>/dev/null || true

# Живость определяется так же, как в 100-redirect.sh: по argv[0] в /proc.
# Подстрочный поиск по всей командной строке принимал бы за живой сервис
# посторонний процесс (например "vi /opt/etc/hysteria/config.json").
wd_proc_alive() {
    _wd_p="$1"
    # dns4.2.40 N-10 (аудит-3): быстрый путь через pidof — как в
    # 100-redirect.sh после N-2. Обход /proc ниже даёт сотни форков
    # (cat+tr+head на каждый PID) за серию проверок при поднятии WAN;
    # pidof сравнивает имя процесса так же, как обход. Обход остаётся
    # резервом для сборок без pidof.
    if command -v pidof >/dev/null 2>&1; then
        pidof "$_wd_p" >/dev/null 2>&1
        return $?
    fi
    for _wd_d in /proc/[0-9]*; do
        # Читаем через cat: процесс может исчезнуть между раскрытием
        # маски и открытием файла, а сообщение оболочки о неудачном
        # перенаправлении "< файл" не подавляется через 2>/dev/null
        # у команды — оно попадало в журнал роутера как ошибка скрипта.
        _wd_a0="$(cat "$_wd_d/cmdline" 2>/dev/null | tr '\0' '\n' | head -1)"
        [ -n "$_wd_a0" ] || continue
        [ "${_wd_a0##*/}" = "$_wd_p" ] && return 0
    done
    return 1
}

# Отключённый в панели сервис (ENABLED=no) поднимать нельзя: это штатный
# признак того, что пользователь выключил протокол.
wd_revive() {
    _wd_init="/opt/etc/init.d/$1"
    _wd_procs="$2"

    [ -x "$_wd_init" ] || return 0
    grep -qE '^[[:space:]]*ENABLED[[:space:]]*=[[:space:]]*no' \
        "$_wd_init" 2>/dev/null && return 0

    # Do not even call init for a template/empty config. The init scripts
    # repeat this guard for reboot/start races, but keeping it here prevents
    # noisy WAN-hook "revive" messages and needless process attempts.
    case "$_wd_procs" in
        xray) _wd_cfg=/opt/etc/xray/config.json ;;
        trojan) _wd_cfg=/opt/etc/trojan/config.json ;;
        hysteria) _wd_cfg=/opt/etc/hysteria/config.json ;;
        ss-redir) _wd_cfg=/opt/etc/shadowsocks.json ;;
        *) _wd_cfg="" ;;
    esac
    if [ -n "$_wd_cfg" ]; then
        [ -s "$_wd_cfg" ] || return 0
        grep -q '{{' "$_wd_cfg" 2>/dev/null && return 0
        grep -qE '"(address|server|remote_addr|password|auth|id|publicKey)"[[:space:]]*:[[:space:]]*(""|\[[[:space:]]*""|\[\])' \
            "$_wd_cfg" 2>/dev/null && return 0
    fi
    wd_proc_alive "$_wd_procs" && return 0

    "$_wd_init" start >/dev/null 2>&1 || true
    WD_REVIVED=1
    logger -t "$TAG" "WAN up: перезапущен $1"
}

# A WAN recovery must select one tunnel in the configured order. A live
# process is not enough: require its configured local listener as well, so a
# stale PID cannot block the next fallback or make the netfilter path point at
# a dead port.
wd_tunnel_port() {
    case "$1" in
        xray) sed -n \
            -e "s/^[[:space:]]*localportvless[[:space:]]*=[[:space:]]*'\([0-9][0-9]*\)'.*$/\1/p" \
            -e 's/^[[:space:]]*localportvless[[:space:]]*=[[:space:]]*"\([0-9][0-9]*\)".*$/\1/p' \
            "$BOT_CONFIG" 2>/dev/null | head -n1 || true ;;
        trojan) sed -n \
            -e "s/^[[:space:]]*localporttrojan[[:space:]]*=[[:space:]]*'\([0-9][0-9]*\)'.*$/\1/p" \
            -e 's/^[[:space:]]*localporttrojan[[:space:]]*=[[:space:]]*"\([0-9][0-9]*\)".*$/\1/p' \
            "$BOT_CONFIG" 2>/dev/null | head -n1 || true ;;
        hysteria) sed -n \
            -e "s/^[[:space:]]*localporthysteria[[:space:]]*=[[:space:]]*'\([0-9][0-9]*\)'.*$/\1/p" \
            -e 's/^[[:space:]]*localporthysteria[[:space:]]*=[[:space:]]*"\([0-9][0-9]*\)".*$/\1/p' \
            "$BOT_CONFIG" 2>/dev/null | head -n1 || true ;;
        *) return 1 ;;
    esac
}

wd_tunnel_listener_ready() {
    _wd_proto="$1"
    _wd_port="$(wd_tunnel_port "$_wd_proto")"
    case "$_wd_port" in ''|*[!0-9]*)
        case "$_wd_proto" in xray) _wd_port=10810 ;; trojan) _wd_port=10829 ;; hysteria) _wd_port=10830 ;; esac
        ;;
    esac
    # dns4.2.59 Х-09 (аудит 2026-09-29, H-09): готовность подтверждается
    # владением слушателя процессом проекта, а не независимой парой
    # «процесс жив + порт кем-то слушается». Для hysteria и xray
    # обязательно ОБА транспорта (у обоих есть и TCP-вход, и
    # UDP-TPROXY на одном порту, dns4.2.36 KZ-02).
    case "$_wd_proto" in
        xray)     _wd_lp="xray";     _wd_lh="/opt/etc/xray" ;;
        trojan)   _wd_lp="trojan";   _wd_lh="/opt/etc/trojan/config.json" ;;
        hysteria) _wd_lp="hysteria"; _wd_lh="/opt/etc/hysteria/config.json" ;;
        *) return 1 ;;
    esac
    owned_listener_ready "$_wd_lp" "$_wd_port" tcp "$_wd_lh" || return 1
    case "$_wd_proto" in
        hysteria|xray)
            owned_listener_ready "$_wd_lp" "$_wd_port" udp "$_wd_lh" || return 1
            ;;
    esac
    return 0
}

# dns4.2.59 Х-09 (аудит 2026-09-29, H-09): готовность = процесс проекта
# ВЛАДЕЕТ слушателем порта (сопоставление inode сокетов из
# /proc/<pid>/fd с записями /proc/net/{tcp,udp}). Чужой слушатель на
# порту больше не считается готовностью. Аргументы:
#   $1 имя процесса (по argv[0]), $2 порт, $3 транспорт (tcp|udp),
#   $4 необязательная подстрока командной строки (путь конфига).
owned_listener_ready() {
    _olr_proc="$1"; _olr_port="$2"; _olr_proto="$3"; _olr_hint="${4:-}"
    case "$_olr_port" in ''|*[!0-9]*) return 1 ;; esac
    [ "$_olr_port" -ge 1 ] && [ "$_olr_port" -le 65535 ] || return 1
    # РАУД 37 (итоговый аудит, P2-03): проект IPv4-only.
    case "$_olr_proto" in
        tcp) _olr_files="/proc/net/tcp"; _olr_state="0A" ;;
        udp) _olr_files="/proc/net/udp"; _olr_state="" ;;
        *) return 1 ;;
    esac
    _olr_hex="$(printf '%04X' "$_olr_port")"
    # РАУД 38 (повторный аудит, R37-03): на минимальных сборках
    # BusyBox может не быть «pidof» — фолбэк обходом /proc со
    # сравнением basename argv[0] (зеркало svc_enabled_probe).
    if command -v pidof >/dev/null 2>&1; then
        _olr_pids="$(pidof "$_olr_proc" 2>/dev/null || true)"
    else
        _olr_pids=""
        for _olr_d in /proc/[0-9]*; do
            _olr_argv0="$(cat "$_olr_d/cmdline" 2>/dev/null \
                | tr '\0' '\n' | head -1)"
            [ -n "$_olr_argv0" ] || continue
            [ "${_olr_argv0##*/}" = "$_olr_proc" ] || continue
            _olr_pids="$_olr_pids ${_olr_d#/proc/}"
        done
    fi
    _olr_inodes=" "
    for _olr_pid in $_olr_pids; do
        # РАУД 38 (повторный аудит, R37-04): хинт — ОТДЕЛЬНЫЙ
        # argv-токен, а не подстрока командной строки: «/opt/etc/
        # xray» не должен совпадать с «/opt/etc/xray-backup/…».
        if [ -n "$_olr_hint" ]; then
            _olr_match=0
            while IFS= read -r _olr_arg; do
                [ "$_olr_arg" = "$_olr_hint" ] && { _olr_match=1; break; }
            done <<EOF
$(tr '\0' '\n' < "/proc/$_olr_pid/cmdline" 2>/dev/null)
EOF
            [ "$_olr_match" = 1 ] || continue
        fi
        # dns4.2.60 К-3 (аудит 2026-09-29, C-01): sed печатает по одному
        # inode в строке; без перевода строк в пробелы список содержал
        # \n, и awk-поиск " inode " у процесса с двумя и более
        # сокетами не совпадал никогда (все реальные демоны проекта —
        # TCP+UDP). Формат списка: пробел-разделитель с обеих сторон.
        _olr_s="$(ls -l "/proc/$_olr_pid/fd" 2>/dev/null \
            | sed -n 's/^.*socket:\[\([0-9][0-9]*\)\].*$/\1/p' \
            | tr '\n' ' ')"
        [ -n "$_olr_s" ] && _olr_inodes="$_olr_inodes$_olr_s"
    done
    [ "$_olr_inodes" != " " ] || return 1
    for _olr_f in $_olr_files; do
        [ -r "$_olr_f" ] || continue
        awk -v p=":$_olr_hex" -v il="$_olr_inodes" -v st="$_olr_state" '
            NR > 1 {
                n = split($2, _la, ":")
                if (_la[n] != substr(p, 2)) next
                if (st != "" && $4 != st) next
                if (index(il, " " $10 " ") > 0) { ok = 1; exit }
            }
            END { exit ok ? 0 : 1 }' "$_olr_f" 2>/dev/null && return 0
    done
    return 1
}

wd_tunnel_ready() {
    wd_proc_alive "$1" && wd_tunnel_listener_ready "$1"
}

# Start at most one fallback tunnel for this WAN event. If the selected
# process/listener is already usable, lower-priority protocols are not
# started. If it fails to become ready, advance to the next protocol.
wd_revive_tunnel_fallback() {
    for _wd_proto in $(config_words tunnel_protocol_priority 'hysteria xray trojan'); do
        wd_tunnel_ready "$_wd_proto" && {
            logger -t "$TAG" "WAN up: tunnel selected=$_wd_proto (process+listener ready)"
            return 0
        }

        case "$_wd_proto" in
            xray) _wd_init=S24xray; _wd_proc=xray ;;
            trojan) _wd_init=S22trojan; _wd_proc=trojan ;;
            hysteria) _wd_init=S57hysteria; _wd_proc=hysteria ;;
        esac
        wd_revive "$_wd_init" "$_wd_proc"
        _wd_wait=0
        while [ "$_wd_wait" -lt 15 ]; do
            wd_tunnel_ready "$_wd_proto" && {
                logger -t "$TAG" "WAN up: tunnel selected=$_wd_proto after revive"
                return 0
            }
            sleep 1
            _wd_wait=$((_wd_wait + 1))
        done
        logger -t "$TAG" "WAN up: tunnel fallback unavailable=$_wd_proto; trying next"
    done
    return 1
}

# Apply one table synchronously, retrying a transient shared-lock result.
# 100-redirect.sh also queues a one-shot retry for NDM-originated calls; this
# loop makes the WAN recovery path report success as soon as the same
# transaction can be applied.
wd_netfilter_retry() {
    _wnr_table="$1"
    _wnr_try=0
    while [ "$_wnr_try" -lt 4 ]; do
        if type=iptable table="$_wnr_table" \
            /opt/etc/ndm/netfilter.d/100-redirect.sh >/dev/null 2>&1; then
            _wnr_rc=0
        else
            _wnr_rc=$?
        fi
        [ "$_wnr_rc" -ne 75 ] && return "$_wnr_rc"
        sleep 2
        _wnr_try=$((_wnr_try + 1))
    done
    return 75
}

# One background worker owns the lock for the complete recovery sequence.
# The hook itself returns immediately, while a second WAN event cannot start a
# concurrent service/netfilter/DNS refresh worker.
# РАУД 41 (повторный аудит, R40-WD-01): токен владельца задаётся ДО
# запуска воркера и наследуется им. В сабшелле «$$» — это пид РОДИТЕЛЯ,
# поэтому прежняя сверка с «$$» не снимала лок при нормальном выходе;
# снятие сверяет «owner»-файл с токеном, пустой файл — частичная
# инициализация своего лока.
WD_TOKEN="$$-WD-$(date +%s).$(awk '{print $22}' "/proc/$$/stat" 2>/dev/null)"
# РАУД 43 (повторный аудит, R42-WD-HANDOFF): родитель отказывается от
# разрушающей очистки ДО запуска воркера. Если воркер погибнет до
# записи владельца, лок разберёт существующий разбор устаревших
# (мёртвый «pid»); двойного запуска второй хук не допустит, пока лок
# на месте.
WD_HANDOFF=1
(
    # shellcheck disable=SC2154 # _wd_rl_own присваивается строкой трэпа
    trap '_wd_rl_own="$(cat "$WD_LOCK/owner" 2>/dev/null || true)"; case "$_wd_rl_own" in "$WD_TOKEN"|"") rm -rf "$WD_LOCK" 2>/dev/null || true ;; esac' EXIT
    trap 'exit 130' INT
    trap 'exit 143' TERM
    trap 'exit 129' HUP
    printf '%s\n' "$WD_TOKEN" > "$WD_LOCK/owner" 2>/dev/null || true

    WD_REVIVED=0
    # Strict fallback order: Hysteria -> Xray/VLESS -> Trojan. Do not
    # independently revive all three on the same WAN event.
    wd_revive_tunnel_fallback || true
    wd_revive S65shadowsocks ss-redir
    wd_revive S35tor tor

    if [ "$WD_REVIVED" = "1" ]; then
        sleep 5
        _wd_rules_ok=1
        if [ -x /opt/etc/ndm/netfilter.d/100-redirect.sh ]; then
            for _wd_table in nat filter; do
                if ! wd_netfilter_retry "$_wd_table"; then
                    _wd_rules_ok=0
                    logger -t "$TAG" "WAN up: netfilter table=$_wd_table failed"
                fi
            done
            # A failed table can have been deferred while another table
            # released the lock. Re-run the complete set once before declaring
            # a partial rollback.
            if [ "$_wd_rules_ok" = "0" ]; then
                _wd_rules_ok=1
                for _wd_table in nat filter; do
                    wd_netfilter_retry "$_wd_table" || _wd_rules_ok=0
                done
            fi
            if [ "$_wd_rules_ok" = "1" ]; then
                logger -t "$TAG" "WAN up: правила перехвата переустановлены"
            else
                logger -t "$TAG" "WAN up: правила перехвата применены частично; rollback/defer"
            fi
        fi
    fi

    # One coalesced DNS event after WAN/route recovery; no minute cron.
    if [ -x /opt/etc/init.d/S99unblock ]; then
        /opt/etc/init.d/S99unblock dns-event >/dev/null 2>&1 || true
    fi

    # Give the channel and revived services time to settle before refreshing
    # pins and the dnsmasq interface/listen-address managed blocks.
    sleep 10

    # dns4.2.37 H-2 / dns4.2.38 N-6: статус читается ДО выбора ветки.
    # При отложенной транзакции (статус «defer») или пустом статусе
    # (свежая загрузка, /tmp очищен) выполняется только
    # unblock_update.sh: он САМ вызывает unblock_dnsmasq.sh (стадия
    # кандидата и финальная публикация), поэтому прежний прямой вызов
    # перед ним давал двойной полный прогон на каждое поднятие WAN —
    # двойная работа и лишний рестарт dnsmasq в самый чувствительный
    # момент. Параллельный запуск невозможен: у скрипта обновления
    # собственный каталог-лок. В остальных состояниях — только прямой
    # вызов обновления пинов/интерфейсов, как прежде.
    _wd_defer_st="$(grep -o '"status"[[:space:]]*:[[:space:]]*"[^"]*"' \
        /tmp/unblock_update_status.json 2>/dev/null | head -1)"
    _wd_run_update=0
    case "$_wd_defer_st" in
        *defer* | '') [ -x /opt/bin/unblock_update.sh ] && _wd_run_update=1 ;;
    esac
    if [ "$_wd_run_update" = 1 ]; then
        logger -t "$TAG" "WAN up: повтор отложенного/первичного обновления списков"
        if /opt/bin/unblock_update.sh >/dev/null 2>&1; then
            logger -t "$TAG" "WAN up: списки, пины и интерфейсы dnsmasq обновлены"
        else
            _wd_dns_rc=$?
            logger -t "$TAG" "WAN up: обновление списков отложено/не удалось rc=$_wd_dns_rc"
        fi
    elif [ -x /opt/bin/unblock_dnsmasq.sh ]; then
        if /opt/bin/unblock_dnsmasq.sh >/dev/null 2>&1; then
            logger -t "$TAG" "WAN up: endpoint pin and dnsmasq interfaces refreshed"
        else
            _wd_dns_rc=$?
            logger -t "$TAG" "WAN up: DNS refresh deferred/failed rc=$_wd_dns_rc"
        fi
    fi
) >/dev/null 2>&1 </dev/null &
WD_WORKER_PID=$!
if [ -z "$WD_WORKER_PID" ]; then
    # РАУД 43 (повторный аудит, R42-WD-HANDOFF): запуск воркера не
    # состоялся — возвращаем право очистки и разбираем лок сами.
    WD_HANDOFF=0
    rm -rf "$WD_LOCK" 2>/dev/null || true
    exit 1
fi
# In BusyBox ash $$ is inherited by a subshell. Record $! from the parent,
# otherwise a finished hook can look like a stale/dead owner while the worker
# is still running.
printf '%s\n' "$WD_WORKER_PID" > "$WD_LOCK/pid" 2>/dev/null || true
awk '{print $22}' "/proc/$WD_WORKER_PID/stat" 2>/dev/null > "$WD_LOCK/start" || true

# The single worker above also refreshes pins and dnsmasq after the WAN
# channel settles. No second background branch is created: its previous
# independent lock ownership allowed DNS and service recovery to overlap.

exit 0
