#!/bin/sh
# /opt/etc/ndm/netfilter.d/100-redirect.sh
# Перехват трафика для списков обхода.
#   TCP  -> nat/REDIRECT на локальные порты прокси.
#   UDP  -> mangle/TPROXY (vless, hysteria) либо nat/REDIRECT (shadowsocks).
# Оболочка: BusyBox ash (#!/bin/sh), без bash-измов.

# Этот hook обязан попытаться применить все независимые секции даже при
# отказе одного необязательного netfilter-модуля. `set -e` здесь опасен:
# ненулевой rc одного `iptables -I` обрывал выполнение до TCP/TPROXY/VPN и
# создавал fail-open. Ошибки критических операций накапливаются в HOOK_RC.
set -u

PATH="/opt/sbin:/opt/bin:/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

# ─────────────────────────────────────────────────────────────────────
# IPv6: закрыть прокси-порты от внешней сети.
# ─────────────────────────────────────────────────────────────────────
# Перехват трафика (REDIRECT/TPROXY) реализован только для IPv4, но
# xray (Go) на "listen": "0.0.0.0" может создать dual-stack сокет. Если
# IPv6 случайно включили, прокси-порты не должны становиться доступными из
# LAN/WAN IPv6: эти правила закрывают их полностью, кроме loopback.
# Это только защита локальных портов; полноценный IPv4-only режим обязан
# дополнительно отключать IPv6 в KeeneticOS, а deploy проверяет это заранее.
if [ "${type:-}" = "ip6tables" ]; then
    [ "${table:-}" = "filter" ] || exit 0

    IPT6="$(command -v ip6tables 2>/dev/null || true)"
    [ -n "$IPT6" ] || exit 0
    IPT6="$IPT6 -w"

    for p6 in 1082 9141 10810 10829 10830 8080; do
        for pr6 in tcp udp; do
            # Удаляем старые варианты, включая прежние разрешения ULA/
            # link-local, иначе они опередят новое fail-closed правило.
            while $IPT6 -D INPUT -p "$pr6" --dport "$p6" \
                -j DROP >/dev/null 2>&1; do :; done
            while $IPT6 -D INPUT -i lo -p "$pr6" \
                --dport "$p6" -j ACCEPT >/dev/null 2>&1; do :; done
            for n6 in fc00::/7 fe80::/10 ::1/128; do
                while $IPT6 -D INPUT -p "$pr6" --dport "$p6" \
                    -s "$n6" -j ACCEPT >/dev/null 2>&1; do :; done
            done

            # Сначала loopback, затем DROP для любого прочего IPv6.
            $IPT6 -I INPUT 1 -p "$pr6" --dport "$p6" \
                -j DROP >/dev/null 2>&1 || true
            $IPT6 -I INPUT 1 -i lo -p "$pr6" --dport "$p6" \
                -j ACCEPT >/dev/null 2>&1 || true
        done
    done
    exit 0
fi

# filter тоже обрабатывается: в нём живут правила доступа к веб-панели.
case "${table:-}" in
    mangle|nat|filter) ;;
    *) exit 0 ;;
esac

TAG="100-redirect.sh"

# На Keenetic нет logread, а вывод logger в syslog прошивки недоступен
# обычными средствами. Поэтому диагностика дублируется в файл.
REDIRECT_LOG="/opt/var/log/100-redirect.log"
mkdir -p /opt/var/log 2>/dev/null || true

# Хук вызывается при каждом изменении состояния интерфейсов, поэтому лог
# обязан быть самоограниченным: пишем ТОЛЬКО ошибки и держим файл в
# пределах 64 КБ, оставляя последние 100 строк. Иначе накопитель с
# Entware со временем переполнится.
REDIRECT_LOG_MAX=65536
REDIRECT_LOG_KEEP=100

log_msg() {
    logger -t "$TAG" "$*" 2>/dev/null || true

    if [ -f "$REDIRECT_LOG" ]; then
        _lsz="$(wc -c < "$REDIRECT_LOG" 2>/dev/null || echo 0)"
    else
        _lsz=0
    fi
    case "$_lsz" in
        ''|*[!0-9]*) _lsz=0 ;;
    esac
    if [ "$_lsz" -gt "$REDIRECT_LOG_MAX" ]; then
        _ltmp="${REDIRECT_LOG}.tmp.$$"
        if tail -n "$REDIRECT_LOG_KEEP" "$REDIRECT_LOG" \
            > "$_ltmp" 2>/dev/null; then
            mv -f "$_ltmp" "$REDIRECT_LOG" 2>/dev/null || rm -f "$_ltmp"
        else
            rm -f "$_ltmp"
        fi
    fi

    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$*" \
        >> "$REDIRECT_LOG" 2>/dev/null || true
}

# Ошибка одного правила не должна пропускать последующие независимые
# секции. Различаем три исхода:
#   warning       — потеря необязательной оптимизации;
#   degraded-safe — штатный dataplane недоступен, но DROP не даёт утечки;
#   error         — обязательное правило и безопасный fallback не созданы.
# Только последний исход возвращает ndm ненулевой код. Повтор одинакового
# состояния не раздувает журнал: runtime-файл используется лишь для
# диагностики и НИКОГДА не участвует в решении, какие правила ставить.
HOOK_RC=0
HOOK_LEVEL=ok
HOOK_MESSAGES=""

hook_record() {
    _hr_level="$1"
    shift
    _hr_msg="$(printf '%s' "$*" | tr '\r\n' '  ' | cut -c1-512)"
    case "$_hr_level" in
        error) HOOK_LEVEL=error; HOOK_RC=1 ;;
        degraded)
            [ "$HOOK_LEVEL" = error ] || HOOK_LEVEL=degraded
            ;;
        warning)
            [ "$HOOK_LEVEL" = ok ] && HOOK_LEVEL=warning
            ;;
    esac
    if [ -n "$HOOK_MESSAGES" ]; then
        HOOK_MESSAGES="$HOOK_MESSAGES; $_hr_msg"
    else
        HOOK_MESSAGES="$_hr_msg"
    fi
    return 0
}

hook_warn() {
    hook_record warning "$*"
}

hook_degraded() {
    hook_record degraded "$*"
}

hook_error() {
    hook_record error "$*"
}

hook_finish() {
    _hf_table="${table:-unknown}"
    case "$_hf_table" in
        nat|mangle|filter) ;;
        *) _hf_table=unknown ;;
    esac
    _hf_file="/tmp/keenzoo_hook_state_${_hf_table}"
    _hf_summary="$HOOK_LEVEL"
    [ -n "$HOOK_MESSAGES" ] \
        && _hf_summary="${_hf_summary}: ${HOOK_MESSAGES}"
    _hf_old=""
    if [ -r "$_hf_file" ]; then
        IFS= read -r _hf_old < "$_hf_file" 2>/dev/null || _hf_old=""
    fi
    if [ "$_hf_summary" != "$_hf_old" ]; then
        if [ "$HOOK_LEVEL" = ok ] && [ -n "$_hf_old" ] \
            && [ "${_hf_old%%:*}" != ok ]; then
            log_msg "$_hf_table: восстановлено штатное состояние"
        elif [ "$HOOK_LEVEL" != ok ]; then
            log_msg "$_hf_table: $_hf_summary"
        fi
        _hf_tmp="${_hf_file}.tmp.$$"
        (umask 077 && printf '%s\n' "$_hf_summary" > "$_hf_tmp") \
            2>/dev/null \
            && mv -f "$_hf_tmp" "$_hf_file" 2>/dev/null \
            || rm -f "$_hf_tmp"
    fi
    return "$HOOK_RC"
}

# Пакет Entware "iptables" ставит /opt/sbin/iptables, где есть только
# libxt_CT/libxt_conntrack — расширений TPROXY, socket и set в нём НЕТ.
# Так как /opt/sbin в PATH первым, правила молча не создавались
# ("Couldn't load target `TPROXY'"). Прошивочный iptables Keenetic их умеет.
# Проверка расширения по ВЫВОДУ, а не по коду возврата: iptables на
# неизвестную цель печатает общую справку и выходит с 0, поэтому
# "iptables -j TPROXY --help >/dev/null; echo $?" даёт 0 даже там, где
# TPROXY нет. Из-за этого выбирался ущербный /opt/sbin/iptables.
# Определение возможностей iptables.
#
# Заголовок справки — основной признак, но полагаться ТОЛЬКО на него нельзя:
# формат отличается между сборками (двоеточие, регистр, отступ), а часть
# расширений вкомпилирована в libiptext.so и печатает заголовок иначе.
# Проверено на KN-2311: libiptext.so содержит и "TPROXY target options:",
# и "set match options:", то есть пакет Entware способен на TPROXY и
# --match-set, хотя отдельных libxt_set.so/libxt_TPROXY.so в нём нет.
# Прежний детектор с жёстким "^" давал ложный отрицательный вердикт, и
# проект без нужды уходил в деградированный режим.
#
# Поэтому проверка двухуровневая: текст справки, а при неудаче — наличие
# характерных опций расширения в том же выводе.
ipt_has_target() {
    _iht_out="$(LC_ALL=C "$1" -j "$2" --help 2>&1 || true)"
    printf '%s' "$_iht_out" | grep -qi "$2 target options" && return 0
    case "$2" in
        TPROXY)
            printf '%s' "$_iht_out" | grep -q -- '--on-port' && return 0
            ;;
    esac
    return 1
}

ipt_has_match() {
    _ihm_out="$(LC_ALL=C "$1" -m "$2" --help 2>&1 || true)"
    printf '%s' "$_ihm_out" | grep -qi "$2 match options" && return 0
    case "$2" in
        set)
            printf '%s' "$_ihm_out" | grep -q -- '--match-set' && return 0
            ;;
    esac
    return 1
}

ipt_is_capable() {
    ipt_has_target "$1" TPROXY && ipt_has_match "$1" set
}

pick_iptables() {
    # Прошивочный iptables Keenetic содержит libxt_TPROXY/socket/set.
    # Пакет Entware iptables (1.4.21) несёт только CT/conntrack — он не
    # должен победить только потому, что /opt/sbin стоит первым в PATH.
    # Runtime-кэш используется лишь как первый КАНДИДАТ: путь ограничен
    # известными каталогами, executable и capability проверяются заново.
    _pi_cache="/tmp/keenzoo_iptables_bin"
    _c=""
    if [ -r "$_pi_cache" ]; then
        IFS= read -r _c < "$_pi_cache" 2>/dev/null || _c=""
        case "$_c" in
            /usr/sbin/iptables|/sbin/iptables|/bin/iptables|\
            /usr/bin/iptables|/usr/local/sbin/iptables|\
            /tmp/sbin/iptables|/tmp/usr/sbin/iptables|\
            /opt/sbin/iptables|/opt/bin/iptables) ;;
            *) _c="" ;;
        esac
        if [ -n "$_c" ] && [ -x "$_c" ] && ipt_is_capable "$_c"; then
            printf '%s|1' "$_c"
            return 0
        fi
    fi

    # Прошивочный бинарник на разных моделях лежит по-разному. Сначала
    # проверяются абсолютные пути, затем допустимые glob-кандидаты.
    for _c in /usr/sbin/iptables /sbin/iptables /bin/iptables \
        /usr/bin/iptables /usr/local/sbin/iptables \
        /tmp/sbin/iptables /tmp/usr/sbin/iptables \
        /opt/sbin/iptables /opt/bin/iptables; do
        [ -x "$_c" ] || continue
        if ipt_is_capable "$_c"; then
            printf '%s|1' "$_c"
            return 0
        fi
    done

    # Глоб без ls -d: ls в BusyBox молча выдаёт код 0 и для пустого
    # списка, а разбор его вывода хрупок (имена с пробелами).
    for _c in /usr/sbin/iptables* /sbin/iptables* /bin/iptables* \
        /tmp/sbin/iptables*; do
        [ -e "$_c" ] || continue
        case "$_c" in *-save|*-restore|*multi*) continue ;; esac
        [ -x "$_c" ] || continue
        if ipt_is_capable "$_c"; then
            printf '%s|1' "$_c"
            return 0
        fi
    done

    # По абсолютным путям не нашли — пробуем то, что даёт PATH.
    _c="$(command -v iptables 2>/dev/null || true)"
    if [ -n "$_c" ] && ipt_is_capable "$_c"; then
        printf '%s|1' "$_c"
        return 0
    fi

    # Ни один не подтвердил обе обязательные возможности. Берём первый
    # существующий и отдельно определяем set/TPROXY ниже: это позволяет
    # построить диагностируемый fail-closed fallback.
    for _c in /usr/sbin/iptables /sbin/iptables /bin/iptables \
        /usr/bin/iptables /opt/sbin/iptables; do
        [ -x "$_c" ] && { printf '%s|0' "$_c"; return 0; }
    done
    printf 'iptables|0'
}

_IPT_PICK="$(pick_iptables)"
IPT_BIN="${_IPT_PICK%%|*}"
_IPT_CAPABLE="${_IPT_PICK#*|}"
# Возможности учитываются независимо: xt_socket — оптимизация established
# TPROXY-сессий, а set+TPROXY — обязательный dataplane. Если pick уже
# доказал set+TPROXY, не запускаем те же четыре help/grep повторно.
IPT_HAS_SET=0
IPT_HAS_TPROXY=0
IPT_HAS_SOCKET=0
if [ "$_IPT_CAPABLE" = 1 ]; then
    IPT_HAS_SET=1
    IPT_HAS_TPROXY=1
else
    ipt_has_match "$IPT_BIN" set && IPT_HAS_SET=1
    ipt_has_target "$IPT_BIN" TPROXY && IPT_HAS_TPROXY=1
fi
ipt_has_match "$IPT_BIN" socket && IPT_HAS_SOCKET=1
# Единый источник выбора для панели (M6): generator.py сначала читает
# этот кэш и лишь затем перебирает свой список путей.
printf '%s' "$IPT_BIN" > /tmp/keenzoo_iptables_bin 2>/dev/null || true
IPT="$IPT_BIN -w"
if [ "$IPT_HAS_SET" != 1 ]; then
    hook_error "iptables $IPT_BIN: расширение -m set недоступно — правила списков не гарантированы"
fi
# Отсутствие TPROXY само по себе ещё не hard error: mangle_add_tproxy()
# обязана заменить каждое такое правило на проверенный DROP. Состояние
# станет degraded-safe только после успешной установки fallback; если и
# DROP не создался, функция повысит итог до error/rc=1.

# Одноразовая очистка старого policy-VPN выполняется до обычной генерации
# правил. Это нужно, чтобы сначала снять references на ipset, а затем
# безопасно уничтожить ошибочный набор WAN/Bridge.
purge_vpn_state() {
    _pvs_set="${PURGE_VPN_SET:-}"
    _pvs_mark="${PURGE_VPN_MARK:-}"
    [ -n "$_pvs_set" ] || return 0

    for _pvs_proto in tcp udp; do
        while $IPT -t mangle -D PREROUTING -p "$_pvs_proto" \
            -m set --match-set "$_pvs_set" dst \
            -j MARK --set-mark "$_pvs_mark" >/dev/null 2>&1; do :; done
    done
    while $IPT -t mangle -D PREROUTING \
        -m conntrack --ctstate NEW \
        -m set --match-set "$_pvs_set" dst \
        -j CONNMARK --set-mark "$_pvs_mark" >/dev/null 2>&1; do :; done
    return 0
}

if [ -n "${PURGE_VPN_SET:-}" ]; then
    purge_vpn_state
    exit 0
fi

# ── Порты локальных прокси ───────────────────────────────────────────────
PORT_SS=1082
PORT_TOR=9141
PORT_VLESS=10810
PORT_TROJAN=10829
PORT_HYSTERIA=10830
# Порт веб-панели (generator.py). Держится здесь, чтобы
# правила доступа переустанавливались вместе с остальными.
PORT_WEB=8080

# ── TPROXY: отдельная метка и таблица маршрутизации ──────────────────────
# Маска гарантирует отсутствие пересечения с VPN-метками вида 0xd1001.
# Метка вынесена в старший бит (0x1000000). VPN-марки формируются как
# 0xd<table_id>, где table_id растёт от 1001; начиная с table_id=1100
# значение 0xd1100 задевало бы бит 0x100 и трафик VPN ошибочно уходил
# бы в TPROXY-таблицу. Бит 24 в марки вида 0xdXXXX не попадает никогда.
TPROXY_MARK="0x1000000"
TPROXY_MASK="0x1000000"

# Метка исходящих пакетов самого xray (sockopt.mark в outbound). Служит
# только для RETURN в OUTPUT, чтобы трафик прокси не заворачивался в него
# же. Значение не пересекается ни с TPROXY_MARK, ни с VPN-марками 0xdXXXX.
XRAY_MARK="0x2000000"
TPROXY_TABLE=100
TPROXY_RULE_PRIO=1770

# ── Внутренние (клиентские) интерфейсы ───────────────────────────────────
# Правила обхода обязаны действовать одинаково для LAN, Wi-Fi, гостевой
# сети и для клиентов, подключённых к роутеру по VPN (в т.ч. WireGuard
# сервер прошивки: nwg*, wg*). Список фильтруется по факту существования
# интерфейса, чтобы не плодить мёртвые правила.
LAN_IFACE_PATTERNS="br0 br1 br2 wlan0 wlan1 wlan2 wlan3 nwg0 nwg1 nwg2 wg0 wg1 tun0 tap0 ppp-l2tp0 sstp0"

lan_ifaces() {
    _li_out=""
    # Один снимок вместо отдельного `ip link show` для каждого из 16
    # шаблонов. Файлового TTL-кэша намеренно нет: hook обязан увидеть
    # добавление/удаление интерфейса уже при следующем событии NDM.
    _li_all="$(ip -o link show 2>/dev/null | awk -F': ' '
        NF >= 2 {
            n=$2; sub(/@.*/, "", n); printf "%s ", n
        }')"

    for _li_if in $LAN_IFACE_PATTERNS; do
        case " $_li_all " in
            *" $_li_if "*)
                _li_out="${_li_out}${_li_out:+ }${_li_if}"
                ;;
        esac
    done

    # Keenetic NDM names its WireGuard interface Wireguard0, while the
    # kernel exposes nwg0. Подхватываем и nwg3+/wg2+, не полагаясь на
    # ограниченный статический список, но принимаем только numeric suffix.
    for _li_if in $_li_all; do
        case "$_li_if" in
            nwg*) _li_num="${_li_if#nwg}" ;;
            wg*)  _li_num="${_li_if#wg}" ;;
            *) continue ;;
        esac
        case "$_li_num" in ''|*[!0-9]*) continue ;; esac
        case " $_li_out " in
            *" $_li_if "*) ;;
            *) _li_out="${_li_out}${_li_out:+ }${_li_if}" ;;
        esac
    done

    [ -n "$_li_out" ] || _li_out="br0"
    printf '%s\n' "$_li_out"
}

LAN_IFACES="$(lan_ifaces)"

# P6 (ревью 2026-10-05): раньше адрес искался только на br0 — на
# конфигурациях без моста правила доступа к панели не создавались.
# br0 идёт первым в LAN_IFACE_PATTERNS, поэтому штатные установки
# получают тот же адрес, что и раньше.
local_ip=""
# Сначала предпочтителен RFC1918 LAN. На нестандартной адресации берём
# первый обычный IPv4 unicast; адрес нужен только для DNS-DNAT, остальные
# секции hook от него не зависят.
for _li in $LAN_IFACES; do
    _li_cand=$(
        ip -4 addr show "$_li" 2>/dev/null \
            | awk '/inet /{print $2}' \
            | cut -d/ -f1 \
            | grep -E '^(192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)' \
            | head -n1
    )
    if [ -n "$_li_cand" ]; then
        local_ip="$_li_cand"
        break
    fi
done
if [ -z "$local_ip" ]; then
    for _li in $LAN_IFACES; do
        _li_cand="$(ip -4 addr show "$_li" 2>/dev/null | awk '
            /inet / {
                split($2, a, "/"); split(a[1], o, ".")
                if (o[1] >= 1 && o[1] <= 223 && o[1] != 127 &&
                    !(o[1] == 169 && o[2] == 254)) { print a[1]; exit }
            }')"
        if [ -n "$_li_cand" ]; then
            local_ip="$_li_cand"
            log_msg "DNS-DNAT: RFC1918-адрес не найден, используется $local_ip ($_li)"
            break
        fi
    done
fi

# ═════════════════════════════════════════════════════════════════════════
# 8. Доступ к веб-панели: только из локальных сетей
# ═════════════════════════════════════════════════════════════════════════
# Правила ставятся здесь, а не только при старте панели: Keenetic
# пересоздаёт цепочки при смене состояния интерфейсов и вызывает этот хук,
# после чего разрешающие правила панели пропадали и она становилась
# недоступной из LAN до перезапуска S99generator.
# Разрешение выдаётся по ИСХОДНОЙ ПОДСЕТИ, а не по имени интерфейса:
# на Keenetic Wi-Fi-клиенты приходят через разные мосты (гостевая сеть,
# отдельный бридж 5 ГГц, имена вида wl0/ra0), угадать их нельзя.
if [ "${table:-}" = "filter" ]; then
    # Снять прежний DROP, чтобы добавить его последним.
    while $IPT -D INPUT -p tcp --dport "$PORT_WEB" \
        -j DROP >/dev/null 2>&1; do :; done

    # (ревизия 2026-10-12, блок B7): blanket RFC1918-разрешения сняты —
    # они открывали порты в сторону ЛЮБОЙ приватной -s-подсети, включая
    # аплинк, если провайдер выдаёт адрес из 10/8 (CGNAT/L2TP-сети).
    # Поэтому для веб-порта разрешаются только подсети, РЕАЛЬНО
    # существующие на определённых выше LAN-интерфейсах, а для
    # прокси-портов — только -i lo и -i <LAN>. Старые blanket-правила
    # со прежних установок зачищаются здесь же.
    for legacy_net in 192.168.0.0/16 10.0.0.0/8 172.16.0.0/12; do
        while $IPT -D INPUT -p tcp --dport "$PORT_WEB" \
            -s "$legacy_net" -j ACCEPT >/dev/null 2>&1
        do
            :
        done
    done

    _lan_subnets="127.0.0.0/8"
    _lan_found=0
    for proxy_if in $LAN_IFACES; do
        _if_nets=$(ip -4 addr show dev "$proxy_if" 2>/dev/null \
            | awk '/inet /{print $2}')
        for _if_net in $_if_nets; do
            case " $_lan_subnets " in
                *" $_if_net "*) ;;
                *) _lan_subnets="$_lan_subnets $_if_net" ;;
            esac
            _lan_found=1
        done
    done
    # K5 (повторный аудит): деградация доступности обязана оставлять
    # след в логе — иначе панель «просто пропадёт» на нестандартной
    # сборке ip или при сбое парсинга.
    [ "$_lan_found" = "1" ] || log_msg \
        "B7: подсети LAN не определены (ip -4 addr show) — веб-панель $PORT_WEB доступна только с 127.0.0.1"

    for web_net in $_lan_subnets; do
        if ! $IPT -C INPUT -p tcp --dport "$PORT_WEB" \
            -s "$web_net" -j ACCEPT >/dev/null 2>&1
        then
            $IPT -I INPUT -p tcp --dport "$PORT_WEB" \
                -s "$web_net" -j ACCEPT >/dev/null 2>&1 || true
        fi
    done

    $IPT -A INPUT -p tcp --dport "$PORT_WEB" -j DROP >/dev/null 2>&1 || true

    # ─────────────────────────────────────────────────────────────────
    # Прокси-порты: закрыть от WAN (defense-in-depth).
    # ─────────────────────────────────────────────────────────────────
    # ss-redir, tor, xray, trojan и hysteria слушают 0.0.0.0, потому что
    # принимают перехваченный трафик со всех внутренних интерфейсов.
    # Своих правил INPUT у них не было — защищал только межсетевой экран
    # прошивки. При случайном пробросе порта или его отключении роутер
    # превратился бы в открытый прокси-релей.
    #
    # Разрешение выдаётся двумя независимыми способами, чтобы ни один
    # легитимный путь не оказался отрезан:
    #   1) -i lo          — трафик самого роутера после REDIRECT/TPROXY
    #                       (bot.txt -> unblockrouter) приходит через lo;
    #   2) -i <LAN>       — перехваченный трафик клиентов.
    # Бывшая третья ось (-s RFC1918-blanket) удалена (ревизия 2026-10-12,
    # блок B7): она открывала прокси-порты в сторону аплинка при
    # приватной WAN-адресации (CGNAT, L2TP 10/8) — при отключённом
    # межсетевом экране прошивки роутер становился открытым релеем
    # для всех клиентов такой апстрим-подсети. Прежние -s-правила со
    # старых установок зачищаются при первом же проходе хука.
    # DROP ставится безусловно: при пустом LAN_IFACES легитимного пути
    # просто нет, и fail-open против собственного замысла недопустим.
    for proxy_port in "$PORT_SS" "$PORT_TOR" "$PORT_VLESS" \
        "$PORT_TROJAN" "$PORT_HYSTERIA"; do
        for proxy_proto in tcp udp; do
            # Снять прежний DROP, чтобы он снова оказался последним.
            while $IPT -D INPUT -p "$proxy_proto" \
                --dport "$proxy_port" -j DROP >/dev/null 2>&1
            do
                :
            done

            if ! $IPT -C INPUT -i lo -p "$proxy_proto" \
                --dport "$proxy_port" -j ACCEPT >/dev/null 2>&1
            then
                $IPT -I INPUT -i lo -p "$proxy_proto" \
                    --dport "$proxy_port" -j ACCEPT \
                    >/dev/null 2>&1 || true
            fi

            for proxy_if in $LAN_IFACES; do
                if ! $IPT -C INPUT -i "$proxy_if" -p "$proxy_proto" \
                    --dport "$proxy_port" -j ACCEPT >/dev/null 2>&1
                then
                    $IPT -I INPUT -i "$proxy_if" -p "$proxy_proto" \
                        --dport "$proxy_port" -j ACCEPT \
                        >/dev/null 2>&1 || true
                fi
            done

            # Зачистка наследия со старых установок.
            for proxy_net in 127.0.0.0/8 192.168.0.0/16 \
                10.0.0.0/8 172.16.0.0/12; do
                while $IPT -D INPUT -p "$proxy_proto" \
                    --dport "$proxy_port" -s "$proxy_net" \
                    -j ACCEPT >/dev/null 2>&1
                do
                    :
                done
            done

            $IPT -A INPUT -p "$proxy_proto" \
                --dport "$proxy_port" -j DROP \
                >/dev/null 2>&1 \
                || log_msg "INPUT DROP failed: $proxy_proto/$proxy_port"
        done
    done
fi

if [ "${table:-}" = "filter" ]; then
    # В таблице filter больше делать нечего.
    hook_finish
    exit $?
fi

if [ -z "$local_ip" ] && [ "${table:-}" = "nat" ]; then
    hook_warn "DNS-DNAT: IPv4-адрес LAN не найден — пропущено только перенаправление :53; TCP/UDP/VPN продолжаются"
fi

ensure_set() {
    ipset create "$1" hash:net family inet hashsize 1024 maxelem 65536 -exist 2>/dev/null || true
}

# ── Идемпотентные помощники (проверка через -C, без grep по iptables-save)
# Протокол считается выключенным, если в его init-скрипте стоит
# ENABLED=no (ползунок в веб-панели). Для такого протокола правила
# перехвата не создаются, а ранее созданные снимаются — иначе трафик
# уходил бы на порт остановленного сервиса и соединение просто рвалось.
svc_enabled() {
    _init="$1"
    _svc_quiet="${2:-0}"
    # Нет init-файла или он не исполняемый — протокол не установлен,
    # и правила на его порт создавать нельзя (M8): иначе трафик из
    # набора уходил бы на закрытый порт вместо прямого выхода.
    [ -f "$_init" ] || return 1
    [ -x "$_init" ] || return 1
    if grep -qE '^[[:space:]]*ENABLED[[:space:]]*=[[:space:]]*no' \
        "$_init" 2>/dev/null
    then
        return 1
    fi

    # Мало того, что сервис разрешён — он должен реально работать.
    # Правило на упавший сервис создаёт чёрную дыру: пакеты уходят на
    # порт, который никто не слушает, и клиент получает таймаут вместо
    # обхода (наблюдалось с hysteria: сервис dead, а 6 правил на
    # unblockhysteria стояли). Порт берётся из PROCS init-скрипта.
    _svc_proc="$(sed -n \
        's/^[[:space:]]*PROCS[[:space:]]*=[[:space:]]*\([^[:space:]#]*\).*/\1/p' \
        "$_init" 2>/dev/null | head -1)"
    [ -n "$_svc_proc" ] || return 0

    # Разбор /proc, без pgrep: он есть не во всех сборках BusyBox.
    # Сравнивается ИМЯ БИНАРНИКА (argv[0]), а не вся командная строка:
    # подстрочный поиск принимал за живой сервис любой процесс, где имя
    # встречается в аргументах — например "vi /opt/etc/hysteria/config.json"
    # или "tail -f .../hysteria.log". Тогда правила создавались для
    # мёртвого сервиса, то есть ровно та ошибка, ради которой делалась
    # проверка.
    # Результат кэшируется на время прогона: функция вызывается до 15 раз
    # (5 сервисов × 3 интерфейса), и каждый раз обходить весь /proc
    # слишком дорого — прошивка убивала хук по таймауту
    # ("100-redirect.sh: timed out", Opkg::Manager).
    # PROCS в поставляемых init-скриптах — фиксированный набор. Явный
    # case сохраняет дешёвый кэш без eval и без предсказуемых файлов /tmp.
    case "$_svc_proc" in
        ss-redir) _svc_cached="${_SVC_ALIVE_SS_REDIR:-}" ;;
        tor) _svc_cached="${_SVC_ALIVE_TOR:-}" ;;
        xray) _svc_cached="${_SVC_ALIVE_XRAY:-}" ;;
        trojan) _svc_cached="${_SVC_ALIVE_TROJAN:-}" ;;
        hysteria) _svc_cached="${_SVC_ALIVE_HYSTERIA:-}" ;;
        *) _svc_cached="" ;;
    esac
    case "$_svc_cached" in
        1) return 0 ;;
        0) return 1 ;;
    esac

    _svc_found=1
    for _svc_d in /proc/[0-9]*; do
        # Процесс мог завершиться между раскрытием маски и чтением файла.
        # Перенаправление "< файл" выполняет ОБОЛОЧКА, и её сообщение
        # "can't open ...: no such file" не подавляется через 2>/dev/null
        # у самой команды — в журнале роутера это выглядело как ошибка
        # скрипта. Читаем через cat с подавлением его собственного stderr.
        _svc_argv0="$(cat "$_svc_d/cmdline" 2>/dev/null \
            | tr '\0' '\n' | head -1)"
        [ -n "$_svc_argv0" ] || continue
        # argv[0] может быть как "hysteria", так и "/opt/bin/hysteria".
        if [ "${_svc_argv0##*/}" = "$_svc_proc" ]; then
            _svc_found=0
            break
        fi
    done

    _svc_value=0
    [ "$_svc_found" = "0" ] && _svc_value=1
    case "$_svc_proc" in
        ss-redir) _SVC_ALIVE_SS_REDIR="$_svc_value" ;;
        tor) _SVC_ALIVE_TOR="$_svc_value" ;;
        xray) _SVC_ALIVE_XRAY="$_svc_value" ;;
        trojan) _SVC_ALIVE_TROJAN="$_svc_value" ;;
        hysteria) _SVC_ALIVE_HYSTERIA="$_svc_value" ;;
    esac
    if [ "$_svc_value" = 1 ]; then
        return 0
    fi

    [ "$_svc_quiet" = 1 ] || log_msg "$_svc_proc не запущен"
    return 1
}

# Снимает правило REDIRECT с конкретного интерфейса.
nat_del_prerouting() {
    _proto="$1"
    _set="$2"
    _port="$3"
    _if="$4"
    while $IPT -t nat -D PREROUTING -i "$_if" -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    do
        :
    done
}

# Снимает правило TPROXY с конкретного интерфейса.
mangle_del_tproxy() {
    _set="$1"
    _port="$2"
    _if="$3"
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst \
        -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
        --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    do
        :
    done
}

# Если TPROXY отвергнут ядром, UDP назначения из списка нельзя выпускать
# напрямую. DROP располагается в том же служебном блоке перед TPROXY и
# снимается сразу после успешного восстановления боевого правила.
mangle_del_tproxy_fallback() {
    _set="$1"
    _if="$2"
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst -j DROP >/dev/null 2>&1
    do
        :
    done
}

mangle_add_tproxy_fallback() {
    _set="$1"
    _if="$2"
    _pos="${UDP_GUARD_POS:-1}"
    if ! $IPT -t mangle -C PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst -j DROP >/dev/null 2>&1
    then
        _drop_err="$($IPT -t mangle -I PREROUTING "$_pos" -i "$_if" \
            -p udp -m set --match-set "$_set" dst -j DROP 2>&1)" || {
            hook_error "fail-closed DROP add failed: $_set/$_if: $_drop_err"
            return 1
        }
    fi
    return 0
}

nat_add_prerouting() {
    _proto="$1"
    _set="$2"
    _port="$3"
    _if="$4"
    if ! set_exists "$_set"; then
        hook_error "REDIRECT skip: ipset $_set отсутствует"
        return 0
    fi
    if ! $IPT -t nat -C PREROUTING -i "$_if" -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    then
        _nat_err="$($IPT -t nat -A PREROUTING -i "$_if" -p "$_proto" \
            -m set --match-set "$_set" dst \
            -j REDIRECT --to-port "$_port" 2>&1)" || {
            hook_error "REDIRECT add failed: $_proto/$_set/$_port/$_if: $_nat_err"
            return 0
        }
    fi
    return 0
}

nat_del_prerouting_any() {
    # Удаляет старое правило без -i (наследие прежних версий).
    _proto="$1"
    _set="$2"
    _port="$3"
    while $IPT -t nat -D PREROUTING -p "$_proto" \
        -m set --match-set "$_set" dst \
        -j REDIRECT --to-port "$_port" >/dev/null 2>&1
    do
        :
    done
}

# Загрузка модуля netfilter при необходимости.
# Хук вызывается при каждой перестройке цепочек, в том числе при
# загрузке роутера, поэтому модули грузятся именно здесь: деплой
# выполняется однократно и после reboot не отработает.
# modprobe на Keenetic бесполезен — в /lib/modules нет modules.dep,
# поэтому используется insmod с полным путём к .ko.
load_kmod() {
    _km="$1"

    if lsmod 2>/dev/null | awk -v m="$_km" '$1==m {f=1} END{exit !f}'
    then
        return 0
    fi

    modprobe "$_km" >/dev/null 2>&1 && return 0

    _kdir="/lib/modules/$(uname -r)"
    [ -d "$_kdir" ] || return 1

    _kfile="$(find "$_kdir" -name "${_km}.ko" -print 2>/dev/null \
        | head -n1)"
    [ -n "$_kfile" ] || return 1

    insmod "$_kfile" >/dev/null 2>&1 || true

    lsmod 2>/dev/null | awk -v m="$_km" '$1==m {f=1} END{exit !f}'
}

# Цель TPROXY доступна только при загруженном xt_TPROXY. Проверяем по
# факту наличия цели в ядре и при отсутствии — догружаем модули.
ensure_tproxy_kmod() {
    if grep -qx 'TPROXY' /proc/net/ip_tables_targets 2>/dev/null; then
        return 0
    fi

    for _d in nf_defrag_ipv4 nf_tproxy_ipv4 nf_tproxy_core \
        nf_socket_ipv4 ip_set; do
        load_kmod "$_d" >/dev/null 2>&1 || true
    done
    for _m in xt_TPROXY xt_socket xt_set; do
        load_kmod "$_m" >/dev/null 2>&1 || true
    done

    if grep -qx 'TPROXY' /proc/net/ip_tables_targets 2>/dev/null; then
        log_msg "xt_TPROXY загружен вручную (insmod)"
        return 0
    fi
    return 1
}

mangle_add_tproxy() {
    _set="$1"
    _port="$2"
    _if="$3"

    # Набор обязан существовать: без него iptables отвергает правило
    # целиком ("Set ... doesn't exist" / "Can't open socket to ipset").
    if ! set_exists "$_set"; then
        hook_error "TPROXY skip: ipset $_set отсутствует"
        return 0
    fi

    if $IPT -t mangle -C PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst \
        -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
        --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
    then
        mangle_del_tproxy_fallback "$_set" "$_if"
        return 0
    fi

    # Ошибка TPROXY не подавляется, но её rc зависит от результата DROP:
    # установленный fallback означает безопасную деградацию, а не падение
    # hook-а. Ненулевой rc остаётся только если не создался и DROP.
    _err="$($IPT -t mangle -A PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst \
        -j TPROXY --on-ip 127.0.0.1 --on-port "$_port" \
        --tproxy-mark "${TPROXY_MARK}/${TPROXY_MASK}" 2>&1)" || {
        if mangle_add_tproxy_fallback "$_set" "$_if"; then
            if [ "${_tproxy_degraded_reported:-0}" = 0 ]; then
                _tproxy_degraded_reported=1
                hook_degraded "TPROXY недоступен; UDP закрыт fail-closed DROP: $_err"
            fi
        fi
        # Ошибка "No chain/target/match by that name" неоднозначна — одна
        # безопасная проба отделяет отсутствие TPROXY от отказа -m set.
        # Её результат не меняет policy: решающим остаётся наличие DROP.
        if [ "${_tproxy_diag:-0}" = "0" ]; then
            _tproxy_diag=1
            if $IPT -t mangle -I PREROUTING -p udp \
                -d 127.0.0.2 --dport 1 \
                -j TPROXY --on-ip 127.0.0.1 \
                --on-port 12345 --tproxy-mark 1/1 >/dev/null 2>&1
            then
                $IPT -t mangle -D PREROUTING -p udp \
                    -d 127.0.0.2 --dport 1 \
                    -j TPROXY --on-ip 127.0.0.1 \
                    --on-port 12345 --tproxy-mark 1/1 \
                    >/dev/null 2>&1 || true
            fi
        fi
        return 0
    }

    mangle_del_tproxy_fallback "$_set" "$_if"
    return 0
}

# ── H6: ndm вызывает хук отдельно на nat, mangle и filter. Раньше весь
# файл исполнялся трижды (~370 вызовов iptables на событие). Ниже
# разводка работы по таблицам; тела секций не изменены. Системные
# действия (модули, ip rule/route) и ipset-ensure — общие.
# (P10, аудит rev3: строка «[ "$table" = "filter" ] && exit 0» была
# мёртвой — filter-ветка уже вышла из скрипта раньше, на блоке
# «В таблице filter больше делать нечего»; удалена.)
if [ "$table" = "mangle" ]; then _tbl_sys=1; else _tbl_sys=0; fi
if [ "$table" = "nat" ]; then _tbl_nat=1; else _tbl_nat=0; fi

# Пути init-скриптов control-plane и DNS-tunnel: по ним читается
# состояние ползунка ENABLED и проверяется ожидаемый процесс.
INIT_VLESS="/opt/etc/init.d/S24xray"
INIT_TROJ="/opt/etc/init.d/S22trojan"
INIT_HY="/opt/etc/init.d/S57hysteria"

# ── Выбор протокола для трафика роутера (bot.txt -> unblockrouter) ─────
# vl — xray :10810 · tr — trojan :10829 (только TCP: UDP при нём не
# перехватывается) · hy — hysteria :10830. Источник выбора — файл
# /opt/etc/unblock/router_proto (ставит панель, вкладка «Бот»); до его
# появления — vless (историческое поведение). Тест из консоли:
# ROUTER_PROTOCOL=tr type=iptable table=nat <этот хук>.
ROUTER_PROTO_FILE="/opt/etc/unblock/router_proto"
router_proto() {
    _rp=""
    if [ -n "${ROUTER_PROTOCOL:-}" ]; then
        _rp="$ROUTER_PROTOCOL"
    elif [ -r "$ROUTER_PROTO_FILE" ]; then
        _rp="$(tr -d ' \t\r\n' < "$ROUTER_PROTO_FILE" 2>/dev/null)"
    fi
    case "$_rp" in
        vl|tr|hy) printf '%s' "$_rp" ;;
        *) printf '%s' vl ;;
    esac
}

# ── Готовность и безопасный failover control-plane ──────────────────────
# Наличие процесса не гарантирует, что REDIRECT/TPROXY-порт уже слушает.
# Снимки /proc/net строятся один раз на вызов; файлового liveness-кэша нет.
# Это local readiness, а не проверка доступности удалённого proxy-сервера.
_ROUTER_TCP_PORTS="$(awk '
    FNR > 1 && $4 == "0A" {
        split($2, a, ":"); if (a[2] != "") print toupper(a[2])
    }' /proc/net/tcp /proc/net/tcp6 2>/dev/null || true)"
_ROUTER_UDP_PORTS="$(awk '
    FNR > 1 {
        split($2, a, ":"); if (a[2] != "") print toupper(a[2])
    }' /proc/net/udp /proc/net/udp6 2>/dev/null || true)"

router_port_ready() {
    _rpr_proto="$1"
    _rpr_hex="$(printf '%04X' "$2" 2>/dev/null)"
    [ -n "$_rpr_hex" ] || return 1
    if [ "$_rpr_proto" = tcp ]; then
        _rpr_ports="$_ROUTER_TCP_PORTS"
    else
        _rpr_ports="$_ROUTER_UDP_PORTS"
    fi
    case "
${_rpr_ports}
" in
        *"
${_rpr_hex}
"*) return 0 ;;
    esac
    return 1
}

router_proto_ready() {
    case "$1" in
        vl) _rdy_init="$INIT_VLESS"; _rdy_port="$PORT_VLESS"; _rdy_udp=1 ;;
        tr) _rdy_init="$INIT_TROJ";  _rdy_port="$PORT_TROJAN"; _rdy_udp=0 ;;
        hy) _rdy_init="$INIT_HY";    _rdy_port="$PORT_HYSTERIA"; _rdy_udp=1 ;;
        *) return 1 ;;
    esac
    svc_enabled "$_rdy_init" 1 || return 1
    router_port_ready tcp "$_rdy_port" || return 1
    [ "$_rdy_udp" = 0 ] || router_port_ready udp "$_rdy_port"
}

ROUTER_SELECTED="$(router_proto)"
ROUTER_READY_VL=0
ROUTER_READY_TR=0
ROUTER_READY_HY=0
router_proto_ready vl && ROUTER_READY_VL=1
router_proto_ready tr && ROUTER_READY_TR=1
router_proto_ready hy && ROUTER_READY_HY=1
ROUTER_EFFECTIVE="$ROUTER_SELECTED"
ROUTER_STATE=blocked
case "$ROUTER_SELECTED" in
    vl) _router_selected_ready="$ROUTER_READY_VL" ;;
    tr) _router_selected_ready="$ROUTER_READY_TR" ;;
    hy) _router_selected_ready="$ROUTER_READY_HY" ;;
esac
if [ "$_router_selected_ready" = 1 ]; then
    ROUTER_STATE=ready
else
    # Сначала варианты с полноценным TCP+UDP, затем TCP-only Trojan.
    # Direct path здесь принципиально отсутствует.
    for _router_fallback in vl hy tr; do
        [ "$_router_fallback" = "$ROUTER_SELECTED" ] && continue
        case "$_router_fallback" in
            vl) _router_fallback_ready="$ROUTER_READY_VL" ;;
            tr) _router_fallback_ready="$ROUTER_READY_TR" ;;
            hy) _router_fallback_ready="$ROUTER_READY_HY" ;;
        esac
        if [ "$_router_fallback_ready" = 1 ]; then
            ROUTER_EFFECTIVE="$_router_fallback"
            ROUTER_STATE=fallback
            break
        fi
    done
fi
case "$ROUTER_STATE" in
    fallback)
        hook_warn "control-plane: $ROUTER_SELECTED не готов; безопасный tunnel failover -> $ROUTER_EFFECTIVE"
        ;;
    blocked)
        hook_degraded "control-plane: нет готового туннеля; unblockrouter остаётся fail-closed на $ROUTER_EFFECTIVE"
        ;;
esac

# Статус читается панелью, но не используется hook-ом как источник истины.
# Запись атомарна; значения принадлежат фиксированным enum/0/1.
_router_status_file="/tmp/keenzoo_router_status"
_router_status_tmp="${_router_status_file}.tmp.$$"
if (umask 077 && {
    printf 'selected=%s\n' "$ROUTER_SELECTED"
    printf 'effective=%s\n' "$ROUTER_EFFECTIVE"
    printf 'state=%s\n' "$ROUTER_STATE"
    printf 'ready_vl=%s\n' "$ROUTER_READY_VL"
    printf 'ready_tr=%s\n' "$ROUTER_READY_TR"
    printf 'ready_hy=%s\n' "$ROUTER_READY_HY"
    printf 'table=%s\n' "${table:-unknown}"
    printf 'timestamp=%s\n' "$(date +%s 2>/dev/null || echo 0)"
} > "$_router_status_tmp") 2>/dev/null; then
    mv -f "$_router_status_tmp" "$_router_status_file" 2>/dev/null \
        || rm -f "$_router_status_tmp"
else
    rm -f "$_router_status_tmp"
fi

# ═════════════════════════════════════════════════════════════════════════
# 1. DNS клиентов -> локальный dnsmasq (только внутренние интерфейсы)
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ] && [ -n "$local_ip" ]; then

# Прежняя версия ставила DNAT без -i: правило применялось и к пакетам,
# пришедшим с WAN, то есть роутер становился открытым DNS-релеем.
for protocol in udp tcp; do
    while $IPT -t nat -D PREROUTING -p "$protocol" --dport 53 \
        -j DNAT --to-destination "$local_ip" >/dev/null 2>&1
    do
        :
    done
done

for iface in $LAN_IFACES; do
    for protocol in udp tcp; do
        if ! $IPT -t nat -C PREROUTING -i "$iface" -p "$protocol" --dport 53 \
            -j DNAT --to-destination "$local_ip" >/dev/null 2>&1
        then
            $IPT -t nat -I PREROUTING -i "$iface" -p "$protocol" --dport 53 \
                -j DNAT --to-destination "$local_ip" >/dev/null 2>&1 || true
        fi
    done
done

fi

# ═════════════════════════════════════════════════════════════════════════
# 2. Подготовка ipset
# ═════════════════════════════════════════════════════════════════════════
for s in unblocksh unblocktor unblockvless unblocktroj unblockhysteria unblockrouter unblockdns; do
    ensure_set "$s"
done

# Снимок имён один раз на hook-вызов. Проверки ниже выполняются exact-name
# сравнением в shell: это заменяет десятки fork/exec `ipset list -n SET`.
# Снимок не сохраняется в /tmp и поэтому не переживает следующее событие.
_IPSET_NAMES="$(ipset list -n 2>/dev/null || true)"
ipset_snapshot_has() {
    _ish_name="$1"
    case "
${_IPSET_NAMES}
" in
        *"
${_ish_name}
"*) return 0 ;;
    esac
    return 1
}

# Если общий listing оказался неполным (редкая несовместимость ipset или
# сбой ensure), нельзя удалять guard, а затем объявлять set отсутствующим.
# В таком аварийном случае возвращаемся к прежней точечной проверке.
_IPSET_SNAPSHOT_OK=1
for _ish_required in unblocksh unblocktor unblockvless unblocktroj \
    unblockhysteria unblockrouter unblockdns; do
    ipset_snapshot_has "$_ish_required" || _IPSET_SNAPSHOT_OK=0
done
set_exists() {
    _se_name="$1"
    ipset_snapshot_has "$_se_name" && return 0
    [ "$_IPSET_SNAPSHOT_OK" = 1 ] && return 1
    ipset list -n "$_se_name" >/dev/null 2>&1
}

# ═════════════════════════════════════════════════════════════════════════
# 3. Чистка устаревших/некорректных правил
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ]; then

# UDP через nat/REDIRECT для Tor/Trojan/Hysteria: это TCP-входы либо
# TPROXY-входы, REDIRECT ломал такой трафик.
nat_del_prerouting_any udp unblocktor "$PORT_TOR"
nat_del_prerouting_any udp unblocktroj "$PORT_TROJAN"
nat_del_prerouting_any udp unblockhysteria "$PORT_HYSTERIA"
nat_del_prerouting_any udp unblockvless "$PORT_VLESS"
# Старые правила без -i.
nat_del_prerouting_any tcp unblocksh "$PORT_SS"
nat_del_prerouting_any udp unblocksh "$PORT_SS"
nat_del_prerouting_any tcp unblocktor "$PORT_TOR"
nat_del_prerouting_any tcp unblockvless "$PORT_VLESS"
nat_del_prerouting_any tcp unblocktroj "$PORT_TROJAN"
nat_del_prerouting_any tcp unblockhysteria "$PORT_HYSTERIA"

fi

# ═════════════════════════════════════════════════════════════════════════
# 4. TCP: nat/REDIRECT на локальные порты (по каждому внутр. интерфейсу)
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ]; then

# Пути init-скриптов находятся в общем блоке выше; состояние процессов
# используется только для выбора DNS-tunnel, но не для снятия перехвата.

# Fail-closed: наличие записей в ipset, а не состояние процесса, определяет
# перехват. Отключённый/повреждённый сервис оставляет назначения
# недоступными на локальном порту вместо прямого выхода через провайдера.
for iface in $LAN_IFACES; do
    nat_add_prerouting tcp unblocksh         "$PORT_SS"       "$iface"
    # ss-redir запущен с -u и обрабатывает UDP через REDIRECT.
    nat_add_prerouting udp unblocksh         "$PORT_SS"       "$iface"
    nat_add_prerouting tcp unblocktor        "$PORT_TOR"      "$iface"
    nat_add_prerouting tcp unblockvless      "$PORT_VLESS"    "$iface"
    nat_add_prerouting tcp unblocktroj       "$PORT_TROJAN"   "$iface"
    nat_add_prerouting tcp unblockhysteria   "$PORT_HYSTERIA" "$iface"
done

fi

# ═════════════════════════════════════════════════════════════════════════
# 5. UDP через TPROXY для VLESS (xray) и Hysteria2
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_sys" = 1 ]; then

# nat/REDIRECT для UDP не сохраняет оригинальный адрес назначения, поэтому
# dokodemo-door/udpTProxy получали пакеты без dst и трафик рвался.
# Корректная схема: mangle/TPROXY + метка + локальная таблица маршрутизации.
#
# G27 (ред. 29): проверяем ВЕСЬ контракт правила, а не любое `lookup 100`:
# при наличии чужого правила той же таблицы прежний grep подавлял создание
# fwmark-маршрута, и UDP уходил мимо lo. Одновременно удаляем точные дубли,
# накопленные старой проверкой с якорем `$` (на части прошивок строка
# `ip rule show` оканчивается пробелом, поэтому hook добавлял правило снова).
tproxy_rule_count() {
    ip -4 rule show 2>/dev/null | awk \
        -v p="${TPROXY_RULE_PRIO}:" \
        -v m="$TPROXY_MARK" -v mask="$TPROXY_MASK" \
        -v t="$TPROXY_TABLE" '
        $1 == p {
            mark_ok=0; table_ok=0
            for (i=1; i<=NF; i++) {
                if ($i=="fwmark" &&
                    ($(i+1)==m || $(i+1)==m "/" mask)) mark_ok=1
                if (($i=="lookup" || $i=="table") && $(i+1)==t)
                    table_ok=1
            }
            if (mark_ok && table_ok) n++
        }
        END { print n+0 }
    '
}

_tpr_count="$(tproxy_rule_count)"
case "$_tpr_count" in ''|*[!0-9]*) _tpr_count=0 ;; esac
while [ "$_tpr_count" -gt 1 ]; do
    if ip -4 rule del fwmark "${TPROXY_MARK}/${TPROXY_MASK}" \
        lookup "$TPROXY_TABLE" priority "$TPROXY_RULE_PRIO" \
        >/dev/null 2>&1
    then
        _tpr_count=$((_tpr_count - 1))
    else
        log_msg "TPROXY ip rule: не удалось удалить дубликат"
        break
    fi
done
if [ "$_tpr_count" -eq 0 ]; then
    if ! ip -4 rule add fwmark "${TPROXY_MARK}/${TPROXY_MASK}" \
        lookup "$TPROXY_TABLE" priority "$TPROXY_RULE_PRIO" \
        >/dev/null 2>&1
    then
        hook_error "TPROXY ip rule add failed: mark=${TPROXY_MARK}/${TPROXY_MASK} table=$TPROXY_TABLE priority=$TPROXY_RULE_PRIO"
    fi
fi

ip -4 route replace local default dev lo table "$TPROXY_TABLE" 2>/dev/null \
    || hook_error "TPROXY route add failed: local default dev lo table $TPROXY_TABLE"

# Модули netfilter должны быть загружены ДО создания правил: на Keenetic
# xt_TPROXY.ko поставляется прошивкой, но автоматически не грузится.
ensure_tproxy_kmod || true

# Верх PREROUTING перестраивается детерминированно. `iptables -I` без
# позиции всегда вставляет правило первым: прежний код сначала ставил DNS,
# затем socket и фактически инвертировал обещанный порядок. Удаляем только
# точные правила KeenZOO, затем создаём socket, а DNS вставляем над ним.
while $IPT -t mangle -D PREROUTING -p udp --dport 53 \
    -j RETURN >/dev/null 2>&1; do :; done
while $IPT -t mangle -D PREROUTING -p udp -m socket \
    -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" \
    >/dev/null 2>&1; do :; done

_SOCKET_RULE_OK=0
if [ "$IPT_HAS_SOCKET" = 1 ]; then
    if $IPT -t mangle -I PREROUTING 1 -p udp -m socket \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" \
        >/dev/null 2>&1
    then
        _SOCKET_RULE_OK=1
    else
        hook_warn "socket-MARK add failed — продолжаем без xt_socket"
    fi
else
    hook_warn "xt_socket недоступен — продолжаем без socket-MARK"
fi

_DNS_RULE_OK=0
if $IPT -t mangle -I PREROUTING 1 -p udp --dport 53 \
    -j RETURN >/dev/null 2>&1
then
    _DNS_RULE_OK=1
else
    hook_error "DNS RETURN add failed"
fi

# Guards/fallback DROP должны стоять сразу после реально созданных
# служебных правил и до любых старых/новых TPROXY.
UDP_GUARD_POS=1
[ "$_DNS_RULE_OK" = 1 ] && UDP_GUARD_POS=$((UDP_GUARD_POS + 1))
[ "$_SOCKET_RULE_OK" = 1 ] && UDP_GUARD_POS=$((UDP_GUARD_POS + 1))

# UDP-guard (fail-closed) для TCP-only входов: у trojan и tor нет
# UDP-перехвата по дизайну. Раньше их UDP в mangle не распознавался:
# если IP домена оказывался в наборе vless/hysteria (общий CDN-адрес),
# пакет подхватывало TPROXY чужого протокола, а без чужого совпадения
# он уходил напрямую провайдеру мимо туннеля (инцидент: whoer.net из
# trojan.txt показывал egress Hysteria — QUIC/443 на Cloudflare-IP из
# unblockhysteria). Явный DROP ставится ДО правил TPROXY (вставка
# на позицию 3, сразу за меткой сокета и DNS-возвратом): REJECT ядром
# этой сборки не принимается в mangle (только filter), DROP согласован
# со всеми таблицами. QUIC такого домена теряет handshake-пакеты,
# Happy Eyeballs уходит на TCP через свой туннель. Пересечения с наборами
# VLESS/Hysteria исключаются ниже и продолжают идти в их UDP-TPROXY.
#
# G27 (ред. 29): старые релизы ставили широкий DROP без исключений. При
# обновлении установленный Tor/Trojan шёл сразу в add-функцию, поэтому
# legacy-правило не снималось и продолжало убивать UDP VLESS/Hysteria на
# общих CDN-IP. Удаляем только старую широкую форму (DROP и исторический
# REJECT) перед проверкой нового правила; новое правило не затрагивается.
mangle_del_udpguard_legacy() {
    _set="$1"
    _if="$2"
    for _guard_target in DROP REJECT; do
        while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
            -m set --match-set "$_set" dst -j "$_guard_target" \
            >/dev/null 2>&1
        do
            :
        done
    done
}

mangle_add_udpguard() {
    _set="$1"
    _if="$2"
    # В том числе снимается уже существующая refined-форма: простая -C
    # оставляла её на старой позиции ниже чужого/миграционного TPROXY.
    mangle_del_udpguard "$_set" "$_if"
    if ! set_exists "$_set"; then
        hook_error "UDP-guard skip: ipset $_set отсутствует"
        return 0
    fi
    # Освобождение пересечений (ревью 2026-10-12): логические наборы
    # пересекаются по CDN-IP (один IP одновременно в troj и vless
    # наборах — облачные фронты делят их тысячами). DROP ко всему set
    # убивал бы UDP vless-доменов на таких IP, хотя xray 24.x+ несёт
    # их UDP через собственный UoT/XUDP. Для dst из наборов протоколов
    # с UDP-инбаундом (vless, hysteria) guard не действует — пакет
    # пройдёт до TPROXY-позиции и уйдёт в их порт. Чисто troj/tor-IP
    # по-прежнему защищены от утечки (у них UDP-инбаундов нет).
    _gn_excl=""
    for _gn_ex in unblockvless unblockhysteria; do
        if set_exists "$_gn_ex"; then
            _gn_excl="$_gn_excl -m set ! --match-set $_gn_ex dst"
        fi
    done
    _guard_err="$($IPT -t mangle -I PREROUTING "$UDP_GUARD_POS" \
        -i "$_if" -p udp -m set --match-set "$_set" dst \
        $_gn_excl -j DROP 2>&1)" || {
        hook_error "UDP-guard add failed: $_set/$_if/pos=$UDP_GUARD_POS: $_guard_err"
        return 0
    }
    return 0
}
mangle_del_udpguard() {
    _set="$1"
    _if="$2"
    # Удаляем обе разновидности: новую с exclusion-цепочкой и legacy без
    # неё. Последняя функция также чистит исторический REJECT.
    _gd_excl=""
    for _gd_ex in unblockvless unblockhysteria; do
        _gd_excl="$_gd_excl -m set ! --match-set $_gd_ex dst"
    done
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp \
        -m set --match-set "$_set" dst $_gd_excl -j DROP \
        >/dev/null 2>&1
    do
        :
    done
    mangle_del_udpguard_legacy "$_set" "$_if"
}

# ── vless: LEGACY-зачистка vision-гарда UDP/443 (2026-10-12) ──────────
# Ранее для ключей с flow=xtls-rprx-vision здесь ставился DROP udp/443 до
# TPROXY: считалось, что Vision не несёт UDP вовсе. Замер на живом ядре
# xray 26.x доказал обратное: UDP/443 клиентское ядро роняет само по
# дизайну Vision (QUIC→TCP), а прочий UDP (звонки, игры, STUN) переносит
# через UoT/XUDP без гардов (живой звонок Telegram через туннель с ростом
# UDP-счётчиков TPROXY). Гард как отдельный слой iptables снят; цикл
# ниже идемпотентно стирает правила прежних прогонов.
mangle_del_vlessquicguard() {
    _set="$1"
    _if="$2"
    while $IPT -t mangle -D PREROUTING -i "$_if" -p udp --dport 443 \
        -m set --match-set "$_set" dst -j DROP >/dev/null 2>&1
    do
        :
    done
}

# Гард раньше TPROXY: порядок в кадре определяет победителя правила.
# Наличие/ENABLED сервиса не влияет на fail-closed классификацию списка.
for iface in $LAN_IFACES; do
    mangle_add_udpguard unblocktroj "$iface"
    mangle_add_udpguard unblocktor "$iface"
done

# Vision-гард снят (см. комментарий к зачистке выше): на ядрах xray >=24
# блок UDP/443 делает само клиентское ядро по дизайну Vision; остатки
# прежних DROP-правил безусловно стираем на каждом прогоне хука.
for iface in $LAN_IFACES; do
    mangle_del_vlessquicguard unblockvless "$iface"
done

for iface in $LAN_IFACES; do
    mangle_add_tproxy unblockvless    "$PORT_VLESS"    "$iface"
    mangle_add_tproxy unblockhysteria "$PORT_HYSTERIA" "$iface"
done

# UDP, сгенерированный самим роутером (bot.txt -> unblockrouter):
# mangle/OUTPUT лишь маркирует пакет, таблица 100 ведёт его на lo, а
# TPROXY-правила для lo не было — чёрная дыра (H3). Пользовательский
# выбор хранится в router_proto, а ROUTER_EFFECTIVE может временно указать
# на другой local-ready туннель. Остальные варианты снимаются. Trojan UDP
# не принимает — при effective=tr он блокируется в OUTPUT ниже.
_rp="$ROUTER_EFFECTIVE"
# Fallback DROP не содержит port. Поэтому его нельзя снимать в `else`
# цикла по портам: при effective=vl следующая итерация `hy` удаляла только
# что созданный DROP и снова открывала router UDP при отсутствии TPROXY.
for _rp_port in "$PORT_VLESS" "$PORT_HYSTERIA"; do
    mangle_del_tproxy unblockrouter "$_rp_port" lo
done
mangle_del_tproxy_fallback unblockrouter lo
case "$_rp" in
    vl) mangle_add_tproxy unblockrouter "$PORT_VLESS" lo ;;
    hy) mangle_add_tproxy unblockrouter "$PORT_HYSTERIA" lo ;;
    tr) : ;;
esac

fi

# ═════════════════════════════════════════════════════════════════════════
# 6. Трафик самого роутера (bot.txt -> unblockrouter)
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_nat" = 1 ]; then

if ! $IPT -t nat -C OUTPUT -o lo -j RETURN >/dev/null 2>&1; then
    $IPT -t nat -I OUTPUT -o lo -j RETURN >/dev/null 2>&1 || true
fi

for net in 127.0.0.0/8 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16; do
    if ! $IPT -t nat -C OUTPUT -d "$net" -j RETURN >/dev/null 2>&1; then
        $IPT -t nat -A OUTPUT -d "$net" -j RETURN >/dev/null 2>&1 || true
    fi
done

# Защита от петли: пакеты, которые xray сам отправляет наружу, помечены
# XRAY_MARK (sockopt.mark в outbound). Без этого исключения правила ниже
# завернули бы исходящий трафик xray обратно в его же inbound.
if ! $IPT -t nat -C OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; then
    $IPT -t nat -I OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1 || true
fi
fi

if [ "$_tbl_sys" = 1 ]; then
if ! $IPT -t mangle -C OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1; then
    $IPT -t mangle -I OUTPUT -m mark --mark "$XRAY_MARK" -j RETURN >/dev/null 2>&1 || true
fi
fi

if [ "$_tbl_nat" = 1 ]; then

# DNS через активный туннель. В наборе unblockdns находятся адреса
# внешних системных DoH/DoT endpoint-ов, а не IP произвольных сайтов.
# Поэтому клиентский DNS остаётся в dnsmasq/system proxy, а только его
# исходящие TCP/443 и TCP/853 соединения идут через выбранный tunnel.
DNS_TUNNEL_PORT=""
if [ "${DNS_TUNNEL_DISABLE:-0}" != "1" ]; then
    case "${DNS_TUNNEL_PROTOCOL:-}" in
        xray) DNS_TUNNEL_PORT="$PORT_VLESS" ;;
        trojan) DNS_TUNNEL_PORT="$PORT_TROJAN" ;;
        hysteria) DNS_TUNNEL_PORT="$PORT_HYSTERIA" ;;
        *)
            if svc_enabled "$INIT_VLESS"; then
                DNS_TUNNEL_PORT="$PORT_VLESS"
            elif svc_enabled "$INIT_TROJ"; then
                DNS_TUNNEL_PORT="$PORT_TROJAN"
            elif svc_enabled "$INIT_HY"; then
                DNS_TUNNEL_PORT="$PORT_HYSTERIA"
            fi
            ;;
    esac
fi

# Снять старые варианты, включая прежнее правило без --dport.
for _dns_tunnel_port in "$PORT_VLESS" "$PORT_TROJAN" "$PORT_HYSTERIA"; do
    for _dns_remote_port in 443 853; do
        while $IPT -t nat -D OUTPUT -p tcp --dport "$_dns_remote_port" \
            -m set --match-set unblockdns dst \
            -j REDIRECT --to-port "$_dns_tunnel_port" >/dev/null 2>&1; do :; done
    done
    while $IPT -t nat -D OUTPUT -p tcp \
        -m set --match-set unblockdns dst \
        -j REDIRECT --to-port "$_dns_tunnel_port" >/dev/null 2>&1; do :; done
done

if [ -n "$DNS_TUNNEL_PORT" ]; then
    for _dns_remote_port in 443 853; do
        if ! $IPT -t nat -C OUTPUT -p tcp --dport "$_dns_remote_port" \
            -m set --match-set unblockdns dst \
            -j REDIRECT --to-port "$DNS_TUNNEL_PORT" >/dev/null 2>&1; then
            $IPT -t nat -A OUTPUT -p tcp --dport "$_dns_remote_port" \
                -m set --match-set unblockdns dst \
                -j REDIRECT --to-port "$DNS_TUNNEL_PORT" >/dev/null 2>&1 || true
        fi
    done
fi

# TCP роутера (bot.txt) -> effective-протокол: выбранный local-ready либо
# безопасный tunnel fallback. Если готовых туннелей нет, effective остаётся
# выбранным и закрытый порт даёт RST вместо прямой утечки. Остальные порты
# снимаются циклом перед установкой effective-варианта.
_rp="$ROUTER_EFFECTIVE"
for _rpv in vl tr hy; do
    case "$_rpv" in
        vl) _rp_port="$PORT_VLESS" ;;
        tr) _rp_port="$PORT_TROJAN" ;;
        hy) _rp_port="$PORT_HYSTERIA" ;;
    esac
    while $IPT -t nat -D OUTPUT -p tcp \
        -m set --match-set unblockrouter dst \
        -j REDIRECT --to-port "$_rp_port" >/dev/null 2>&1
    do
        :
    done
done
case "$_rp" in
    vl) _rp_port="$PORT_VLESS" ;;
    tr) _rp_port="$PORT_TROJAN" ;;
    hy) _rp_port="$PORT_HYSTERIA" ;;
esac
if ! $IPT -t nat -C OUTPUT -p tcp \
    -m set --match-set unblockrouter dst \
    -j REDIRECT --to-port "$_rp_port" >/dev/null 2>&1
then
    _rp_err="$($IPT -t nat -A OUTPUT -p tcp \
        -m set --match-set unblockrouter dst \
        -j REDIRECT --to-port "$_rp_port" 2>&1)" \
        || hook_error "router TCP REDIRECT add failed: $_rp/$_rp_port: $_rp_err"
fi

# UDP роутера ранее уходил в ss-redir (PORT_SS) — это противоречило
# требованию "bot.txt только через xray". Снимаем такое правило.
while $IPT -t nat -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst \
    -j REDIRECT --to-port "$PORT_SS" >/dev/null 2>&1
do
    :
done

# nat/REDIRECT для UDP непригоден: xray не восстановит исходный адрес
# назначения. Локальный UDP заворачивается меткой в таблицу 100 (local
# default dev lo), после чего пакет проходит PREROUTING и попадает в
# TPROXY-инбаунд vless-udp-tproxy — тот же путь, что и у UDP из LAN.
while $IPT -t nat -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst \
    -j REDIRECT --to-port "$PORT_VLESS" >/dev/null 2>&1
do
    :
done

fi

if [ "$_tbl_sys" = 1 ]; then
_rp="$ROUTER_EFFECTIVE"
# Сначала снимаем обе взаимоисключающие формы. Для vl/hy UDP маркируется
# и возвращается через lo к TPROXY; у TCP-only trojan он явно блокируется,
# а не уходит напрямую.
while $IPT -t mangle -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst \
    -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" >/dev/null 2>&1
do
    :
done
while $IPT -t mangle -D OUTPUT -p udp \
    -m set --match-set unblockrouter dst -j DROP >/dev/null 2>&1
do
    :
done
if [ "$_rp" = "tr" ]; then
    _rp_err="$($IPT -t mangle -A OUTPUT -p udp \
        -m set --match-set unblockrouter dst -j DROP 2>&1)" \
        || hook_error "router UDP fail-closed DROP add failed: $_rp_err"
else
    _rp_err="$($IPT -t mangle -A OUTPUT -p udp \
        -m set --match-set unblockrouter dst \
        -j MARK --set-mark "${TPROXY_MARK}/${TPROXY_MASK}" 2>&1)" \
        || hook_error "MARK(OUTPUT udp) add failed: $_rp_err"
fi

fi

# ═════════════════════════════════════════════════════════════════════════
# 7. VPN-интерфейсы прошивки: ipset -> fwmark -> policy routing
# ═════════════════════════════════════════════════════════════════════════
if [ "$_tbl_sys" = 1 ]; then

# При отключении интерфейса нельзя оставлять старые MARK/CONNMARK-правила:
# они отправляют новый трафик в уже неработающую policy table.
vpn_del_mark_rules() {
    _vd_set="$1"
    _vd_mark="$2"

    for _vd_proto in tcp udp; do
        while $IPT -t mangle -D PREROUTING -p "$_vd_proto" \
            -m set --match-set "$_vd_set" dst \
            -j MARK --set-mark "$_vd_mark" >/dev/null 2>&1
        do
            :
        done
    done

    while $IPT -t mangle -D PREROUTING \
        -m conntrack --ctstate NEW \
        -m set --match-set "$_vd_set" dst \
        -j CONNMARK --set-mark "$_vd_mark" >/dev/null 2>&1
    do
        :
    done
}

# Копия common.sh:vpn_set_name_from_file (F1, аудит rev3) — текст
# обязан совпадать с common.sh; NDM-хук держит локальную копию,
# чтобы работать автономно, без sourcing общей библиотеки.
vpn_set_name_from_file() {
    _vsn="${1##*/}"
    _vsn="${_vsn%.txt}"
    _vsn="unblock${_vsn}"
    if [ "${#_vsn}" -gt 27 ]; then
        _vsn="$(printf '%s' "$_vsn" | cut -c1-27)"
    fi
    printf '%s\n' "$_vsn"
}

# F5 (аудит rev4 #9): манифест соответствия «набор ↔ fwmark ↔ iface».
# Каждый прогон хука пересобирает его целиком (nat- и mangle-запуски
# пишут идентичное содержимое): updater при постпроверке требует
# уже не «любой MARK-тип правила», а конкретную метку набора. Файл
# — реестр ТОЛЬКО интерфейсов в состоянии up: для down-интерфейса
# правил нет и проверять его набор по манифесту не нужно (legacy-
# эвристика остаётся запасным контуром для «чужих» наборов).
_vpn_map_tmp="/tmp/vpn-route-map.$$"
: > "$_vpn_map_tmp"

for vpn_file_name in /opt/etc/unblock/vpn-*.txt; do
    [ -f "$vpn_file_name" ] || continue

    vpn_unblock_name="$(basename "$vpn_file_name" .txt)"
    unblockvpn="$(vpn_set_name_from_file "$vpn_file_name")"
    # M2/F1: ID интерфейса берём из последнего сегмента basename;
    # hash-имена (vpn-<имя>-h<cksum>) его не содержат — читаем sidecar,
    # который vpn-хук записал рядом с файлом списка.
    _sid="/opt/etc/unblock/.${vpn_unblock_name}.iface"
    if [ -f "$_sid" ]; then
        vpn_type="$(sed -n '1p' "$_sid" 2>/dev/null)"
    else
        # F4 (аудит rev4 #3): fallback-парсинг — из ПОЛНОГО basename,
        # а не из $unblockvpn: тот уже усечён до 27 символов законом
        # имён (F1), и последний сегмент <id интерфейса> при усечении
        # теряется — раньше «id» брался из середины имени, и правила
        # вешались на несуществующую таблицу.
        vpn_type="$(printf '%s\n' "$vpn_unblock_name" | sed 's/-/ /g' | awk '{print $NF}')"
    fi
    [ -n "$vpn_type" ] || continue

    vpn_type_lower="$(printf '%s' "$vpn_type" | tr '[:upper:]' '[:lower:]')"
    vpn_table_id="$(grep -w "$vpn_type_lower" /opt/etc/iproute2/rt_tables 2>/dev/null \
        | awk '{print $1}' | head -n1 || true)"
    [ -n "$vpn_table_id" ] || continue
    vpn_mark_id="0xd${vpn_table_id}"

    vpn_link_up="$(curl -s --max-time 5 \
        "localhost:79/rci/show/interface/${vpn_type}/link" 2>/dev/null \
        | tr -d '"' || true)"

    if [ "$vpn_link_up" != "up" ]; then
        vpn_del_mark_rules "$unblockvpn" "$vpn_mark_id"
        ip -4 rule del from all table "$vpn_table_id" priority 1778 \
            >/dev/null 2>&1 || true
        ip -4 rule del fwmark "$vpn_mark_id" lookup "$vpn_table_id" \
            priority 1778 >/dev/null 2>&1 || true
        ip -4 route flush table "$vpn_table_id" >/dev/null 2>&1 || true
        ipset flush "$unblockvpn" >/dev/null 2>&1 || true
        continue
    fi

    ensure_set "$unblockvpn"

    fastnat="$(curl -s --max-time 5 localhost:79/rci/show/version 2>/dev/null | grep ppe || true)"
    software="$(curl -s --max-time 5 localhost:79/rci/show/rc/ppe 2>/dev/null \
        | grep software -C1 | head -1 | awk '{print $2}' | tr -d ',' || true)"
    hardware="$(curl -s --max-time 5 localhost:79/rci/show/rc/ppe 2>/dev/null \
        | grep hardware -C1 | head -1 | awk '{print $2}' | tr -d ',' || true)"

    if [ -z "$fastnat" ] && [ "$software" = "false" ] && [ "$hardware" = "false" ]; then
        for proto in tcp udp; do
            if ! $IPT -t mangle -C PREROUTING -p "$proto" \
                -m set --match-set "$unblockvpn" dst \
                -j MARK --set-mark "$vpn_mark_id" >/dev/null 2>&1
            then
                $IPT -t mangle -A PREROUTING -p "$proto" \
                    -m set --match-set "$unblockvpn" dst \
                    -j MARK --set-mark "$vpn_mark_id" >/dev/null 2>&1 || true
            fi
        done
    else
        if ! $IPT -t mangle -C PREROUTING \
            -m conntrack --ctstate NEW \
            -m set --match-set "$unblockvpn" dst \
            -j CONNMARK --set-mark "$vpn_mark_id" >/dev/null 2>&1
        then
            $IPT -t mangle -A PREROUTING \
                -m conntrack --ctstate NEW \
                -m set --match-set "$unblockvpn" dst \
                -j CONNMARK --set-mark "$vpn_mark_id" >/dev/null 2>&1 || true
        fi
        if ! $IPT -t mangle -C PREROUTING -j CONNMARK --restore-mark >/dev/null 2>&1; then
            $IPT -t mangle -A PREROUTING -j CONNMARK --restore-mark >/dev/null 2>&1 || true
        fi
    fi

    # Строка манифеста: набор, метка, таблица, логическое имя iface.
    printf '%s %s %s %s\n' "$unblockvpn" "$vpn_mark_id" "$vpn_table_id" \
        "$vpn_type" >> "$_vpn_map_tmp" 2>/dev/null || true

    # Успешная обработка VPN-интерфейса не логируется: хук срабатывает на
    # каждое изменение состояния, и такие записи быстро раздували файл.
    # В лог попадают только ошибки.
done

mv -f "$_vpn_map_tmp" /opt/etc/unblock/vpn-route-map 2>/dev/null \
    || rm -f "$_vpn_map_tmp"
fi

hook_finish
exit $?
