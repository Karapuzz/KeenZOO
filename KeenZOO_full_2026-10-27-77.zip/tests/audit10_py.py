#!/usr/bin/env python3
"""audit10_py.py — приёмочные тесты R39-4 (R38-04): fail-closed ревизия
procfs. Внешний harness (не часть проекта)."""
import ast
import io
import os
import shutil
import sys
import tempfile
import logging
import threading
import json
import time
import signal
import subprocess

SRC = '/home/user/KeenZOO/opt/etc/bot/generator.py'
NEEDED = ['_bg_group_executable', '_bg_stop_child']
NEEDED_ASSIGNS = ['_BG_SYNC']

src_text = io.open(SRC, encoding='utf-8').read()
tree = ast.parse(src_text)
seg = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in NEEDED:
        seg[node.name] = ast.get_source_segment(src_text, node)
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id in NEEDED_ASSIGNS:
                seg[t.id] = ast.get_source_segment(src_text, node)
missing = [n for n in NEEDED + NEEDED_ASSIGNS if n not in seg]
assert not missing, f"не извлечены: {missing}"

def make_ns():
    ns = {'os': os, 'sys': sys, 'time': time, 'signal': signal,
          'logging': logging, 'threading': threading, 'json': json,
          'subprocess': subprocess, 'shutil': shutil}
    exec(seg['_BG_SYNC'], ns)
    for f in NEEDED:
        exec(seg[f], ns)
    return ns

PASS = 0
FAIL = 0
def ok(name):
    global PASS; PASS += 1; print(f"  ✅ {name}")
def bad(name, why=''):
    global FAIL; FAIL += 1; print(f"  ❌ {name} {why}")

W = tempfile.mkdtemp(prefix='a10py_')
ns = make_ns()
P = os.path.join(W, 'proc')

def fake_proc(pgid, pid, state, comm='(proc)'):
    d = os.path.join(P, str(pid))
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, 'stat'), 'w') as f:
        f.write(f'{pid} {comm} {state} 1 {pgid} 1 0 0 0\n')

def fresh():
    shutil.rmtree(P, ignore_errors=True)
    os.makedirs(P)

# ── P1: только зомби → [] ──────────────────────────────────────────────
fresh(); fake_proc(4242, 101, 'Z'); fake_proc(4242, 102, 'Z'); fake_proc(7, 201, 'R')
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P1 зомби-группа → []') if r == [] else bad('P1', repr(r))

# ── P2: R-член → в списке ──────────────────────────────────────────────
fresh(); fake_proc(4242, 101, 'R')
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P2 R-член → [101:R]') if r == ['101:R'] else bad('P2', repr(r))

# ── P3: stat нечитаем (это каталог → иная OSError, не ENOENT) → None ──
fresh(); fake_proc(4242, 101, 'R')
os.remove(os.path.join(P, '101', 'stat'))
os.mkdir(os.path.join(P, '101', 'stat'))      # open() даст errno EISDIR
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P3 нечитаемый stat (EISDIR) → None (fail-closed)') if r is None else bad('P3', repr(r))

# ── P4: мусорный stat без ')' → None ───────────────────────────────────
fresh()
os.makedirs(os.path.join(P, '103'))
with open(os.path.join(P, '103', 'stat'), 'w') as f:
    f.write('garbage without paren\n')
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P4 stat без скобки → None') if r is None else bad('P4', repr(r))

# ── P5: полей меньше трёх → None ───────────────────────────────────────
fresh()
os.makedirs(os.path.join(P, '104'))
with open(os.path.join(P, '104', 'stat'), 'w') as f:
    f.write('104 (proc) R 1\n')               # только 3 поля после )
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P5 короткий stat → None') if r is None else bad('P5', repr(r))

# ── P6: pgrp не число → None ───────────────────────────────────────────
fresh()
os.makedirs(os.path.join(P, '105'))
with open(os.path.join(P, '105', 'stat'), 'w') as f:
    f.write('105 (proc) R 1 notanumber 1\n')
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P6 pgrp не число → None') if r is None else bad('P6', repr(r))

# ── P7: исчезнувший PID (битая ссылка → ENOENT) — допустимая гонка ────
fresh(); fake_proc(4242, 101, 'Z')
os.symlink(os.path.join(W, 'no_such_target'),
           os.path.join(P, '106'))             # digit-имя, stat не читается
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P7 ENOENT (гонка исчезновения) → не None, [] ') if r == [] else bad('P7', repr(r))

# ── P8: Z + R + мусор → None (любое unknown топит подтверждение) ───────
fresh(); fake_proc(4242, 101, 'Z'); fake_proc(4242, 102, 'R')
os.makedirs(os.path.join(P, '107'))
with open(os.path.join(P, '107', 'stat'), 'w') as f:
    f.write('bad\n')
r = ns['_bg_group_executable'](4242, procfs=P)
ok('P8 смешанная группа с мусором → None') if r is None else bad('P8', repr(r))

# ── P9: корень procfs недоступен → None ────────────────────────────────
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'no_proc'))
ok('P9 корень /proc недоступен → None') if r is None else bad('P9', repr(r))

# ── P10: коммутация с недоступным _bg_stop_child → False ───────────────
class Proc10:
    pid = 4242
    def wait(self, timeout=None):
        return 0
class OSProxy10:
    def __init__(self, real):
        self._real = real
    def __getattr__(self, name):
        return getattr(self._real, name)
    def killpg(self, pgid, sig):
        return 0
ns10 = make_ns()
ns10['os'] = OSProxy10(os)
ns10['_bg_group_executable'] = lambda pgid, procfs='/proc': None
r = ns10['_bg_stop_child'](Proc10())
ok('P10 скан недоступен → остановка НЕ подтверждена') if r is False else bad('P10', repr(r))

# ── P11: реальная TERM-игнорирующая группа → True ──────────────────────
proc = subprocess.Popen(
    ['sh', '-c', 'trap "" TERM; sleep 30'],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    start_new_session=True, stdin=subprocess.DEVNULL)
time.sleep(0.3)
r = ns['_bg_stop_child'](proc)
ok('P11 реальная группа остановлена') if (r is True and proc.poll() is not None) \
    else bad('P11', f'r={r} poll={proc.poll()}')

shutil.rmtree(W, ignore_errors=True)
print("════════════════════════════════════════")
print(f"ИТОГ audit10_py: PASS={PASS} FAIL={FAIL}")
sys.exit(0 if FAIL == 0 else 1)
