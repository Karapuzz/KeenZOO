#!/bin/bash
# f41_tpl.sh — приёмочный стенд правки R41-1 (аудит-11, M-1):
# дефолтные конфиги из шаблонов рендерятся БЕЗ задвоенных значений
# (провал профильного case в общий fallback давал example.comexample.com,
# 443443, 8388443, tcp443). Извлекает РЕАЛЬНЫЕ функции из дерева.
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f41tpl
rm -rf "$F"; mkdir -p "$F/out"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

sed -n '/^tpl_default()/,/^}/p' "$K/opt/bin/deploy_bypass.sh" > "$F/funcs.s"
sed -n '/^gen_config_from_template()/,/^}/p' "$K/opt/bin/deploy_bypass.sh" >> "$F/funcs.s"
sh -n "$F/funcs.s" || { echo "FATAL: синтаксис извлечённых функций"; exit 1; }

render(){ ( . "$F/funcs.s"; gen_config_from_template "$1" "$2" "$3" ); }

T="$K/opt/etc/bot/templates"
declare -A TPL=( [hysteria]="$T/hysteria_template.json" [vless]="$T/vless_template.json"
                 [trojan]="$T/trojan_template.json" [shadowsocks]="$T/shadowsocks_template.json"
                 [torrc]="$T/tor_template.torrc" )
declare -A OUT=( [hysteria]=hysteria.json [vless]=vless.json [trojan]=trojan.json
                 [shadowsocks]=shadowsocks.json [torrc]=torrc )

# 1) рендер всех пяти шаблонов + отсутствие задвоений
for kind in hysteria vless trojan shadowsocks torrc; do
    out="$F/out/${OUT[$kind]}"
    render "${TPL[$kind]}" "$out" "$kind" >/dev/null 2>&1
    if [ -f "$out" ]; then ok "рендер $kind: файл создан"; else bad "рендер $kind: файл НЕ создан"; continue; fi
    if grep -qE 'example\.comexample\.com|CHANGE_MECHANGE_ME|443443|8388443|tcp443' "$out"; then
        bad "$kind: задвоенные значения в рендере"
    else
        ok "$kind: задвоений нет"
    fi
done

# 2) JSON-валидность четырёх конфигов
for kind in hysteria vless trojan shadowsocks; do
    if python3 -m json.tool "$F/out/${OUT[$kind]}" >/dev/null 2>&1; then
        ok "$kind: валидный JSON"
    else
        bad "$kind: битый JSON"
    fi
done

# 3) контрольные значения заглушек
grep -q '"server": "example.com:443"' "$F/out/hysteria.json" \
    && ok "hysteria server=example.com:443 (одиночные)" || bad "hysteria server"
grep -qE '"address": *"example.com"' "$F/out/vless.json" \
    && ok "vless address=example.com" || bad "vless address"
grep -qE '"server_port": *8388' "$F/out/shadowsocks.json" \
    && ok "shadowsocks server_port=8388" || bad "shadowsocks server_port"
grep -q '"password": \["CHANGE_ME"\]' "$F/out/trojan.json" \
    && ok "trojan password=CHANGE_ME" || bad "trojan password"
grep -q '# Bridge obfs4' "$F/out/torrc" && ok "torrc bridges-заглушка" || bad "torrc bridges"

# 4) tpl_default: точечная семантика (профильные + fallback-ключи)
. "$F/funcs.s"
t(){ v="$(tpl_default "$1" "$2")"; if [ "$v" = "$3" ]; then ok "tpl $1/$2=$3"; else bad "tpl $1/$2=«$v» (ждали «$3»)"; fi; }
t vless transport tcp
t shadowsocks port 8388
t hysteria obfs_password CHANGE_ME
t hysteria localporthysteria 10830
t vless id 00000000-0000-0000-0000-000000000000
t trojan remote_addr 127.0.0.1
t torrc bridges '# Bridge obfs4 IP:PORT FINGERPRINT cert=... iat-mode=0'

# 5) анти-дубль гейт: шаблон с уже задвоенным литералом — отказ, файл не пишется
sed 's/{{address}}/example.comexample.com/' "$T/vless_template.json" > "$F/vless_bad.json"
render "$F/vless_bad.json" "$F/out/vless_bad.json" vless >/dev/null 2>&1
rc=$?
if [ "$rc" -eq 1 ] && [ ! -f "$F/out/vless_bad.json" ]; then
    ok "анти-дубль гейт: задвоенный рендер отклонён, файл не записан"
else
    bad "анти-дубль гейт пропустил задвоение (rc=$rc)"
fi

echo "═══ F41 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
