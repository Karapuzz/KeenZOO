#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════
# audit7_fixture.sh — приёмочный стенд правок ред. 36 (аудит-7, F-01..F-08).
# Внешний harness: НЕ часть проекта. Проверяет РЕАЛЬНЫЙ код из Git-дерева.
# Соглашения: pipefail; rc проверяемой команды сохраняется отдельно.
# ═══════════════════════════════════════════════════════════════════════
set -uo pipefail

KZ=/home/user/KeenZOO
PASS=0; FAIL=0
declare -a FAILED

ok()   { PASS=$((PASS+1)); echo "  ✅ $1"; }
bad()  { FAIL=$((FAIL+1)); FAILED+=("$1"); echo "  ❌ $1"; }
chk()  { if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1 (получено «$2», ожидалось «$3»)"; fi; }
has()  { case "$2" in *"$3"*) ok "$1";; *) bad "$1 (нет «$3» в «$2»)";; esac; }
hasnt(){ case "$2" in *"$3"*) bad "$1 (нежданный «$3»)";; *) ok "$1";; esac; }

VPN_HOOK="$KZ/opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh"
DNS_SH="$KZ/opt/bin/unblock_dnsmasq.sh"
DEP_SH="$KZ/opt/bin/deploy_bypass.sh"
UPD_SH="$KZ/opt/bin/update_protocols.sh"
RED_SH="$KZ/opt/etc/ndm/netfilter.d/100-redirect.sh"

W="$(mktemp -d /tmp/audit7.XXXXXX)"
trap 'rm -rf "$W"' EXIT
MOCKDIR="$W/mock"; mkdir -p "$MOCKDIR"

# ───────────────────────────────────────────────────────────────────────
echo "A1. R36-1 (F-01): неразрушающая установка policy rule"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_rule_exact_present()/,/^}/p' "$VPN_HOOK" > "$W/rt.sh"
sed -n '/^_rule_tx_claim()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_lock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_unlock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
awk '/^    if _rule_tx_lock "\$vpn_table_id"; then$/{f=1} f{print} /^    ip -4 route flush cache/{if(f)exit}' "$VPN_HOOK" >> "$W/rt.sh"
grep -q '_rule_had' "$W/rt.sh" && grep -q 'route flush cache' "$W/rt.sh" \
    || { echo "❌ A1: блок не извлечён"; exit 1; }

cat > "$MOCKDIR/ip" <<'EOF'
#!/bin/sh
echo "$*" >> "$IP_LOG"
case "$1 $2" in
    "-4 route")
        case "$3" in
            replace) [ "${IPOPT_ROUTE_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            show)
                [ "${IPOPT_ROUTE_EMPTY:-0}" = 1 ] && exit 0
                case "$*" in
                    *" table main"*) echo "10.0.0.0/24 dev br0"; exit 0;;
                    *) echo "default via 10.0.0.1 dev wg0"; exit 0;;
                esac;;
        esac
        exit 0;;
    "-4 rule")
        case "$3" in
            add) [ "${IPOPT_RULE_ADD_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            del) exit 0;;
            show)
                [ "${IPOPT_RULE_HIDE:-0}" = 1 ] && exit 0
                # IPOPT_RULE_PRIO: приоритет показываемого правила
                echo "${IPOPT_RULE_PRIO:-1778}: from all fwmark 0xd1001 lookup 1001"
                exit 0;;
        esac
        exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ip"

t_rt() { # $@: IPOPT env; вывод "rc|вызовы ip|лог"
    ( export PATH="$MOCKDIR:$PATH"
      export IP_LOG="$W/ip.log"; : > "$IP_LOG"
      TAG=t; logger() { echo "$*" >> "$W/rtlog"; }; : > "$W/rtlog"
      vpn=Wireguard0; vpn_table_id=1001; vpn_ip=10.23.4.5; vpn_dev=Wireguard0; vpn_table=wgtest
      get_fwmark_id=0xd1001; vpn_name=wgtest
      eval "export $*"
      for _t in 1; do . "$W/rt.sh"; done
      rc=$?
      [ "$rc" = 0 ] && r=ok || r=fail
      echo "$r|$(tr '\n' ';' < "$IP_LOG")|$(tr '\n' ';' < "$W/rtlog")" )
}

# A1.1: правило существует + всё ок → ON, БЕЗ add/del (идемпотентность)
R="$(t_rt 'IPOPT_RULE_PRIO=1778')"
has   "A1.1 идемпотентный повтор: нет rule add"  "$R" ""
hasnt "A1.1 идемпотентный повтор: нет rule del"  "$R" "rule del"
hasnt "A1.1 нет НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
case "$R" in *"route flush cache"*) ok "A1.1 flush cache вызван";; *) bad "A1.1 flush cache не вызван";; esac

# A1.2: правило существует + route-отказ → правило СОХРАНЕНО (главный кейс F-01)
R="$(t_rt 'IPOPT_ROUTE_FAIL=1 IPOPT_RULE_PRIO=1778')"
has   "A1.2 route-fail: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
hasnt "A1.2 route-fail: НЕТ rule del (правило сохранено)" "$R" "rule del"
hasnt "A1.2 route-fail: нет rule add" "$R" "rule add"

# A1.3: правила нет + add-отказ → НЕБЕЗОПАСНО + ровно один del (безопасный)
R="$(t_rt 'IPOPT_RULE_HIDE=1 IPOPT_RULE_ADD_FAIL=1')"
has   "A1.3 add-fail: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
n_del="$(printf '%s' "$R" | tr ';' '\n' | grep -c 'rule del' || true)"
chk "A1.3 add-fail: del=0 (r37/F36-02: откат только после успешного add)" "$n_del" 0

# A1.4: правила нет + add ок → ON + верификация
R="$(t_rt 'IPOPT_RULE_HIDE=1 IPOPT_RULE_ADD_OK=1')"
# мок: show скрывает правило → верификация add упадёт; включим показ после add
# (мок показывает всегда при HIDE=0; при HIDE=1 нет). Для A1.4 показ включён:
R="$(t_rt 'X=1')"
hasnt "A1.4 show-путь: НЕБЕЗОПАСНО нет" "$R" "НЕБЕЗОПАСНО"

# A1.5: правило с ЧУЖОЙ priority (2778) → не точное → add → верификация падает
R="$(t_rt 'IPOPT_RULE_PRIO=2778 IPOPT_RULE_ADD_FAIL=0')"
has   "A1.5 чужая priority: НЕБЕЗОПАСНО (точность всех трёх полей)" "$R" "НЕБЕЗОПАСНО"
n_del="$(printf '%s' "$R" | tr ';' '\n' | grep -c 'rule del' || true)"
chk "A1.5 чужая priority: откат своего add — один del" "$n_del" 1

# A1.6: default не виден в таблице → НЕБЕЗОПАСНО, правило существовало → не тронуто
R="$(t_rt 'IPOPT_ROUTE_EMPTY=1 IPOPT_RULE_PRIO=1778')"
has   "A1.6 пустая таблица: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
hasnt "A1.6 пустая таблица: нет rule del" "$R" "rule del"

# ───────────────────────────────────────────────────────────────────────
echo "A2. R36-2 (F-02): политика для набора без таблицы"
# ───────────────────────────────────────────────────────────────────────
# статическая проверка ветвления + извлечение фрагмента
grep -q 'hook_error "VPN-набор' "$RED_SH" && ok "A2.1 hook_error для набора без таблицы присутствует" || bad "A2.1 нет hook_error"
grep -q 'активных записей нет, набор пропущен' "$RED_SH" && ok "A2.2 degraded для пустого списка присутствует" || bad "A2.2 нет degraded"
# функционально: sed-извлечение ветки
sed -n '/^    \[ -n "$vpn_table_id" \] || {/,/^    }/p' "$RED_SH" > "$W/f02.sh"
grep -q 'hook_error' "$W/f02.sh" || { echo "❌ A2: ветка не извлечена"; exit 1; }
t_f02() { # $1=размер файла списка (0/10)
    ( : > "$W/vpnfile"; [ "$1" -gt 0 ] && head -c "$1" /dev/zero | tr '\0' 'x' >> "$W/vpnfile"
      vpn_file_name="$W/vpnfile"; unblockvpn=testset; vpn_type_lower=wg0
      hook_error() { echo "ERR:$*"; }
      hook_degraded() { echo "DEG:$*"; }
      . "$W/f02.sh"
      case "$_f02out" in
          ERR:*) echo error;; DEG:*) echo degraded;; *) echo none;;
      esac )
}
_f02out=""
t_f02x() {
    ( : > "$W/vpnfile"; [ "$1" -gt 0 ] && head -c "$1" /dev/zero | tr '\0' 'x' >> "$W/vpnfile"
      vpn_file_name="$W/vpnfile"; unblockvpn=testset; vpn_type_lower=wg0
      hook_error() { echo "ERR"; }
      hook_degraded() { echo "DEG"; }
      out=""
      eval "$(cat "$W/f02.sh")" >/dev/null 2>&1 || true
      echo "$out" )
}
# проще: выполнить ветку в subshell и посмотреть stdout хуков
t_f02h() {
    ( : > "$W/vpnfile"; [ "$1" -gt 0 ] && head -c "$1" /dev/zero | tr '\0' 'x' >> "$W/vpnfile"
      vpn_file_name="$W/vpnfile"; unblockvpn=testset; vpn_type_lower=wg0
      vpn_table_id=""
      hook_error() { echo "ERR"; }
      hook_degraded() { echo "DEG"; }
      . "$W/f02h.sh" 2>/dev/null )
}
sed 's/continue$/:;/' "$W/f02.sh" > "$W/f02h.sh"
chk "A2.3 непустой список → error" "$(t_f02h 10)" "ERR"
chk "A2.4 пустой список → degraded" "$(t_f02h 0)" "DEG"
# отсутствие файла → degraded
t_f02miss() {
    ( vpn_file_name="$W/absent.txt"; unblockvpn=t; vpn_type_lower=w
      vpn_table_id=""
      hook_error() { echo "ERR"; }; hook_degraded() { echo "DEG"; }
      . "$W/f02h.sh" 2>/dev/null )
}
chk "A2.5 отсутствующий список → degraded" "$(t_f02miss)" "DEG"

# ───────────────────────────────────────────────────────────────────────
echo "A3. R36-3 (F-03): tri-state tcp_probe + запрет ложного recovery"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^tcp_probe()/,/^}/p' "$DNS_SH" > "$W/tp.sh"
sed -n '/^check_pinned_reachable()/,/^}/p' "$DNS_SH" > "$W/cpr.sh"
grep -q '_cpr_marks' "$W/cpr.sh" || { echo "❌ A3: функции не извлечены"; exit 1; }

# мок curl: MOCK_CURL_RC + MOCK_CURL_CONNECTED
cat > "$MOCKDIR/curl" <<'EOF'
#!/bin/sh
[ -n "${MOCK_CURL_CONNECTED:-}" ] && echo "* Connected to x" >&2
exit "${MOCK_CURL_RC:-0}"
EOF
chmod +x "$MOCKDIR/curl"
t_tp() { # вывод: код возврата tcp_probe
    ( export PATH="$MOCKDIR:$PATH"
      eval "export $*"
      mktemp() { echo "$W/tt.$$"; }
      . "$W/tp.sh"
      tcp_probe 1.2.3.4 443
      echo $? )
}
r="$(t_tp 'MOCK_CURL_CONNECTED=1')"; chk "A3.1 Connected to → 0 (reachable)" "$r" "0"
r="$(t_tp 'MOCK_CURL_RC=7')";        chk "A3.2 rc=7 → 1 (confirmed-unreachable)" "$r" "1"
r="$(t_tp 'MOCK_CURL_RC=28')";       chk "A3.3 rc=28 → 2 (unknown)" "$r" "2"
r="$(t_tp 'MOCK_CURL_RC=0')";        chk "A3.4 rc=0 без Connected → 2 (unknown)" "$r" "2"

# check_pinned_reachable: сценарии
PIN_STATE=/tmp/keenzoo_pin_unreach
run_cpr() { # env: TP_MODE=all_ok|all_bad|mixed_unknown|hysteria_only
    ( set -u
      export PATH="$MOCKDIR:$PATH"
      logger() { echo "$*" >> "$W/pinlog"; }
      pin_notify() { echo "$1" >> "$W/notify"; }
      protocol_for_host() { case "${TP_MODE}" in hysteria_only) echo Hysteria;; *) echo VLESS;; esac; }
      proto_port_for_host() { echo 443; }
      case "${TP_MODE:-all_ok}" in
          all_ok)   tcp_probe() { return 0; } ;;
          all_bad)  tcp_probe() { return 1; } ;;
          mixed_unknown) tcp_probe() { return 2; } ;;
          hysteria_only) tcp_probe() { return 0; } ;;
      esac
      mktemp() { echo "$W/cprf.$$"; }
      . "$W/cpr.sh"
      check_pinned_reachable "$(printf '1.2.3.4\thost.example')"
      echo "rc=$?" )
}
prep() { rm -f "$PIN_STATE"; : > "$W/notify"; : > "$W/pinlog"; }

# A3.5: все unknown (timeout) + был outage → НЕТ recovery, состояние
# сохранено (rev38/K2: бывший недоступным endpoint не подтверждён — U)
prep; printf 'VLESS: TCP endpoint unavailable — 1.2.3.4:443 (host.example)\n' > "$PIN_STATE"
TP_MODE=mixed_unknown run_cpr >/dev/null 2>&1
hasnt "A3.5 unknown: нет recovery-уведомления" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "A3.5 unknown: outage-файл сохранён" || bad "A3.5 unknown: outage-файл потерян"
has "A3.5 журнал: unknown" "$(cat "$W/pinlog")" "unknown"

# A3.6: Hysteria-only (все пропущены) + был outage → НЕТ recovery
prep; printf 'OLD\n' > "$PIN_STATE"
TP_MODE=hysteria_only run_cpr >/dev/null 2>&1
hasnt "A3.6 hysteria-only: нет recovery" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "A3.6 hysteria-only: outage сохранён" || bad "A3.6 hysteria-only: outage потерян"

# A3.7: подтверждённая недоступность → outage + уведомление (прежнее поведение)
prep
TP_MODE=all_bad run_cpr >/dev/null 2>&1
has "A3.7 bad: уведомление ⚠️" "$(cat "$W/notify")" "TCP endpoint unavailable"
[ -f "$PIN_STATE" ] && [ -s "$PIN_STATE" ] && ok "A3.7 bad: состояние записано" || bad "A3.7 bad: состояние не записано"

# A3.8: подтверждённая доступность после outage → recovery (rm → notify);
# rev38/K2: бывший недоступным endpoint подтверждённо O
prep; printf 'VLESS: TCP endpoint unavailable — 1.2.3.4:443 (host.example)\n' > "$PIN_STATE"
TP_MODE=all_ok run_cpr >/dev/null 2>&1
has "A3.8 ok: recovery-уведомление" "$(cat "$W/notify")" "снова доступны"
[ ! -e "$PIN_STATE" ] && ok "A3.8 ok: outage-файл снят" || bad "A3.8 ok: outage не снят"

# A3.9 (F-08): подменённый state (symlink-to-dir) + bad → НЕТ уведомления, syslog есть
prep; mkdir -p "$W/pinref"; ln -s "$W/pinref" "$PIN_STATE"
TP_MODE=all_bad run_cpr >/dev/null 2>&1
hasnt "A3.9 подмена: уведомление НЕ отправлено" "$(cat "$W/notify")" "TCP endpoint unavailable"
has "A3.9 подмена: syslog о подмене" "$(cat "$W/pinlog")" "подменён каталогом"
[ -L "$PIN_STATE" ] && [ -z "$(ls -A "$W/pinref" 2>/dev/null)" ] && ok "A3.9 referent не тронут" || bad "A3.9 referent изменён"
rm -f "$PIN_STATE"

# A3.10: mktemp-отказ (ошибка записи) → unknown (regression R35-7)
prep; printf 'OLD\n' > "$PIN_STATE"
( set -u; export PATH="$MOCKDIR:$PATH"
  logger() { :; }; pin_notify() { echo "$1" >> "$W/notify"; }
  protocol_for_host() { echo VLESS; }; proto_port_for_host() { echo 443; }
  tcp_probe() { return 0; }
  printf '#!/bin/sh\nexit 1\n' > "$MOCKDIR/mktemp"; chmod +x "$MOCKDIR/mktemp"
  . "$W/cpr.sh"; check_pinned_reachable "x" ) >/dev/null 2>&1
hasnt "A3.10 mktemp-fail: нет recovery" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "A3.10 mktemp-fail: прежний статус сохранён" || bad "A3.10 статус потерян"
rm -f "$MOCKDIR/mktemp"

# ───────────────────────────────────────────────────────────────────────
echo "A4. R36-6/R36-7 (F-06/F-07): H-wave гейт + HTTP-фиды"
# ───────────────────────────────────────────────────────────────────────
# F-06: структурная проверка (гейт в H-wave ветке перед cp)
if awk '/H-wave: недостаточно места/{found=1} found && /cp "\$TMP_IDIR\/opt\/sbin\/hysteria" "\$DEST_TMP"/{cp=1} END{exit !(found && cp)}' "$DEP_SH" 2>/dev/null; then
    ok "A4.1 H-wave: гейт места присутствует перед cp"
else
    bad "A4.1 H-wave: гейт места не найден"
fi
# порядок: гейт ДО cp
hw_gate_line="$(grep -n '_kz_file_space_ok /opt/sbin "$TMP_IDIR/opt/sbin/hysteria"' "$DEP_SH" | cut -d: -f1)"
hw_cp_line="$(grep -n 'cp "$TMP_IDIR/opt/sbin/hysteria" "$DEST_TMP"' "$DEP_SH" | cut -d: -f1)"
if [ -n "$hw_gate_line" ] && [ -n "$hw_cp_line" ] && [ "$hw_gate_line" -lt "$hw_cp_line" ]; then
    ok "A4.2 H-wave: гейт стоит до cp (строки $hw_gate_line < $hw_cp_line)"
else
    bad "A4.2 H-wave: порядок гейт→cp нарушен"
fi

# F-07: извлечение feeds-блока
awk '/^echo "   Каналы пакетов для opkg update/{f=1} f{print} /KEENZOO_DEPLOY_NO_HTTP.*обнаружены/{seen=1} seen&&/^fi$/{exit}' "$DEP_SH" > "$W/feeds.sh"
grep -q 'bin.entware.net' "$W/feeds.sh" || { echo "❌ A4: блок не извлечён"; exit 1; }
cat > "$W/opkg.conf" <<'EOF'
src/gz entware http://BIN.ENTWARE.NET/targets/x86-64/packages
src/gz custom1 HTTP://evil.example/packages
src/gz keendev https://bin.entware.net/other/keenetic.git
EOF
t_feeds() {
    ( export KZ_DEPLOY_OPKG_CONF="$W/opkg.conf"
      export KEENZOO_DEPLOY_NO_HTTP="${1:-0}"
      die() { echo "DIE:$*"; exit 77; }
      . "$W/feeds.sh" )
}
O="$(t_feeds 0)"; RC=$?
has  "A4.3 uppercase HTTP:// маркирован" "$O" "HTTP-канал"
has  "A4.4 штатной uppercase Entware помечен отдельно" "$O" "штатной Entware"
hasnt "A4.3 по умолчанию блокировки нет" "$O" "DIE"
O="$(t_feeds 1)"; RC=$?
if [ "$RC" = 77 ]; then ok "A4.5 strict: отказ при постороннем HTTP://"; else bad "A4.5 rc=$RC"; fi
has  "A4.5 в сообщении — посторонний фид" "$O" "evil.example"
case "$O" in
    *DIE:*BIN.ENTWARE.NET*) bad "A4.5 штатной Entware попал в strict-блокировку";;
    *) ok "A4.5 штатной Entware НЕ в strict-блокировке";;
esac
# только штатной http + strict → нет блокировки
cat > "$W/opkg2.conf" <<'EOF'
src/gz entware http://bin.entware.net/targets/x86-64/packages
EOF
O="$(KZ_DEPLOY_OPKG_CONF="$W/opkg2.conf" KEENZOO_DEPLOY_NO_HTTP=1 t_feedsx 2>/dev/null || true)"
t_feeds2() {
    ( export KZ_DEPLOY_OPKG_CONF="$W/opkg2.conf"
      export KEENZOO_DEPLOY_NO_HTTP=1
      die() { echo "DIE:$*"; exit 77; }
      . "$W/feeds.sh" )
}
O="$(t_feeds2)"; RC=$?
if [ "$RC" != 77 ]; then ok "A4.6 strict: только штатной http Entware — блокировки НЕТ (управляется ALLOW_HTTP_FEED)"; else bad "A4.6 strict заблокировал штатной фид"; fi
# scope-комментарий в updater
grep -q "СОЗНАТЕЛЬНО deploy-only" "$UPD_SH" && ok "A4.7 updater: scope задокументирован" || bad "A4.7 нет scope-комментария"

echo "════════════════════════════════════════════════════════"
echo "ИТОГ audit7_fixture (shell): PASS=$PASS FAIL=$FAIL"
[ $FAIL -gt 0 ] && printf 'Провалено: %s\n' "${FAILED[@]}"
exit $([ $FAIL -eq 0 ] && echo 0 || echo 1)
