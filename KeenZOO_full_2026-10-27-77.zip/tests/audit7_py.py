#!/usr/bin/env python3
"""audit7_py.py — приёмочные тесты правок R36-4/R36-5 в generator.py.

Внешний harness (не часть проекта). Функции извлекаются из РЕАЛЬНОГО
generator.py через ast и исполняются в изолированном namespace.
"""
import ast
import io
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import logging
import types
import secrets

SRC = '/home/user/KeenZOO/opt/etc/bot/generator.py'

NEEDED = ['_bg_group_executable', 
    '_bg_check_publish', '_bg_check_unlock', '_bg_still_owner',
    '_bg_stop_child', '_bg_check_wait', '_bg_start_failure',
]
NEEDED_ASSIGNS = ['BG_CHECK_TIMEOUT', '_BG_SYNC']

src_text = io.open(SRC, encoding='utf-8').read()
tree = ast.parse(src_text)
seg = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in NEEDED:
        seg[node.name] = ast.get_source_segment(src_text, node)
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id in NEEDED_ASSIGNS:
                seg[t.id] = ast.get_source_segment(src_text, node)
missing = [n for n in NEEDED + NEEDED_ASSIGNS if n not in seg]
assert not missing, f"не извлечены: {missing}"

def make_ns():
    ns = {
        'os': os, 'sys': sys, 'json': json, 'time': time,
        'shutil': shutil, 'tempfile': tempfile, 'threading': threading,
        'subprocess': subprocess, 'logging': logging, 'signal': signal,
        'secrets': secrets,
    }
    exec(seg['BG_CHECK_TIMEOUT'], ns)
    exec(seg['_BG_SYNC'], ns)
    for f in NEEDED:
        exec(seg[f], ns)
    return ns

PASS = 0
FAIL = 0
def ok(name):
    global PASS; PASS += 1; print(f"  ✅ {name}")
def bad(name, why=''):
    global FAIL; FAIL += 1; print(f"  ❌ {name} {why}")

KIND = 'zztest7'
ST = f'/tmp/keenzoo_bg_{KIND}.json'
LOCK = f'/tmp/keenzoo_bg_{KIND}.lockdir'

def cleanup():
    shutil.rmtree(LOCK, ignore_errors=True)
    try: os.unlink(ST)
    except OSError: pass
    for p in os.listdir('/tmp'):
        if p.startswith(f'keenzoo_bg_{KIND}'):
            try: os.unlink(os.path.join('/tmp', p))
            except OSError:
                shutil.rmtree(os.path.join('/tmp', p), ignore_errors=True)

ns = make_ns()
cleanup()

# ── U1: unlock чужого замка — rename-verify-restore ────────────────────
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write('FOREIGN_TOKEN')
with open(os.path.join(LOCK, 'pid'), 'w') as f:
    f.write('123')
ns['_bg_check_unlock'](LOCK, 'MYTOKEN')
if os.path.isdir(LOCK):
    ok('U1 чужой замок: lockdir возвращён на место')
else:
    bad('U1 чужой замок удалён или потерян')
with open(os.path.join(LOCK, 'token')) as f:
    if f.read().strip() == 'FOREIGN_TOKEN':
        ok('U1 token владельца не тронут')
    else:
        bad('U1 token повреждён')
rel_leftovers = [p for p in os.listdir('/tmp') if p.startswith(f'{LOCK}.rel.')]
if not rel_leftovers:
    ok('U1 мусора .rel.* не осталось')
else:
    bad('U1 остались .rel.*', rel_leftovers)

# ── U2: свой замок — снимается ─────────────────────────────────────────
shutil.rmtree(LOCK, ignore_errors=True)
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write('MYTOKEN')
ns['_bg_check_unlock'](LOCK, 'MYTOKEN')
if not os.path.isdir(LOCK):
    ok('U2 свой замок снят')
else:
    bad('U2 свой замок не снят')

# ── U3: waiter без владения не публикует статус ────────────────────────
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write('OTHER_OWNER')
ns['_bg_check_publish'](KIND, {'status': 'running', 'ts': 1,
                               'message': 'новая задача'})
class ProcDone:
    pid = 4242
    def wait(self):
        return 0
ns['_bg_check_wait'](KIND, ProcDone(), '/tmp/keenzoo_bg_x.log', LOCK, 'MYTOKEN')
d = json.load(open(ST))
if d.get('status') == 'running' and d.get('message') == 'новая задача':
    ok('U3 утраченное владение: финальный статус НЕ опубликован')
else:
    bad('U3 статус перезаписан', repr(d))
if os.path.isdir(LOCK):
    ok('U3 чужой замок не удалён waiter-ом')
else:
    bad('U3 waiter удалил чужой замок')

# ── U4: kill-эскалация при игнорировании SIGTERM (r37: сигналы группе) ─
kills = []
killed = {'flag': False}
def killpg(pgid, sig):
    kills.append((pgid, sig))
    if sig == 0:
        if killed['flag']:
            raise OSError(3, 'No such process')
        return                      # группа «жива»
    if sig == signal.SIGKILL:
        killed['flag'] = True       # SIGKILL безусловен
class StubbornProc:
    pid = 777
    def wait(self, timeout=None):
        if killed['flag']:
            return 0
        raise subprocess.TimeoutExpired(cmd='x', timeout=timeout)
ns4 = make_ns()
ns4['os'] = types.SimpleNamespace(killpg=killpg, rename=os.rename,
                                  path=os.path)
r = ns4['_bg_stop_child'](StubbornProc())
sig_list = [sig for _, sig in kills]
if r is True and signal.SIGKILL in sig_list and sig_list.count(0) >= 1:
    ok('U4 SIGTERM группе проигнорирован → SIGKILL группе, завершение подтверждено')
else:
    bad('U4 эскалация не сработала', f'kills={kills} r={r}')
if sig_list[0] == signal.SIGTERM:
    ok('U4 первым сигналом группа получает SIGTERM (не прямой PID)')
else:
    bad('U4 первый сигнал не SIGTERM группе', sig_list[:1])

# ── U5: процесс умирает от SIGKILL (реалистичный незакоренелый child) ──
shutil.rmtree(LOCK, ignore_errors=True)
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write('MYTOKEN')
log7 = '/tmp/keenzoo_bg_zztest7.U5.log'
with open(log7, 'w') as f:
    f.write('x')
state5 = {'dead': False}
def killpg5(pgid, sig):
    if sig == 0:
        if state5['dead']:
            raise OSError(3, 'No such process')
        return
    if sig == signal.SIGKILL:
        state5['dead'] = True
class Stubborn2Proc:
    pid = 888
    def wait(self, timeout=None):
        if state5['dead']:
            return 0
        raise subprocess.TimeoutExpired(cmd='x', timeout=timeout)
class OSProxy5:
    def __init__(self, real):
        self._real = real
    def __getattr__(self, name):
        return getattr(self._real, name)
    def killpg(self, pgid, sig):
        killpg5(pgid, sig)
ns5 = make_ns()
ns5['os'] = OSProxy5(os)
ns5['_bg_start_failure'](KIND, Stubborn2Proc(), log7, LOCK, 'MYTOKEN',
                         'Не удалось запустить')
d = json.load(open(ST))
if d.get('status') == 'error' and d.get('message') == 'Не удалось запустить':
    ok('U5 SIGKILL-остановка: статус error, без «не подтверждён»')
else:
    bad('U5 сообщение', repr(d.get('message')))
if not os.path.isdir(LOCK):
    ok('U5 замок снят после подтверждённой остановки группы')
else:
    bad('U5 замок не снят')
if not os.path.exists(log7):
    ok('U5 лог удалён после подтверждённой остановки')
else:
    bad('U5 лог не удалён')

# ── U5b: killpg SIGKILL не имеет прав (EPERM) → замок НЕ снимается ────
shutil.rmtree(LOCK, ignore_errors=True)
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write('MYTOKEN')
log7b = '/tmp/keenzoo_bg_zztest7.U5b.log'
with open(log7b, 'w') as f:
    f.write('x')
class EpermProc:
    pid = 889
    def wait(self, timeout=None):
        raise subprocess.TimeoutExpired(cmd='x', timeout=timeout)
class OSProxy5b:
    def __init__(self, real):
        self._real = real
    def __getattr__(self, name):
        return getattr(self._real, name)
    def killpg(self, pgid, sig):
        if sig == 0:
            return                  # группа «жива»
        if sig == signal.SIGKILL:
            raise OSError(1, 'Operation not permitted')
ns5b = make_ns()
ns5b['os'] = OSProxy5b(os)
ns5b['_bg_start_failure'](KIND, EpermProc(), log7b, LOCK, 'MYTOKEN',
                          'Не удалось запустить')
d = json.load(open(ST))
if 'не подтверждён' in d.get('message', ''):
    ok('U5b EPERM: статус честно сообщает неподтверждённую остановку')
else:
    bad('U5b сообщение', repr(d.get('message')))
if os.path.isdir(LOCK):
    ok('U5b EPERM: замок НЕ снят (сериализация сохранена)')
else:
    bad('U5b EPERM: замок снят при живой группе')
if os.path.exists(log7b):
    ok('U5b EPERM: лог не удалён')
else:
    bad('U5b EPERM: лог удалён')
shutil.rmtree(LOCK, ignore_errors=True)

# ── U6: нормальная остановка — proc=None и покорный proc ──────────────
if ns['_bg_stop_child'](None) is True:
    ok('U6 proc=None → подтверждённая остановка')
else:
    bad('U6 proc=None')
class MeekProc:
    pid = 999
    def terminate(self):
        pass
    def wait(self, timeout=None):
        return 0
if ns['_bg_stop_child'](MeekProc()) is True:
    ok('U6 покорный proc → terminate/wait без killpg')
else:
    bad('U6 покорный proc')

cleanup()
os.unlink(log7) if os.path.exists(log7) else None
print("════════════════════════════════════════")
print(f"ИТОГ audit7_py: PASS={PASS} FAIL={FAIL}")
sys.exit(0 if FAIL == 0 else 1)
