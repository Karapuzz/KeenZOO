#!/bin/sh
# audit10_fixture.sh — приёмочные тесты правок R39-1..R39-7 (аудит-10).
# Внешний harness (не часть проекта): извлекает РЕАЛЬНЫЕ фрагменты кода
# release-candidate и исполняет их с моками ip/iptables/ipset/логгера.
set -uo pipefail

W="$(mktemp -d /tmp/a10fix.XXXXXX 2>/dev/null)" || exit 1
MOCKDIR="$W/mock"; mkdir -p "$MOCKDIR"
VPN_HOOK=/home/user/KeenZOO/opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh
DNS_SH=/home/user/KeenZOO/opt/bin/unblock_dnsmasq.sh
RED_SH=/home/user/KeenZOO/opt/etc/ndm/netfilter.d/100-redirect.sh
DEP_SH=/home/user/KeenZOO/opt/bin/deploy_bypass.sh

PASS=0; FAIL=0
ok()  { PASS=$((PASS + 1)); echo "  ✅ $1"; }
bad() { FAIL=$((FAIL + 1)); echo "  ❌ $1 ${2:-}"; }
has()  { printf '%s' "$2" | grep -q -- "$3" && ok "$1" || bad "$1" "«$3» не найден"; }
hasnt(){ printf '%s' "$2" | grep -q -- "$3" && bad "$1" "«$3» найден" || ok "$1"; }
chk() { [ "$2" = "$3" ] && ok "$1" || bad "$1" "$2 ≠ $3"; }
n_of(){ printf '%s' "$1" | tr ';' '\n' | grep -c -- "$2" || true; }

# ═════════════════════════════════════════════════════════════════════
echo "C1. R39-2: семантика priority 1778 (unit)"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_rule_exact_present()/,/^}/p' "$VPN_HOOK" > "$W/m.sh"
grep -q '_rule_exact_present()' "$W/m.sh" \
    || { echo "❌ C1: функция не извлечена"; exit 1; }
cat > "$MOCKDIR/ip" <<'EOF'
#!/bin/sh
case "$1 $2 $3" in
    "-4 rule show") [ -n "${IPOPT_RULE_SHOW:-}" ] && printf '%s\n' "$IPOPT_RULE_SHOW"; exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ip"
mx() {
    ( export PATH="$MOCKDIR:$PATH"
      IPOPT_RULE_SHOW="$1" sh -c '. "$0"; _rule_exact_present 0xd1001 1001 wgtest >/dev/null 2>&1; echo $?' "$W/m.sh" )
}
EXACT="1778: from all fwmark 0xd1001 lookup 1001"
chk "C1.1 каноническое (число) → rc=0"                    "$(mx "$EXACT")" 0
chk "C1.2 каноническое (имя таблицы) → rc=0"              "$(mx "1778: from all fwmark 0xd1001 lookup wgtest")" 0
chk "C1.3 дубликат канона ×2 → rc=0 (дубли безвредны)"    "$(mx "$EXACT
$EXACT")" 0
chk "C1.4 канон + постороннее на 1778 → rc=2 (стоп)"      "$(mx "$EXACT
1778: from all not fwmark 0xd1001 lookup 1001")" 2
chk "C1.5 только mark (наш mark, чужая таблица) → rc=2"   "$(mx "1778: from all fwmark 0xd1001 lookup 999")" 2
chk "C1.6 только таблица (чужой mark) → rc=2"             "$(mx "1778: from all fwmark 0x999 lookup 1001")" 2
chk "C1.7 полностью постороннее на 1778 → rc=2"           "$(mx "1778: from all fwmark 0x999 lookup 999")" 2
chk "C1.8 not fwmark → rc=2"                              "$(mx "1778: from all not fwmark 0xd1001 lookup 1001")" 2
chk "C1.9 from-подсеть → rc=2"                            "$(mx "1778: from 192.0.2.0/24 fwmark 0xd1001 lookup 1001")" 2
chk "C1.10 лишний селектор iif → rc=2"                    "$(mx "1778: from all fwmark 0xd1001 lookup 1001 iif eth0")" 2
chk "C1.11 маска fwmark → rc=2"                           "$(mx "1778: from all fwmark 0xd1001/0xffffff lookup 1001")" 2
chk "C1.12 пустой вывод → rc=1"                           "$(mx "")" 1
chk "C1.13 чужой priority 2778 → rc=1"                    "$(mx "2778: from all fwmark 0xd1001 lookup 1001")" 1

# ═════════════════════════════════════════════════════════════════════
echo "C2. R39-2/R39-3: транзакция — стоп при конфликте, замок, неразрушающий откат"
# ───────────────────────────────────────────────────────────────────────
{ sed -n '/^_rule_exact_present()/,/^}/p' "$VPN_HOOK"
  sed -n '/^_rule_tx_claim()/,/^}/p' "$VPN_HOOK"
  sed -n '/^_rule_tx_lock()/,/^}/p' "$VPN_HOOK"
  sed -n '/^_rule_tx_unlock()/,/^}/p' "$VPN_HOOK"
  awk '/^    if _rule_tx_lock "\$vpn_table_id"; then$/{f=1} f{print} /^    ip -4 route flush cache/{if(f)exit}' "$VPN_HOOK"; } > "$W/rt.sh"
grep -q '_rule_tx_unlock' "$W/rt.sh" && grep -q '_rule_pre_rc' "$W/rt.sh" \
    || { echo "❌ C2: блок не извлечён"; exit 1; }
cat > "$MOCKDIR/ip" <<'EOF'
#!/bin/sh
echo "$*" >> "$IP_LOG"
case "$1 $2" in
    "-4 route")
        case "$3" in
            replace) [ "${IPOPT_ROUTE_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            show)
                case "$*" in
                    *" table main"*) echo "10.0.0.0/24 dev br0"; exit 0;;
                    *) echo "default via 10.0.0.1 dev wg0"; exit 0;;
                esac;;
        esac
        exit 0;;
    "-4 rule")
        case "$3" in
            add) [ "${IPOPT_RULE_ADD_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            del) exit 0;;
            show)
                _n="$(cat "$W/showcnt" 2>/dev/null || echo 0)"
                _n=$((_n + 1)); echo "$_n" > "$W/showcnt"
                if [ -n "${IPOPT_SHOW_SWITCH:-}" ] && [ "$_n" -ge "$IPOPT_SHOW_SWITCH" ]; then
                    [ -n "${IPOPT_RULE_SHOW_LATE:-}" ] && printf '%s\n' "$IPOPT_RULE_SHOW_LATE"
                else
                    [ -n "${IPOPT_RULE_SHOW:-}" ] && printf '%s\n' "$IPOPT_RULE_SHOW"
                fi
                exit 0;;
        esac
        exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ip"
t_rt() {
    ( export PATH="$MOCKDIR:$PATH"
      export IP_LOG="$W/ip.log" W="$W"; : > "$IP_LOG"; echo 0 > "$W/showcnt"
      TAG=t; logger() { echo "$*" >> "$W/rtlog"; }; : > "$W/rtlog"
      vpn=Wireguard0; vpn_table_id=1001; vpn_table=wgtest
      vpn_ip=10.23.4.5; vpn_dev=Wireguard0
      get_fwmark_id=0xd1001; vpn_name=wgtest
      eval "export $*"
      for _t in 1; do . "$W/rt.sh"; done
      rc=$?
      [ "$rc" = 0 ] && r=ok || r=fail
      echo "$r|$(tr '\n' ';' < "$IP_LOG")|$(tr '\n' ';' < "$W/rtlog")" )
}
NOTFW='1778: from all not fwmark 0xd1001 lookup 1001'
EXACT='1778: from all fwmark 0xd1001 lookup 1001'
# C2.1: постороннее правило на 1778 → полная остановка ДО route replace
R="$(t_rt "IPOPT_RULE_SHOW='$NOTFW' IPOPT_RULE_ADD_FAIL=1")"
has  "C2.1 конфликт диагностирован" "$R" "постороннее/конфликтное правило"
has  "C2.1 требуется ручной разбор" "$R" "ip -4 rule show"
chk "C2.1 route replace НЕ выполнялся" "$(n_of "$R" 'route replace')" 0
chk "C2.1 add НЕ выполнялся"          "$(n_of "$R" 'rule add')" 0
chk "C2.1 del НЕ выполнялся"          "$(n_of "$R" 'rule del')" 0
has  "C2.1 НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
[ ! -d /tmp/keenzoo_rule_1001.lockdir ] && ok "C2.1 замок снят при стопе" || bad "C2.1 замок остался"
# C2.2: чистый путь — add+verify успешны, замок снят
R="$(t_rt "IPOPT_RULE_SHOW='' IPOPT_RULE_SHOW_LATE='$EXACT' IPOPT_SHOW_SWITCH=2")"
case "$R" in ok|ok\|*) ok "C2.2 чистый путь: успех";; *) bad "C2.2 сбой: $R";; esac
chk "C2.2 add=1" "$(n_of "$R" 'rule add')" 1
[ ! -d /tmp/keenzoo_rule_1001.lockdir ] && ok "C2.2 замок снят после успеха" || bad "C2.2 замок остался"
# C2.3: verify-fail, конкурент вернул правило (recheck rc=0) → del нет
R="$(t_rt "IPOPT_RULE_SHOW='' IPOPT_RULE_SHOW_LATE='$EXACT' IPOPT_SHOW_SWITCH=3")"
has  "C2.3 конкурентная смена: откат не выполнен" "$R" "конкурентная смена состояния"
chk "C2.3 del=0" "$(n_of "$R" 'rule del')" 0
# C2.4: verify-fail + тень (recheck rc=2: правило + постороннее) → del нет
R="$(t_rt "IPOPT_RULE_SHOW='' IPOPT_RULE_SHOW_LATE='$NOTFW
$EXACT' IPOPT_SHOW_SWITCH=3")"
has  "C2.4 правило+тень: откат не выполнен" "$R" "конкурентная смена состояния"
chk "C2.4 del=0" "$(n_of "$R" 'rule del')" 0
# C2.5: verify-fail, правило отсутствует (recheck rc=1) → del выполняется
R="$(t_rt "IPOPT_RULE_SHOW=''")"
chk "C2.5 del=1 (нашего правила нет)" "$(n_of "$R" 'rule del')" 1
# C2.6: таймаут замка (живой посторонний владелец) → мутаций нет
LIVEPID=""; sleep 30 & LIVEPID=$!
mkdir -p /tmp/keenzoo_rule_1001.lockdir; echo "$LIVEPID" > /tmp/keenzoo_rule_1001.lockdir/pid
R="$(t_rt "IPOPT_RULE_SHOW=''")"
chk "C2.6 route replace нет (замок не получен)" "$(n_of "$R" 'route replace')" 0
chk "C2.6 add нет" "$(n_of "$R" 'rule add')" 0
has  "C2.6 честный лог о замке" "$R" "замок rule-транзакции table 1001 не получен"
[ -d /tmp/keenzoo_rule_1001.lockdir ] && ok "C2.6 чужой замок не тронут" || bad "C2.6 чужой замок удалён"
rm -rf /tmp/keenzoo_rule_1001.lockdir
kill "$LIVEPID" 2>/dev/null || true

# ═════════════════════════════════════════════════════════════════════
echo "C3. R39-3: lock — mv-claim, ownerless, pid-запись"
# ───────────────────────────────────────────────────────────────────────
{ sed -n '/^_rule_tx_claim()/,/^}/p' "$VPN_HOOK"
  sed -n '/^_rule_tx_lock()/,/^}/p' "$VPN_HOOK"
  sed -n '/^_rule_tx_unlock()/,/^}/p' "$VPN_HOOK"; } > "$W/lk.sh"
grep -q '_rule_tx_claim' "$W/lk.sh" \
    || { echo "❌ C3: функции не извлечены"; exit 1; }
LK="/tmp/keenzoo_rule_1001.lockdir"
rm -rf "$LK" "$LK".reap.* 2>/dev/null
# C3.1: захват + pid записан
( TAG=t; logger() { echo "$*" >&2; }; . "$W/lk.sh"; _rule_tx_lock 1001 ) 2>/dev/null
[ -d "$LK" ] && [ "$(cat "$LK/pid" 2>/dev/null)" != "" ] \
    && ok "C3.1 захвачен, pid записан" || bad "C3.1 захват/pid"
# C3.2: живой владелец (фоновый sleep) → claim отказ, каталог на месте
LIVEPID2=""; sleep 30 & LIVEPID2=$!
rm -rf "$LK"; mkdir -p "$LK"; echo "$LIVEPID2" > "$LK/pid"
CLAIM_RC="$( ( TAG=t; logger() { echo "$*" >&2; }; _rtl_dir="$LK"; . "$W/lk.sh"; _rule_tx_claim >/dev/null 2>&1; echo $? ) 2>/dev/null )"
[ "$CLAIM_RC" = 1 ] && [ -d "$LK" ] && [ "$(cat "$LK/pid" 2>/dev/null)" = "$LIVEPID2" ] \
    && ok "C3.2 claim живого владельца: отказ, каталог на месте" || bad "C3.2 claim живого" "$CLAIM_RC"
kill "$LIVEPID2" 2>/dev/null || true
# C3.3: чужой unlock (pid постороннего процесса) не снимает
LIVEPID3=""; sleep 30 & LIVEPID3=$!
rm -rf "$LK"; mkdir -p "$LK"; echo "$LIVEPID3" > "$LK/pid"
( TAG=t; logger() { :; }; . "$W/lk.sh"; _rule_tx_unlock 1001 )
if [ -d "$LK" ]; then ok "C3.3 чужой unlock не снял"; else bad "C3.3 замок потерян"; fi
kill "$LIVEPID3" 2>/dev/null || true
# C3.4: свой unlock снимает — pid в файле принадлежит subshell
rm -rf "$LK"; mkdir -p "$LK"; echo $$ > "$LK/pid"
( TAG=t; logger() { :; }; . "$W/lk.sh"; _rule_tx_unlock 1001 )
[ ! -d "$LK" ] && ok "C3.4 свой unlock снял" || bad "C3.4 не снял"
# C3.5: ownerless-замок (без pid) восстанавливается ограниченно
rm -rf "$LK"; mkdir -p "$LK"
T0=$(date +%s)
( TAG=t; logger() { echo "$*" >&2; }; . "$W/lk.sh"; _rule_tx_lock 1001 ) 2>/dev/null
T1=$(date +%s)
if [ -d "$LK" ] && [ "$(cat "$LK/pid" 2>/dev/null)" != "" ]; then
    ok "C3.5 ownerless восстановлен и перехвачен ($((T1 - T0))с)"
else
    bad "C3.5 ownerless не восстановлен"
fi
rm -rf "$LK"
# C3.6: мёртвый pid → перехват
rm -rf "$LK"; mkdir -p "$LK"; echo 999999 > "$LK/pid"
( TAG=t; logger() { echo "$*" >&2; }; . "$W/lk.sh"; _rule_tx_lock 1001 ) 2>/dev/null
[ -d "$LK" ] && [ "$(cat "$LK/pid" 2>/dev/null)" != "999999" ] \
    && ok "C3.6 stale (мёртвый pid) перехвачен" || bad "C3.6 stale не перехвачен"
rm -rf "$LK" "$LK".reap.* 2>/dev/null

# ═════════════════════════════════════════════════════════════════════
echo "C4. R39-1: B′ — staging + атомарный swap (fail-open окна нет)"
# ───────────────────────────────────────────────────────────────────────
awk '/^    \[ -n "\$vpn_table_id" \] \|\| \{$/{f=1} f{print} f&&/^    \}$/{exit}' "$RED_SH" > "$W/gate_body.sh"
grep -q '_fc_stage' "$W/gate_body.sh" \
    || { echo "❌ C4: блок не извлечён"; exit 1; }
{ echo 'for _t in 1; do'; cat "$W/gate_body.sh"; echo 'done'; } > "$W/gate.sh"
cat > "$MOCKDIR/ipset" <<'EOF'
#!/bin/sh
echo "ipset $*" >> "$IPSET_LOG"
_ST="$W/ipset_state"; mkdir -p "$_ST"
case "$1" in
    create) echo 0 > "$_ST/$2.cnt" 2>/dev/null
            [ "${IPSET_CREATE_FAIL:-0}" = 1 ] && exit 1; exit 0;;
    destroy) rm -f "$_ST/$2.cnt" 2>/dev/null; exit 0;;
    flush)   echo 0 > "$_ST/$2.cnt" 2>/dev/null; exit 0;;
    add)     _c="$(cat "$_ST/$2.cnt" 2>/dev/null || echo 0)"
             echo $((_c + 1)) > "$_ST/$2.cnt"; exit 0;;
    restore)
            [ "${IPSET_RESTORE_FAIL:-0}" = 1 ] && exit 1
            _set=""; _n=0
            while read -r _l; do
                case "$_l" in add\ *) _set="${_l#add }"; _set="${_set%% *}"; _n=$((_n + 1));; esac
            done
            [ -n "$_set" ] || exit 1
            _c="$(cat "$_ST/$_set.cnt" 2>/dev/null || echo 0)"
            echo $((_c + _n)) > "$_ST/$_set.cnt"
            exit 0;;
    list)
            if [ -n "${IPSET_FORCE_ENTRIES:-}" ]; then
                echo "Number of entries: $IPSET_FORCE_ENTRIES"; exit 0
            fi
            echo "Number of entries: $(cat "$_ST/$2.cnt" 2>/dev/null || echo 0)"
            exit 0;;
    swap)
            [ "${IPSET_SWAP_FAIL:-0}" = 1 ] && exit 1
            _a="$(cat "$_ST/$2.cnt" 2>/dev/null || echo 0)"
            _b="$(cat "$_ST/$3.cnt" 2>/dev/null || echo 0)"
            echo "$_b" > "$_ST/$2.cnt"; echo "$_a" > "$_ST/$3.cnt"
            exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ipset"
STG=0
t_gate() { # $1=список; $2..=env; вывод "E:..|D:..|A:..|Xd:..|S:..|ipset-лог"
    ( export PATH="$MOCKDIR:$PATH"
      printf '%s' "$1" > "$W/vpnlist.txt"
      export vpn_file_name="$W/vpnlist.txt" unblockvpn=unblockvpn-X vpn_type_lower=wgtest
      export vpn_table_id=""
      export IPSET_LOG="$W/ipset.log"; : > "$W/ipset.log"
      export W="$W"
      : > "$W/gerr"; : > "$W/gdeg"; : > "$W/fadd"; : > "$W/fdel"; : > "$W/eset"
      hook_error()   { echo "$*" >> "$W/gerr"; }
      hook_degraded(){ echo "$*" >> "$W/gdeg"; }
      vpn_fallback_add() { echo "$*" >> "$W/fadd"; echo "FADD $*" >> "$IPSET_LOG"; [ "${FADD_FAIL:-0}" = 1 ] && return 1; return 0; }
      vpn_fallback_del() { echo "$*" >> "$W/fdel"; return 0; }
      ensure_set() { echo "$*" >> "$W/eset"; [ "${IPSET_CREATE_FAIL:-0}" = 1 ] && return 1; return 0; }
      eval "export $2"
      . "$W/gate.sh"
      echo "E:$(cat "$W/gerr")|D:$(cat "$W/gdeg")|A:$(cat "$W/fadd")|Xd:$(cat "$W/fdel")|S:$(cat "$W/eset")|$(tr '\n' ';' < "$W/ipset.log")" )
}
LIST4='1.2.3.4
5.6.7.0/24
1.2.3.4
# комментарий

9.9.9.9 # inline
'
# C4.1: политика A (флаг выключен) — прежнее поведение
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=0")"
has  "C4.1 политика A: честный error МИМО VPN" "$R" "МИМО VPN"
has  "C4.1 fallback DROP снят (детерминизм)" "$R" "Xd:unblockvpn-X"
hasnt "C4.1 DROP не ставился" "$R" "A:unblockvpn-X"
# C4.2: B′ успех — staging, restore, swap; live НЕ flush'ится
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=1")"
has  "C4.2 закрыт fail-closed DROP (3 записи — дублика dedup)" "$R" "3 записей"
has  "C4.2 пакетный restore использован" "$R" "ipset restore"
has  "C4.2 атомарный swap выполнен" "$R" "ipset swap"
_c42_log="$(printf '%s' "$R" | tr ';' '\n')"
if [ "$(printf '%s' "$_c42_log" | grep -n 'ipset swap' | head -1 | cut -d: -f1)" -lt "$(printf '%s' "$_c42_log" | grep -n '^FADD ' | head -1 | cut -d: -f1)" ]; then
    ok "C4.2 swap ДО установки DROP (нет окна)"
else
    bad "C4.2 DROP ставится до swap"
fi
hasnt "C4.2 ЖИВОЙ набор не flush'ится" "$R" "flush unblockvpn-X"
has  "C4.2 fallback_add вызван" "$R" "A:unblockvpn-X"
chk "C4.2 restore ровно один" "$(n_of "$R" 'ipset restore')" 1
chk "C4.2 swap ровно один" "$(n_of "$R" 'ipset swap')" 1
# C4.3: restore отказ → прежний набор нетронут, swap нет
printf '2' > "$W/ipset_state/unblockvpn-X.cnt" 2>/dev/null || { mkdir -p "$W/ipset_state"; printf '2' > "$W/ipset_state/unblockvpn-X.cnt"; }
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=1 IPSET_RESTORE_FAIL=1")"
has  "C4.3 «набор не подготовлен»" "$R" "не подготовлен"
has  "C4.3 прежняя блокировка сохранена" "$R" "прежняя блокировка сохранена"
hasnt "C4.3 swap не выполнялся" "$R" "ipset swap"
chk "C4.3 live-набор нетронут (2 записи)" "$(cat "$W/ipset_state/unblockvpn-X.cnt" 2>/dev/null)" 2
# C4.4: несовпадение числа записей → переключение не выполняется
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=1 IPSET_FORCE_ENTRIES=2")"
has  "C4.4 «не сходится» — переключение не выполнено" "$R" "переключение не выполнено"
hasnt "C4.4 swap не выполнялся" "$R" "ipset swap"
chk "C4.4 live-набор нетронут" "$(cat "$W/ipset_state/unblockvpn-X.cnt" 2>/dev/null)" 2
# C4.5: swap недоступен → fail-closed, прежнее состояние сохранено
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=1 IPSET_SWAP_FAIL=1")"
has  "C4.5 «ipset swap отклонён»" "$R" "ipset swap отклонён"
has  "C4.5 прежняя блокировка сохранена" "$R" "прежняя блокировка сохранена"
chk "C4.5 live-набор нетронут" "$(cat "$W/ipset_state/unblockvpn-X.cnt" 2>/dev/null)" 2
# C4.6: DROP уже установлен (повторное событие) — DROP не снимается и live не пустеет
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=1")"
hasnt "C4.6 fallback_del НЕ вызывался (DROP не снимался)" "$R" "Xd:unblockvpn-X"
has  "C4.6 закрыт fail-closed DROP" "$R" "закрыт fail-closed DROP"
# C4.7: ensure_set отказ → честная ошибка
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=1 IPSET_CREATE_FAIL=1")"
has  "C4.7 набор ipset не создан" "$R" "набор ipset не создан"
hasnt "C4.7 swap не выполнялся" "$R" "ipset swap"
# C4.8: DROP-установка отказала → небезопасно
R="$(t_gate "$LIST4" "KEENZOO_FAIL_CLOSED_NO_TABLE=1 FADD_FAIL=1")"
has  "C4.8 DROP не установлен → небезопасно" "$R" "fail-closed DROP не установлен"
# C4.9: пустой список → degraded + DROP снят
R="$(t_gate "# только комментарии

" "KEENZOO_FAIL_CLOSED_NO_TABLE=1")"
has  "C4.9 пустой список → degraded" "$R" "D:VPN-набор unblockvpn-X"
has  "C4.9 stale DROP снят" "$R" "Xd:unblockvpn-X"
rm -rf "$W/ipset_state"

# ═════════════════════════════════════════════════════════════════════
echo "C5. R39-5: порт authority — диапазон и единственность ':'"
# ───────────────────────────────────────────────────────────────────────
awk '/^echo "   Каналы пакетов для opkg update/{f=1} f{print} /KEENZOO_DEPLOY_NO_HTTP.*обнаружены/{seen=1} seen&&/^fi$/{exit}' "$DEP_SH" > "$W/feeds.sh"
grep -q '*:*:*' "$W/feeds.sh" \
    || { echo "❌ C5: блок не извлечён"; exit 1; }
t_feed() {
    ( printf '%s\n' "$1" > "$W/opkg.conf"
      export KZ_DEPLOY_OPKG_CONF="$W/opkg.conf" KEENZOO_DEPLOY_NO_HTTP="${2:-0}"
      die() { echo "DIE:$*"; exit 77; }
      out="$(. "$W/feeds.sh")"; rc=$?
      echo "${out}|$rc" )
}
for U in 'http://bin.entware.net:80:443/f' 'http://bin.entware.net:99999/f' 'http://bin.entware.net:0/f' 'http://bin.entware.net:65536/f'; do
    O="$(t_feed "src/gz evil $U" 1)"
    case "$O" in *DIE:*) ok "C5 $U → заблокирован (malformed)";; *) bad "C5 $U проходит как штатной";; esac
done
for U in 'http://bin.entware.net:80/f' 'http://bin.entware.net:65535/f' 'http://bin.entware.net:1/f'; do
    O="$(t_feed "src/gz entware $U" 1)"
    case "$O" in *DIE:*) bad "C5 $U ошибочно заблокирован";; *) ok "C5 $U → штатной, не блокируется";; esac
done
O="$(t_feed 'src/gz evil http://bin.entware.net:80@evil.example/feed' 1)"
case "$O" in *DIE:*) ok "C5 userinfo по-прежнему блокируется";; *) bad "C5 userinfo-обход вернулся";; esac

# ═════════════════════════════════════════════════════════════════════
echo "C6. R39-6: recovery и обрезанная последняя запись state"
# ─────────────────════════════════════════════════════════════════════
sed -n '/^check_pinned_reachable()/,/^}/p' "$DNS_SH" > "$W/cpr.sh"
grep -q '_cpr_sline || \[ -n' "$W/cpr.sh" \
    || { echo "❌ C6: функция не извлечена/не исправлена"; exit 1; }
PIN_STATE=/tmp/keenzoo_pin_unreach
BAD1='VLESS: TCP endpoint unavailable — 1.2.3.4:443 (h1.example)'
run_cpr() { # PROBE_H1=0|1|2
    ( set -u
      logger() { echo "$*" >> "$W/pinlog"; }
      pin_notify() { echo "$1" >> "$W/notify"; }
      protocol_for_host() { echo VLESS; }
      proto_port_for_host() { echo 443; }
      _pr="${PROBE_H1:-2}"
      tcp_probe() { return "$_pr"; }
      mktemp() { echo "$W/cprf.$$"; }
      . "$W/cpr.sh"
      check_pinned_reachable "$(printf '1.2.3.4\th1.example')"
      echo "rc=$?" )
}
prep() { rm -f "$PIN_STATE" "$W"/cprf.* 2>/dev/null; : > "$W/notify"; : > "$W/pinlog"; }
# C6.1: обрезанная валидная запись + probe ok → ПРАВОМЕРНЫЙ recovery
prep; printf '%s' "$BAD1" > "$PIN_STATE"
PROBE_H1=0 run_cpr >/dev/null 2>&1
has  "C6.1 обрезанная запись распознана → recovery" "$(cat "$W/notify")" "снова доступны"
[ -f "$PIN_STATE" ] && bad "C6.1 state не снят" || ok "C6.1 state снят (endpoint подтверждён)"
# C6.2: обрезанная запись + probe U → recovery НЕТ
prep; printf '%s' "$BAD1" > "$PIN_STATE"
PROBE_H1=2 run_cpr >/dev/null 2>&1
hasnt "C6.2 endpoint не подтверждён → recovery нет" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "C6.2 state сохранён" || bad "C6.2 state потерян"
# C6.3: обрезанный мусор + probe ok → fail-closed, recovery нет
prep; printf 'MUSOR_NO_NL' > "$PIN_STATE"
PROBE_H1=0 run_cpr >/dev/null 2>&1
hasnt "C6.3 мусорная обрезанная запись → recovery нет" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "C6.3 state сохранён (fail-closed)" || bad "C6.3 state потерян"
# C6.4: контроль — полная запись + probe ok → recovery
prep; printf '%s\n' "$BAD1" > "$PIN_STATE"
PROBE_H1=0 run_cpr >/dev/null 2>&1
has  "C6.4 контроль: recovery по полной записи" "$(cat "$W/notify")" "снова доступны"
rm -f "$PIN_STATE"

# ═════════════════════════════════════════════════════════════════════
echo "C7. R39-7: uninstall — подтверждение снятия fallback DROP"
# ─────────────────════════════════════════════════════════════════════
sed -n '/rev38 (аудит-9, сопровождение/,/^    done$/p' "$DEP_SH" > "$W/un.sh"
grep -q 'fallback DROP не снят' "$W/un.sh" \
    || { echo "❌ C7: блок не извлечён"; exit 1; }
t_un() { # $1=IPT_LEAVE_DROP=0|1; вывод: предупреждения
    ( export PATH="$MOCKDIR:$PATH"
      export IPT_LOG="$W/ipt.log"; : > "$W/ipt.log"
      export W="$W"
      : > "$W/unwarn"; rm -f "$W"/del.* 2>/dev/null || true
      warn() { echo "$*" >> "$W/unwarn"; }
      IPT="IPT"
      IPT() {
          echo "IPT $*" >> "$IPT_LOG"
          case "$*" in
              *"-D PREROUTING"*)
                  if [ "${IPT_LEAVE_DROP:-0}" = 1 ]; then return 1; fi
                  _k="$(printf '%s' "$*" | cksum | cut -d' ' -f1)"
                  if [ -f "$W/del.$_k" ]; then return 1; fi
                  : > "$W/del.$_k"
                  return 0;;
              *"-C PREROUTING"*)
                  [ "${IPT_LEAVE_DROP:-0}" = 1 ] && return 0
                  return 1;;
          esac
          return 0
      }
      eval "export $1"
      _un_sets="unblockvpn-A unblockvpn-B"
      for _t in 1; do . "$W/un.sh"; done )
}
t_un "IPT_LEAVE_DROP=0"
[ ! -s "$W/unwarn" ] && ok "C7.1 всё снято — предупреждений нет" || bad "C7.1 лишний warn: $(cat "$W/unwarn")"
t_un "IPT_LEAVE_DROP=1"
has "C7.2 остаток DROP → явное предупреждение" "$(cat "$W/unwarn")" "fallback DROP не снят: mangle/unblockvpn-A/tcp"
chk "C7.2 предупреждены все 4 формы" "$(cat "$W/unwarn" | wc -l)" 4

echo "════════════════════════════════════════════════════════"
echo "ИТОГ audit10_fixture (shell): PASS=$PASS FAIL=$FAIL"
[ "$FAIL" = 0 ] || exit 1
exit 0
