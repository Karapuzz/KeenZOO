#!/usr/bin/env python3
"""audit8_py.py — приёмочные тесты правок R37-4/R37-5 в generator.py.

Внешний harness (не часть проекта). Функции извлекаются из РЕАЛЬНОГО
generator.py через ast и исполняются в изолированном namespace.
"""
import ast
import io
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import logging
import secrets

SRC = '/home/user/KeenZOO/opt/etc/bot/generator.py'

NEEDED = ['_bg_group_executable', 
    '_bg_check_publish', '_bg_check_unlock', '_bg_still_owner',
    '_bg_stop_child', '_bg_check_wait', '_bg_start_failure',
    '_bg_check_lock',
]
NEEDED_ASSIGNS = ['BG_CHECK_TIMEOUT', '_BG_SYNC']

src_text = io.open(SRC, encoding='utf-8').read()
tree = ast.parse(src_text)
seg = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in NEEDED:
        seg[node.name] = ast.get_source_segment(src_text, node)
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id in NEEDED_ASSIGNS:
                seg[t.id] = ast.get_source_segment(src_text, node)
missing = [n for n in NEEDED + NEEDED_ASSIGNS if n not in seg]
assert not missing, f"не извлечены: {missing}"

def make_ns():
    ns = {
        'os': os, 'sys': sys, 'json': json, 'time': time,
        'shutil': shutil, 'tempfile': tempfile, 'threading': threading,
        'subprocess': subprocess, 'logging': logging, 'signal': signal,
        'secrets': secrets,
    }
    exec(seg['BG_CHECK_TIMEOUT'], ns)
    exec(seg['_BG_SYNC'], ns)
    for f in NEEDED:
        exec(seg[f], ns)
    return ns

PASS = 0
FAIL = 0
def ok(name):
    global PASS; PASS += 1; print(f"  ✅ {name}")
def bad(name, why=''):
    global FAIL; FAIL += 1; print(f"  ❌ {name} {why}")

KIND = 'zztest8'
ST = f'/tmp/keenzoo_bg_{KIND}.json'
LOCK = f'/tmp/keenzoo_bg_{KIND}.lockdir'

def cleanup():
    shutil.rmtree(LOCK, ignore_errors=True)
    for p in os.listdir('/tmp'):
        if p.startswith(f'keenzoo_bg_{KIND}'):
            try: os.unlink(os.path.join('/tmp', p))
            except OSError:
                shutil.rmtree(os.path.join('/tmp', p), ignore_errors=True)

cleanup()
ns = make_ns()

# ── V1: _BG_SYNC существует и работоспособен ───────────────────────────
if isinstance(ns['_BG_SYNC'], type(threading.Lock())):
    ok('V1 _BG_SYNC — threading.Lock')
else:
    bad('V1 _BG_SYNC', repr(ns['_BG_SYNC']))
acq = ns['_BG_SYNC'].acquire(timeout=1)
if acq:
    ns['_BG_SYNC'].release()
    ok('V1 _BG_SYNC: acquire/release')
else:
    bad('V1 _BG_SYNC не захватывается')

# ── V2: чужой живой замок не вытесняется из канонического пути ────────
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write('FOREIGN')
with open(os.path.join(LOCK, 'pid'), 'w') as f:
    f.write('123')
ns['_bg_check_unlock'](LOCK, 'MYTOKEN')
if os.path.isdir(LOCK):
    ok('V2 чужой замок: lockdir НЕ переименован (предпроверка)')
else:
    bad('V2 чужой замок вытеснен')
rels = [p for p in os.listdir('/tmp') if p.startswith(f'{LOCK}.rel.')]
if not rels:
    ok('V2 никаких .rel.* артефактов')
else:
    bad('V2 остались .rel.*', rels)

# ── V3: свой замок снимается ───────────────────────────────────────────
shutil.rmtree(LOCK, ignore_errors=True)
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write('MYTOKEN')
ns['_bg_check_unlock'](LOCK, 'MYTOKEN')
ok_v3 = not os.path.isdir(LOCK)
(ok('V3 свой замок снят') if ok_v3 else bad('V3 свой замок не снят'))

# ── V4: takeover между предпроверкой и rename → restore ────────────────
os.mkdir(LOCK, 0o700)
MY = 'MYTOKEN2'
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write(MY)

class OSProxy4:
    """После нашего rename подменяет token в release-каталоге —
    имитация takeover между чтением и rename (проверка restore)."""
    def __init__(self, real, lockdir, marker):
        self._real, self._ld, self._mk = real, lockdir, marker
    def __getattr__(self, name):
        return getattr(self._real, name)
    def rename(self, a, b):
        r = self._real.rename(a, b)
        if a == self._ld:      # наш rename lockdir→release
            try:
                with open(os.path.join(b, 'token'), 'w') as f:
                    f.write('TAKER')   # нас «обошли»
            except OSError:
                pass
        return r

ns4 = make_ns()
ns4['os'] = OSProxy4(os, LOCK, None)
ns4['_bg_check_unlock'](LOCK, MY)
if os.path.isdir(LOCK):
    with open(os.path.join(LOCK, 'token')) as f:
        restored = f.read().strip()
    if restored == 'TAKER':
        ok('V4 takeover в окне: чужой замок ВОЗВРАЩЁН по каноническому пути')
    else:
        bad('V4 restore: неожиданный token', restored)
else:
    bad('V4 takeover в окне: замок не восстановлен')
rels = [p for p in os.listdir('/tmp') if p.startswith(f'{LOCK}.rel.')]
if not rels:
    ok('V4 мусора .rel.* нет')
else:
    bad('V4 остались .rel.*', rels)
shutil.rmtree(LOCK, ignore_errors=True)

# ── V5: остановка группы — grandchild переживает TERM родителя ────────
# parent: игнорирует SIGTERM, но быстро завершается сам; grandchild
# (sleep 30) наследует игнор — живёт после смерти parent.
proc = subprocess.Popen(
    ['sh', '-c', 'trap "" TERM; sleep 30 & sleep 0.5'],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    start_new_session=True, stdin=subprocess.DEVNULL)
time.sleep(0.7)                     # parent ещё жив, grandchild работает
pgid = proc.pid
t0 = time.time()
r = ns['_bg_stop_child'](proc)
dt = time.time() - t0
if r is True:
    ok(f'V5 stop_child=True за {dt:.1f}с')
else:
    bad('V5 stop_child не подтвердил остановку')
if proc.poll() is not None:
    ok('V5 direct child завершён')
else:
    bad('V5 direct child жив')
time.sleep(0.3)
group_gone = False
try:
    os.killpg(pgid, 0)
except OSError:
    group_gone = True
if group_gone:
    ok('V5 process group опустела (grandchild убит)')
else:
    # возможны unreaped-зомби — код не исполняют; отметим как WARNING-пас
    print('  ⚠️ V5 группа сигнализирует (возможны зомби) — считается '
          'остановкой после SIGKILL')

# ── V6: эскалация — вся группа игнорирует SIGTERM ─────────────────────
proc = subprocess.Popen(
    ['sh', '-c', 'trap "" TERM; sleep 30'],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    start_new_session=True, stdin=subprocess.DEVNULL)
time.sleep(0.3)
pgid = proc.pid
t0 = time.time()
r = ns['_bg_stop_child'](proc)
dt = time.time() - t0
if r is True and proc.poll() is not None:
    ok(f'V6 TERM-игнорирующая группа остановлена (SIGKILL) за {dt:.1f}с')
else:
    bad('V6 группа не остановлена', f'r={r} poll={proc.poll()}')
time.sleep(0.3)
try:
    os.killpg(pgid, 0)
    print('  ⚠️ V6 остаточная сигнализация группы (зомби) — допустимо')
except OSError:
    pass

# ── V7: реальный interleaving: waiter + конкурентный takeover под sync ─
os.mkdir(LOCK, 0o700)
TOK_OLD = 'old' * 8
with open(os.path.join(LOCK, 'token'), 'w') as f:
    f.write(TOK_OLD)
ns['_bg_check_publish'](KIND, {'status': 'running', 'ts': 1,
                               'message': 'новая задача'})
class ProcSleep:
    pid = 4242
    def wait(self):
        time.sleep(0.2)
        return 0
errors = []
def waiter():
    try:
        ns['_bg_check_wait'](KIND, ProcSleep(), '/tmp/keenzoo_bg_x.log',
                             LOCK, TOK_OLD)
    except Exception as e:
        errors.append(e)
def taker():
    time.sleep(0.05)
    # конкурентный stale-takeover + публикация running нового владельца
    shutil.rmtree(LOCK, ignore_errors=True)
    os.mkdir(LOCK, 0o700)
    with open(os.path.join(LOCK, 'token'), 'w') as f:
        f.write('new' * 8)
    ns['_bg_check_publish'](KIND, {'status': 'running', 'ts': 2,
                                   'message': 'ЕЩЁ более новая задача'})
th1 = threading.Thread(target=waiter)
th2 = threading.Thread(target=taker)
th1.start(); th2.start(); th1.join(); th2.join()
d = json.load(open(ST))
if d.get('message') == 'ЕЩЁ более новая задача':
    ok('V7 interleaving: статус новой задачи не перезаписан старым waiter')
else:
    bad('V7 статус перезаписан', repr(d))
with open(os.path.join(LOCK, 'token')) as f:
    if f.read().strip() == 'new' * 8:
        ok('V7 замок нового владельца цел')
    else:
        bad('V7 замок нового владельца повреждён')

cleanup()
print("════════════════════════════════════════")
print(f"ИТОГ audit8_py: PASS={PASS} FAIL={FAIL}")
sys.exit(0 if FAIL == 0 else 1)
