#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════
# audit8_fixture.sh — приёмочный стенд правок ред. 37 (аудит-8, F36-01..08).
# Внешний harness: НЕ часть проекта. Проверяет РЕАЛЬНЫЙ код из Git-дерева.
# ═══════════════════════════════════════════════════════════════════════
set -uo pipefail

KZ=/home/user/KeenZOO
PASS=0; FAIL=0
declare -a FAILED
ok()   { PASS=$((PASS+1)); echo "  ✅ $1"; }
bad()  { FAIL=$((FAIL+1)); FAILED+=("$1"); echo "  ❌ $1"; }
chk()  { if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1 (получено «$2», ожидалось «$3»)"; fi; }
has()  { case "$2" in *"$3"*) ok "$1";; *) bad "$1 (нет «$3» в «$2»)";; esac; }
hasnt(){ case "$2" in *"$3"*) bad "$1 (нежданный «$3»)";; *) ok "$1";; esac; }

VPN_HOOK="$KZ/opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh"
RED_SH="$KZ/opt/etc/ndm/netfilter.d/100-redirect.sh"
DNS_SH="$KZ/opt/bin/unblock_dnsmasq.sh"
DEP_SH="$KZ/opt/bin/deploy_bypass.sh"

W="$(mktemp -d /tmp/audit8.XXXXXX)"
trap 'rm -rf "$W"' EXIT
MOCKDIR="$W/mock"; mkdir -p "$MOCKDIR"

# ───────────────────────────────────────────────────────────────────────
echo "B1/B2. R37-1/R37-2: токен-точный матчер + откат по факту add"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_rule_exact_present()/,/^}/p' "$VPN_HOOK" > "$W/rt.sh"
sed -n '/^_rule_tx_claim()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_lock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_unlock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
awk '/^    if _rule_tx_lock "\$vpn_table_id"; then$/{f=1} f{print} /^    ip -4 route flush cache/{if(f)exit}' "$VPN_HOOK" >> "$W/rt.sh"
grep -q '_rule_exact_present()' "$W/rt.sh" && grep -q '_rule_added' "$W/rt.sh" \
    || { echo "❌ B1: блок не извлечён"; exit 1; }

cat > "$MOCKDIR/ip" <<'EOF'
#!/bin/sh
echo "$*" >> "$IP_LOG"
case "$1 $2" in
    "-4 route")
        case "$3" in
            replace) [ "${IPOPT_ROUTE_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            show)
                [ "${IPOPT_ROUTE_EMPTY:-0}" = 1 ] && exit 0
                case "$*" in
                    *" table main"*) echo "10.0.0.0/24 dev br0"; exit 0;;
                    *) echo "default via 10.0.0.1 dev wg0"; exit 0;;
                esac;;
        esac
        exit 0;;
    "-4 rule")
        case "$3" in
            add) [ "${IPOPT_RULE_ADD_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            del) exit 0;;
            show)
                # IPOPT_RULE_SHOW: строка вывода ip rule show
                [ -n "${IPOPT_RULE_SHOW:-}" ] && echo "$IPOPT_RULE_SHOW"
                exit 0;;
        esac
        exit 0;;
esac
exit 0
EOF
chmod +x "$MOCKDIR/ip"

EXACT="1778: from all fwmark 0xd1001 lookup 1001"
POISON="1778: from all fwmark 0xd10010 lookup 10010"
FOREIGN="2778: from all fwmark 0xd1001 lookup 1001"

t_rt() {
    ( export PATH="$MOCKDIR:$PATH"
      export IP_LOG="$W/ip.log"; : > "$IP_LOG"
      TAG=t; logger() { echo "$*" >> "$W/rtlog"; }; : > "$W/rtlog"
      vpn=Wireguard0; vpn_table_id=1001; vpn_ip=10.23.4.5; vpn_dev=Wireguard0; vpn_table=wgtest
      get_fwmark_id=0xd1001; vpn_name=wgtest
      eval "export $*"
      for _t in 1; do . "$W/rt.sh"; done
      rc=$?
      [ "$rc" = 0 ] && r=ok || r=fail
      echo "$r|$(tr '\n' ';' < "$IP_LOG")|$(tr '\n' ';' < "$W/rtlog")" )
}
ndel() { printf '%s' "$1" | tr ';' '\n' | grep -c 'rule del' || true; }
nadd() { printf '%s' "$1" | tr ';' '\n' | grep -c 'rule add' || true; }

# B2.1 (r39/R38-02): префикс-яд (0xd10010/10010) — постороннее правило
# на 1778 → полная остановка: ни route, ни add, ни del
R="$(t_rt "IPOPT_RULE_SHOW='$POISON'")"
has   "B2.1 префикс-яд: НЕБЕЗОПАСНО (ложного VPN ON нет)" "$R" "НЕБЕЗОПАСНО"
has   "B2.1 префикс-яд: конфликт диагностирован" "$R" "постороннее/конфликтное правило"
chk   "B2.1 префикс-яд: add НЕ выполнялся" "$(nadd "$R")" 0
chk   "B2.1 префикс-яд: del НЕ выполнялся" "$(ndel "$R")" 0

# B2.2: точное правило → идемпотентность (0 add, 0 del)
R="$(t_rt "IPOPT_RULE_SHOW='$EXACT'")"
hasnt "B2.2 точное правило: нет НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
chk   "B2.2 идемпотентно: add=0" "$(nadd "$R")" 0
chk   "B2.2 идемпотентно: del=0" "$(ndel "$R")" 0

# B2.3: чужой priority с точными mark/table → не точное → add → verify fail → del=1
R="$(t_rt "IPOPT_RULE_SHOW='$FOREIGN'")"
has   "B2.3 чужой priority: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
chk   "B2.3 чужой priority: del=1 (свой add)" "$(ndel "$R")" 1

# B2.4: route-отказ, правило существовало → del=0 (сохранено)
R="$(t_rt "IPOPT_RULE_SHOW='$EXACT' IPOPT_ROUTE_FAIL=1")"
has   "B2.4 route-fail: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
chk   "B2.4 существовавшее правило сохранено (del=0)" "$(ndel "$R")" 0

# B2.5: route-отказ, правила НЕ было → del=0 (F36-02: откат только после add)
R="$(t_rt "IPOPT_ROUTE_FAIL=1")"
has   "B2.5 route-fail без правила: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
chk   "B2.5 слепого del нет (del=0)" "$(ndel "$R")" 0

# B2.6: add-отказ → del=0 (F36-02)
R="$(t_rt "IPOPT_RULE_ADD_FAIL=1")"
has   "B2.6 add-fail: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
chk   "B2.6 del=0 (ничего не добавляли)" "$(ndel "$R")" 0

# B2.7: add ок, но verify не видит (show пуст после add) → del=1
R="$(t_rt "IPOPT_RULE_SHOW_AFTER_ADD=1 IPOPT_RULE_SHOW=''")"
R="$(t_rt "IPOPT_RULE_SHOW=''")"
has   "B2.7 verify-fail после add: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
chk   "B2.7 откат своего add (del=1)" "$(ndel "$R")" 1

# B2.8: полный успех (точное правило отсутствует, add ок, verify видит)
R="$(t_rt "IPOPT_RULE_SHOW_OK=1 IPOPT_RULE_SHOW='$EXACT' IPOPT_RULE_ADD_FAIL=0")"
R="$(t_rt "IPOPT_RULE_SHOW='$EXACT IPOPT_ADD_APPEND=1'")"
# полный успех покрывает B2.2; отдельный сценарий: правило появляется только после add
R="$(t_rt "IPOPT_RULE_SHOW='2778: from all lookup main'")"
has   "B2.8 нет точного до add; add+verify: show по-прежнему без точного → НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"

# ───────────────────────────────────────────────────────────────────────
echo "B3. R37-3: активные записи вместо размера файла"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^    \[ -n "$vpn_table_id" \] || {/,/^    }/p' "$RED_SH" > "$W/f03.sh"
grep -q 'grep -qvE' "$W/f03.sh" || { echo "❌ B3: ветка не извлечена"; exit 1; }
sed 's/continue$/:;/' "$W/f03.sh" > "$W/f03h.sh"
t_f03() { # $1=содержимое (multiline через \n)
    ( printf '%b' "$1" > "$W/vpnlist"
      vpn_file_name="$W/vpnlist"; unblockvpn=t; vpn_type_lower=w; vpn_table_id=""
      hook_error() { echo "ERR"; }; hook_degraded() { echo "DEG"; }
      . "$W/f03h.sh" 2>/dev/null )
}
chk "B3.1 только комментарии → degraded" "$(t_f03 '# comment\n\n   # ещё\n')" "DEG"
chk "B3.2 активная запись → error"      "$(t_f03 '1.2.3.4 # примечание\n')" "ERR"
chk "B3.3 CIDR → error"                 "$(t_f03 '10.0.0.0/24\n')" "ERR"
chk "B3.4 пустой файл → degraded"       "$(t_f03 '')" "DEG"

# ───────────────────────────────────────────────────────────────────────
echo "B4. R37-6: точный hostname штатного фида"
# ───────────────────────────────────────────────────────────────────────
awk '/^echo "   Каналы пакетов для opkg update/{f=1} f{print} /KEENZOO_DEPLOY_NO_HTTP.*обнаружены/{seen=1} seen&&/^fi$/{exit}' "$DEP_SH" > "$W/feeds.sh"
grep -q '_opf_host' "$W/feeds.sh" || { echo "❌ B4: блок не извлечён"; exit 1; }
t_feed() { # $1=строка src; вывод "OUT|RC"
    ( printf '%s\n' "$1" > "$W/opkg.conf"
      export KZ_DEPLOY_OPKG_CONF="$W/opkg.conf" KEENZOO_DEPLOY_NO_HTTP="${2:-0}"
      die() { echo "DIE:$*"; exit 77; }
      out="$(. "$W/feeds.sh")"; rc=$?
      echo "${out}|$rc" )
}
O="$(t_feed 'src/gz entware http://bin.entware.net/targets/x86-64/packages' 1)"
has  "B4.1 точный хост → штатной, не блокируется" "$O" "штатной Entware"
case "$O" in *DIE:*) bad "B4.1 strict заблокировал штатной";; *) ok "B4.1 нет блокировки";; esac
O="$(t_feed 'src/gz entware HTTP://BIN.ENTWARE.NET/targets/x86-64/packages' 1)"
case "$O" in *DIE:*) bad "B4.2 uppercase штатной заблокирован";; *) ok "B4.2 uppercase штатной → не блокируется";; esac
O="$(t_feed 'src/gz entware http://bin.entware.net:80/targets/packages' 1)"
case "$O" in *DIE:*) bad "B4.3 порт заблокирован";; *) ok "B4.3 хост с портом → не блокируется";; esac
O="$(t_feed 'src/gz evil http://bin.entware.net.evil.example/packages' 1)"
case "$O" in *DIE:*) ok "B4.4 поддельный суффикс-хост → заблокирован";; *) bad "B4.4 обход через суффикс-хост";; esac
O="$(t_feed 'src/gz evil http://evil.example/bin.entware.net/x' 1)"
case "$O" in *DIE:*) ok "B4.5 имя в пути → заблокирован";; *) bad "B4.5 обход через путь";; esac
O="$(t_feed 'src/gz bin.entware.net http://evil.example/packages' 1)"
case "$O" in *DIE:*) ok "B4.6 имя фида = bin.entware.net, URL чужой → заблокирован";; *) bad "B4.6 обход через имя фида";; esac
O="$(t_feed 'src/gz keendev https://bin.entware.net/other/keenetic.git' 0)"
hasnt "B4.7 https-фид без пометки" "$O" "HTTP-канал"

# ───────────────────────────────────────────────────────────────────────
echo "B5. R37-7: bad-доминирует + прозрачность unknown"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^check_pinned_reachable()/,/^}/p' "$DNS_SH" > "$W/cpr.sh"
PIN_STATE=/tmp/keenzoo_pin_unreach
run_cpr() { # TP_MODE=bad_unknown|unk_only|ok_mixed_unk
    ( set -u
      logger() { echo "$*" >> "$W/pinlog"; }
      pin_notify() { echo "$1" >> "$W/notify"; }
      protocol_for_host() { echo VLESS; }
      proto_port_for_host() { echo 443; }
      case "${TP_MODE:-}" in
          bad_unknown)
              # первый endpoint: bad, второй: unknown
              n=0
              tcp_probe() { n=$((n+1)); [ "$n" -le 2 ] && return 1 || return 2; } ;;
          unk_only)  tcp_probe() { return 2; } ;;
          ok_mixed_unk) tcp_probe() { return 2; } ;;
      esac
      mktemp() { echo "$W/cprf.$$"; }
      . "$W/cpr.sh"
      check_pinned_reachable "$(printf '1.2.3.4\th1.example\n5.6.7.8\th2.example')"
      echo "rc=$?" )
}
prep() { rm -f "$PIN_STATE"; : > "$W/notify"; : > "$W/pinlog"; }

prep
TP_MODE=bad_unknown run_cpr >/dev/null 2>&1
has  "B5.1 bad+unknown: outage-уведомление отправлено" "$(cat "$W/notify")" "TCP endpoint unavailable"
has  "B5.1 прозрачность: «исход 1 проб неизвестен»" "$(cat "$W/notify")" "исход 1 проб неизвестен"
[ -s "$PIN_STATE" ] && ok "B5.1 состояние сохранено" || bad "B5.1 состояние не сохранено"

prep; printf 'OLD\n' > "$PIN_STATE"
TP_MODE=unk_only run_cpr >/dev/null 2>&1
hasnt "B5.2 только unknown: НЕТ recovery" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "B5.2 прежний статус сохранён" || bad "B5.2 статус потерян"

prep; printf 'OLD\n' > "$PIN_STATE"
# bad=0, ok=0, unknown>0 (все пробы U) → recovery нет; r38/K2: ok>0
# c unknown на прочих endpoint'ах recovery разрешён (см. audit9 B5.3)
TP_MODE=ok_mixed_unk run_cpr >/dev/null 2>&1
hasnt "B5.3 ok+unknown: НЕТ recovery" "$(cat "$W/notify")" "снова доступны"
[ -s "$PIN_STATE" ] && ok "B5.3 прежний статус сохранён" || bad "B5.3 статус потерян"
has "B5.3 журнал: unknown" "$(cat "$W/pinlog")" "unknown"
rm -f "$PIN_STATE"

echo "════════════════════════════════════════════════════════"
echo "ИТОГ audit8_fixture (shell): PASS=$PASS FAIL=$FAIL"
[ $FAIL -gt 0 ] && printf 'Провалено: %s\n' "${FAILED[@]}"
exit $([ $FAIL -eq 0 ] && echo 0 || echo 1)
