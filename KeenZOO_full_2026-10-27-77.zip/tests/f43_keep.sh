#!/bin/bash
# f43_keep.sh — приёмочный стенд правок R43 (аудит-13):
#  A. C-1/C-2: keep-прунинг staging — пользовательские файлы переживают apply
#  B. N-1: вердикт при мёртвых портах + живом туннеле → BOOTSTRAP_PUBLIC
#  C. N-2: managed-блок при DNS_UNAVAILABLE содержит публичные резолверы
#  D. N-3: round-trip списков сохраняет все комментарии и формат "# "
#  E–I. Статические контракты N-4/N-6/N-7/N-8/N-9
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f43k
rm -rf "$F"; mkdir -p "$F"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. C-1/C-2: keep-прунинг staging ═══"
# извлекаем блок прунинга и подменяем корень
awk '/^# C-1\/C-2 \(аудит-13\)/{f=1} f{print} f&&/^if busybox cp -a/{exit}' \
    "$K/opt/bin/deploy_bypass.sh" | sed '1d;$d' > "$F/prune.raw"
sed -e "s#EXTRACT_DIR\"/opt/#EXTRACT_DIR\"§STG§#g" \
    -e "s#EXTRACT_DIR/opt/#EXTRACT_DIR§STG§#g" \
    -e "s#/opt/#$F/root/opt/#g" \
    -e "s#\"/\$_kz_rel\"#\"$F/root/\$_kz_rel\"#g" \
    -e "s#§STG§#/opt/#g" "$F/prune.raw" > "$F/prune.s"
grep -q '_kz_keep' "$F/prune.s" || bad "A: блок прунинга не извлёкся"
# сценарий 1: обновление (живые файлы есть)
mkdir -p "$F/root/opt/etc/bot" "$F/root/opt/etc/unblock" \
         "$F/staging/opt/etc/bot" "$F/staging/opt/etc/unblock"
echo "web_password = 'SECRET-MARKER'" > "$F/root/opt/etc/bot/bot_config.py"
printf 'archive-default-config\n' > "$F/staging/opt/etc/bot/bot_config.py"
printf 'user-entry.example\n' > "$F/root/opt/etc/unblock/vless.txt"
printf 'archive-list-entry.example\n' > "$F/staging/opt/etc/unblock/vless.txt"
printf 'archive-bot-list.example\n' > "$F/staging/opt/etc/unblock/bot.txt"
( _SAFE_EXTRACT_DIR="$F/staging"; . "$F/prune.s" )
[ "$(cat "$F/root/opt/etc/bot/bot_config.py")" = "web_password = 'SECRET-MARKER'" ] \
    && ok "A1: живой bot_config.py не затёрт (секрет на месте)" || bad "A1: bot_config затёрт"
[ ! -e "$F/staging/opt/etc/bot/bot_config.py" ] \
    && ok "A2: копия bot_config удалена из staging (cp -a не тронет живой)" || bad "A2"
[ "$(cat "$F/root/opt/etc/unblock/vless.txt")" = "user-entry.example" ] \
    && ok "A3: живой vless.txt не затёрт" || bad "A3: vless.txt затёрт"
[ ! -e "$F/staging/opt/etc/unblock/vless.txt" ] && ok "A4: копия vless.txt из staging удалена" || bad "A4"
# сценарий 2: чистая установка (живых файлов нет)
rm -rf "$F/root"; mkdir -p "$F/root/opt"
( _SAFE_EXTRACT_DIR="$F/staging"; . "$F/prune.s" )
[ "$(cat "$F/staging/opt/etc/unblock/bot.txt")" = "archive-bot-list.example" ] \
    && ok "A5: чистая установка — файл из архива остаётся в staging (будет применён)" || bad "A5"

echo "═══ B. N-1: вердикт при мёртвых портах и живом туннеле ═══"
awk '/^# ── Verdict ──/{f=1} f{print} f&&/_prev_verdict=/{exit}' \
    "$K/opt/bin/dns_spoof_check.sh" | sed '$d' > "$F/verdict.s"
sed -n '/^is_ip()/,/^}/p' "$K/opt/bin/common.sh" > "$F/isip.s"
cat > "$F/run_verdict.sh" <<'EOF'
#!/bin/sh
. /tmp/f43k/isip.s
TRUSTED_RANKED=""
INSECURE=""
TUNNEL_PROTOCOL_ORDER="xray trojan hysteria"
tunnel_protocol_active() { return 0; }   # живой процесс туннеля
BOOTSTRAP_RESOLVERS="8.8.8.8 77.88.8.8"
dig() { printf '93.184.216.34\n'; }       # публичный резолвер отвечает
TUNNEL_PROTO=""; BOOTSTRAP_OK=""
. /tmp/f43k/verdict.s
printf 'VERDICT=%s TUNNEL_PROTO=%s BOOTSTRAP_OK=%s\n' "$VERDICT" "$TUNNEL_PROTO" "$BOOTSTRAP_OK"
EOF
chmod +x "$F/run_verdict.sh"
OUT=$(sh "$F/run_verdict.sh" 2>&1)
case "$OUT" in
    "VERDICT=BOOTSTRAP_PUBLIC TUNNEL_PROTO=xray BOOTSTRAP_OK=8.8.8.8 77.88.8.8")
        ok "B1: мёртвые порты + живой туннель → BOOTSTRAP_PUBLIC (не TUNNEL_DNS), туннель в отчёте" ;;
    *) bad "B1: $OUT" ;;
esac
grep -q 'VERDICT="TUNNEL_DNS"' "$K/opt/bin/dns_spoof_check.sh" && bad "B2: вердикт TUNNEL_DNS остался" || ok "B2: вердикт TUNNEL_DNS удалён"
grep -q 'initial_tunnel_refresh' "$K/opt/bin/dns_spoof_check.sh" && bad "B3: мёртвая ветка реакции осталась" || ok "B3: мёртвая ветка реакции удалена"

echo "═══ C. N-2: managed-блок с fallback ═══"
sed -n '/^update_dnsmasq_upstreams()/,/^}/p' "$K/opt/bin/unblock_dnsmasq.sh" > "$F/udu.s"
cat > "$F/run_udu.sh" <<'EOF'
#!/bin/sh
DNS_UPSTREAM_BEGIN="# BEGIN KeenZOO managed DNS upstreams"
DNS_UPSTREAM_END="# END KeenZOO managed DNS upstreams"
safe_replace() { cat "$2" > "$1"; }
provider_resolver_list() { printf '77.88.8.8 77.88.8.7\n'; }
BOOTSTRAP_RESOLVERS="8.8.8.8 1.1.1.1"
. /tmp/f43k/udu.s
# случай 1: локальные порты мертвы
DNS_WORKING_PORTS=""
DNSMASQ_CONF=/tmp/f43k/dnsmasq1.conf
printf 'listen-address=127.0.0.1\n' > "$DNSMASQ_CONF"
update_dnsmasq_upstreams
echo "== unavailable =="; sed -n '/BEGIN KeenZOO/,/END KeenZOO/p' "$DNSMASQ_CONF"
# случай 2: рабочий порт есть
DNS_WORKING_PORTS="40508"
DNSMASQ_CONF=/tmp/f43k/dnsmasq2.conf
printf 'listen-address=127.0.0.1\n' > "$DNSMASQ_CONF"
update_dnsmasq_upstreams
echo "== working =="; sed -n '/BEGIN KeenZOO/,/END KeenZOO/p' "$DNSMASQ_CONF"
EOF
OUT=$(sh "$F/run_udu.sh" 2>&1)
echo "$OUT" | grep -q 'server=127.0.0.1#40500' && ok "C1: 40500 присутствует (последним — R46-1)" || bad "C1: нет 40500"
echo "$OUT" | grep -q 'server=77.88.8.8' && ok "C2: резолверы провайдера добавлены (DNS_UNAVAILABLE)" || bad "C2: нет provider"
echo "$OUT" | grep -q 'server=8.8.8.8' && ok "C3: публичный bootstrap добавлен" || bad "C3: нет bootstrap"
W=$(echo "$OUT" | sed -n '/== working ==/,$p')
echo "$W" | grep -q 'server=127.0.0.1#40508' && ok "C4: рабочий порт записан портом" || bad "C4"
echo "$W" | grep -q 'server=77.88.8.8' && bad "C5: при живых портах добавлены лишние fallback" || ok "C5: при живых портах fallback не добавляется"

echo "═══ D. N-3: round-trip комментариев ═══"
python3 - "$K" <<'PYD' && ok "D1: все комментарии сохранены, формат '# '" || bad "D1: round-trip теряет комментарии"
import io, os, sys, tempfile
K = sys.argv[1]
sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import lists_core as lc
lc.UNBLOCK_DIR = tempfile.mkdtemp(prefix='f43d_')
path = os.path.join(lc.UNBLOCK_DIR, 'vless.txt')
sample = ("# KeenZOO VLESS\n# ——— раздел ———\nexample.com\nsecond.example\n\n"
          "# хвостовой комментарий без записей\n")
lc.parse_and_save(path, sample, skip_global_dedup=True)
out = io.open(path, encoding='utf-8').read()
for needle in ('# KeenZOO VLESS', '# ——— раздел ———', 'example.com',
               'second.example', '# хвостовой комментарий без записей'):
    assert needle in out, f'потеряно: {needle}\n---\n{out}'
secs = lc._read_blocks(path)
assert ('KeenZOO VLESS', []) in secs, f'comment-only секции нет в _read_blocks: {secs}'
assert ('хвостовой комментарий без записей', []) in secs, secs
assert '# ' in out and '\n#' not in out.replace('# ', ''), 'формат без пробела'
PYD

echo "═══ E–I. Статические контракты ═══"
# R45-2 (аудит-15): порог вынесен в DNS_PROBE_ATTEMPTS (дефолт 3 = r42);
# поведенческая проверка бюджета — f45_audit.sh (B1–B5).
grep -q 'DNS_PROBE_ATTEMPTS="${DNS_PROBE_ATTEMPTS:-3}"' "$K/opt/bin/unblock_ipset.sh" \
    && grep -q '\[ "$COUNT" -ge "$DNS_PROBE_ATTEMPTS" \]' "$K/opt/bin/unblock_ipset.sh" \
    && ok "E: N-4 бюджет попыток (DNS_PROBE_ATTEMPTS, дефолт 3)" || bad "E: бюджет попыток не найден"
grep -q 'DNS_UNAVAILABLE: локальные порты не ответили' "$K/opt/bin/unblock_ipset.sh" \
    && ok "E2: журнал причины fallback" || bad "E2"
grep -q '\[ "$XRAY_SOURCE" != "github" \] || \[ "$DEPLOY_MODE" = "restore" \]' "$K/opt/bin/deploy_bypass.sh" \
    && ok "F: N-6 гейт шага 6 учитывает источник/restore" || bad "F"
grep -q '^svc_configured()' "$K/opt/bin/common.sh" && ok "G1: N-7 svc_configured в common.sh" || bad "G1"
grep -v '^[[:space:]]*#' "$K/opt/bin/common.sh" | grep -q 'svc_enabled' \
    && bad "G2: старое имя живо в коде" || ok "G2: в коде common.sh имени svc_enabled нет (только в комментарии о хуке)"
grep -q 'svc_configured "\$_init"' "$K/opt/bin/unblock_dnsmasq.sh" && ok "G3: вызов переименован" || bad "G3"
grep -q 'keenzoo_iptables_bin' "$K/opt/bin/test_udp_tunnels.sh" \
    && ok "H: N-8 диагностика читает кэш хука" || bad "H"
# I: source common.sh не форкает iptables
mkdir -p "$F/nofork"
cat > "$F/nofork/iptables" <<'EOF'
#!/bin/sh
echo "FORKED-IPTABLES $*" >> /tmp/f43k/forks.log
exit 0
EOF
chmod +x "$F/nofork/iptables"; : > "$F/forks.log"
PATH="$F/nofork:$PATH" sh -c ". '$K/opt/bin/common.sh'" 2>/dev/null
[ ! -s "$F/forks.log" ] && ok "I1: N-9 source common.sh — 0 запусков iptables" || bad "I1: $(cat "$F/forks.log")"
OUT=$(PATH="$F/nofork:$PATH" sh -c ". '$K/opt/bin/common.sh'; iptables_dns_bin" 2>/dev/null)
[ -n "$OUT" ] && ok "I2: iptables_dns_bin лениво возвращает бинарник ($OUT)" || bad "I2: пусто"

echo "═══ F43 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
