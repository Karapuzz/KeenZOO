#!/usr/bin/env python3
"""audit6_py.py — приёмочные тесты правок R35-5/R35-6 в generator.py.

Внешний harness (не часть проекта). Функции извлекаются из РЕАЛЬНОГО
generator.py через ast и исполняются в изолированном namespace.
"""
import ast
import io
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import types
import logging

SRC = '/home/user/KeenZOO/opt/etc/bot/generator.py'

NEEDED_FUNCS = ['_bg_group_executable', 
    '_tail_file', '_bg_check_paths', '_bg_check_publish',
    '_bg_cleanup_prev_log', '_bg_lock_takeover', '_bg_check_lock',
    '_bg_check_unlock', '_bg_still_owner', '_bg_stop_child',
    '_bg_check_wait', '_bg_start_failure',
    'start_bg_check', '_read_bg_check',
]
NEEDED_ASSIGNS = ['_BG_LOG_RE', 'BG_CHECK_TIMEOUT', '_BG_SYNC']

tree = ast.parse(io.open(SRC, encoding='utf-8').read())
seg = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in NEEDED_FUNCS:
        seg[node.name] = ast.get_source_segment(io.open(SRC, encoding='utf-8').read(), node)
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id in NEEDED_ASSIGNS:
                seg[t.id] = ast.get_source_segment(io.open(SRC, encoding='utf-8').read(), node)
missing = [n for n in NEEDED_FUNCS + NEEDED_ASSIGNS if n not in seg]
assert not missing, f"не извлечены: {missing}"

import secrets  # noqa: E402

def make_ns():
    ns = {
        'os': os, 'sys': sys, 'json': json, 're': re, 'time': time,
        'shutil': shutil, 'tempfile': tempfile, 'threading': threading,
        'subprocess': subprocess, 'logging': logging, 'secrets': secrets,
        'signal': signal,
    }
    exec(seg['_BG_LOG_RE'], ns)
    exec(seg['BG_CHECK_TIMEOUT'], ns)
    exec(seg['_BG_SYNC'], ns)
    for f in NEEDED_FUNCS:
        exec(seg[f], ns)
    return ns

PASS = 0
FAIL = 0
def ok(name):
    global PASS; PASS += 1; print(f"  ✅ {name}")
def bad(name, why=''):
    global FAIL; FAIL += 1; print(f"  ❌ {name} {why}")

KIND = 'zztest'
ST = f'/tmp/keenzoo_bg_{KIND}.json'
LOCK = f'/tmp/keenzoo_bg_{KIND}.lockdir'

def cleanup():
    shutil.rmtree(LOCK, ignore_errors=True)
    shutil.rmtree(f'{LOCK}.stale.0', ignore_errors=True)
    for p in os.listdir('/tmp'):
        if p.startswith(f'keenzoo_bg_{KIND}'):
            try: os.unlink(os.path.join('/tmp', p))
            except OSError: pass
    try: os.unlink(ST)
    except OSError: pass

cleanup()
ns = make_ns()

# ── T1: _tail_file — хвост через seek ──────────────────────────────────
big = '/tmp/audit6_big.log'
with open(big, 'w') as f:
    f.write('X' * 9000000 + 'TAIL_MARKER_123')
r = ns['_tail_file'](big)
if r.endswith('TAIL_MARKER_123') and len(r) <= 4000:
    ok('T1 _tail_file: хвост ≤4000 и корректен')
else:
    bad('T1 _tail_file', f'len={len(r)} end={r[-20:]!r}')
os.unlink(big)
if ns['_tail_file']('/nonexistent/file') == '':
    ok('T1 _tail_file: отсутствующий файл → пусто')
else:
    bad('T1 _tail_file: отсутствующий файл')

# ── T2: _BG_LOG_RE ─────────────────────────────────────────────────────
RX = ns['_BG_LOG_RE']
good = ['/tmp/keenzoo_bg_updates.AbC123x.log', '/tmp/keenzoo_bg_dns-spoof.XyZ09_.log']
evil = ['/tmp/keenzoo_bg_../../etc/passwd', '/tmp/keenzoo_bg_evil',
        '/tmp/keenzoo_bg_x.log/../../p', '/etc/passwd', '/tmp/keenzoo_bg_.log']
if all(RX.match(p) for p in good) and not any(RX.match(p) for p in evil):
    ok('T2 _BG_LOG_RE: валидные пути проходят, обходные нет')
else:
    bad('T2 _BG_LOG_RE')

# ── T3: захват/повторный захват ────────────────────────────────────────
lockdir, token = ns['_bg_check_lock'](KIND)
if os.path.isfile(os.path.join(lockdir, 'token')) and os.path.isfile(os.path.join(lockdir, 'pid')):
    ok('T3 замок создан: token+pid')
else:
    bad('T3 замок создан')
try:
    ns['_bg_check_lock'](KIND)
    bad('T3 повторный захват должен был упасть')
except RuntimeError:
    ok('T3 повторный захват → RuntimeError')
# живой pid + token → занято независимо от возраста
old = time.time() - 5000
os.utime(lockdir, (old, old))
try:
    ns['_bg_check_lock'](KIND)
    bad('T5 живой child + старый замок не должен отбираться')
except RuntimeError:
    ok('T5 token-замок с живым PID не отбирается по возрасту')
ns['_bg_check_unlock'](lockdir, 'WRONGTOKEN')
if os.path.isdir(lockdir):
    ok('T8 unlock с чужим token не трогает замок')
else:
    bad('T8 unlock с чужим token удалил замок')
ns['_bg_check_unlock'](lockdir, token)
if not os.path.isdir(lockdir):
    ok('T8 unlock владельцем снимает замок')
else:
    bad('T8 unlock владельцем')

# ── T4: stale takeover старого формата (без token, мёртвый pid) ───────
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'pid'), 'w') as f:
    f.write('999999999')          # заведомо мёртвый
os.utime(LOCK, (time.time() - 4000, time.time() - 4000))
lockdir, token = ns['_bg_check_lock'](KIND)
ok('T4 stale takeover (мёртвый pid, старый формат) проходит')
ns['_bg_check_unlock'](lockdir, token)

# ── T6: старый формат + живой pid + возраст >900 → takeover (legacy) ──
os.mkdir(LOCK, 0o700)
with open(os.path.join(LOCK, 'pid'), 'w') as f:
    f.write(str(os.getpid()))     # живой
os.utime(LOCK, (time.time() - 4000, time.time() - 4000))
lockdir, token = ns['_bg_check_lock'](KIND)
ok('T6 legacy-замок (без token) с живым pid отбирается по возрасту — прежняя семантика')
ns['_bg_check_unlock'](lockdir, token)

# ── T7: конкурентный stale recovery — ровно один победитель ───────────
class OSProxy:
    def __init__(self, real, delay):
        self._real, self._delay = real, delay
    def __getattr__(self, name):
        return getattr(self._real, name)
    def rename(self, a, b):
        time.sleep(self._delay())
        return self._real.rename(a, b)
import random
random.seed(42)
wins = []
for round_no in range(8):
    os.mkdir(LOCK, 0o700)
    with open(os.path.join(LOCK, 'pid'), 'w') as f:
        f.write('999999999')
    os.utime(LOCK, (time.time() - 4000, time.time() - 4000))
    ns7 = make_ns()
    ns7['os'] = OSProxy(os, lambda: random.uniform(0.02, 0.25))
    results = []
    barrier = threading.Barrier(2)
    def worker():
        barrier.wait()
        try:
            ld, tk = ns7['_bg_check_lock'](KIND)
            results.append(('win', ld, tk))
        except Exception as e:
            results.append(('fail', type(e).__name__))
    t1 = threading.Thread(target=worker); t2 = threading.Thread(target=worker)
    t1.start(); t2.start(); t1.join(); t2.join()
    nwin = sum(1 for r in results if r[0] == 'win')
    wins.append(nwin)
    if nwin == 1:
        for r in results:
            if r[0] == 'win':
                ns7['_bg_check_unlock'](r[1], r[2])
    else:
        # несколько победителей: снять все и отметить провал
        for p in os.listdir('/tmp'):
            if p.startswith(f'keenzoo_bg_{KIND}.lockdir'):
                shutil.rmtree(os.path.join('/tmp', p), ignore_errors=True)
if all(w == 1 for w in wins):
    ok(f'T7 конкурентный stale recovery: один победитель во всех {len(wins)} раундах')
else:
    bad('T7 конкурентный stale recovery', f'победители по раундам: {wins}')

# ── T11: ротация лога предыдущего прогона ──────────────────────────────
prev_log = '/tmp/keenzoo_bg_zztest.PreV123.log'
with open(prev_log, 'w') as f:
    f.write('old run log')
ns['_bg_check_publish'](KIND, {'status': 'done', 'log_path': prev_log})
ns['_bg_cleanup_prev_log'](KIND)
if not os.path.exists(prev_log):
    ok('T11 _bg_cleanup_prev_log удаляет лог предыдущего прогона')
else:
    bad('T11 ротация не сработала')
# невалидный путь не трогается
keep = '/tmp/keep_audit6.log'
with open(keep, 'w') as f:
    f.write('keep')
ns['_bg_check_publish'](KIND, {'status': 'done', 'log_path': '/tmp/keenzoo_bg_evil'})
ns['_bg_cleanup_prev_log'](KIND)
if os.path.exists(keep):
    ok('T11 посторонние пути не трогаются')
else:
    bad('T11 удалён посторонний файл')

# ── T12: _read_bg_check — strict log_path ──────────────────────────────
good_log = '/tmp/keenzoo_bg_zztest.Read1.log'
with open(good_log, 'w') as f:
    f.write('ЖУРНАЛ ПРОГОНА')
ns['_bg_check_publish'](KIND, {'status': 'done', 'ts': int(time.time()),
                               'log_path': good_log})
d = ns['_read_bg_check'](KIND)
if d.get('log') == 'ЖУРНАЛ ПРОГОНА':
    ok('T12 _read_bg_check: валидный log_path читается')
else:
    bad('T12 _read_bg_check', repr(d.get('log')))
os.unlink(good_log)
ns['_bg_check_publish'](KIND, {'status': 'done', 'ts': int(time.time()),
                               'log_path': '/tmp/keenzoo_bg_'})
d = ns['_read_bg_check'](KIND)
if d.get('log') == '' :
    ok('T12 _read_bg_check: невалидный путь → fallback на legacy (пусто)')
else:
    bad('T12 _read_bg_check fallback', repr(d.get('log')))

# ── T9: Popen падает → статус error, не running ───────────────────────
script = '/tmp/audit6_probe.sh'
with open(script, 'w') as f:
    f.write('#!/bin/sh\necho probe\n')
os.chmod(script, 0o755)
ns9 = make_ns()
ns9['BG_CHECKS'] = {KIND: script}
def popen_fail(*a, **k):
    raise PermissionError(13, 'Permission denied')
ns9['subprocess'] = types.SimpleNamespace(Popen=popen_fail, DEVNULL=subprocess.DEVNULL)
try:
    ns9['start_bg_check'](KIND)
    bad('T9 start_bg_check должен был пробросить исключение')
except PermissionError:
    pass
st = json.load(open(ST))
if st.get('status') == 'error' and 'Не удалось запустить' in st.get('message', ''):
    ok('T9 Popen-fail → опубликован финальный error')
else:
    bad('T9 Popen-fail статус', repr(st))
if not os.path.isdir(LOCK):
    ok('T9 замок снят')
else:
    bad('T9 замок не снят')
leftovers = [p for p in os.listdir('/tmp') if p.startswith(f'keenzoo_bg_{KIND}.') and p.endswith('.log')]
if not leftovers:
    ok('T9 лог запуска удалён')
else:
    bad('T9 лог запуска остался', leftovers)

# ── T10: Thread.start падает → child остановлен, error ────────────────
ns10 = make_ns()
ns10['BG_CHECKS'] = {KIND: script}
terminated = []
class FakeProc:
    pid = 4242
    def terminate(self): terminated.append('term')
    def wait(self, timeout=None): terminated.append('wait')
def popen_ok(*a, **k):
    return FakeProc()
class ThreadFail:
    def __init__(self, *a, **k): pass
    def start(self): raise RuntimeError('can\'t start new thread')
ns10['subprocess'] = types.SimpleNamespace(Popen=popen_ok, DEVNULL=subprocess.DEVNULL)
ns10['threading'] = types.SimpleNamespace(Thread=ThreadFail)
try:
    ns10['start_bg_check'](KIND)
    bad('T10 Thread.start fail должен был пробросить исключение')
except RuntimeError:
    pass
st = json.load(open(ST))
if st.get('status') == 'error' and 'контрольный поток' in st.get('message', ''):
    ok('T10 Thread-fail → финальный error')
else:
    bad('T10 Thread-fail статус', repr(st))
# r37 (F36-07): сигнал адресуется ГРУППЕ (os.killpg), а не прямому PID;
# стаб-группы 4242 не существует → killpg тихо ESRCH, direct child
# дожидается через wait. Подтверждение — вызов wait.
if 'wait' in terminated:
    ok('T10 child ожидён (r37: сигнал группе, direct child wait)')
else:
    bad('T10 child не остановлен', terminated)
if not os.path.isdir(LOCK):
    ok('T10 замок снят')
else:
    bad('T10 замок не снят')

# ── T13: успешный прогон через start_bg_check (smoke) ─────────────────
ns13 = make_ns()
ns13['BG_CHECKS'] = {KIND: script}
ns13['start_bg_check'](KIND)
deadline = time.time() + 15
while time.time() < deadline:
    try:
        st = json.load(open(ST))
        if st.get('status') in ('done', 'error'):
            break
    except Exception:
        pass
    time.sleep(0.2)
if st.get('status') == 'done' and st.get('rc') == 0:
    ok('T13 успешный прогон: done, waiter опубликовал статус и снял замок')
else:
    bad('T13 успешный прогон', repr(st))
if not os.path.isdir(LOCK):
    ok('T13 замок снят waiter-ом')
else:
    bad('T13 замок не снят')
_d13 = ns13['_read_bg_check'](KIND)
if 'probe' in (_d13.get('log') or '') and _d13.get('log_path', '').startswith('/tmp/keenzoo_bg_'):
    ok('T13 вывод child попал в per-run лог')
else:
    bad('T13 лог прогона', repr(_d13.get('log')))

cleanup()
os.unlink(script); os.unlink(keep)
print(f"════════════════════════════════════════")
print(f"ИТОГ audit6_py: PASS={PASS} FAIL={FAIL}")
sys.exit(0 if FAIL == 0 else 1)
