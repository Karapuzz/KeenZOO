#!/usr/bin/env python3
"""audit9_py.py — приёмочные тесты R38-4 (F37-04): ревизия состояний
process group после SIGKILL. Внешний harness (не часть проекта)."""
import ast
import io
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import logging
import threading
import json

SRC = '/home/user/KeenZOO/opt/etc/bot/generator.py'
NEEDED = ['_bg_group_executable', '_bg_stop_child']
NEEDED_ASSIGNS = ['_BG_SYNC']

src_text = io.open(SRC, encoding='utf-8').read()
tree = ast.parse(src_text)
seg = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in NEEDED:
        seg[node.name] = ast.get_source_segment(src_text, node)
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id in NEEDED_ASSIGNS:
                seg[t.id] = ast.get_source_segment(src_text, node)
missing = [n for n in NEEDED + NEEDED_ASSIGNS if n not in seg]
assert not missing, f"не извлечены: {missing}"

def make_ns():
    ns = {'os': os, 'sys': sys, 'time': time, 'signal': signal,
          'logging': logging, 'subprocess': subprocess,
          'threading': threading, 'shutil': shutil, 'json': json}
    exec(seg['_BG_SYNC'], ns)
    for f in NEEDED:
        exec(seg[f], ns)
    return ns

PASS = 0
FAIL = 0
def ok(name):
    global PASS; PASS += 1; print(f"  ✅ {name}")
def bad(name, why=''):
    global FAIL; FAIL += 1; print(f"  ❌ {name} {why}")

W = tempfile.mkdtemp(prefix='a9py_')
ns = make_ns()

def fake_proc(pgid, pid, state, comm='(proc)'):
    d = os.path.join(W, 'proc', str(pid))
    os.makedirs(d, exist_ok=True)
    # /proc/pid/stat: pid (comm) S ppid pgrp ...
    stat = f'{pid} {comm} {state} 1 {pgid} 1 0 0 0\n'
    with open(os.path.join(d, 'stat'), 'w') as f:
        f.write(stat)

def fresh_procfs():
    shutil.rmtree(os.path.join(W, 'proc'), ignore_errors=True)
    os.makedirs(os.path.join(W, 'proc'))

# ── W1: только зомби (Z) → [], остановка подтверждается ────────────────
fresh_procfs()
fake_proc(4242, 101, 'Z')
fake_proc(4242, 102, 'Z')
fake_proc(777, 201, 'R')          # чужая группа
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'proc'))
if r == []:
    ok('W1 группа только из зомби → [] (не исполняют)')
else:
    bad('W1 зомби-группа', repr(r))

# ── W2: живой R-член → возвращается в списке ───────────────────────────
fresh_procfs()
fake_proc(4242, 101, 'Z')
fake_proc(4242, 102, 'R')
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'proc'))
if r == ['102:R']:
    ok('W2 R-член группы → [102:R] (остановка НЕ подтверждается)')
else:
    bad('W2 R-член', repr(r))

# ── W3: D-state (uninterruptible) → живой ──────────────────────────────
fresh_procfs()
fake_proc(4242, 101, 'D')
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'proc'))
if r == ['101:D']:
    ok('W3 D-state считается незавершённым (killpg(0) его не отличает)')
else:
    bad('W3 D-state', repr(r))

# ── W4: X (dead) и x — не исполняющие ──────────────────────────────────
fresh_procfs()
fake_proc(4242, 101, 'X')
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'proc'))
if r == []:
    ok('W4 X-состояние → не исполняющий')
else:
    bad('W4 X', repr(r))

# ── W5: группа пуста/отсутствует → [] ──────────────────────────────────
fresh_procfs()
fake_proc(777, 201, 'R')
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'proc'))
if r == []:
    ok('W5 группы нет в /proc → []')
else:
    bad('W5 пусто', repr(r))

# ── W6: /proc недоступен → None (fail-closed) ──────────────────────────
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'no_such_proc'))
if r is None:
    ok('W6 ошибка сканирования → None (подтверждение не даётся)')
else:
    bad('W6 скан-отказ', repr(r))

# ── W7: повреждённый stat (без ')') и мусорные каталоги — пропускаются ─
fresh_procfs()
os.makedirs(os.path.join(W, 'proc', '103'), exist_ok=True)
with open(os.path.join(W, 'proc', '103', 'stat'), 'w') as f:
    f.write('garbage without paren\n')
os.makedirs(os.path.join(W, 'proc', 'notapid'), exist_ok=True)
fake_proc(4242, 104, 'S', comm='(weird ) name)')   # скобка в comm
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'proc'))
if r is None:
    ok('W7 malformed-stat → None (r39: unknown, fail-closed)')
else:
    bad('W7 malformed должен давать None', repr(r))
fresh_procfs()
fake_proc(4242, 104, 'S', comm='(weird ) name)')
r = ns['_bg_group_executable'](4242, procfs=os.path.join(W, 'proc'))
if r == ['104:S']:
    ok('W7b comm со скобкой разобран по последней )')
else:
    bad('W7b comm со скобкой', repr(r))

# ── W8: _bg_stop_child — residual group с живым членом → False ────────
class Proc8:
    pid = 4242
    def wait(self, timeout=None):
        return 0
class OSProxy8:
    def __init__(self, real):
        self._real = real
    def __getattr__(self, name):
        return getattr(self._real, name)
    def killpg(self, pgid, sig):
        return 0                      # группа «сигнализирует» всегда
ns8 = make_ns()
ns8['os'] = OSProxy8(os)
ns8['_bg_group_executable'] = lambda pgid, procfs='/proc': ['55:R']
r = ns8['_bg_stop_child'](Proc8())
if r is False:
    ok('W8 остаточная группа с R-членом → False (замок не снимется)')
else:
    bad('W8 живой остаток', repr(r))

# ── W9: остаточная группа только из зомби → True ───────────────────────
ns9 = make_ns()
ns9['os'] = OSProxy8(os)
ns9['_bg_group_executable'] = lambda pgid, procfs='/proc': []
r = ns9['_bg_stop_child'](Proc8())
if r is True:
    ok('W9 остаточная группа из зомби → True (честный журнал)')
else:
    bad('W9 зомби-остаток', repr(r))

# ── W10: /proc-скан недоступен → False (fail-closed) ───────────────────
ns10 = make_ns()
ns10['os'] = OSProxy8(os)
ns10['_bg_group_executable'] = lambda pgid, procfs='/proc': None
r = ns10['_bg_stop_child'](Proc8())
if r is False:
    ok('W10 состояние группы не определено → False')
else:
    bad('W10 undetermined', repr(r))

# ── W11: реальная группа — TERM-игнорирующий потомок, гибнущий от KILL ─
proc = subprocess.Popen(
    ['sh', '-c', 'trap "" TERM; sleep 30'],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    start_new_session=True, stdin=subprocess.DEVNULL)
time.sleep(0.3)
t0 = time.monotonic()
r = ns['_bg_stop_child'](proc)
dt = time.monotonic() - t0
if r is True and proc.poll() is not None:
    ok(f'W11 реальная TERM-игнорирующая группа остановлена за {dt:.1f}с')
else:
    bad('W11 реальная группа', f'r={r} poll={proc.poll()}')

# ── W12: монотонные дедлайны — время не идёт назад ─────────────────────
src_fn = seg['_bg_stop_child']
if 'time.monotonic()' in src_fn and 'deadline = time.time()' not in src_fn:
    ok('W12 grace/deadline на time.monotonic()')
else:
    bad('W12 в _bg_stop_child остался time.time()')

shutil.rmtree(W, ignore_errors=True)
print("════════════════════════════════════════")
print(f"ИТОГ audit9_py: PASS={PASS} FAIL={FAIL}")
sys.exit(0 if FAIL == 0 else 1)
