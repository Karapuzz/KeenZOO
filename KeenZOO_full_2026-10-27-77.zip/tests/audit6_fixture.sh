#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════
# audit6_fixture.sh — приёмочный стенд правок ред. 35 (аудит-6).
# Внешний harness: НЕ часть проекта. Проверяет РЕАЛЬНЫЙ код, извлечённый
# из рабочих файлов Git-дерева /home/user/KeenZOO.
# Соглашения: pipefail; rc проверяемой команды сохраняется отдельно.
# ═══════════════════════════════════════════════════════════════════════
set -uo pipefail

KZ=/home/user/KeenZOO
PASS=0; FAIL=0; UC=0
declare -a FAILED

ok()   { PASS=$((PASS+1)); echo "  ✅ $1"; }
bad()  { FAIL=$((FAIL+1)); FAILED+=("$1"); echo "  ❌ $1"; }
chk()  { if [ "$2" = "$3" ]; then ok "$1 ($2)"; else bad "$1 (получено «$2», ожидалось «$3»)"; fi; }
has()  { case "$2" in *"$3"*) ok "$1";; *) bad "$1 (нет «$3» в «$2»)";; esac; }
hasnt(){ case "$2" in *"$3"*) bad "$1 (нежданный «$3» в «$2»)";; *) ok "$1";; esac; }

VPN_HOOK="$KZ/opt/etc/ndm/ifstatechanged.d/100-unblock-vpn.sh"
DNS_SH="$KZ/opt/bin/unblock_dnsmasq.sh"
UPD_SH="$KZ/opt/bin/update_protocols.sh"
DEP_SH="$KZ/opt/bin/deploy_bypass.sh"

W="$(mktemp -d /tmp/audit6.XXXXXX)"
trap 'rm -rf "$W"' EXIT
export MOCKDIR="$W/mock"; mkdir -p "$MOCKDIR"

# ───────────────────────────────────────────────────────────────────────
echo "S1. _valid_ipv4 (R35-2) — реальная функция из 100-unblock-vpn.sh"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_valid_ipv4()/,/^}/p' "$VPN_HOOK" > "$W/v4.sh"
grep -q '^_valid_ipv4()' "$W/v4.sh" || { echo "❌ S1: функция не извлечена"; exit 1; }
t_v4() { # $1=вход $2=ожидание (0 valid/1 invalid)
    ( . "$W/v4.sh"; _valid_ipv4 "$1" && echo 0 || echo 1 )
}
chk "S1.1 10.23.4.5 → valid"        "$(t_v4 10.23.4.5)"    0
chk "S1.2 частичный 10.23.4. → inv" "$(t_v4 '10.23.4.')"   1
chk "S1.3 три октета → inv"         "$(t_v4 10.23.4)"      1
chk "S1.4 пять октетов → inv"       "$(t_v4 10.23.4.5.6)"  1
chk "S1.5 октет 256 → inv"          "$(t_v4 256.1.1.1)"    1
chk "S1.6 буквы → inv"              "$(t_v4 a.b.c.d)"      1
chk "S1.7 пустой октет → inv"       "$(t_v4 10..4.5)"      1
chk "S1.8 пустая строка → inv"      "$(t_v4 '')"           1
chk "S1.9 пробел в поле → inv"      "$(t_v4 '10.23.4.5 6')" 1
chk "S1.10 0.0.0.0 → valid"         "$(t_v4 0.0.0.0)"      0

# ───────────────────────────────────────────────────────────────────────
echo "S2. is_client_tunnel tri-state (R35-1)"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_rci_query()/,/^}/p' "$VPN_HOOK" > "$W/role.sh"
sed -n '/^is_client_tunnel()/,/^}/p' "$VPN_HOOK" >> "$W/role.sh"
grep -q '^is_client_tunnel()' "$W/role.sh" || { echo "❌ S2: функция не извлечена"; exit 1; }
# mock curl: URL-суффикс → env MOCK_<SUF>_OUT / MOCK_<SUF>_RC
cat > "$MOCKDIR/curl" <<'EOF'
#!/bin/sh
for a in "$@"; do
    case "$a" in
        */global)    printf '%s' "${MOCK_GLOBAL_OUT:-}";   exit "${MOCK_GLOBAL_RC:-0}";;
        */defaultgw) printf '%s' "${MOCK_DEFAULTGW_OUT:-}"; exit "${MOCK_DEFAULTGW_RC:-0}";;
    esac
done
exit 1
EOF
chmod +x "$MOCKDIR/curl"
t_role() { # аргументы — env-присваивания; вывод 0/1/2
    ( set -u; export PATH="$MOCKDIR:$PATH"
      _RCI_CURL_OK=1
      RCI=http://rci.test
      interface_cfg() { printf '%s' "${MOCK_CFG:-}"; }
      . "$W/role.sh"
      eval "export $@"
      is_client_tunnel "${MOCK_ID:-Wireguard0}" && echo 0 || echo $? ) 2>/dev/null
}
chk "S2.1 global=true → client(0)"      "$(t_role 'MOCK_GLOBAL_OUT=true')" 0
chk "S2.2 rc=28 (timeout) → unknown(2)" "$(t_role 'MOCK_GLOBAL_RC=28 MOCK_GLOBAL_OUT=10.23.4.')" 2
chk "S2.3 пусто rc=0 → unknown(2)"      "$(t_role 'MOCK_GLOBAL_OUT=')" 2
chk "S2.4 false+false → server(1)"      "$(t_role 'MOCK_GLOBAL_OUT=false MOCK_DEFAULTGW_OUT=false')" 1
chk "S2.5 false+defaultgw=true → 0"     "$(t_role 'MOCK_GLOBAL_OUT=false MOCK_DEFAULTGW_OUT=true')" 0
chk "S2.6 false+defaultgw rc=5 → 2"     "$(t_role 'MOCK_GLOBAL_OUT=false MOCK_DEFAULTGW_RC=5')" 2
chk "S2.7 неожиданное тело → 2"         "$(t_role 'MOCK_GLOBAL_OUT=Component not found:')" 2
chk "S2.8 WG listen-port → server(1) без RCI" \
    "$(t_role 'MOCK_ID=Wireguard1 MOCK_CFG="listen-port = 51820" MOCK_GLOBAL_RC=7')" 1
chk "S2.9 нет curl (_RCI_CURL_OK=0) → 2" \
    "$(MOCK_NOCURL=1; set -u; _RCI_CURL_OK=0; interface_cfg() { :; }; . "$W/role.sh"; is_client_tunnel Wireguard0 >/dev/null 2>&1 && echo 0 || echo $?)" 2

# ───────────────────────────────────────────────────────────────────────
echo "S3. Верификация route/rule (R35-3)"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^_rule_exact_present()/,/^}/p' "$VPN_HOOK" > "$W/rt.sh"
sed -n '/^_rule_tx_claim()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_lock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
sed -n '/^_rule_tx_unlock()/,/^}/p' "$VPN_HOOK" >> "$W/rt.sh"
awk '/^    if _rule_tx_lock "\$vpn_table_id"; then$/{f=1} f{print} /^    ip -4 route flush cache/{if(f)exit}' "$VPN_HOOK" >> "$W/rt.sh"
grep -q '_rt_ok=1' "$W/rt.sh" && grep -q 'route flush cache' "$W/rt.sh" \
    || { echo "❌ S3: блок не извлечён"; exit 1; }
IPOK="$MOCKDIR/ip"; export IPOK
cat > "$IPOK" <<'EOF'
#!/bin/sh
# мок ip: поведение по IPOPT_* env; журнал вызовов
echo "$*" >> "$IP_LOG"
case "$1 $2" in
    "-4 route")
        case "$3" in
            replace)
                [ "${IPOPT_ROUTE_FAIL:-0}" = 1 ] && exit 1
                exit 0;;
            show)
                [ "${IPOPT_ROUTE_EMPTY:-0}" = 1 ] && exit 0
                case "$*" in
                    *" table main"*) echo "10.0.0.0/24 dev br0"; exit 0;;
                    *) echo "default via 10.0.0.1 dev wg0"; exit 0;;
                esac;;
        esac
        exit 0;;
    "-4 rule")
        case "$3" in
            add) [ "${IPOPT_RULE_ADD_FAIL:-0}" = 1 ] && exit 1; exit 0;;
            del) exit 0;;
            show)
                [ "${IPOPT_RULE_HIDE:-0}" = 1 ] && exit 0
                echo "1778: from all fwmark 0xd1001 lookup 1001"
                exit 0;;
        esac
        exit 0;;
esac
exit 0
EOF
chmod +x "$IPOK"
t_rt() { # $1..: IPOPT env; вывод "rc|логвызовы"
    ( export PATH="$MOCKDIR:/usr/bin:/bin"
      export IP_LOG="$W/ip.log"; : > "$IP_LOG"
      TAG=t; logger() { echo "$*" >> "$W/rtlog"; }
      vpn=Wireguard0; vpn_table_id=1001; vpn_ip=10.23.4.5; vpn_dev=Wireguard0; vpn_table=wgtest
      get_fwmark_id=0xd1001; vpn_name=wgtest; : > "$W/rtlog"
      eval "export $*"
      for _t in 1; do
          . "$W/rt.sh"
      done
      rc=$?
      [ "$rc" = 0 ] && r=ok || r=fail
      echo "$r|$(tr '\n' ';' < "$IP_LOG")|$(tr '\n' ';' < "$W/rtlog")" )
}
# rev36: контракт обновлён под неразрушающую схему (F-01 аудит-7):
# точное наличие правила проверяется до route; идемпотентный повтор не
# делает add/del; существовавшее правило при отказе не удаляется.
R="$(t_rt 'IPOPT_ROUTE_FAIL=0')"
has  "S3.1 успех: flush cache вызван" "$R" "route flush cache"
hasnt "S3.1 успех: НЕБЕЗОПАСНО нет" "$R" "НЕБЕЗОПАСНО"
hasnt "S3.1 идемпотентно: нет rule add" "$R" "rule add"
hasnt "S3.1 идемпотентно: нет rule del" "$R" "rule del"
R="$(t_rt 'IPOPT_ROUTE_FAIL=1')"
has  "S3.2 route-fail: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
hasnt "S3.2 route-fail: flush не вызван" "$R" "flush cache"
hasnt "S3.2 route-fail: существовавшее правило НЕ удаляется" "$R" "rule del"
hasnt "S3.2 route-fail: rule add не выполнялся" "$R" "rule add"
R="$(t_rt 'IPOPT_RULE_HIDE=1 IPOPT_RULE_ADD_FAIL=1')"
has  "S3.3 add-fail (правила не было): НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
hasnt "S3.3 add-fail: flush не вызван" "$R" "flush cache"
# rev37 (F36-02): откат только после успешного add — при отказе add del нет
n_del_s33="$(printf '%s' "$R" | tr ';' '\n' | grep -c 'rule del' || true)"
chk "S3.3 add-fail: del=0 (r37: откат по факту add)" "$n_del_s33" 0
R="$(t_rt 'IPOPT_RULE_HIDE=1')"
has  "S3.4 добавленное правило не подтвердилось: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
has  "S3.4 rollback del после своего add" "$R" "rule add"
R="$(t_rt 'IPOPT_ROUTE_EMPTY=1')"
has  "S3.5 default не виден в таблице: НЕБЕЗОПАСНО" "$R" "НЕБЕЗОПАСНО"
hasnt "S3.5 существовавшее правило НЕ удаляется" "$R" "rule del"

# ───────────────────────────────────────────────────────────────────────
echo "S4. Guard list-seen (R35-8) — три копии"
# ───────────────────────────────────────────────────────────────────────
extract_ls() { # $1=файл $2=var(_lsr|_ls_reset)
    awk -v v="$2" '
        index($0, v "=\"$(mktemp /tmp/.kz_ls.XXXXXX") {f=1}
        f {print}
        seen && /^ *fi$/ {exit}
        /не является обычным файлом/ {seen=1}
    ' "$1"
}
run_ls() { # $1=файл $2=var $3=сценарий(normal|symdir) → rc
    (
      cd "$W"
      LSID="$RANDOM$RANDOM"
      LSF="$W/seen.$LSID"
      rm -f "$LSF"
      case "$3" in
          symdir)
              mkdir -p "$W/refdir.$LSID"
              ln -s "$W/refdir.$LSID" "$LSF"
              ;;
          normal) : ;;
      esac
      export LIST_SEEN_FILE="$LSF"
      extract_ls "$1" "$2" > "$W/lsblk.$$"
      grep -q 'не является обычным файлом' "$W/lsblk.$$" || exit 90
      sh -c "warn_stub() { :; }; . '$W/lsblk.$$'" >/dev/null 2>"$W/lserr.$$"
      echo $?
    )
}
for spec in "DNS:$DNS_SH:_lsr" "IPSET:$KZ/opt/bin/unblock_ipset.sh:_lsr" "UPD:$KZ/opt/bin/unblock_update.sh:_ls_reset"; do
    n="${spec%%:*}"; rest="${spec#*:}"; f="${rest%%:*}"; v="${rest##*:}"
    rc="$(run_ls "$f" "$v" symdir)"
    chk "S4.$n symlink-to-dir → отказ (rc=1)" "$rc" 1
    rc="$(run_ls "$f" "$v" normal)"
    chk "S4.$n обычный путь → сброс ок (rc=0)" "$rc" 0
done
# семантика mv в symlink-to-dir ( BusyBox ): подтверждение класса проблемы
( mkdir -p "$W/mvd"; : > "$W/mvfile"; ln -s "$W/mvd" "$W/symd"
  mv -f "$W/mvfile" "$W/symd" 2>/dev/null
  if [ -f "$W/mvd/mvfile" ] && [ -L "$W/symd" ]; then
      ok "S4.busybox mv в symlink-to-dir уносит внутрь (проблема реальна)"
  else
      bad "S4.busybox mv поведение изменилось — перепроверить guard"
  fi )

# ───────────────────────────────────────────────────────────────────────
echo "S5. check_pinned_reachable (R35-7): ошибка записи ≠ recovery"
# ───────────────────────────────────────────────────────────────────────
sed -n '/^check_pinned_reachable()/,/^}/p' "$DNS_SH" > "$W/cpr.sh"
grep -q '^check_pinned_reachable()' "$W/cpr.sh" || { echo "❌ S5: функция не извлечена"; exit 1; }
PIN_STATE=/tmp/keenzoo_pin_unreach
export PIN_STATE
prep_cpr() { rm -f "$PIN_STATE"; : > "$W/notify"; : > "$W/pinlog"; }
run_cpr() { # env: CPR_MKTEMP_DEVFULL=1|0, CPR_TCP_FAIL=1|0, CPR_STATE_PRE=1|0, CPR_STATE_SYMDIR=1|0
    ( set -u
      export PATH="$MOCKDIR:$PATH"
      logger() { echo "$*" >> "$W/pinlog"; }
      pin_notify() { echo "$1" >> "$W/notify"; }
      protocol_for_host() { echo VLESS; }
      proto_port_for_host() { echo 443; }
      tcp_probe() { [ "${CPR_TCP_FAIL:-0}" = 1 ] && return 1; return 0; }
      if [ "${CPR_MKTEMP_DEVFULL:-0}" = 1 ]; then
          printf '#!/bin/sh\necho /dev/full\n' > "$MOCKDIR/mktemp"; chmod +x "$MOCKDIR/mktemp"
      else
          rm -f "$MOCKDIR/mktemp"
      fi
      . "$W/cpr.sh"
      check_pinned_reachable "$(printf '1.2.3.4\thost.example')"
      echo "rc=$?" )
}
# A: пробы падают, запись ок → уведомление ⚠️ + состояние сохранено (mv)
prep_cpr
O="$(CPR_TCP_FAIL=1 run_cpr)"
has  "S5.A отказ проб → уведомление ⚠️" "$(cat "$W/notify")" "TCP endpoint unavailable"
if [ -f "$PIN_STATE" ] && [ ! -L "$PIN_STATE" ]; then ok "S5.A состояние — обычный файл (mv)"; else bad "S5.A состояние не файл"; fi
has  "S5.A в состоянии — запись о недоступности" "$(cat "$PIN_STATE" 2>/dev/null)" "unavailable"
# B: /dev/full + пробы УСПЕШНЫ → записывать нечего, recovery правомерен
# (пустой printf не пишет байтов — ошибки записи нет; это не «ложное
# восстановление»: пробы реально прошли). rev38/K2: в состоянии — РЕАЛЬНАЯ
# bad-строка формата «… — ip:port (host)»; её endpoint обязан стать O.
prep_cpr; printf 'VLESS: TCP endpoint unavailable — 1.2.3.4:443 (host.example)\n' > "$PIN_STATE"
O="$(CPR_MKTEMP_DEVFULL=1 CPR_TCP_FAIL=0 run_cpr)"
chk "S5.B probes-pass → rc=0" "${O##*rc=}" 0
has  "S5.B правомерное «✅ снова доступны»" "$(cat "$W/notify")" "снова доступны"
[ ! -e "$PIN_STATE" ] && ok "S5.B outage-файл снят (recovery)" || bad "S5.B outage-файл не снят"
hasnt "S5.B журнал: нет лишнего «не сохранён»" "$(cat "$W/pinlog")" "не сохранён"
# C: /dev/full + пробы ПАДАЮТ → тоже unknown, уведомлений нет
prep_cpr; printf 'OLD OUTAGE LINE\n' > "$PIN_STATE"
O="$(CPR_MKTEMP_DEVFULL=1 CPR_TCP_FAIL=1 run_cpr)"
has  "S5.C уведомлений нет" "$(cat "$W/notify")" ""
[ -s "$PIN_STATE" ] && ok "S5.C outage-файл сохранён" || bad "S5.C outage-файл потерян"
# D: состояние = symlink-to-dir → mv не выполняется, каталог цел
prep_cpr; mkdir -p "$W/pinref.$$"; ln -s "$W/pinref.$$" "$PIN_STATE"
O="$(CPR_TCP_FAIL=1 run_cpr)"
if [ -L "$PIN_STATE" ] && [ ! -f "$W/pinref.$$/*" ] && [ -z "$(ls -A "$W/pinref.$$")" ]; then
    ok "S5.D symlink-to-dir: ничего не уехало внутрь"
else
    bad "S5.D файл уехал внутрь symlink-каталога"
fi
if grep -q "подменён каталогом" "$W/pinlog" 2>/dev/null; then ok "S5.D журнал: подменено каталогом"; else bad "S5.D журнал: нет сообщения о подмене"; fi
rm -f "$PIN_STATE"; rm -rf "$MOCKDIR/mktemp"

# ───────────────────────────────────────────────────────────────────────
echo "S6. df-гейты (R35-9): функции из update_protocols.sh и deploy_bypass.sh"
# ───────────────────────────────────────────────────────────────────────
cat > "$MOCKDIR/df" <<'EOF'
#!/bin/sh
[ "${MOCK_DF_FAIL:-0}" = 1 ] && exit 1
case "$*" in
    *"${MOCK_DF_PATH:-__none__}"*) echo "Filesystem 1K-blocks Used ${MOCK_DF_FREE:-0} Available"; exit 0;;
esac
echo "Filesystem 1K-blocks Used ${MOCK_DF_FREE_OTHER:-99999999} Available"; exit 0
EOF
chmod +x "$MOCKDIR/df"
sed -n '/^_kz_df_free_kb()/,/^}/p' "$UPD_SH" > "$W/df.sh"
sed -n '/^_kz_dl_space_ok()/,/^}/p' "$UPD_SH" >> "$W/df.sh"
sed -n '/^_kz_file_space_ok()/,/^}/p' "$UPD_SH" >> "$W/df.sh"
grep -q '_kz_file_space_ok' "$W/df.sh" || { echo "❌ S6: функции не извлечены"; exit 1; }
: > "$W/bigfile"; head -c 4096 /dev/zero >> "$W/bigfile" 2>/dev/null || dd if=/dev/zero of="$W/bigfile" bs=4096 count=1 2>/dev/null
t_df() { # env → "rc|warns"
    ( set -u; export PATH="$MOCKDIR:$PATH"
      WARNLOG="$W/warn"; export WARNLOG; : > "$WARNLOG"
      warn() { echo "$*" >> "$WARNLOG"; }
      KEENZOO_DLTMP=/opt/share/keenzoo-dl
      . "$W/df.sh"
      eval "$1"
      _kz_file_space_ok /opt/sbin "$W/bigfile" >"$W/dfout" 2>&1; r1=$?
      sed -i 's#/opt/sbin#/opt/sbin#' "$W/dfout"
      _kz_dl_space_ok 131072 >>"$W/dfout" 2>&1; r2=$?
      echo "$r1$r2|$(tr '\n' ';' < "$WARNLOG")" )
}
R="$(MOCK_DF_PATH=/opt/sbin MOCK_DF_FREE=100 t_df 'X=1')"
case "$R" in "10|"*) ok "S6.1 мало места на /opt/sbin → file-гейт отказ, dl-гейт прошёл";; *) bad "S6.1 ($R)";; esac
R="$(MOCK_DF_PATH=/opt/sbin MOCK_DF_FREE=100 t_df 'X=1' )"
R="$(MOCK_DF_FREE=100 MOCK_DF_PATH=/opt/share/keenzoo-dl t_df 'X=1')"
case "$R" in "01|"*) ok "S6.2 мало места в DLTMP → dl-гейт отказ, file-гейт прошёл";; *) bad "S6.2 ($R)";; esac
R="$(MOCK_DF_FREE=99999999 t_df 'X=1')"
case "$R" in "00|"*) ok "S6.3 места достаточно → оба гейта прошли";; *) bad "S6.3 ($R)";; esac
R="$(MOCK_DF_FAIL=1 t_df 'X=1')"
case "$R" in "00|"*) ok "S6.4 df сломан → fail-open обоих гейтов";; *) bad "S6.4 ($R)";; esac
R="$(MOCK_DF_FAIL=1 t_df 'X=1')"
has "S6.4 предупреждение при fail-open" "$R" "Не удалось определить"
# синхронность копий deploy/updater
for fn in _kz_df_free_kb _kz_dl_space_ok _kz_file_space_ok; do
    a="$(sed -n "/^$fn()/,/^}/p" "$UPD_SH")"
    b="$(sed -n "/^$fn()/,/^}/p" "$DEP_SH")"
    if [ "$a" = "$b" ]; then ok "S6.5 $fn: копии текстуально синхронны"; else bad "S6.5 $fn: копии разошлись"; fi
done

# ───────────────────────────────────────────────────────────────────────
echo "S7. Фиды opkg (R35-10): маркировка HTTP + строгий режим"
# ───────────────────────────────────────────────────────────────────────
awk '/^echo "   Каналы пакетов для opkg update/{f=1} f{print} /KEENZOO_DEPLOY_NO_HTTP.*обнаружены/{seen=1} seen&&/^fi$/{exit}' "$DEP_SH" > "$W/feeds.sh"
grep -q 'HTTP-канал' "$W/feeds.sh" || { echo "❌ S7: блок не извлечён"; exit 1; }
cat > "$W/opkg.conf" <<'EOF'
src/gz entware http://bin.entware.net/targets/x86-64/packages
src/gz keendev https://bin.entware.net/other/keenetic.git
src/gz custom http://evil.example/packages
EOF
t_feeds() { # $1: NO_HTTP значение
    ( export KZ_DEPLOY_OPKG_CONF="$W/opkg.conf"
      export KEENZOO_DEPLOY_NO_HTTP="${1:-0}"
      die() { echo "DIE:$*"; exit 77; }
      . "$W/feeds.sh" )
}
O="$(t_feeds 0)"; RC=$?
has  "S7.1 http-фид помечен ⚠️" "$O" "HTTP-канал"
hasnt "S7.1 по умолчанию блокировки нет" "$O" "DIE"
O="$(t_feeds 1)"; RC=$?
if [ "$RC" = 77 ]; then ok "S7.2 NO_HTTP=1 → отказ до opkg update (посторонний http)"; else bad "S7.2 rc=$RC"; fi
has  "S7.2 в сообщении — посторонний фид" "$O" "evil.example"
case "$O" in
    *DIE:*bin.entware.net*) bad "S7.2 штатной Entware попал в блокировку";;
    *) ok "S7.2 штатной Entware не блокируется (r36/F-07)";;
esac

# ───────────────────────────────────────────────────────────────────────
echo "════════════════════════════════════════════════════════"
echo "ИТОГ audit6_fixture (shell): PASS=$PASS FAIL=$FAIL"
[ $FAIL -gt 0 ] && printf 'Провалено: %s\n' "${FAILED[@]}"
exit $([ $FAIL -eq 0 ] && echo 0 || echo 1)
