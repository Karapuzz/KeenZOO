#!/bin/bash
# f45_audit.sh — приёмочный стенд правок R45 (аудит-15):
#  A. diag_pick_iptables: тёзка переименован, контракт-комментарий,
#     MD5-твин deploy↔100-redirect не тронут
#  B. DNS_PROBE_ATTEMPTS: поведенческий тест РЕАЛЬНОГО цикла из
#     unblock_ipset.sh (дефолт 3 / override 2 и 5 / мусор и 0 → гвард 3)
#     + аварийный fallback 40500 с режимом DNS_UNAVAILABLE_FALLBACK
#  C. tunnel_dns_rule_ok: один $(iptables_dns_bin) на вызов;
#     ленивый 0-fork source (как f43-I2)
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f45chk
rm -rf "$F"; mkdir -p "$F"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }
T="$K/opt/bin/test_udp_tunnels.sh"

echo "═══ A. diag_pick_iptables (R45-1) ═══"
if grep -n 'pick_iptables' "$T" | grep -v ':#' | grep -qv 'diag_pick_iptables'; then
    bad "A1: в test_udp_tunnels осталось имя pick_iptables вне комментариев"
else
    ok "A1: имя pick_iptables вне комментариев отсутствует"
fi
[ "$(grep -c 'diag_pick_iptables' "$T")" -ge 2 ] \
    && ok "A2: diag_pick_iptables определён и вызывается" \
    || bad "A2: diag_pick_iptables не найден (нужно ≥2 вхождения)"
grep -q 'НЕ твин' "$T" && grep -q 'синхронизировать' "$T" \
    && ok "A3: контракт-комментарий (не твин / не синхронизировать)" \
    || bad "A3: контракт-комментарий не найден"
M1=$(sed -n '/^pick_iptables()/,/^}/p' "$K/opt/bin/deploy_bypass.sh" | md5sum | cut -d' ' -f1)
M2=$(sed -n '/^pick_iptables()/,/^}/p' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" | md5sum | cut -d' ' -f1)
[ -n "$M1" ] && [ "$M1" = "$M2" ] \
    && ok "A4: MD5-твин deploy↔100-redirect не тронут (${M1:0:8})" \
    || bad "A4: твин разошёлся"

echo "═══ B. DNS_PROBE_ATTEMPTS (R45-2, реальный цикл) ═══"
awk 'bb && /^[[:space:]]*done[[:space:]]*$/ {print; exit}
     /DNS_PROBE_ATTEMPTS=/ {f=1}
     f {print}
     f && /DNS_UNAVAILABLE_FALLBACK/ {nb=1}
     nb && /^[[:space:]]*break[[:space:]]*$/ {bb=1}' \
    "$K/opt/bin/unblock_ipset.sh" > "$F/loop.s"
grep -q 'while \[ -z "$WORKING_DNS_PORTS" \]' "$F/loop.s" \
    && grep -q 'DNS_PROBE_ATTEMPTS' "$F/loop.s" \
    && ok "B0: реальный цикл извлечён ($(wc -l < "$F/loop.s") строк)" \
    || bad "B0: экстракт неполон"
probe() { # $1=default|<значение>
    rm -f "$F/tries"; : > "$F/tries"
    {
        echo "select_working_ports() { echo 1 >> '$F/tries'; return 0; }"
        echo "logger() { :; }"
        echo "sleep() { :; }"
        cat "$F/loop.s"
        echo "echo \"tries=\$(wc -l < '$F/tries' | tr -d ' ') wdp=\$WORKING_DNS_PORTS mode=\$DNS_HEALTH_MODE\""
    } > "$F/probe.sh"
    if [ "$1" = default ]; then
        env -u DNS_PROBE_ATTEMPTS sh "$F/probe.sh"
    else
        DNS_PROBE_ATTEMPTS="$1" sh "$F/probe.sh"
    fi
}
t_default=$(probe default)
t_2=$(probe 2)
t_5=$(probe 5)
t_garbage=$(probe abc)
t_zero=$(probe 0)
[ "$t_default" = "tries=3 wdp=40500 mode=DNS_UNAVAILABLE_FALLBACK" ] \
    && ok "B1: дефолт — 3 попытки, fallback 40500, режим FALLBACK" \
    || bad "B1: $t_default"
[ "$t_2" = "tries=2 wdp=40500 mode=DNS_UNAVAILABLE_FALLBACK" ] \
    && ok "B2: DNS_PROBE_ATTEMPTS=2 → ровно 2 попытки" \
    || bad "B2: $t_2"
[ "$t_5" = "tries=5 wdp=40500 mode=DNS_UNAVAILABLE_FALLBACK" ] \
    && ok "B3: DNS_PROBE_ATTEMPTS=5 → ровно 5 попыток" \
    || bad "B3: $t_5"
[ "$t_garbage" = "tries=3 wdp=40500 mode=DNS_UNAVAILABLE_FALLBACK" ] \
    && ok "B4: мусорное значение → гвард → 3" \
    || bad "B4: $t_garbage"
[ "$t_zero" = "tries=3 wdp=40500 mode=DNS_UNAVAILABLE_FALLBACK" ] \
    && ok "B5: 0 → гвард → 3" \
    || bad "B5: $t_zero"

echo "═══ C. Один вызов iptables_dns_bin (R45-3) ═══"
C=$(grep -c '\$(iptables_dns_bin)' "$K/opt/bin/common.sh")
[ "$C" = 1 ] && ok "C1: в common.sh ровно 1 \$(iptables_dns_bin) (было 2 call-site)" \
    || bad "C1: вхождений: $C"
grep -q '_tdp_ipt="$(iptables_dns_bin)"' "$K/opt/bin/common.sh" \
    && ok "C2: единственный вызов — присваивание _tdp_ipt в начале функции" \
    || bad "C2: якорь _tdp_ipt не найден"
grep -q 'if "$_tdp_ipt" -w -t nat -C OUTPUT' "$K/opt/bin/common.sh" \
    && ok "C3: цикл использует кэшированный \$_tdp_ipt" \
    || bad "C3: цикл не использует _tdp_ipt"
mkdir -p "$F/nofork"
OUT=$(PATH="$F/nofork:/usr/bin:/bin" sh -c ". '$K/opt/bin/common.sh'; iptables_dns_bin" 2>/dev/null)
rc=$?
[ "$rc" = 0 ] && [ -n "$OUT" ] \
    && ok "C4: source + ленивый вызов возвращает бинарник ($OUT)" \
    || bad "C4: rc=$rc out=$OUT"

echo "═══ F45 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
