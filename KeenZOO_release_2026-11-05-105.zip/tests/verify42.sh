#!/bin/bash
# verify42.sh — поведенческий верификатор мини-аудита r68 (FB-121/FB-124).
# Воспроизводит живой инцидент: «sh -c body имя арг…» на Keenetic-прошивке
# теряет имя/аргументы — новая обёртка обязана работать в режиме «только -c
# body» и диагностировать отсутствие переменных явным error-статусом.
set -u
K=${1:-/home/user/KeenZOO}
GEN="$K/opt/etc/bot/generator.py"
F=/tmp/verify42
rm -rf "$F"; mkdir -p "$F"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

# V1: python-синтаксис (FB-178/аудит-46: кэш компиляции — во временный
# каталог, проверяемое дерево не трогается; прежде py_compile писал
# __pycache__ прямо в $K и скрипт удалял его же из чужого дерева).
_V1C="$F/v1pyc"; mkdir -p "$_V1C"
PYTHONPYCACHEPREFIX="$_V1C" python3 -m py_compile "$GEN" 2>/dev/null \
    && ok "V1: py_compile generator.py" \
    || bad "V1: py_compile"
rm -rf "$_V1C"

# V2: маркеры аудита и отсутствие старого argv-контракта
V2=1
grep -q 'FB-121 (аудит-42' "$GEN" || V2=0
grep -q 'FB-124 (аудит-42' "$GEN" || V2=0
[ "$(grep -c 'keenzoo-update' "$GEN" || true)" = 0 ] || V2=0
[ "$(grep -c 'keenzoo-proto-update' "$GEN" || true)" = 0 ] || V2=0
[ "$(grep -cF "'/bin/sh', '-c', body]," "$GEN" || true)" = 2 ] || V2=0
[ "$(grep -c 'env={' "$GEN" || true)" = 2 ] || V2=0
[ "$V2" = 1 ] && ok "V2: маркеры FB-121/124; argv 3-элементный ×2; env= ×2; старые argv-маркеры удалены" \
    || bad "V2: контракт статических маркеров"

Q="'''"
# V3: обёртка списков — режим прошивки (sh -c body, без argv), rc=7 → фолбэк
python3 - "$GEN" > "$F/body1.sh" <<'PYV'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
b = re.findall('body = ' + Q + '(.*?)' + Q, src, re.S)
assert len(b) == 2
sys.stdout.write(b[0])
PYV
python3 - "$GEN" > "$F/body2.sh" <<'PYV'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
b = re.findall('body = ' + Q + '(.*?)' + Q, src, re.S)
assert len(b) == 2
sys.stdout.write(b[1])
PYV
dash -n "$F/body1.sh" 2>/dev/null && dash -n "$F/body2.sh" 2>/dev/null \
    && ok "V3: dash -n обоих тел обёрток" || bad "V3: dash -n"

printf '#!/bin/sh\necho out; echo err >&2; exit 7\n' > "$F/s7.sh"; chmod +x "$F/s7.sh"
# r102: родитель панели передаёт claim всегда (с r101) — финализатор
# публикует финал только с доказательством владения (KZ98-01-контракт).
rm -f "$F/st.json" "$F/st2.json"
KZ_STATUS_FILE="$F/st.json" KZ_TMP_STATUS="$F/tm" KZ_SCRIPT="$F/s7.sh" KZ_ONLY= \
    KZ_CLAIM=v4ours sh -c "$(cat "$F/body1.sh")" > "$F/run.log" 2>&1
V3R=$?
if [ "$V3R" = 7 ] && grep -q 'out' "$F/run.log" \
    && grep -q '"status":"error"' "$F/st.json" \
    && grep -q 'exit code 7' "$F/st.json" && [ ! -e "$F/tm" ]; then
    ok "V4: обёртка списков в режиме прошивки (без argv): rc=7, фолбэк-статус (claim родителя), tmp потреблён"
else
    bad "V4: rc=$V3R st=$(cat "$F/st.json" 2>/dev/null)"
fi

# V5: обёртка списков — СТАРЫЙ режим (argv с именем) больше не нужен:
#     те же значения через env при «лишних» argv-параметрах не ломают прогон
KZ_STATUS_FILE="$F/st2.json" KZ_TMP_STATUS="$F/tm2" KZ_SCRIPT="$F/s7.sh" KZ_ONLY= \
    KZ_CLAIM=v5ours sh -c "$(cat "$F/body1.sh")" keenzoo-update A1 A2 A3 > "$F/run2.log" 2>&1
V5R=$?
if [ "$V5R" = 7 ] && grep -q 'exit code 7' "$F/st2.json"; then
    ok "V5: argv-хвост игнорируется (прошивка/здоровый sh — один результат)"
else
    bad "V5: rc=$V5R"
fi

# V6 (r100): FB-124 — окружение не дошло → честный отказ rc=3, общий
# статус НЕ тронут, родительский temp удалён (r100 KZ99-01/02; r99
# KZ98-01 — протокольная ветка; прежде обе писали прямой error-статус).
printf '%s' '{"status":"running","ts":1,"message":"victim1"}' > "$F/g1.json"
printf '%s' '{"status":"running","ts":1,"action":"x","claim":"victim2"}' > "$F/g2.json"
: > "$F/gt1"; : > "$F/gt2"
env -i PATH="$PATH" KZ_STATUS_FILE="$F/g1.json" KZ_TMP_STATUS="$F/gt1" \
    KZ_SCRIPT= KZ_ONLY= sh -c "$(cat "$F/body1.sh")" > "$F/gr1.log" 2>&1; V6A=$?
env -i PATH="$PATH" KZ_SC= KZ_ACT=x KZ_ST="$F/g2.json" KZ_TMP="$F/gt2" \
    KZ_CLAIM= sh -c "$(cat "$F/body2.sh")" > "$F/gr2.log" 2>&1; V6B=$?
if [ "$V6A" = 3 ] && [ "$V6B" = 3 ] \
    && grep -Fq 'не получила KZ_*-переменные' "$F/gr1.log" \
    && grep -Fq 'не получила KZ_*-переменные' "$F/gr2.log" \
    && grep -q '"running"' "$F/g1.json" \
    && grep -q '"claim":"victim2"' "$F/g2.json" \
    && [ ! -e "$F/gt1" ] && [ ! -e "$F/gt2" ]; then
    ok "V6: FB-124 — обе обёртки fail-closed: rc=3, диагноз в логе, чужой running цел, temp удалён (r100)"
else
    bad "V6: rc1=$V6A rc2=$V6B g1=$(cat "$F/g1.json" 2>/dev/null) g2=$(cat "$F/g2.json" 2>/dev/null) t1=$([ -e "$F/gt1" ] && echo есть) t2=$([ -e "$F/gt2" ] && echo есть)"
fi

# V7 (r100): обёртка протоколов — полный цикл с предусловием
# производства (FB-181/Z42-2): свежий running с claim + KZ_CLAIM в env
# + KZ_PY; без claim публикация обоснованно отклоняется (r99).
printf '#!/bin/sh\necho proto-out\nexit 0\n' > "$F/p.sh"; chmod +x "$F/p.sh"
printf '%s' '{"status":"running","ts":100,"action":"hysteria","claim":"v7c"}' > "$F/pst.json"
KZ_SC="$F/p.sh" KZ_ACT=hysteria KZ_ST="$F/pst.json" KZ_TMP="$F/ptm" \
    KZ_CLAIM=v7c KZ_PY="$(command -v python3)" \
    sh -c "$(cat "$F/body2.sh")" > "$F/prun.log" 2>&1
V7R=$?
if [ "$V7R" = 0 ] && grep -q 'proto-out' "$F/prun.log" \
    && grep -q '"status":"done"' "$F/pst.json" \
    && grep -q '"action":"hysteria"' "$F/pst.json" && [ ! -e "$F/ptm" ]; then
    ok "V7: полный цикл: предусловие running+claim, KZ_PY; done + action, tmp потреблён"
else
    bad "V7: rc=$V7R st=$(cat "$F/pst.json" 2>/dev/null)"
fi

# V8 (r101, P2-01): fallback списочной обёртки — владение статусом
# по claim: чужой running не затирается; свой — страховка TS-1 работает.
printf '#!/bin/sh\nexit 0\n' > "$F/s0.sh"; chmod +x "$F/s0.sh"
printf '%s' '{"status": "running", "ts": 100, "message": "новый прогон", "claim": "newowner"}' > "$F/v8st.json"
: > "$F/v8tm"
env -i PATH="$PATH" KZ_STATUS_FILE="$F/v8st.json" KZ_TMP_STATUS="$F/v8tm" \
    KZ_SCRIPT="$F/s0.sh" KZ_ONLY= KZ_CLAIM=oursclaim \
    sh -c "$(cat "$F/body1.sh")" > "$F/v8run.log" 2>&1; V8A=$?
printf '%s' '{"status": "running", "ts": 100, "message": "starting", "claim": "v8ours"}' > "$F/v8st2.json"
: > "$F/v8tm2"
env -i PATH="$PATH" KZ_STATUS_FILE="$F/v8st2.json" KZ_TMP_STATUS="$F/v8tm2" \
    KZ_SCRIPT="$F/s7.sh" KZ_ONLY= KZ_CLAIM=v8ours \
    sh -c "$(cat "$F/body1.sh")" > "$F/v8run2.log" 2>&1; V8B=$?
if [ "$V8A" = 0 ] && grep -q '"claim": "newowner"' "$F/v8st.json" \
    && grep -Fq 'claim не совпал' "$F/v8run.log" \
    && [ ! -e "$F/v8tm" ] \
    && [ "$V8B" = 7 ] && grep -q '"status":"error"' "$F/v8st2.json" \
    && grep -q 'exit code 7' "$F/v8st2.json" && [ ! -e "$F/v8tm2" ]; then
    ok "V8: fallback под claim — чужой running не тронут (диагностика в логе), свой → error «exit code 7», temp убраны (P2-01/r101)"
else
    bad "V8: rc1=$V8A rc2=$V8B st1=$(cat "$F/v8st.json" 2>/dev/null) st2=$(cat "$F/v8st2.json" 2>/dev/null)"
fi

# V9 (r102, KZ101-01): транзакционный финализатор — конкурентная публикация
# в окне «проверка→замена» (интерпозер date) больше не затирается.
mkdir -p /opt/bin
cat > /opt/bin/date <<'V9DATE'
#!/bin/sh
printf '%s' '{"status":"running","ts":1793999999,"message":"start"}' > "$KZ_STATUS_FILE"
exec /bin/date "$@"
V9DATE
chmod +x /opt/bin/date
printf '%s' '{"status": "running", "ts": 100, "message": "starting", "claim": "v9ours"}' > "$F/v9st.json"
: > "$F/v9tm"
env -i PATH="$PATH" KZ_STATUS_FILE="$F/v9st.json" KZ_TMP_STATUS="$F/v9tm" \
    KZ_SCRIPT="$F/s7.sh" KZ_ONLY= KZ_CLAIM=v9ours \
    sh -c "$(cat "$F/body1.sh")" > "$F/v9run.log" 2>&1; V9A=$?
rm -f /opt/bin/date
rmdir /opt/bin 2>/dev/null
if [ "$V9A" = 7 ] \
    && [ "$(cat "$F/v9st.json")" = '{"status":"running","ts":1793999999,"message":"start"}' ] \
    && grep -Fq 'claim не совпал' "$F/v9run.log" \
    && [ ! -e "$F/v9tm" ] \
    && [ -f "$F/v9st.json.lockfile" ]; then
    ok "V9: финализатор транзакционен — чужой running из окна «проверка→замена» (интерпозер date) сохранён байт-в-байт, диагностика в логе, temp убран, lock-файл стабилен (KZ101-01/r102)"
else
    bad "V9: rc=$V9A st=$(cat "$F/v9st.json" 2>/dev/null) log=$(tail -1 "$F/v9run.log" 2>/dev/null)"
fi

# V10 (r103, P2-01/P2-02/P3-D): fail-closed writer'ы статуса списков:
# (a) ветка locked не трогает чужой статус;
# (b) write_status при отказе python-хелпера не публикует незащищённый статус;
# (c) body экспортирует STATUS_FILE child-updater'у.
UPD103="$K/opt/bin/unblock_update.sh"
mkdir -p "$F/v10lock"; echo $$ > "$F/v10lock/pid"
printf '%s' '{"status":"running","ts":100,"message":"starting","claim":"v10act"}' > "$F/v10st.json"
sed 's/^    sleep 2$/    sleep 0/' "$UPD103" > "$F/uu_fast.sh"
V10_BEFORE="$(cat "$F/v10st.json")"
env -i PATH="$PATH" HOME=/root STATUS_FILE="$F/v10st.json" \
    SCRIPT_LOCK="$F/v10lock" sh "$F/uu_fast.sh" > "$F/v10out" 2> "$F/v10err"
V10_R1=$?
V10_OK1=0
[ "$V10_R1" = 1 ] && [ "$(cat "$F/v10st.json")" = "$V10_BEFORE" ] \
    && grep -Fq 'lock занят живым прогоном' "$F/v10err" && V10_OK1=1

sed -n '/^write_status() {/,/^}/p' "$UPD103" > "$F/v10ws.sh"
printf '%s' '{"status":"running","ts":1,"message":"active","claim":"v10act2"}' > "$F/v10st2.json"
V10_B2="$(cat "$F/v10st2.json")"
env -i PATH="$PATH" HOME=/root STATUS_FILE="$F/v10st2.json" KZ_PY=/bin/false \
    sh -c ". '$F/v10ws.sh'; write_status error late" > "$F/v10out2" 2> "$F/v10err2"
V10_R2=$?
V10_OK2=0
[ "$V10_R2" = 0 ] && [ "$(cat "$F/v10st2.json")" = "$V10_B2" ] \
    && grep -Fq 'хелпер статуса недоступен' "$F/v10err2" && V10_OK2=1

printf '#!/bin/sh\nif [ "$STATUS_FILE" = "/custom/v10.json" ]; then echo CHILD_OK; else echo CHILD_BAD; fi\nexit 0\n' > "$F/v10env.sh"
chmod +x "$F/v10env.sh"
: > "$F/v10tm3"
env -i PATH="$PATH" HOME=/root KZ_STATUS_FILE=/custom/v10.json \
    KZ_TMP_STATUS="$F/v10tm3" KZ_SCRIPT="$F/v10env.sh" KZ_ONLY= KZ_CLAIM=v10c \
    sh -c "$(cat "$F/body1.sh")" > "$F/v10out3" 2>&1
V10_OK3=0
grep -q CHILD_OK "$F/v10out3" && V10_OK3=1

if [ "$V10_OK1" = 1 ] && [ "$V10_OK2" = 1 ] && [ "$V10_OK3" = 1 ]; then
    ok "V10: fail-closed writer'ы (P2-01: locked без записи, P2-02b: write_status без legacy, P3-D: export STATUS_FILE в body) (r103)"
else
    bad "V10: locked=$V10_OK1 ws=$V10_OK2 exp=$V10_OK3"
fi

# V11 (r105, P3-01/P3-02):
# (a) symlink на пути UPDATE_LOG_FILE игнорируется (цель не тронута);
# (b) body экспортирует UPDATE_LOG_FILE child-updater'у;
# (c) -B -S в хелперах.
touch "$F/v11_target"
ln -s "$F/v11_target" "$F/v11_symlink.log"
env -i PATH="$PATH" HOME=/root STATUS_FILE="$F/v10st.json" \
    UPDATE_LOG_FILE="$F/v11_symlink.log" SCRIPT_LOCK="$F/v10lock" \
    sh "$F/uu_fast.sh" > /dev/null 2>&1
V11_OK1=0
[ ! -s "$F/v11_target" ] && V11_OK1=1

printf '#!/bin/sh\nif [ "$UPDATE_LOG_FILE" = "/custom/v11.log" ]; then echo LOG_OK; else echo LOG_BAD; fi\nexit 0\n' > "$F/v11log.sh"
chmod +x "$F/v11log.sh"
: > "$F/v11tm"
env -i PATH="$PATH" HOME=/root KZ_STATUS_FILE=/custom/v11.json \
    KZ_UPDATE_LOG_FILE=/custom/v11.log \
    KZ_TMP_STATUS="$F/v11tm" KZ_SCRIPT="$F/v11log.sh" KZ_ONLY= KZ_CLAIM=v11c \
    sh -c "$(cat "$F/body1.sh")" > "$F/v11out" 2>&1
V11_OK2=0
grep -q LOG_OK "$F/v11out" && V11_OK2=1

V11_OK3=0
[ "$(grep -c '\-B \-S \-c' "$GEN" || true)" = 2 ] \
    && [ "$(grep -c '\-B \-S \-c' "$UPD103" || true)" = 1 ] && V11_OK3=1

if [ "$V11_OK1" = 1 ] && [ "$V11_OK2" = 1 ] && [ "$V11_OK3" = 1 ]; then
    ok "V11: r105 — symlink-защита журнала locked, export UPDATE_LOG_FILE в body, флаги -B -S в хелперах"
else
    bad "V11: symlink=$V11_OK1 log_exp=$V11_OK2 bs=$V11_OK3"
fi

echo "═══ VERIFY42 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
