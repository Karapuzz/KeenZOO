#!/bin/bash
# f47_audit.sh v13 — приёмочный стенд правок аудитов 18/19/20/22/23/24/25/26/27/28/29 (r45→…→r54→кандидат r55):
#  R. Аудит-26 (внешние отчёты по r51): S57-гейт заглушки с портом
#     (K51-1), PID-личность при останове (K51-3), HTTP-гейт — обе
#     копии, 6 форм opkg.conf + fail-closed на нечитаемом (R51-02),
#     мемоизация opkg list-installed (K51-2), порог Range (R51-07),
#     SKIPPED_HTTP со всех точек (R51-05), SNI-исключение needs_key
#     (R51-06), CFG_STATE web_username + баннер (R50-UX-1), LAN-lock
#     (N51-2), _auth_cmp (FB-33), cross-list warning (N51-1),
#     benchmark-диапазон (R50-FW-1), wget-warn (FB-34), маркеры
#  U. Аудит-29 (внешний отчёт по r54): гонка записи списков (общий
#     pid-tmp + несериализованный read-modify-write: 20 параллельных
#     POST давали 13×500 и 1 запись из 20) — mkstemp + _LISTS_WRITE_LOCK;
#     _write_enabled — тот же pid-tmp; счётчик неудачных входов считает
#     только предъявленные неверные креды (без Authorization — 401 без
#     счётчика); паритет 4 валидаторов на «auth отсутствует» (needs_key
#     с флагом hysteria, placeholders с require_auth)
#  T. Аудит-28 (внешний отчёт по r53): регресс JS addToList (лишняя })
#     ловится рендером + node --check; HTTP-гейт — 11 форм opkg.conf ×
#     обе копии (кавычки вокруг типа, dist/dist/gz, каталог); порядок
#     «модули → проба» и вердикт пробы в решении deploy (|0 не «✅»);
#     паритет 4 валидаторов hysteria; lookup-add: 1 чтение + лимит;
#     check_updates «проверка не удалась»; PID-личность по /proc/exe;
#     баннер «панель не настроена»; _kz_pkg_installed литерально; Range
#     по коду 206; маркеры FB-43..FB-51
#  S. Аудит-27 (внешний отчёт по r52): проба iptables вставкой правила
#     (K52-7), минифицированный JSON в детекторах заглушек (K52-1),
#     честный вердикт dnsmasq при отсутствии (K52-4), JS warning (K52-3),
#     снимок списков cross-check (K52-6), opkg list-installed ×1 (K52-5),
#     tty-вывод check_updates (N52-8), маркеры FB-35..41
#  Q. Аудит-25 (внешние отчёты по r50): декоратор before_request на
#     security_checks (P0), семантика _auth_fails (K50-2/A9-5), гейт
#     заглушки hysteria в S57 (K50-3), покрытие HTTP-гейта всеми
#     opkg install/upgrade (A9-2), Origin my.keenetic.net/loopback
#     (K50-4/A9-4), канонический путь hysteria (K50-5), форма src
#     фида (A9-3), честность заметки Range (A9-6), учёт гейт-пропусков
#     в сводке (A9-7), фильтр токена-заглушки (K50-7), shlex (K50-8),
#     кэш LAN-адресов (K50-9)
#  P. Аудит-24 (повторный сбой установки, rc=3): HTTP-политика перенесена
#     в точку риска — гейт перед сетевой opkg install (установленное
#     пропускается без сети; отсутствующее при http-фиде без ALLOW —
#     warn+пропуск); rc=3 → warn+продолжение; одиночный OFFLINE-флаг
#     самодостаточен; http-проба с ensure_dns и повтором (FB-8)
#  N. Аудит-23 (сбой установки на устройстве): проверка фидов Entware —
#     https без curl = «не проверено» (не бракуется), Range-проба 256Б,
#     недоступность фидов не убивает установку (авторитет — opkg update;
#     политический rc=3 для http-фида — с явным обходом ALLOW-флагом)
#  M. Аудит-22: O-1 (Origin: SSH-туннель 127.0.0.1:любой-порт при
#     loopback-клиенте, альтернативные LAN-IP, allowed_origin_hosts;
#     request.host не возвращён), TS-1 (tmp-статус не переживает
#     прогон: trap в body, очистка при отказе Popen), AF-1 (жёсткий
#     кап _auth_fails 256), SN-1 (нормализация fallback-подсетей,
#     логирование отказов ACCEPT) — поведенчески, экстракцией helpers
#  L. Аудит-21: FW-1b (зачистка legacy-blanket в setup_firewall,
#     без fallback на ALLOWED_SUBNETS), PF-1 (preflight панели —
#     только flask+markupsafe; текст deploy раздельный), RM-1
#     (uninstall_netfilter предупреждает об остатке чужих ACCEPT
#     на :8080 — поведенчески, на моках секции A)
#  K. Аудит-20: FW-1 (нет blanket-RFC1918 в setup_firewall, подсети
#     LAN как в блоке B7 хука), TW-1 (нет root-обёрток-файлов в /tmp:
#     sh -c + O_NOFOLLOW + mkstemp; фолбэк-статус обёртки), RL-1
#     (ротация: триггер по размеру, KEEP — цель), TG-1 (общая
#     tg_send_message: urlencode + токен вне cmdline), CS-1
#     (Origin: hostname-whitelist, чистка _auth_fails), BC-1 (ранний
#     chmod 0600 bot_config.py после apply)
#  A. R47-1+R48-2: uninstall_netfilter на моках iptables/ip/ipset —
#     проектные правила сняты (negated-DROP с -i и исключениями, DNS
#     RETURN udp/53, ACCEPT 8080 по фактическим подсетям), ЧУЖИЕ правила
#     на 8080 (голый ACCEPT / udp / публичный -s) целы, прочие чужие целы,
#     регрессия прежних форм снятия, идемпотентность
#  B. N-5+R48-3: start() из S99generator ЦЕЛИКОМ (не «до первого fi»):
#     preflight до is_running-выхода; при ненастроенном конфиге и живом
#     процессе — останов; already-running при настроенном; сломанный
#     python-конфиг не отсекается (grep не исполняет код)
#  C. R45-4+R48-1: советы про секреты — реальное поле token, исключение
#     заглушки ТОКЕН_БОТА, раздельные советы (токен / пароль панели)
#  D. R48-6: сводка deploy считает ACCEPT 8080 двухступенчатым grep'ом
#     (форма хука с -s между --dport и -j видна)
#  E. R48-8: сводка различает «панель не настроена» и «не запустилась»
#  F. R48-9: test_udp_tunnels — процесс не запущен => warn, а не FAIL
#  G. R48-5: просмотр списка в боте ≡ рендеру сохранения (R46-2)
#  H. R48-7: wsSettings.host вместо headers.Host (шаблон + конвертер)
#  J. аудит-19: R49-1 (без двойного запуска unblock_update в deploy,
#     boot-путь S99unblock цел), R49-2 (версия hysteria из баннера)
#  I. маркеры правок, синтаксис, отсутствие bot_token, JSON шаблона,
#     хук 100-redirect.sh не тронут; A6-4: pidof-фолбэк через /proc
set -u
K=${1:-/home/user/KeenZOO}
F=/tmp/f47chk
rm -rf "$F"; mkdir -p "$F/bin"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); echo "[OK]   $1"; }
bad(){ FAIL=$((FAIL+1)); echo "[FAIL] $1"; }

echo "═══ A. R47-1+R48-2: uninstall_netfilter на моках ═══"

# мок iptables: состояние в файле, формат table|chain|-A chain spec
cat > "$F/bin/iptables" <<'EOF'
#!/bin/bash
R=${IPT_MOCK_STATE:?}
T=filter
args=("$@")
i=0
while [ $i -lt ${#args[@]} ]; do
    case "${args[$i]}" in
        -t) T=${args[$((i+1))]}; i=$((i+2)); continue ;;
        -w) i=$((i+1)); continue ;;
    esac
    break
done
act=${args[$i]}
chain=${args[$((i+1))]}
spec=""
j=$((i+2))
while [ $j -lt ${#args[@]} ]; do
    spec="$spec ${args[$j]}"
    j=$((j+1))
done
spec=${spec# }
case "$act" in
    -S)
        awk -F'|' -v t="$T" -v c="$chain" \
            '$1==t && $2==c {sub(/^[^|]*\|[^|]*\|-A [^ ]* /,""); print "-A " c " " $0}' "$R"
        ;;
    -D)
        key="${T}|${chain}|-A ${chain} ${spec}"
        if grep -qxF "$key" "$R"; then
            grep -vx "$key" "$R" > "$R.tmp" && mv "$R.tmp" "$R"
            exit 0
        fi
        exit 1
        ;;
    -C)
        grep -qxF "${T}|${chain}|-A ${chain} ${spec}" "$R" && exit 0
        exit 1
        ;;
esac
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ip6tables"
cat > "$F/bin/ip" <<'EOF'
#!/bin/sh
[ "$1" = "link" ] && [ "$2" = "show" ] && {
    case "$3" in br0|nwg0) exit 0 ;; *) exit 1 ;; esac
}
if [ "$1" = "-4" ] && [ "$2" = "addr" ]; then
    if [ "$4" = "br0" ]; then
        printf '2: br0: <BROADCAST,MULTICAST,UP> mtu 1500\n    inet 192.168.1.1/24 brd 192.168.1.255 scope global br0\n'
    fi
    exit 0
fi
[ "$1" = "rule" ] && exit 1
[ "$1" = "route" ] && exit 0
exit 0
EOF
cat > "$F/bin/ipset" <<'EOF'
#!/bin/sh
if [ "$1" = "list" ] && [ "$2" = "-n" ]; then
    printf 'unblockdns\nunblockhysteria\nunblockrouter\nunblocksh\nunblocktor\nunblocktroj\nunblockvless\n'
fi
exit 0
EOF
# моки для секции E: netstat управляется маркером, ss всегда молчит
cat > "$F/bin/netstat" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/net8080 ] || exit 1
printf 'tcp 0 0 0.0.0.0:8080 0.0.0.0:* LISTEN\n'
exit 0
EOF
printf '#!/bin/sh\nexit 1\n' > "$F/bin/ss"
# мок pidof для секции F: маркер pidup => rc 0
cat > "$F/bin/pidof" <<'EOF'
#!/bin/sh
[ -f /tmp/f47chk/pidup ] && exit 0
exit 1
EOF
chmod +x "$F/bin/"*

# фикстура правил: проектные (все формы) + чужие (должны уцелеть),
# в т.ч. ТРИ чужих на 8080 (R48-2)
cat > "$F/rules.txt" <<'EOF'
nat|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -j REDIRECT --to-port 9141
nat|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockvless dst -j REDIRECT --to-port 10810
nat|PREROUTING|-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1
nat|PREROUTING|-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP
mangle|PREROUTING|-A PREROUTING -p tcp -m set --match-set unblockhysteria dst -j DROP
mangle|PREROUTING|-A PREROUTING -p udp --dport 53 -j RETURN
mangle|PREROUTING|-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000
mangle|PREROUTING|-A PREROUTING -p udp -m set --match-set unblockrouter dst -j MARK --set-mark 0xd1001/0xd1001
mangle|PREROUTING|-A PREROUTING -m conntrack --ctstate NEW -m set --match-set unblocktor dst -j CONNMARK --set-mark 0xd1001
mangle|PREROUTING|-A PREROUTING -j CONNMARK --restore-mark
mangle|PREROUTING|-A PREROUTING -p tcp --dport 5000 -j DROP
filter|INPUT|-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 192.168.0.0/16 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p udp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 8080 -j DROP
filter|INPUT|-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT
filter|INPUT|-A INPUT -i br0 -p tcp --dport 9141 -j ACCEPT
filter|INPUT|-A INPUT -p tcp --dport 22 -j ACCEPT
nat|OUTPUT|-A OUTPUT -o lo -j RETURN
nat|OUTPUT|-A OUTPUT -d 192.168.0.0/16 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x2000000 -j RETURN
mangle|OUTPUT|-A OUTPUT -m mark --mark 0x9999999 -j RETURN
EOF
cp "$F/rules.txt" "$F/state.txt"

awk '/^uninstall_netfilter\(\) \{/,/^\}/' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/un.s"
UN_LINES=$(wc -l < "$F/un.s")
[ "$UN_LINES" -gt 150 ] \
    && ok "A0: экстракт uninstall_netfilter (${UN_LINES} строк)" \
    || bad "A0: экстракт подозрительно мал (${UN_LINES} строк)"

cat > "$F/runA.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runA.sh"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA.log" 2>&1
rcA=$?
LEFT=$(cat "$F/state.txt")
chk_gone(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 1 || return 0; }
chk_here(){ printf '%s\n' "$LEFT" | grep -qF -- "$1" && return 0 || return 1; }

[ "$rcA" = 0 ] && [ "$(grep -c '^RC=0$' "$F/runA.log")" = 1 ] \
    && ok "A1: uninstall_netfilter отработала rc=0" \
    || bad "A1: rc=$rcA ($(tail -2 "$F/runA.log"))"
chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblocktor dst -m set ! --match-set unblockvless dst -m set ! --match-set unblockhysteria dst -j DROP' \
    && chk_gone '-A PREROUTING -i nwg0 -p udp -m set --match-set unblocktroj dst -m set ! --match-set unblockvless dst -j DROP' \
    && ok "A2: negated-DROP UDP-guard снят (обе формы)" \
    || bad "A2: guard-DROP остался: $(printf '%s\n' "$LEFT" | grep 'unblocktor dst\|unblocktroj dst' | grep DROP)"
chk_gone '-A PREROUTING -p udp --dport 53 -j RETURN' \
    && ok "A3: DNS RETURN (mangle, udp/53) снят" \
    || bad "A3: DNS RETURN остался"
NACC=$(printf '%s\n' "$LEFT" | grep -c -- '--dport 8080 -j ACCEPT' || true)
[ "$NACC" = 3 ] \
    && ok "A4: проектные ACCEPT 8080 (5 приватных -s, включая 169.254) сняты, осталось ровно 3 чужих" \
    || bad "A4: осталось ACCEPT 8080: $NACC (ожидалось 3 чужих)"
chk_gone '-A INPUT -s 169.254.10.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4c: link-local ACCEPT (169.254.10.0/24) снят (A6-1)" \
    || bad "A4c: link-local ACCEPT пережил удаление"
chk_here '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -p udp --dport 8080 -j ACCEPT' \
    && chk_here '-A INPUT -s 203.0.113.0/24 -p tcp --dport 8080 -j ACCEPT' \
    && ok "A4b: чужие 8080 целы: голый tcp / udp / публичный -s (R48-2)" \
    || bad "A4b: чужое 8080-правило удалено: $(printf '%s\n' "$LEFT" | grep -- '--dport 8080')"
chk_gone '-A PREROUTING -p udp -m set --match-set unblocksh dst -j DROP' \
    && chk_gone '-A PREROUTING -i br0 -p udp -m set --match-set unblockvless dst -j TPROXY --on-ip 127.0.0.1 --on-port 10810 --tproxy-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -j CONNMARK --restore-mark' \
    && chk_gone '-A PREROUTING -p udp -m socket -j MARK --set-mark 0x1000000/0x1000000' \
    && chk_gone '-A PREROUTING -p udp --dport 53 -j DNAT --to-destination 192.168.1.1' \
    && chk_gone '-A OUTPUT -m mark --mark 0x2000000 -j RETURN' \
    && chk_gone '-A INPUT -p tcp --dport 8080 -j DROP' \
    && chk_gone '-A INPUT -i lo -p tcp --dport 10810 -j ACCEPT' \
    && ok "A5: регрессия прежних форм: REDIRECT/TPROXY/простой DROP/CONNMARK/socket/DNAT/OUTPUT/8080-DROP сняты" \
    || bad "A5: что-то из прежних форм осталось"
chk_here '-A PREROUTING -p tcp --dport 5000 -j DROP' \
    && chk_here '-A INPUT -p tcp --dport 22 -j ACCEPT' \
    && chk_here '-A PREROUTING -p tcp --dport 9999 -j DNAT --to-destination 1.2.3.4' \
    && chk_here '-A OUTPUT -m mark --mark 0x9999999 -j RETURN' \
    && ok "A6: прочие чужие правила целы (DROP 5000 / ACCEPT 22 / DNAT 9999 / RETURN 0x9999999)" \
    || bad "A6: чужое правило удалено"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runA.sh" > "$F/runA2.log" 2>&1
rcA2=$?
LEFT2=$(cat "$F/state.txt")
if [ "$rcA2" = 0 ] && [ "$LEFT2" = "$LEFT" ]; then
    ok "A7: идемпотентность — повторный прогон rc=0, состояние не изменилось"
else
    bad "A7: rc=$rcA2, дельта: $(diff <(printf '%s\n' "$LEFT") <(printf '%s\n' "$LEFT2") | head -5)"
fi

echo "═══ B. N-5+R48-3: start() целиком (S99generator) ═══"
awk '/^start\(\) \{/,/^\}/' "$K/opt/etc/init.d/S99generator" > "$F/start.fn"
grep -q 'R48-3 (аудит-18)' "$F/start.fn" && grep -q 'SKIPPED' "$F/start.fn" \
    && ok "B0: экстракт start() ($(wc -l < "$F/start.fn") строк), preflight внутри" \
    || bad "B0: экстракт неполон"
runB(){
    CFG="$1"; ISRUN="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/start.fn" > "$F/start.case"
    {
        echo 'NAME=generator'
        echo "PIDFILE=$F/pid"
        echo "LOGFILE=$F/gen.log"
        echo "WORKDIR=$F/wd"
        echo "APP=$F/app"
        echo "is_running(){ [ -f '$F/isrun' ]; }"
        echo "kill_app(){ echo kill >> '$F/kills'; }"
        echo 'find_python(){ printf "/bin/echo\n"; }'
        echo ". '$F/start.case'"
        echo 'start'
        echo 'echo "RC=$?"'
    } > "$F/runB.sh"
    rm -f "$F/kills" "$F/pid" "$F/isrun" "$F/gen.log"
    [ "$ISRUN" = 1 ] && { : > "$F/isrun"; echo 12345 > "$F/pid"; }
    mkdir -p "$F/wd"; : > "$F/app"
    ( bash "$F/runB.sh" ) 2>/dev/null
}
mkdir -p "$F/cfg"
printf "web_username = 'admin'\nweb_password = ''\n" > "$F/cfg/empty_pass.py"
printf "web_username = ''\nweb_password = 'x'\n" > "$F/cfg/empty_user.py"
printf "web_username = 'admin'\nweb_password = 'secret'\n" > "$F/cfg/ok.py"
printf "web_username = 'admin'\nweb_password = 'x'\nэтот файл не python !!!\n" > "$F/cfg/broken.py"
O1=$(runB "$F/cfg/empty_pass.py" 0)
printf '%s' "$O1" | grep -q 'SKIPPED' && [ -z "$(printf '%s' "$O1" | grep 'Stopping')" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B1: пустой пароль, процесса нет → SKIPPED, никто не тронут" \
    || bad "B1: $O1 kills=$(cat "$F/kills" 2>/dev/null)"
O2=$(runB "$F/cfg/empty_pass.py" 1)
printf '%s' "$O2" | grep -q 'Stopping' && printf '%s' "$O2" | grep -q 'SKIPPED' \
    && [ -f "$F/kills" ] && [ ! -f "$F/pid" ] \
    && ok "B2: пустой пароль, панель жива → останов (kill_app, pidfile снят) + SKIPPED (R48-3)" \
    || bad "B2: $O2 kills=$(cat "$F/kills" 2>/dev/null) pid=$(cat "$F/pid" 2>/dev/null)"
O3=$(runB "$F/cfg/ok.py" 1)
printf '%s' "$O3" | grep -q 'already running' && [ -z "$(printf '%s' "$O3" | grep SKIPPED)" ] \
    && [ ! -f "$F/kills" ] \
    && ok "B3: настроено, панель жива → already running, без SKIPPED/kill" \
    || bad "B3: $O3"
O4=$(runB "$F/cfg/ok.py" 0)
[ -z "$(printf '%s' "$O4" | grep SKIPPED)" ] && printf '%s' "$O4" | grep -q 'Starting' \
    && ok "B4: настроено, процесса нет → preflight пройден, старт (Starting…)" \
    || bad "B4: $O4"
O5=$(runB "$F/cfg/broken.py" 0)
[ -z "$(printf '%s' "$O5" | grep SKIPPED)" ] && printf '%s' "$O5" | grep -q 'Starting' \
    && ok "B5: сломанный python-конфиг НЕ отсекается (grep не исполняет код)" \
    || bad "B5: $O5"
L1=$(grep -n 'web_username' "$F/start.fn" | head -1 | cut -d: -f1)
L2=$(grep -n 'if is_running; then' "$F/start.fn" | head -1 | cut -d: -f1)
[ -n "$L1" ] && [ -n "$L2" ] && [ "$L1" -lt "$L2" ] \
    && ok "B6: preflight стоит ДО is_running-выхода (строки $L1 < $L2)" \
    || bad "B6: порядок нарушен ($L1 vs $L2)"

echo "═══ C. R45-4+R48-1: советы про секреты ═══"
awk '/# R45-4 \(аудит-17\)/{f=1} f{print} f && /^fi$/{n++; if (n==2) exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/sec.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/sec.body" | grep -c '__CFG__')
[ "$SUBS" = 3 ] \
    && ok "C0: экстракт блока секретов, 3 grep-условия ведут на bot_config.py" \
    || bad "C0: замен путей = $SUBS (ожидалось 3)"
runC(){
    CFG="$1"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/sec.body" > "$F/sec.run"
    ( . "$F/sec.run" )
}
printf "token = '123456:REAL-KEY'\nweb_password = ''\n" > "$F/cfg/tok.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = 'p'\n" > "$F/cfg/ph.py"
printf "token = '123456:REAL-KEY'\nweb_password = 'p'\n" > "$F/cfg/both.py"
printf "token = 'ТОКЕН_БОТА'\nweb_password = ''\n" > "$F/cfg/none.py"
printf "token='ТОКЕН_БОТА'\n" > "$F/cfg/ph2.py"
C1=$(runC "$F/cfg/tok.py")
printf '%s' "$C1" | grep -q 'перевыпустите токен' && [ -z "$(printf '%s' "$C1" | grep 'смените пароль')" ] \
    && ok "C1: токен заполнен, пароль пуст → совет про токен, без совета про пароль" \
    || bad "C1: $C1"
C2=$(runC "$F/cfg/ph.py")
printf '%s' "$C2" | grep -q 'смените пароль' && [ -z "$(printf '%s' "$C2" | grep 'перевыпустите токен')" ] \
    && ok "C2: заглушка токена, пароль заполнен → совет про пароль, без токена" \
    || bad "C2: $C2"
C3=$(runC "$F/cfg/both.py")
printf '%s' "$C3" | grep -q 'перевыпустите токен' && printf '%s' "$C3" | grep -q 'смените пароль' \
    && ok "C3: оба заполнены → оба совета" \
    || bad "C3: $C3"
C4=$(runC "$F/cfg/none.py"); C5=$(runC "$F/cfg/missing.py"); C6=$(runC "$F/cfg/ph2.py")
[ -z "$C4" ] && [ -z "$C5" ] && [ -z "$C6" ] \
    && ok "C4: заглушка+пустой пароль / нет файла / заглушка без пробелов → тишина" \
    || bad "C4: напечатано: C4=[$C4] C5=[$C5] C6=[$C6]"
NB=$(grep 'bot_token' "$K/opt/bin/deploy_bypass.sh" | grep -vc '^[[:space:]]*#' || true)
[ "${NB:-0}" = 0 ] \
    && ok "C5: несуществующего поля bot_token больше нет вне комментариев" \
    || bad "C5: bot_token вне комментариев: $NB"

echo "═══ D. R48-6: подсчёт ACCEPT 8080 в сводке ═══"
awk '/# R48-6 \(аудит-18\)/{f=1} f{ if ($0 ~ /^if \[/) exit; print }' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.block"
grep -c 'WEB_ACC=' "$F/webacc.block" | grep -q '^2$' \
    && ok "D0: экстракт присваивания WEB_ACC (обе строки)" \
    || bad "D0: экстракт неполон"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 10.6.0.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
{ echo 'IPT_BIN=/tmp/f47chk/bin/ipt_web'; cat "$F/webacc.block"; echo 'echo "WEB_ACC=$WEB_ACC"'; } > "$F/runD.sh"
D1=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=' )
[ "$D1" = "WEB_ACC=4" ] \
    && ok "D1: форма хука с -s считается (4 ACCEPT из 5 правил; старая склейка дала бы 1)" \
    || bad "D1: $D1"
printf '#!/bin/sh\nexit 0\n' > "$F/bin/ipt_web"
D2=$(bash "$F/runD.sh" 2>/dev/null | grep '^WEB_ACC=')
[ "$D2" = "WEB_ACC=0" ] \
    && ok "D2: пустой вывод → WEB_ACC=0 (без unbound variable/ошибок)" \
    || bad "D2: $D2"

# A6-2: счётчик остаётся фактом, но вердикт «Доступ из LAN» не выдаётся
awk '/# R48-6 \(аудит-18\)/{f=1} f{print} f && /^fi$/{exit}' \
    "$K/opt/bin/deploy_bypass.sh" > "$F/webacc.full"
runD3(){
    MOCK="$1"
    {
        echo "IPT_BIN=$MOCK"
        echo 'warn(){ echo "WARN: $*"; }'
        cat "$F/webacc.full"
    } > "$F/runD3.sh"
    bash "$F/runD3.sh" 2>/dev/null
}
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 192.168.1.0/24 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT' \
 '-A INPUT -p tcp --dport 8080 -j DROP'
exit 0
EOF
chmod +x "$F/bin/ipt_web"
D3=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D3" | grep -q 'Найдены ACCEPT-правила на :8080 (2)' \
    && [ -z "$(printf '%s' "$D3" | grep 'Доступ из LAN')" ] \
    && ok "D3: WEB_ACC>0 → ℹ️ «Найдены ACCEPT-правила…», без вердикта «Доступ из LAN» (A6-2)" \
    || bad "D3: $D3"
cat > "$F/bin/ipt_web" <<'EOF'
#!/bin/sh
printf '%s\n' \
 '-A INPUT -s 127.0.0.0/8 -p tcp --dport 8080 -j ACCEPT'
exit 0
EOF
D4=$(runD3 "$F/bin/ipt_web")
printf '%s' "$D4" | grep -q 'Найдены ACCEPT-правила на :8080 (1)' \
    && [ -z "$(printf '%s' "$D4" | grep 'Доступ из LAN')" ] \
    && ok "D4: только loopback-ACCEPT → ℹ️ (не «доступ из LAN разрешён»)" \
    || bad "D4: $D4"

echo "═══ E. R48-8: сводка про порт 8080 ═══"
awk '/# Панель обязана СЛУШАТЬ/,/^fi$/' "$K/opt/bin/deploy_bypass.sh" > "$F/lstn.body"
SUBS=$(sed 's|/opt/etc/bot/bot_config.py|__CFG__|g' "$F/lstn.body" | grep -c '__CFG__')
[ "$SUBS" = 2 ] \
    && ok "E0: экстракт блока слушателя, оба условия (A6-3) ведут на bot_config.py" \
    || bad "E0: замен путей = $SUBS (ожидалось 2)"
runE(){
    CFG="$1"; NET="$2"
    sed "s|/opt/etc/bot/bot_config.py|$CFG|g" "$F/lstn.body" > "$F/lstn.run"
    rm -f "$F/net8080"
    [ "$NET" = 1 ] && : > "$F/net8080"
    (
        PATH="$F/bin:/usr/bin:/bin"
        warn(){ echo "WARN: $*"; }
        . "$F/lstn.run"
    )
}
E1=$(runE "$F/cfg/ok.py" 1)
printf '%s' "$E1" | grep -q '8080 слушается' \
    && ok "E1: порт слушается → ✅ (пароль не важен)" \
    || bad "E1: $E1"
E2=$(runE "$F/cfg/ok.py" 0)
printf '%s' "$E2" | grep -q 'НЕ слушается' && [ -z "$(printf '%s' "$E2" | grep 'не настроена')" ] \
    && ok "E2: пароль задан, порт молчит → предупреждение с логом" \
    || bad "E2: $E2"
E3=$(runE "$F/cfg/empty_pass.py" 0)
printf '%s' "$E3" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E3" | grep 'НЕ слушается')" ] \
    && ok "E3: пароль пуст, порт молчит → ℹ️ «не настроена», без поиска ошибки в логе (R48-8)" \
    || bad "E3: $E3"
E4=$(runE "$F/cfg/missing.py" 0)
printf '%s' "$E4" | grep -q 'не настроена' \
    && ok "E4: конфига нет → ℹ️ «не настроена»" \
    || bad "E4: $E4"
E5=$(runE "$F/cfg/empty_user.py" 0)
printf '%s' "$E5" | grep -q 'не настроена' && [ -z "$(printf '%s' "$E5" | grep 'НЕ слушается')" ] \
    && ok "E5: пустой web_username + пароль → «не настроена», не «НЕ слушается» (A6-3)" \
    || bad "E5: $E5"

echo "═══ F. R48-9: градация test_udp_tunnels ═══"
awk '/# R48-9 \(аудит-18\)/{f=1} f{print} f && /^    fi$/{n++; if (n==4) exit}' \
    "$K/opt/bin/test_udp_tunnels.sh" > "$F/udp.block"
grep -q '_proc_up' "$F/udp.block" && grep -q 'A6-4 (аудит-19)' "$F/udp.block" \
    && [ "$(grep -c 'не проверяем' "$F/udp.block")" = 2 ] \
    && ok "F0: экстракт сокетных проверок с градацией и /proc-фолбэком" \
    || bad "F0: экстракт неполон"
runF(){
    LU="$1"; LT="$2"; PUP="$3"
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    [ "$PUP" = 1 ] && : > "$F/pidup"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"$LU\"; _lt=\"$LT\""
        echo ". '$F/udp.block'"
    } > "$F/runF.sh"
    ( PATH="$F/bin:/usr/bin:/bin" bash "$F/runF.sh" ) 2>/dev/null
}
runF "10.0.0.1:10810" "10.0.0.1:10810" 1
[ "$(wc -l < "$F/f.ok")" = 3 ] && [ ! -f "$F/f.bad" ] \
    && ok "F1: процесс жив, сокеты слушают → 3×OK" \
    || bad "F1: ok=$(cat "$F/f.ok" 2>/dev/null | wc -l) bad=$(cat "$F/f.bad" 2>/dev/null | wc -l)"
runF "" "10.0.0.1:10810" 1
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" \
    && ok "F2: процесс жив, udp-сокета нет → FAIL сохранён (реальный дефект)" \
    || bad "F2: bad=$(cat "$F/f.bad" 2>/dev/null)"
runF "" "" 0
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F3: процесс не запущен → warn, сокеты не проверяем, FAIL нет (R48-9)" \
    || bad "F3: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

# A6-4: PATH без pidof вовсе — живость через /proc-скан (имитатор xray)
_BASH4="$(command -v bash)"
mkdir -p "$F/bin2"
ln -sf "$(command -v tr)" "$F/bin2/tr"
ln -sf "$(command -v head)" "$F/bin2/head"
cp /bin/sleep "$F/bin2/xray" && chmod +x "$F/bin2/xray"
"$F/bin2/xray" 30 & _IMPID=$!
runFP(){
    rm -f "$F/pidup" "$F/f.ok" "$F/f.bad" "$F/f.warn"
    {
        echo 'ok(){ echo "$*" >> /tmp/f47chk/f.ok; }'
        echo 'bad(){ echo "$*" >> /tmp/f47chk/f.bad; }'
        echo 'warn(){ echo "$*" >> /tmp/f47chk/f.warn; }'
        echo "_bin=xray; _init=S24xray; _p=10810"
        echo "_lu=\"\"; _lt=\"\""
        echo ". '$F/udp.block'"
    } > "$F/runFP.sh"
    # bash по абсолютному пути: VAR=x cmd резолвит cmd уже в новом PATH
    ( PATH="$F/bin2" "$_BASH4" "$F/runFP.sh" ) 2>/dev/null
}
runFP
[ -f "$F/f.bad" ] && grep -q 'НЕ слушает' "$F/f.bad" && grep -q 'запущен' "$F/f.ok" \
    && ok "F4: без pidof живой процесс найден через /proc → udp-FAIL сохранён (A6-4)" \
    || bad "F4: ok=$(cat "$F/f.ok" 2>/dev/null) bad=$(cat "$F/f.bad" 2>/dev/null)"
kill "$_IMPID" 2>/dev/null; wait "$_IMPID" 2>/dev/null
runFP
[ ! -f "$F/f.bad" ] && grep -q 'не найден' "$F/f.warn" \
    && [ "$(grep -c 'не проверяем' "$F/f.warn")" = 2 ] \
    && ok "F5: без pidof процесс отсутствует → warn, FAIL нет" \
    || bad "F5: bad=$(cat "$F/f.bad" 2>/dev/null) warn=$(cat "$F/f.warn" 2>/dev/null)"

echo "═══ J. Аудит-19: R49-1 (дубль unblock_update), R49-2 (hysteria) ═══"
NB1=$(grep 'safe_start_service "S99unblock"' "$K/opt/bin/deploy_bypass.sh" \
    | grep -vc '^[[:space:]]*#' || true)
[ "${NB1:-0}" = 0 ] && grep -q 'R49-1 (аудит-19)' "$K/opt/bin/deploy_bypass.sh" \
    && ok "J1: deploy не запускает S99unblock в фоне (дубль исключён, контракт-комментарий на месте)" \
    || bad "J1: живых вызовов S99unblock: $NB1"
grep -q '/opt/bin/unblock_update.sh >/dev/null 2>&1 &' \
    "$K/opt/etc/init.d/S99unblock" \
    && ok "J2: boot-путь S99unblock не тронут (фоновый запуск при загрузке)" \
    || bad "J2: S99unblock изменился"
# NB: head -1|awk для XRAY корректен (первая строка без баннера) —
# инвариант только про hysteria-строку
HYLINE=$(grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1)
printf '%s' "$HYLINE" | grep -qF "head -1 | awk" \
    && bad "J3: hysteria-строка всё ещё парсится по первому полю баннера" \
    || ok "J3: парсинг версии hysteria — grep -oE (xray-строки не тронуты)"
mkdir -p "$F/bin3"
cat > "$F/bin3/hysteria" <<'HYS'
#!/bin/sh
printf 'Hysteria2 \xe2\x9c\x93\n'
printf 'Version:        app/v2.13.0\n'
printf 'Platform:       linux/amd64\n'
exit 0
HYS
chmod +x "$F/bin3/hysteria"
grep 'уже установлена ($(' "$K/opt/bin/deploy_bypass.sh" | head -1 > "$F/hy.echo"
( PATH="$F/bin3:/usr/bin:/bin" sh -c "_hy_bin='$F/bin3/hysteria'; . '$F/hy.echo'" ) > "$F/hy.out" 2>/dev/null
grep -q 'уже установлена (2.13.0), скачивание пропущено' "$F/hy.out" \
    && ok "J4: hysteria 2.x (баннер первой строкой) → «уже установлена (2.13.0)» (R49-2)" \
    || bad "J4: вывод: $(cat "$F/hy.out" 2>/dev/null)"
ND=$(grep -c 'аудит-19' "$K/opt/bin/deploy_bypass.sh" || true)
NT=$(grep -c 'аудит-19' "$K/opt/bin/test_udp_tunnels.sh" || true)
[ "$ND" -ge 5 ] && [ "$NT" -ge 1 ] \
    && ok "J5: маркеры аудита-19: deploy=$ND, test_udp_tunnels=$NT" \
    || bad "J5: deploy=$ND test_udp=$NT"

echo "═══ K. Аудит-20: firewall панели, /tmp-обёртки, ротация, TG, CSRF ═══"
GEN="$K/opt/etc/bot/generator.py"

# K1 (FW-1): в setup_firewall нет blanket-цикла по ALLOWED_SUBNETS;
# подсети берутся из LAN-интерфейсов (паритет с B7 хука).
K1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'for net in \[str(n) for n in ALLOWED_SUBNETS\]' || true)
K1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "proto kernel\|'inet'" || true)
grep -q 'веб-панель доступна только с 127.0.0.1' "$GEN" && K1C=1 || K1C=0
[ "$K1A" = 0 ] && [ "$K1B" -ge 2 ] && [ "$K1C" = 1 ] \
    && ok "K1: setup_firewall — подсети LAN-интерфейсов (B7-паритет), без blanket" \
    || bad "K1: blanket=$K1A lan_list=$K1B degr=$K1C"

# K2 (TW-1): нет файлов-обёрток в /tmp; sh -c + O_NOFOLLOW + mkstemp.
K2A=$(grep -c 'WRAPPER' "$GEN" || true)
K2B=$(grep -c "'-c', body," "$GEN" || true)
K2C=$(grep -c 'O_NOFOLLOW' "$GEN" || true)
K2D=$(grep -c 'mkstemp' "$GEN" || true)
if [ "$K2A" = 0 ] && [ "$K2B" = 2 ] && [ "$K2C" -ge 2 ] && [ "$K2D" -ge 3 ]; then
    # поведенческий прогон точного body обёртки unblock
    KF2="$(mktemp -d)"
    sed -n "/^    body = '\{3\}/,/^'\{3\}$/p" "$GEN" \
        | sed "1s/^    body = '\{3\}//; \$d" > "$KF2/body.sh"
    dash -n "$KF2/body.sh" 2>/dev/null
    printf '#!/bin/sh\necho out; echo err >&2; exit 7\n' > "$KF2/s.sh"
    chmod +x "$KF2/s.sh"
    sh "$KF2/body.sh" "$KF2/st.json" "$KF2/tm" "$KF2/s.sh" "" \
        > "$KF2/run.log" 2>&1
    K2RC=$?
    if [ "$K2RC" = 7 ] \
        && grep -q 'out' "$KF2/run.log" \
        && grep -q '"status":"error"' "$KF2/st.json" \
        && grep -q 'exit code 7' "$KF2/st.json"; then
        ok "K2: обёртки — sh -c + O_NOFOLLOW; body: rc/log/фолбэк-статус верны"
    else
        bad "K2: body-прогон rc=$K2RC: $(cat "$KF2/st.json" 2>/dev/null)"
    fi
    rm -rf "$KF2"
else
    bad "K2: WRAPPER=$K2A sh-c=$K2B nofollow=$K2C mkstemp=$K2D"
fi

# K3 (RL-1): триггер ротации — только размер; KEEP — цель обрезки.
K3T=$(grep -c 'if \[ "$_sz" -gt "$MAX" \]' "$K/opt/bin/rotate_logs.sh" || true)
K3L=$(grep -c -- '-gt "$KEEP"' "$K/opt/bin/rotate_logs.sh" || true)
KF3="$(mktemp -d)"
sed 's|^rotate /opt/etc/bot/error.log$|rotate "$TGT"|; s|^rotate /opt/root/KeenSnap/backup.log$|:|; s|^rotate /opt/var/log/100-redirect.log$|:|; s|^rotate /tmp/unblock_update.log$|:|; s|^MAX=.* rotate |: # |; s|^find /tmp -maxdepth 1|: find /nonexistent|' \
    "$K/opt/bin/rotate_logs.sh" > "$KF3/rot.sh"
sed -i "s|^umask 022|umask 022\nTGT=\"$KF3/error.log\"|" "$KF3/rot.sh"
dash -n "$KF3/rot.sh" 2>/dev/null
awk 'BEGIN{for(i=1;i<=150;i++)print "line"i}' > "$KF3/error.log"
MAX=524288 KEEP=100 sh "$KF3/rot.sh"
K3A=$(wc -l < "$KF3/error.log")
awk 'BEGIN{for(i=1;i<=1000;i++)print "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}' \
    > "$KF3/error.log"
MAX=50000 KEEP=100 sh "$KF3/rot.sh"
K3B=$(wc -l < "$KF3/error.log")
if [ "$K3T" = 1 ] && [ "$K3L" = 0 ] && [ "$K3A" = 150 ] && [ "$K3B" = 100 ]; then
    ok "K3: ротация по размеру: 150 строк<MAX не тронуты, >MAX → KEEP=100"
else
    bad "K3: триггер=$K3T keep-триггер=$K3L A=$K3A B=$K3B"
fi
rm -rf "$KF3"

# K4 (TG-1): общая tg_send_message; urlencode; токен вне cmdline.
K4A=$(grep -c 'tg_send_message()' "$K/opt/bin/common.sh" || true)
K4B=$(grep -c -- '--data-urlencode' "$K/opt/bin/common.sh" || true)
K4C=$(grep -c -- '-K -' "$K/opt/bin/common.sh" || true)
K4D=$(( $(grep -c 'text=\${' "$K/opt/bin/check_updates.sh" || true) \
    + $(grep -c 'text=\${' "$K/opt/bin/unblock_dnsmasq.sh" || true) ))
KF4="$(mktemp -d)"; mkdir -p "$KF4/bin" "$KF4/run"
sed "s|/opt/etc/bot/bot_config.py|$KF4/bot_config.py|g; s|/opt/var/run/|$KF4/run/|g" \
    "$K/opt/bin/common.sh" > "$KF4/common_m.sh"
printf 'token = "ABC123TOKEN"\n' > "$KF4/bot_config.py"
echo "-100200300" > "$KF4/run/bot_chat_id_notify.txt"
printf '#!/bin/sh\necho "ARGV:$@" >> "$MOCKLOG"\ncat > "$MOCKCFG"\nexit 0\n' \
    > "$KF4/bin/curl"
chmod +x "$KF4/bin/curl"
export MOCKLOG="$KF4/argv.log" MOCKCFG="$KF4/cfg.txt"
K4E=$(PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_urlencode 'a&b%c+d<e>'")
PATH="$KF4/bin:$PATH" sh -c ". '$KF4/common_m.sh'; tg_send_message 'обновление & готово 100%' HTML"
K4G=0; grep -q 'ABC123TOKEN' "$KF4/argv.log" 2>/dev/null || K4G=1
K4H=0; grep -q 'url = "https://api.telegram.org/botABC123TOKEN/sendMessage"' \
    "$KF4/cfg.txt" 2>/dev/null && K4H=1
if [ "$K4A" = 1 ] && [ "$K4B" -ge 1 ] && [ "$K4C" -ge 1 ] && [ "$K4D" = 0 ] \
    && [ "$K4E" = 'a%26b%25c%2Bd%3Ce%3E' ] && [ "$K4G" = 1 ] && [ "$K4H" = 1 ]; then
    ok "K4: tg_send_message: -K -, --data-urlencode, urlencode, токен вне argv"
else
    bad "K4: fn=$K4A ue=$K4B K=$K4C oldtext=$K4D enc=$K4E tok=$K4G url=$K4H"
fi
rm -rf "$KF4"

# K5 (CS-1+O-1/AF-1): request.host не источник доверия; политика в
# helpers; sweep вызывается из security_checks.
K5A=$(grep -c 'str(request.host)' "$GEN" || true)
K5B=$(grep -c 'def _csrf_origin_allowed' "$GEN" || true)
K5C=$(grep -c 'def _auth_fails_sweep' "$GEN" || true)
K5D=$(grep -c '_auth_fails_sweep(' "$GEN" || true)
[ "$K5A" = 0 ] && [ "$K5B" = 1 ] && [ "$K5C" = 1 ] && [ "$K5D" -ge 2 ] \
    && ok "K5: Origin/_auth_fails — политика в helpers, вызов на месте (L-1+O-1/AF-1)" \
    || bad "K5: reqhost=$K5A origin_h=$K5B sweep_h=$K5C calls=$K5D"

# K6 (BC-1): ранний chmod 0600 bot_config.py сразу после apply.
K6A=$(grep -c 'chmod 0600 /opt/etc/bot/bot_config.py' "$K/opt/bin/deploy_bypass.sh" || true)
K6B=$(sed -n "$(grep -n 'if busybox cp -a' "$K/opt/bin/deploy_bypass.sh" | head -1 | cut -d: -f1),+22p" \
    "$K/opt/bin/deploy_bypass.sh" | grep -c 'BC-1' || true)
[ "$K6A" -ge 4 ] && [ "$K6B" -ge 2 ] \
    && ok "K6: chmod 0600 bot_config.py после apply (BC-1, до аварийных выходов)" \
    || bad "K6: chmod-строк=$K6A маркеров-возле-apply=$K6B"

echo "═══ L. Аудит-21: legacy-blanket, preflight, предупреждение -remove ═══"

# L1 (FW-1b): зачистка legacy-blanket в setup_firewall; fallback нет.
L1A=$(sed -n "$(grep -n 'def setup_firewall' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c "legacy_net in ('192.168.0.0/16', '10.0.0.0/8'," || true)
L1B=$(sed -n "$(grep -n 'def _lan_subnet_list' "$GEN" | cut -d: -f1),/^def /p" \
    "$GEN" | grep -c 'ALLOWED_SUBNETS' || true)
[ "$L1A" = 1 ] && [ "$L1B" = 0 ] \
    && ok "L1: legacy-blanket снимается панелью; fallback на ALLOWED_SUBNETS нет" \
    || bad "L1: legacy=$L1A fallback=$L1B"

# L2 (PF-1): preflight — только flask+markupsafe; текст deploy раздельный.
L2A=$(grep -c 'import flask, markupsafe' "$K/opt/etc/init.d/S99generator" || true)
L2B=$(grep -c 'import flask, requests' "$K/opt/etc/init.d/S99generator" || true)
L2C=$(grep -c 'Панели нужен flask (+markupsafe); боту — telebot и requests' \
    "$K/opt/bin/deploy_bypass.sh" || true)
L2D=$(grep -c 'Веб-панель и бот без этих модулей не запустятся' \
    "$K/opt/bin/deploy_bypass.sh" || true)
[ "$L2A" = 1 ] && [ "$L2B" = 0 ] && [ "$L2C" = 1 ] && [ "$L2D" = 0 ] \
    && ok "L2: preflight flask+markupsafe (без requests); текст deploy раздельный" \
    || bad "L2: preflight=$L2A/$L2B текст=$L2C/$L2D"

# L3 (RM-1): uninstall_netfilter предупреждает об остатке чужих ACCEPT.
# Поведенчески: тот же экстракт/мок, что в секции A.
cat > "$F/runL.sh" <<'EOF'
#!/bin/bash
set -u
IPT=/tmp/f47chk/bin/iptables
IPT_MOCK_STATE=/tmp/f47chk/l3state.txt
export IPT_MOCK_STATE
warn() { echo "WARN: $*" >&2; }
. /tmp/f47chk/un.s
uninstall_netfilter
echo "RC=$?"
EOF
chmod +x "$F/runL.sh"
cp "$F/rules.txt" "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3a.log" 2>&1
L3A=$(grep -c 'вне формы проекта: 3' "$F/l3a.log" || true)
grep -v -- '--dport 8080 -j ACCEPT' "$F/rules.txt" > "$F/l3state.txt"
PATH="$F/bin:/usr/bin:/bin" bash "$F/runL.sh" > "$F/l3b.log" 2>&1
L3B=$(grep -c 'вне формы проекта' "$F/l3b.log" || true)
L3RC=$(grep -c '^RC=0$' "$F/l3a.log" || true)
if [ "$L3A" = 1 ] && [ "$L3B" = 0 ] && [ "$L3RC" = 1 ]; then
    ok "L3: -remove предупреждает о 3 чужих ACCEPT; без чужих — молчит; rc=0"
else
    bad "L3: с-чужими=$L3A без-чужих=$L3B rc=$L3RC"
fi

echo "═══ M. Аудит-22: Origin-туннель, tmp-статус, кап, нормализация ═══"

# M1 (O-1): поведенческая матрица _csrf_origin_allowed (экстракция).
python3 - "$GEN" > "$F/m1.out" 2>&1 <<'PYM1'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _csrf_origin_allowed\(.*?(?=^(?:@app\.before_request\n)?def )', src, re.M | re.S)
assert m, 'no _csrf_origin_allowed'
import ipaddress
from urllib.parse import urlparse
g = {
    'ipaddress': ipaddress, 'urlparse': urlparse,
    'LAN_IP': '192.168.1.1', 'LISTEN_PORT': 8080,
    '_lan_host_addresses': lambda: {'192.168.2.1'},
    '_ORIGIN_EXTRA_HOSTS': ['my.keenetic.net'],
}
exec(m.group(0), g)
f = g['_csrf_origin_allowed']
cases = [
    ('http://192.168.1.1:8080', '192.168.1.5', True),
    ('http://127.0.0.1:18080', '127.0.0.1', True),
    ('http://localhost:19000', '127.0.0.1', True),
    ('http://127.0.0.1:18080', '192.168.1.5', False),
    ('http://127.0.0.1:8080', '192.168.1.5', False),
    ('http://localhost:8080', '192.168.1.5', False),
    ('http://192.168.2.1:8080', '192.168.1.5', True),
    ('http://my.keenetic.net:8080', '192.168.1.5', True),
    ('http://evil.example:8080', '192.168.1.5', False),
    ('http://192.168.1.1', '192.168.1.5', False),
    ('ftp://192.168.1.1:8080', '192.168.1.5', False),
]
bad = [i for i, (o, c, want) in enumerate(cases) if f(o, c) != want]
if bad:
    print('BAD=%s' % ','.join(map(str, bad)))
else:
    print('MATRIX_OK(%d)' % len(cases))
PYM1
grep -q 'MATRIX_OK(11)' "$F/m1.out" \
    && ok "M1: Origin: туннель ✓ (loopback-клиент), удалённый loopback ✗ на любом порту (A9-4), альт-LAN-IP ✓, конфиг-имя ✓, чужие ✗" \
    || bad "M1: $(cat "$F/m1.out")"

# M2 (TS-1): tmp-статус не переживает прогон (успех и fallback).
KF6="$(mktemp -d)"
python3 - "$GEN" > "$KF6/body.sh" <<'PYM2'
import sys, re
Q = chr(39) * 3
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search('body = ' + Q + '(.*?)' + Q, src, re.S)
assert m, 'no body'
sys.stdout.write(m.group(1))
PYM2
dash -n "$KF6/body.sh" 2>/dev/null
printf '{"status":"done","ts":1,"message":"by script"}\n' > "$KF6/st1.json"
printf '#!/bin/sh\nexit 0\n' > "$KF6/s0.sh"; chmod +x "$KF6/s0.sh"
sh "$KF6/body.sh" "$KF6/st1.json" "$KF6/tmp1" "$KF6/s0.sh" "" \
    > "$KF6/a.log" 2>&1
printf '#!/bin/sh\nexit 7\n' > "$KF6/s7.sh"; chmod +x "$KF6/s7.sh"
sh "$KF6/body.sh" "$KF6/st2.json" "$KF6/tmp2" "$KF6/s7.sh" "" \
    > "$KF6/b.log" 2>&1
if [ ! -e "$KF6/tmp1" ] && [ ! -e "$KF6/tmp2" ] \
    && grep -q 'by script' "$KF6/st1.json" \
    && grep -q '"status":"error"' "$KF6/st2.json" \
    && grep -q 'exit code 7' "$KF6/st2.json"; then
    ok "M2: tmp-статус удалён и при успехе (trap), и при fallback (mv); статусы верны"
else
    bad "M2: tmp1=$([ -e "$KF6/tmp1" ] && echo есть || echo нет) tmp2=$([ -e "$KF6/tmp2" ] && echo есть || echo нет)"
fi
rm -rf "$KF6"
K2TRAP=$(grep -c "trap 'rm -f" "$GEN" || true)
K2EXC=$(grep -c 'os.unlink(tmp_status)' "$GEN" || true)
[ "$K2TRAP" = 2 ] && [ "$K2EXC" = 2 ] \
    && ok "M2b: trap в обоих body + очистка при отказе Popen (TS-1)" \
    || bad "M2b: trap=$K2TRAP unlink=$K2EXC"

# M3 (AF-1 + FB-11): кап 256; истёкшие блокировки чистятся; активный
# счётчик НЕ сбрасывается (K50-2); 429 достижим; предел после вставки.
python3 - "$GEN" > "$F/m3.out" 2>&1 <<'PYM3'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
mc = re.search(r'^_AUTH_FAILS_MAX = (\d+)$', src, re.M)
mt = re.search(r'^def _auth_fails_trim\(.*?(?=^def )', src, re.M | re.S)
mf = re.search(r'^def _auth_fails_sweep\(.*?(?=^def )', src, re.M | re.S)
assert mc and mt and mf, 'no const/funcs'
g = {'_AUTH_FAILS_MAX': int(mc.group(1))}
exec(mt.group(0), g)
exec(mf.group(0), g)
trim, sweep = g['_auth_fails_trim'], g['_auth_fails_sweep']
d = {('10.%d.0.1' % i): (5, 2e9) for i in range(300)}
sweep(d, '10.0.0.1', 1e9)
cap_ok = len(d) == 256
d2 = {'a': (0, 100.0), 'b': (5, 2e9)}
r = sweep(d2, 'a', 1e9)
exp_ok = 'a' not in d2 and 'b' in d2 and r == (0, 0.0)
d3 = {'c': (3, 0.0)}
r3 = sweep(d3, 'c', 1e9)
keep_ok = r3 == (3, 0.0) and 'c' in d3
fm = {}
hist = []
for i in range(6):
    f, b = sweep(fm, 'c', 1000.0 + i)
    if b > 1000.0 + i:
        hist.append('429')
        continue
    f += 1
    if f >= 5:
        fm['c'] = (0, 1000.0 + i + 300)
        hist.append('B')
    else:
        fm['c'] = (f, 0.0)
        hist.append(str(f))
    trim(fm)
sim_ok = hist == ['1', '2', '3', '4', 'B', '429']
fm2 = {('c%d' % i): (1, 0.0) for i in range(256)}
sweep(fm2, 'new', 1e9)
fm2['new'] = (1, 0.0)
trim(fm2)
ins_ok = len(fm2) == 256
res = (cap_ok, exp_ok, keep_ok, sim_ok, ins_ok)
print('OK' if all(res) else
      'BAD cap=%s exp=%s keep=%s sim=%s(%s) ins=%s(%d)' % (
          cap_ok, exp_ok, keep_ok, sim_ok, hist, ins_ok, len(fm2)))
PYM3
grep -q '^OK$' "$F/m3.out" \
    && ok "M3: кап 256; истёкшая снята; активный счётчик жив; 6 неудачных → блок+429; предел после вставки (AF-1+FB-11)" \
    || bad "M3: $(cat "$F/m3.out")"

# M4 (SN-1): fallback-нормализация host-bits; невалидные пропущены.
python3 - "$GEN" > "$F/m4.out" 2>&1 <<'PYM4'
import sys, re
src = open(sys.argv[1], encoding='utf-8').read()
m = re.search(r'^def _lan_subnet_list\(.*?(?=^def )', src, re.M | re.S)
assert m, 'no func'
import ipaddress, threading
class _R:
    def __init__(self, out): self.stdout = out
class _SP:
    def run(self, args, **kw):
        if args[:4] == ['ip', '-4', 'route', 'show']:
            return _R('')
        if args[:4] == ['ip', '-4', 'addr', 'show']:
            return _R(
                '2: br9: <BROADCAST,MULTICAST,UP>\n'
                '    inet 192.168.2.1/24 brd 192.168.2.255 br9\n'
                '    inet 10.0.0.99/8 brd 10.255.255.255 br9\n'
                '    inet frog/24 br9\n')
        return _R('')
class _C:
    lan_ifaces = ['br9']
g = {'subprocess': _SP(), 'ipaddress': ipaddress, 'config': _C(),
     'threading': threading}
exec(m.group(0), g)
nets, found = g['_lan_subnet_list']()
ok1 = '192.168.2.1/24' not in nets and '192.168.2.0/24' in nets
ok2 = '10.0.0.0/8' in nets
ok3 = not any('frog' in n for n in nets)
ok4 = nets and nets[0] == '127.0.0.0/8' and found is True
print('OK' if ok1 and ok2 and ok3 and ok4 else
      'BAD %r' % (nets,))
PYM4
grep -q '^OK$' "$F/m4.out" \
    && ok "M4: fallback: 192.168.2.1/24 → 192.168.2.0/24; 10.0.0.99/8 → 10.0.0.0/8; frog пропущен (SN-1)" \
    || bad "M4: $(cat "$F/m4.out")"
grep -q 'ACCEPT не создан' "$GEN" \
    && ok "M4b: отказ создания ACCEPT логируется (SN-1)" \
    || bad "M4b: нет логирования отказа ACCEPT"

echo "═══ N. Аудит-23: проверка фидов Entware (сбой установки r48) ═══"
NB="$F/nb"; mkdir -p "$NB/bin" "$NB/dl"
DEP="$K/opt/bin/deploy_bypass.sh"
# экстракция функций блока зеркал
for _nfn in _entware_stock_feeds _entware_feed_base _entware_probe_feed_url \
            _entware_feeds_reachable _entware_prepare_candidate pick_entware_base; do
    awk "/^${_nfn}\(\) \{/,/^\}/" "$DEP" >> "$NB/fns.sh"
    echo >> "$NB/fns.sh"
done
grep -q '^pick_entware_base()' "$NB/fns.sh" || bad "N0: экстракция блока зеркал не удалась"

# N1 (FB-2): https-проба без curl → «не проверено» (rc 2), не «нет».
printf '#!/bin/sh\nexit 1\n' > "$NB/bin/wget"; chmod +x "$NB/bin/wget"
cat > "$NB/run1.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD=""
export KEENZOO_DLTMP DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run1.sh"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run1.sh" 2>/dev/null | tail -1)
[ "$NBRC" = "PROBE_RC=2" ] \
    && ok "N1: https без curl → «не проверено» (rc 2), зеркало не бракуется (FB-2)" \
    || bad "N1: $NBRC (ожидался PROBE_RC=2)"

# N2 (FB-3): curl-проба лёгкая (Range 256Б), а не полная загрузка.
printf '#!/bin/sh\necho "ARGV:$@" >> /tmp/f47chk/nb/curl.log\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c 256 /dev/zero > "$2"; shift; done\nexit 0\n' \
    > "$NB/bin/curl"; chmod +x "$NB/bin/curl"
cat > "$NB/run2.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl; DL_CMD="curl"
export KEENZOO_DLTMP DL_CMD
have_cmd() { command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
EOF
chmod +x "$NB/run2.sh"
rm -f "$NB/curl.log"
NBRC=$(PATH=/usr/bin:/bin bash "$NB/run2.sh" 2>/dev/null | tail -1)
if [ "$NBRC" = "PROBE_RC=0" ] && grep -q -- '-r 0-255' "$NB/curl.log" 2>/dev/null; then
    ok "N2: curl-проба — Range 256Б (не полная загрузка Packages.gz) (FB-3)"
else
    bad "N2: rc=$NBRC; curl-лог: $(cat "$NB/curl.log" 2>/dev/null | head -1)"
fi
rm -f "$NB/bin/curl"

# N3/N4/N5: поведенческие сценарии pick_entware_base (как на устройстве).
cat > "$NB/pick.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/nb/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/nb/dl
KZ_DEPLOY_OPKG_CONF="$1"
ENTWARE_ARCH=aarch64-k3.10; DL_CMD=""
export KEENZOO_DLTMP KZ_DEPLOY_OPKG_CONF ENTWARE_ARCH DL_CMD
have_cmd() { [ "$1" = curl ] && return 1; command -v "$1" >/dev/null 2>&1; }
warn() { echo "WARN: $*"; }
die()   { echo "DIE: $*"; exit 42; }
ENTWARE_MIRRORS="https://bin.entware.net https://entware.diversion.ch"
_ENTWARE_BASE_REQUESTED=""
ENTWARE_BASE=""; ENTWARE_MIRROR_SWITCH_NEEDED=0; ENTWARE_MIRROR_CHANGED=0
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
pick_entware_base >/dev/null 2>&1
echo "PICK_RC=$?"
EOF
chmod +x "$NB/pick.sh"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc/gz keendev http://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\nsrc/gz keendev https://bin.entware.net/aarch64-k3.10/keenetic\n' > "$NB/https.conf"
RC_A=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/http.conf" 2>/dev/null | tail -1)
RC_B=$(PATH=/usr/bin:/bin bash "$NB/pick.sh" "$NB/https.conf" 2>/dev/null | tail -1)
[ "$RC_A" = "PICK_RC=0" ] \
    && ok "N3: сценарий устройства (http-фиды, curl нет) → rc 0, установка не гибнет (FB-6 аудита-24)" \
    || bad "N3: $RC_A (ожидался PICK_RC=0)"
[ "$RC_B" = "PICK_RC=0" ] \
    && ok "N4: https-фиды без curl → rc 0: установка НЕ гибнет, решает opkg update (FB-1/FB-2)" \
    || bad "N4: $RC_B (ожидался PICK_RC=0)"

# N5 (FB-1/FB-5): инварианты текстов и семантики в самом deploy.
N5A=$(grep -c 'ни один HTTPS-кандидат не прошёл' "$DEP" || true)
N5B=$(grep -c 'Разрешить осознанно: KEENZOO_ALLOW_HTTP_FEED=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5C=$(grep -c 'KEENZOO_OPKG_OFFLINE=1 /opt/bin/deploy_bypass.sh' "$DEP" || true)
N5D=$(grep -c 'Ни один кандидат не подтверждён; opkg.conf остаётся прежним' "$DEP" || true)
[ "$N5A" = 0 ] && [ "$N5B" = 1 ] && [ "$N5C" -ge 1 ] && [ "$N5D" = 1 ] \
    && ok "N5: старые немые die убраны; подсказки-обходы на месте (FB-1/FB-5/FB-6)" \
    || bad "N5: старый-die=$N5A allow-hint=$N5B offline-hint=$N5C fb1-warn=$N5D"

echo "═══ P. Аудит-24: HTTP-гейт в точке риска, retry пробы ═══"
PB="$F/pb"; mkdir -p "$PB/bin" "$PB/dl"
# экстракция гейт-хелперов
for _pfn in _kz_pkg_installed _kz_http_feed_active _kz_http_install_gate; do
    awk "/^${_pfn}\(\) \{/,/^\}/" "$DEP" >> "$PB/gate.sh"
    echo >> "$PB/gate.sh"
done
grep -q '^_kz_http_install_gate()' "$PB/gate.sh" || bad "P0: экстракция гейтов не удалась"

# фейковый opkg: list-installed знает только tor; /var/opkg/status недоступен
printf '#!/bin/sh\n[ "$1" = list-installed ] && { echo "tor - 1.0"; exit 0; }\nexit 0\n' \
    > "$PB/bin/opkg"; chmod +x "$PB/bin/opkg"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\n' > "$PB/http.conf"
printf 'src/gz entware https://bin.entware.net/aarch64-k3.10\n' > "$PB/https.conf"

cat > "$PB/g.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/pb/bin:/bin"; export PATH
warn() { echo "WARN: $*"; }
. /tmp/f47chk/pb/gate.sh >/dev/null 2>&1
case "$1" in
    installed) _kz_pkg_installed "$2"; echo "RC=$?";;
    gate)      KZ_DEPLOY_OPKG_CONF="$2" KEENZOO_ALLOW_HTTP_FEED="${3:-0}" \
                   _kz_http_install_gate testpkg; echo "RC=$?";;
esac
EOF
chmod +x "$PB/g.sh"
GR1=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed tor 2>/dev/null | tail -1)
GR2=$(PATH=/usr/bin:/bin bash "$PB/g.sh" installed xray 2>/dev/null | tail -1)
GR3=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 0 2>/dev/null | tail -1)
GR4=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/http.conf 1 2>/dev/null | tail -1)
GR5=$(PATH=/usr/bin:/bin bash "$PB/g.sh" gate /tmp/f47chk/pb/https.conf 0 2>/dev/null | tail -1)
if [ "$GR1" = "RC=0" ] && [ "$GR2" = "RC=1" ] && [ "$GR3" = "RC=1" ] \
    && [ "$GR4" = "RC=0" ] && [ "$GR5" = "RC=0" ]; then
    ok "P1: гейт: установлен→пропуск; http без ALLOW→warn+пропуск; http+ALLOW/https→можно (FB-6)"
else
    bad "P1: inst=$GR1/$GR2 http0=$GR3 http1=$GR4 https=$GR5"
fi
GATE_WARNS=$(PATH=/usr/bin:/bin KZ_DEPLOY_OPKG_CONF=/tmp/f47chk/pb/http.conf bash -c \
    'warn(){ echo "WARN:$*"; }; PATH="/tmp/f47chk/pb/bin:/bin"; . /tmp/f47chk/pb/gate.sh >/dev/null 2>&1; _kz_http_install_gate testpkg' 2>/dev/null)
printf '%s' "$GATE_WARNS" | grep -q 'KEENZOO_ALLOW_HTTP_FEED=1' \
    && ok "P2: warn гейта несёт обход KEENZOO_ALLOW_HTTP_FEED=1 (FB-7)" \
    || bad "P2: warn гейта без подсказки: $GATE_WARNS"

# P3: гейт вызван во всех сетевых opkg install шага пакетов.
P3A=$(grep -c '_kz_http_install_gate' "$DEP" || true)
P3B=$(grep -c '_kz_pkg_installed "\$pkg" && continue' "$DEP" || true)
[ "$P3A" -ge 10 ] && [ "$P3B" = 1 ] \
    && ok "P3: гейт на всех местах установок ($P3A); цикл пакетов: skip-if-installed" \
    || bad "P3: gate=$P3A skip=$P3B"

# P4 (FB-8): http-проба — ensure_dns + повтор.
# FB-51 (аудит-28) добавил внутрь http-ветки case с собственными ;;,
# поэтому прежний awk-диапазон до первого ;; обрезался — считаем по
# всей функции пробы.
awk 'index($0, "_entware_probe_feed_url() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$F/p4fn.sh"
P4A=$(grep -c 'ensure_dns' "$F/p4fn.sh" || true)
P4B=$(grep -c '_epf_try' "$F/p4fn.sh" || true)
P4C=$(grep -c 'while \[ "\$_epf_try" -le 2 \]' "$F/p4fn.sh" || true)
[ "$P4A" -ge 1 ] && [ "$P4B" -ge 3 ] && [ "$P4C" -ge 1 ] \
    && ok "P4: http-проба: ensure_dns + 2 попытки (FB-8; диапазон уточнён под case FB-51)" \
    || bad "P4: dns=$P4A retry=$P4B loops=$P4C"

# P5: формулировки.
P5A=$(grep -c 'Текущий фид Entware работает по HTTP' "$DEP" || true)
[ "$P5A" -ge 1 ] \
    && ok "P5: формулировка «работает по HTTP» вместо «не разрешён» (FB-9)" \
    || bad "P5: формулировки нет"

echo "═══ Q. Аудит-25: панель, HTTP-политика, Origin, гейты ═══"

# Q0 (FB-10): единственный @app.before_request стоит на security_checks().
python3 - "$GEN" > "$F/q0.out" 2>&1 <<'PYQ0'
import sys
lines = open(sys.argv[1], encoding='utf-8').read().split('\n')
dec = [i for i, l in enumerate(lines) if l.strip() == '@app.before_request']
ok = (len(dec) == 1 and dec[0] + 1 < len(lines)
      and lines[dec[0] + 1].startswith('def security_checks():'))
print('OK' if ok else 'BAD dec=%r' % [lines[i] for i in dec])
PYQ0
grep -q '^OK$' "$F/q0.out" \
    && ok "Q0: @app.before_request — единственный и на security_checks() (K50-1)" \
    || bad "Q0: $(cat "$F/q0.out")"

# Q1 (FB-11): lock вокруг sweep+вставки; предел после вставки.
Q1A=$(grep -c '^_AUTH_FAILS_LOCK = threading.Lock()' "$GEN" || true)
Q1B=$(grep -c 'with _AUTH_FAILS_LOCK:' "$GEN" || true)
Q1C=$(grep -c '_auth_fails_trim(_auth_fails)' "$GEN" || true)
[ "$Q1A" = 1 ] && [ "$Q1B" = 1 ] && [ "$Q1C" = 1 ] \
    && ok "Q1: sweep+вставка под _AUTH_FAILS_LOCK; trim после вставки (K50-2/A9-5)" \
    || bad "Q1: lock=$Q1A with=$Q1B trim=$Q1C"

# Q2 (FB-14): базовое имя, ключ конфига, нет портового фолбэка loopback.
Q2A=$(grep -c "_ORIGIN_EXTRA_HOSTS = \['my.keenetic.net'\] + \[" "$GEN" || true)
Q2B=$(grep -c "'allowed_origin_hosts'" "$K/opt/etc/bot/bot_config.py" || true)
Q2C=$(grep -c 'return port == str(LISTEN_PORT)' "$GEN" || true)
[ "$Q2A" = 1 ] && [ "$Q2B" -ge 1 ] && [ "$Q2C" = 0 ] \
    && ok "Q2: my.keenetic.net в базовом наборе; ключ в bot_config; loopback — только loopback-клиент (K50-4/A9-4)" \
    || bad "Q2: base=$Q2A cfg=$Q2B fallback=$Q2C"

# Q3 (FB-12): гейт заглушки в S57hysteria — статика и поведение.
S57="$K/opt/etc/init.d/S57hysteria"
Q3A=$(grep -c 'SKIPPED: hysteria не настроена' "$S57" || true)
Q3B=$(grep -c 'CHANGE_ME' "$S57" || true)
Q3C=$(grep -n 'case "${1:-}" in' "$S57" | head -1 | cut -d: -f1)
Q3D=$(grep -n '^\. /opt/etc/init.d/rc\.func' "$S57" | head -1 | cut -d: -f1)
QB="$F/qb"; mkdir -p "$QB"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$QB/gate.sh"
printf '{\n  "server": "example.com:443",\n  "auth": "CHANGE_ME"\n}\n' > "$QB/ph.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k"\n}\n' > "$QB/ok.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k",\n  "tls": {"sni": "example.com"}\n}\n' > "$QB/sni.json"
printf '{\n  "server": "",\n  "auth": "k"\n}\n' > "$QB/empty.json"
cat > "$QB/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/qb/gate.sh
echo "GATE_RC=PASS"
EOF
chmod +x "$QB/run.sh"
Q3R1=$(KEENZOO_HYSTERIA_CONFIG="$QB/ph.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R2=$(KEENZOO_HYSTERIA_CONFIG="$QB/ok.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R3=$(KEENZOO_HYSTERIA_CONFIG="$QB/sni.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R4=$(KEENZOO_HYSTERIA_CONFIG="$QB/empty.json" sh "$QB/run.sh" start 2>&1; echo "rc=$?")
Q3R5=$(KEENZOO_HYSTERIA_CONFIG="$QB/ph.json" sh "$QB/run.sh" stop 2>&1; echo "rc=$?")
if [ "$Q3A" -ge 1 ] && [ "$Q3B" -ge 1 ] && [ -n "$Q3C" ] && [ -n "$Q3D" ] \
    && [ "$Q3C" -lt "$Q3D" ] \
    && printf '%s' "$Q3R1" | grep -q 'SKIPPED: hysteria не настроена' \
    && printf '%s' "$Q3R1" | grep -q 'rc=0' \
    && printf '%s' "$Q3R2" | grep -q 'GATE_RC=PASS' \
    && printf '%s' "$Q3R3" | grep -q 'GATE_RC=PASS' \
    && printf '%s' "$Q3R4" | grep -q 'SKIPPED' \
    && printf '%s' "$Q3R5" | grep -q 'GATE_RC=PASS'; then
    ok "Q3: S57-гейт: заглушка/пустой server → SKIPPED (rc0); валидный и SNI-маскировка → старт; stop не задет (K50-3)"
else
    bad "Q3: A=$Q3A B=$Q3B case=$Q3C rcfunc=$Q3D r1=$(echo "$Q3R1" | tail -1) r2=$(echo "$Q3R2" | tail -1) r3=$(echo "$Q3R3" | tail -1) r4=$(echo "$Q3R4" | tail -1) r5=$(echo "$Q3R5" | tail -1)"
fi

# Q4 (FB-13): перечислитель ВСЕХ opkg install/upgrade — гейт обязателен.
python3 - "$K" > "$F/q4.out" 2>&1 <<'PYQ4'
import re, sys
PAT = re.compile(r'^(?:if\s+!?\s*|elif\s+|&&\s*)?opkg\s+(?:install|upgrade)\b')
def check(path, want):
    lines = open(path, encoding='utf-8').read().split('\n')
    sites, ungated = [], []
    for n, line in enumerate(lines):
        t = line.strip()
        if not t or t.startswith('#') or t.startswith(('echo', 'warn', 'printf')):
            continue
        if PAT.match(t):
            sites.append(n + 1)
            if not any(('_kz_http_install_gate' in lines[k]
                        or '_upd_http_install_gate' in lines[k])
                       for k in range(max(0, n - 10), n)):
                ungated.append(n + 1)
    return sites, ungated, want
root = sys.argv[1]
ds, du, dw = check(root + '/opt/bin/deploy_bypass.sh', 12)
us, uu, uw = check(root + '/opt/bin/update_protocols.sh', 4)
ok = (not du and not uu and len(ds) == dw and len(us) == uw)
print('OK deploy=%d updater=%d' % (len(ds), len(us)) if ok else
      'BAD deploy=%d(%s) updater=%d(%s) ungated=%r/%r' % (
          len(ds), dw, len(us), uw, du, uu))
PYQ4
grep -q '^OK deploy=12 updater=4' "$F/q4.out" \
    && ok "Q4: все 16 opkg install/upgrade (12 deploy + 4 updater) под HTTP-гейтом (A9-2)" \
    || bad "Q4: $(cat "$F/q4.out")"

# Q5 (FB-17): форма src распознаётся гейтом.
Q5="$F/q5"; mkdir -p "$Q5/bin"
for _pfn in _kz_http_feed_active _kz_http_install_gate; do
    awk "/^${_pfn}\(\) \{/,/^\}/" "$DEP" >> "$Q5/gate.sh"
    echo >> "$Q5/gate.sh"
done
printf '#!/bin/sh\nexit 0\n' > "$Q5/bin/opkg"; chmod +x "$Q5/bin/opkg"
printf 'src custom http://bin.entware.net/aarch64-k3.10\n' > "$Q5/src-http.conf"
printf 'src custom https://bin.entware.net/aarch64-k3.10\n' > "$Q5/src-https.conf"
printf 'src/gz entware http://bin.entware.net/aarch64-k3.10\nsrc custom https://mirror.example/x\n' > "$Q5/mixed.conf"
cat > "$Q5/g.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/q5/bin:/bin"; export PATH
warn() { echo "WARN: $*"; }
. /tmp/f47chk/q5/gate.sh >/dev/null 2>&1
KZ_DEPLOY_OPKG_CONF="$1" KEENZOO_ALLOW_HTTP_FEED="${2:-0}" _kz_http_install_gate testpkg
echo "RC=$?"
EOF
chmod +x "$Q5/g.sh"
Q5R1=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/src-http.conf 0 2>/dev/null | tail -1)
Q5R2=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/src-https.conf 0 2>/dev/null | tail -1)
Q5R3=$(PATH=/usr/bin:/bin bash "$Q5/g.sh" /tmp/f47chk/q5/mixed.conf 0 2>/dev/null | tail -1)
[ "$Q5R1" = "RC=1" ] && [ "$Q5R2" = "RC=0" ] && [ "$Q5R3" = "RC=1" ] \
    && ok "Q5: src-форма фида: http → skip, https → ок, mixed → skip (A9-3)" \
    || bad "Q5: http=$Q5R1 https=$Q5R2 mixed=$Q5R3"

# Q6 (FB-18): сервер без Range — честная заметка, rc 0.
Q6="$F/q6"; mkdir -p "$Q6/bin" "$Q6/dl"
printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c 100000 /dev/zero > "$2"; shift; done\nexit 0\n' \
    > "$Q6/bin/curl"; chmod +x "$Q6/bin/curl"
cat > "$Q6/run.sh" <<'EOF'
#!/bin/bash
set -u
PATH="/tmp/f47chk/q6/bin:/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/q6/dl; DL_CMD="curl"
export KEENZOO_DLTMP DL_CMD
have_cmd() { command -v "$1" >/dev/null 2>&1; }
warn() { :; }
. /tmp/f47chk/nb/fns.sh >/dev/null 2>&1
_entware_probe_feed_url "https://bin.entware.net/aarch64-k3.10"
echo "PROBE_RC=$?"
echo "NOTE=$_EPF_NOTE"
EOF
chmod +x "$Q6/run.sh"
Q6OUT=$(PATH=/usr/bin:/bin bash "$Q6/run.sh" 2>/dev/null | tail -2)
if printf '%s' "$Q6OUT" | grep -q 'PROBE_RC=0' \
    && printf '%s' "$Q6OUT" | grep -q 'полная загрузка (сервер без Range)'; then
    ok "Q6: сервер игнорирует Range → rc0 + честная «полная загрузка» (не «range 256Б») (A9-6)"
else
    bad "Q6: $Q6OUT"
fi

# Q7 (FB-19): гейт-пропуски видны в сводке.
Q7A=$(grep -c '^SKIPPED_HTTP=""' "$DEP" || true)
Q7B=$(grep -c 'SKIPPED_HTTP="${SKIPPED_HTTP} ${pkg}"' "$DEP" || true)
Q7C=$(grep -c 'Пакеты не установлены из-за HTTP-политики' "$DEP" || true)
Q7D=$(grep -c '\[ -z "$SKIPPED_HTTP" \]' "$DEP" || true)
[ "$Q7A" = 1 ] && [ "$Q7B" = 1 ] && [ "$Q7C" = 1 ] && [ "$Q7D" = 1 ] \
    && ok "Q7: SKIPPED_HTTP копится, ⚠️-строка есть, «✅ Пакеты» подавлен (A9-7)" \
    || bad "Q7: init=$Q7A acc=$Q7B warn=$Q7C guard=$Q7D"

# Q8 (FB-20): заглушки токена не покидают tg_bot_token.
Q8="$F/q8"; mkdir -p "$Q8"
awk '/^tg_bot_token\(\) \{/,/^\}/' "$K/opt/bin/common.sh" > "$Q8/tok.sh"
sed -i "s#/opt/etc/bot/bot_config.py#$Q8/cfg.py#" "$Q8/tok.sh"
printf 'tg_bot_token\n' >> "$Q8/tok.sh"
printf "token = 'ТОКЕН_БОТА'\n" > "$Q8/cfg.py"; Q8R1=$(sh "$Q8/tok.sh" | wc -c)
printf "token = 'CHANGE_ME'\n" > "$Q8/cfg.py"; Q8R2=$(sh "$Q8/tok.sh" | wc -c)
printf "token = '12345:ABC-DEF'\n" > "$Q8/cfg.py"; Q8R3=$(sh "$Q8/tok.sh")
[ "$Q8R1" = 0 ] && [ "$Q8R2" = 0 ] && [ "$Q8R3" = "12345:ABC-DEF" ] \
    && ok "Q8: ТОКЕН_БОТА/CHANGE_ME → пусто; реальный токен проходит (K50-7)" \
    || bad "Q8: r1=$Q8R1 r2=$Q8R2 r3=[$Q8R3]"

# Q9 (FB-21/FB-22): shlex убран; кэш адресов LAN (включая пустой результат).
python3 - "$GEN" > "$F/q9.out" 2>&1 <<'PYQ9'
import sys, re, types, ipaddress, threading
src = open(sys.argv[1], encoding='utf-8').read()
shlex_n = len([l for l in src.split('\n') if 'shlex' in l])
mfunc = re.search(r'^def _lan_host_addresses\(.*?(?=^def )', src, re.M | re.S)
mcache1 = re.search(r'^_LAN_HOSTS_CACHE = \{.*$', src, re.M)
mcache2 = re.search(r'^_LAN_HOSTS_CACHE_TTL = [\d.]+$', src, re.M)
# FB-30 (аудит-26): функция берёт модульный _LAN_HOSTS_LOCK —
# экстракция Q9 обязана дать его неймспейсу.
mlock = re.search(r'^_LAN_HOSTS_LOCK = threading\.Lock\(\)$', src, re.M)
assert mfunc and mcache1 and mcache2 and mlock, 'no cache/lock/func'
import time as _time
def make_env(stdout):
    calls = {'n': 0}
    class _R:
        def __init__(self, out):
            self.stdout = out
    class _SP:
        TimeoutExpired = Exception
        def run(self, args, **kw):
            calls['n'] += 1
            return _R(stdout)
    class _C:
        lan_ifaces = ['br0', 'br1', 'nwg0']
    g = {'time': _time, 'subprocess': _SP(), 'config': _C(),
         'ipaddress': ipaddress, 'threading': threading}
    exec(mcache1.group(0), g)
    exec(mcache2.group(0), g)
    exec(mlock.group(0), g)
    exec(mfunc.group(0), g)
    return g['_lan_host_addresses'], calls
f, calls = make_env('    inet 192.168.1.1/24 brd x br0\n')
a = f()
same = all(f() == a for _ in range(19))
fe, ce = make_env('')
fe()
fe(); fe(); fe()
print('OK shlex=%d forks=%d stable=%s empty_forks=%d' % (
    shlex_n, calls['n'], same, ce['n']) if (
    shlex_n == 0 and calls['n'] == 3 and same and ce['n'] == 3) else
    'BAD shlex=%d forks=%d stable=%s empty_forks=%d' % (
        shlex_n, calls['n'], same, ce['n']))
PYQ9
grep -q '^OK ' "$F/q9.out" \
    && ok "Q9: import shlex убран; кэш LAN: 3 форка на 20 вызовов, пустой результат кэшируется (K50-8/K50-9)" \
    || bad "Q9: $(cat "$F/q9.out")"

# Q10 (FB-15): канонический путь hysteria.
Q10A=$(grep -c -- '-x /opt/sbin/hysteria' "$DEP" || true)
Q10B=$(grep -c '_hy_canon_ok' "$DEP" || true)
Q10C=$(grep -c '/opt/sbin/hysteria version' "$DEP" || true)
Q10D=$(grep -c 'DEPLOY_MODE" = "restore"' "$DEP" || true)
[ "$Q10A" -ge 2 ] && [ "$Q10B" -ge 2 ] && [ "$Q10C" -ge 4 ] && [ "$Q10D" -ge 1 ] \
    && ok "Q10: гейты/версии hysteria — по /opt/sbin; послабление только restore (K50-5)" \
    || bad "Q10: canon=$Q10A flag=$Q10B ver=$Q10C restore=$Q10D"

# Q11 (FB-16): сводка называет оба поля.
Q11A=$(grep -c 'задайте web_username и web_password' "$DEP" || true)
[ "$Q11A" = 1 ] \
    && ok "Q11: сводка: «задайте web_username и web_password» (K50-6)" \
    || bad "Q11: $Q11A"

# Q12 (FB-13): гейт в update_protocols + граница политики задокументирована.
Q12A=$(grep -c '_upd_http_install_gate' "$K/opt/bin/update_protocols.sh" || true)
Q12B=$(grep -c 'opkg update (загрузка индекса) НЕ гейтится' "$K/opt/bin/update_protocols.sh" || true)
[ "$Q12A" = 5 ] && [ "$Q12B" = 1 ] \
    && ok "Q12: updater: гейт-хелпер + 4 вызова; граница политики описана (A9-2)" \
    || bad "Q12: gate=$Q12A boundary=$Q12B"

# Q13 (FB-10, опционально): реальный Flask-смоук, если flask доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/q13.out" 2>&1 <<'PYQ13'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g
reg = g.app.before_request_funcs.get(None) or list(
    g.app.before_request_funcs.values())[0]
names = [f.__name__ for f in reg]
c = g.app.test_client()
r1 = c.get('/')
r2 = c.get('/api/cfg')
ok = (names == ['security_checks'] and r1.status_code != 500
      and r2.status_code != 500)
print('OK registry=%s /=%s cfg=%s' % (names, r1.status_code, r2.status_code)
      if ok else 'BAD registry=%s /=%s cfg=%s' % (
          names, r1.status_code, r2.status_code))
PYQ13
    grep -q '^OK ' "$F/q13.out" \
        && ok "Q13: Flask: before_request=[security_checks], GET без 5xx (K50-1)" \
        || bad "Q13: $(cat "$F/q13.out")"
else
    echo "[SKIP] Q13: Flask-смоук — flask не установлен на хосте (инвариант Q0 покрывает класс)"
fi

echo "═══ G. R48-5: просмотр списка ≡ сохранению ═══"
python3 - "$K" "$F" <<'PYB'
import ast, io, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

sys.path.insert(0, os.path.join(K, 'opt/etc/bot'))
import lists_core as lc

src = io.open(os.path.join(K, 'opt/etc/bot/handlers.py'), encoding='utf-8').read()
names = {'load_bypass_blocks', 'sections_to_text', 'format_blocks_for_display'}
segs = [ast.get_source_segment(src, n) for n in ast.parse(src).body
        if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(segs) == 3, 'не все функции извлечены'
ns = {'lists_core': lc, 'os': os}
exec('import os\n', ns)
exec('\n\n'.join(segs), ns)

tf = os.path.join(F, 'disp.txt')
io.open(tf, 'w', encoding='utf-8').write(
    '9.example.com\n1.example.com\n# Группа 1\n8.8.8.8\n1.1.1.1\n'
    '# Пометка без записей\n7.7.7.7\n')
secs = ns['load_bypass_blocks'](tf)
disp = ns['format_blocks_for_display'](secs)
expect = ('1.example.com\n9.example.com\n\n# Группа 1\n1.1.1.1\n8.8.8.8\n\n'
          '# Пометка без записей\n7.7.7.7')
if disp == expect:
    ok('G1: просмотр = порядок файла + сортировка в секции + comment-only видны')
else:
    bad(f'G1: {disp!r} != {expect!r}')
if disp.startswith('1.example.com\n9.example.com'):
    ok('G2: безымянные записи не «всплыли» в конец')
else:
    bad('G2: порядок безымянных нарушен')
if '# Пометка без записей' in disp:
    ok('G3: comment-only секция показывается (N-3 паритет)')
else:
    bad('G3: comment-only скрыт')
if ns['format_blocks_for_display']( []) == 'Список пуст':
    ok('G4: пустой список — «Список пуст»')
else:
    bad('G4: пустой список не обработан')
# Настоящий контракт R48-5: то, что пользователь ВИДИТ, равно тому,
# что оказалось бы в файле после сохранения (round-trip через
# parse_and_save — рендер сохранения сортирует записи так же).
d2 = os.path.join(F, 'lists'); os.makedirs(d2)
lc.UNBLOCK_DIR = d2
tf2 = os.path.join(d2, 'vless.txt')
lc.parse_and_save(tf2, ns['sections_to_text'](secs))
saved = io.open(tf2, encoding='utf-8').read()
if disp == saved.rstrip('\n'):
    ok('G5: просмотр ≡ файлу после сохранения (round-trip parse_and_save)')
else:
    bad(f'G5: {disp!r} != {saved!r}')
io.open(os.path.join(F, 'g.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
GP=0; GF=1
[ -s "$F/g.counts" ] && read GP GF < "$F/g.counts"
PASS=$((PASS+GP)); FAIL=$((FAIL+GF))

echo "═══ H. R48-7: wsSettings.host ═══"
TPL="$K/opt/etc/bot/templates/vless_template.json"
grep -q '"host":"{{ws_host}}"' "$TPL" \
    && ok "H1: шаблон: wsSettings.host (новая форма)" \
    || bad "H1: шаблон не содержит host"
NOLD=$(grep -c '"headers"\|"Host"' "$TPL" || true)
[ "$NOLD" = 0 ] \
    && ok "H2: шаблон: headers/Host отсутствуют" \
    || bad "H2: устаревшая форма в шаблоне ($NOLD)"
python3 - "$K" "$F" <<'PYB'
import ast, io, json, os, sys
K, F = sys.argv[1], sys.argv[2]
_p = [0]; _f = [0]
def ok(m):
    _p[0] += 1; print('[OK]   ' + m)
def bad(m):
    _f[0] += 1; print('[FAIL] ' + m)

grep_tpl = io.open(os.path.join(
    K, 'opt/etc/bot/templates/vless_template.json'),
    encoding='utf-8').read()
if '"path":"{{ws_path}}"' in grep_tpl and '{{ws_host}}' in grep_tpl:
    ok('H3: ws-блок шаблона структурно цел (path+host; рендер — f41)')
else:
    bad('H3: ws-блок шаблона повреждён')

src = io.open(os.path.join(K, 'opt/etc/bot/utils.py'), encoding='utf-8').read()
seg = [ast.get_source_segment(src, n) for n in ast.parse(src).body
       if isinstance(n, ast.FunctionDef) and n.name == '_convert_singbox_vless'][0]
ns = {}
exec(seg, ns)
fn = ns['_convert_singbox_vless']

sb_old = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/ws',
                        'headers': {'Host': 'cdn.example.org'}}}
ws = fn(sb_old)['outbounds'][0]['streamSettings']['wsSettings']
if ws == {'path': '/ws', 'host': 'cdn.example.org'}:
    ok('H4: sing-box headers.Host → wsSettings.host (фолбэк старой формы)')
else:
    bad(f'H4: {ws!r}')

sb_new = {'server': 's.example', 'server_port': 443, 'uuid': 'u',
          'transport': {'type': 'ws', 'path': '/w', 'host': 'h.example'}}
ws2 = fn(sb_new)['outbounds'][0]['streamSettings']['wsSettings']
if ws2 == {'path': '/w', 'host': 'h.example'}:
    ok('H5: sing-box host → wsSettings.host (приоритет новой формы)')
else:
    bad(f'H5: {ws2!r}')
io.open(os.path.join(F, 'h.counts'), 'w').write(f'{_p[0]} {_f[0]}\n')
sys.exit(1 if _f[0] else 0)
PYB
HP=0; HF=1
[ -s "$F/h.counts" ] && read HP HF < "$F/h.counts"
PASS=$((PASS+HP)); FAIL=$((FAIL+HF))

echo "═══ I. Маркеры, синтаксис, контракты ═══"
MD=$(grep -c 'R48-[1268] (аудит-18)' "$K/opt/bin/deploy_bypass.sh" || true)
[ "$MD" = 4 ] \
    && ok "I1: маркеры R48-1/2/6/8 в deploy (4)" \
    || bad "I1: маркеров в deploy = $MD (ожидалось 4)"
grep -q 'R48-3 (аудит-18)' "$K/opt/etc/init.d/S99generator" \
    && grep -q 'R48-9 (аудит-18)' "$K/opt/bin/test_udp_tunnels.sh" \
    && grep -q 'R48-5 (аудит-18)' "$K/opt/etc/bot/handlers.py" \
    && grep -q 'R48-7 (аудит-18)' "$K/opt/etc/bot/utils.py" \
    && ok "I2: маркеры R48-3/9/5/7 на местах" \
    || bad "I2: какой-то маркер отсутствует"
dash -n "$K/opt/bin/deploy_bypass.sh" && dash -n "$K/opt/etc/init.d/S99generator" \
    && dash -n "$K/opt/bin/test_udp_tunnels.sh" \
    && ok "I3: синтаксис правленых shell-файлов (dash -n)" \
    || bad "I3: dash -n упал"
python3 -m py_compile "$K/opt/etc/bot/handlers.py" "$K/opt/etc/bot/utils.py" \
    && ok "I4: py_compile handlers.py + utils.py" \
    || bad "I4: py_compile упал"
grep -q 'web INPUT DROP add/verify failed' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    && ok "I5: хук 100-redirect.sh на месте (правки аудита-18 его не касались)" \
    || bad "I5: хук неожиданно изменён"
# FB-43 (аудит-28): единственная правка хука в r54 — гейт кэша (_IPT_CAPABLE);
# всё прочее содержимое обязано совпадать с HEAD.
if git -C "$K" rev-parse --git-dir >/dev/null 2>&1; then
    I6D=$(git -C "$K" diff HEAD -- opt/etc/ndm/netfilter.d/100-redirect.sh \
        | grep -E '^[+-]' | grep -vE '^(\+\+\+|---)')
    I6N=$(printf '%s\n' "$I6D" | grep -c '^-')
    I6M=$(printf '%s\n' "$I6D" | grep -c '^+if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]')
    I6C=$(printf '%s\n' "$I6D" | grep -c '^+#')
    I6T=$(printf '%s\n' "$I6D" | grep -vcE '^(\+#|\+if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]|-if \[ -n "\$_KZ_HOOK_TMPDIR" \]; then$)')
    if [ -z "$I6D" ]; then
        ok "I6: хук не отличается от Git HEAD"
    elif [ "$I6N" = 1 ] && [ "$I6M" = 1 ] && [ "$I6T" = 0 ] && [ "$I6C" -ge 1 ]; then
        ok "I6: диф хука = только гейт кэша FB-43 (1 строка ужесточена, прочее = HEAD)"
    else
        bad "I6: неожиданный диф хука (n=$I6N m=$I6M c=$I6C t=$I6T)"
    fi
else
    ok "I6: [SKIP] git-раскладка — сверка с HEAD не требуется"
fi
grep -q 'safe_start_service "S99generator"' "$K/opt/bin/deploy_bypass.sh" \
    && grep -A3 'safe_start_service() {' "$K/opt/bin/deploy_bypass.sh" | grep -q '|| true' \
    && ok "I7: deploy не падает от SKIPPED (safe_start_service глотает rc)" \
    || bad "I7: контракт safe_start_service изменён"

echo "═══ R. Аудит-26: S57-гейт с портом, PID-личность, гейты/кэш/панель ═══"

# R0 (FB-23/K51-1/R51-01): заглушка сервера с ПОРТОМ и валидным auth
# тоже отсекается гейтом S57 (ранее example.com:443 проходил на старт).
RB="$F/rb"; mkdir -p "$RB"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$RB/gate.sh"
cat > "$RB/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/rb/gate.sh
echo "GATE_RC=PASS"
EOF
chmod +x "$RB/run.sh"
printf '{\n  "server": "example.com:443",\n  "auth": "realkey"\n}\n' > "$RB/p1.json"
printf '{\n  "server": "example.com:8443",\n  "auth": "realkey"\n}\n' > "$RB/p2.json"
printf '{\n  "server": "example.com",\n  "auth": "realkey"\n}\n' > "$RB/p3.json"
printf '{\n  "server": "",\n  "auth": "realkey"\n}\n' > "$RB/p4.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "realkey",\n  "tls": {"sni": "example.com"}\n}\n' > "$RB/p5.json"
printf '{\n  "server": "real.example.org:443",\n  "auth": "realkey"\n}\n' > "$RB/p6.json"
R0A=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" sh "$RB/run.sh" start 2>&1)
R0B=$(KEENZOO_HYSTERIA_CONFIG="$RB/p2.json" sh "$RB/run.sh" start 2>&1)
R0C=$(KEENZOO_HYSTERIA_CONFIG="$RB/p3.json" sh "$RB/run.sh" start 2>&1)
R0D=$(KEENZOO_HYSTERIA_CONFIG="$RB/p4.json" sh "$RB/run.sh" start 2>&1)
R0E=$(KEENZOO_HYSTERIA_CONFIG="$RB/p5.json" sh "$RB/run.sh" start 2>&1)
R0F=$(KEENZOO_HYSTERIA_CONFIG="$RB/p6.json" sh "$RB/run.sh" start 2>&1)
if printf '%s\n%s' "$R0A" "$R0B" | grep -q 'SKIPPED: hysteria не настроена' \
    && printf '%s\n%s' "$R0C" "$R0D" | grep -q 'SKIPPED: hysteria не настроена' \
    && ! printf '%s\n%s\n%s\n%s' "$R0A" "$R0B" "$R0C" "$R0D" | grep -q GATE_RC \
    && printf '%s' "$R0E" | grep -q GATE_RC=PASS \
    && printf '%s' "$R0F" | grep -q GATE_RC=PASS; then
    ok "R0: S57: example.com:443/:8443/без-порта/пустой + валидный auth → SKIPPED; SNI-маскировка и реальный → старт (K51-1/R51-01)"
else
    bad "R0: a=$(echo "$R0A" | tail -1) b=$(echo "$R0B" | tail -1) c=$(echo "$R0C" | tail -1) d=$(echo "$R0D" | tail -1) e=$(echo "$R0E" | tail -1) f=$(echo "$R0F" | tail -1)"
fi

# R1 (FB-25/K51-3/R51-03): pid-файл — только подсказка: сигнал только
# процессу, чей /proc/PID/cmdline относится к hysteria; сам pid-файл
# снимается при любом исходе; PID 0/мусор безопасны; stop не задет.
R1STATE(){ [ -r "/proc/$1/stat" ] && awk '{print $3}' "/proc/$1/stat" 2>/dev/null || echo X; }
RP="$F/rp"; mkdir -p "$RP"
# FB-48 (аудит-28, R53-05): личность процесса — по /proc/PID/exe, поэтому
# «свой» фейкуется РЕАЛЬНЫМ исполняемым файлом с именем hysteria (прежний
# скрипт-фейк имел exe=/bin/sh и по exe-признаку «своим» не является).
cp /bin/sleep "$RP/hysteria" 2>/dev/null \
    || cp /usr/bin/sleep "$RP/hysteria" 2>/dev/null \
    || cp "$(command -v sleep)" "$RP/hysteria"
chmod +x "$RP/hysteria"
# a) чужой живой процесс — не тронут, pid снят
sleep 60 & R1P1=$!
printf '%s\n' "$R1P1" > "$RP/pid"
R1A=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
R1A1=$(R1STATE "$R1P1"); [ -e "$RP/pid" ] && R1A2=present || R1A2=removed
kill "$R1P1" 2>/dev/null; wait "$R1P1" 2>/dev/null
# b) свой процесс (exe = .../hysteria) — снят с «Stopping»
"$RP/hysteria" 600 & R1P2=$!
sleep 1
printf '%s\n' "$R1P2" > "$RP/pid"
R1B=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
sleep 1
R1B1=$(R1STATE "$R1P2"); [ -e "$RP/pid" ] && R1B2=present || R1B2=removed
wait "$R1P2" 2>/dev/null
# b2) чужой процесс с подстрокой hysteria в argv, но чужим exe —
#     НЕ убит (FB-48: прежний матч *hysteria* по cmdline убивал бы его)
bash -c 'exec -a hysteria-marker sleep 60' & R1P3=$!
sleep 1
printf '%s\n' "$R1P3" > "$RP/pid"
R1F=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1)
R1F1=$(R1STATE "$R1P3")
kill "$R1P3" 2>/dev/null; wait "$R1P3" 2>/dev/null
# c) PID 0 (kill 0 = process-group) и d) мусорный PID — никто не тронут
printf '0\n' > "$RP/pid"
R1C=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1); R1C1=$?
[ -e "$RP/pid" ] && R1C2=present || R1C2=removed
printf '999999999\n' > "$RP/pid"
R1D=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" KEENZOO_HYSTERIA_PIDFILE="$RP/pid" sh "$RB/run.sh" start 2>&1); R1D1=$?
[ -e "$RP/pid" ] && R1D2=present || R1D2=removed
# e) stop не задет гейтом
R1E=$(KEENZOO_HYSTERIA_CONFIG="$RB/p1.json" sh "$RB/run.sh" stop 2>&1)
if [ "$R1A1" != Z ] && [ "$R1A1" != X ] && [ "$R1A2" = removed ] \
    && { [ "$R1B1" = Z ] || [ "$R1B1" = X ]; } && [ "$R1B2" = removed ] \
    && printf '%s' "$R1B" | grep -q 'Stopping hysteria' \
    && [ "$R1F1" != Z ] && [ "$R1F1" != X ] \
    && [ "$R1C1" = 0 ] && [ "$R1C2" = removed ] \
    && [ "$R1D1" = 0 ] && [ "$R1D2" = removed ] \
    && printf '%s' "$R1E" | grep -q GATE_RC=PASS; then
    ok "R1: S57 PID: чужой жив+pid снят; свой (exe) снят с «Stopping»; argv-подстрока чужого не убита; 0/мусор безопасны; stop цел (K51-3/R51-03+FB-48)"
else
    bad "R1: a1=$R1A1/$R1A2 b1=$R1B1/$R1B2 f1=$R1F1 c=$R1C1/$R1C2 d=$R1D1/$R1D2 e=$(echo "$R1E" | tail -1)"
fi

# R2 (FB-24/R51-02): HTTP-гейт — обе копии, 6 форм opkg.conf.
RG="$F/rg"; mkdir -p "$RG"
awk '/^_kz_http_feed_active\(\) \{/,/^\}$/' "$DEP" > "$RG/dep.sh"
awk '/^_kz_http_install_gate\(\) \{/,/^\}$/' "$DEP" >> "$RG/dep.sh"
awk '/^_upd_http_feed_active\(\) \{/,/^\}$/' "$K/opt/bin/update_protocols.sh" > "$RG/upd.sh"
awk '/^_upd_http_install_gate\(\) \{/,/^\}$/' "$K/opt/bin/update_protocols.sh" >> "$RG/upd.sh"
printf 'src/gz entware http://bin.entware.net/x\n' > "$RG/plain"
printf '   src/gz entware http://bin.entware.net/x\n' > "$RG/lead"
printf 'src/gz "entware" "http://bin.entware.net/x"\n' > "$RG/quoted"
printf '\t src "entware" http://bin.entware.net/x\n' > "$RG/mixed"
printf 'src/gz entware https://bin.entware.net/x\n' > "$RG/https"
cat > "$RG/depdrv.sh" <<'EOF'
#!/bin/sh
warn(){ echo "WARN: $*"; }
. /tmp/f47chk/rg/dep.sh
KZ_DEPLOY_OPKG_CONF="$1"; export KZ_DEPLOY_OPKG_CONF
_kz_http_install_gate testpkg; echo "rc=$?"
EOF
cat > "$RG/upddrv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/rg/upd.sh
KZ_DEPLOY_OPKG_CONF="$1"; export KZ_DEPLOY_OPKG_CONF
_upd_http_install_gate testpkg; echo "rc=$?"
EOF
chmod +x "$RG/depdrv.sh" "$RG/upddrv.sh"
R2RES=""
for cfg in plain lead quoted mixed https missing; do
    [ "$cfg" = missing ] && conf="$F/rg/no-such-file" || conf="$RG/$cfg"
    unset KEENZOO_ALLOW_HTTP_FEED
    D=$(sh "$RG/depdrv.sh" "$conf" 2>&1 | tail -1)
    U=$(sh "$RG/upddrv.sh" "$conf" 2>&1 | tail -1)
    case "$cfg" in
        https) EXP="rc=0|rc=0" ;;
        *) EXP="rc=1|rc=1" ;;
    esac
    R2RES="$R2RES $cfg=${D#rc=}/${U#rc=}"
    [ "$D|$U" = "$EXP" ] || R2BAD="$R2BAD $cfg"
done
unset KEENZOO_ALLOW_HTTP_FEED
R2M=$(sh "$RG/depdrv.sh" "$F/rg/no-such-file" 2>&1; sh "$RG/upddrv.sh" "$F/rg/no-such-file" 2>&1)
if [ -z "${R2BAD:-}" ] && printf '%s' "$R2M" | grep -q 'не читается'; then
    ok "R2: HTTP-гейт (deploy+updater): plain/lead/quoted/mixed → блок, https → rc0, missing → fail-closed warn (R51-02)"
else
    bad "R2:$R2RES bad=[$R2BAD] missing_warn=$(printf '%s' "$R2M" | grep -c 'не читается')"
fi

# R3 (FB-26/K51-2): мемоизация opkg list-installed.
RM="$F/rm"; mkdir -p "$RM/bin"
awk '/^_kz_pkg_installed\(\) \{/,/^\}$/' "$DEP" > "$RM/fns.sh"
awk '/^_kz_pkg_cache_note\(\) \{/,/^\}$/' "$DEP" >> "$RM/fns.sh"
cat > "$RM/bin/opkg" <<'EOF'
#!/bin/sh
echo "opkg-call $*" >> /tmp/f47chk/rm/opkg.log
printf 'tor - 0.1\nxray - 1.0\n'
exit 0
EOF
chmod +x "$RM/bin/opkg"
cat > "$RM/drv.sh" <<'EOF'
#!/bin/sh
PATH="/tmp/f47chk/rm/bin:$PATH"; export PATH
. /tmp/f47chk/rm/fns.sh
_kz_pkg_installed tor; echo "tor=$?"
_kz_pkg_installed xray; echo "xray=$?"
_kz_pkg_installed tor; echo "tor2=$?"
_kz_pkg_installed dnsmasq-full; echo "dns=$?"
_kz_pkg_cache_note dnsmasq-full
_kz_pkg_installed dnsmasq-full; echo "dns2=$?"
EOF
R3OUT=$(sh "$RM/drv.sh" 2>&1)
R3N=$(wc -l < "$RM/opkg.log" 2>/dev/null || echo 0)
if printf '%s' "$R3OUT" | grep -q 'tor=0' && printf '%s' "$R3OUT" | grep -q 'xray=0' \
    && printf '%s' "$R3OUT" | grep -q 'tor2=0' && printf '%s' "$R3OUT" | grep -q 'dns=1' \
    && printf '%s' "$R3OUT" | grep -q 'dns2=0' && [ "$R3N" = 1 ]; then
    ok "R3: мемоизация: 6 проверок → 1 вызов opkg list-installed; cache_note виден (K51-2)"
else
    bad "R3: out=$(echo "$R3OUT" | tr '\n' ' ') calls=$R3N"
fi

# R4 (FB-28/R51-07): порог тела для вердикта Range — ≤256 Б.
RR="$F/rr"; mkdir -p "$RR/bin" "$RR/dl"
awk '/^_entware_probe_feed_url\(\) \{/,/^\}$/' "$DEP" > "$RR/fn.sh"
cat > "$RR/drv.sh" <<'EOF'
#!/bin/sh
PATH="/tmp/f47chk/rr/bin:/bin:/usr/bin"; export PATH
KEENZOO_DLTMP=/tmp/f47chk/rr/dl; export KEENZOO_DLTMP
DL_CMD=curl; export DL_CMD
have_cmd(){ command -v "$1" >/dev/null 2>&1; }
warn(){ :; }
ensure_dns(){ :; }
. /tmp/f47chk/rr/fn.sh
_entware_probe_feed_url "https://bin.entware.net/armv7sf-k3.2/Packages.gz"
echo "rc=$? note=${_EPF_NOTE}"
EOF
R4R=""; R4BAD=""
for sz in 256 1000; do
    printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && head -c %s /dev/zero > "$2"; shift; done\nexit 0\n' "$sz" > "$RR/bin/curl"
    chmod +x "$RR/bin/curl"
    OUT=$(sh "$RR/drv.sh" 2>&1)
    R4R="$R4R [$sz] $(echo "$OUT" | tail -1)"
    if [ "$sz" = 256 ]; then
        echo "$OUT" | grep -q 'range' || R4BAD="$R4BAD $sz"
    else
        echo "$OUT" | grep -q 'полная загрузка' || R4BAD="$R4BAD $sz"
    fi
done
if [ -z "$R4BAD" ]; then
    ok "R4: Range-проба: 256Б → range-вердикт, 1000Б → полная загрузка (R51-07)"
else
    bad "R4:$R4R bad=[$R4BAD]"
fi

# R5 (FB-29/R51-05): SKIPPED_HTTP — сбор со всех гейтов шага, сводка в конце.
R5A=$(grep -c '^SKIPPED_HTTP=""$' "$DEP")
R5B=$(grep -c 'SKIPPED_HTTP="${SKIPPED_HTTP} ' "$DEP")
R5I=$(grep -n '^SKIPPED_HTTP=""$' "$DEP" | head -1 | cut -d: -f1)
R5L=$(grep -n 'SKIPPED_HTTP="${SKIPPED_HTTP} ' "$DEP" | tail -1 | cut -d: -f1)
R5S=$(grep -n 'Пакеты не установлены из-за HTTP-политики' "$DEP" | head -1 | cut -d: -f1)
if [ "$R5A" = 1 ] && [ "$R5B" = 6 ] && [ -n "$R5I" ] && [ -n "$R5L" ] && [ -n "$R5S" ] \
    && [ "$R5I" -lt "$R5L" ] && [ "$R5L" -lt "$R5S" ]; then
    ok "R5: SKIPPED_HTTP: 6 точек сбора, сводка после последней (dnsmasq-full) (R51-05)"
else
    bad "R5: init=$R5A points=$R5B i=$R5I last=$R5L summary=$R5S"
fi

# R6 (FB-31/R51-06): example.com в sni/serverName/peer_name — не заглушка.
RN="$F/rn"; mkdir -p "$RN"
awk '/^needs_key\(\) \{/,/^\}$/' "$DEP" > "$RN/nk.sh"
printf '{\n  "server": "real.example.org:443",\n  "auth": "k",\n  "tls": {"sni": "example.com"}\n}\n' > "$RN/sni.json"
printf '{\n  "server": "example.com:443",\n  "auth": "k"\n}\n' > "$RN/stub.json"
cat > "$RN/drv.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/rn/nk.sh
needs_key /tmp/f47chk/rn/sni.json; echo "sni=$?"
needs_key /tmp/f47chk/rn/stub.json; echo "stub=$?"
EOF
R6OUT=$(sh "$RN/drv.sh" 2>&1)
R6GREP=$(grep -c '_SNI_VALUE_RE' "$K/opt/etc/bot/utils.py" || true)
if printf '%s' "$R6OUT" | grep -q 'sni=1' && printf '%s' "$R6OUT" | grep -q 'stub=0' \
    && [ "$R6GREP" -ge 1 ]; then
    ok "R6: needs_key: SNI-маскировка не «заглушка», server-stub — заглушка; _SNI_VALUE_RE в utils (R51-06+FB-36)"
else
    bad "R6: out=$(echo "$R6OUT" | tr '\n' ' ') utils_re=$R6GREP"
fi

# R7 (FB-32/R50-UX-1): CFG_STATE несёт web_username; баннер — фактическое имя.
RQ="$F/rq"; mkdir -p "$RQ"
sed -n "/^CFG_STATE=\"\$(python3 -/,/^PYEOF$/p" "$DEP" | sed '1d;$d' | sed "s|'/opt/etc/bot'|'$RQ'|" > "$RQ/cfgstate.py"
printf 'token = "X"\nallowed_user_ids = [1]\nweb_password = "Y"\n' > "$RQ/bot_config.py"
R7A=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
printf 'web_username = "ivan"\n' >> "$RQ/bot_config.py"
R7B=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
# FB-49 (аудит-28, R53-10): баннер — ветка if/else (пустое имя = «панель
# не настроена», семантика S99/CFG_STATE), а не молчаливый «admin».
sed -n "/^_panel_user=\"\$(grep/,/^fi$/p" "$DEP" | sed "s|/opt/etc/bot/bot_config.py|$RQ/bot_config.py|" > "$RQ/banner.sh"
R7C=$(sh "$RQ/banner.sh" 2>/dev/null)
sed -i 's/^web_username.*/web_username = ""/' "$RQ/bot_config.py"
R7D=$(python3 "$RQ/cfgstate.py" 2>/dev/null)
R7E=$(grep -c '\[ "\${4:-empty}" = "ok" \] || NEED_CONFIG=1' "$DEP" || true)
R7F=$(sh "$RQ/banner.sh" 2>/dev/null)
if [ "$R7A" = "ok ok ok empty" ] && [ "$R7B" = "ok ok ok ok" ] && [ "$R7D" = "ok ok ok empty" ] \
    && printf '%s' "$R7C" | grep -q '(ivan,' \
    && printf '%s' "$R7F" | grep -q 'панель не настроена: web_username пуст' \
    && [ "$R7E" = 1 ]; then
    ok "R7: CFG_STATE 4-й токен web_username; баннер: имя или «панель не настроена» (R50-UX-1+FB-49)"
else
    bad "R7: a=[$R7A] b=[$R7B] d=[$R7D] ivan=[$R7C] empty=[$R7F] tok4=$R7E"
fi

# R8+R9+R10 (FB-30/FB-33/N51-1): панель — если flask доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/r8.out" 2>&1 <<'PYR8'
import sys, time, threading
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g

# R8 (FB-30/N51-2): lock + повторная проверка; конкурентный шторм → 3 форка.
lock_ok = ('_LAN_HOSTS_LOCK = threading.Lock()' in open(
    sys.argv[1] + '/opt/etc/bot/generator.py', encoding='utf-8').read())
calls = {'n': 0}
class _R:
    def __init__(self, out): self.stdout = out
class _SP:
    TimeoutExpired = Exception
    def run(self, args, **kw):
        calls['n'] += 1; time.sleep(0.05)
        return _R('    inet 192.168.1.1/24 brd x br0\n')
g.subprocess = _SP()
g._LAN_HOSTS_CACHE['ts'] = 0.0
for _ in range(8):
    threading.Thread(target=lambda: g._lan_host_addresses()).start()
while threading.active_count() > 1:
    time.sleep(0.02)
print('R8 %s forks=%d' % ('OK' if lock_ok and calls['n'] == 3 else 'BAD',
                          calls['n']))

# R9 (FB-33): _auth_cmp — модульное сравнение, не-ASCII не роняет.
try:
    r9 = (g._auth_cmp('a', 'a') is True and g._auth_cmp('a', 'b') is False
          and g._auth_cmp('пароль', 'пароль') is True)
    print('R9 %s' % ('OK' if r9 else 'BAD'))
except Exception as e:
    print('R9 BAD %s' % e)

# R10 (N51-1): cross-list warning; маршрут на api_lookup_add; декораторы целы.
lines = open(sys.argv[1] + '/opt/etc/bot/generator.py',
             encoding='utf-8').read().split('\n')
bad_dec = []
for i, l in enumerate(lines):
    if l.strip().startswith('@app.route'):
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines) or not lines[j].startswith('def '):
            bad_dec.append(i + 1)
g.config.web_username = 'admin'; g.config.web_password = 'testpass'
g.config.list_files = {'vless': '/tmp/f47chk/rl_vless.txt',
                       'hysteria': '/tmp/f47chk/rl_hy.txt',
                       'bot': '/tmp/f47chk/rl_bot.txt'}
open('/tmp/f47chk/rl_vless.txt', 'w').write('crossdup.example\n')
open('/tmp/f47chk/rl_hy.txt', 'w').write('')
c = g.app.test_client()
TOK = 'a' * 64
with c.session_transaction() as s:
    s['csrf_token'] = TOK
r = c.post('/api/lookup-add', headers={'Origin': 'http://127.0.0.1'},
           auth=('admin', 'testpass'),
           data={'list': 'hysteria', 'entries': 'crossdup.example',
                 'csrf_token': TOK})
b = r.get_json() or {}
r3 = c.post('/api/lookup-add', headers={'Origin': 'http://127.0.0.1'},
            auth=('admin', 'testpass'),
            data={'list': 'hysteria', 'entries': 'fresh.example',
                  'csrf_token': TOK})
b3 = r3.get_json() or {}
r2 = c.post('/api/lookup-add', headers={'Origin': 'http://evil.example'},
            auth=('admin', 'testpass'),
            data={'list': 'hysteria', 'entries': 'x.example',
                  'csrf_token': TOK})
ok10 = (not bad_dec and r.status_code == 200 and b.get('added') == ['crossdup.example']
        and 'vless' in (b.get('warning') or '')
        and r3.status_code == 200 and 'warning' not in b3
        and r2.status_code == 403)
print('R10 %s status=%s warn=%s fresh=%s evil=%s dec=%s' % (
    'OK' if ok10 else 'BAD', r.status_code,
    'vless' in (b.get('warning') or ''), 'warning' not in b3,
    r2.status_code, bad_dec))
PYR8
    grep -q '^R8 OK' "$F/r8.out" \
        && ok "R8: LAN-кэш под lock; 8 потоков → 3 форка (N51-2)" \
        || bad "R8: $(grep '^R8' "$F/r8.out")"
    grep -q '^R9 OK' "$F/r8.out" \
        && ok "R9: _auth_cmp модульная, ASCII/не-ASCII (FB-33)" \
        || bad "R9: $(grep '^R9' "$F/r8.out")"
    grep -q '^R10 OK' "$F/r8.out" \
        && ok "R10: N51-1: cross-list warning в ответе; свежие — без warning; чужой Origin 403; все @app.route ведут на def (маршрут lookup-add цел)" \
        || bad "R10: $(grep '^R10' "$F/r8.out")"
else
    echo "[SKIP] R8/R9/R10: Flask-смоук — flask не установлен на хосте"
fi

# R11 (FB-27/R50-FW-1): benchmark-диапазон в matcher снятия ACCEPT.
R11A=$(grep -c '198\.1\[89\]\.\*' "$DEP" || true)
[ "$R11A" -ge 1 ] \
    && ok "R11: 198.18.0.0/15 в matcher проектных ACCEPT (R50-FW-1)" \
    || bad "R11: matcher=[$R11A]"

# R12 (FB-34/N51-2): wget-ветка tg_send_message предупреждает про argv.
R12A=$(grep -c 'токен кратко виден в argv' "$K/opt/bin/common.sh" || true)
[ "$R12A" -ge 1 ] \
    && ok "R12: warn в wget-ветке tg_send_message (FB-34)" \
    || bad "R12: warn=[$R12A]"

# R13: маркеры правок аудита-26 на местах (карта «маркер → файл»).
R13B=""
for m in FB-24 FB-26 FB-27 FB-28 FB-29 FB-31 FB-32; do
    grep -q "$m (аудит-26" "$DEP" || R13B="$R13B $m(dep)"
done
grep -q 'FB-24 (аудит-26' "$K/opt/bin/update_protocols.sh" || R13B="$R13B FB-24(upd)"
grep -q 'FB-23 (аудит-26' "$S57" || R13B="$R13B FB-23(S57)"
grep -q 'FB-25 (аудит-26' "$S57" || R13B="$R13B FB-25(S57)"
grep -q 'FB-30 (аудит-26' "$GEN" || R13B="$R13B FB-30(gen)"
grep -q 'FB-33 (аудит-26' "$GEN" || R13B="$R13B FB-33(gen)"
grep -q 'N51-1 (аудит-26' "$GEN" || R13B="$R13B N51-1(gen)"
grep -q 'FB-31 (аудит-26' "$K/opt/etc/bot/utils.py" || R13B="$R13B FB-31(utils)"
grep -q 'FB-34 (аудит-26' "$K/opt/bin/common.sh" || R13B="$R13B FB-34(common)"
if [ -z "$R13B" ]; then
    ok "R13: маркеры FB-23..FB-34 + N51-1 во всех правленых файлах"
else
    bad "R13: отсутствуют:[$R13B]"
fi

echo "═══ S. Аудит-27: проба iptables, детекторы заглушек, честные вердикты ═══"

# S0 (FB-35/K52-7): справка --help не доказывает вставку — проба правилом.
SB="$F/sb"; mkdir -p "$SB/bin"
for fn in ipt_has_target ipt_has_match ipt_is_capable _ipt_probe_ok _ipt_candidate_ok; do
    awk -v f="$fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$SB/fns.sh"
    echo >> "$SB/fns.sh"
done
dash -n "$SB/fns.sh" || { bad "S0: экстракция проб-функций невалидна"; }
cat > "$SB/bin/ipset" <<EOF
#!/bin/sh
echo "ipset \$*" >> "$SB/ipset.log"
exit 0
EOF
cat > "$SB/bin/iptables.good" <<EOF
#!/bin/sh
echo "ipt \$*" >> "$SB/ipt.log"
case "\$1 \$2" in
  "-j TPROXY") echo "TPROXY target options:"; echo "  --on-port port"; exit 0;;
  "-m set") echo "set match options:"; exit 0;;
esac
exit 0
EOF
cat > "$SB/bin/iptables.nft" <<'EOF'
#!/bin/sh
# «nft-подобный»: справку печатает (юзерспейс-плагин), вставку — нет
case "$1 $2" in
  "-j TPROXY") echo "TPROXY target options:"; echo "  --on-port port"; exit 0;;
  "-m set") echo "set match options:"; exit 0;;
esac
case " $* " in
  *" -I "*) echo "Warning: Extension TPROXY revision 0 not supported, missing kernel module?" >&2
            echo "iptables v1.8.11 (nf_tables): RULE_APPEND failed" >&2; exit 4;;
esac
exit 0
EOF
chmod +x "$SB/bin/"*
# a) нет ipset → rc 2 (доверяем справке — холодная установка не ломается)
S0A=$(env -i PATH=/usr/bin:/bin sh -c ". '$SB/fns.sh'; _ipt_probe_ok '$SB/bin/iptables.good'; echo \$?" 2>/dev/null)
# b) рабочий бинарник → кандидат rc 0; вставка/удаление и create/destroy парны
: > "$SB/ipt.log"; : > "$SB/ipset.log"
S0B=$(PATH="$SB/bin:/usr/bin:/bin" sh -c ". '$SB/fns.sh'; _ipt_candidate_ok '$SB/bin/iptables.good'; echo \$?" 2>/dev/null)
S0BI=$(grep -c ' -I ' "$SB/ipt.log" || true)
S0BD=$(grep -c ' -D ' "$SB/ipt.log" || true)
S0BC=$(grep -c ' create ' "$SB/ipset.log" || true)
S0BX=$(grep -c ' destroy ' "$SB/ipset.log" || true)
# c) nft-подобный (справка проходит!) → кандидат rc 1 — отвергнут пробой
S0C=$(PATH="$SB/bin:/usr/bin:/bin" sh -c ". '$SB/fns.sh'; _ipt_candidate_ok '$SB/bin/iptables.nft'; echo \$?" 2>/dev/null)
# d) гейт кандидата стоит на всех точках выбора (deploy 5, хук 4) и в хуке есть проба
S0D=$(grep -c '_ipt_candidate_ok "$_c"' "$DEP" || true)
S0E=$(grep -c '_ipt_candidate_ok "$_c"' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || true)
S0F=$(grep -c '^_ipt_probe_ok() {' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || true)
if [ "$S0A" = 2 ] && [ "$S0B" = 0 ] && [ "$S0C" = 1 ] \
    && [ "$S0BI" = "$S0BD" ] && [ "$S0BI" -ge 1 ] && [ "$S0BC" = "$S0BX" ] \
    && [ "$S0D" = 5 ] && [ "$S0E" = 4 ] && [ "$S0F" = 1 ]; then
    ok "S0: проба iptables: без ipset rc2; рабочий rc0 (вставка/удаление парны); nft-подобный rc1; гейт на 5+4 точках, проба в хуке (K52-7)"
else
    bad "S0: a=$S0A b=$S0B c=$S0C i/d=$S0BI/$S0BD c/x=$S0BC/$S0BX sites=$S0D/$S0E hookprobe=$S0F"
fi

# S1 (FB-36/K52-1): минифицированный JSON — значение поля, а не строка.
SC="$F/sc"; mkdir -p "$SC"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$SC/nk.sh"
cat > "$SC/mk.sh" <<'EOF'
#!/bin/sh
. /tmp/f47chk/sc/nk.sh
i=0; fail=0
t(){ i=$((i+1)); printf '%s' "$2" > /tmp/f47chk/sc/c$i.json
     needs_key /tmp/f47chk/sc/c$i.json; r=$?
     [ "$r" = "$3" ] || { echo "case$i($1):rc=$r,want=$3"; fail=1; } }
t 'mini-stub+mask'  '{"server":"example.com:443","auth":"s3cret","tls":{"sni":"vpn.example.org"}}' 0
t 'mini-stub'       '{"server":"example.com","auth":"s3cret"}' 0
t 'mini-empty-srv'  '{"server":"","auth":"s3cret"}' 0
t 'mini-empty-addr' '{"address":"","password":"x"}' 0
t 'multi-stub'      '{
 "server": "example.com:443",
 "auth": "s3cret",
 "tls": {"sni": "vpn.example.org"}
}' 0
t 'multi-stub2'     '{
 "server": "example.com",
 "auth": "k"
}' 0
t 'mini-real+mask'  '{"server":"real.example.org:443","auth":"k","tls":{"sni":"example.com"}}' 1
t 'multi-real+mask' '{
 "server": "real.example.org:443",
 "auth": "k",
 "tls": {"sni": "example.com"}
}' 1
t 'mini-serverName' '{"server":"real.example.org:443","auth":"k","transport":{"tls":{"serverName":"example.com"}}}' 1
t 'mini-sni-clean'  '{"server":"real.example.org:443","auth":"k","tls":{"sni":"ex-ample.com"}}' 1
t 'mini-CHANGE_ME'  '{"password":"CHANGE_ME"}' 0
t 'mini-zero-uuid'  '{"server":"real.example.org:443","uuid":"00000000-0000-0000-0000-000000000000"}' 0
echo "fail=$fail"
EOF
chmod +x "$SC/mk.sh"
S1S=$(sh "$SC/mk.sh" 2>/dev/null | tail -1)
python3 - "$K" > "$F/s1py.out" 2>&1 <<'PYS1'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import importlib.util
spec = importlib.util.spec_from_file_location('u27', sys.argv[1] + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec); spec.loader.exec_module(u)
cases = [(1, True), (2, True), (3, True), (4, True), (5, True), (6, True),
         (7, False), (8, False), (9, False), (10, False), (11, True), (12, True)]
bad = []
for i, want in cases:
    got = u.config_has_placeholders(f'/tmp/f47chk/sc/c{i}.json')
    if got != want:
        bad.append(i)
print('OK' if not bad else 'BAD %r' % bad)
PYS1
if [ "$S1S" = "fail=0" ] && grep -q '^OK$' "$F/s1py.out"; then
    ok "S1: needs_key+utils: 12 кейсов мини/мульти — заглушка в server видна, sni/serverName/peer_name-маскировка чиста (K52-1)"
else
    bad "S1: shell=[$S1S] py=$(cat "$F/s1py.out")"
fi

# S2 (FB-37/K52-4): dnsmasq — честный вердикт при отсутствии бинарника.
SD="$F/sd"; mkdir -p "$SD/bin"
awk '/^DNSMASQ_IPSET_OK=0$/{f=1} f{print} /dnsmasq с поддержкой ipset/{if(f)exit}' "$DEP" > "$SD/blk.sh"
{ echo 'warn(){ echo "WARN: $*"; }'
  echo 'have_cmd(){ command -v "$1" >/dev/null 2>&1; }'
  echo '_kz_http_install_gate(){ return 1; }'
  echo '_kz_pkg_cache_note(){ :; }'
  echo 'SKIPPED_HTTP=""'
  cat "$SD/blk.sh"; } > "$SD/run.sh"
printf '#!/bin/sh\necho "dnsmasq 2.90"\n' > "$SD/bin/dnsmasq.ok"; chmod +x "$SD/bin/dnsmasq.ok"
printf '#!/bin/sh\necho "dnsmasq 2.90 (no-ipset)"\n' > "$SD/bin/dnsmasq.noip"; chmod +x "$SD/bin/dnsmasq.noip"
ln -sf "$SD/bin/dnsmasq.ok" "$SD/bin/dnsmasq"
S2A=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
ln -sf "$SD/bin/dnsmasq.noip" "$SD/bin/dnsmasq"
S2B=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
rm -f "$SD/bin/dnsmasq"
S2C=$(PATH="$SD/bin:/usr/bin:/bin" sh "$SD/run.sh" 2>&1)
if printf '%s' "$S2A" | grep -q '✅ dnsmasq с поддержкой ipset' \
    && ! printf '%s' "$S2B" | grep -q '✅' \
    && printf '%s' "$S2B" | grep -q 'БЕЗ ipset' \
    && ! printf '%s' "$S2C" | grep -q '✅' \
    && printf '%s' "$S2C" | grep -q 'не найден в PATH'; then
    ok "S2: dnsmasq: есть+ipset → ✅; no-ipset → warn без ✅; отсутствует → warn без ✅ (K52-4)"
else
    bad "S2: a=$(echo "$S2A" | head -1) b=$(echo "$S2B" | grep -c WARN) c=$(echo "$S2C" | head -1)"
fi

# S3 (FB-38/K52-3): JS addToList показывает warning из ответа.
S3A=$(grep -c "j.warning?' \\\\u26A0 '+j.warning:''" "$GEN" || true)
[ "$S3A" = 1 ] \
    && ok "S3: addToList: warning отображается (JS-ветка на месте) (K52-3)" \
    || bad "S3: js_branch=$S3A"

# S4 (FB-40/K52-5): единственный opkg list-installed — внутри мемоизации.
# только код: комментарий FB-40 тоже упоминает opkg list-installed
S4A=$(grep -v '^[[:space:]]*#' "$DEP" | grep -c 'opkg list-installed' || true)
[ "$S4A" = 1 ] \
    && ok "S4: opkg list-installed ×1 (мемоизация; ветки iptables закрыты) (K52-5)" \
    || bad "S4: calls=$S4A"

# S5 (FB-41/N52-8): check_updates — tty печатает, не-tty молчит.
SE="$F/se"; mkdir -p "$SE"
awk '/# ── Уведомление ──/{f=1} f{print}' "$K/opt/bin/check_updates.sh" > "$SE/tail.sh"
{ echo 'HAS_UPDATES=true'
  echo 'ARCH=x64'
  echo 'MSG="🆕 <b>Обновления (x64):</b>"'
  echo 'send_telegram(){ echo "TG" >> "'"$SE"'/tg.log"; }'
  cat "$SE/tail.sh"; } > "$SE/drv.sh"
dash -n "$SE/drv.sh" || bad "S5: драйвер невалиден"
rm -f "$SE/tg.log"; sh "$SE/drv.sh" > "$SE/notty.out" 2>/dev/null
S5A=$(wc -c < "$SE/notty.out" | tr -d ' ')
S5B=$([ -f "$SE/tg.log" ] && echo tg || echo notg)
if command -v script >/dev/null 2>&1; then
    S5C=$(script -qec "sh '$SE/drv.sh'" /dev/null 2>/dev/null | tr -d '\r' | grep -c 'Обновления (x64)')
else
    S5C=1  # pty-утилита недоступна — проверяем только не-tty ветку
fi
if [ "$S5A" = 0 ] && [ "$S5B" = tg ] && [ "$S5C" = 1 ]; then
    ok "S5: check_updates: не-tty молчит (Telegram вызван); tty печатает без HTML-тегов (N52-8)"
else
    bad "S5: notty_bytes=$S5A tg=$S5B tty=$S5C"
fi

# S6 (FB-39/K52-6): снимок списков — по Flask, если доступен.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/s6.out" 2>&1 <<'PYS6'
import sys
sys.path.insert(0, sys.argv[1] + '/opt/etc/bot')
import generator as g
g.config.list_files = {n: f'/tmp/f47chk/sf_{n}.txt' for n in
                       ('shadowsocks', 'vless', 'trojan', 'hysteria', 'tor', 'bot')}
for n in g.config.list_files:
    open(g.config.list_files[n], 'w').write(
        '\n'.join(f'd{i}.example' for i in range(500)) + '\n')
calls = {'n': 0}
orig = g.read_file_text
def counting(p):
    calls['n'] += 1
    return orig(p)
g.read_file_text = counting
_cls = g._cross_list_sources('hysteria')
snap_reads = calls['n']
cross = [e for e in (f'd{i}.example' for i in range(100))
         for name, entries in _cls.items() if e in entries]
calls['n'] = 0
wrap = g._cross_list_hint('d0.example', 'hysteria')
ok6 = (snap_reads == 4 and calls['n'] == 4 and len(cross) == 400
       and wrap == ['shadowsocks', 'vless', 'trojan', 'tor'])
print('OK snap=%d wrap_reads=%d cross=%d' % (snap_reads, calls['n'], len(cross))
      if ok6 else 'BAD snap=%d wrap_reads=%d cross=%d wrap=%s' % (
          snap_reads, calls['n'], len(cross), wrap))
PYS6
    grep -q '^OK ' "$F/s6.out" \
        && ok "S6: cross-list: 100 записей → 4 чтения (снимок), предупреждения те же; обёртка жива (K52-6)" \
        || bad "S6: $(cat "$F/s6.out")"
else
    echo "[SKIP] S6: Flask-смоук — flask не установлен на хосте"
fi

# S7: маркеры правок аудита-27 на местах.
S7B=""
for m in FB-35 FB-36 FB-37 FB-40; do
    grep -q "$m (аудит-27" "$DEP" || S7B="$S7B $m(dep)"
done
grep -q 'FB-35 (аудит-27' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || S7B="$S7B FB-35(hook)"
grep -q 'FB-36 (аудит-27' "$K/opt/etc/bot/utils.py" || S7B="$S7B FB-36(utils)"
grep -q 'FB-38' "$GEN" || S7B="$S7B FB-38(gen)"
grep -q 'FB-39' "$GEN" || S7B="$S7B FB-39(gen)"
grep -q 'FB-41 (аудит-27' "$K/opt/bin/check_updates.sh" || S7B="$S7B FB-41(cu)"
if [ -z "$S7B" ]; then
    ok "S7: маркеры FB-35..FB-41 во всех правленых файлах (deploy, хук, utils, generator, check_updates)"
else
    bad "S7: отсутствуют:[$S7B]"
fi

# ═══ T. Аудит-28: регресс JS, HTTP-гейт, вердикт пробы, паритет валидаторов ═══
echo "═══ T. Аудит-28 (r53): JS, гейт 11 форм, |0-вердикт, валидаторы, лимиты ═══"

# T0 (FB-42/R53-01): регресс JS — рендер + node --check каждого блока.
if python3 -c 'import flask' >/dev/null 2>&1 \
    && command -v node >/dev/null 2>&1; then
    python3 - "$K" > "$F/t0.out" 2>&1 <<'PYT0'
import sys, re, subprocess, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
html = c.get('/', auth=('a', 'b')).data.decode()
blocks = re.findall(r'<script[^>]*>(.*?)</script>', html, re.S)
assert blocks, 'нет script-блоков'
for i, b in enumerate(blocks, 1):
    p = f'/tmp/f47chk/t0js{i}.js'
    open(p, 'w').write(b)
    r = subprocess.run(['node', '--check', p], capture_output=True)
    assert r.returncode == 0, 'блок %d: %s' % (
        i, r.stderr.decode()[-140:])
print('OK blocks=%d' % len(blocks))
PYT0
    if grep -q '^OK' "$F/t0.out"; then
        ok "T0: все inline <script> панели валидны (node --check) — регресс FB-38 пойман и закрыт (R53-01)"
    else
        bad "T0: $(tail -1 "$F/t0.out")"
    fi
else
    if ! grep -Fq ":'')}}" "$GEN" && grep -Fq ":'')}" "$GEN"; then
        ok "T0: [частично, без flask/node] исходник addToList без лишней } (R53-01)"
    else
        bad "T0: паттерн регресса JS на месте (R53-01)"
    fi
fi

# T1 (FB-43/R53-03): модули ДО пробы; вердикт пробы — в решении deploy/хука.
T1B=""
_s2=$(grep -n '⏳ \[2/11\]' "$DEP" | head -1 | cut -d: -f1)
_lk=$(grep -n '^load_kmod() {' "$DEP" | head -1 | cut -d: -f1)
_pk=$(awk -v s="$_s2" 'NR>s && /_IPT_PICK="\$\(pick_iptables\)"/{print NR; exit}' "$DEP")
[ -n "$_lk" ] && [ "$_lk" -lt "$_pk" ] || T1B="$T1B load_kmod<pick"
awk -v s="$_s2" -v p="$_pk" 'NR>=s&&NR<p&&/for _dep in nf_defrag_ipv4/{f=1} END{exit !f}' "$DEP" \
    || T1B="$T1B mods-before-pick"
[ "$(grep -c 'if \[ "\$_IPT_CAPABLE" != 1 \]; then' "$DEP")" = 2 ] \
    || T1B="$T1B flag-accept"
grep -q '\[ "\${_ipt_re#\*|}" = 1 \]' "$DEP" || T1B="$T1B repick-flag"
grep -q 'пригодность не подтверждена (гейт справка+проба)' "$DEP" \
    || T1B="$T1B honest-verdict"
grep -q 'if \[ "\$_IPT_CAPABLE" = 1 \] && \[ -n "\$_KZ_HOOK_TMPDIR" \]' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" \
    || T1B="$T1B hook-cache-gate"
TB1="$F/t1"; mkdir -p "$TB1/bin"
cat > "$TB1/bin/iptables" <<'EOF'
#!/bin/sh
case "$*" in
    *--help*) echo "TPROXY target options:"; echo "set match options:"; exit 0 ;;
    *PREROUTING*) exit 4 ;;
esac
exit 0
EOF
cat > "$TB1/bin/ipset" <<'EOF'
#!/bin/sh
exit 0
EOF
chmod +x "$TB1/bin/iptables" "$TB1/bin/ipset"
for _fn in ipt_has_target ipt_has_match ipt_is_capable _ipt_probe_ok _ipt_candidate_ok pick_iptables; do
    awk -v f="$_fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" >> "$TB1/h.sh"
done
T1R=$(PATH="$TB1/bin:/usr/bin:/bin" sh -c ". '$TB1/h.sh'; pick_iptables" 2>/dev/null)
case "$T1R" in
    *'|0') : ;;
    *) T1B="$T1B nft-only[$T1R]" ;;
esac
if [ -z "$T1B" ]; then
    ok "T1: модули до пробы; решение по флагу (|0 ≠ ✅); кэш хука только для |1; nft-only pick → |0 (R53-03)"
else
    bad "T1:$T1B"
fi

# T2 (FB-44/R53-02): HTTP-гейт — 11 форм opkg.conf × обе копии.
T2D=""
extract_fn() { awk -v f="$1" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$2"; }
{ extract_fn _kz_http_feed_active "$DEP"; extract_fn _kz_http_install_gate "$DEP"; } > "$F/t2dep.sh"
{ extract_fn _upd_http_feed_active "$K/opt/bin/update_protocols.sh"; extract_fn _upd_http_install_gate "$K/opt/bin/update_protocols.sh"; } > "$F/t2upd.sh"
warn() { :; }
. "$F/t2dep.sh"
. "$F/t2upd.sh"
T2N=0
t2_case() { # $1=tag $2=content|@DIR|@MISS $3=ожидаемый rc гейта $4=dep|upd
    case "$2" in
        @DIR) rm -rf "$F/t2conf"; mkdir -p "$F/t2conf" ;;
        @MISS) rm -rf "$F/t2conf" ;;
        *) rm -rf "$F/t2conf"; printf '%s\n' "$2" > "$F/t2conf" ;;
    esac
    T2N=$((T2N+1))
    if [ "$4" = dep ]; then
        KZ_DEPLOY_OPKG_CONF="$F/t2conf" _kz_http_install_gate pkg
    else
        KZ_DEPLOY_OPKG_CONF="$F/t2conf" _upd_http_install_gate pkg
    fi
    [ $? = "$3" ] || T2D="$T2D $1-$4"
}
for _cp in dep upd; do
    t2_case srcgz_http 'src/gz entware http://foo/bar' 1 "$_cp"
    t2_case quoted_type '"src/gz" entware http://foo/bar' 1 "$_cp"
    t2_case quoted_all '"src/gz" "entware" "http://foo/bar"' 1 "$_cp"
    t2_case src_plain 'src entware http://foo/bar' 1 "$_cp"
    t2_case indent_q '   src/gz "entware" "http://foo/bar"' 1 "$_cp"
    t2_case dist_gz 'dist/gz feed http://foo/bar' 1 "$_cp"
    t2_case dist 'dist feed http://foo/bar' 1 "$_cp"
    t2_case directory @DIR 1 "$_cp"
    t2_case missing @MISS 1 "$_cp"
    t2_case https 'src/gz entware https://foo/bar' 0 "$_cp"
    t2_case commented '# src/gz entware http://foo/bar' 0 "$_cp"
done
if [ -z "$T2D" ]; then
    ok "T2: HTTP-гейт: 11 форм × deploy+update — 4 fail-open формы закрыты, https/комментарий свободны (R53-02)"
else
    bad "T2:$T2D (из $T2N)"
fi

# T3 (FB-45/R53-04): паритет 4 валидаторов hysteria на 8 конфигах.
T3="$F/t3"; mkdir -p "$T3/cfg"
T3BASE='"tcpRedirect": {"listen": "0.0.0.0:10830"}, "udpTProxy": {"listen": "0.0.0.0:10830"}'
printf '{ "server": "real.example.org:443", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c1.json"
printf '{ "server": "example.com:443", "auth": "realkey", "tls": {"sni": "example.com"}, %s }\n' "$T3BASE" > "$T3/cfg/c2.json"
printf '{ "server": "", "auth": "realkey", %s }\n' "$T3BASE" > "$T3/cfg/c3.json"
printf '{ "server": "real.example.org:443", "auth": "00000000-0000-0000-0000-000000000000", %s }\n' "$T3BASE" > "$T3/cfg/c4.json"
printf '{ "server": "real.example.org:443", "auth": "", %s }\n' "$T3BASE" > "$T3/cfg/c5.json"
printf '{ "server": "real.example.org:443", %s }\n' "$T3BASE" > "$T3/cfg/c6.json"
printf '{ "server": "real.example.org:443", "auth": "CHANGE_ME", %s }\n' "$T3BASE" > "$T3/cfg/c7.json"
printf '{ "server": "{{server}}:{{port}}", "auth": "{{auth}}", %s }\n' "$T3BASE" > "$T3/cfg/c8.json"
T3S57="$T3/rb"; mkdir -p "$T3S57"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$T3S57/gate.sh"
cat > "$T3S57/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
. /tmp/f47chk/t3/rb/gate.sh
echo "GATE_RC=PASS"
EOF
T3B=""
for i in 1 2 3 4 5 6 7 8; do
    . "$(awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$F/t3nk.sh"; echo "$F/t3nk.sh")"
    # FB-54 (аудит-29, N54-2): флаг hysteria включает проверку
    # отсутствующего auth (без флага — xray/ss/trojan без поля auth
    # не считаются заглушками).
    needs_key "$T3/cfg/c$i.json" hysteria
    nk=$?
    s57out=$(KEENZOO_HYSTERIA_CONFIG="$T3/cfg/c$i.json" sh "$T3S57/run.sh" start 2>&1)
    if printf '%s' "$s57out" | grep -q SKIPPED; then s57=SKIP; else s57=START; fi
    case "$i:$nk:$s57" in
        1:1:START|2:0:SKIP|3:0:SKIP|4:0:SKIP|5:0:SKIP|6:0:SKIP|7:0:SKIP|8:0:SKIP) : ;;
        *) T3B="$T3B c$i(nk=$nk,s57=$s57)" ;;
    esac
done
python3 - "$K" > "$F/t3py.out" 2>&1 <<'PYT3'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('u', K + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
exp_ph = {1: False, 2: True, 3: True, 4: True, 5: True,
          6: True, 7: True, 8: True}
exp_pf = {1: 'ok', 2: 'ok', 3: 'rej', 4: 'rej', 5: 'rej',
          6: 'rej', 7: 'rej', 8: 'rej'}
for i in range(1, 9):
    fp = f'/tmp/f47chk/t3/cfg/c{i}.json'
    ph = u.config_has_placeholders(fp, require_auth=True)
    try:
        u._preflight_hysteria(fp)
        pf = 'ok'
    except ValueError:
        pf = 'rej'
    assert ph == exp_ph[i], f'c{i} placeholders={ph}'
    assert pf == exp_pf[i], f'c{i} preflight={pf}'
print('OK')
PYT3
grep -q '^OK' "$F/t3py.out" || T3B="$T3B py:$(tail -1 "$F/t3py.out")"
if [ -z "$T3B" ]; then
    ok "T3: 4 валидатора hysteria сходятся на 8 конфигах, включая отсутствующий auth — FB-54 (R53-04+N54-2)"
else
    bad "T3:$T3B"
fi

# T4 (FB-46+T-2/R53-06-07): lookup-add — 1 чтение target, лимит, bot, точка.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/t4.out" 2>&1 <<'PYT4'
import sys, os, re, importlib.util, tempfile
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzt4_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('')
calls = {'n': 0}
_orig = g.read_file_text
def _cr(fp):
    calls['n'] += 1
    return _orig(fp)
g.read_file_text = _cr
c = g.app.test_client()
with c.session_transaction() as sess:
    sess['auth'] = True
html = c.get('/', auth=('a', 'b')).data.decode()
token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"', html).group(1)
H = {'Origin': 'http://localhost'}
tf = g.config.list_files['trojan']
calls['n'] = 0
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'trojan',
         'entries': '\n'.join('d%d.example' % i for i in range(100))},
         headers=H, auth=('a', 'b'))
assert r.status_code == 200 and calls['n'] == 5, (r.status_code, calls['n'])
g.MAX_LIST_LINES = 5
open(tf, 'w').write('a.example\nb.example\n')
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'trojan',
         'entries': 'x1.example\nx2.example\nx3.example\nx4.example'},
         headers=H, auth=('a', 'b'))
assert r.status_code == 400 and len(open(tf).read().splitlines()) == 2
open(g.config.list_files['vless'], 'w').write('shared.example\n')
calls['n'] = 0
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'bot',
         'entries': 'shared.example'}, headers=H, auth=('a', 'b'))
assert r.status_code == 200 and 'warning' not in r.get_json() and calls['n'] == 1
open(g.config.list_files['tor'], 'w').write('dot.example\n')
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'tor',
         'entries': 'dot.example.'}, headers=H, auth=('a', 'b'))
j = r.get_json()
assert j.get('added') == [] and j.get('duplicates') == ['dot.example']
r = c.post('/api/lookup-add', data={'csrf_token': token, 'list': 'tor',
         'entries': 'weird.example.'}, headers=H, auth=('a', 'b'))
assert r.get_json().get('added') == ['weird.example']
assert 'weird.example.' not in open(g.config.list_files['tor']).read()
print('OK')
PYT4
    if grep -q '^OK' "$F/t4.out"; then
        ok "T4: lookup-add: 100 записей → 5 чтений; лимит 400 без записи; bot без cross; точка нормализована (R53-06/07)"
    else
        bad "T4: $(tail -1 "$F/t4.out")"
    fi
else
    grep -q 'FB-46 (аудит-28, R53-06)' "$GEN" \
        && ok "T4: [частично, без flask] маркеры FB-46/T-2 на месте" \
        || bad "T4: маркеры FB-46/T-2 отсутствуют"
fi

# T5 (FB-47/R53-08): check_updates — «проверка не удалась» ≠ «Обновлений нет».
T5="$F/t5"; mkdir -p "$T5"
awk '/# ── Уведомление ──/{f=1} f{print}' "$K/opt/bin/check_updates.sh" > "$T5/tail.sh"
{ echo 'HAS_UPDATES=false'; echo 'ARCH=x64'
  echo 'CHECK_FAILED=1'
  echo 'send_telegram(){ :; }'
  cat "$T5/tail.sh"; } > "$T5/drv_fail.sh"
{ echo 'HAS_UPDATES=false'; echo 'ARCH=x64'
  echo 'CHECK_FAILED=0'
  echo 'send_telegram(){ :; }'
  cat "$T5/tail.sh"; } > "$T5/drv_ok.sh"
T5B=""
sh "$T5/drv_fail.sh" > "$T5/notty" 2>/dev/null
[ "$(wc -c < "$T5/notty" | tr -d ' ')" = 0 ] || T5B="$T5B fail-notty-не-молчит"
if command -v script >/dev/null 2>&1; then
    script -qec "sh '$T5/drv_fail.sh'" /dev/null 2>/dev/null | tr -d '\r' > "$T5/tty_fail"
    script -qec "sh '$T5/drv_ok.sh'" /dev/null 2>/dev/null | tr -d '\r' > "$T5/tty_ok"
    grep -q 'Проверка обновлений не удалась' "$T5/tty_fail" || T5B="$T5B fail-нет-честного-сбоя"
    grep -q 'Обновлений нет' "$T5/tty_fail" && T5B="$T5B fail-ложное-«нет»"
    grep -q 'Обновлений нет' "$T5/tty_ok" || T5B="$T5B ok-нет-«нет»"
else
    grep -q 'Проверка обновлений не удалась' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-текста-сбоя"
fi
grep -q 'OPKG_UPD_RC=0' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-захвата-rc"
grep -q '\\"check_failed\\":' "$K/opt/bin/check_updates.sh" || T5B="$T5B нет-check_failed-в-JSON"
if [ -z "$T5B" ]; then
    ok "T5: check_updates: сбой источников → «Проверка не удалась» (tty+JSON check_failed), успех → «Обновлений нет» (R53-08)"
else
    bad "T5:$T5B"
fi

# T6 (FB-48/R53-05): PID-личность по /proc/exe.
T6="$F/t6"; mkdir -p "$T6/rp"
awk '/^_kz_hy_cfg=/,/^esac$/' "$S57" > "$T6/rp/gate.sh"
cat > "$T6/rp/run.sh" <<'EOF'
#!/bin/sh
DESC=hysteria
export KEENZOO_HYSTERIA_CONFIG
export KEENZOO_HYSTERIA_PIDFILE
. /tmp/f47chk/t6/rb/gate.sh
echo "GATE_RC=PASS"
EOF
sed -i "s|/tmp/f47chk/t6/rb/|/tmp/f47chk/t6/rp/|" "$T6/rp/run.sh"
printf '{ "server": "real.example.org:443", "auth": "00000000-0000-0000-0000-000000000000" }\n' > "$T6/stub.json"
cp /bin/sleep "$T6/rp/hysteria" 2>/dev/null || cp "$(command -v sleep)" "$T6/rp/hysteria"
chmod +x "$T6/rp/hysteria"
T6B=""
"$T6/rp/hysteria" 300 & T6P1=$!
sleep 1
printf '%s\n' "$T6P1" > "$T6/rp/pid"
T6A=$(KEENZOO_HYSTERIA_CONFIG="$T6/stub.json" KEENZOO_HYSTERIA_PIDFILE="$T6/rp/pid" sh "$T6/rp/run.sh" start 2>&1)
sleep 1
kill -0 "$T6P1" 2>/dev/null && T6B="$T6B свой-не-снят"
printf '%s' "$T6A" | grep -q 'Stopping hysteria' || T6B="$T6B нет-Stopping"
wait "$T6P1" 2>/dev/null
bash -c 'exec -a hysteria-marker sleep 60' & T6P2=$!
sleep 1
printf '%s\n' "$T6P2" > "$T6/rp/pid"
KEENZOO_HYSTERIA_CONFIG="$T6/stub.json" KEENZOO_HYSTERIA_PIDFILE="$T6/rp/pid" sh "$T6/rp/run.sh" start >/dev/null 2>&1
kill -0 "$T6P2" 2>/dev/null || T6B="$T6B argv-чужой-убит"
kill "$T6P2" 2>/dev/null; wait "$T6P2" 2>/dev/null
[ -e "$T6/rp/pid" ] && T6B="$T6B pid-не-снят"
if [ -z "$T6B" ]; then
    ok "T6: S57 PID: свой (exe=hysteria) снят; argv-подстрока чужого не убита; pid снят (R53-05)"
else
    bad "T6:$T6B"
fi

# T7 (FB-49/R53-10): баннер — имя или «панель не настроена».
T7="$F/t7"; mkdir -p "$T7"
sed -n "/^_panel_user=\"\$(grep/,/^fi$/p" "$DEP" | sed "s|/opt/etc/bot/bot_config.py|$T7/bot_config.py|" > "$T7/banner.sh"
printf 'web_username = "ivan"\n' > "$T7/bot_config.py"
T7A=$(sh "$T7/banner.sh" 2>/dev/null)
printf 'web_username = ""\n' > "$T7/bot_config.py"
T7B=$(sh "$T7/banner.sh" 2>/dev/null)
if printf '%s' "$T7A" | grep -q '(ivan,' \
    && printf '%s' "$T7B" | grep -q 'панель не настроена: web_username пуст'; then
    ok "T7: сводка deploy: пустой web_username → «панель не настроена», а не «admin» (R53-10)"
else
    bad "T7: ivan=[$T7A] empty=[$T7B]"
fi

# T8 (FB-50/R53-11): _kz_pkg_installed — литерально + пустой список не залипает.
T8="$F/t8"; mkdir -p "$T8/bin"
awk 'index($0, "_kz_pkg_installed() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$T8/pki.sh"
printf '#!/bin/sh\nexit 1\n' > "$T8/bin/opkg"; chmod +x "$T8/bin/opkg"
T8B=""
(
    PATH="$T8/bin:/usr/bin:/bin"
    . "$T8/pki.sh"
    _KZ_PKG_LIST=""; unset _KZ_PKG_LIST_READY _KZ_PKG_NEW
    _kz_pkg_installed foo
    [ -z "${_KZ_PKG_LIST_READY:-}" ] || exit 3
    exit 0
) || T8B="$T8B пустой-список-залип"
printf '#!/bin/sh\necho "libstdc++ - 1.0"\necho "iptables - 1.8"\n' > "$T8/bin/opkg"; chmod +x "$T8/bin/opkg"
(
    PATH="$T8/bin:/usr/bin:/bin"
    . "$T8/pki.sh"
    _KZ_PKG_LIST=""; unset _KZ_PKG_LIST_READY _KZ_PKG_NEW
    _kz_pkg_installed 'libstdc++' || exit 4
    _kz_pkg_installed 'libstdc' && exit 5
    exit 0
) || T8B="$T8B rc=$?-литерал"
if [ -z "$T8B" ]; then
    ok "T8: _kz_pkg_installed: пустой сбойный список не кэшируется; libstdc++ найден, libstdc — нет (R53-11)"
else
    bad "T8:$T8B"
fi

# T9 (FB-51/R53-09): Range-заметка по коду ответа, а не по размеру.
T9="$F/t9"; mkdir -p "$T9/bin" "$T9/dl"
cat > "$T9/bin/curl" <<'EOF'
#!/bin/sh
out=""; code=""; body=""
for a in "$@"; do
    case "$a" in
        http*://*206*) code=206; body=bbbb ;;
        http*://*200s*) code=200; body=bb ;;
        http*://*nc*) code=""; body=bbbb ;;
        http*://*200b*) code=200; body=bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb ;;
    esac
done
prev=""
for a in "$@"; do
    [ "$prev" = "-o" ] && printf '%s' "$body" > "$a"
    prev="$a"
done
[ -n "$code" ] && printf '%s' "$code"
exit 0
EOF
chmod +x "$T9/bin/curl"
cat > "$T9/drv.sh" <<'EOF'
#!/bin/sh
DL_CMD=curl
KEENZOO_DLTMP=/tmp/f47chk/t9/dl
dl_file() { return 1; }
warn() { :; }
. /tmp/f47chk/t9/pf.sh
_entware_probe_feed_url "$1"
echo "rc=$? NOTE=[$_EPF_NOTE]"
EOF
for _fn in _entware_probe_feed_url; do
    awk -v f="$_fn" 'index($0, f"() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$T9/pf.sh"
done
T9B=""
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f206.example/o)" = "rc=0 NOTE=[curl, range 256Б]" ] || T9B="$T9B 206"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f200s.example/o)" = "rc=0 NOTE=[curl, полная загрузка (сервер без Range)]" ] || T9B="$T9B 200-короткое"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://fnc.example/o)" = "rc=0 NOTE=[curl, range 256Б]" ] || T9B="$T9B фолбэк-без-кода"
[ "$(PATH="$T9/bin:/usr/bin:/bin" sh "$T9/drv.sh" https://f200b.example/o)" = "rc=0 NOTE=[curl, полная загрузка (сервер без Range)]" ] || T9B="$T9B 200-большое"
if [ -z "$T9B" ]; then
    ok "T9: Range-заметка: 206 → range; 200+короткое тело → «полная загрузка» (прежде ложный range); без кода — размер (R53-09)"
else
    bad "T9:$T9B"
fi

# T10: маркеры правок аудита-28 на местах.
T10B=""
grep -q 'FB-43 (аудит-28' "$DEP" || T10B="$T10B FB-43(dep)"
grep -q 'FB-43 (аудит-28' "$K/opt/etc/ndm/netfilter.d/100-redirect.sh" || T10B="$T10B FB-43(hook)"
grep -q 'FB-44 (аудит-28' "$DEP" || T10B="$T10B FB-44(dep)"
grep -q 'FB-44 (аудит-28' "$K/opt/bin/update_protocols.sh" || T10B="$T10B FB-44(upd)"
grep -q 'FB-45 (аудит-28' "$DEP" || T10B="$T10B FB-45(dep)"
grep -q 'FB-45 (аудит-28' "$S57" || T10B="$T10B FB-45(S57)"
grep -q 'FB-45 (аудит-28' "$K/opt/etc/bot/utils.py" || T10B="$T10B FB-45(utils)"
grep -q 'FB-46 (аудит-28' "$GEN" || T10B="$T10B FB-46(gen)"
grep -q 'T-2 (аудит-28' "$GEN" || T10B="$T10B T-2(gen)"
grep -q 'FB-47 (аудит-28' "$K/opt/bin/check_updates.sh" || T10B="$T10B FB-47(cu)"
grep -q 'FB-48 (аудит-28' "$S57" || T10B="$T10B FB-48(S57)"
grep -q 'FB-49 (аудит-28' "$DEP" || T10B="$T10B FB-49(dep)"
grep -q 'FB-50 (аудит-28' "$DEP" || T10B="$T10B FB-50(dep)"
grep -q 'FB-51 (аудит-28' "$DEP" || T10B="$T10B FB-51(dep)"
if [ -z "$T10B" ]; then
    ok "T10: маркеры FB-43..FB-51 + T-2 во всех правленых файлах (FB-42 — JS-паттерн, см. T0)"
else
    bad "T10: отсутствуют:$T10B"
fi

# ═══ U. Аудит-29: гонка записи, счётчик входа, паритет auth ═══
echo "═══ U. Аудит-29 (r54): запись списков, счётчик входа, паритет auth ═══"

# U0 (FB-52/K54-2): 20 параллельных POST — 20×200 и 20/20 записей.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/u0.out" 2>&1 <<'PYU0'
import sys, os, re, importlib.util, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
tmp = tempfile.mkdtemp(prefix='kzu0_')
names = ('shadowsocks', 'vless', 'trojan', 'tor', 'hysteria', 'bot')
g.config.list_files = {n: os.path.join(tmp, n + '.txt') for n in names}
for n in names:
    open(os.path.join(tmp, n + '.txt'), 'w').write('')
N = 20
results = [None] * N
barrier = threading.Barrier(N)
def worker(i):
    c = g.app.test_client()
    with c.session_transaction() as sess:
        sess['auth'] = True
    html = c.get('/', auth=('a', 'b')).data.decode()
    token = re.search(r'name="csrf_token"[^>]*value="([^"]+)"',
                      html).group(1)
    barrier.wait()
    r = c.post('/api/lookup-add',
               data={'csrf_token': token, 'list': 'trojan',
                     'entries': 'p%d.example' % i},
               headers={'Origin': 'http://localhost'},
               auth=('a', 'b'))
    results[i] = r.status_code
ts = [threading.Thread(target=worker, args=(i,)) for i in range(N)]
for t in ts: t.start()
for t in ts: t.join()
ok = sum(1 for c in results if c == 200)
e500 = sum(1 for c in results if c == 500)
content = set(open(g.config.list_files['trojan']).read().splitlines())
landed = sum(1 for i in range(N) if ('p%d.example' % i) in content)
assert ok == N and e500 == 0 and landed == N, (ok, e500, landed)
print('OK')
PYU0
    if grep -q '^OK' "$F/u0.out"; then
        ok "U0: 20 параллельных POST /api/lookup-add: 20×200, 20/20 записей (r54: 13×500, 1/20) (K54-2)"
    else
        bad "U0: $(tail -1 "$F/u0.out")"
    fi
else
    grep -q 'mkstemp' "$K/opt/etc/bot/lists_core.py" \
        && ok "U0: [частично, без flask] mkstemp в _atomic_write_text (K54-2)" \
        || bad "U0: нет mkstemp в lists_core (K54-2)"
fi

# U1 (FB-52): прямой стресс _atomic_write_text — 24 потока, без исключений.
python3 - "$K" > "$F/u1.out" 2>&1 <<'PYU1'
import sys, importlib.util, os, tempfile, threading
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location(
    'lc', K + '/opt/etc/bot/lists_core.py')
lcm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lcm)
d = tempfile.mkdtemp(prefix='kzu1_')
fp = os.path.join(d, 'stress.txt')
open(fp, 'w').write('')
errs = []
def hammer(k):
    try:
        for j in range(30):
            lcm._atomic_write_text(fp, 't%d.%d ' % (k, j) + 'x' * 200)
    except Exception as e:
        errs.append(repr(e))
ts = [threading.Thread(target=hammer, args=(k,)) for k in range(24)]
for t in ts: t.start()
for t in ts: t.join()
left = [f for f in os.listdir(d) if '.tmp' in f]
assert not errs and not left and len(open(fp).read()) > 100, (errs[:2], left)
print('OK')
PYU1
if grep -q '^OK' "$F/u1.out"; then
    ok "U1: _atomic_write_text: 24 потока × 30 записей — 0 исключений, tmp не залипают (K54-2)"
else
    bad "U1: $(tail -1 "$F/u1.out")"
fi

# U2 (FB-52/N54-3): _write_enabled — параллельные переключения, права 0755.
python3 - "$K" > "$F/u2.out" 2>&1 <<'PYU2'
import sys, os, importlib.util, tempfile, threading, stat
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
d = tempfile.mkdtemp(prefix='kzu2_')
scripts = {}
for i in range(4):
    sp = os.path.join(d, 'S99svc%d' % i)
    open(sp, 'w').write('#!/bin/sh\nENABLED=yes\nPROCS=svc%d\n' % i)
    os.chmod(sp, 0o755)
    scripts['svc%d' % i] = sp
g.SERVICE_SCRIPTS = scripts
def toggle(i):
    for j in range(15):
        g._write_enabled('svc%d' % i, (j % 2 == 0))
ts = [threading.Thread(target=toggle, args=(i,)) for i in range(4)]
for t in ts: t.start()
for t in ts: t.join()
modes = {oct(stat.S_IMODE(os.stat(sp).st_mode)) for sp in scripts.values()}
heads = {open(sp).read().splitlines()[1].split('=')[0] for sp in scripts.values()}
left = [f for f in os.listdir(d) if '.tmp' in f]
assert modes == {'0o755'} and heads == {'ENABLED'} and not left, (modes, heads, left)
print('OK')
PYU2
if grep -q '^OK' "$F/u2.out"; then
    ok "U2: _write_enabled: 4×15 параллельных переключений — права 0755, без tmp-остатков (N54-3)"
else
    bad "U2: $(tail -1 "$F/u2.out")"
fi

# U3 (FB-53/N54-4): без кредов — 401 без счётчика; неверные креды — 429.
if python3 -c 'import flask' >/dev/null 2>&1; then
    python3 - "$K" > "$F/u3.out" 2>&1 <<'PYU3'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('g', K + '/opt/etc/bot/generator.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
g.config.web_username = 'a'
g.config.web_password = 'b'
c = g.app.test_client()
noauth = [c.get('/').status_code for _ in range(7)]
wrong = [c.get('/', auth=('a', 'nope')).status_code for _ in range(7)]
good = c.get('/', auth=('a', 'b')).status_code
assert noauth == [401] * 7, noauth
assert wrong[:5] == [401] * 5 and 429 in wrong[5:], wrong
assert good == 200, good
print('OK')
PYU3
    if grep -q '^OK' "$F/u3.out"; then
        ok "U3: вход: 7 без Authorization — все 401; неверные креды — 429; верный пароль — 200 (N54-4)"
    else
        bad "U3: $(tail -1 "$F/u3.out")"
    fi
else
    grep -q 'elif auth is None:' "$GEN" \
        && ok "U3: [частично, без flask] ветка «без кредов» на месте (N54-4)" \
        || bad "U3: нет ветки FB-53 (N54-4)"
fi

# U4 (FB-54/N54-2): флаг hysteria в needs_key и require_auth в placeholders.
U4="$F/u4"; mkdir -p "$U4"
printf '{ "server": "real.example.org:443", "tcpRedirect": {}, "udpTProxy": {} }\n' > "$U4/c6.json"
printf '{ "outbounds": [{ "protocol": "vless", "settings": { "vnext": [{ "address": "real.example.org", "users": [{ "id": "11111111-2222-3333-4444-555555555555" }] }] } }] }\n' > "$U4/vless.json"
awk 'index($0, "needs_key() {")==1{p=1} p{print} p&&/^}$/{p=0}' "$DEP" > "$U4/nk.sh"
U4B=""
(
    . "$U4/nk.sh"
    needs_key "$U4/c6.json" hysteria || exit 1
    needs_key "$U4/c6.json" && exit 2
    needs_key "$U4/vless.json" && exit 3
    exit 0
) || U4B="$U4B needs_key(rc=$?)"
python3 - "$K" > "$F/u4py.out" 2>&1 <<'PYU4'
import sys, importlib.util
K = sys.argv[1]
sys.path.insert(0, K + '/opt/etc/bot')
spec = importlib.util.spec_from_file_location('u', K + '/opt/etc/bot/utils.py')
u = importlib.util.module_from_spec(spec)
spec.loader.exec_module(u)
assert u.config_has_placeholders('/tmp/f47chk/u4/c6.json',
                                 require_auth=True) is True
assert u.config_has_placeholders('/tmp/f47chk/u4/c6.json') is False
assert u.config_has_placeholders('/tmp/f47chk/u4/vless.json') is False
print('OK')
PYU4
grep -q '^OK' "$F/u4py.out" || U4B="$U4B py:$(tail -1 "$F/u4py.out")"
if [ -z "$U4B" ]; then
    ok "U4: needs_key c флагом hysteria и placeholders(require_auth): auth отсутствует = «ключ не задан»; xray/vless не задет (N54-2)"
else
    bad "U4:$U4B"
fi

# U5: маркеры правок аудита-29 на местах.
U5B=""
grep -q 'FB-52 (аудит-29' "$K/opt/etc/bot/lists_core.py" || U5B="$U5B FB-52(lists_core)"
grep -q 'FB-52 (аудит-29' "$GEN" || U5B="$U5B FB-52(gen)"
grep -q 'N54-3' "$GEN" || U5B="$U5B FB-52(_write_enabled)"
grep -q 'FB-53 (аудит-29' "$GEN" || U5B="$U5B FB-53(gen)"
grep -q 'FB-54 (аудит-29' "$DEP" || U5B="$U5B FB-54(dep)"
grep -q 'FB-54 (аудит-29' "$K/opt/etc/bot/utils.py" || U5B="$U5B FB-54(utils)"
if [ -z "$U5B" ]; then
    ok "U5: маркеры FB-52/FB-53/FB-54 во всех правленых файлах (lists_core, generator, deploy, utils)"
else
    bad "U5: отсутствуют:$U5B"
fi

echo "═══ F47 ИТОГ: PASS=$PASS FAIL=$FAIL ═══"
[ "$FAIL" = 0 ]
